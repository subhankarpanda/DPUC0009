﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.PageObjects;
using FASTSelenium.DataObjects.ADM;

namespace EscrowChargeGenericComp
{
    [CodedUITest, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class FMUC0019_AssignEscrowChargeProcessBusinessParty : MasterTestClass
    {

        public FMUC0019_AssignEscrowChargeProcessBusinessParty()
        {

        }

        #region BAT
        [TestMethod]
        public void FMUC0019_BAT0001()
        {
            Reports.TestDescription = "MF1: Enter an Escrow Charge Process Business Party – Find Code.";
            try
            {
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;//Test should work on HUD and CD
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; 
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                //City = "Santa Ana", 
                                County = "ALAMEDA", 
                                //Country = "USA" 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region CreateNewLoan
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region Navigate to Real Estate Broker/Agent and Enter Invalid Business Source
                Reports.TestStep = "Navigate to Real Estate Broker/Agent and Enter Invalid Business Source.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad(FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode);
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText(@"INVALID_ID");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgentSummary.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnCancel.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion
                #region Navigate to Real Estate Broker/Agent and Enter Valid Business Source
                Reports.TestStep = "Navigate to Real Estate Broker/Agent and Enter Valid Business Source.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Reports.TestStep = "Enter Gab Code and Click on Find.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText(@"HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual(@"(816)154-4610", FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessPhone.FAGetValue());
                Support.AreEqual(@"(694)119-9115", FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessFax.FAGetValue());
                Support.AreEqual(@"(960)406-4197", FastDriver.RealEstateBrokerAgent.BrokerInformationCellPhone.FAGetValue());
                Support.AreEqual(@"(205)461-6841", FastDriver.RealEstateBrokerAgent.BrokerInformationPager.FAGetValue());
                Support.AreEqual("true", FastDriver.RealEstateBrokerAgent.BrokerInformationEmailAddress.FAGetValue().Contains("@").ToString().ToLower());
                string BrokerInfoSalesRep1 = FastDriver.RealEstateBrokerAgent.BrokerInformationSalesRep1.FAGetSelectedItem().ToString();
                if(BrokerInfoSalesRep1 == null)
                {
                    BrokerInfoSalesRep1 = "";
                }
                string BrokerInfoSalesRep2 = FastDriver.RealEstateBrokerAgent.BrokerInformationSalesRep2.FAGetSelectedItem().ToString();
                if (BrokerInfoSalesRep2 == null)
                {
                    BrokerInfoSalesRep2 = "";
                }
                Support.AreEqual(@"", BrokerInfoSalesRep1);//index 0 should be empty
                Support.AreEqual(@"", BrokerInfoSalesRep2);//index 0 should be empty
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"10.00");
                Reports.TestStep = "Click on Done.";
                FastDriver.RealEstateBrokerAgent.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch(Exception e)
            {
                FailTest("Test case FMUC0019_BAT0001 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1: Enter an Escrow Charge Process Business Party – Find Name.";
                Reports.TestStep = "Verify for Fist Instance on Summary Screen and Enter Invalid Name.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;//Test should work on HUD and CD
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; 
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region CreateNewLoan
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region Navigate to Real Estate Broker/Agent and Enter Invalid Business Source Name
                Reports.TestStep = "Navigate to Real Estate Broker/Agent and Enter Invalid Business Source Name.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad(FastDriver.RealEstateBrokerAgent.BrokerInformationName);
                FastDriver.RealEstateBrokerAgent.BrokerInformationName.FASetText(@"INVALID_NAME");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgentSummary.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnCancel.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion
                #region Navigate to Real Estate Broker/Agent and Enter Valid Business Source Name
                Reports.TestStep = "Navigate to Real Estate Broker/Agent and Enter Valid Business Source Name.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Reports.TestStep = "Enter Gab Code and Click on Find.";
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationName.FASetText(@"Other Broker 2");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                Support.AreEqual(@"(710)545-8584", FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessPhone.FAGetValue());
                Support.AreEqual(@"(950)165-4941", FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessFax.FAGetValue());
                Support.AreEqual(@"(962)154-9410", FastDriver.RealEstateBrokerAgent.BrokerInformationCellPhone.FAGetValue());
                Support.AreEqual(@"(741)100-5874", FastDriver.RealEstateBrokerAgent.BrokerInformationPager.FAGetValue());
                Support.AreEqual("true", FastDriver.RealEstateBrokerAgent.BrokerInformationEmailAddress.FAGetValue().Contains("@").ToString().ToLower());
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"20.00");
                Reports.TestStep = "Click on Done.";
                FastDriver.RealEstateBrokerAgent.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch(Exception e)
            {
                FailTest("Test case FMUC0019_BAT0002 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF2: Enter an Escrow Charge Process Business Party – Select from Global Address Book.";
                Reports.TestStep = "Verify for Second Instance on Summary Screen and Select GAB ID from Global Address Book.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;//Test should work on HUD and CD
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; 
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                //City = "Santa Ana", 
                                County = "ALAMEDA", 
                                //Country = "USA" 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region CreateNewLoan
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region Navigate to Real Estate Broker/Agent and Enter Valid Business Source from the Address Book Search Dialog
                Reports.TestStep = "Navigate to Real Estate Broker/Agent and Enter Valid Business Source from the Address Book Search Dialog.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.Click();
                Playback.Wait(1000);
                Reports.TestStep = "Enter Gab Code and Click on Find.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.Click();
                Reports.TestStep = "Select the Code from GAB.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "HUDOTHRBR3");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsRadio.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Enter commission Amount.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"30");
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.Open();
                #endregion
            }
            catch(Exception e)
            {
                FailTest("Test case FMUC0019_BAT0003 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF3: Enter an Escrow Charge Process Business Party – Select from File.";
                Reports.TestStep = "Verify for Third Instance on Summary Screen and Select GAB ID from File Address Book.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD; //Test should work on HUD and CD
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                //City = "Santa Ana", 
                                County = "ALAMEDA", 
                                //Country = "USA" 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region CreateNewLoan
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region Navigate to Real Estate Broker/Agent and Enter Valid Business Source from the Address Book Search Dialog using File Address Book
                Reports.TestStep = "Navigate to Real Estate Broker/Agent and Enter Valid Business Source from the Address Book Search Dialog using File Address Book.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();

                Reports.TestStep = "Enter Gab Code and Click on Find.";
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                Reports.TestStep = "Select the Code from GAB.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.FileaddressBookRadio);
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.FileaddressBookRadio);
                FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.FileaddressBookRadio);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter commission Amount.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"30");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion                
            }
            catch(Exception e)
            {
                FailTest("Test case FMUC0019_BAT0004 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF4: Enter an Escrow Charge Process Business Party – Ad Hoc Entry.";
                Reports.TestStep = "Create an AD-HOC instance of REB.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD; //Test should work on HUD and CD
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                //City = "Santa Ana", 
                                County = "ALAMEDA", 
                                //Country = "USA" 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region CreateNewLoan
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region Navigate to Real Estate Broker/Agent and Enter Valid Business Source from the Address Book Business Organization Ad Hoc Dialog 
                Reports.TestStep = "Navigate to Real Estate Broker/Agent and Enter Valid Business Source from the Address Book Book Business Organization Ad Hoc Dialog";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.FAClick();
                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", timeoutSeconds: 10);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Alameda");
                FastDriver.AddressBookSearchDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Reports.TestStep = "Enter commission Amount.";
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"30");
                Reports.TestStep = "Verify for AD-HOC Instance on Summary Screen.";
                FastDriver.RealEstateBrokerAgent.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.Open();
                Support.AreEqual(@"REB001", FastDriver.RealEstateBrokerAgent.OtherBrokerName.FAGetText());
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_BAT0005 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF5: Change Business Party Name.";
                Reports.TestStep = "Select REB Pend check and issue.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Set Default Check Printer
                SetDefaultCheckPrinter();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD; //Test should work on HUD and CD
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; 
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                //City = "Santa Ana", 
                                County = "ALAMEDA", 
                                //Country = "USA" 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region CreateNewLoan
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000", 
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                //FastDriver.NewLoan.ClickRecapTab();
                //FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region Navigate to Real Estate Broker/Agent and Enter Valid Business Source
                Reports.TestStep = "Navigate to Real Estate Broker/Agent and Enter Valid Business Source.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Reports.TestStep = "Enter Gab Code and Click on Find.";
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText(@"HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                Support.AreEqual(@"(816)154-4610", FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessPhone.FAGetValue());
                Support.AreEqual(@"(694)119-9115", FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessFax.FAGetValue());
                Support.AreEqual(@"(960)406-4197", FastDriver.RealEstateBrokerAgent.BrokerInformationCellPhone.FAGetValue());
                Support.AreEqual(@"(205)461-6841", FastDriver.RealEstateBrokerAgent.BrokerInformationPager.FAGetValue());
                Support.AreEqual("true", FastDriver.RealEstateBrokerAgent.BrokerInformationEmailAddress.FAGetValue().Contains("@").ToString().ToLower());
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"1.00");
                Reports.TestStep = "Click on Done.";
                FastDriver.RealEstateBrokerAgent.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to Active Disbursement Summary and Issue Check
                FastDriver.ActiveDisbursementSummary.Open();                
                Support.AreEqual("Check", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("#1", "Pending", "#3", TableAction.GetText).Message);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", @"Other Broker 1 for HUD Test Name 1 Other", "Status", TableAction.Click);
                Support.AreEqual(true.ToString().ToLower(), FastDriver.ActiveDisbursementSummary.Print.Enabled.ToString().ToLower());
                Reports.TestStep = "Click on Print.";
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.PrintDlg.SendPrint();
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 200);
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.Open();
                string checkNo = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("#1", "Issued", "#5", TableAction.GetText).Message;
                #endregion
                #region Navigate to Real Estate Broker/Agent and Enter Valid Business Source
                Reports.TestStep = "Navigate to Real Estate Broker/Agent and Enter Valid Business Source.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                #endregion
                #region Edit Issued Check
                Reports.TestStep = "Edit Issued Check.";
                string OtherBrokerName = "Other Broker 1 for HUD Test Name 1 Other";
                Support.IsTrue(OtherBrokerName.Contains(FastDriver.RealEstateBrokerAgent.OtherBrokerName.FAGetText().ToString()), "Other Broker Name verification");
                FastDriver.RealEstateBrokerAgent.OtherBrokerNameRow.Click();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.EditOther.Click();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText(@"INVALID_ID");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton : true);
                FastDriver.RealEstateBrokerAgentSummary.Open();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_BAT0006 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_BAT0007()
        {
            try
            {
                Reports.TestDescription = "MF2_AF7_1: Raise a New GAB Entry Request.";
                Reports.TestStep = "Raising New Gab Request.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;//Test should work on HUD and CD
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; 
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                //City = "Santa Ana", 
                                County = "ALAMEDA", 
                                //Country = "USA" 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region Navigate to Home Warranty Detail and Click on Find to Open Address Book Search Dialog
                Reports.TestStep = "Navigate to Home Warranty Detail and Click on Find to Open Address Book Search Dialog.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.Find.Click();
                
                Reports.TestStep = "Select Entity Type and click on Find button at the Address Book Search Dialog.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", timeoutSeconds: 10);
                Playback.Wait(2000);
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.EntityType);
                FastDriver.AddressBookSearchDlg.EntityType.FASelectItem(@"Developer");
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                Playback.Wait(6000);

                Reports.TestStep = "Click on New GAB button.";
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.NewGAB);
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();
                
                Reports.TestStep = "Creates a New GAB Request.";
                FastDriver.GABEntryRequestDlg.WaitForDialogToLoad();
                FastDriver.GABEntryRequestDlg.WaitCreation(FastDriver.GABEntryRequestDlg.EntityType);
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItem(@"Corporate");
                FastDriver.GABEntryRequestDlg.Name1.FASetText(@"Name 1 TFS 106786");
                FastDriver.GABEntryRequestDlg.Name2.FASetText(@"Name 2 TFS 106786");
                FastDriver.GABEntryRequestDlg.LocDescription.FASetText(@"Loc Description");
                FastDriver.GABEntryRequestDlg.TaxIDNumber.FASetText(@"1111111111");
                FastDriver.GABEntryRequestDlg.BusOrgComments.FASetText(@"Bus Org Comments");
                FastDriver.GABEntryRequestDlg.EntryInstructions.FASetText(@"Entity Instruction");
                FastDriver.GABEntryRequestDlg.MailingAddressLine1.FASetText(@"1 First American Way");
                FastDriver.GABEntryRequestDlg.MailingAddressCity.FASetText(@"Santa Ana");
                FastDriver.GABEntryRequestDlg.MailingAddressState.FASelectItem(@"CA");
                FastDriver.GABEntryRequestDlg.MailingAddressZip.FASetText(@"92707");
                FastDriver.GABEntryRequestDlg.MailingAddressCounty.FASetText(@"Orange");
                FastDriver.GABEntryRequestDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(2000);

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame(); 
                FastDriver.HomeWarrantyDetail.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();
                #endregion
                //#region Verifying for label of Business Party for Request Raised
                //Reports.TestStep = "Verifying for label of Business Party for Request Raised.";
                //FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                //FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                //#endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_BAT0007 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_BAT0008()
        {
            try
            {
                Reports.TestDescription = "MF2_AF7_2: Approve the Gab Request.";
                _ADMLOGIN();
                
                Reports.TestStep = "Double Click on the Gab search results table.";
                FastDriver.LeftNavigation.Navigate<GABEntryRequestQueue>(@"Home>System Maintenance>GAB Entry Request Queue").WaitForGABEntryRequestTableToLoad();
                FastDriver.GABEntryRequestQueue.GABEntryRequestTable.PerformTableAction("#6", "Name 1 TFS 106786", "#1", TableAction.DoubleClick);

                Reports.TestStep = "Click on Find and Select gab.";
                FastDriver.AddressBookSearch.WaitForScreenToLoad();
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10, true);
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad(timeout: 10);
                FastDriver.AddressBookSearch.AddToGAB.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Add to GAB", timeoutSeconds: 10);
                Playback.Wait(5000);
                FastDriver.BusPartyOrgSetUpAddToGABDlg.SwitchToDialogContentFrame();
                FastDriver.BusPartyOrgSetUpAddToGABDlg.Done.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                
                Reports.TestStep = "Click on Done button";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Add to GAB", timeoutSeconds: 10);
                Playback.Wait(5000);
                FastDriver.BusPartyOrgSetUpAddToGABDlg.SwitchToDialogContentFrame();
                FastDriver.BusPartyOrgSetUpAddToGABDlg.Done.FAClick();
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_BAT0008 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_BAT0009()
        {
            try
            {
                Reports.TestDescription = "MF3_AF6_1: Raise a modify GAB request.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;//Test should work on HUD and CD
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                //City = "Santa Ana", 
                                County = "ALAMEDA", 
                                //Country = "USA" 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region Navigate to Home Warranty and click on Find button
                Reports.TestStep = "Navigate to Home Warranty Detail and Click on Find to Open Address Book Search Dialog.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.Find.Click();
                #endregion
                #region Enter Name and click on Find and select the search result and click on Modify GAB
                Reports.TestStep = "Enter Name and click on Find and select the search result and click on Modify GAB.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", timeoutSeconds: 10);
                Playback.Wait(2000);
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.EntityName);
                FastDriver.AddressBookSearchDlg.EntityName.FASetText(@"Name 1 TFS 106786");
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10, true);
                Playback.Wait(2000);
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.SearchResultsRadio);
                FastDriver.AddressBookSearchDlg.SearchResultsRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.ModifyGAB);
                FastDriver.AddressBookSearchDlg.ModifyGAB.FAClick();

                Reports.TestStep = "Edit Contacts.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Request GAB Entry", timeoutSeconds: 10);
                Playback.Wait(2000); //wait for dialog content to be rendered
                FastDriver.GABEntryRequestDlg.SwitchToDialogContentFrame();
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.WaitCreation(FastDriver.GABEntryRequestDlg.Name1);
                FastDriver.GABEntryRequestDlg.Name1.FASetText(@"BusinessPartyOrganizationSetUp");
                FastDriver.GABEntryRequestDlg.Name2.FASetText(@"A Division Of First American Title Ins.");
                FastDriver.GABEntryRequestDlg.BusinessPhoneNumber.FASetText(@"(616)451-2290");
                FastDriver.GABEntryRequestDlg.BusinessFaxNumber.FASetText(@"(616)451-2290");
                FastDriver.GABEntryRequestDlg.EmailNumber.FASetText(@"nzkvkjzr@aol.com");
                FastDriver.GABEntryRequestDlg.HomePhoneNumber.FASetText(@"(714)800-1570");
                FastDriver.GABEntryRequestDlg.HomeFaxNumber.FASetText(@"(714)800-1570");
                FastDriver.GABEntryRequestDlg.MailingAddressLine1.FASetText(@"15441 94Th Avenue");
                FastDriver.GABEntryRequestDlg.MailingAddressCity.FASetText(@"Orland Park");
                FastDriver.GABEntryRequestDlg.MailingAddressState.FASelectItem(@"IL");
                FastDriver.GABEntryRequestDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(2000);

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                FastDriver.HomeWarrantyDetail.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();
                #endregion
            }
            catch(Exception e)
            {
                FailTest("Test case FMUC0019_BAT0009 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_BAT0010()
        {
            try
            {
                Reports.TestDescription = "MF3_AF6_2: Add Contacts.";
                _ADMLOGIN();

                Reports.TestStep = "Double Click on the Gab search results table for adding contacts.";
                FastDriver.LeftNavigation.Navigate<GABEntryRequestQueue>(@"Home>System Maintenance>GAB Entry Request Queue").WaitForGABEntryRequestTableToLoad();
                FastDriver.GABEntryRequestQueue.GABEntryRequestTable.PerformTableAction(6, "BusinessPartyOrganizationSetUp", 1, TableAction.DoubleClick);

                /*
                Reports.TestStep = "Click on View Modify contacts.";
                FastDriver.BusinessPartyOrganizationSetUpDlg.SwitchToDialogLeftContentFrame();
                FastDriver.BusinessPartyOrganizationSetUpDlg.WaitCreation(FastDriver.BusinessPartyOrganizationSetUpDlg.EntityType);
                FastDriver.BusinessPartyOrganizationSetUpDlg.AddModifyContact.ScrollIntoView(); // Bring element into view
                FastDriver.BusinessPartyOrganizationSetUpDlg.AddModifyContact.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                Playback.Wait(2000);
                FastDriver.DialogBottomFrame.ClickDone();
                */

                Reports.TestStep = "Click on Copy and change status to Modified and Click on Done.";
                FastDriver.BusinessPartyOrganizationSetUpDlg.WaitForScreenToLoad(element: FastDriver.BusinessPartyOrganizationSetUpDlg.AddressTable);
                FastDriver.BusinessPartyOrganizationSetUpDlg.AddressTable.PerformTableAction("Type", "Billing", "Type", TableAction.Click);
                FastDriver.BusinessPartyOrganizationSetUpDlg.Copy.FAClick();
                FastDriver.BusinessPartyOrganizationSetUpDlg.Status.FASelectItem(@"Modified");
                FastDriver.BusinessPartyOrganizationSetUpDlg.Done.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch(Exception e)
            {
                FailTest("Test case FMUC0019_BAT0010 failed because " + e.Message);
            }
        }

        #endregion

        #region Regression
        [TestMethod]
        public void FMUC0019_REG0001()
        {
            try
            {
                Reports.TestDescription = "FMFM881_FM887_FM1627_ES6126_ES6127_ES6349_ES6350_ES6353_ES6352_ES6128_ES6129_FM889_EWC2: Select the Business Party For Create a file, Display Global Indicator, Default Contact Info to Bus Org when Edit Name Selected and attentio";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Set Default Check Printer
                SetDefaultCheckPrinter();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD; //Test should work on HUD and CD
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                //City = "Santa Ana", 
                                County = "ALAMEDA", 
                                //Country = "USA" 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region Navigate to Utility Screen
                Reports.TestStep = "Navigate to Utility Screen.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                #endregion
                #region To enter Buyer charge
                Reports.TestStep = "To enter Buyer charge.";
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Save Changes without Bus Party
                Reports.TestStep = "Save Changes without Bus Party.";
                FastDriver.WebDriver.HandleDialogMessage(); 
                #endregion
                #region FM881 - Verify for Business Party Required Error
                Reports.TestStep = "FM881 - Verify for Business Party Required Error.";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.UtilityDetail.ErrorMessageList.FAGetText().Contains("BusOrgID: Business Party required").ToString().ToLower());
                #endregion
                #region Enter Business Party and charges after getting Business Party is required field error
                Reports.TestStep = "Enter Business Party and charges after getting Business Party is required field error.";
                FastDriver.UtilityDetail.SwitchToContentFrame(); 
                FastDriver.UtilityDetail.FindGABcode(@"HUDUTLCMP1");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                #endregion
                #region Verify that GAB Code is accepted
                Reports.TestStep = "Verify that GAB Code is accepted.";
                Support.AreEqual(@"HUDUTLCMP1", FastDriver.UtilityDetail.GabCodeLabel.FAGetText());
                #endregion
                #region Verify for the Global Indicator
                Reports.TestStep = "Verify for the Global Indicator.";
                Support.AreEqual("true", FastDriver.UtilityDetail.GlobalIndicator.Exists().ToString().ToLower());
                #endregion
                #region To click on Find button under business party.
                Reports.TestStep = "To click on Find button under business party.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.Find.FAClick();
                #endregion
                #region Select a Entity Type and Click on Find Button
                Reports.TestStep = "Select a Entity Type and Click on Find Button.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", timeoutSeconds: 10);
                Playback.Wait(2000); //wait for dialog content to be rendered
                FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.EntityType, 10);
                FastDriver.AddressBookSearchDlg.EntityType.FASelectItem(@"Lender");
                FastDriver.AddressBookSearchDlg.EntityName.FASetText(@"b*");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.SearchResultsTable);
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("ID Code", "588", "Select", TableAction.Click);
                Support.AreEqual("true", FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("ID Code", "588", "Select", TableAction.GetAttribute, "selected").Message.ToString().ToLower());
                FastDriver.AddressBookSearchDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick(); 
                #endregion
                #region Verify that GAB Code is accepted
                Reports.TestStep = "Verify that GAB Code is accepted.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Support.AreEqual("588", FastDriver.UtilityDetail.GabCodeLabel.FAGetText().ToString().Trim());
                #endregion
                #region Verify for the Global Indicator
                Reports.TestStep = "Verify for the Global Indicator.";
                Support.AreEqual("true", FastDriver.UtilityDetail.GlobalIndicator.Exists().ToString().ToLower());
                #endregion
                #region Enter the Reference Number
                Reports.TestStep = "Enter the Reference Number.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.Reference.FASetText(@"12345");
                #endregion
                #region Replace Existing Gab Having Reference No with New one
                Reports.TestStep = "Replace Existing Gab Having Reference No with New one.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText(@"247");
                FastDriver.UtilityDetail.Find.FAClick();
                #endregion
                #region Change Business Party have Ref No.
                Reports.TestStep = "Change Business Party have Ref No.";
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion
                #region Verify that Reference Number exists after clicking on OK in Warning Dialog
                Reports.TestStep = "Verify that Reference Number exists after clicking on OK in Warning Dialog.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Support.AreEqual(@"12345", FastDriver.UtilityDetail.Reference.FAGetValue());
                #endregion
                #region Replace Existing Gab Having Reference No with New one
                Reports.TestStep = "Replace Existing Gab Having Reference No with New one.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText(@"247");
                FastDriver.UtilityDetail.Find.FAClick();
                #endregion
                #region User tries to change a Business Party which has a Reference number specified against it
                Reports.TestStep = "User tries to change a Business Party which has a Reference number specified against it.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                #endregion
                #region Verify that Reference Number gets removed after clicking on cancel in Warning Dialog
                Reports.TestStep = "Verify that Reference Number gets removed after clicking on cancel in Warning Dialog.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Support.AreEqual(@"", FastDriver.UtilityDetail.Reference.FAGetValue()); 
                #endregion
                #region Verify that edit checkbox is Uncheck and Contact information are disable. Cant edit the contact info without Check edit checkbox.
                Reports.TestStep = "Verify that edit checkbox is Uncheck and Contact information are disable. Cant edit the contact info without Check edit checkbox.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Support.AreEqual("false", FastDriver.UtilityDetail.Edit.Selected.ToString().ToLower());
                Support.AreEqual("false", FastDriver.UtilityDetail.BusPhone.Enabled.ToString().ToLower());
                Support.AreEqual("false", FastDriver.UtilityDetail.BusFax.Enabled.ToString().ToLower());
                Support.AreEqual("false", FastDriver.UtilityDetail.CellPhone.Enabled.ToString().ToLower());
                Support.AreEqual("false", FastDriver.UtilityDetail.Pager.Enabled.ToString().ToLower());
                Support.AreEqual("false", FastDriver.UtilityDetail.EmailAddress.Enabled.ToString().ToLower());
                #endregion
                #region Check the edit Checkbox and Enter Contact Info
                Reports.TestStep = "Check the edit Checkbox and Enter Contact Info.";
                FastDriver.UtilityDetail.Edit.FAClick();
                FastDriver.UtilityDetail.BusPhone.FASetText(@"1234567890");
                FastDriver.UtilityDetail.BusFax.FASetText(@"1234567890");
                FastDriver.UtilityDetail.CellPhone.FASetText(@"1234567890");
                FastDriver.UtilityDetail.Pager.FASetText(@"1234567890");
                FastDriver.UtilityDetail.EmailAddress.FASetText(@"Regresion@firstam.com");
                FastDriver.UtilityDetail.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                #endregion
                #region EWC7- Validate When the user enters an invalid e-Mail address-Error.
                Reports.TestStep = "EWC7- Validate When the user enters an invalid e-Mail address-Error.";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.EmailAddress.FASetText(@"Regresion@firstam");
                FastDriver.UtilityDetail.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion
                #region Validate When the user enters an valid e-Mail address-Error.
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.EmailAddress.FASetText(@"Regresion@firstam.com");
                FastDriver.UtilityDetail.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Verify that System allowed to Edit the Contact Information after Check the edit name check box
                Reports.TestStep = "Verify that System allowed to Edit the Contact Information after Check the edit name check box.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Support.AreEqual(@"(123)456-7890", FastDriver.UtilityDetail.BusPhone.FAGetValue());
                Support.AreEqual(@"(123)456-7890", FastDriver.UtilityDetail.BusFax.FAGetValue());
                Support.AreEqual(@"(123)456-7890", FastDriver.UtilityDetail.CellPhone.FAGetValue());
                Support.AreEqual(@"(123)456-7890", FastDriver.UtilityDetail.Pager.FAGetValue());
                Support.AreEqual(@"Regresion@firstam.com", FastDriver.UtilityDetail.EmailAddress.FAGetValue());
                #endregion
                #region Verify that on deselect the edit checkbox system will revert all the original contact info from the Gab Code.
                Reports.TestStep = "Verify that on deselect the edit checkbox system will revert all the original contact info from the Gab Code.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.Edit.FASetCheckbox(false);
                Support.AreNotEqual(@"(123)456-7890", FastDriver.UtilityDetail.BusPhone.FAGetValue());
                Support.AreNotEqual(@"(123)456-7890", FastDriver.UtilityDetail.BusFax.FAGetValue());
                Support.AreNotEqual(@"(123)456-7890", FastDriver.UtilityDetail.CellPhone.FAGetValue());
                Support.AreNotEqual(@"(123)456-7890", FastDriver.UtilityDetail.Pager.FAGetValue());
                Support.AreNotEqual(@"Regresion@firstam.com", FastDriver.UtilityDetail.EmailAddress.FAGetValue());
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"10");
                #endregion
                #region Print All Checks
                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.Click();
                FastDriver.PrintChecks.SwitchToContentFrame();
                #endregion
                #region Click on Deliver
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog.";
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Enter Invalid Gab or Change the Gab for Issued Instance
                Reports.TestStep = "Enter Invalid Gab or Change the Gab for Issued Instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText(@"XCHZ");
                FastDriver.UtilityDetail.Find.FAClick();
                #endregion
                //#region Change Payee To whom check issued
                //Reports.TestStep = "Change Payee To whom check issued.";
                //FastDriver.WebDriver.HandleDialogMessage();
                //FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                //FastDriver.UtilityDetail.SwitchToContentFrame();
                //#endregion

            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0001 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0002()
        {
            try
            {
                Reports.TestDescription = "Get the value of address of the gab from address book";
                #region LOGIN
                _ADMLOGIN();
                #endregion
                #region Search a GAB in Address Book and click on Edit button
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText(@"utility");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad(timeout: 10);
                FastDriver.AddressBookSearch.EditAddress(@"UTILITY");
                #endregion
                #region Get the value of business phone, fax, email of the Gab
                Reports.TestStep = "Get the value of business phone, fax, email of the Gab";
                FastDriver.BusPartyOrgSetUp.SwitchToContentFrame();
                string BusPhone = FastDriver.BusPartyOrgSetUp.BusinessPhoneTypeNumber.FAGetValue().ToString();
                Support.DataSave("BusinessPhoneTypeNumber", "BusPhone", BusPhone);
                string BusFax = FastDriver.BusPartyOrgSetUp.BusinessFaxTypeNumber.FAGetValue().ToString();
                Support.DataSave("BusinessFaxTypeNumber", "BusFax", BusFax);
                string BusEmail = FastDriver.BusPartyOrgSetUp.EmailNumber.FAGetValue().ToString();
                Support.DataSave("EmailNumber", "BusEmail", BusEmail);
                string BusPager = FastDriver.BusPartyOrgSetUp.PagerNumber.FAGetValue().ToString();
                Support.DataSave("PagerNumber", "BusPager", BusPager);
                string CellPhone = FastDriver.BusPartyOrgSetUp.CellularNumber.FAGetValue().ToString();
                Support.DataSave("CellularNumber", "CellPhone", CellPhone);
                #endregion
                #region Search a GAB in Address Book and click on Edit button for the Gab code Hudflinsr1
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button for the Gab code Hudflinsr1";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText(@"Hudflinsr1");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad(timeout: 10);
                FastDriver.AddressBookSearch.EditAddress(@"HUDFLINSR1");
                #endregion
                #region Get the value of business phone, fax, email of the Gab code Hudflinsr1
                Reports.TestStep = "Get the value of business phone, fax, email of the Gab code Hudflinsr1";
                FastDriver.BusPartyOrgSetUp.SwitchToContentFrame();
                string BusPhoneHudflinsr1 = FastDriver.BusPartyOrgSetUp.BusinessPhoneTypeNumber.FAGetValue().ToString();
                Support.DataSave("BusinessPhoneTypeNumber", "BusPhoneHudflinsr1", BusPhone);
                string BusFaxHudflinsr1 = FastDriver.BusPartyOrgSetUp.BusinessFaxTypeNumber.FAGetValue().ToString();
                Support.DataSave("BusinessFaxTypeNumber", "BusFaxHudflinsr1", BusFax);
                string BusPagerHudflinsr1 = FastDriver.BusPartyOrgSetUp.PagerNumber.FAGetValue().ToString();
                Support.DataSave("PagerNumber", "BusPagerHudflinsr1", BusPager);
                string CellPhoneHudflinsr1 = FastDriver.BusPartyOrgSetUp.CellularNumber.FAGetValue().ToString();
                Support.DataSave("CellularNumber", "CellPhoneHudflinsr1", CellPhone);
                string EmailHudflinsr1 = FastDriver.BusPartyOrgSetUp.EmailNumber.FAGetValue().ToString();
                Support.DataSave("EmailNumber", "EmailHudflinsr1", BusEmail);                
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0002 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0003()
        {
            try
            {
                Reports.TestDescription = "BR_ES6282_ES6357_ES6196_ES6355_FM886_FM1835_FM1836_ECW5: Verifying the Contact Information after Edit the name Select ,Attention Field.";
                #region Variable Declaration
                bool IsFormTypeCD = false;
                string BusPhone1, BusPhoneFax1, BusCellPhone1, BusEmail1, BusPhoneHudflinsr1, BusFaxHudflinsr1, CellPhoneHudflinsr1, BusPagerHudflinsr1, EmailHudflinsr1, data, SelectedIndex, ExpectedMsg, ActualMsg = "";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD; //Test should work on HUD and CD
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                //City = "Santa Ana", 
                                County = "ALAMEDA", 
                                //Country = "USA" 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Change Attention value
                Reports.TestStep = "Change Attention value.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyAttention.SendKeys(FAKeys.Down);
                FastDriver.FileHomepage.AcceptDialogAndCompareWith();
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow:true);
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion
                #region Save the values of business fax, phone and email of the attention contact
                Reports.TestStep = "Save the values of business fax, phone and email of the attention contact";
                BusPhone1 = FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue().ToString();
                Support.DataSave("BusinessPartyBusPhone", "busphone1", BusPhone1);
                BusPhoneFax1 = FastDriver.FileHomepage.BusinessPartyBusFax.FAGetValue().ToString();
                Support.DataSave("BusinessPartyBusFax", "busphonefax1", BusPhoneFax1);
                BusCellPhone1 = FastDriver.FileHomepage.BusinessPartyCellPhone.FAGetValue().ToString();
                Support.DataSave("BusinessPartyCellPhone", "buscellphone1", BusCellPhone1);
                BusEmail1 = FastDriver.FileHomepage.BusinessPartyEmailAddress.FAGetValue().ToString();
                Support.DataSave("BusinessPartyEmailAddress", "busemail1", BusEmail1);
                //the following  data needs to be saved for the subsequent verifications...
                Support.DataSave("BusinessPartyBusPhone", "BusPhone", "(171)111-1111");
                Support.DataSave("BusinessPartyBusFax", "BusFax", "(171)111-1112");
                Support.DataSave("BusinessPartyCellPhone", "CellPhone", "(171)111-1114");
                Support.DataSave("BusinessPartyBusPager", "BusPager", "(171)111-1113");
                #endregion
                #region Click on Home
                Reports.TestStep = "Click on Home.";
                FastDriver.LeftNavigation.Navigate<HomePage>("Home").WaitForHomeScreen();
                #endregion
                #region User navigates away after update page
                Reports.TestStep = "User navigates away after update page.";
                ExpectedMsg = "Exit without saving changes?";
                Support.AreEqual(ExpectedMsg, FastDriver.WebDriver.HandleDialogMessage());
                #endregion
                #region User updates the file and navigates off the File Homepage and answers “OK” to the “Exit without save changes?” prompt
                Reports.TestStep = "User updates the file and navigates off the File Homepage and answers “OK” to the “Exit without save changes?” prompt.";
                ExpectedMsg = "All modified information will be erased for this order.\r\nDo you wish to cancel this entry?";
                Support.AreEqual(ExpectedMsg, FastDriver.WebDriver.HandleDialogMessage());
                #endregion
                #region Set an instance of Utility details
                Reports.TestStep = "Set an instance of Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                #endregion
                #region Enter charges and make payment method as CHK
                Reports.TestStep = "Enter charges and make payment method as CHK.";
                if(!AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"10.00");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"10.00");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(@"10.00");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(@"10.00");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.UtilityDetail.WaitForScreenToLoad();

                    Reports.TestStep = "Verify Buyer Charges at Utility Source Screen";
                    Support.AreEqual(@"10.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue());
                    
                    Reports.TestStep = "Verify Seller Charges at Utility Source Screen";
                    Support.AreEqual(@"10.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue());
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem(@"CHK");
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem(@"CHK");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"2.50");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"2.50");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.UtilityDetail.WaitForScreenToLoad();
                }
                #endregion
                #region Verify the default contact information
                Reports.TestStep = "Verify the default contact information.";
                Support.DataLoad("BusPhone", "BusPhone");
                data = Support.data;//has the data from the previous DataLoad method
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString().Trim());
                Support.DataLoad("BusFax", "BusFax");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusFax.FAGetValue().ToString().Trim());
                Support.DataLoad("CellPhone", "CellPhone");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.CellPhone.FAGetValue().ToString().Trim());
                Support.DataLoad("Pager", "BusPager");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.Pager.FAGetValue().ToString().Trim());
                Support.AreEqual("true", FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString().Contains("@").ToString().ToLower());
                #endregion
                #region Verify that attention drop down is enabled
                Reports.TestStep = "Verify that attention drop down is enabled.";
                Support.AreEqual("true", FastDriver.UtilityDetail.Attention.Enabled.ToString().ToLower());
                #endregion
                #region Verify Enter Name if Checkbox is checked
                Reports.TestStep = "Verify Enter Name if Check box is Checked.";
                FastDriver.UtilityDetail.EditName.FASetCheckbox(true);
                #endregion
                #region Verify the default contact information again
                Reports.TestStep = "Verify the default contact information again.";
                //check the GAB or business party because the values are not matching...
                Support.DataLoad("BusPhone", "BusPhone");
                data = Support.data;//has the data from the previous DataLoad method
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString().Trim());
                Support.DataLoad("BusFax", "BusFax");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusFax.FAGetValue().ToString().Trim());
                Support.DataLoad("CellPhone", "CellPhone");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.CellPhone.FAGetValue().ToString().Trim());
                Support.DataLoad("Pager", "BusPager");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.Pager.FAGetValue().ToString().Trim());
                Support.AreEqual("true", FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString().Contains("@").ToString().ToLower());
                #endregion
                #region Verify that attention drop down is disabled
                Reports.TestStep = "Verify that attention drop down is disabled.";
                Support.AreEqual("false", FastDriver.UtilityDetail.Attention.Enabled.ToString().ToLower());
                #endregion
                #region Deselect the edit name checkbox
                Reports.TestStep = "Deselect the edit name checkbox.";
                FastDriver.UtilityDetail.EditName.FASetCheckbox(false);
                #endregion
                #region Verify that attention drop down is enable
                Reports.TestStep = "Verify that attention drop down is enable.";
                Support.AreEqual("true", FastDriver.UtilityDetail.Attention.Enabled.ToString().ToLower());
                #endregion
                #region Verify the default contact information 3
                Reports.TestStep = "Verify the default contact information 3.";
                //check the GAB or business party because the values are not matching...
                Support.DataLoad("BusPhone", "BusPhone");
                data = Support.data;//has the data from the previous DataLoad method
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString().Trim());
                Support.DataLoad("BusFax", "BusFax");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusFax.FAGetValue().ToString().Trim());
                Support.DataLoad("CellPhone", "CellPhone");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.CellPhone.FAGetValue().ToString().Trim());
                Support.DataLoad("Pager", "BusPager");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.Pager.FAGetValue().ToString().Trim());
                Support.AreEqual("true", FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString().Contains("@").ToString().ToLower());
                #endregion
                #region Change the Business GAB Code
                Reports.TestStep = "Change the Business GAB Code.";
                /* this sections' comparisons fail because data on the file 
                should have been saved with the expected values, but 
                this was not done on the Coded UI tests this was based on
                */
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.FindGABcode(@"Hudflinsr1");
                //begins saving data for GAB code Hudflinsr1 because it will be loaded later
                BusPhoneHudflinsr1 = FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString();
                Support.DataSave("BusinessPartyBusPhone", "BusPhoneHudflinsr1", BusPhoneHudflinsr1);
                BusFaxHudflinsr1 = FastDriver.UtilityDetail.BusFax.FAGetValue().ToString();
                Support.DataSave("BusinessPartyBusFax", "BusFaxHudflinsr1", BusFaxHudflinsr1);
                CellPhoneHudflinsr1 = FastDriver.UtilityDetail.CellPhone.FAGetValue().ToString();
                Support.DataSave("BusinessPartyCellPhone", "CellPhoneHudflinsr1", CellPhoneHudflinsr1);
                BusPagerHudflinsr1 = FastDriver.UtilityDetail.Pager.FAGetValue().ToString();
                Support.DataSave("BusinessPartyEmailAddress", "BusPagerHudflinsr1", BusPagerHudflinsr1);
                EmailHudflinsr1 = FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString();
                Support.DataSave("BusinessPartyEmailAddress", "EmailHudflinsr1", EmailHudflinsr1);
                //end saving 
                Support.DataLoad("BusPhone", "BusPhoneHudflinsr1");
                data = Support.data;//has the data from the previous DataLoad method
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString().Trim());//check this
                Support.DataLoad("BusFax", "BusFaxHudflinsr1");  //check this
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusFax.FAGetValue().ToString().Trim());
                Support.DataLoad("CellPhone", "CellPhoneHudflinsr1");  //check this
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.CellPhone.FAGetValue().ToString().Trim());
                Support.DataLoad("Pager", "BusPagerHudflinsr1"); //check this
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.Pager.FAGetValue().ToString().Trim());
                Support.DataLoad("EmailAddress", "EmailHudflinsr1");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString().Trim());
                Support.AreEqual("true", FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString().Contains("@").ToString().ToLower());
                FastDriver.UtilityDetail.Attention.SendKeys(FAKeys.Down);
                #endregion
                #region Verify the contact information after Select attention name
                Reports.TestStep = "Verify the contact information after Select attention name.";
                /* this sections' comparisons fail because data on the file 
                should have been saved with the expected values, but 
                this was not done on the Coded UI tests this was based on
                */
                Support.DataLoad("BusPhone", "busphone1");
                data = Support.data;//has the data from the previous DataLoad method
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString().Trim());
                //Support.DataLoad("BusFax", "busphonefax1");//check this
                Support.DataLoad("BusFax", "BusFaxHudflinsr1");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusFax.FAGetValue().ToString().Trim());
                //Support.DataLoad("CellPhone", "buscellphone1");//check this
                Support.DataLoad("CellPhone", "CellPhoneHudflinsr1");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.CellPhone.FAGetValue().ToString().Trim());
                Support.AreEqual("true", FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString().Contains("@").ToString().ToLower());
                #endregion
                #region Verify Enter Name if Check box is Checked
                Reports.TestStep = "Verify Enter Name if Check box is Checked.";
                FastDriver.UtilityDetail.EditName.FASetCheckbox(true);
                #endregion
                #region Verify that on Select the Edit Name check Box, Contact information revert backs to Primary contacts and no value in attention drop down
                Reports.TestStep = "Verify that on Select the Edit Name check Box, Contact information revert backs to Primary contacts and no value in attention drop down.";
                /* this sections' comparisons fail because data on the file 
                should have been saved with the expected values, but 
                this was not done on the Coded UI tests this was based on
                */
                Support.DataLoad("BusPhone", "busphone1");
                data = Support.data;//has the data from the previous DataLoad method
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString().Trim());
                Support.DataLoad("BusFax", "busphonefax1");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusFax.FAGetValue().ToString().Trim());//check this
                Support.DataLoad("CellPhone", "buscellphone1");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.CellPhone.FAGetValue().ToString().Trim());//check this
                Support.AreEqual("true", FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString().Contains("@").ToString().ToLower());
                SelectedIndex = FastDriver.UtilityDetail.Attention.GetAttribute("SelectedIndex");
                if(SelectedIndex == null)
                {
                    SelectedIndex = "";
                }
                //Support.AreEqual(@"0", SelectedIndex);//check this. This should not expect index Zero because the dropdown is disabled
                Support.AreEqual(@"", SelectedIndex);//No value should be an empty string instead of Zero
                #endregion
                #region Change the Business GAB Code again
                Reports.TestStep = "Change the Business GAB Code again.";
                /* this sections' comparisons fail because data on the file 
                should have been saved with the expected values, but 
                this was not done on the Coded UI tests this was based on
                */
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.FindGABcode(@"Hudflinsr1");
                Support.DataLoad("BusPhone", "BusPhoneHudflinsr1");
                data = Support.data;//has the data from the previous DataLoad method
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString().Trim());
                Support.DataLoad("BusPhone", "BusFaxHudflinsr1");  //check this
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.BusFax.FAGetValue().ToString().Trim());
                Support.DataLoad("BusPhone", "CellPhoneHudflinsr1");  //check this
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.CellPhone.FAGetValue().ToString().Trim());
                Support.DataLoad("BusPhone", "BusPagerHudflinsr1"); //check this
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.Pager.FAGetValue().ToString().Trim());
                Support.DataLoad("EmailAddress", "EmailHudflinsr1");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString().Trim());
                Support.AreEqual("true", FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString().Contains("@").ToString().ToLower());
                FastDriver.UtilityDetail.Attention.SendKeys(FAKeys.Down);//index: 1
                #endregion
                #region Select the edit contact check box
                Reports.TestStep = "Select the edit contact check box.";
                FastDriver.UtilityDetail.Edit.FASetCheckbox(true);
                #endregion
                #region Select the attention field
                Reports.TestStep = "Select the attention field.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.Attention.SendKeys(FAKeys.Down);//index: 1
                #endregion
                #region Verify that after Select the attention field, system should automatically deselect the contact edit check box
                Reports.TestStep = "Verify that after Select the attention field, system should automatically deselect the contact edit check box.";
                Support.AreEqual("true", FastDriver.UtilityDetail.Edit.Selected.ToString().ToLower());
                #endregion
                #region Verify Enter Name if Check box is Checked
                Reports.TestStep = "verify Enter Name if Check box is Checked.";
                FastDriver.UtilityDetail.EditName.FASetCheckbox(true);
                #endregion
                #region Verify that attention drop down is disable
                Reports.TestStep = "Verify that attention drop down is disabled.";
                Support.AreEqual("false", FastDriver.UtilityDetail.Attention.Enabled.ToString().ToLower());
                #endregion
                #region Deselect the edit name checkbox.
                Reports.TestStep = "Deselect the edit name checkbox.";
                FastDriver.UtilityDetail.EditName.FASetCheckbox(false);
                #endregion
                #region Verify that attention drop down is enable
                Reports.TestStep = "Verify that attention drop down is enable.";
                Support.AreEqual("true", FastDriver.UtilityDetail.Attention.Enabled.ToString().ToLower());
                #endregion
                #region Select the attention field again
                Reports.TestStep = "Select the attention field again.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.Attention.SendKeys(FAKeys.Down);//index: 1
                #endregion
                #region Verify Enter Name if Check box is Checked
                Reports.TestStep = "Verify Enter Name if Check box is Checked.";
                FastDriver.UtilityDetail.EditName.FASetCheckbox(true);
                #endregion
                #region Verify that attention drop down is disable.
                Reports.TestStep = "Verify that attention drop down is disable.";
                Support.AreEqual("false", FastDriver.UtilityDetail.Attention.Enabled.ToString().ToLower());
                #endregion
                #region Enter the name in Edit name field
                Reports.TestStep = "Enter the name in Edit name field.";
                FastDriver.UtilityDetail.Name.FASetText(@"Edit Name");
                #endregion
                #region BR FM1836 - Validate system populates the contact details when business party has a contact in the Attention field
                Reports.TestStep = "BR FM1836 - Validate system populates the contact details when business party has a contact in the Attention field.";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.EditName.FASetCheckbox(false);
                FastDriver.UtilityDetail.Attention.SendKeys(FAKeys.Down);//index: 1
                //Contact
                FastDriver.UtilityDetail.EditContact.FASetCheckbox(false);
                Playback.Wait(2000);
                /* The following condition should check that the field is not populated (length == 0)
                 * and that is not enabled (!Enabled), so the test won't fail believing that the field was 
                 * populated and not enabled
                 */
                //Contact Phone
                if (FastDriver.UtilityDetail.BusPhoneContact.FAGetValue().Length > 0 && !FastDriver.UtilityDetail.BusPhoneContact.Enabled)
                    Reports.StatusUpdate("Contact Phone field populates and is not enabled", true);
                else if (FastDriver.UtilityDetail.BusPhoneContact.FAGetValue().Length > 0 && FastDriver.UtilityDetail.BusPhoneContact.Enabled)
                    Reports.StatusUpdate("Contact Phone field populates and should not be enabled", false);
                else if (FastDriver.UtilityDetail.BusPhoneContact.FAGetValue().Length <= 0 && !FastDriver.UtilityDetail.BusPhoneContact.Enabled)
                    Reports.StatusUpdate("Contact Phone field doesn't populate and is not enabled", true);
                else
                    Reports.StatusUpdate("Contact Phone field doesn't populate and should not be enabled", false);
                //Fax Contact
                if (FastDriver.UtilityDetail.BusFaxContact.FAGetValue().Length > 0 && !FastDriver.UtilityDetail.BusFaxContact.Enabled)
                    Reports.StatusUpdate("Contact Fax field populates and is not enabled", true);
                else if (FastDriver.UtilityDetail.BusFaxContact.FAGetValue().Length > 0 && FastDriver.UtilityDetail.BusFaxContact.Enabled)
                    Reports.StatusUpdate("Contact Fax field populates and should not be enabled", false);
                else if (FastDriver.UtilityDetail.BusFaxContact.FAGetValue().Length <= 0 && !FastDriver.UtilityDetail.BusFaxContact.Enabled)
                    Reports.StatusUpdate("Contact Fax field doesn't populate and is not be enabled", true);
                else
                    Reports.StatusUpdate("Contact Fax field doesn't populate and should not be enabled", false);
                //Cell Phone Contact
                if (FastDriver.UtilityDetail.CellPhoneContact.FAGetValue().Length > 0 && !FastDriver.UtilityDetail.CellPhoneContact.Enabled)
                    Reports.StatusUpdate("Contact Cell number field populates and is not enabled", true);
                else if (FastDriver.UtilityDetail.CellPhoneContact.FAGetValue().Length > 0 && FastDriver.UtilityDetail.CellPhoneContact.Enabled)
                    Reports.StatusUpdate("Contact Cell field populates and should not be enabled", false);
                else if (FastDriver.UtilityDetail.CellPhoneContact.FAGetValue().Length <= 0 && !FastDriver.UtilityDetail.CellPhoneContact.Enabled)
                    Reports.StatusUpdate("Contact Cell field doesn't populate and is not enabled", true);
                else
                    Reports.StatusUpdate("Contact Cell field doesn't populate and should not be enabled", false);
                //Pager Contact
                if (FastDriver.UtilityDetail.PagerContact.FAGetValue().Length > 0 && !FastDriver.UtilityDetail.PagerContact.Enabled)
                    Reports.StatusUpdate("Contact Pager number field populates and is not enabled", true);
                else if (FastDriver.UtilityDetail.PagerContact.FAGetValue().Length > 0 && FastDriver.UtilityDetail.PagerContact.Enabled)
                    Reports.StatusUpdate("Contact Pager field populates and should not be enabled", false);
                else if (FastDriver.UtilityDetail.PagerContact.FAGetValue().Length <= 0 && !FastDriver.UtilityDetail.PagerContact.Enabled)
                    Reports.StatusUpdate("Contact Pager field doesn't populate and is not enabled", true);
                else
                    Reports.StatusUpdate("Contact Pager field doesn't populate and should not be enabled", false);
                //Email Contact
                if (FastDriver.UtilityDetail.EmailAddressContact.FAGetValue().Length > 0 && !FastDriver.UtilityDetail.EmailAddressContact.Enabled)
                    Reports.StatusUpdate("Contact Email field populates and is not enabled", true);
                else if (FastDriver.UtilityDetail.EmailAddressContact.FAGetValue().Length > 0 && FastDriver.UtilityDetail.EmailAddressContact.Enabled)
                    Reports.StatusUpdate("Contact Email field populates and should not be enabled", false);
                else if (FastDriver.UtilityDetail.EmailAddressContact.FAGetValue().Length <= 0 && !FastDriver.UtilityDetail.EmailAddressContact.Enabled)
                    Reports.StatusUpdate("Contact Email field doesn't populate and is not enabled", true);
                else
                    Reports.StatusUpdate("Contact Email field doesn't populate and should not be enabled", false);
                #endregion
                #region BR ES6228 - Validate  system shall continue to display the edited GAB contact information at the file level, as long as the Edit Checkbox remains selected
                Reports.TestStep = "BR ES6228 - Validate  system shall continue to display the edited GAB contact information at the file level, as long as the Edit Checkbox remains selected.";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.Edit.FASetCheckbox(true);
                FastDriver.UtilityDetail.CellPhone.FASetText(@"9810456382");
                FastDriver.UtilityDetail.EmailAddress.FASetText(@"test@firstam.com");
                FastDriver.UtilityDetail.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                Support.AreEqual(@"(981)045-6382", FastDriver.UtilityDetail.CellPhone.FAGetValue());
                Support.AreEqual(@"test@firstam.com", FastDriver.UtilityDetail.EmailAddress.FAGetValue());
                #endregion
                #region Validate system changes to usual GAP details on uncheck of Edit Checkbox
                Reports.TestStep = "Validate system changes to usual GAP details on uncheck of Edit Checkbox";
                /* this sections' comparisons fail because data on the file 
                should have been saved with the expected values, but 
                this was not done on the Coded UI tests this was based on
                */
                FastDriver.UtilityDetail.Edit.FASetCheckbox(false);
                Support.AreEqual(@"(962)105-4485", FastDriver.UtilityDetail.CellPhone.FAGetValue());
                Support.DataLoad("EmailAddress", "EmailHudflinsr1");
                Support.AreEqualTrim(data, FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString().Trim());
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                #endregion
                #region BR ES6193- Validate system retain Edited Contact Info when Atten Re-Entered
                Reports.TestStep = "BR ES6193- Validate system retain Edited Contact Info when Atten Re-Entered";
                FastDriver.UtilityDetail.Attention.SendKeys(FAKeys.Down);//index: 1
                FastDriver.UtilityDetail.EditContact.FASetCheckbox(true);
                FastDriver.UtilityDetail.BusPhoneContact.FASetText(@"5555555555");
                FastDriver.UtilityDetail.BusFaxContact.FASetText(@"2222222222");//this needs to be added for the following verifications
                FastDriver.UtilityDetail.PagerContact.FASetText(@"3333333333");//this needs to be added for the following verifications
                FastDriver.UtilityDetail.CellPhoneContact.FASetText(@"4444444444");//this needs to be added for the following verifications
                FastDriver.UtilityDetail.EmailAddressContact.FASetText(@"GAP@firstam.com");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                if (FastDriver.UtilityDetail.EditContact.Selected) 
                {
                    Reports.StatusUpdate("Edit checkbox is checked and contact details are enabled to re-edit", true);
                }
                Support.AreEqual(@"(555)555-5555", FastDriver.UtilityDetail.BusPhoneContact.FAGetValue());
                Support.AreEqual(@"(222)222-2222", FastDriver.UtilityDetail.BusFaxContact.FAGetValue());//fails because this value was not assigned on the test
                Support.AreEqual(@"(444)444-4444", FastDriver.UtilityDetail.CellPhoneContact.FAGetValue());//fails because this value was not assigned on the test
                Support.AreEqual(@"(333)333-3333", FastDriver.UtilityDetail.PagerContact.FAGetValue());//fails because this value was not assigned on the test
                Support.AreEqual(@"GAP@firstam.com", FastDriver.UtilityDetail.EmailAddressContact.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
                #region BR ES6140 - Validate system Prevent Edit Contact Information
                Reports.TestStep = "BR ES6140 - Validate system Prevent Edit Contact Information.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.Attention.SendKeys(FAKeys.Down);//index: 1
                FastDriver.UtilityDetail.Reference.FASetText(@" ");
                FastDriver.UtilityDetail.ContactSectionButton.Click();
                Support.AreEqual(@"true", FastDriver.UtilityDetail.EditContact.Selected.ToString().ToLower());
                Support.AreEqual(@"true", FastDriver.UtilityDetail.BusPhoneContact.Enabled.ToString().ToLower());
                Support.AreEqual(@"true", FastDriver.UtilityDetail.BusFaxContact.Enabled.ToString().ToLower());
                Support.AreEqual(@"true", FastDriver.UtilityDetail.CellPhoneContact.Enabled.ToString().ToLower());
                Support.AreEqual(@"true", FastDriver.UtilityDetail.PagerContact.Enabled.ToString().ToLower());
                Support.AreEqual(@"true", FastDriver.UtilityDetail.EmailAddressContact.Enabled.ToString().ToLower());
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0003 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0004()
        {
            try
            {
                Reports.TestDescription = "BR_ECW5: Validate system on change to New Lender on Loan details.";
                #region Variable Declaration
                string DialogMessage, ActualMessage = "";
                #endregion

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD; //Test should work on HUD and CD
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                //City = "Santa Ana", 
                                County = "ALAMEDA", 
                                //Country = "USA" 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                #region Create loan of Mortgage having mortage products
                Reports.TestStep = "Create loan of Mortgage having mortage products";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem(@"Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText(@"10000");
                FastDriver.NewLoan.FindGABCode(@"MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                if (FastDriver.NewLoan.LoanDetailsMortgageProduct.FAGetAllTextFromSelect(", ").Contains("50 - i Declare - Regular"))
                {
                    FastDriver.NewLoan.LoanDetailsMortgageProduct.FASelectItem(@"50 - i Declare - Regular");
                }
                else
                {
                    Reports.StatusUpdate("Error: This GAB doesn't have a Mortgage Product added for \"50 - i Declare - Regular\". ", false);
                }
                #endregion

                #region Validate on click of CANCEL button system will abort the Lender change, and will leave lender on the file,will NOT remove the Mortgage Product or Loan Type
                Reports.TestStep = "Validate on click of CANCEL button system will abort the Lender change, and will leave lender on the file,will NOT remove the Mortgage Product or Loan Type.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText(@"247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                DialogMessage = @"You are changing the New Lender. Mortgage Product is specific to Lender, and will be deleted from the loan. You may need to reselect a Mortgage Product on Loan Details.";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton : false);
                Support.AreEqual(DialogMessage, ActualMessage);
                FastDriver.NewLoan.WaitForScreenToLoad();
                Reports.StatusUpdate("System will abort the Lender change, and will leave lender on the file, system will NOT remove the Mortgage Product or Loan Type.", true);
                #endregion

                #region Validate on click of OK button system will change the existing lender to the selected lender per existing rules AND will delete the Mortgage Product AND Loan Type for this lender’s loan on file
                Reports.TestStep = "Validate on click of OK button system will change the existing lender to the selected lender per existing rules AND will delete the Mortgage Product AND Loan Type for this lender’s loan on file.";
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                Support.AreEqual(DialogMessage, ActualMessage);
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual(@"247", FastDriver.NewLoan.LoanDetailsGabcodeLabel.FAGetText().ToString().Trim());
                Reports.StatusUpdate("System will change the existing lender to the selected lender per existing rules AND will delete the Mortgage Product AND Loan Type for this lender’s loan on file", true);
                #endregion

                #region Validate the NMLS ID and ST License ID fields are displayed.
                Reports.TestStep = "Validate the NMLS ID and ST License ID fields are displayed in Loan Details.";
                Support.AreEqual(true, FastDriver.NewLoan.NewLoanDetails_NMLSID.IsDisplayed(), "Verifying NMLS ID field is displayed.");
                Support.AreEqual(true, FastDriver.NewLoan.NewLoanDetails_STLICENSEID.IsDisplayed(), "Verifying NMLS ID field is displayed.");

                Reports.TestStep = "Validate the NMLS ID and ST License ID fields are blank if no data is added.";
                Support.AreEqual(true, FastDriver.NewLoan.NewLoanDetails_NMLSID.FAGetValue().Equals(""), "Verifying that default selection is blank");
                Support.AreEqual(true, FastDriver.NewLoan.NewLoanDetails_STLICENSEID.FAGetSelectedItem().Equals(""), "Verifying that default selection is blank.");

                Reports.TestStep = "Validate the NMLS ID and ST License ID fields are displayed in Mortgage Broker.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                Support.AreEqual(true, FastDriver.NewLoan.NewLoanMortgage_NMLSID.IsDisplayed(), "Verifying NMLS ID field is displayed.");
                Support.AreEqual(true, FastDriver.NewLoan.NewLoanMortgage_STLICENSEID.IsDisplayed(), "Verifying NMLS ID field is displayed.");

                Reports.TestStep = "Validate the NMLS ID and ST License ID fields are blank if no data is added.";
                Support.AreEqual(true, FastDriver.NewLoan.NewLoanMortgage_NMLSID.FAGetValue().Equals(""), "Verifying that default selection is blank");
                Support.AreEqual(true, FastDriver.NewLoan.NewLoanMortgage_STLICENSEID.FAGetSelectedItem().Equals(""), "Verifying that default selection is blank.");
                FastDriver.WebDriver.Quit();
                #endregion

                #region Defining NMLS & State License and validating in New Loan Screen
                _ADMLOGIN();

                #region Data Setup
                var busOrg = new BusinessOrganizationParameters()
                {
                    IDCode = "F19" + Support.RandomString("AAAAAZ"),
                    EntityType = "Lender",
                    Name1 = "Test Name1",
                    Name2 = "Test Name2",
                    LocDescription = "Location Description",
                    TitleOfficer = "FAST QA02",
                    EscrowOfficer = "FAST QA02",
                    Comments = "Location Description",
                    newAddress = true,
                    AddressLine1 = "Street1",
                    AddressLine2 = "Street2",
                    AddressLine3 = "#",
                    City = "Santa Ana",
                    State = "CA",
                    Zip = "92707",
                    County = "Orange",
                    ABANumber = "123",
                    BankName = "Citi Bank",
                    BankAddress = "Service Vendor",
                    AccountNumber = "1234567"
                };

                var newbusOrg = new BusinessOrganizationParameters()
                {
                    IDCode = Support.RandomString("AAAAAZ") + "F19",
                    EntityType = "Lender",
                    Name1 = "Test Name1",
                    Name2 = "Test Name2",
                    LocDescription = "Location Description",
                    TitleOfficer = "FAST QA02",
                    EscrowOfficer = "FAST QA02",
                    Comments = "Location Description",
                    newAddress = true,
                    AddressLine1 = "Street1",
                    AddressLine2 = "Street2",
                    AddressLine3 = "#",
                    City = "Santa Ana",
                    State = "CA",
                    Zip = "92707",
                    County = "Orange",
                    ABANumber = "123",
                    BankName = "Citi Bank",
                    BankAddress = "Service Vendor",
                    AccountNumber = "1234567"
                };
                
                #endregion

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Create a new GAB";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").CreateNewAddressEntry(busOrg);
                FastDriver.AddressBookSearch.SearchAddressBook(busOrg.IDCode);
                FastDriver.AddressBookSearch.EditAddress(busOrg.IDCode);

                Reports.TestStep = "Add NMLS and state license";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.LicenseInformationNew.FAClick();
                string licenseID = FastDriver.LicenseInformationDlg.CreateLicense("CA", "lender", "All");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NotesEntryDlg.EnterNote("FMUC0019 Reg Testing");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.LicenseInformationNew.FAClick();
                string nmlsID = FastDriver.LicenseInformationDlg.CreateNMLS();
                FastDriver.NotesEntryDlg.EnterNote("FMUC0019 Reg Testing");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create a new GAB";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").CreateNewAddressEntry(newbusOrg);
                FastDriver.AddressBookSearch.SearchAddressBook(newbusOrg.IDCode);
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log in to IIS";
                _IISLOGIN();

                Reports.TestStep = "Create file with GAB that has Addtional Role as Lender";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId(busOrg.IDCode),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    }
                };
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Validate that NMLS license and state license are displayed in New Loan screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.NewLoan.NewLoanDetails_STLICENSEID.FAGetAllTextFromSelect(", ").Contains(licenseID), "Verifying newly created state license.");
                Support.AreEqual(true, FastDriver.NewLoan.NewLoanDetails_NMLSID.FAGetValue().Equals(nmlsID), "Verifying newly created NMLS ID");

                Reports.TestStep = "Validate that removing a Lender from a Loan instance deletes the License Information of the contact";
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.NewLoan.NewLoanDetails_STLICENSEID.FAGetSelectedItem().Contains(licenseID), "Verifying license info was removed.");

                Reports.TestStep = "Click on Find and look up GAB with no state license";
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.SearchAndSelect(newbusOrg.IDCode);
                FastDriver.AddressBookSearchDlg.ModifyGAB.FAClick();

                Reports.TestStep = "Add state license and NMLS ID";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.LicenseInformationNew.FAClick();
                licenseID = FastDriver.LicenseInformationDlg.CreateLicense("CA", "lender", "All");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.LicenseInformationNew.FAClick();
                nmlsID = FastDriver.LicenseInformationDlg.CreateNMLS();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verifying modified GAB has state license and NMLS ID";
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.NewLoan.NewLoanDetails_ModifiedNMLS.FAGetValue().Equals(nmlsID), "Verifying modified GAB has NMLS ID");
                Support.AreEqual(true, FastDriver.NewLoan.NewLoanDetails_ModifiedLicense.FAGetSelectedItem().Contains(licenseID), "Verifying modified GAB has state license.");

                Reports.TestStep = "Click on Find and look up GAB with no state license";
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.SearchAndSelect(newbusOrg.IDCode);
                FastDriver.AddressBookSearchDlg.GABDetails.FAClick();

                Reports.TestStep = "Verifying that License Information section is disabled in GAB Details screen";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad(element: FastDriver.GABEntryRequestDlg.LicenseInformationNew);
                Support.AreEqual(false, FastDriver.GABEntryRequestDlg.LicenseInformationNew.IsEnabled(), "Verifying if button is enabled.");
                Support.AreEqual(false, FastDriver.GABEntryRequestDlg.LicenseInformationEdit.IsEnabled(), "Verifying if button is enabled.");
                Support.AreEqual(false, FastDriver.GABEntryRequestDlg.LicenseInformationStatus.IsEnabled(), "Verifying if button is enabled.");
                Support.AreEqual(false, FastDriver.GABEntryRequestDlg.LicenseInfoHistory.IsEnabled(), "Verifying if button is enabled.");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.DialogBottomFrame.ClickDone();
                
                Reports.TestStep = "Navigate to Property Tax Info and update Property Address.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertyTaxSummary.PropertiesSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PropertyTaxSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("Panama City");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Bay");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("FL");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that GAB has state license defined but not for state of Property1, then those are not displayed in New Loan screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.NewLoan.NewLoanDetails_ModifiedLicense.FAGetSelectedItem().Contains(licenseID), "Verifying modified GAB has state license.");




                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0004 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0005()
        {
            try
            {
                Reports.TestDescription = "BR_ES6358: Enter Different Name for Attention.";
                Reports.TestStep = "Click on skip button to go to QFE.";
                #region Variable Declaration
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Set Default Check Printer
                SetDefaultCheckPrinter();
                #endregion
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD; //Test should work on HUD and CD
                customizableFileRequest.File.SalesPriceAmount = 12000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        //AddrBookEntryID =  179803671, //HUDASLNDR1
                        //AddrBookEntryID =  179803738, //HUDFLINSR1
                        //AddrBookEntryID =  179803644, //MORTLNDR
                        //AddrBookEntryID =  8836170, //MORTLNDR on EVAL02 Automation...
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        //RoleTypeObjectCD = "DirectedBy",
                        BusOrgContact = new BusOrgContact(){
                            ContactName = @"CNTCTMortLNDR Name 2, CNTCTMortLNDR Name 1",
                        },//Attention...
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.NewLender
                        },
                        
                    }
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                                //Country = "USA" 
                            } 
                        } 
                    } 
                };
                #endregion
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Change the Business Source on File Home Page
                Reports.TestStep = "Change the Business Source on File Home Page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText(@"HUDFLINSR1");
                FastDriver.FileHomepage.BussinessPartyFind.FAClick();
                FastDriver.FileHomepage.AcceptDialogAndCompareWith();
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                FastDriver.FileHomepage.SwitchToBottomFrame();
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.SwitchToContentFrame();
                #endregion
                #region Set an instance of Utility details
                Reports.TestStep = "Set an instance of Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                #endregion
                #region Enter charges and make payment method as CHK
                Reports.TestStep = "Enter charges and make payment method as CHK.";
                if (IsFormTypeCD)
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"10.00");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"10.00");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(@"10.00");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(@"10.00");
                    FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.UtilityDetail.SwitchToContentFrame();
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem(@"CHK");
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem(@"CHK");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"2.50");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"2.50");
                    FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.UtilityDetail.SwitchToContentFrame();
                }
                #endregion
                #region Print All Checks
                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.Click();
                FastDriver.PrintChecks.SwitchToContentFrame();
                #endregion
                #region Click on Deliver
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog.";
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 200);
                #endregion
                #region Edit the Business Source Details
                Reports.TestStep = "Edit the Business Source Details.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText(@"#");
                do
                {
                    FastDriver.FileHomepage.BusinessPartyEditCont.Click();
                } 
                while (!FastDriver.FileHomepage.BusinessPartyEditCont.Selected);
                FastDriver.FileHomepage.WaitForScreenToLoad(element: FastDriver.FileHomepage.BusinessPartyEmailAddress);
                FastDriver.FileHomepage.BusinessPartyEmailAddress.FASetText(@"Business@Source.com");
                do
                {
                    FastDriver.FileHomepage.BusinessPartyEdit.Click();
                    FastDriver.FileHomepage.AcceptDialogAndCompareWith();
                    FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                    FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.FileHomepage.SwitchToContentFrame();
                }
                while (!FastDriver.FileHomepage.BusinessPartyEdit.Selected);
                FastDriver.FileHomepage.WaitCreation(element: FastDriver.FileHomepage.BusinessPartyEditName);
                FastDriver.FileHomepage.BusinessPartyEditName.FASetText(@"Edit Name");
                FastDriver.FileHomepage.AcceptDialogAndCompareWith();
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileHomepage.SwitchToContentFrame();
                FastDriver.BottomFrame.Save();
                
                //Reports.TestStep = "Dummy Navigation to New Loan";
                //FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0005 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0006()
        {
            try
            {
                Reports.TestDescription = "BR_FM888_FM1286_FM1284_FM1640: Enter Ad Hoc Business Party ,Display Ad Hoc Indicator search GAB Code by Name and ID us Wild Star.";
                Reports.TestStep = "Click on skip button to go to QFE.";
                #region Variable Declaration
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD; //Test should work on HUD and CD
                customizableFileRequest.File.SalesPriceAmount = 12000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID =  179803644, //MORTLNDR
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        BusOrgContact = new BusOrgContact(){
                            ContactName = @"CNTCTMortLNDR Name 2, CNTCTMortLNDR Name 1",
                        },//Attention...
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.NewLender
                        },
                        
                    }
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Change the Business Source on File Home Page
                Reports.TestStep = "Change the Business Source on File Home Page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText(@"HUDFLINSR1");
                FastDriver.FileHomepage.BussinessPartyFind.FAClick();
                FastDriver.FileHomepage.AcceptDialogAndCompareWith();
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                FastDriver.FileHomepage.SwitchToBottomFrame();
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.SwitchToContentFrame();
                #endregion
                #region Enter Name in UTILITY Information section
                Reports.TestStep = "Enter Name in UTILITY Information section.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABName.FASetText(@"Automation FMUC Name 1");
                #endregion
                #region Click on FIND Button
                Reports.TestStep = "Click on FIND Button.";
                FastDriver.UtilityDetail.Find.FAClick();
                #endregion
                #region Verify that ADHOC entry is accepted to create the instance
                Reports.TestStep = "Verify that ADHOC entry is accepted to create the instance.";
                FastDriver.UtilityDetail.WaitForValue(FastDriver.UtilityDetail.GabCodeLabel, @"FMUC19AECP");
                Support.AreEqual(@"FMUC19AECP", FastDriver.UtilityDetail.GabCodeLabel.FAGetText().ToString().Trim());
                #endregion
                #region Verify for the Global Indicator
                Reports.TestStep = "Verify for the Global Indicator.";
                Support.IsTrue(FastDriver.UtilityDetail.GlobalIndicator.Exists(), "Verifying the existance of Global Indicator");
                #endregion
                #region Set an instance of Utility details
                Reports.TestStep = "Set an instance of Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                #endregion
                #region Enter charges and make payment method as CHK
                Reports.TestStep = "Enter charges and make payment method as CHK.";
                if (IsFormTypeCD)
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"10.00");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"10.00");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(@"10.00");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(@"10.00");
                    FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.UtilityDetail.SwitchToContentFrame();
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem(@"CHK");
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem(@"CHK");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"2.50");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"2.50");
                    FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.UtilityDetail.SwitchToContentFrame();
                }
                #endregion
                #region Enter the Wild Card and Click on Find
                Reports.TestStep = "Enter the Wild Card and Click on Find.";
                Reports.TestStep = "Set an instance of Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"HUD");
                #endregion
                #region Search for the GAB Code
                Reports.TestStep = "Search for the GAB Code.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.FileaddressBookRadio);
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio);
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Business Source", "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #region Check the edit Checkbox and Enter Contact Info
                Reports.TestStep = "Check the edit Checkbox and Enter Contact Info.";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.Edit.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Clicked Edit";
                FastDriver.UtilityDetail.BusPhone.FASetText(@"1234567890");
                FastDriver.UtilityDetail.BusFax.FASetText(@"1234567890");
                FastDriver.UtilityDetail.CellPhone.FASetText(@"1234567890");
                FastDriver.UtilityDetail.Pager.FASetText(@"1234567890");
                FastDriver.UtilityDetail.EmailAddress.FASetText(@"Regresion@firstam.com");
                FastDriver.UtilityDetail.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Verify that System allowed to Edit the Contact Information after Check the edit name check box
                Reports.TestStep = "Verify that System allowed to Edit the Contact Information after Check the edit name check box.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Support.AreEqual(@"(123)456-7890", FastDriver.UtilityDetail.BusPhone.FAGetValue());
                Support.AreEqual(@"(123)456-7890", FastDriver.UtilityDetail.BusFax.FAGetValue());
                Support.AreEqual(@"(123)456-7890", FastDriver.UtilityDetail.CellPhone.FAGetValue());
                Support.AreEqual(@"(123)456-7890", FastDriver.UtilityDetail.Pager.FAGetValue());
                Support.AreEqual(@"Regresion@firstam.com", FastDriver.UtilityDetail.EmailAddress.FAGetValue());
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0006 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0007()
        {
            try
            {
                Reports.TestDescription = "BR_FM1641_FM1642_FM1643_FM1644_FM1645_FM2993_FM884_FM885: Search the name of a business party by enter either the complete name or lead characters, Filter Find Name by EntityType,User can use Primary Contact as attention";
                #region Variable Declaration
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD; //Test should work on HUD and CD
                customizableFileRequest.File.SalesPriceAmount = 12000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        //AddrBookEntryID =  179803671, //HUDASLNDR1
                        //AddrBookEntryID =  179803738, //HUDFLINSR1
                        //AddrBookEntryID =  179803644, //MORTLNDR
                        RoleTypeObjectCD = "BUSSOURCE",
                        //RoleTypeObjectCD = "DirectedBy",
                        BusOrgContact = new BusOrgContact(){
                            ContactName = @"CNTCTMortLNDR Name 2, CNTCTMortLNDR Name 1",
                        },//Attention...
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.NewLender
                        },
                        
                    }
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Enter Name that Matches Exactly in the GAB Name Section                                
                Reports.TestStep = "Enter Name that Matches Exactly in the GAB Name Section.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABName.FASetText(@"Flood Insurance 1 for HUD Testing Name 1");
                #endregion
                #region Click on FIND Button
                Reports.TestStep = "Click on FIND Button.";
                FastDriver.UtilityDetail.Find.FAClick();
                #endregion
                #region Verify that system is Pulling the GAB on Enter exact GAB
                Reports.TestStep = "Verify that system is Pulling the GAB on Enter exact GAB";
                FastDriver.UtilityDetail.WaitForValue(FastDriver.UtilityDetail.GabCodeLabel, @"HUDFLINSR1");
                Support.AreEqual(@"HUDFLINSR1", FastDriver.UtilityDetail.GabCodeLabel.FAGetText().ToString().Trim());
                #endregion
                #region Enter Name which Does Not match Exactly to the GAB Name
                Reports.TestStep = "Enter Name which Does Not match Exactly to the GAB Name.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABName.FASetText(@"Flood Insurance ");
                #endregion
                #region Click on FIND Button again
                Reports.TestStep = "Click on FIND Button again.";
                FastDriver.UtilityDetail.Find.FAClick();
                #endregion
                #region Search for the GAB Code
                Reports.TestStep = "Search for the GAB Code.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookRadio, 15);
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio, 15);
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Business Source", "Select", TableAction.On);
                FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Verify that system is Pulling the GAB on Enter exact GAB again
                Reports.TestStep = "Verify that system is Pulling the GAB on Enter exact GAB again.";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.WaitForValue(FastDriver.UtilityDetail.GabCodeLabel, @"HUDFLINSR1");
                Support.AreEqual(@"HUDFLINSR1", FastDriver.UtilityDetail.GabCodeLabel.FAGetText().ToString().Trim());
                #endregion
                #region Enter Name which Does Not match Exactly to the GAB Name again
                Reports.TestStep = "Enter Name which Does Not match Exactly to the GAB Name again.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABName.FASetText(@"Flood Insurance ");
                #endregion
                #region Click on FIND Button again 3
                Reports.TestStep = "Click on FIND Button again 3.";
                FastDriver.UtilityDetail.Find.FAClick();
                #endregion
                #region Select a Entity Type and Click on Find Button
                Reports.TestStep = "Select a Entity Type and Click on Find Button.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.EntityType.FASelectItem(@"Lender");
                FastDriver.AddressBookSearchDlg.EntityName.FASetText(@"b*");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.SearchResultsTable);
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("ID Code", "588", "Select", TableAction.Click);
                Support.AreEqual("true", FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("ID Code", "588", "Select", TableAction.GetAttribute, "selected").Message.ToString().ToLower());
                FastDriver.AddressBookSearchDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                #endregion
                #region Click on FIND Button again 4
                Reports.TestStep = "Click on FIND Button again 4.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.Find.FAClick();
                #endregion
                #region Enter such data in Entity Name so that no result will get Load
                Reports.TestStep = "Enter such data in Entity Name so that no result will get Load.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", timeoutSeconds: 10);
                Playback.Wait(2000); //wait for dialog content to be rendered
                FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.EntityName, 10);
                FastDriver.AddressBookSearchDlg.EntityName.FASetText(@"abcde1234");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                Support.AreEqual("false", FastDriver.AddressBookSearchDlg.SearchResultsTable.Exists().ToString().ToLower());
                FastDriver.AddressBookSearchDlg.SwitchToDialogBottomFrame();
                #endregion
                #region Select a Entity Type and Click on Find Button again
                Reports.TestStep = "Select a Entity Type and Click on Find Button again.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.EntityType.FASelectItem(@"Lender");
                FastDriver.AddressBookSearchDlg.EntityName.FASetText(@"b*");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.SearchResultsTable);
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("ID Code", "588", "Select", TableAction.Click);
                Support.AreEqual("true", FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("ID Code", "588", "Select", TableAction.GetAttribute, "selected").Message.ToString().ToLower());
                FastDriver.AddressBookSearchDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                #endregion
                #region Enter the GAB Code which is having primary business contact in the global address book and Verify the Attention Field
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("FMUC19AECP");
                Support.AreEqual("true", FastDriver.UtilityDetail.Attention.Enabled.ToString().ToLower());
                Support.AreEqual(@"FIRST", FastDriver.UtilityDetail.Attention.FAGetSelectedItem().ToString());
                #endregion
                #region Select the Attention Field other than Primary Contact
                Reports.TestStep = "Select the Attention Field other than Primary Contact.";
                //FastDriver.UtilityDetail.Attention.SendKeys(Keys.Down);
                FastDriver.UtilityDetail.Attention.FASelectItemBySendingKeys(@"SECOND");
                #endregion
                #region Verify the attention Field is changed
                Reports.TestStep = "Verify the attention Field is changed.";
                Support.AreEqual("true", FastDriver.UtilityDetail.Attention.Enabled.ToString().ToLower());
                Support.AreEqual(@"SECOND", FastDriver.UtilityDetail.Attention.FAGetSelectedItem());
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0007 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0008()
        {
            try
            {
                Reports.TestDescription = "ADM_SetUp_BR_ES6360_ES6443_ES6444: Check Status Email Check Box.";
                #region LOGIN
                _ADMLOGIN();
                #endregion
                #region Search a GAB in Address Book and click on Edit button
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText(@"HUDFLINSR1");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad(timeout: 10);
                FastDriver.AddressBookSearch.EditAddress(@"HUDFLINSR1");
                #endregion
                #region Select the Status Email Checkbox
                Reports.TestStep = "Select the Status Email Checkbox.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad(FastDriver.BusPartyOrgSetUp.StatusEmail);
                Support.AreEqual(false, FastDriver.BusPartyOrgSetUp.StatusEmail.IsEnabled(), "Status email is disabled");
                //FastDriver.BusPartyOrgSetUp.StatusEmail.FASetCheckbox(true);
                //FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch(Exception e)
            {
                FailTest("Test case FMUC0019_REG0008 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0009()
        {
            try
            {
                Reports.TestDescription = "BR_ES6360_ES6443_ES6444: Display Email Indicator, The indicator can be edited after it is saved at file level, System should Display Email Indicator on All the screen wont come if Business party is ADHOC.";
                #region Variable Declaration
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 12000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        //AddrBookEntryID =  179803671, //HUDASLNDR1
                        //AddrBookEntryID =  179803738, //HUDFLINSR1
                        //AddrBookEntryID =  179803644, //MORTLNDR
                        RoleTypeObjectCD = "BUSSOURCE",
                        //RoleTypeObjectCD = "DirectedBy",
                        BusOrgContact = new BusOrgContact(){
                            ContactName = @"CNTCTMortLNDR Name 2, CNTCTMortLNDR Name 1",
                        },//Attention...
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.NewLender
                        },
                        
                    }
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Verify that before Enter Business ID Status Email checkbox is disabled
                Reports.TestStep = "Verify that before Enter Business ID Status Email checkbox is disabled.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                Support.AreEqual("false", FastDriver.UtilityDetail.EmailStatus.Enabled.ToString().ToLower());
                #endregion
                #region Verify that status Email is Checked and Email ID
                Reports.TestStep = "Verify that status Email is Checked and Email ID.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"HUDFLINSR1");
                Support.AreEqual("true", FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString().Contains("@").ToString().ToLower());
                Support.AreEqual("false", FastDriver.UtilityDetail.EmailStatus.Selected.ToString().ToLower());
                //Support.AreEqual("true", FastDriver.UtilityDetail.EmailStatus.Selected.ToString().ToLower());
                //This is not passing because gab code HUDFLINSR1 doesn't have email status selected by default for UtilityDetail screen 
                //on EVAL02 CD Region (Sept 7, 2015)
                //It's not checked on production either...
                FastDriver.UtilityDetail.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();                
                #endregion
                #region Deselect the status email checkbox
                Reports.TestStep = "Deselect the status email checkbox.";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.EmailStatus.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();                
                #endregion
                #region Verify that Status email checkbox is unchecked
                Reports.TestStep = "Verify that Status email checkbox is unchecked.";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Support.AreEqual("false", FastDriver.UtilityDetail.EmailStatus.Selected.ToString().ToLower());
                #endregion
                #region Verify that Status email checkbox is disable before creating instance at Survey Detail
                Reports.TestStep = "Verify that Status email checkbox is disable before creating instance at Survey Detail.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                Support.AreEqual("false", FastDriver.SurveyDetail.EmailStatus.Enabled.ToString().ToLower());
                #endregion
                #region Verify that Status email checkbox is checked at Survey Detail
                Reports.TestStep = "Verify that Status email checkbox is checked at Survey Detail.";
                FastDriver.SurveyDetail.FindGABCode(@"HUDFLINSR1");
                Support.AreEqual("true", FastDriver.SurveyDetail.EmailStatus.Enabled.ToString().ToLower());
                #endregion
                #region Deselecting the status email checkbox at Survey Detail
                Reports.TestStep = "Deselecting the status email checkbox at Survey Detail.";
                FastDriver.SurveyDetail.EmailStatus.FASetCheckbox(false);
                FastDriver.SurveyDetail.SwitchToBottomFrame();
                FastDriver.SurveyDetail.SaveAndReloadScreen();
                #endregion
                #region Verify that Status email checkbox is unchecked at Survey Detail
                Reports.TestStep = "Verify that Status email checkbox is unchecked at Survey Detail.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("false", FastDriver.SurveyDetail.EmailStatus.Selected.ToString().ToLower());
                #endregion
                #region Verify that before entering Business ID Status Email checkBox is disable at Home Warranty
                Reports.TestStep = "Verify that before entering Business ID Status Email checkBox is disable at Home Warranty.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                Support.AreEqual("false", FastDriver.HomeWarrantyDetail.WeeklyEmailStatus.Enabled.ToString().ToLower());
                #endregion
                #region Verify that Status email checkbox is checked at Home Warranty
                Reports.TestStep = "Verify that Status email checkbox is checked at Home Warranty.";
                FastDriver.HomeWarrantyDetail.FindGABCode(@"HUDFLINSR1");
                Support.AreEqual("true", FastDriver.HomeWarrantyDetail.WeeklyEmailStatus.Enabled.ToString().ToLower());
                #endregion
                #region Deselecting the status email checkbox at Home Warranty
                Reports.TestStep = "Deselecting the status email checkbox at Home Warranty.";
                FastDriver.HomeWarrantyDetail.WeeklyEmailStatus.FASetCheckbox(false);
                FastDriver.HomeWarrantyDetail.SaveAndReloadScreen();
                #endregion
                #region Verify that Status email checkbox is unchecked at Home Warranty
                Reports.TestStep = "Verify that Status email checkbox is unchecked at Home Warranty.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("false", FastDriver.HomeWarrantyDetail.WeeklyEmailStatus.Selected.ToString().ToLower());
                #endregion
                #region Create instance with different value, clicking on Find Button at Property Tax Check
                Reports.TestStep = "Create instance with different value, clicking on Find Button at Property Tax Check.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode(@"HUDASLNDR1");                
                #endregion
                #region Verify that Status email checkbox is checked at Property Tax Check 
                Reports.TestStep = "Verify that Status email checkbox is checked at Property Tax Check.";
                FastDriver.PropertyTaxCheck.FindGABCode(@"HUDFLINSR1");
                Support.AreEqual("true", FastDriver.PropertyTaxCheck.StatusEmail.Enabled.ToString().ToLower());
                #endregion
                #region Deselecting the status email checkbox at Property Tax Check
                Reports.TestStep = "Deselecting the status email checkbox at Property Tax Check.";
                FastDriver.PropertyTaxCheck.StatusEmail.FASetCheckbox(false);
                #endregion
                #region Verify that status Email is Checked at Property Tax Check
                Reports.TestStep = "Verify that status Email is Checked at Property Tax Check.";
                FastDriver.PropertyTaxCheck.FindGABCode(@"HUDASLNDR1");
                Support.AreEqual("true", FastDriver.PropertyTaxCheck.StatusEmail.Enabled.ToString().ToLower());
                #endregion
                #region Verifying that before enter Business ID Status Email checkbox is disabled at Homeowner Association
                Reports.TestStep = "Verifying that before enter Business ID Status Email checkbox is disabled at Homeowner Association.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                Support.AreEqual("false", FastDriver.HomeownerAssociation.WeeklyEmailStatus.Enabled.ToString().ToLower());
                #endregion
                #region Verifying that status Email is Checked at Homeowner Association
                Reports.TestStep = "Verifying that status Email is Checked at Homeowner Association";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode(@"HUDFLINSR1");
                Support.AreEqual("true", FastDriver.HomeownerAssociation.WeeklyEmailStatus.Enabled.ToString().ToLower());
                #endregion
                #region Deselect the status email checkbox at Homeowner Association
                Reports.TestStep = "Deselect the status email checkbox at Homeowner Association.";
                FastDriver.HomeownerAssociation.WeeklyEmailStatus.FASetCheckbox(false);
                #endregion
                #region Verifying that Status email checkbox is unchecked at Homeowner Association
                Reports.TestStep = "Verifying that Status email checkbox is unchecked at Homeowner Association.";
                Support.AreEqual("false", FastDriver.HomeownerAssociation.WeeklyEmailStatus.Selected.ToString().ToLower());
                #endregion
                #region Verify that before Enter Business ID Status Email checkbox is disabled at Lease
                Reports.TestStep = "Verify that before Enter Business ID Status Email checkbox is disabled at Lease.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                Support.AreEqual("false", FastDriver.LeaseDetail.WeeklyEmailStatus.Enabled.ToString().ToLower());
                #endregion
                #region Verify that status Email is Checked at Lease
                Reports.TestStep = "Verify that status Email is Checked at Lease.";
                FastDriver.LeaseDetail.FindGABcode(@"HUDFLINSR1");
                Support.AreEqual("true", FastDriver.LeaseDetail.WeeklyEmailStatus.Enabled.ToString().ToLower());
                #endregion
                #region Deselect the status email checkbox at Lease
                Reports.TestStep = "Deselect the status email checkbox at Lease.";
                FastDriver.LeaseDetail.WeeklyEmailStatus.FASetCheckbox(false);
                #endregion
                #region Verify that Status email checkbox is unchecked at Lease
                Reports.TestStep = "Verify that Status email checkbox is unchecked at Lease.";
                Support.AreEqual("false", FastDriver.HomeownerAssociation.WeeklyEmailStatus.Selected.ToString().ToLower());
                #endregion
                #region Verify that before Enter Business ID Status Email checkbox is disabled at Misc Disb
                Reports.TestStep = "Verify that before Enter Business ID Status Email checkbox is disabled at Misc Disb.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual("false", FastDriver.MiscDisbursementDetail.StatusEmail.Enabled.ToString().ToLower());
                #endregion
                #region Verify that status Email is Checked at Misc Disb
                Reports.TestStep = "Verify that status Email is Checked at Misc Disb.";
                FastDriver.MiscDisbursementDetail.FindGABcode(@"HUDFLINSR1");
                Support.AreEqual("true", FastDriver.MiscDisbursementDetail.StatusEmail.Enabled.ToString().ToLower());
                #endregion
                #region Deselect the status email checkbox at Misc Disb
                Reports.TestStep = "Deselect the status email checkbox at Misc Disb.";
                FastDriver.MiscDisbursementDetail.StatusEmail.FASetCheckbox(false);
                #endregion
                #region Verify that Status email checkbox is unchecked at Misc Disb
                Reports.TestStep = "Verify that Status email checkbox is unchecked at Misc Disb.";
                Support.AreEqual("false", FastDriver.MiscDisbursementDetail.StatusEmail.Selected.ToString().ToLower());
                #endregion

            }
            catch(Exception e)
            {
                FailTest("Test case FMUC0019_REG0009 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0010()
        {
            try
            {
                Reports.TestDescription = "ADM_SetUpFOR_ES6445_ES6447: Delete Email from Contacts.";
                #region LOGIN
                _ADMLOGIN();
                #endregion
                #region Search a GAB in Address Book and click on Edit button
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText(@"utility");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad(timeout: 10);
                FastDriver.AddressBookSearch.EditAddress(@"UTILITY");
                #endregion
                #region Click on Version button to Edit the Bus Org
                Reports.TestStep = "Click on Version button to Edit the Bus Org.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BusPartyOrgSetUp.SwitchToContentFrame();
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                #endregion
                #region Uncheck Status Email Checkbox and remove emailid
                Reports.TestStep = "Uncheck Status Email Checkbox and remove emailid.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad(FastDriver.BusPartyOrgSetUp.StatusEmail);
                FastDriver.BusPartyOrgSetUp.PagerType.ScrollIntoView();
                FastDriver.BusPartyOrgSetUp.PagerType.FASelectItemBySendingKeys(@"E-Mail");
                Playback.Wait(5000);
                #endregion
                #region Verify status email checkbox is unchecked and email is deleted
                Reports.TestStep = "Verify status email checkbox is unchecked and email is deleted.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad(FastDriver.BusPartyOrgSetUp.PagerNumber);
                FastDriver.BusPartyOrgSetUp.PagerNumber.ScrollIntoView();
                Support.AreEqual(string.Empty, FastDriver.BusPartyOrgSetUp.PagerNumber.FAGetValue());
                FastDriver.BottomFrame.Reset(); // Clean up
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0010 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0011()
        {

            try
            {
                Reports.TestDescription = "BR_ES6445_ES6447: The system shall disable the Status Email indicator at file level, when the e-mail address is removed from the file business party record.";
                #region Variable Declaration
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 12000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        //AddrBookEntryID =  179803671, //HUDASLNDR1
                        //AddrBookEntryID =  179803738, //HUDFLINSR1
                        //AddrBookEntryID =  179803644, //MORTLNDR
                        RoleTypeObjectCD = "BUSSOURCE",
                        //RoleTypeObjectCD = "DirectedBy",
                        BusOrgContact = new BusOrgContact(){
                            ContactName = @"CNTCTMortLNDR Name 2, CNTCTMortLNDR Name 1",
                        },//Attention...
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.NewLender
                        },
                        
                    }
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Verify that Email Field is Blank and Email Status checkbox is Disable
                Reports.TestStep = "Verify that Email Field is Blank and Email Status checkbox is Disable.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"Utility");
                Support.AreEqual("raqhwcg@email.com", FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString());//this is the mail for this GAB on EVAL02 (Sept 4, 2015)
                //CodedUI test compares with an empty string, apparently
                //because there's a different email on each environment
                //maybe another GAB should be used here...
                Support.AreEqual("true", FastDriver.UtilityDetail.EmailStatus.IsSelected().ToString().ToLower(), "Validating Status Email field");
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0011 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0012()
        {
            try
            {
                Reports.TestDescription = "ADM_SetupRevertingchanges: Retrieve the Changes Made to GAB code.";
                #region LOGIN
                _ADMLOGIN();
                #endregion
                #region Search a GAB in Address Book and click on Edit button
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText(@"utility");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad(timeout: 10);
                FastDriver.AddressBookSearch.EditAddress(@"UTILITY");
                #endregion
                #region Click on Version button to Edit the Bus Org
                Reports.TestStep = "Click on Version button to Edit the Bus Org.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.Version.Click();
                FastDriver.BusPartyOrgSetUp.PhonesAdd.Click();
                #endregion
                #region Revert back changes,check the status email check box and enter email id
                Reports.TestStep = "Revert back changes,check the status email check box and enter email id.";
                FastDriver.BusPartyOrgSetUp.StatusEmail.FASetCheckbox(true);
                FastDriver.BusPartyOrgSetUp.EmailNumber.FASetText(@"raqhwcg@email.com");
                #endregion
                #region Verify status email checkbox is checked and email is entered
                Reports.TestStep = "Verify status email checkbox is checked and email is entered.";
                Support.AreEqual("true", FastDriver.BusPartyOrgSetUp.StatusEmail.Selected.ToString().ToLower());
                Support.AreEqual("raqhwcg@email.com", FastDriver.BusPartyOrgSetUp.EmailNumber.FAGetValue().ToString());
                FastDriver.BusPartyOrgSetUp.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0012 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0013()
        {
            try
            {
                Reports.TestDescription = "Add second contact for FMUC19AECP";
                #region LOGIN
                _ADMLOGIN();
                #endregion
                #region Search a GAB in Address Book and click on Edit button
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").SearchAddressBook(gabID: "FMUC19AECP");
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad(timeout: 10);
                FastDriver.AddressBookSearch.EditAddress(@"FMUC19AECP");
                #endregion
                #region Click on View/Add Contact.
                Reports.TestStep = "Click on View/Add Contact.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                #endregion
                #region To create new contact
                Reports.TestStep = "To create new contact.";
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.New.FAClick();
                #endregion
                #region Enter firstname as SECOND
                Reports.TestStep = "Enter firstname as SECOND";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.FirstName.FASetText(@"SECOND");
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0013 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0014()
        {
            try 
            {
                Reports.TestDescription = "BR_FM2619: System should reflect the Attention Contact details on Summary screen.";
                #region Variable Declaration
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 12000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        //AddrBookEntryID =  179803671, //HUDASLNDR1
                        //AddrBookEntryID =  179803738, //HUDFLINSR1
                        //AddrBookEntryID =  179803644, //MORTLNDR
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        //RoleTypeObjectCD = "DirectedBy",
                        BusOrgContact = new BusOrgContact(){
                            ContactName = @"CNTCTMortLNDR Name 2, CNTCTMortLNDR Name 1",
                        },//Attention...
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.NewLender
                        },
                        
                    }
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Change the Business Source on File Home Page
                Reports.TestStep = "Change the Business Source on File Home Page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText(@"HUDFLINSR1");
                FastDriver.FileHomepage.BussinessPartyFind.FAClick();
                FastDriver.FileHomepage.AcceptDialogAndCompareWith();
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion
                #region Select the attention field  for GAB code FMUC19AECP
                Reports.TestStep = "Select the attention field for GAB code FMUC19AECP.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"FMUC19AECP");
                FastDriver.UtilityDetail.Attention.FASelectItemBySendingKeys(@"FIRST");
                FastDriver.BottomFrame.New(); 
                #endregion
                #region Select the attention field  for GAB code HUDFLINSR1
                Reports.TestStep = "Select the attention field for GAB code HUDFLINSR1.";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"HUDFLINSR1");
                FastDriver.UtilityDetail.Attention.FASelectItemBySendingKeys(@"Contact, Flood Insurance 1");
                FastDriver.BottomFrame.New(); 
                #endregion
                #region Select the attention field  for GAB code 247
                Reports.TestStep = "Select the attention field for GAB code 247.";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"247");
                FastDriver.UtilityDetail.Attention.SendKeys(FAKeys.Down);//index: 1
                // "FIRST" should be listed as the attention contact for this one too...
                FastDriver.BottomFrame.Done(); 
                #endregion
                #region Navigate to Summary screen and Verify the Attention contact data
                Reports.TestStep = "Navigate to Summary screen and Verify the Attention contact data.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                try
                {
                    FastDriver.UtilitySummary.SummaryTable.PerformTableAction("Contact", "Flood Insurance 1 Contact", "#1", TableAction.GetText);
                }
                catch(NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"Flood Insurance 1 Contact\" on Utility Summary table. " + e.Message, false);
                }
                #endregion
                #region Navigate to Summary screen and Verify the Attention contact data 2
                Reports.TestStep = "Navigate to Summary screen and Verify the Attention contact data 2.";
                try
                {
                    //FastDriver.UtilitySummary.SummaryTable.PerformTableAction("Contact", "FIRST", "#1", TableAction.GetText);
                    FastDriver.UtilitySummary.SummaryTable.PerformTableAction("Contact", "Flood Insurance 1 Contact", "#1", TableAction.GetText);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"L247\" on Utility Summary table" + e.Message, false);
                }
                #endregion
                #region Navigate to Summary screen and Verify the Attention contact data 3
                Reports.TestStep = "Navigate to Summary screen and Verify the Attention contact data 3.";
                try
                {
                    FastDriver.UtilitySummary.SummaryTable.PerformTableAction("Contact", "FIRST", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"FIRST\" on Utility Summary table" + e.Message, false);
                }
                FastDriver.UtilitySummary.Edit.FAClick();
                #endregion
                #region Select the Attention Field other than Primary Contact
                Reports.TestStep = "Select the Attention Field other than Primary Contact.";
                FastDriver.UtilityDetail.WaitForScreenToLoad(); 
                FastDriver.UtilityDetail.Attention.FASelectItemBySendingKeys(@"SECOND");
                #endregion
                #region Navigate to Summary screen and Verify the Attention contact data
                Reports.TestStep = "Navigate to Summary screen and Verify the Attention contact data 4.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilitySummary.WaitForElementToLoad();
                try
                {
                    FastDriver.UtilitySummary.SummaryTable.PerformTableAction("Contact", "SECOND", "#1", TableAction.GetText);
                    Reports.StatusUpdate("Found \"SECOND\" on Utility Summary table", true);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"SECOND\" on Utility Summary table" + e.Message, false);
                }
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0014 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0015()
        {
            try 
            {
                Reports.TestDescription = "BR_FM976: System can edit the contacts on file side, this edit will not update the business party's information on the global address book.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                //City = "Santa Ana", 
                                County = "ALAMEDA", 
                                //Country = "USA" 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region Create a New Instance and Edit Contacts at File Level
                Reports.TestStep = "Create a New Instance and Edit Contacts at File Level.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                FastDriver.UtilityDetail.Edit.FASetCheckbox(true);
                FastDriver.UtilityDetail.BusPhone.FASetText(@"2222222222");
                FastDriver.UtilityDetail.BusFax.FASetText(@"2222222222");
                FastDriver.UtilityDetail.EditName.FASetCheckbox(true);
                FastDriver.UtilityDetail.Name.FASetText(@"EDITNAME");
                FastDriver.BottomFrame.Done();
                #endregion
                #region To click on Find button under business party
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.Find.Click();
                #endregion
                #region Select file ADDRESS BOOK RADIO and verify that id added to FAB
                Reports.TestStep = "Select file ADDRESS BOOK RADIO and verify that id added to FAB.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio);
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "Utility Company", "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0015 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0016()
        {
            //this test is failing because of Bug 679490
            try 
            {
                Reports.TestDescription = "BR_FM4791_92_93_97_96_99_FM4800_01_34_35_84_ES6470_71: Verify the Sales representative on different screens of fast, Maintain Sales Representative,Desect,Check Sales Representative Format.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                //City = "Santa Ana", 
                                County = "ALAMEDA", 
                                //Country = "USA" 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region Select Sales Represent 1 and Sales Represent 2
                Reports.TestStep = "Select Sales Represent 1 and Sales Represent 2.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                //August 28, 2015
                //On EVAL01 and EVAL02 this should select QA06 or QA08 
                FastDriver.FileHomepage.BusinessPartySalesRep1.FASelectItemBySendingKeys(@"FATICO, Firstam");
                FastDriver.FileHomepage.BusinessPartySalesRep2.FASelectItemBySendingKeys(@"FATICO, Firstam");
                FastDriver.BottomFrame.Save();
                #endregion
                #region Change the Business Party on File Home Page
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyGABcode.FASetText(@"FMUC19AECP");
                FastDriver.FileHomepage.BussinessPartyFind.SendKeys("");
                FastDriver.FileHomepage.BussinessPartyFind.Click();
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(Timeout: 15);
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                #endregion
                #region Verifying for The Sales Representatives and attention field
                Reports.TestStep = "Verifying for The Sales Representatives and attention field.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"FIRST", FastDriver.FileHomepage.BusinessPartyAttention.FAGetSelectedItem());
                Support.AreEqual(@"QA06, FAST", FastDriver.FileHomepage.BusinessPartySalesRep1.FAGetSelectedItem().ToString());
                Support.AreEqual(@"QA08, FAST", FastDriver.FileHomepage.BusinessPartySalesRep2.FAGetSelectedItem().ToString());
                FastDriver.BottomFrame.Save();
                #endregion
                #region Change the attention field and verifying for the Default Sales Representative for the Business Source
                Reports.TestStep = "Change the attention field and verifying for the Default Sales Representative for the Business Source.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessPartyAttention.FASelectItem(@"SECOND");
                Support.AreEqual(@"", FastDriver.FileHomepage.BusinessPartySalesRep1.FAGetSelectedItem());
                Support.AreEqual(@"", FastDriver.FileHomepage.BusinessPartySalesRep2.FAGetSelectedItem());
                FastDriver.BottomFrame.Save();
                #endregion
                #region Verifying the Business Party and Sales Represent Changed Event
                Reports.TestStep = "Verifing the Business Party and Sales Represent Changed Event.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                try
                {
                    FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[FileBusiness Party & SalesRep(s) changed]", "Event", TableAction.Click);
                    Reports.StatusUpdate("Found \"[FileBusiness Party & SalesRep(s) changed]\" on Event table", true);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"[FileBusiness Party & SalesRep(s) changed]\" on Event table" + e.Message, false);
                }
                #endregion
                #region Verifing the Sales Represent Changed Event
                Reports.TestStep = "Verifing the Sales Represent Changed Event.";
                try
                {
                    FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Sales Reps Changed]", "Event", TableAction.Click);
                    Reports.StatusUpdate("Found \"[Sales Reps Changed]\" on Event table", true);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"[Sales Reps Changed]\" on Event table" + e.Message, false);
                }
                #endregion
                #region Create an AD-HOC instance of REB
                Reports.TestStep = "Create an AD-HOC instance of REB.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.FAClick();
                #endregion
                #region Enter REB ad-hoc details
                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Alameda");
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #region Verify that Sales Representative will be display as Blank when instance is created through ADHOC Entry
                Reports.TestStep = "Verify that Sales Representative will be display as Blank when instance is created through ADHOC Entry.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgent.OtherBrokerNameRow.Click();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.EditOther.Click();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual(@"true", FastDriver.RealEstateBrokerAgent.BrokerContactSalesRep1.Exists().ToString().ToLower());
                Support.AreEqual(@"true", FastDriver.RealEstateBrokerAgent.BrokerContactSalesRep2.Exists().ToString().ToLower());
                #endregion
                #region Validate the OEC Sales Representative Drop Down
                Reports.TestStep = "Validate the OEC Sales Representative Drop Down.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.OutsideEscrowCompanyDetail.SalesRep1.Exists().ToString().ToLower());
                Support.AreEqual("true", FastDriver.OutsideEscrowCompanyDetail.SalesRep2.Exists().ToString().ToLower());
                #endregion
                #region Validate the sales representative at Attorney Seller
                Reports.TestStep = "Validate the sales representative at Attorney Seller.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.AttorneyDetail.SalesRep1.Exists().ToString().ToLower());//Map this
                Support.AreEqual("true", FastDriver.AttorneyDetail.SalesRep2.Exists().ToString().ToLower());//Map this
                #endregion
                #region Validate the sales representative at Attorney Buyer
                Reports.TestStep = "Validate the sales representative at Attorney Buyer.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.AttorneyDetail.SalesRep1.Exists().ToString().ToLower());
                Support.AreEqual("true", FastDriver.AttorneyDetail.SalesRep2.Exists().ToString().ToLower());
                #endregion
                #region Verify the sales Representative 1 and Sales Representative 2 are displayed for REB Seller
                Reports.TestStep = "Verify the sales Representative 1 and Sales Representative 2 are displayed for REB Seller.";
                FastDriver.RealEstateBrokerAgent.NavigateToRealEstateBrokerAgent();
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB(@"HUDFLINSR1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual(@"true", FastDriver.RealEstateBrokerAgent.BrokerContactSalesRep1.Exists().ToString().ToLower());
                Support.AreEqual(@"true", FastDriver.RealEstateBrokerAgent.BrokerContactSalesRep2.Exists().ToString().ToLower());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0016 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0017()
        {
            try
            {
                Reports.TestDescription = "BR_ES10425_26_27_28_29_30_32_34_EWC_1: GAB Entry Request, GAB Request from a new file, GAB Request from an unsaved FBP,Search for GAB Entry, Required Fields to launch new GAB Request.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Click on skip button to go to QFE
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").ClickSkipSearchButton();
                #endregion
                #region In QFE screen clicking on Find button
                Reports.TestStep = "In QFE screen clicking on Find button.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceFind.Click();
                #endregion
                #region Enter another entity type
                Reports.TestStep = "Enter another entity type.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Attorney");          
                #endregion
                #region Found more than 300 records in Gab Search
                Reports.TestStep = "Found more than 300 records in Gab Search.";
                string expMsg = "Found more than 300 records.\r\nA maximum of 300 records will be displayed.\r\nIn order to have less record please provide more data for search.";
                Support.AreEqual(expMsg, FastDriver.WebDriver.HandleDialogMessage(timeout: 10));
                #endregion
                #region Click on New GAB button
                Reports.TestStep = "Click on New GAB button.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();
                #endregion
                #region Enter Attorney type to Create GAB Request
                Reports.TestStep = "Enter Attorney type to Create GAB Request.";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItemBySendingKeys(@"Attorney");
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #region Warn: Name1 is a required field
                Reports.TestStep = "Warn: Name1 is a required field.";
                string expMsgWarn = "Warning: Name1 is a required field.";
                Support.AreEqual(expMsgWarn, FastDriver.WebDriver.HandleDialogMessage());
                #endregion
                #region Enter First Name to Create GAB Request
                Reports.TestStep = "Enter First Name to Create GAB Request.";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.Name1.FASetText(@"Name 1 TFS 106786");
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #region This request is rejected due to incomplete information. In order to complete your request to add this Party to the Global Address Book you need to provide Address Line 1, City, and State
                Reports.TestStep = "This request is rejected due to incomplete information.  In order to complete your request to add this Party to the Global Address Book you need to provide Address Line 1, City, and State.";
                string expMsgReq = "This request is rejected due to incomplete information.  In order to complete your request to add this Party to the Global Address Book you need to provide Address Line 1, City, and State.";
                string actualMsgReq = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: false);
                Support.AreEqual(expMsgReq, actualMsgReq);
                #endregion
                #region Creates a New GAB Request
                Reports.TestStep = "Creates a New GAB Request.";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItem(@"Attorney");
                FastDriver.GABEntryRequestDlg.Name1.FASetText(@"Name 1 TFS 106786");
                FastDriver.GABEntryRequestDlg.Name2.FASetText(@"Name 2 TFS 106786");
                FastDriver.GABEntryRequestDlg.LocDescription.FASetText(@"Loc Description");
                FastDriver.GABEntryRequestDlg.TaxIDNumber.FASetText(@"1111111111");
                FastDriver.GABEntryRequestDlg.BusOrgComments.FASetText(@"Bus Org Comments");
                FastDriver.GABEntryRequestDlg.EntryInstructions.FASetText(@"Entity Instruction");
                FastDriver.GABEntryRequestDlg.BusinessPhoneNumber.FASetText(@"#");
                FastDriver.GABEntryRequestDlg.BusinessFaxNumber.FASetText(@"#");
                FastDriver.GABEntryRequestDlg.EmailNumber.FASetText(@"Sshrivastava@firstam.com");
                FastDriver.GABEntryRequestDlg.PagerNumber.FASetText(@"#");
                FastDriver.GABEntryRequestDlg.CellularNumber.FASetText(@"#");
                FastDriver.GABEntryRequestDlg.HomePhoneNumber.FASetText(@"#");
                FastDriver.GABEntryRequestDlg.HomeFaxNumber.FASetText(@"#");
                FastDriver.GABEntryRequestDlg.MailingAddressLine1.FASetText(@"1 First American Way");
                FastDriver.GABEntryRequestDlg.MailingAddressLine2.FASetText(@"1 First American Way");
                FastDriver.GABEntryRequestDlg.MailingAddressLine4.FASetText(@"1 First American Way");
                FastDriver.GABEntryRequestDlg.MailingAddressCity.FASetText(@"Santa Ana");
                FastDriver.GABEntryRequestDlg.MailingAddressState.FASelectItem(@"CA");
                FastDriver.GABEntryRequestDlg.MailingAddressZip.FASetText(@"92707");
                FastDriver.GABEntryRequestDlg.MailingAddressCounty.FASetText(@"Orange");
                FastDriver.GABEntryRequestDlg.ContactsAdd.Click();
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad(element: FastDriver.GABEntryRequestDlg.ContactsFirstName);
                FastDriver.GABEntryRequestDlg.ContactsFirstName.FASetText(@"Contact First Name");
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #region First name and Last name are required fields
                Reports.TestStep = "First name and Last name are required fields.";
                string expMsgName = "First name and Last name are required fields";
                Support.AreEqual(expMsgName, FastDriver.WebDriver.HandleDialogMessage());
                #endregion
                #region Enter Contact Last Name
                Reports.TestStep = "Enter Contact Last Name.";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.ContactsLastName.FASetText(@"Contact Last Name");
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #region Verify that QFE Page is loaded
                Reports.TestStep = "Verify that QFE Page is loaded.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.QuickFileEntry.BusinessSourceFind.Exists().ToString().ToLower());
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0017 failed because " + e.Message);
            }
        }   

        [TestMethod]
        public void FMUC0019_REG0018()
        {
            try
            {
                Reports.TestDescription = "BR_ES10431: Verifying that Mail address is copied to the Business and Billing address and approve the GAB Request.";
                #region LOGIN
                _ADMLOGIN();
                #endregion
                #region Double Click on the Gab search results table
                Reports.TestStep = "Double Click on the Gab search results table.";
                FastDriver.LeftNavigation.Navigate<GABEntryRequestQueue>(@"Home>System Maintenance>GAB Entry Request Queue").WaitForGABEntryRequestTableToLoad();
                FastDriver.GABEntryRequestQueue.GABEntryRequestTable.PerformTableAction("#6", "Name 1 TFS 106786", "#1", TableAction.DoubleClick);
                FastDriver.AddressBookSearch.WaitForScreenToLoad();
                #endregion
                #region Select The entity Type and Click on Find Button
                Reports.TestStep = "Select The entity Type and Click on Find Button.";
                FastDriver.AddressBookSearch.SearchAddressBook(entityType: "Attorney");
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad(timeout: 10);
                FastDriver.AddressBookSearch.AddToGAB.FAClick();
                #endregion
                #region Verify that Billing address is reflecting correctly
                Reports.TestStep = "Verify that Billing address is reflecting correctly.";
                FastDriver.BusinessPartyOrganizationSetUpDlg.WaitForScreenToLoad(element: FastDriver.BusinessPartyOrganizationSetUpDlg.AddressTable);
                Support.AreEqual(true, FastDriver.BusinessPartyOrganizationSetUpDlg.AddressTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean().Contains("1 First American Way"), "Verifying that 1 First American Way is listed");
                #endregion
                #region Verify that Mailing address is reflecting correctly
                Reports.TestStep = "Verify that Mailing address is reflecting correctly.";
                Support.AreEqual(true, FastDriver.BusinessPartyOrganizationSetUpDlg.AddressTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean().Contains("1 First American Way"), "Verifying that 1 First American Way is listed");
                #endregion
                #region Verify that Business address is reflecting correctly
                Reports.TestStep = "Verify that Business address is reflecting correctly.";
                Support.AreEqual(true, FastDriver.BusinessPartyOrganizationSetUpDlg.AddressTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().Contains("1 First American Way"), "Verifying that 1 First American Way is listed");
                #endregion
                #region Click Done
                Reports.TestStep = "Click Done.";
                //FastDriver.BusinessPartyOrganizationSetUpDlg.SwitchToDialogContentFrame();
                FastDriver.BusinessPartyOrganizationSetUpDlg.Done.FAClick();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0018 failed because " + e.Message);
            }
        }   

        [TestMethod]
        public void FMUC0019_REG0019()
        {
            try
            {
                Reports.TestDescription = "ADMSETUP_FM4794: Set the values for Sales representative and Primary Contact.";
                #region LOGIN
                _ADMLOGIN();
                #endregion
                #region Search a GAB in Address Book and click on Edit button
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").SearchAddressBook("HUDFLINSR1");
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad(timeout: 10);
                FastDriver.AddressBookSearch.EditAddress(@"HUDFLINSR1");
                #endregion
                #region Remove the Primary Contact and Select the Sales Represents
                Reports.TestStep = "Remove the Primary Contact and Select the Sales Represents.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.PrimaryContact.FASelectItemBySendingKeys(@"");
                FastDriver.BusPartyOrgSetUp.SalesRep1.FASelectItemBySendingKeys(@"QA02 FAST");
                FastDriver.BusPartyOrgSetUp.SalesRep2.FASelectItemBySendingKeys(@"QA03 FAST");
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0019 failed because " + e.Message);
            }
        }   

        [TestMethod]
        public void FMUC0019_REG0020()
        {
            try
            {
                #region Variable Declaration
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 12000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "REFI";//REFINANCE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        //AddrBookEntryID =  179803671, //HUDASLNDR1
                        //AddrBookEntryID =  179803738, //HUDFLINSR1
                        //AddrBookEntryID =  179803644, //MORTLNDR
                        RoleTypeObjectCD = "BUSSOURCE",
                        //RoleTypeObjectCD = "DirectedBy",
                        BusOrgContact = new BusOrgContact(){
                            ContactName = @"CNTCTMortLNDR Name 2, CNTCTMortLNDR Name 1",
                        },//Attention...
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.NewLender
                        },
                        
                    }
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Validate the Business segment values
                Reports.TestStep = "Validate the Business segment values.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(@"Residential", FastDriver.FileHomepage.BusinessSegment.FAGetSelectedItem().ToString());
                #endregion
                #region Select Sales Represent 1 and Sales Represent 2
                Reports.TestStep = "Select Sales Represent 1 and Sales Represent 2.";
                //August 28, 2015
                //On EVAL01 and EVAL02 this should select QA02 or QA03 
                FastDriver.FileHomepage.BusinessPartySalesRep1.FASelectItemBySendingKeys(@"FATICO, Firstam");
                FastDriver.FileHomepage.BusinessPartySalesRep2.FASelectItemBySendingKeys(@"FATICO, Firstam");
                FastDriver.BottomFrame.Save();
                #endregion
            }
            catch(Exception e)
            {
                FailTest("Test case FMUC0019_REG0020 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0021()
        {
            try
            {
                Reports.TestDescription = "BR_FM4798: System should not change the File side contacts details when we are change contacts for the business party in the ADM.";
                #region LOGIN
                _ADMLOGIN();
                #endregion
                #region Search a GAB in Address Book and click on Edit button
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").SearchAddressBook("HUDFLINSR1");
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad(timeout: 10);
                FastDriver.AddressBookSearch.EditAddress(@"HUDFLINSR1");
                #endregion
                #region Validate the fields for exact values
                Reports.TestStep = "Validate the fields for exact values.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                Support.AreEqual(@"Flood Insurance 1 billing street 1", FastDriver.BusPartyOrgSetUp.AddressLine1.FAGetValue());
                Support.AreEqual(@"Flood Insurance 1 billing street 2", FastDriver.BusPartyOrgSetUp.AddressLine2.FAGetValue());
                Support.AreEqual(@"Flood Insurance 1 billing street 3", FastDriver.BusPartyOrgSetUp.AddressLine3.FAGetValue());
                Support.AreEqual(@"Flood Insurance 1 billing street 4", FastDriver.BusPartyOrgSetUp.AddressLine4.FAGetValue());
                Support.AreEqual(@"Flood Insurance 1 billing city", FastDriver.BusPartyOrgSetUp.City.FAGetValue());
                Support.AreEqual(@"74012-6548", FastDriver.BusPartyOrgSetUp.Zip.FAGetValue());
                Support.AreEqual(@"Flood Insurance 1 billing county", FastDriver.BusPartyOrgSetUp.County.FAGetValue());
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0021 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0022()
        {
            try
            {
                Reports.TestDescription = "BR_ES6642_ES6643: Display of Electronic Info for Data Elements.";
                #region Variable Declaration
                string data = "";
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 12000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "REFI";//REFINANCE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        //AddrBookEntryID =  179803671, //HUDASLNDR1
                        //AddrBookEntryID =  179803738, //HUDFLINSR1
                        //AddrBookEntryID =  179803644, //MORTLNDR
                        RoleTypeObjectCD = "BUSSOURCE",
                        //RoleTypeObjectCD = "DirectedBy",
                        BusOrgContact = new BusOrgContact(){
                            ContactName = @"CNTCTMortLNDR Name 2, CNTCTMortLNDR Name 1",
                        },//Attention...
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.NewLender
                        },
                        
                    }
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Navigate to Misc Disb and Search for GAB code HUDFLINSR1
                Reports.TestStep = "Navigate to Misc Disb and Search for GAB code HUDFLINSR1";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode(@"HUDFLINSR1");
                FastDriver.MiscDisbursementDetail.Attention.FASelectItemBySendingKeys(@"Contact, Flood Insurance 1");
                string BusPhone = FastDriver.MiscDisbursementDetail.BusinessPhone.FAGetValue().ToString();
                Support.DataSave("BusinessSourceBusinessPhone", "busphone1", BusPhone);
                string BusFax = FastDriver.MiscDisbursementDetail.BusinessFax.FAGetValue().ToString();
                Support.DataSave("BusinessSourceFax", "busphonefax1", BusFax);
                string CellPhone = FastDriver.MiscDisbursementDetail.CellPhone.FAGetValue().ToString();
                Support.DataSave("BusinessSourceCellPhone", "buscellphone1", CellPhone);
                string BusEmail = FastDriver.MiscDisbursementDetail.EmailAddress.FAGetValue().ToString();
                Support.DataSave("EmailAddress", "busemail1", BusEmail);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to Document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                #endregion
                #region Click on Add Button
                Reports.TestStep = "Click on Add Button.";
                FastDriver.DocumentRepository.Add.Click();
                #endregion
                #region Search Specific template
                Reports.TestStep = "Search Specific template.";
                //FastDriver.AdHocDocuments.SearchDocument(source: "Both", templateType: "Endorsement/Guarantee", templateDescription: "BusinessSourceContactInfo", state: "");
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.SearchDocument("Both", "Endorsement/Guarantee", "BusinessSourceContactInfo", "");
                //FastDriver.AdHocDocuments.TemplateType.FASelectItemBySendingKeys("Endorsement/Guarantee");
                //FastDriver.AdHocDocuments.TemplateType.SendKeys(FAKeys.Tab);
                //FastDriver.AdHocDocuments.WaitCreation(FastDriver.AdHocDocuments.TemplateDescription, 10);
                //FastDriver.AdHocDocuments.TemplateDescription.FASetText("BusinessSourceContactInfo");
                //FastDriver.AdHocDocuments.State.FASelectItem("");
                //FastDriver.AdHocDocuments.FindNow.Click();
                //FastDriver.AdHocDocuments.WaitCreation(FastDriver.AdHocDocuments.SearchResultsTable, 10);
                try
                {
                    //the Phrase BusinessSourceContactInfo for the template has to be added for the current region
                    //Verified production on August 31, 2015
                    FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Type", "Endorsement/Guarantee", "Type", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"BusinessSourceContactInfo\" on Ad Hoc Documents Search results table. This template needs to be added for the current region on this environment." + e.Message, false);
                }
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                Playback.Wait(2000); //wait document to get processed
                #endregion
                #region Select the Endorsement Guarantee Document and click on Edit
                Reports.TestStep = "Select the Endorsement Guarantee Document and click on Edit.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(element: FastDriver.DocumentRepository.DocumentsTable);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", "Endorsement/Guarantee", "#1", TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();
                #endregion
                #region Verify the Business Contacts for the Business source.Please verify Manually if fails
                Reports.TestStep = "Verify the Business Contacts for the Business source.Please verify Manually if fails.";
                FastDriver.DocumentPreparationwin.WaitForScreenToLoad();
                Support.DataLoad("BusinessSourceBusinessPhone", "busphone1");
                data = Support.data;//has the data from the previous DataLoad method
                Support.AreEqualTrim(@data, FastDriver.DocumentPreparationwin.BusinessSourceBusinessPhone.FAGetValue().ToString().Trim());//MiscDisbPhone1BusNo
                Support.DataLoad("BusinessSourceFax", "busphonefax1");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.DocumentPreparationwin.BusinessSourceFax.FAGetValue().ToString().Trim());//MiscDisbPhone1BusFaxNo
                Support.DataLoad("BusinessSourceCellPhone", "buscellphone1");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.DocumentPreparationwin.BusinessSourceCellPhone.FAGetValue().ToString().Trim());//MiscDisbPhone1CellPhoneNo
                Support.DataLoad("EmailAddress", "busemail1");
                data = Support.data;
                Support.AreEqualTrim(@data, FastDriver.DocumentPreparationwin.EmailAddress.FAGetValue().ToString().Trim());//MiscDisbPhoneEmailAddress
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0022 failed because " + e.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0019_REG0023()
        {
            try
            {
                Reports.TestDescription = "Error_Warning_Field_Definition_EWC03_To_12: Verifying Error Warn conditions for Business Party.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Set Default Check Printer
                SetDefaultCheckPrinter();
                #endregion
                #region Click on skip button to go to QFE
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").ClickSkipSearchButton();
                #endregion
                #region Entering Invalid ID For Business Source
                Reports.TestStep = "Entering Invalid ID For Business Source.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(@"INVALID_ID");
                FastDriver.QuickFileEntry.BusinessSourceFind.Click();
                #endregion
                #region ID Code Not Found
                Reports.TestStep = "ID Code Not Found.";
                string expMsg = @"ID Code not found.";
                Support.AreEqual(expMsg, FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton : true));
                #endregion
                #region Click on Find button in Business Source section
                Reports.TestStep = "Click on Find button in Business Source section.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceFind.Click();
                #endregion
                #region Click on Find button
                Reports.TestStep = "Click on Find button.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.Find.Click();
                #endregion
                #region User has requested a search without enter any search criteria in QFE
                Reports.TestStep = "User has requested a search without enter any search criteria in QFE.";
                string msg = "User must provide at least one search criterion to complete the search.";
                Support.AreEqual(msg, FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton : true));
                #endregion
                #region Enter Entity type and click on Find
                Reports.TestStep = "Enter Entity type and click on Find.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Developer");
                #endregion
                #region Click on New GAB button
                Reports.TestStep = "Click on New GAB button.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.NewGAB.Click();
                #endregion
                #region Change the Entity type and Click on Done
                Reports.TestStep = "Change the Entity type and Click on Done.";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItemBySendingKeys(@"Energy");
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #region Click on Ok button
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton : true);
                #endregion
                #region Enter Blank in entity type
                Reports.TestStep = "Enter Blank in entity type.";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItemByIndex(0);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #region User clicks on Done button without select an Entity Type for the request
                Reports.TestStep = "User clicks on Done button without select an Entity Type for the request.";
                expMsg = @"Warning: Entity Type is required.";
                string actualMsg = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                Support.AreEqual(expMsg, actualMsg);
                #endregion
                #region Enter Entity Type, Name 1, Address Line 1, City. Enter all the required data except state
                Reports.TestStep = "Enter Entity Type, Name 1, Address Line 1, City. Enter all the required data except state.";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItemBySendingKeys(@"Energy");
                FastDriver.GABEntryRequestDlg.Name1.FASetText(@"Name1");
                FastDriver.GABEntryRequestDlg.MailingAddressLine1.FASetText(@"Street1");
                FastDriver.GABEntryRequestDlg.MailingAddressCity.FASetText(@"Santa ana");
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #region This request is rejected due to incomplete information. In order to complete your request to add this Party to the Global Address Book you need to provide Address Line 1, City, and State
                Reports.TestStep = "This request is rejected due to incomplete information. In order to complete your request to add this Party to the Global Address Book you need to provide Address Line 1, City, and State.";
                expMsg = @"This request is rejected due to incomplete information.  In order to complete your request to add this Party to the Global Address Book you need to provide Address Line 1, City, and State.";
                actualMsg = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual(expMsg, actualMsg);
                #endregion
                #region Enter all the required data to create GAB Request
                Reports.TestStep = "Enter all the required data to create GAB Request.";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItemBySendingKeys(@"Energy");
                FastDriver.GABEntryRequestDlg.Name1.FASetText(@"Name1");
                FastDriver.GABEntryRequestDlg.MailingAddressLine1.FASetText(@"Street1");
                FastDriver.GABEntryRequestDlg.MailingAddressCity.FASetText(@"Santa ana");
                FastDriver.GABEntryRequestDlg.MailingAddressState.FASelectItemBySendingKeys(@"CA");
                FastDriver.GABEntryRequestDlg.ContactsAdd.Click();
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #region First name and Last name are required fields
                Reports.TestStep = "First name and Last name are required fields.";
                expMsg = "First name and Last name are required fields";
                actualMsg = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                Support.AreEqual(expMsg, actualMsg);
                #endregion
                #region Enter all the required data to create GAB Request.
                Reports.TestStep = "Enter all the required data to create GAB Request.";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.ContactsFirstName.FASetText(@"Contact First Name");
                FastDriver.GABEntryRequestDlg.ContactsLastName.FASetText(@"Contact Last Name");
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #region Entering Business Party Clicking on Find
                Reports.TestStep = "Entering Business Party Clicking on Find.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.QuickFileEntry.BusinessSourceFind.Exists().ToString().ToLower());
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode(@"HUDFLINSR1");
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                #endregion
                #region Select Edit contact check box and Entering Invalid Email ID
                Reports.TestStep = "Select Edit contact check box and Entering Invalid Email ID.";
                FastDriver.QuickFileEntry.BusinessSourceEditCont.FASetCheckbox(true);
                FastDriver.QuickFileEntry.BusinessSourceEmailAddress.FASetText(@"Invalid@First");
                FastDriver.BottomFrame.Save();
                #endregion
                #region Enter invalid data
                Reports.TestStep = "Enter invalid data.";
                expMsg = @"Please correct invalid data entered.";
                Support.AreEqual(expMsg, FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true));
                #endregion
                #region Entering Valid Email ID and Select Edit Name check Box
                Reports.TestStep = "Entering Valid Email ID and Select Edit Name check Box.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceEmailAddress.FASetText(@"valid@Firstam.com");
                FastDriver.QuickFileEntry.BusinessSourceEditName.FASetCheckbox(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState(@"CA");
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                #endregion
                #region When user checks the Edit Name Check Box and user tries to save the split fee information without specify the Name
                Reports.TestStep = "When user checks the Edit Name Check Box and user tries to save the split fee information without specify the Name.";
                expMsg = @"Name Field is required when Edit Name Checkbox is selected";
                Support.AreEqual(expMsg, FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true));                
                #endregion
                #region Entering Name in Edit Name Check Box
                Reports.TestStep = "Entering Name in Edit Name Check Box.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceEditName.FASetCheckbox(true);
                FastDriver.QuickFileEntry.BusinessSourceNameEdit.FASetText(@"Name Edit");
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Get File No. From File Home Page
                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.FileHomepage.ChangeOO.Exists().ToString().ToLower());
                Support.DataSave("FileNum", "FileNum1", FastDriver.FileHomepage.FileNum.FAGetValue().ToString());
                #endregion
                #region Add a homeowner association instance directly
                Reports.TestStep = "Add a homeowner association instance directly.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode(@"247");
                FastDriver.HomeownerAssociation.AmountDues.FASetText(@"10.00");
                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys(@"MONTH");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FASetText(@"4.00");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FASetText(@"2.00");
                FastDriver.HomeownerAssociation.ManagementCompanyBuyerCharge.FASetText(@"4.50");
                FastDriver.HomeownerAssociation.ManagementCompanySellerCharge.FASetText(@"2.50");
                FastDriver.HomeownerAssociation.ProrationAmount.FASetText(@"10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText(@"07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText(@"08-17-2012");
                FastDriver.HomeownerAssociation.ProrationBuyerCharge.FASetText(@"1.50");
                FastDriver.HomeownerAssociation.ProrationSellerCharge.FASetText(@"2.50");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Validate a newly added homeowner association instance directly
                Reports.TestStep = "Validate a newly added homeowner association instance directly.";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                Support.AreEqual(@"10.00", FastDriver.HomeownerAssociation.AmountDues.FAGetValue());
                Support.AreEqual(@"MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem());
                Support.AreEqual(@"4.00", FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FAGetValue());
                Support.AreEqual(@"2.00", FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FAGetValue());
                Support.AreEqual(@"4.50", FastDriver.HomeownerAssociation.ManagementCompanyBuyerCharge.FAGetValue());
                Support.AreEqual(@"2.50", FastDriver.HomeownerAssociation.ManagementCompanySellerCharge.FAGetValue()); 
                Support.AreEqual(@"10.00", FastDriver.HomeownerAssociation.ProrationAmount.FAGetValue());
                Support.AreEqual(@"07-16-2012", FastDriver.HomeownerAssociation.FromDate.FAGetValue());
                Support.AreEqual(@"08-17-2012", FastDriver.HomeownerAssociation.ToDate.FAGetValue());
                Support.AreEqual(@"1.50", FastDriver.HomeownerAssociation.ProrationBuyerCharge.FAGetValue());
                Support.AreEqual(@"2.50", FastDriver.HomeownerAssociation.ProrationSellerCharge.FAGetValue());    
                #endregion
                #region Navigate to Home Warranty screen
                Reports.TestStep = "Navigate to Home Warranty screen.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode(@"248");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText(@"Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText(@"300.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText(@"275.00");
                FastDriver.HomeWarrantyDetail.Amount.FASetText(@"562.00");
                FastDriver.HomeWarrantyDetail.EarlyCoverageChargeDescription.FASetText(@"Home Warranty - Early Coverage");
                FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FASetText(@"699.00");
                FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FASetText(@"845.00");
                FastDriver.BottomFrame.Done();                
                #endregion
                #region Click on Scan button for scan
                Reports.TestStep = "Navigate to Document Repository screen.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.FilteredTemplatesTab.Click();//Sometimes Documents tab is loaded with the Doc Rep screen
                FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();
                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.DocumentRepository.Scan.Click();
                #endregion
                #region Click on Open Button
                Reports.TestStep = "Click on Open Button.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                //Must include the annotation "DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")" for the following to work
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(500);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000); //wait for Save Document dialog
                Reports.TestStep = "Save the TIF Doc.";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);
                #endregion
                #region Click on A division of First American Payee then edit
                Reports.TestStep = "Click on A division of First American Payee then edit.";
                FastDriver.ActiveDisbursementSummary.Open(elementToWaitFor: FastDriver.ActiveDisbursementSummary.Disbursements);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", @"A Division Of First American Title Ins.", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion
                #region Convert to wire attach Instruction
                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem(@"Wire");
                FastDriver.EditDisbursement.Add.Click();
                #endregion
                #region Select the wire Instruction Doc
                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #region Convert to wire attach Instruction
                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText(@"12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText(@"ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText(@"ReceivingBankAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText(@"12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText(@"12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText(@"BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText(@"Beneficiary Note 1");
                FastDriver.BottomFrame.Save();
                #endregion
                #region Click on Midwest Financial Group Payee then Print
                Reports.TestStep = "Click on Midwest Financial Group Payee then Print.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", @"Midwest Financial Group", "Status", TableAction.Click);
                Support.AreEqual(true.ToString().ToLower(), FastDriver.ActiveDisbursementSummary.Print.Enabled.ToString().ToLower());
                
                Reports.TestStep = "Click on Print.";
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                #endregion
                #region Click on Deliver
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.Click();
                
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog.";
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 210);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Changing the Business party
                Reports.TestStep = "Changing the Business party.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HUDFLINSR1");
                actualMsg = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                #endregion
                #region Change Payee To whom check issued
                Reports.TestStep = "Change Payee To whom check issued.";
                expMsg = @"A check has been issued for this Payee.  The Payee name cannot be changed.";
                Support.AreEqual(expMsg, actualMsg);
                #endregion
                #region Change the Business ID For the Payee whose Wire in in Issued Status
                Reports.TestStep = "Change the Business ID For the Payee whose Wire in in Issued Status.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode(@"HUDFLINSR1");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Click on Ok button
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                #endregion
                #region Verifying for the Error After Change Business Party for Issued Wire
                Reports.TestStep = "Verifying for the Error After Change Business Party for Issued Wire.";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.HomeownerAssociation.ErrorMessageList.FAGetText().Contains("A wire has been created for this Payee. The Payee name cannot be changed.").ToString().ToLower());
                #endregion 
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0023 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0024_PH()
        {
            try
            {
                Reports.TestDescription = "FM1497_ES6130_ES13464_ES10683_ES10438_ES10433: Please verify These BRs Manually we cant automate.";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Support.AreEqual("true", "false");//set it to fail, so manual team will look at it
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0024_PH failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0019_REG0025_PH()
        {
            try
            {
                Reports.TestDescription = "ES6446_FM3749_ES10437_ES10435_ES10436_ES13464_ES6446: Please verify These BRs Manually we cant automate.";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Support.AreEqual("true", "false");//set it to fail, so manual team will look at it
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0019_REG0025_PH failed because " + e.Message);
            }
        }   

        #endregion


        #region IISLOGIN
        public void _IISLOGIN(string UserName = null, string Password = null)
        {
            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }
        #endregion

        #region ADMLOGIN
        public void _ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);

        }
        #endregion
      
        public void SetDefaultCheckPrinter()
        {
            Reports.TestStep = "Set default check printer";
            FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
            FastDriver.PrinterConfiguration.SetDefaultPrinter();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
