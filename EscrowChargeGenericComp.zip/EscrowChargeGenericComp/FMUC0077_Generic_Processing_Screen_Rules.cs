﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using AutoIt;
using System.Linq;


namespace EscrowChargeGenericComp
{
    /// <summary>
    /// Summary description for FMUC0077_Generic_Processing_Screen_Rules
    /// </summary>
    [CodedUITest]
    public class FMUC0077_Generic_Processing_Screen_Rules : MasterTestClass
    {
        #region Regression

        #region Test FMUC0077_REG0001

        [TestMethod]
        public void FMUC0077_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM2812_FM3200: Create Pending Disbursement from Home Warranty Screen.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").ClickSkipSearchButton();
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000.00");
                FastDriver.QuickFileEntry.TermsDatesLiabililtyAmount.FASetText("5000.00");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("5000.00");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("246");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Home Warranty screen & enter charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("HUDHMWRNT2");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                if (!AutoConfig.UseCDFormType)
                    FastDriver.HomeWarrantyDetail.BuyerBroker.FASetText("300.00");
                else
                    FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 300);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Check Amount.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("Check Amount :$300.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Clean());

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("400");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItemBySendingKeys("Buyer");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItemBySendingKeys("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItemBySendingKeys("Other");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Navigate to Active disbursement Summary and select pending check and click on Print.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                IWebElement element = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "300.00", "Payee", TableAction.GetCell).Element
                    .FindElements(By.TagName("span")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Support.AreEqual("Home Warranty 2 for HUD Test Name 1 Home", element.Text.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "300.00", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                Keyboard.SendKeys("^L");
                Playback.Wait(250);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 60);

                Reports.TestStep = "Verifying for the Issued status.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                element = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Issued", "Amount", TableAction.GetCell).Element
                    .FindElements(By.TagName("span")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Support.AreEqual("300.00", element.Text.Clean());
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                Reports.TestStep = "Validate the check issued.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                Support.AreEqual("Check Amount :$300.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Clean());
                Reports.StatusUpdate("CheckIssuedImage  Exists? -> " + FastDriver.HomeWarrantyDetail.CheqImage.Displayed.ToString(), 
                    FastDriver.HomeWarrantyDetail.CheqImage.Displayed);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Changing the Business party.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("HUDFLINSR1");
                FastDriver.HomeWarrantyDetail.Find.FAClick();

                Reports.TestStep = "Change Payee To whom check issued.";
                Support.AreEqual("A check has been issued for this Payee. The Payee name cannot be changed.", FastDriver.WebDriver.HandleDialogMessage(true, true).Clean());

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0077_REG0002

        [TestMethod]
        public void FMUC0077_REG0002()
        {
            try
            {
                Reports.TestDescription = "EditingContactInADM: Edit Contact in ADM side.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                String NumToUpdate;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Search For HUDFLINSR1 GAB code.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText("HUDHMWRNT2");
                FastDriver.AddressBookSearch.Find.FAClick();
                Playback.Wait(3000);
                FastDriver.AddressBookSearch.WaitForScreenToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction("ID Code", "HUDHMWRNT2", "Name", TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "verify the gab details of HUDHMWRNT2 after click on edit on Address book search.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                Support.AreEqual("HUDHMWRNT2", FastDriver.BusPartyOrgSetUp.IDCode.GetAttribute("value").Clean());
                if (FastDriver.BusPartyOrgSetUp.BusinessFaxTypeNumber.GetAttribute("value").Clean() != "(616)451-2290")
                    NumToUpdate = "(616)451-2291";
                else
                    NumToUpdate = "(616)451-2290";
                FastDriver.BusPartyOrgSetUp.BusinessFaxTypeNumber.FASetText(NumToUpdate);
                value = FastDriver.BusPartyOrgSetUp.BusinessFaxTypeNumber.GetAttribute("value").Clean();
                FastDriver.BusPartyOrgSetUp.EmailNumber.FASetText("test@test.com");
                value = FastDriver.BusPartyOrgSetUp.EmailNumber.GetAttribute("value").Clean();
                FastDriver.BusPartyOrgSetUp.PagerType.FASelectItem("Pager");
                FastDriver.BusPartyOrgSetUp.PagerNumber.FASetText(NumToUpdate);
                value = FastDriver.BusPartyOrgSetUp.PagerNumber.GetAttribute("value").Clean();
                FastDriver.BusPartyOrgSetUp.CellularType.FASelectItem("Cellular");
                FastDriver.BusPartyOrgSetUp.CellularNumber.FASetText(NumToUpdate);
                value = FastDriver.BusPartyOrgSetUp.CellularNumber.GetAttribute("value").Clean();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Search For HUDFLINSR1 GAB code.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText("HUDHMWRNT2");
                FastDriver.AddressBookSearch.Find.FAClick();
                Playback.Wait(3000);
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction("ID Code", "HUDHMWRNT2", "Name", TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "Verify that Contact edited.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                Support.AreEqual("HUDHMWRNT2", FastDriver.BusPartyOrgSetUp.IDCode.GetAttribute("value").Clean());
                Support.AreEqual(NumToUpdate, FastDriver.BusPartyOrgSetUp.BusinessFaxTypeNumber.GetAttribute("value").Clean());
                Support.AreEqual("test@test.com", FastDriver.BusPartyOrgSetUp.EmailNumber.GetAttribute("value").Clean());
                Support.AreEqual(NumToUpdate, FastDriver.BusPartyOrgSetUp.PagerNumber.GetAttribute("value").Clean());
                Support.AreEqual(NumToUpdate, FastDriver.BusPartyOrgSetUp.CellularNumber.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0077_REG0003

        [TestMethod]
        public void FMUC0077_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM2812_FM3200: Create Pending Disbursement from Home Warranty Screen.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("HUDHMWRNT2");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                if (!FastDriver.HomeWarrantyDetail.BuyerBroker.Enabled)
                    Support.Fail("This Test Case needs to be excuted in HUD Region! ");
                if(!AutoConfig.UseCDFormType)
                    FastDriver.HomeWarrantyDetail.BuyerBroker.FASetText("300.00");
                else
                    FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 300);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("400");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItemBySendingKeys("Buyer");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItemBySendingKeys("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItemBySendingKeys("Other");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                IWebElement element = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "300.00", "Payee", TableAction.GetCell).Element
                    .FindElements(By.TagName("span")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Support.AreEqual("Home Warranty 2 for HUD Test Name 1 Home", element.Text.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "300.00", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                Keyboard.SendKeys("^L");
                Playback.Wait(250);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 60);

                Reports.TestStep = "Verify the contacts information not reflected in File for entry for which Check is issued after editing in ADM side.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                Support.AreEqual("(616)451-2291", FastDriver.HomeWarrantyDetail.BusFax.GetAttribute("value").Clean());
                Support.AreEqual("(616)451-2291", FastDriver.HomeWarrantyDetail.CellPhone.GetAttribute("value").Clean());
                Support.AreEqual("(616)451-2291", FastDriver.HomeWarrantyDetail.Pager.GetAttribute("value").Clean());
                Support.AreEqual("test@test.com", FastDriver.HomeWarrantyDetail.EmailAddress.GetAttribute("value").Clean());

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion

        #endregion

        #region HelpMethods

        private static void CreateFile(string TransactionType = "SALE", string BusinessSegment = "RESIDENTAL", string BusSourceGabCode = "HUDFLINSR1", string DirectebyIDCode = "HUDLEASE03",
            string NewLoanIDCode = "247", string AssBusPartyIDCode = "HUDASLNDR1")
        {
            CreateFileRequest fileRequest = new CreateFileRequest();
            fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            fileRequest.File.BusinessParties = new FileBusinessParty[]
            {
                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(BusSourceGabCode),   // HUDFLINSR1
                    RoleTypeObjectCD = "BUSSOURCE",
                    CustomerReferenceNumber = "1234567890",
                    AdditionalRole = new AdditionalRoleList() { eAddtionalRole = AdditionalRoleType.NewLender }
                },

                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(DirectebyIDCode),   // HUDLEASE03
                    RoleTypeObjectCD = "DirectedBy"
                },

                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(AssBusPartyIDCode), // HUDASLNDR1
                    RoleTypeObjectCD = "ASSOTDPTY"
                }
            };

            fileRequest.File.BusinessSegmentObjectCD = BusinessSegment; // RESIDENTIAL
            fileRequest.File.TransactionTypeObjectCD = TransactionType; // REFI           
            fileRequest.File.NewLoan.FileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId(NewLoanIDCode);  // 247

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
