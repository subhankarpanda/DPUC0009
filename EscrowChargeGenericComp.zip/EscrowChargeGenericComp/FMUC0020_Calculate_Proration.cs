﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using AutoIt;
using System.Linq;

namespace EscrowChargeGenericComp
{
    /// <summary>
    /// Summary description for FMUC0020_Calculate_Proration
    /// </summary>
    [CodedUITest]
    public class FMUC0020_Calculate_Proration : MasterTestClass
    {
        #region BAT

        #region Test FMUC0020_BAT0001

        [TestMethod]
        public void FMUC0020_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1: Navigate to Proration Tax screen and create instance on Proration.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                String Date;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);
                /*
                Reports.TestStep = "Edit the Charge Description.";
                FastDriver.ProrationDetail.WaitForScreenToLoad();     //HUD
                FastDriver.ProrationDetail.Description.FASetText(@"Edit Charge Description");
                */
                Reports.TestStep = "Verify the Proration Details screen.";
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                    Reports.StatusUpdate("Credit Seller not selected!", true);
                else
                    Reports.StatusUpdate("Credit Seller selected!", false);

                FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(true);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.Amount.Text.Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.FromDate.Text.Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = (string)FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual(@"YEAR", value);
                Support.AreEqual("", FastDriver.ProrationDetail.ToDate.Text.Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                FastDriver.ProrationDetail.BuyerCredit.Click();
                Support.AreEqual("0.00", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Homeowner Association screen.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.HomeownerAssociation.GABcode.FASetText("HOA1");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("100.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Date = DateTime.Now.ToDateString();
                FastDriver.HomeownerAssociation.ToDate.FASetText(Date);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.FromDate.FASetText(Date);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                if (!FastDriver.HomeownerAssociation.CreditSeller.Selected)
                    FastDriver.HomeownerAssociation.CreditSeller.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                if (!FastDriver.HomeownerAssociation.DayofClosePaidbySeller.Selected)
                    FastDriver.HomeownerAssociation.DayofClosePaidbySeller.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.Per.FASelectItemBySendingKeys(@"YEAR");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                Playback.Wait(1000);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Support.AreEqual("0.27", FastDriver.HomeownerAssociation.ProrationBuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("0.27", FastDriver.HomeownerAssociation.ProrationSellerCredit.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0020_BAT0002

        [TestMethod]
        public void FMUC0020_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1: Modify_Tax_Proration_Without_Re-calculation.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Modify_Tax_Proration_Without_Recalculation for Amount field.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.ProrationDetail.Amount.FASetText("15");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Click on Cancel Button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Modify_Tax_Proration_Without_Recalculation for From Inclusive";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (FastDriver.ProrationDetail.fromInclusive.Selected)
                    FastDriver.ProrationDetail.fromInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0020_BAT0003

        [TestMethod]
        public void FMUC0020_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF2: Modify_Tax_Proration_With_Recalculation.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.ProrationDetail.Amount.FASetText("15" + FAKeys.Tab);
                FastDriver.ProrationDetail.BuyerCharge.FASetText("15" + Keys.Tab);
                //FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                //FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Modify_Tax_Proration_Without_Recalculation for From Inclusive";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (FastDriver.ProrationDetail.fromInclusive.Selected)
                    FastDriver.ProrationDetail.fromInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (!FastDriver.ProrationDetail.fromInclusive.Selected)
                    FastDriver.ProrationDetail.fromInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Modify_Tax_Proration_With_Recalculation for Amount field.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString(), "Verify whether the 'CreditSeller' checkbox is checked.");
                FastDriver.ProrationDetail.Amount.FASetText(@"20");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0020_BAT0004

        [TestMethod]
        public void FMUC0020_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF3: Verifying for Edited Modified tax Proration and verifying for entered.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Edit Calculated Charge Amounts without affecting the Proration formula.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.ProrationDetail.Amount.FASetText(@"20");
                if (!FastDriver.ProrationDetail.fromInclusive.Selected)
                    FastDriver.ProrationDetail.fromInclusive.FAClick();
                FastDriver.ProrationDetail.FromDate.FASetText("04-02-2012");
                FastDriver.ProrationDetail.ToDate.FASetText("07-02-2012");
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"YEAR");
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.BuyerCharge.FASetText(@"5.00");
                FastDriver.ProrationDetail.BuyerCredit.FASetText(@"10.00");

                Reports.TestStep = "Verify the modified amount on Proration tax screen.";
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("20.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = (string)FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("5.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("4.99", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());  

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0020_BAT0005

        [TestMethod]
        public void FMUC0020_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF4: Delete_Tax_Proration_Charges and Verifying.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.ProrationDetail.Amount.FASetText(@"20");
                if (!FastDriver.ProrationDetail.fromInclusive.Selected)
                    FastDriver.ProrationDetail.fromInclusive.FAClick();
                FastDriver.ProrationDetail.FromDate.FASetText("04-02-2012");
                FastDriver.ProrationDetail.ToDate.FASetText("07-02-2012");
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"YEAR");
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.BuyerCharge.FASetText(@"5.00");
                FastDriver.ProrationDetail.BuyerCredit.FASetText(@"10.00");

                Reports.TestStep = "Delete_Tax_Proration_Charge.";
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("20.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                FastDriver.ProrationDetail.BuyerCharge.FASetText(@"0");
                FastDriver.ProrationDetail.SellerCredit.FASetText(@"0");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Verify the Deleted buyer charge and Seller credit on Proration tax screen.";
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("20.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = (string)FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Deselect the Per Field on Proration Tax screen.";
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("20.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("");
                Playback.Wait(750);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("20.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = (string)FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0020_BAT0006

        [TestMethod]
        public void FMUC0020_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF4: Delete_Tax_Proration_Charges and Verifying.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.ProrationDetail.Amount.FASetText(@"20");
                if (!FastDriver.ProrationDetail.fromInclusive.Selected)
                    FastDriver.ProrationDetail.fromInclusive.FAClick();
                FastDriver.ProrationDetail.FromDate.FASetText("04-02-2012");
                FastDriver.ProrationDetail.ToDate.FASetText("07-02-2012");
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"YEAR");
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.BuyerCharge.FASetText(@"5.00");
                FastDriver.ProrationDetail.BuyerCredit.FASetText(@"10.00");
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("20.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                FastDriver.ProrationDetail.BuyerCharge.FASetText(@"0");
                FastDriver.ProrationDetail.SellerCredit.FASetText(@"0");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete the Proration Tax instance from Proration - Tax Screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Verify the Proration Details screen.";
                Support.AreEqual("False", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();


                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion

        #endregion

        #region Regression

        #region Test FMUC0020_REG0001

        [TestMethod]
        public void FMUC0020_REG0001()
        {
            try
            {
                Reports.TestDescription = "MF895_FM1663_FM1579: Calculate the Formula and and verify on change the Hold amount and other values.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.FileHomepage.ChangeOO.Displayed.ToString());

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Verify the Proration Details screen.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("False", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Enter Description and Charges.";
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                if (!FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected)
                    FastDriver.ProrationDetail.DayofClosePaidbySeller.FAClick();
                FastDriver.ProrationDetail.Amount.FASetText(@"10.00");
                FastDriver.ProrationDetail.FromDate.FASetText("04-02-2012");
                FastDriver.ProrationDetail.BasedOn.FASelectItem("365");
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"YEAR");
                FastDriver.ProrationDetail.ToDate.FASetText("07-02-2012");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Uncheck Paid Of closer checkBox.";
                if (FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected)
                    FastDriver.ProrationDetail.DayofClosePaidbySeller.FAClick();

                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Change the per Field to DAY.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"DAY");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per Day.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("DAY", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("910.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("910.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to MONTH.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"MONTH");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per Month.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("MONTH", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("29.99", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("29.99", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to QUARTER.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"QUARTER");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per Quarter.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("QUARTER", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("9.97", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("9.97", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to SEMIANNUAL.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"SEMIANNUAL");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per Semiannual.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("SEMIANNUAL", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("4.99", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("4.99", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to TRIMESTER.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"TRIMESTER");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per Trimester.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("TRIMESTER", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("7.48", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("7.48", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to WEEK.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"WEEK");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per Week.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("WEEK", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("130.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("130.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to YEAR.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"YEAR");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per Year.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change Based on Days To 360.";
                FastDriver.ProrationDetail.BasedOn.FASelectItem("360", false);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify that Based on Days Changed successfully.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);

                Reports.TestStep = "Change the per Field to DAY.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"DAY");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per Day.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("DAY", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("900.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("900.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to MONTH.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"MONTH");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per Month.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("MONTH", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("30.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("30.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to QUARTER.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"QUARTER");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per Quarter.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("QUARTER", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to SEMIANNUAL.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"SEMIANNUAL");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per SEMIANNUAL.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("SEMIANNUAL", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("5.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("5.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to TRIMESTER.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"TRIMESTER");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per TRIMESTER.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("TRIMESTER", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("7.50", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("7.50", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to WEEK.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"WEEK");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per WEEK.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("WEEK", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("130.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("130.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to YEAR.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"YEAR");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per YEAR.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("2.50", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("2.50", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change Based on Days To 366.";
                FastDriver.ProrationDetail.BasedOn.FASelectItem(@"366", false);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                
                Reports.TestStep = "Verify that Based on Days Changed successfully.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);

                Reports.TestStep = "Change the per Field to DAY.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"DAY");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per DAY.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("DAY", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("910.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("910.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to MONTH.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"MONTH");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per MONTH.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("MONTH", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("29.99", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("29.99", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to QUARTER.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"QUARTER");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per QUARTER.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("QUARTER", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("9.95", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("9.95", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to SEMIANNUAL.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"SEMIANNUAL");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per SEMIANNUAL.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("SEMIANNUAL", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("4.97", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("4.97", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to TRIMESTER.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"TRIMESTER");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per TRIMESTER.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("TRIMESTER", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("7.46", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("7.46", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to WEEK.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"WEEK");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per WEEK.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("WEEK", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("130.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("130.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to YEAR.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"YEAR");
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 365 Day format - Per YEAR.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0020_REG0002

        [TestMethod]
        public void FMUC0020_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM1922_FM2243: Edit the formula and verify the charges.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                if (FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected)
                    FastDriver.ProrationDetail.DayofClosePaidbySeller.FAClick();
                FastDriver.ProrationDetail.Amount.FASetText(@"10.00");
                FastDriver.ProrationDetail.FromDate.FASetText("04-02-2012");
                FastDriver.ProrationDetail.BasedOn.FASelectItem("366");
                FastDriver.ProrationDetail.ToDate.FASetText("07-02-2012");
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"YEAR");
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);
                
                Reports.TestStep = "Uncheck seller credit check Box.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();

                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Validate Buyer credit and seller charge after Uncheck Buyer Credit Checkbox.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("False", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Check seller credit check Box.";
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();

                Reports.TestStep = "Change prorate parameters in Insurance screen. Click on Cancel.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, false));

                Reports.TestStep = "Validate Buyer credit and seller charge after Uncheck Buyer Credit Checkbox.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Uncheck seller credit check Box.";
                if (FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();

                Reports.TestStep = "Change prorate parameters in Insurance screen. Click on Cancel.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, false));

                Reports.TestStep = "check seller credit check Box.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();

                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify Formula for 366 Day format - Per Year.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Uncheck Inclusive From Check Box.";
                if (FastDriver.ProrationDetail.fromInclusive.Selected)
                    FastDriver.ProrationDetail.fromInclusive.FAClick();

                Reports.TestStep = "Change prorate parameters in Insurance screen. Click on Cancel.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, false));

                Reports.TestStep = "Validate Buyer Charge and seller Credit after Uncheck the Inclusive Check Box for From.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "check Inclusive From Check Box.";
                if (!FastDriver.ProrationDetail.fromInclusive.Selected)
                    FastDriver.ProrationDetail.fromInclusive.FAClick();

                Reports.TestStep = "Change prorate parameters in Insurance screen. Click on Cancel.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, false));

                Reports.TestStep = "Uncheck Inclusive From Check Box.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (FastDriver.ProrationDetail.fromInclusive.Selected)
                    FastDriver.ProrationDetail.fromInclusive.FAClick();

                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Validate Buyer Charge and seller Credit after Uncheck the Inclusive Check Box for From.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("2.46", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("2.46", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "check Inclusive To Check Box.";
                if (!FastDriver.ProrationDetail.toInclusive.Selected)
                    FastDriver.ProrationDetail.toInclusive.FAClick();

                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Validate Buyer Charge and seller Credit after check the Inclusive Check Box for TO.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("366", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change Based on Value.";
                FastDriver.ProrationDetail.BasedOn.FASelectItem(@"360", false);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Change the per Field to DAY.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"DAY");

                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Change the per Field to YEAR.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"YEAR");

                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Validate Buyer Charge and seller Credit Change Based on Field.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("2.50", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("2.50", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the per Field to DAY.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"DAY");

                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Validate Buyer Charge and seller Credit Change Per Field.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("DAY", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("900.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("900.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "check Days of close by seller.";
                if (!FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected)
                    FastDriver.ProrationDetail.DayofClosePaidbySeller.FAClick();

                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Validate Day of Close Paid by Seller.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("DAY", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("900.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("900.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the amount.";
                FastDriver.ProrationDetail.Amount.FASetText("11.00");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Validate the changed amount.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("11.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("DAY", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("990.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("990.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the From Date.";
                FastDriver.ProrationDetail.FromDate.FASetText("05-02-2012");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Validate the changed From Date.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("11.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("05-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("DAY", value);
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("660.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("660.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Change the To Date.";
                FastDriver.ProrationDetail.ToDate.FASetText("8-2-2012");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Validate the changed To Date.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("11.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("05-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("360", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("DAY", value);
                Support.AreEqual("08-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("990.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("990.00", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0020_REG0003

        [TestMethod]
        public void FMUC0020_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM1873_FM1819_FM1690: Use Prorate as of Date, No Prorate As Of Date, Disable Prorate As Of Date.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                if (!FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected)
                    FastDriver.ProrationDetail.DayofClosePaidbySeller.FAClick();
                if (!FastDriver.ProrationDetail.fromInclusive.Selected)
                    FastDriver.ProrationDetail.fromInclusive.FAClick();
                FastDriver.ProrationDetail.Amount.FASetText(@"11.00");
                FastDriver.ProrationDetail.FromDate.FASetText("05-02-2012");
                FastDriver.ProrationDetail.BasedOn.FASelectItem("360");
                FastDriver.ProrationDetail.ToDate.FASetText("08-02-2012");
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"DAY");
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Select From prorate date check Box.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (!FastDriver.ProrationDetail.fromProrate.Selected)
                    FastDriver.ProrationDetail.fromProrate.FAClick();

                Reports.TestStep = "Prorate As Of Date does not exist.";
                Support.AreEqual("Prorate As Of Date does not exist.", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Setting Prorate date as of Date same as From date on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                value = FastDriver.TermsDatesStatus.Status.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("Open", value);
                FastDriver.TermsDatesStatus.ProrateAsOf.FASetText("05-02-2012");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Select Proration to calculate the re- Proration.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Re-calculate Prorations");
                FastDriver.ProrationDateChangedDlg.SwitchToDialogContentFrame();
                if (!FastDriver.ProrationDateChangedDlg.Insurance.Selected)
                    FastDriver.ProrationDateChangedDlg.Insurance.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "The Prorate As of Date has changed.";
                Support.AreEqual("The Prorate As of Date has changed. Would you like to update the Disbursement Date?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify the Prorate date as of Date same as From date on Proration Tax screen.";
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                value = FastDriver.TermsDatesStatus.Status.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("Open", value);
                Support.AreEqual("05-02-2012", FastDriver.TermsDatesStatus.ProrateAsOf.GetAttribute("value").Clean());

                Reports.TestStep = "Setting Prorate date as of Date same as TO date on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                value = FastDriver.TermsDatesStatus.Status.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("Open", value);
                FastDriver.TermsDatesStatus.ProrateAsOf.FASetText("08-02-2012");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Select Proration to calculate the re- Proration.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Re-calculate Prorations");
                FastDriver.ProrationDateChangedDlg.SwitchToDialogContentFrame();
                if (!FastDriver.ProrationDateChangedDlg.Insurance.Selected)
                    FastDriver.ProrationDateChangedDlg.Insurance.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "The Prorate As of Date has changed.";
                Support.AreEqual("The Prorate As of Date has changed. Would you like to update the Disbursement Date?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Verify the Prorate date as of Date same as To date on Proration Tax screen.";
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                value = FastDriver.TermsDatesStatus.Status.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("Open", value);
                Support.AreEqual("08-02-2012", FastDriver.TermsDatesStatus.ProrateAsOf.GetAttribute("value").Clean());

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Select From prorate date check Box.";
                if (!FastDriver.ProrationDetail.fromProrate.Selected)
                    FastDriver.ProrationDetail.fromProrate.FAClick();

                Reports.TestStep = "Change prorate parameters in Insurance screen. Click on Cancel.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, false));

                Reports.TestStep = "Validate that From Prorate Date is Disabled after selecting Prorate as of check Box.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                value = FastDriver.ProrationDetail.FromDate.Enabled.ToString();
                Reports.StatusUpdate("Field -> FromDate Enabled = " + value, (!FastDriver.ProrationDetail.FromDate.Enabled));

                Reports.TestStep = "Select From prorate date check Box.";
                if (!FastDriver.ProrationDetail.toProrate.Selected)
                    FastDriver.ProrationDetail.toProrate.FAClick();

                Reports.TestStep = "Change prorate parameters in Insurance screen. Click on Cancel.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, false));

                Reports.TestStep = "Validate that TO Prorate Date is Disabled after selecting Prorate as of check Box.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                value = FastDriver.ProrationDetail.ToDate.Enabled.ToString();
                Reports.StatusUpdate("Field -> ToDate Enabled = " + value, (!FastDriver.ProrationDetail.ToDate.Enabled));

                Reports.TestStep = "Uncheck Inclusive To Check Box.";
                if (FastDriver.ProrationDetail.toInclusive.Selected)
                    FastDriver.ProrationDetail.toInclusive.FAClick();

                Reports.TestStep = "Validate Proration Message.";
                if (FastDriver.WebDriver.HandleDialogMessage(true, true) == "Proration formula values have changed. Do you wish to recalculate prorated charges?")
                    Reports.StatusUpdate("", true);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0020_REG0004

        [TestMethod]
        public void FMUC0020_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM1817_FM1093_FM2715: User can use which date to inclusive, Fixed Proration charge, user can edit Buyer and seller charge.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                if (!FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected)
                    FastDriver.ProrationDetail.DayofClosePaidbySeller.FAClick();
                if (!FastDriver.ProrationDetail.fromInclusive.Selected)
                    FastDriver.ProrationDetail.fromInclusive.FAClick();
                FastDriver.ProrationDetail.Amount.FASetText(@"11.00");
                FastDriver.ProrationDetail.FromDate.FASetText("05-02-2012");
                FastDriver.ProrationDetail.BasedOn.FASelectItem("360");
                FastDriver.ProrationDetail.ToDate.FASetText("08-02-2012");
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(@"DAY");
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.ProrateAsOf.FASetText("08-02-2012");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Re-calculate Prorations");
                FastDriver.ProrationDateChangedDlg.SwitchToDialogContentFrame();
                if (!FastDriver.ProrationDateChangedDlg.Insurance.Selected)
                    FastDriver.ProrationDateChangedDlg.Insurance.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);
                if (!FastDriver.ProrationDetail.fromProrate.Selected)
                    FastDriver.ProrationDetail.fromProrate.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (!FastDriver.ProrationDetail.toProrate.Selected)
                    FastDriver.ProrationDetail.toProrate.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (FastDriver.ProrationDetail.toInclusive.Selected)
                    FastDriver.ProrationDetail.toInclusive.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "check Inclusive To Check Box.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                if (FastDriver.ProrationDetail.fromInclusive.Selected)
                    FastDriver.ProrationDetail.fromInclusive.Click();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (!FastDriver.ProrationDetail.toInclusive.Selected)
                    FastDriver.ProrationDetail.toInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "check Inclusive From Check Box.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (!FastDriver.ProrationDetail.fromInclusive.Selected)
                    FastDriver.ProrationDetail.fromInclusive.FAClick();

                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Deselect From prorate date check Box.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (FastDriver.ProrationDetail.fromProrate.Selected)
                    FastDriver.ProrationDetail.fromProrate.FAClick();

                Reports.TestStep = "Calculated charges will be removed. Do you wish to delete FromDate ?";
                value = FastDriver.WebDriver.HandleDialogMessage(true, true);
                Support.AreEqual("True", value.Contains("Calculated charges will be removed.").ToString());
                Support.AreEqual("True", value.Contains("Do you wish to delete 'From Date' ?").ToString());

                Reports.TestStep = "Check From Proration date";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                if (!FastDriver.ProrationDetail.fromProrate.Selected)
                    FastDriver.ProrationDetail.fromProrate.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "check that From And TO date are same.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual(FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean().Substring(0,10),
                    FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean().Substring(0, 10));

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Enter amount to Buyer credit and Seller charge field.";
                FastDriver.ProrationDetail.BuyerCredit.FASetText("10.00");
                FastDriver.ProrationDetail.SellerCharge.FASetText("10.00");

                Reports.TestStep = "Validate that User can enter Buyer credit and seller charge Explicitly.";
                Support.AreEqual("10.00", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0020_REG0005

        [TestMethod]
        public void FMUC0020_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM2736: The system will disable proration charge calculation and manual entry when the transaction type is Refinance or Loan.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").ClickSkipSearchButton();
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Refinance");

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify for FileHomePage.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.FileHomepage.ChangeOO.Displayed.ToString());

                Reports.TestStep = "The system will disable proration charge calculation and manual entry when the transaction type is Refinance or Loan.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Miscellaneous").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.ProrationTax.New.Enabled.ToString());

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0020_REG0006

        [TestMethod]
        public void FMUC0020_REG0006()
        {
            try
            {
                Reports.TestDescription = "FM2736: The system will disable proration charge calculation and manual entry when the transaction type is Refinance or Loan.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                NewFileParameters fileParameters = new NewFileParameters();
                fileParameters.BusinessSourceGABcode = "HUDASLNDR1";
                fileParameters.TransactionType = "Sale w/Mortgage";
                fileParameters.PropertyState = "CA";
                fileParameters.PropertyCounty = "Orange";
                fileParameters.Title = true;
                fileParameters.Escrow = true;
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").ClickSkipSearchButton().CreateFile(fileParameters);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify for FileHomePage.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.FileHomepage.ChangeOO.Displayed.ToString());
                value = FastDriver.FileHomepage.FileNum.Text.Clean();

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("False", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "check Days of close by seller Enter From and To date as same.";
                if (!FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected)
                    FastDriver.ProrationDetail.DayofClosePaidbySeller.FAClick();
                FastDriver.ProrationDetail.Amount.FASetText("1000.00");
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.ProrationDetail.FromDate.FASetText(value);
                FastDriver.ProrationDetail.ToDate.FASetText(value + FAKeys.Tab);
                Keyboard.SendKeys(FAKeys.Tab);
                Support.AreEqual("City/Town Taxes", FastDriver.ProrationDetail.Description.GetAttribute("value").Clean());
                Support.AreEqual("2.74", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("2.74", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0020_REG0007_FD

        [TestMethod]
        public void FMUC0020_REG0007_FD()
        {
            try
            {
                Reports.TestDescription = "EWC_2_Field_Defination";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Verify for FileHomePage.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.FileHomepage.ChangeOO.Displayed.ToString());

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Verify for default controls on Protation Tax screen.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("False", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.Text.Clean();
                if (value == null)
                    value = "";
                Support.AreEqual("360 365 366", value);
                value = FastDriver.ProrationDetail.Per.Text.Clean();
                if (value == null)
                    value = "";
                Support.AreEqual("DAY MONTH QUARTER SEMIANNUAL TRIMESTER WEEK YEAR", value);
                Support.AreEqual("", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("City/Town Taxes", FastDriver.ProrationDetail.Description.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Check credit seller checkbox and Verify for Buyer seller charges and credits enable property.";
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                Reports.StatusUpdate("Field Description Enabled -> " + FastDriver.ProrationDetail.Description.Enabled, (!FastDriver.ProrationDetail.Description.Enabled));
                Reports.StatusUpdate("Field BuyerCharge Enabled -> " + FastDriver.ProrationDetail.BuyerCharge.Enabled, (FastDriver.ProrationDetail.BuyerCharge.Enabled));
                Reports.StatusUpdate("Field BuyerCredit Enabled -> " + FastDriver.ProrationDetail.BuyerCredit.Enabled, (FastDriver.ProrationDetail.BuyerCredit.Enabled));
                Reports.StatusUpdate("Field SellerCharge Enabled -> " + FastDriver.ProrationDetail.SellerCharge.Enabled, (FastDriver.ProrationDetail.SellerCharge.Enabled));
                Reports.StatusUpdate("Field SellerCredit Enabled -> " + FastDriver.ProrationDetail.SellerCredit.Enabled, (FastDriver.ProrationDetail.SellerCredit.Enabled));

                Reports.TestStep = "Uncheck credit seller checkbox and Verify for Buyer seller charges and credits enable property.";
                if (FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                Reports.StatusUpdate("Field Description Enabled -> " + FastDriver.ProrationDetail.Description.Enabled, (!FastDriver.ProrationDetail.Description.Enabled));
                Reports.StatusUpdate("Field BuyerCharge Enabled -> " + FastDriver.ProrationDetail.BuyerCharge.Enabled, (FastDriver.ProrationDetail.BuyerCharge.Enabled));
                Reports.StatusUpdate("Field BuyerCredit Enabled -> " + FastDriver.ProrationDetail.BuyerCredit.Enabled, (FastDriver.ProrationDetail.BuyerCredit.Enabled));
                Reports.StatusUpdate("Field SellerCharge Enabled -> " + FastDriver.ProrationDetail.SellerCharge.Enabled, (FastDriver.ProrationDetail.SellerCharge.Enabled));
                Reports.StatusUpdate("Field SellerCredit Enabled -> " + FastDriver.ProrationDetail.SellerCredit.Enabled, (FastDriver.ProrationDetail.SellerCredit.Enabled));

                Reports.TestStep = "Check credit seller checkbox and Verify for Buyer seller charges and credits enable property.";
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                Reports.StatusUpdate("Field Description Enabled -> " + FastDriver.ProrationDetail.Description.Enabled, (!FastDriver.ProrationDetail.Description.Enabled));
                Reports.StatusUpdate("Field BuyerCharge Enabled -> " + FastDriver.ProrationDetail.BuyerCharge.Enabled, (FastDriver.ProrationDetail.BuyerCharge.Enabled));
                Reports.StatusUpdate("Field BuyerCredit Enabled -> " + FastDriver.ProrationDetail.BuyerCredit.Enabled, (FastDriver.ProrationDetail.BuyerCredit.Enabled));
                Reports.StatusUpdate("Field SellerCharge Enabled -> " + FastDriver.ProrationDetail.SellerCharge.Enabled, (FastDriver.ProrationDetail.SellerCharge.Enabled));
                Reports.StatusUpdate("Field SellerCredit Enabled -> " + FastDriver.ProrationDetail.SellerCredit.Enabled, (FastDriver.ProrationDetail.SellerCredit.Enabled));

                Reports.TestStep = "Check For Field Defination.";
                FastDriver.ProrationDetail.Amount.FASetText("1234567891000");
                FastDriver.ProrationDetail.FromDate.FASetText("1234567");
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                FastDriver.ProrationDetail.ToDate.FASetText("1234567");
                //FastDriver.ProrationDetail.Description.FASetText("123456789112345678911234567891123456789112345Extra");   //For CD this field is Disabled
                FastDriver.ProrationDetail.BuyerCharge.FASetText("1234567891000");
                FastDriver.ProrationDetail.BuyerCredit.FASetText("1234567891000");
                FastDriver.ProrationDetail.SellerCharge.FASetText("1234567891000");
                FastDriver.ProrationDetail.SellerCredit.FASetText("1234567891000");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Verify The error.";
                Support.AreEqual("?", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("??-??-????", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                value = FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("365", value);
                value = FastDriver.ProrationDetail.Per.FAGetSelectedItem();
                if (value == null)
                    value = "";
                Support.AreEqual("YEAR", value);
                Support.AreEqual("??-??-????", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                //Support.AreEqual("123456789112345678911234567891123456789112345", FastDriver.ProrationDetail.Description.GetAttribute("value").Clean());  //For CD this field is Disabled
                Support.AreEqual("?", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("?", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("?", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("?", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Reset.";
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Verify for default controls on Protation Tax screen.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("False", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.FromDate.GetAttribute("value").Clean());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                value = FastDriver.ProrationDetail.BasedOn.Text.Clean();
                if (value == null)
                    value = "";
                Support.AreEqual("360 365 366", value);
                value = FastDriver.ProrationDetail.Per.Text.Clean();
                if (value == null)
                    value = "";
                Support.AreEqual("DAY MONTH QUARTER SEMIANNUAL TRIMESTER WEEK YEAR", value);
                Support.AreEqual("", FastDriver.ProrationDetail.ToDate.GetAttribute("value").Clean());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("City/Town Taxes", FastDriver.ProrationDetail.Description.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Enter Description and Charges.";
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                if (!FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected)
                    FastDriver.ProrationDetail.DayofClosePaidbySeller.FAClick();
                FastDriver.ProrationDetail.Amount.FASetText("10.00");
                FastDriver.ProrationDetail.FromDate.FASetText("04-02-2012");
                FastDriver.ProrationDetail.BasedOn.FASelectItem("365");
                FastDriver.ProrationDetail.Per.FASelectItem("YEAR");
                FastDriver.ProrationDetail.ToDate.FASetText("07-02-2012");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Delete Proration Amount.";
                FastDriver.ProrationDetail.Amount.FASetText("");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Calculated charges will be removed. Do you wish to delete Amount ?";
                value = FastDriver.WebDriver.HandleDialogMessage(true, true);
                Reports.StatusUpdate("'Calculated charges will be removed.' Present on Message Dialog Text -> " + value.Contains("Calculated charges will be removed.").ToString(), 
                    value.Contains("Calculated charges will be removed."));
                Reports.StatusUpdate("'Do you wish to delete 'Amount' ?' Present on Message Dialog Text -> " + value.Contains("Do you wish to delete 'Amount' ?").ToString(), 
                    value.Contains("Do you wish to delete 'Amount' ?"));

                Reports.TestStep = "Validate that amount is deleted.";
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("0", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0020_REG0008

        [TestMethod]
        public void FMUC0020_REG0008()
        {
            try
            {
                Reports.TestDescription = "Field Definitions and FM1579 and FM2715 Business Rules covered.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                String Date = "03-03-2016";
                String Date1;
                String Date2;
                float amt = 500;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Navigate to Proration - Rent screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad();
                FastDriver.ProrationTax.Rent1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Enter data";
                Date = DateTime.Now.ToDateString();
                amt /= DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month);
                FastDriver.ProrationDetail.Amount.FASetText("500.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ProrationDetail.ToDate.FASetText(Date);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ProrationDetail.FromDate.FASetText(Date);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual(String.Format("{0:0.00}", amt), FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual(String.Format("{0:0.00}", amt), FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Proration - Rent screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad();
                FastDriver.ProrationTax.Rent1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Enter the Buyer/Seller Charges and Credits.";
                FastDriver.ProrationDetail.BuyerCharge.FASetText("5.10");
                FastDriver.ProrationDetail.BuyerCredit.FASetText("5.20");
                FastDriver.ProrationDetail.SellerCharge.FASetText("5.30");
                FastDriver.ProrationDetail.SellerCredit.FASetText("5.40");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the entered Charges and Credits.";
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.Rent1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Support.AreEqual("5.10", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("5.20", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());
                Support.AreEqual("5.30", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());
                Support.AreEqual("5.40", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Proration - Miscellaneous screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Miscellaneous").WaitForScreenToLoad();
                FastDriver.ProrationTax.Miscellaneous1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                Support.AreEqual("False", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                FastDriver.ProrationDetail.Amount.FASetText("9999999999.999");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("9,999,999,999.99", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Date1 = DateTime.Today.ToDateString();
                Date2 = DateTime.Today.AddDays(1).ToDateString();
                FastDriver.ProrationDetail.ToDate.FASetText(Date1);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ProrationDetail.FromDate.FASetText(Date2 + FAKeys.Tab);
                //Keyboard.SendKeys(FAKeys.TabAway);
                value = FastDriver.WebDriver.HandleDialogMessage(true, true, timeout: 30);
                Reports.StatusUpdate("Text -> ''To Date' must be later than or equal to 'From Date'' contained in Alert? " + value.Contains("'To Date' must be later than or equal to 'From Date'").ToString(), 
                    value.Contains("'To Date' must be later than or equal to 'From Date'"));
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.FromDate.FASetText(Date1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                
                value = FastDriver.ProrationDetail.BasedOn.Text.Clean();
                Reports.StatusUpdate("BaseOn contains '360' item?", value.Contains("360"));
                Reports.StatusUpdate("BaseOn contains '365' item?", value.Contains("365"));
                Reports.StatusUpdate("BaseOn contains '366' item?", value.Contains("366"));

                value = FastDriver.ProrationDetail.Per.Text.Clean();
                Reports.StatusUpdate("Per contains 'DAY' item?", value.Contains("DAY"));
                Reports.StatusUpdate("Per contains 'MONTH' item?", value.Contains("MONTH"));
                Reports.StatusUpdate("Per contains 'QUARTER' item?", value.Contains("QUARTER"));
                Reports.StatusUpdate("Per contains 'SEMIANNUAL' item?", value.Contains("SEMIANNUAL"));
                Reports.StatusUpdate("Per contains 'TRIMESTER' item?", value.Contains("TRIMESTER"));
                Reports.StatusUpdate("Per contains 'WEEK' item?", value.Contains("WEEK"));
                Reports.StatusUpdate("Per contains 'YEAR' item?", value.Contains("YEAR"));

                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());

                //FastDriver.ProrationDetail.Description.FASetText("abcdefghij12345.,/;*abcdefghij12345.,/;*abcdedfd4545");     //This code doesn't work on CD
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Support.AreEqual("abcdefghij12345.,/;*abcdefghij12345.,/;*abcde", FastDriver.ProrationDetail.Description.GetAttribute("value").Clean());

                FastDriver.ProrationDetail.BuyerCharge.FASetText("9999999999.999");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("9,999,999,999.99", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());

                FastDriver.ProrationDetail.BuyerCredit.FASetText("9999999999.999");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("9,999,999,999.99", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean());

                FastDriver.ProrationDetail.SellerCharge.FASetText("9999999999.999");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("9,999,999,999.99", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean());

                FastDriver.ProrationDetail.SellerCredit.FASetText("9999999999.999");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("9,999,999,999.99", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Workpane Specific Buttons";
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.Miscellaneous1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(500);

                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Keyboard.SendKeys("^D");
                Playback.Wait(2000);

                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.Miscellaneous1.FAClick();

                Reports.TestStep = "Perform Hot key operation for Remove button.";
                Keyboard.SendKeys("%R");
                Playback.Wait(250);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.Miscellaneous1.Click();

                Reports.TestStep = "Perform Hot key operation for Edit button.";
                Keyboard.SendKeys("%E");
                Playback.Wait(500);

                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.BuyerCharge.FASetText("5.00");

                Reports.TestStep = "Perform Hot key operation for Reset button.";
                Keyboard.SendKeys("^R");
                Playback.Wait(250);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Perform Hot key operation for Done button.";
                Keyboard.SendKeys("^D");
                Playback.Wait(2000);

                Reports.TestStep = "Perform Hot key operation for New button.";
                FastDriver.ProrationTax.WaitForScreenToLoad();
                Keyboard.SendKeys("%N");
                Playback.Wait(2000);

                Reports.TestStep = "Perform Hot key operation for Cancel button.";
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Keyboard.SendKeys("^Q");
                Playback.Wait(250);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0020_REG0009

        [TestMethod]
        public void FMUC0020_REG0009()
        {
            try
            {
                Reports.TestDescription = "EWC: Verify the Error Warning Condition for description is mandatory field and Verifying From and To same Date scenario.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                String Date1;
                String Date2;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Add a homeowner association instance directly.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("HOA1");
                FastDriver.HomeownerAssociation.Find.FAClick();

                if (!FastDriver.HomeownerAssociation.CreditSeller.Selected)
                    FastDriver.HomeownerAssociation.CreditSeller.FAClick();
                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("04-02-2012");
                FastDriver.HomeownerAssociation.BasedOn.FASelectItem("365");
                FastDriver.HomeownerAssociation.Per.FASelectItem("YEAR");
                FastDriver.HomeownerAssociation.ToDate.FASetText("07-02-2012");
                FastDriver.HomeownerAssociation.ProrationDescription.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(1000);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the message when user tries to save charges without entering the charge description.";
                Support.AreEqual("Unable to delete charge description. Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage(true, true).Clean());
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Verifying From and To same Date scenario.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("HOA1");
                FastDriver.HomeownerAssociation.Find.FAClick();

                Support.AreEqual("False", FastDriver.HomeownerAssociation.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.HomeownerAssociation.DayofClosePaidbySeller.Selected.ToString());
                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("9999999999.999");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("9,999,999,999.99", FastDriver.HomeownerAssociation.ProrationAmount.GetAttribute("value").Clean());
                Date1 = DateTime.Today.ToDateString();
                Date2 = DateTime.Today.AddDays(1).ToDateString();
                FastDriver.HomeownerAssociation.ToDate.FASetText(Date1);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.FromDate.FASetText(Date2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("'To Date' must be later than or equal to 'From Date'", FastDriver.WebDriver.HandleDialogMessage(true, true).Clean());
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FromDate.FASetText(Date1);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion


        #endregion

        #region HelpMethods

        private static void CreateFile(string TransactionType = "SALE", string BusinessSegment = "RESIDENTAL", string BusSourceGabCode = "HUDFLINSR1", string DirectebyIDCode = "HUDLEASE03",
            string NewLoanIDCode = "247", string AssBusPartyIDCode = "HUDASLNDR1")
        {
            CreateFileRequest fileRequest = new CreateFileRequest();
            fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            fileRequest.File.BusinessParties = new FileBusinessParty[]
            {
                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(BusSourceGabCode),   // HUDFLINSR1
                    RoleTypeObjectCD = "BUSSOURCE",
                    CustomerReferenceNumber = "1234567890",
                    AdditionalRole = new AdditionalRoleList() { eAddtionalRole = AdditionalRoleType.NewLender }
                },

                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(DirectebyIDCode),   // HUDLEASE03
                    RoleTypeObjectCD = "DirectedBy"
                },

                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(AssBusPartyIDCode), // HUDASLNDR1
                    RoleTypeObjectCD = "ASSOTDPTY"
                }
            };

            fileRequest.File.BusinessSegmentObjectCD = BusinessSegment; // RESIDENTIAL
            fileRequest.File.TransactionTypeObjectCD = TransactionType; // REFI           
            fileRequest.File.NewLoan.FileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId(NewLoanIDCode);  // 247

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
