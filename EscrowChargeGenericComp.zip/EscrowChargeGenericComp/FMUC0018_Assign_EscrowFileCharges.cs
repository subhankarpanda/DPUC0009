﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using AutoIt;


namespace FMUC0018
{
    /// <summary>
    /// Escrow Charge Generic Comp - FMUC0018
    /// </summary>
    [CodedUITest]
    public class FMUC0018 : MasterTestClass
    {
        
        #region BAT

        [TestMethod]
        public void FMUC0018_BAT0001()
        {
            try
            {
                string FormType = AutoConfig.FormType;

                Reports.TestDescription = "MF_001: Enter an Escrow File Charge.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with purpose of Sales w/Mortgage";
                CreateFile("SALE");
                 
                Reports.TestStep = "Navigate to Survey & entering GAB, Click find and fill details.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("HUDFLINSR1");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey");

                // ES15121  Show Default HUD-1 Line Numbers  (Tooltip verification - buyer charge)
                string Tooltip = FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetAttribute("title");
                if (FormType == "CD")
                    Support.AreEqual("Section : H", Tooltip);
                else
                    Support.AreEqual("HUD1 line Number : 1302", Tooltip);

                FastDriver.SurveyDetail.SurveyChargesTable.EnterCharges("Survey", buyerCharge: 11.05);

                //// ES15122   Show Default HUD-1 Line Numbers  (Tooltip verification - buyer charge)
                Tooltip = FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetAttribute("title");
                if (FormType == "CD")
                    Support.AreEqual("Section : H", Tooltip);
                else
                    Support.AreEqual("HUD1 line Number : 1302", Tooltip);

                //// ES15121  Show Default HUD-1 Line Numbers  (Tooltip verification - seller charge)
                Tooltip = FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetAttribute("title");
                if (FormType == "CD")
                    Support.AreEqual("Section : H", Tooltip);
                else
                    Support.AreEqual("HUD1 line Number : 1302", Tooltip);
                
                FastDriver.SurveyDetail.SurveyChargesTable.EnterCharges("Survey", sellerCharge: 12.09);

                //// ES15122  Show Default HUD-1 Line Numbers  (Tooltip verification - seller charge)
                Tooltip = FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetAttribute("title");
                if (FormType == "CD")
                    Support.AreEqual("Section : H", Tooltip);
                else
                    Support.AreEqual("HUD1 line Number : 1302", Tooltip);

                FastDriver.SurveyDetail.SurveyChargesTable.EnterCharges("Survey", loanEstimate: 10.05);

                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey", 1, TableAction.Click);

                Reports.TestStep = "Click on Borrower Selected Services-Payment Details.";
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                // CD changes 
                                
                Reports.TestStep = "Select GFE and payment method.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                if (FormType == "CD")
                {
                    Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem());
                    Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem());
                }
                else
                {
                    PaymentDetailsParameters PaymentDetails = new PaymentDetailsParameters();
                    PaymentDetails.BuyerChargePaymentMethod = "CHK";
                    PaymentDetails.SellerChargePaymentMethod = "CHK";
                    FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PaymentDetails);
                    FastDriver.PaymentDetailsDlg.GFEType.FASelectItem("11");
                }
                    
                Reports.TestStep = "Verify for details for Survey charges.";
                if (FormType == "CD")
                    Support.AreEqual("", FastDriver.PaymentDetailsDlg.DESCRPTION.Text);
                else
                    Support.AreEqual("", FastDriver.PaymentDetailsDlg.Description.Text);

                Support.AreEqual("$11.05", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue());
                Support.AreEqual("$12.09", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue());

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify and Validate Data entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                Support.AreEqual("HUDFLINSR1", FastDriver.SurveyDetail.IDcodeLabel.Text);

                FastDriver.SurveyDetail.SurveyChargesTable.VerifyCharges("Survey", buyerCharge: 11.05, sellerCharge: 12.09, loanEstimate: 10.05);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_BAT0002()
        {
            try
            {
                string FormType = AutoConfig.FormType;

                Reports.TestDescription = "AF1_001: Edit an Escrow File Charge.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with purpose of Sales w/Mortgage";
                CreateFile("SALE");
                
                Reports.TestStep = "Edit the details for Survey Details.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("HUDFLINSR1");

                FastDriver.SurveyDetail.SurveyChargesTable.EnterCharges("Survey", buyerCharge:11.05, sellerCharge:12.09, loanEstimate: 10.05);
                
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Modify Charge";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.SurveyChargesTable.EnterCharges("Survey", loanEstimate: 11.00, newDescription: "Survey1");
                
                Reports.TestStep = "Click on Borrower Selected Services-Payment Details.";
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey1", 1, TableAction.Click);
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                // CD changes 
                
                Reports.TestStep = "Select GFE and payment method.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                if (FormType == "CD")
                {
                    Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem());
                    Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem());
                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());
                }
                else
                {
                    PaymentDetailsParameters PaymentDetails = new PaymentDetailsParameters();
                    PaymentDetails.BuyerChargePaymentMethod = "FEE";
                    PaymentDetails.SellerChargePaymentMethod = "CHK";
                    FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PaymentDetails);
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify and Validate Data entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                Support.AreEqual("HUDFLINSR1", FastDriver.SurveyDetail.IDcodeLabel.Text);

                FastDriver.SurveyDetail.SurveyChargesTable.VerifyCharges("Survey1", buyerCharge: 11.05, sellerCharge: 12.09, loanEstimate: 11.00);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_BAT0003()
        {
            try
            {
                string FormType = AutoConfig.FormType;

                Reports.TestDescription = "AF2_001: Delete an Escrow File Charge.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with purpose of Sales w/Mortgage";
                CreateFile("SALE");

                Reports.TestStep = "Edit the details for Survey Details.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("HUDFLINSR1");
                FastDriver.SurveyDetail.SurveyChargesTable.EnterCharges("Survey", buyerCharge: 11.05, sellerCharge: 12.09, loanEstimate: 11.0, newDescription: "Survey1");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete Escrow File Charge.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("HUDFLINSR1");
                FastDriver.SurveyDetail.SurveyChargesTable.EnterCharges("Survey1", buyerCharge: 0, sellerCharge: 0, loanEstimate: 0);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete Charge Description Having Charges.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("HUDFLINSR1");
                FastDriver.SurveyDetail.SurveyChargesTable.EnterCharges("Survey1", newDescription: "");

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify and Validate Data entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("HUDFLINSR1");
                Support.AreEqual("HUDFLINSR1", FastDriver.SurveyDetail.IDcodeLabel.Text, "GAB Code");
                FastDriver.SurveyDetail.SurveyChargesTable.VerifyCharges("Survey1");
            
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        
        #region Regression

        [TestMethod]
        public void FMUC0018_REG0001()
        {
            try
            {

                Reports.TestDescription = "FM882_FM981_FM896_EWC1: Assign Escrow Utility Charges";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with purpose of Sales w/Mortgage";
                CreateFile("SALE");
                
                //public static void CreateNewUtilityInstance
                Reports.TestStep = "Create a new Instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: 50, sellerCharge: 50,newDescription: "Utility Charge");
                                              
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Data for a new Instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("Utility Charge", buyerCharge: 50, sellerCharge: 50);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit the Instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges("Utility Charge", buyerCharge: 100, sellerCharge: 100);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "validate the Edited Instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("Utility Charge", buyerCharge: 100, sellerCharge: 100);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete Charge Description.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges("Utility Charge", newDescription: "");

                Reports.TestStep = "Delete Charge Description - Error message";
                string errMsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", errMsg, "Error message");

                Reports.TestStep = "validate the Edited Instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("Utility Charge", buyerCharge: 100, sellerCharge: 100);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0002()
        {
            try
            {
                string FormType = AutoConfig.FormType;

                Reports.TestDescription = "FM2242_FD: Change Transaction type to Loan";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Equity Loan";
                CreateFile("LOAN");

                Reports.TestStep = "Verify Borrower charge is enabled.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyColumn("Borrower Charge");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Order with transaction type as Refinance.";
                CreateFile("REFI", BusSourceGabCode: "248");

                Reports.TestStep = "Verify Borrower charge is enabled.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyColumn("Borrower Charge");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the fields.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (FormType == "CD")
                    Support.AreEqual("False", FastDriver.NewLoan.BorrowerCharge.Enabled.ToString(), "Borrower Charge is disabled");
                else
                {
                    //FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges("Loan Amount", borrowerCharge: 99999999999.99, loanEstimate: 99999999999.99);
                    FastDriver.NewLoan.BorrowerCharge.FASetText("99999999999.99");
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("12345678901.01");
                }

                FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, borrowerCredit: 99999999999.99);

                FastDriver.NewLoan.BorrowerCredit.FASetText("99999999999.99" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(timeout: 3);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the fields.";
                FastDriver.NewLoan.SaveAndReloadLoanChargesScreen();

                if (FormType == "CD")
                    Support.AreEqual("False", FastDriver.NewLoan.BorrowerCharge.Enabled.ToString(), "Borrower Charge is disabled");
                else
                {
                    //FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges("Loan Amount", borrowerCharge: 99999999999.99, loanEstimate: 99999999999.99);
                    FastDriver.NewLoan.BorrowerCharge.FASetText("999999999999.99");
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("123456789012.01");
                }

                FastDriver.NewLoan.BorrowerCredit.FASetText("999999999999.99");
                FastDriver.WebDriver.HandleDialogMessage(timeout: 3);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter invalid data in Home Warranty Detail screen.";
                string errMsg = FastDriver.WebDriver.HandleDialogMessage(timeout: 3);
                Support.AreEqual("Please correct invalid data entered.", errMsg, "Error message");

                Reports.TestStep = "Validate the fields.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();

                if (FormType == "CD")
                    Support.AreEqual("False", FastDriver.NewLoan.BorrowerCharge.Enabled.ToString(), "Borrower Charge is disabled");
                else
                {
                    //FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges("Loan Amount", borrowerCharge: 99999999999.99, loanEstimate: 99999999999.99);
                    FastDriver.NewLoan.BorrowerCharge.FASetText("99999999999.99");
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("12345678901.01");
                }

                FastDriver.NewLoan.BorrowerCredit.FASetText("99999999999.99");
                FastDriver.WebDriver.HandleDialogMessage(timeout: 3);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM883_FM971_FM1617: Enter Adhoc Utility description";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Sale w/Mortgage";
                CreateFile("SALE");

                Reports.TestStep = "Required data for adhoc.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("HUDFLINSR1");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: 10, sellerCharge: 10, newDescription: "abc");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges("abc", addNewRow: true);


                Reports.TestStep = "Validate description and charges.";
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("abc", buyerCharge: 10.00, sellerCharge: 10);
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("abc");

                Reports.TestStep = "Delete Charge Amount.";
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges("abc", sellerCharge: 0);
                
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("abc", sellerCharge: 0);
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0004()
        {
            try
            {
                string FormType = AutoConfig.FormType;

                Reports.TestDescription = "FM970_2_5_2_1: Show Default HUD 1 Line Number";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Sale w/Mortgage";
                CreateFile("SALE");

                Reports.TestStep = "Show Default HUD-1 Line Numbers.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("247");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, newDescription: "Sanity_Utility");

                string expected = FormType == "CD" ? "Section : H" : "HUD1 line Number : 1302";
                Support.AreEqual(expected, FastDriver.UtilityDetail.UtilityChargesTable.FindElement(By.Id("cg_dcs_0_tbc")).FAGetAttribute("title"), "Buyer Charge tooltip");
                Support.AreEqual(expected, FastDriver.UtilityDetail.UtilityChargesTable.FindElement(By.Id("cg_dcs_0_tsc")).FAGetAttribute("title"), "Seller Charge tooltip");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0005()
        {
            try
            {
                string FormType = AutoConfig.FormType;

                Reports.TestDescription = "FM970_2_5_2_2: Show Assigned HUD 1 Line Number";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Sale w/Mortgage";
                CreateFile("SALE");

                //public static void CreateNewUtilityInstance
                Reports.TestStep = "Create a new Instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges("Utilities", buyerCharge: 50, sellerCharge: 50, newDescription: "Utility Charge");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Show Default HUD-1 Line Numbers.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("247");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, newDescription: "Sanity_Utility");

                string expected = FormType == "CD" ? "Section : H" : "HUD1 line Number : 1302";
                Support.AreEqual(expected, FastDriver.UtilityDetail.UtilityChargesTable.FindElement(By.Id("cg_dcs_0_tbc")).FAGetAttribute("title"), "Buyer Charge tooltip");
                Support.AreEqual(expected, FastDriver.UtilityDetail.UtilityChargesTable.FindElement(By.Id("cg_dcs_0_tsc")).FAGetAttribute("title"), "Seller Charge tooltip");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0006()
        {
            try
            {

                Reports.TestDescription = "FM969_FM2623: Manual charges in adhoc";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Sale w/Mortgage";
                CreateFile("SALE");

                Reports.TestStep = "Required data for adhoc.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("256");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, newDescription: "Utilities");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges("FMUC0018_REG0006", buyerCharge: 20, sellerCharge: 30, addNewRow: true);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Manual charges in adhoc.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("Utilities");
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("FMUC0018_REG0006", buyerCharge: 20.00, sellerCharge: 30);

                Reports.TestStep = "Manual charges in adhoc.";
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges("FMUC0018_REG0006", buyerCharge: 0, sellerCharge: 0);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate description and charges.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("FMUC0018_REG0006");

                Reports.TestStep = "Delete charge description.";
                int row = FastDriver.UtilityDetail.UtilityChargesTable.PerformTableAction(1, "FMUC0018_REG0006", 1, TableAction.GetCell).CurrentRow;
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges("FMUC0018_REG0006", newDescription: "");
               
                Reports.TestStep = "Validate adhoc charges.";
                string actual = FastDriver.UtilityDetail.UtilityChargesTable.PerformTableAction(row+1, 1, TableAction.GetText).Message.Replace("\r\n","").Replace("\t", "").Trim();
                Support.AreEqual("", actual, "Verify charge description 'FMUC0018_REG0006' has been deleted");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0007()
        {
            try
            {

                Reports.TestDescription = "FM969_FM2623_FM4221_FD: Charge Field Character Length";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Sale w/Mortgage";
                CreateFile("SALE");

                Reports.TestStep = "Charge Field Character Length.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("Utility");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: 99999999999.99, sellerCharge: 99999999999.99, newDescription: "FMUC0018_REG0007");
                //FastDriver.UtilityDetail.ProrationTable.EnterCharges(1, buyerCharge: 99999999999.99, sellerCharge: 99999999999.99);
                FastDriver.UtilityDetail.ProrationBuyerCredit.FASetText("99999999999.99");
                FastDriver.UtilityDetail.ProrationSellerCredit.FASetText("99999999999.99" + FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Charge Field Character Length.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("FMUC0018_REG0007", buyerCharge: 99999999999.99, sellerCharge: 99999999999.99);

                Reports.TestStep = "Charge Field Character Length.";
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: 99999999999.99, sellerCharge: 99999999999.99, newDescription: "ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Charge Field Character Length.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH", buyerCharge: 99999999999.99, sellerCharge: 99999999999.99);

                Reports.TestStep = "Charge Field Character Length.";
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: 999999999999.99, sellerCharge: 999999999999.99, newDescription: "ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI");
                FastDriver.UtilityDetail.ProrationBuyerCredit.FASetText("999999999999.99");
                FastDriver.UtilityDetail.ProrationSellerCredit.FASetText("999999999999.99" + FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter invalid data in Home Warranty Detail screen.";
                string msg = FastDriver.WebDriver.HandleDialogMessage(timeout: 3);
                Support.AreEqual("Please correct invalid data entered.", msg, "Verify Invalid Data Error Message");

                Reports.TestStep = "Validate Charge Field Character Length.";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Support.AreEqual("?", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue(), "Verify Utility Buyer Charge");
                Support.AreEqual("?", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue(), "Verify Utility Seller Charge");

                Reports.TestStep = "Edit the Instance.";
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: 100.00, sellerCharge: 100.00);
                FastDriver.UtilityDetail.ProrationBuyerCredit.FASetText("99,999,999,999.99");
                FastDriver.UtilityDetail.ProrationSellerCredit.FASetText("99,999,999,999.99" + FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Charge Field Character Length.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", buyerCharge: 100.00, sellerCharge: 100.00);
                Support.AreEqual("99,999,999,999.99", FastDriver.UtilityDetail.ProrationBuyerCredit.FAGetValue(), "Verify Proration Buyer Credit");
                Support.AreEqual("99,999,999,999.99", FastDriver.UtilityDetail.ProrationSellerCredit.FAGetValue(), "Verify Proration Seller Credit");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0008()
        {
            try
            {                
                Reports.TestDescription = "FM879: Enter Multiple charges for utility";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Sale w/Mortgage";
                CreateFile("SALE");

                Reports.TestStep = "Charge Field Character Length.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("Utility");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: 20.00, sellerCharge: 20.00, newDescription: "Utilities");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges("FMUC0018_REG0008", buyerCharge: 30.00, sellerCharge: 30.00, addNewRow: true);
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges("FMUC0018_REG0008_2", buyerCharge: 40.00, sellerCharge: 40.00, addNewRow: true);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Multiple charges.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("Utilities", buyerCharge: 20.00, sellerCharge: 20.00);
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("FMUC0018_REG0008", buyerCharge: 30.00, sellerCharge: 30.00);
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("FMUC0018_REG0008_2", buyerCharge: 40.00, sellerCharge: 40.00);
                                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0009()
        {
            try
            {
                Reports.TestDescription = "FM2718_FM2719_FM2731_EWC3_EWC4: Issued Check > and < Check Amount";
                string FormType = AutoConfig.FormType;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Sale w/Mortgage";
                CreateFile("SALE");

                Reports.TestStep = "Create a new Instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("Utility");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: 500.00, sellerCharge: 500.00, newDescription: "Sanity_Utility");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Buyer/seller charge.";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("Sanity_Utility", buyerCharge: 500.00, sellerCharge: 500.00);

                Reports.TestStep = "Click on pending check and select manual.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "utility name 1 utility name 2", 8, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue Manual Check.";
                string checkNumber = Support.RandomString("NNNNNNNN");
                FastDriver.IssueManualCheck.SwitchToContentFrame();    
                FastDriver.IssueManualCheck.CheckNo.FASetText(checkNumber);
                checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save();

                //public static void PasswordOrOverdraftConfirmationDialog()
                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();
                // END public static void PasswordOrOverdraftConfirmationDialog()

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                //FastDriver.WebDriver.SwitchToWindow("FAST");
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Manual Check/Receipt Reason");
                FastDriver.ManualCheckReceiptReason.SwitchToDialogContentFrame();
                FastDriver.ManualCheckReceiptReason.WaitCreation(FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason);
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Verify the Issued Check amount.";
                FastDriver.WebDriver.SwitchToWindow("FAST");
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                // Below 2 steps seem invalid because the table is readonly.
                //FATAF.General.value = FALibHS.HtmlTableSet("IIS.DisbursementHistory", "DisbursementTable", @"Status^Issued^Tp.^C^Document|85231").ToString();
                //FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Issued", 5, TableAction.SetText, "85231");
                //FATAF.General.value = FALibHS.HtmlTableSet("IIS.DisbursementHistory", "DisbursementTable", @"Amount^1,000.00^Payee|utility name 1 utility name 2 survey str").ToString();
                //FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Amount", 5, TableAction.SetText, "utility name 1 utility name 2 survey str");

                Reports.TestStep = "Verifying for [Manual Check] Confirmation Event in Event Tracking Log.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                Playback.Wait(2000);    // wait for table to populate
                FastDriver.EventTrackingLog.SwitchToContentFrame();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Manual Check]", "Event", TableAction.Click);
                string comment = FastDriver.EventTrackingLog.Comments.Text;
                Support.AreEqual("True", comment.Contains("Disbursing Bank Account:").ToString(), "Verify Comment");

                Reports.TestStep = "Enter GAB code and click on find button.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("248");

                Reports.TestStep = "Change Payee To whom check issued.";
                string errMsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("A check has been issued for this Payee.  The Payee name cannot be changed.", errMsg, "Verify Error message");

                Reports.TestStep = "Enter Less Charge Amount.";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("450.00" + FAKeys.Tab);

                Reports.TestStep = "User tries to decrease or delete a charge amount with payment method of CHK after the payee check is issued.";
                errMsg = FastDriver.WebDriver.HandleDialogMessage();
                string data = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?";
                Support.AreEqual("True", errMsg.Contains(data).ToString(), "Verify error message when entering less amount");

                Reports.TestStep = "Enter Greater Charge Amount.";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText("600.00" + FAKeys.Tab);

                Reports.TestStep = "Enter Greater Than the Issued Amount and click on OK.";
                errMsg = FastDriver.WebDriver.HandleDialogMessage();
                data = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?";
                Support.AreEqual("True", errMsg.Contains(data).ToString(), "Verify error message when entering greater amound");

                Reports.TestStep = "Click on pending check and select manual.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "50.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Enter previously entered check number.";
                FastDriver.IssueManualCheck.SwitchToContentFrame(); 
                FastDriver.IssueManualCheck.CheckNo.FASetText(checkNumber);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate if check number already present.";
                errMsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("True", errMsg.Contains("already exists within this Bank Account and Office. Continue?").ToString(), "Verify Error message");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Overdraft Confirmation");
                FastDriver.ManualCheckReceiptReason.SwitchToDialogContentFrame();
//                FastDriver.ManualCheckReceiptReason.WaitCreation(FastDriver.OverdraftConfirmationDlg.OK);
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.WebDriver.SwitchToWindow("FAST");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Manual Check/Receipt Reason");
                FastDriver.ManualCheckReceiptReason.SwitchToDialogContentFrame();
                FastDriver.ManualCheckReceiptReason.WaitCreation(FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason);
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Verify the Modified check amount.";
                FastDriver.WebDriver.SwitchToWindow("FAST");
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                // Below 2 steps seem invalid because the table is readonly.
                //FATAF.General.value = FALibHS.HtmlTableSet("IIS.DisbursementHistory", "DisbursementTable", @"Status^Issued^Tp.^C^Document|85231").ToString();
                //FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Issued", 5, TableAction.SetText, "85231");
                //FATAF.General.value = FALibHS.HtmlTableSet("IIS.DisbursementHistory", "DisbursementTable", @"Amount^1,000.00^Payee|utility name 1 utility name 2 survey str").ToString();
                //FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Amount", 5, TableAction.SetText, "utility name 1 utility name 2 survey str");

                Reports.TestStep = "Verify for [Duplicate Manual Check] Confirmation Event in Event Track Log.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                FastDriver.EventTrackingLog.SwitchToContentFrame();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Duplicate Manual Check Number]", "Event", TableAction.Click);
                comment = FastDriver.EventTrackingLog.Comments.Text;
                Support.AreEqual("True", comment.Contains(checkNumber).ToString(), "Verify Comment");
                                

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0010()
        {
            try
            {
                // This test also includes REG0011 (from CodedUI)
                string FormType = AutoConfig.FormType;

                Reports.TestDescription = "FM1570: Enter negative number or zero  in Utility Charge Amount" +
                                          "FM2620: Verify the field for charges only";
                //Reports.TestDescription = "FM2620: Verify the field for charges only";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Sale w/Mortgage";
                CreateFile("SALE");

                //public static void CreateNewUtilityInstance
                Reports.TestStep = "Enter negative number or zero in Utility Charge Amount.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("247");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: -9876, sellerCharge: 0, newDescription: "FMUC0018_REG0010");
                
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Handle invalid data error message.";
                string errMsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Please correct invalid data entered.", errMsg, "Verify Invalid data error message");

                Reports.TestStep = "Create a new Instance.";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: 100.00, sellerCharge: 100.00);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0012()
        {
            try
            {
                string FormType = AutoConfig.FormType;

                Reports.TestDescription = "FM896: Update Check Amount";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Sale w/Mortgage";
                CreateFile("SALE");

                Reports.TestStep = "Update Check Amount.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("247");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: 200.00, sellerCharge: 200.00, newDescription: "Sanity_Utility ");

                Reports.TestStep = "Validate Charge amount and Check Amount.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges(1, Description: "Sanity_Utility ", buyerCharge: 200.00, sellerCharge: 200.00);

                Reports.TestStep = "Update Check Amount.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                //FastDriver.UtilityDetail.FindGABcode("247");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges("Sanity_Utility ", buyerCharge: 50.00, sellerCharge: 100.00);

                Reports.TestStep = "Validate Charge amount and Check Amount.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges(1, Description: "Sanity_Utility ", buyerCharge: 50.00, sellerCharge: 100.00);

                Reports.TestStep = "Delete Charge Amount.";
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges("Sanity_Utility ", sellerCharge: 0);

                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Deleted Charge Amount.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.VerifyCharges("Sanity_Utility ", sellerCharge: 0);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0013()
        {
            try
            {
                string FormType = AutoConfig.FormType;

                Reports.TestDescription = "FM1635: Update Entry Recap";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Sale w/Mortgage";
                CreateFile("SALE");

                Reports.TestStep = "Navigate to New Loan screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                
                Reports.TestStep = "Enter charges to New loan.";
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("300000000" + FAKeys.Tab);

                Reports.TestStep = "Verify the IE message and click on OK button.";
                FastDriver.WebDriver.HandleDialogMessage(timeout: 3);

                Reports.TestStep = "Enter GAB code 247";
                FastDriver.NewLoan.FindGABCode("247");

                Reports.TestStep = "Verify data in Recap section.";
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                string actual = FastDriver.NewLoan.RecapTable.Text;
                Support.AreEqual("True", actual.Contains("Check Reduced by Title/Escrow Fees Paid By Mortgage Broker").ToString(), "Table contains 'Check Reduced by Title/Escrow Fees Paid By Mortgage Broker'");

                Reports.TestStep = "Click on loan charges, enter details for buyer credit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercredit.FASetText("5,000.00");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Total charges in recap tab";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                actual = FastDriver.NewLoan.RecapTable.Text;
                Support.AreEqual("True", actual.Contains("Check Reduced by Title/Escrow Fees Paid By Mortgage Broker").ToString(), "Table contains 'Check Reduced by Title/Escrow Fees Paid By Mortgage Broker'");

                Reports.TestStep = "Click on loan charges, edit details for buyer credit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercredit.FASetText("2,500.00");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Total charges in recap tab after edit";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                actual = FastDriver.NewLoan.RecapTable.Text;
                Support.AreEqual("True", actual.Contains("Check Reduced by Title/Escrow Fees Paid By Mortgage Broker").ToString(), "Table contains 'Check Reduced by Title/Escrow Fees Paid By Mortgage Broker'");

                Reports.TestStep = "Click on loan charges, delete buyer credit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(timeout: 3);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercredit.FASetText("");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Total charges in recap tab";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                actual = FastDriver.NewLoan.RecapTable.Text;
                Support.AreEqual("True", actual.Contains("Check Reduced by Title/Escrow Fees Paid By Mortgage Broker").ToString(), "Table contains 'Check Reduced by Title/Escrow Fees Paid By Mortgage Broker'");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0014()
        {
            try
            {
                string FormType = AutoConfig.FormType;

                Reports.TestDescription = "FM1636_FM1637_FM1638_FM1639_PlaceHolder: PlaceHolder_Verify Preview delivery content manually_Update File Balance Summary,Update HUD1 Statement,Update Settlement Statement";
                
                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Sale w/Mortgage";
                CreateFile("SALE");

                //public static void CreateNewUtilityInstance
                Reports.TestStep = "Create a new Instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: 50, sellerCharge: 50, newDescription: "Utility Charge");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating File balance summary after adding buyer/seller charges";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();

                Reports.TestStep = "Perform Print Deliveries.";
                FastDriver.EscrowFileBalanceSummary.Method("Print").Deliver();
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 300);
                
                if (FormType == "CD")
                {
                    Reports.TestStep = "Navigate to Closing Disclosure screen.";
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                    
                    Reports.TestStep = "Navigate to Delivery Options Screen";
                    FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                    FastDriver.ClosingDisclosure.WaitForDeliveryOptionsScreenToLoad();
                    FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                    FastDriver.WebDriver.HandleDialogMessage(timeout: 2);
                    FastDriver.ClosingDisclosure.WaitForDeliveryOptionsScreenToLoad();
                    string todayDate = DateTime.Now.ToString("MM/dd/yyyy");
                    FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText(todayDate);
                    FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText(todayDate);
                    FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(todayDate);

                    Reports.TestStep = "Check Buyer Only";
                    FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                    FastDriver.ClosingDisclosure.BuyerOnlyCR.FASetCheckbox(true);
                    FastDriver.ClosingDisclosure.BuyerOnlySLN.FASetCheckbox(true);

                    Reports.TestStep = "Perform Preview delivery";
                    FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItem("Preview");
                    FastDriver.ClosingDisclosure.DeliveryButton.FAClick();

                    // wait for PDF reader to appear. then, close it
                    //FastDriver.WebDriver.WaitForWindowAndSwitch("URL:Documents/Print", true, 60);
                    FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);
                    FastDriver.WebDriver.ClosePreviewWindow();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                    FastDriver.ClosingDisclosure.SwitchToContentFrame();
                    FastDriver.ClosingDisclosure.ClickCDTab();
                    
                }
                else 
                {
                    Reports.TestStep = "Navigate to Hud screen.";
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>("Home>Order Entry>Escrow Closing>HUD-1 Statement");
                    // TODO: add more steps to complete delivery
                }
                                

                Reports.TestStep = "Navigate to Print Escrow Settlement Statement screen.";
                FastDriver.LeftNavigation.Navigate<PrintEscrowSetlleStmt>("Home>Order Entry>Escrow Closing>Settlement Statement").WaitForScreenToLoad();

                Reports.TestStep = "Perform Print delivery.";
                FastDriver.PrintEscrowSetlleStmt.Method.FASelectItem("Print");
                FastDriver.PrintEscrowSetlleStmt.Deliver.FAClick();
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 300);

                Reports.TestStep = "Edit the Instance.";    // 12.
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: 100, sellerCharge: 100, newDescription: "Utility Charge");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating File balance summary after adding buyer/seller charges";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();

                Reports.TestStep = "Perform Print Deliveries.";
                FastDriver.EscrowFileBalanceSummary.Method("Print").Deliver();
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 300);

                if (FormType == "CD")
                {
                    Reports.TestStep = "Navigate to Closing Disclosure screen.";
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                    Reports.TestStep = "Navigate to Delivery Options Screen";
                    FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                    FastDriver.ClosingDisclosure.WaitForDeliveryOptionsScreenToLoad();
                    FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                    FastDriver.WebDriver.HandleDialogMessage(timeout: 2);
                    FastDriver.ClosingDisclosure.WaitForDeliveryOptionsScreenToLoad();
                    string todayDate = DateTime.Now.ToString("MM/dd/yyyy");
                    FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText(todayDate);
                    FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText(todayDate);
                    FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(todayDate);

                    Reports.TestStep = "Check Buyer Only";
                    FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                    FastDriver.ClosingDisclosure.BuyerOnlyCR.FASetCheckbox(true);
                    FastDriver.ClosingDisclosure.BuyerOnlySLN.FASetCheckbox(true);

                    Reports.TestStep = "Perform Preview delivery";
                    FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItem("Preview");
                    FastDriver.ClosingDisclosure.DeliveryButton.FAClick();

                    // wait for PDF reader to appear. then, close it
                    //FastDriver.WebDriver.WaitForWindowAndSwitch("URL:Documents/Print", true, 60);
                    FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);
                    FastDriver.WebDriver.ClosePreviewWindow();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                    FastDriver.ClosingDisclosure.SwitchToContentFrame();
                    FastDriver.ClosingDisclosure.ClickCDTab();

                }
                else
                {
                    Reports.TestStep = "Navigate to Hud screen.";
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>("Home>Order Entry>Escrow Closing>HUD-1 Statement");
                    // TODO: add more steps to complete delivery
                }

                Reports.TestStep = "Navigate to Print Escrow Settlement Statement screen."; 
                FastDriver.LeftNavigation.Navigate<PrintEscrowSetlleStmt>("Home>Order Entry>Escrow Closing>Settlement Statement").WaitForScreenToLoad();

                Reports.TestStep = "Perform Print delivery.";   // 20.
                FastDriver.PrintEscrowSetlleStmt.Method.FASelectItem("Print");
                FastDriver.PrintEscrowSetlleStmt.Deliver.FAClick();
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 300);

                Reports.TestStep = "Delete the Instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");
                FastDriver.UtilityDetail.UtilityChargesTable.EnterCharges(1, buyerCharge: 0, sellerCharge: 0);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating File balance summary after adding buyer/seller charges";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();

                Reports.TestStep = "Perform Print Deliveries.";
                FastDriver.EscrowFileBalanceSummary.Method("Print").Deliver();
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 300);

                if (FormType == "CD")
                {
                    Reports.TestStep = "Navigate to Closing Disclosure screen.";
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                    Reports.TestStep = "Navigate to Delivery Options Screen";
                    FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                    FastDriver.ClosingDisclosure.WaitForDeliveryOptionsScreenToLoad();
                    FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                    FastDriver.WebDriver.HandleDialogMessage(timeout: 2);
                    FastDriver.ClosingDisclosure.WaitForDeliveryOptionsScreenToLoad();
                    string todayDate = DateTime.Now.ToString("MM/dd/yyyy");
                    FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText(todayDate);
                    FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText(todayDate);
                    FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(todayDate);

                    Reports.TestStep = "Check Buyer Only";
                    FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                    FastDriver.ClosingDisclosure.BuyerOnlyCR.FASetCheckbox(true);
                    FastDriver.ClosingDisclosure.BuyerOnlySLN.FASetCheckbox(true);

                    Reports.TestStep = "Perform Preview delivery";
                    FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItem("Preview");
                    FastDriver.ClosingDisclosure.DeliveryButton.FAClick();

                    // wait for PDF reader to appear. then, close it
                    //FastDriver.WebDriver.WaitForWindowAndSwitch("URL:Documents/Print", true, 60);
                    FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);
                    FastDriver.WebDriver.ClosePreviewWindow();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                    FastDriver.ClosingDisclosure.SwitchToContentFrame();
                    FastDriver.ClosingDisclosure.ClickCDTab();

                }
                else
                {
                    Reports.TestStep = "Navigate to Hud screen.";
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>("Home>Order Entry>Escrow Closing>HUD-1 Statement");
                    // TODO: add more steps to complete delivery
                }

                Reports.TestStep = "Navigate to Print Escrow Settlement Statement screen.";
                FastDriver.LeftNavigation.Navigate<PrintEscrowSetlleStmt>("Home>Order Entry>Escrow Closing>Settlement Statement").WaitForScreenToLoad();

                Reports.TestStep = "Perform Print delivery.";   // 29.
                FastDriver.PrintEscrowSetlleStmt.Method.FASelectItem("Print");
                FastDriver.PrintEscrowSetlleStmt.Deliver.FAClick();
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 300);
                
               
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0014A_PH()
        {
            try
            {
                Reports.TestDescription = "Validate the above delivery method_PlaceHolder";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0015()
        {
            try
            {
                string FormType = AutoConfig.FormType;

                Reports.TestDescription = "FM10925: Enter GFE Amount for GFE Charge";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Sale w/Mortgage";
                CreateFile("SALE");

                Reports.TestStep = "Select HUD and enter charges.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Enter charges to New loan.";
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00" + FAKeys.Tab);

                Reports.TestStep = "Verify the IE message and click on OK button.";
                FastDriver.WebDriver.HandleDialogMessage(timeout: 3);

                Reports.TestStep = "Enter Loan Liability and GAB code";
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("500.00");
                FastDriver.NewLoan.FindGABCode("255");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Loan Charges and Enter details for HUD type=HUD.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                
                // not sure what is the purpose of all these check if exists!
                Support.AreEqual("True", FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, 1, TableAction.GetCell).Element.Exists().ToString(), "Row 1, Description colum");
                Support.AreEqual("True", FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, 3, TableAction.GetCell).Element.Exists().ToString(), "Row 1, Buyer Charge colum");
                Support.AreEqual("True", FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, 4, TableAction.GetCell).Element.Exists().ToString(), "Row 1, Buyer Credit colum");
                Support.AreEqual("True", FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, 5, TableAction.GetCell).Element.Exists().ToString(), "Row 1, Seller Charge colum");
                Support.AreEqual("True", FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, 6, TableAction.GetCell).Element.Exists().ToString(), "Row 1, Seller Credit colum");
                Support.AreEqual("True", FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(8, 1, TableAction.GetCell).Element.Exists().ToString(), "Row 8, Description colum");
                Support.AreEqual("True", FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(8, 3, TableAction.GetCell).Element.Exists().ToString(), "Row 8, Buyer Charge colum");
                
                if (FormType == "CD")
                { // these are the same as above. why check again?
                    Support.AreEqual("True", FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(8, 1, TableAction.GetCell).Element.Exists().ToString(), "Row 8, Description colum");
                    Support.AreEqual("True", FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(8, 3, TableAction.GetCell).Element.Exists().ToString(), "Row 8, Buyer charge colum");
                }
                              
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0016()
        {
            try
            {
                string FormType = AutoConfig.FormType;

                Reports.TestDescription = "FM1618_FM2622: Editable Charge Description";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with transaction type of Sale w/Mortgage";
                CreateFile("SALE");

                Reports.TestStep = "Click on loan charges, enter details for buyer and seller.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();

                if (FormType == "CD")
                {
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercharge.Enabled.ToString(), "Principal Balance Charges Buyer Charge enabled");
                    Support.AreEqual("", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercharge.Text, "Principal Balance Charges Buyer Charge value");
                }
                else
                {
                    FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercharge.FASetText("20.00");
                }

                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesSellercharge.FASetText("20.00");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on loan charges, delete buyer and seller details.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();

                //FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesdescription.FASetText("Charge Description");
                //FastDriver.WebDriver.HandleDialogMessage(timeout: 3);     // not in CodedUI

                if (FormType == "CD")
                {
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercharge.Enabled.ToString(), "Principal Balance Charges Buyer Charge enabled");
                    Support.AreEqual("", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercharge.Text, "Principal Balance Charges Buyer Charge value");
                }
                else
                {
                    FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesdescription.FASetText("Charge Description");
                    FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercharge.FASetText("0.00");
                }

                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesSellercharge.FASetText("0.00");
                
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                if (FormType == "HUD")
                {
                Reports.TestStep = "Click on loan charges, delete charge description.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesdescription.FASetText("" + FAKeys.Tab);

                Reports.TestStep = "Validate when description is removed.";
                string msg = FastDriver.WebDriver.HandleDialogMessage(timeout: 3);
                Support.AreEqual("True", msg.Contains("Unable to delete charge description.  Charge description still has a charge amount").ToString(), "Unable to delete charge message");

                Reports.TestStep = "Click on loan charges, delete charge description.";
                FastDriver.NewLoan.SwitchToContentFrame();
                string chargeDesc = FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesdescription.FAGetValue();
                Support.AreEqual("Charge Description", chargeDesc, "Charge Description");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                }

                Reports.TestStep = "Click on loan charges, enter details for buyer and seller.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("25.00");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on loan charges, enter details for buyer and seller.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();

                if (FormType == "CD")
                    Support.AreEqual("Prepaid Interest", FastDriver.NewLoan.LoanChargesInterestCalculationDescription.FAGetAttribute("Value"), "Interest Calculation Description");
                else
                    Support.AreEqual("Interest on new loan", FastDriver.NewLoan.LoanChargesInterestCalculationDescription.FAGetValue(), "Interest Calculation Description");

                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

             }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0018_REG0017_PH()
        {
            try
            {
                Reports.TestDescription = "UncoveredBRS_PlaceHolder: FM1638,FM1639,ES10846,ES10847";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        
        #region private methods

        private static void CreateFile(string TransactionType = "REFI", string BusinessSegment = "RESIDENTAL", string BusSourceGabCode = "HUDFLINSR1", string DirectebyIDCode = "HUDLEASE03",
            string NewLoanIDCode = "247", string AssBusPartyIDCode = "HUDASLNDR1")
        {
            CreateFileRequest fileRequest = new CreateFileRequest();
            fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            //fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(BusSourceGabCode);   // HUDFLINSR1
            //fileRequest.File.BusinessParties[0].AdditionalRole = new AdditionalRoleList() { eAddtionalRole = AdditionalRoleType.NewLender };
            //fileRequest.File.BusinessParties[0].CustomerReferenceNumber = "1234567890";
            fileRequest.File.BusinessParties = new FileBusinessParty[]
            {
                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(BusSourceGabCode),   // HUDFLINSR1
                    RoleTypeObjectCD = "BUSSOURCE",
                    CustomerReferenceNumber = "1234567890",
                    AdditionalRole = new AdditionalRoleList() { eAddtionalRole = AdditionalRoleType.NewLender }
                },

                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(DirectebyIDCode),   // HUDLEASE03
                    RoleTypeObjectCD = "DirectedBy"
                },

                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(AssBusPartyIDCode), // HUDASLNDR1
                    RoleTypeObjectCD = "ASSOTDPTY"
                }
            };
            
            fileRequest.File.BusinessSegmentObjectCD = BusinessSegment; // RESIDENTIAL
            fileRequest.File.TransactionTypeObjectCD = TransactionType; // REFI           
            fileRequest.File.NewLoan.FileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId(NewLoanIDCode);  // 247
            
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
            
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
