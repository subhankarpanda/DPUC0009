﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using AutoIt;


namespace EscrowChargeGenericComp
{
    /// <summary>
    /// Calculate Loan Interest - FMUC0021
    /// </summary>
    [CodedUITest]
    public class FMUC0021_Calculate_Loan_Interest : MasterTestClass
    {
        public FMUC0021_Calculate_Loan_Interest() {}

        private FormType CurrentFileType;
        private String InterestCalculationDescription;
        
        #region BAT

        [TestMethod]
        [Description("Calculate Loan Interest.")]
        public void FMUC0021_BAT0001()
        {

            try
            {
                Reports.TestDescription = "MF_001: Calculate Loan Interest.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                    {
                        Type = "Small Loan",
                        Amount = "200000",
                        GABCode = "247"
                    }
                );
                
                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                SetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable,InterestCalculationDescription,"#");
                
                #endregion

                #region Open PDD and Set values
                Reports.TestStep = "Open PDD and Set values";

                FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                if (IsFormTypeCD())
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("0");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("5,000.00");
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                }
                else {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys("POC");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Validate File balance summary for interest calculation.
                Reports.TestStep = "Validate File balance summary for interest calculation.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");

                Support.AreEqual("200,000.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.Text);
                Support.AreEqual("200,000.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text);
                Support.AreEqual("199,000.00", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1,"Buyer",7,TableAction.GetText).Message);
                Support.AreEqual("1,000.00", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1, "Seller", 7, TableAction.GetText).Message);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Recalculate Loan Interest")]
        public void FMUC0021_BAT0002()
        {

            try
            {
                Reports.TestDescription = "AF_001: Recalculate Loan Interest.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                SetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "#");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Validate File balance summary for interest calculation.
                Reports.TestStep = "Validate File balance summary for interest calculation.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");

                Support.AreEqual("195,000.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.Text);
                Support.AreEqual("195,000.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text);
                Support.AreEqual("194,000.00", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1, "Buyer", 7, TableAction.GetText).Message);
                Support.AreEqual("1,000.00", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1, "Seller", 7, TableAction.GetText).Message);
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to New Loan and Recalculate Loan Interest.
                Reports.TestStep = "Navigate to New Loan and Recalculate Loan Interest.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                if (!FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected) {
                    FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAClick();
                }
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Validate the interest calculated charge after recalculation.
                Reports.TestStep = "Validate the interest calculated charge after recalculation.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual("6,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                #endregion

                #region Validate File balance summary after recalculate interest.
                Reports.TestStep = "Validate File balance summary after recalculate interest.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");

                Support.AreEqual("194,000.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.Text);
                Support.AreEqual("194,000.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text);
                Support.AreEqual("193,000.00", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1, "Buyer", 7, TableAction.GetText).Message);
                Support.AreEqual("1,000.00", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1, "Seller", 7, TableAction.GetText).Message);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Overtype Exist Loan Interest Charge.")]
        public void FMUC0021_BAT0003()
        {

            try
            {
                Reports.TestDescription = "AF_002: Overtype Exist Loan Interest Charge.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                SetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription,"7,000.00");
                SetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "#");
                Support.AreEqual("7,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));

                #endregion

                #region Validate File balance summary for interest calculation.
                Reports.TestStep = "Validate File balance summary for interest calculation.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");

                Support.AreEqual("193,000.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.Text);
                Support.AreEqual("193,000.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text);
                Support.AreEqual("192,000.00", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1, "Buyer", 7, TableAction.GetText).Message);
                Support.AreEqual("1,000.00", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1, "Seller", 7, TableAction.GetText).Message);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Enter Loan Interest Charge Directly.")]
        public void FMUC0021_BAT0004()
        {

            try
            {
                Reports.TestDescription = "AF_003: Enter Loan Interest Charge Directly.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values Directly
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values Directly";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                SetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "8,000.00");
                #endregion

                #region Validate File balance summary for interest calculation.
                Reports.TestStep = "Validate File balance summary for interest calculation.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");

                Support.AreEqual("192,000.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.Text);
                Support.AreEqual("192,000.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text);
                Support.AreEqual("191,000.00", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1, "Buyer", 7, TableAction.GetText).Message);
                Support.AreEqual("1,000.00", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1, "Seller", 7, TableAction.GetText).Message);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region REGRESSION

        [TestMethod]
        [Description("Recalculate Loan Interest.")]
        public void FMUC0021_REG0001()
        {

            try
            {
                Reports.TestDescription = "ER_001: Recalculate Loan Interest.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                SetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "#");

                #endregion

                #region Recalculate Loan Interest.
                Reports.TestStep = "Recalculate Loan Interest.";
                if (!FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAClick();
                }
                string DialogMessage = FastDriver.WebDriver.HandleDialogMessage();
                #endregion 

                #region Interest recalculation.
                Reports.TestStep = "Interest recalculation.";
                Support.AreEqual(true.ToString(), DialogMessage.Contains("Interest calculation formula values have changed.").ToString());
                Support.AreEqual(true.ToString(), DialogMessage.Contains("Do you wish to recalculate interest charges?").ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Calculate Loan Interest.")]
        public void FMUC0021_REG0002()
        {

            try
            {
                Reports.TestDescription = "BR_FMUC0021: Calculate Loan Interest.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                SetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "#");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Use Per Diem Amount or Percentage Rate.")]
        public void FMUC0021_REG0003()
        {

            try
            {
                Reports.TestDescription = "BR_FM1015: Use Per Diem Amount or Percentage Rate.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Loan Amount Required.")]
        public void FMUC0021_REG0004()
        {

            try
            {
                Reports.TestDescription = "BR_FM3153: Loan Amount Required.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Calculate Percent Interest.")]
        public void FMUC0021_REG0005()
        {

            try
            {
                Reports.TestDescription = "BR_FM3056: Calculate Percent Interest.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                if (!FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.Selected)
                    FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.FAClick();
                FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FASetText("20");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("555.56", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Calculate Per Diem Interest.")]
        public void FMUC0021_REG0006()
        {

            try
            {
                Reports.TestDescription = "BR_FM3057 : Calculate Per Diem Interest.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        [Description("Enter Fixed Amount Interest.")]
        public void FMUC0021_REG0007()
        {

            try
            {
                Reports.TestDescription = "BR_FM1048: Enter Fixed Amount Interest.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                SetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription,"10,000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Enter From Date and To Date.")]
        public void FMUC0021_REG0008()
        {

            try
            {
                Reports.TestDescription = "BR_FM3058: Enter From Date and To Date.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Mark From Date or To Date as Inclusive.")]
        public void FMUC0021_REG0009()
        {

            try
            {
                Reports.TestDescription = "BR_ES10070: Mark From Date or To Date as Inclusive.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                if (!FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAClick();
                }
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Calculate Interest as Charge or Credit.")]
        public void FMUC0021_REG0010()
        {

            try
            {
                Reports.TestDescription = "BR_ES10071A: Calculate Interest as Charge or Credit.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("5,000.00", GetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Calculate Interest as Charge or Credit.")]
        public void FMUC0021_REG0011()
        {

            try
            {
                Reports.TestDescription = "BR_ES10071B: Calculate Interest as Charge or Credit.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Overtype Calculated Interest.")]
        public void FMUC0021_REG0012()
        {

            try
            {
                Reports.TestDescription = "BR_FM1049: Overtype Calculated Interest.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

                #region Click on Loan Charges Tab and change Buyer charge Amount
                Reports.TestStep = "Click on Loan Charges Tab and change Buyer charge Amount";

                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();


                SetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription,"10,000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        [Description("Select Interest Type.")]
        public void FMUC0021_REG0013()
        {

            try
            {
                Reports.TestDescription = "BR_FM1011: Select Interest Type.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Prompt to Recalculate Interest.")]
        public void FMUC0021_REG0014()
        {

            try
            {
                Reports.TestDescription = "BR_FM1894: Prompt to Recalculate Interest.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

                #region Click on Loan Charges Tab and Recalculate Loan Interest
                Reports.TestStep = "Click on Loan Charges Tab and Recalculate Loan Interest.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                if (!FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected) {
                    FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAClick();
                }
                #endregion

                #region Interest recalculation message dialog.
                Reports.TestStep = "Interest recalculation message dialog.";
                string DialogMessage = FastDriver.WebDriver.HandleDialogMessage();

                Support.AreEqual(true.ToString(), DialogMessage.Contains("Interest calculation formula values have changed.").ToString());
                Support.AreEqual(true.ToString(), DialogMessage.Contains("Do you wish to recalculate interest charges?").ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Interest Payment Details.")]
        public void FMUC0021_REG0015()
        {

            try
            {
                Reports.TestDescription = "BR_FM2714_FD_pencilicon: Interest Payment Details.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

                #region Click on Loan Charges Tab and Recalculate Loan Interest
                Reports.TestStep = "Click on Loan Charges Tab and Recalculate Loan Interest.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                if (!FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAClick();
                }
                #endregion

                #region Interest recalculation message dialog.
                Reports.TestStep = "Interest recalculation message dialog.";
                string DialogMessage = FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

                #region Click on Loan Charges Tab and Open PDD
                Reports.TestStep = " Click on Loan Charges Tab and Open PDD.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                              
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                #endregion

                #region Enter payment details for New loan
                Reports.TestStep = "Enter payment details for New loan.";
                if (IsFormTypeCD())
                {
                    FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItemBySendingKeys("POC");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys("POC");
                    FastDriver.PaymentDetailsDlg.PayTo.FASetText("TEST PAYEE");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region To verify the pencil icon.
                Reports.TestStep = "To verify the pencil icon.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Support.AreEqual(true.ToString(), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPenImage.Displayed.ToString());

                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Field validation Interest Type.")]
        public void FMUC0021_REG0016()
        {

            try
            {
                Reports.TestDescription = "FD_InterestType: Field validation Interest Type.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

                #region Click on Loan Charges Tab and Recalculate Loan Interest
                Reports.TestStep = "Click on Loan Charges Tab and Recalculate Loan Interest.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                if (!FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAClick();
                }
                #endregion

                #region Interest recalculation message dialog.
                Reports.TestStep = "Interest recalculation message dialog.";
                string DialogMessage = FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

                #region Click on Loan Charges Tab and Open PDD
                Reports.TestStep = " Click on Loan Charges Tab and Open PDD.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                #endregion

                #region Enter payment details for New loan
                Reports.TestStep = "Enter payment details for New loan.";
                if (IsFormTypeCD())
                {
                    FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItemBySendingKeys("POC");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys("POC");
                    FastDriver.PaymentDetailsDlg.PayTo.FASetText("TEST PAYEE");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

                #region Click on Loan Charges tab and verify the contents of interest type.
                Reports.TestStep = "Click on Loan Charges tab and verify the contents of interest type.";

                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                string InterestTypeContent = FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.Text;
                Support.AreEqual(true.ToString(), InterestTypeContent.Contains("Adjustable Interest Rate").ToString());
                Support.AreEqual(true.ToString(), InterestTypeContent.Contains("Best Prevailing").ToString());
                Support.AreEqual(true.ToString(), InterestTypeContent.Contains("Fixed Rate").ToString());
                Support.AreEqual(true.ToString(), InterestTypeContent.Contains("Interest in Addition").ToString());
                Support.AreEqual(true.ToString(), InterestTypeContent.Contains("Interest Included").ToString());
                Support.AreEqual(true.ToString(), InterestTypeContent.Contains("Variable Interest Rate").ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Field validation PerDiemAmount.")]
        public void FMUC0021_REG0017()
        {

            try
            {
                Reports.TestDescription = "FD_PerDiemAmount: Field validation PerDiemAmount.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

                #region Click on Loan Charges Tab and Recalculate Loan Interest
                Reports.TestStep = "Click on Loan Charges Tab and Recalculate Loan Interest.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                if (!FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAClick();
                }
                #endregion

                #region Interest recalculation message dialog.
                Reports.TestStep = "Interest recalculation message dialog.";
                string DialogMessage = FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

                #region Click on Loan Charges Tab and Open PDD
                Reports.TestStep = " Click on Loan Charges Tab and Open PDD.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                #endregion

                #region Enter payment details for New loan
                Reports.TestStep = "Enter payment details for New loan.";
                if (IsFormTypeCD())
                {
                    FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItemBySendingKeys("POC");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys("POC");
                    FastDriver.PaymentDetailsDlg.PayTo.FASetText("TEST PAYEE");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                              
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

                #region Click on Loan Charges tab and verify Field validation.

                Reports.TestStep = "Click on Loan Charges tab and verify Field validation";

                SetPerDiemAmountCalculationAndVerify(TestStep: "Field validation of Per Diem Amount-Exact range.", SetAmount: "12345678912.1234", ExpectedAmount: "12,345,678,912.123400");

                SetPerDiemAmountCalculationAndVerify(TestStep: "Field validation of Per Diem Amount-high range.", SetAmount: "123456789123.123", ExpectedAmount: "?");

                SetPerDiemAmountCalculationAndVerify(TestStep: "To clear the perdiem amount.", SetAmount: "", ExpectedAmount: null);

                SetPerDiemAmountCalculationAndVerify(TestStep: "Field validation of Per Diem Amount-decimalLowrange.", SetAmount: "12345678912.1234", ExpectedAmount: "12,345,678,912.123400");
                                                
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Field validation for Percent Interest.")]
        public void FMUC0021_REG0018()
        {

            try
            {
                Reports.TestDescription = "FD_Percentagerate: field validation for Percent Interest.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge
                Reports.TestStep = "Click on Loan Charges Tab, set Interest Calculation Values and verify Buyer charge";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.000000");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemBySendingKeys("360");
                if (!FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.Selected)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.FAClick();
                }
                FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FASetText("1.1234");
                Support.AreEqual(@"1.1234", FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FAGetValue());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion
              
                #region Click on Loan Charges tab and verify Field validation.

                Reports.TestStep = "Click on Loan Charges tab and verify Field validation";

                SetPercentageCalculationAndVerify(TestStep: "Field validation for percent rate-high range.", SetPercentageRate: "123.123", ExpectedAmount: "?");

                SetPercentageCalculationAndVerify(TestStep: "For clearing the percent rate.", SetPercentageRate: "", ExpectedAmount: null);

                SetPercentageCalculationAndVerify(TestStep: "Field validation for percent rate- decimal low range.", SetPercentageRate: "12.123", ExpectedAmount: "12.1230");

                SetPercentageCalculationAndVerify(TestStep: "Field validation for percent rate- decimal high range", SetPercentageRate: "1.12345", ExpectedAmount: "1.1234");

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Field validation for From Date, To Date.")]
        public void FMUC0021_REG0019()
        {

            try
            {
                Reports.TestDescription = "FD_FromandToDate: field validation for From Date, To Date.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and Verify

                FastDriver.NewLoan.SwitchToContentFrame();
     
                SetFromDateCalculationAndVerify(TestStep: "Validate the field From Date with less than 10.", SetFromDate: "123", ExpectedDate: "??-??-????");
                SetFromDateCalculationAndVerify(TestStep: "Validate the field From Date with characters.", SetFromDate: "abcdefghijk", ExpectedDate: "");
                SetFromDateCalculationAndVerify(TestStep: "Clear the From Date.", SetFromDate: "", ExpectedDate: null);

                SetToDateCalculationAndVerify(TestStep: "Validate the field From Date with less than 10.", SetToDate: "123", ExpectedDate: "??-??-????");
                SetToDateCalculationAndVerify(TestStep: "Validate the field From Date with characters.", SetToDate: "abcdefghijk", ExpectedDate: "");
                SetToDateCalculationAndVerify(TestStep: "Clear the From Date.", SetToDate: "", ExpectedDate: null);
                                       
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Field validation for From and To Inclusive check boxes.")]
        public void FMUC0021_REG0020()
        {

            try
            {
                Reports.TestDescription = "FD_FromandToInclusive: field validation for From and To Inclusive check boxes.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and Verify

                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "Click on Loan Charges Tab and Recalculate Loan Interest.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                if (!FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.Selected)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.FAClick();
                }

                if (!FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAClick();
                }

                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();


                Reports.TestStep = "To verify the From and To inclusive check boxes.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual(true.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected.ToString());

                if (FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.Selected)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.FAClick();
                }

                if (FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAClick();
                }

                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();

                Reports.TestStep = "To verify the From and To inclusive check boxes.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual(false.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.Selected.ToString());
                Support.AreEqual(false.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected.ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Field validation for Based on Days.")]
        public void FMUC0021_REG0021()
        {

            try
            {
                Reports.TestDescription = "FD_Basedondays: field validation for Based on Days.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Interest Calculation Values and Verify

                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "To verify the From and To inclusive check boxes.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual(false.ToString(), String.IsNullOrEmpty(FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.Text).ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Field validation for Buyer charge.")]
        public void FMUC0021_REG0022()
        {

            try
            {
                Reports.TestDescription = "FD_Buyercharge: field validation for Buyer charge.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Buyer Charge Values and Verify

                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "To verify the lower limit for Buyer charge.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                SetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "1234567891.12");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("1,234,567,891.12",GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));

                Reports.TestStep = "To verify the lower decimal limit for Buyer charge.";
                SetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "12345678912.1");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("12,345,678,912.10", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));

                Reports.TestStep = "To verify the exact limit for Buyer charge.";
                ClearBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription);
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
                SetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "12345678912.12");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("12,345,678,912.12", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));

                Reports.TestStep = "To verify the higher limit for Buyer charge.";
                ClearBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription);
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);

                SetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "123456789123.1");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("?", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, InterestCalculationDescription, 3, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).GetAttribute("value"));

                Reports.TestStep = "To clear the field Buyer charge, Buyer credit.";
                ClearBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription);
                ClearBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription);
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);

                Reports.TestStep = "To verify the higher decimal limit for Buyer charge.";
                SetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "1234567891.123");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("1,234,567,891.12", GetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));

                Reports.TestStep = "To clear the field Buyer charge, Buyer credit.";
                SetBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "");
                SetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Field validation for Buyer credit.")]
        public void FMUC0021_REG0023()
        {

            try
            {
                Reports.TestDescription = "FD_Buyercredit: field validation for Buyer credit.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Click on Loan Charges Tab, set Buyer Credit  Values and Verify

                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "To verify the lower limit for Buyer credit.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                SetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "1234567891.12");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("1,234,567,891.12", GetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));

                Reports.TestStep = "To verify the lower decimal limit for Buyer credit.";
                SetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "12345678912.1");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("12,345,678,912.10", GetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));

                Reports.TestStep = "To verify the exact limit for Buyer credit.";
                ClearBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription);
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
                SetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "12345678912.12");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("12,345,678,912.12", GetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));

                Reports.TestStep = "To verify the higher limit for Buyer credit.";
                ClearBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription);
                SetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "123456789123.1");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("?", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, InterestCalculationDescription, 4, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).GetAttribute("value"));

                Reports.TestStep = "To clear the field Buyer charge, Buyer credit.";
                ClearBuyerCharge(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription);
                ClearBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription);
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);

                Reports.TestStep = "To verify the higher decimal limit for Buyer credit.";
                SetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription, "1234567891.123");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("1,234,567,891.12", GetBuyerCredit(FastDriver.NewLoan.InterestCalculationTable, InterestCalculationDescription));
                               
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        [Description("Field validation for Seller charge and Seller credit.")]
        public void FMUC0021_REG0024()
        {

            try
            {
                Reports.TestDescription = "FD_Sellerchgsellercrdt: field validation for Seller charge and Seller credit.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FillNewLoanForm(new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "200000",
                    GABCode = "247"
                }
                );

                #endregion

                #region Navigate to Loan Charges Tab and verify the Seller charge and seller credit field.

                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "Navigate to Loan Charges Tab and verify the Seller charge and seller credit field.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                               
                Support.AreEqual(IsFormTypeCD().ToString(), FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, InterestCalculationDescription, 5, TableAction.GetCell).Element.FindElement(By.CssSelector("input[type=\"text\"]")).Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, InterestCalculationDescription, 6, TableAction.GetCell).Element.FindElement(By.CssSelector("input[type=\"text\"]")).Enabled.ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        
        #region PRIVATE METHODS

        private  void _CreateFile(){
           
            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
            CurrentFileType = customizableFileRequest.formType;
            InterestCalculationDescription = CurrentFileType == FormType.CD ? "Prepaid Interest" : "Interest on new loan";
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.SalesPriceAmount = 1000;
            customizableFileRequest.File.LiabilityAmount = 1000;
            
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

        }

        private void _IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private string GetBuyerCharge(IWebElement TableCharges, string DescriptionRow)
        {
            return TableCharges.PerformTableAction(1, DescriptionRow, 3, TableAction.GetAttribute, "value").Message;
        }

        private void SetBuyerCharge(IWebElement TableCharges, string DescriptionRow, string BuyerCreditValue)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 3, TableAction.SetText, BuyerCreditValue);
        }

        private void ClearBuyerCharge(IWebElement TableCharges, string DescriptionRow)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 3, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).Clear();
        }
       
        private string GetBuyerCredit(IWebElement TableCharges, string DescriptionRow)
        {
            return TableCharges.PerformTableAction(1, DescriptionRow, 4, TableAction.GetAttribute, "value").Message;
        }

        private void SetBuyerCredit(IWebElement TableCharges, string DescriptionRow, string BuyerCreditValue)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 4, TableAction.SetText, BuyerCreditValue);
        }
        
        private void ClearBuyerCredit(IWebElement TableCharges, string DescriptionRow)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 4, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).Clear();
        }
            
        private bool IsFormTypeCD()
        {
            return CurrentFileType == FormType.CD;
        }

        private void SetPerDiemAmountCalculationAndVerify(string TestStep, string SetAmount, string ExpectedAmount)
        {

            Reports.TestStep = TestStep;
            FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
            FastDriver.NewLoan.LoanChargesTab.FAClick();
            FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

            FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText(SetAmount);
            FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.NewLoan.SwitchToContentFrame();
            if (ExpectedAmount != null) {
                Support.AreEqual(ExpectedAmount, FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue());
            }
           
            FastDriver.NewLoan.SwitchToContentFrame();
            FastDriver.BottomFrame.Done();
            if (ExpectedAmount == "?")
            {//if ? after clicking done a message appear and we need to handle it
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1,000.00");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
               
            }
        }

        private void SetPercentageCalculationAndVerify(string TestStep, string SetPercentageRate, string ExpectedAmount)
        {

            Reports.TestStep = TestStep;
            FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
            FastDriver.NewLoan.LoanChargesTab.FAClick();
            FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
            if (!FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.Selected)
            {
                FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.FAClick();
            }
            FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FASetText(SetPercentageRate);
            FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.SendKeys(FAKeys.Tab);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.NewLoan.SwitchToContentFrame();
            if (ExpectedAmount != null)
            {
                Support.AreEqual(ExpectedAmount, FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FAGetValue());
            }

            FastDriver.NewLoan.SwitchToContentFrame();
            FastDriver.BottomFrame.Done();
            if (ExpectedAmount == "?")
            {//if ? after clicking done a message appear and we need to handle it
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FASetText("1.00");
                FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

            }
        }

        private void SetFromDateCalculationAndVerify(string TestStep, string SetFromDate, string ExpectedDate)
        {

            Reports.TestStep = TestStep;
            FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
            FastDriver.NewLoan.LoanChargesTab.FAClick();
            FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

            FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText(SetFromDate);
            FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.SendKeys(FAKeys.Tab);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.NewLoan.SwitchToContentFrame();
            if (ExpectedDate != null)
            {
                Support.AreEqual(ExpectedDate, FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue());
            }

            FastDriver.NewLoan.SwitchToContentFrame();
            FastDriver.BottomFrame.Done();
            if (ExpectedDate == "??-??-????")
            {//if ? after clicking done a message appear and we need to handle it
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("07-20-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

            }
        }

        private void SetToDateCalculationAndVerify(string TestStep, string SetToDate, string ExpectedDate)
        {

            Reports.TestStep = TestStep;
            FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
            FastDriver.NewLoan.LoanChargesTab.FAClick();
            FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

            FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText(SetToDate);
            FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.NewLoan.SwitchToContentFrame();
            if (ExpectedDate != null)
            {
                Support.AreEqual(ExpectedDate, FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue());
            }

            FastDriver.NewLoan.SwitchToContentFrame();
            FastDriver.BottomFrame.Done();
            if (ExpectedDate == "??-??-????")
            {//if ? after clicking done a message appear and we need to handle it
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("07-25-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

            }
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
