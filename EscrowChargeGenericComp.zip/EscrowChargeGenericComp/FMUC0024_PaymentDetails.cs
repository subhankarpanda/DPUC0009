﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTWCFHelpers.FastFileService;
using System.Threading;

namespace EscrowChargeGenericComp
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest]
    public class FMUC0024_PaymentDetails : MasterTestClass
    {
        public FMUC0024_PaymentDetails()
        {
        }

        #region - BAT
        [TestMethod]
        public void FMUC0024_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Change the payment details.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.SurveyDetail.SurveyChargesTable, "Survey", buyerCharge: 2.00, sellerCharge: 3.00, loanEstimate: 1.50);
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails("FMUC0024 - Survey", "2.50", "2.60");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2.50");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2.60");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.SurveyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Validate the payment details entered.";
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("FMUC0024 - Survey", FastDriver.PaymentDetailsDlg.Description.FAGetValue());
                Support.AreEqual("$2.50", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue());
                Support.AreEqual("$2.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                Support.AreEqual("$2.60", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue());
                Support.AreEqual("$2.60", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1_01: Cancel the payment details.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.SurveyDetail.SurveyChargesTable, "Survey", buyerCharge: 2.50, sellerCharge: 2.60, loanEstimate: 1.50);

                Reports.TestStep = "Click on Payment Details.";
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails("FMUC0024 - Survey-Edited", "2.00", "3.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("3.00");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.SurveyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Validate the payment details entered.";
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("Survey", FastDriver.PaymentDetailsDlg.Description.FAGetValue());
                Support.AreEqual("$2.50", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue());
                Support.AreEqual("$2.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                Support.AreEqual("$2.60", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue());
                Support.AreEqual("$2.60", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF1_01: Cancel the payment details.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.SurveyDetail.SurveyChargesTable, "Survey", buyerCharge: 2.50, sellerCharge: 2.60, loanEstimate: 1.50);
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                
                Reports.TestStep = "Enter payment details for New loan.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("5,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("5,000.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region - REGRESSION
        [TestMethod]
        public void FMUC0024_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM1186_FM927_FM1043_FM1042_FM938_FM935_FM2511_ES12614_ES12615_FM1196: Change the Payment Details and verify it in the main screen.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                
                Reports.TestStep = "Enter values in Loan Charges screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.PrincipalBalanceChargesTable, "Loan Amount", buyerCredit: 2.00, sellerCharge: 30.00);
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("RBL", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem());
                Support.AreEqual("RBL", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem());
                Support.AreEqual("$2.00", FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue());
                Support.AreEqual("Lender", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FAGetSelectedItem());
                Support.AreEqual("$30.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue());
                FastDriver.PaymentDetailsDlg.Description.FASetText("FMUC0024 - NewLoan1");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("2.50");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("Lender");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.60");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("2.60");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual("FMUC0024 - NewLoan1", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesdescription.FAGetValue());
                Support.AreEqual("2.50", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercredit.FAGetValue());
                Support.AreEqual("2.60", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesSellercharge.FAGetValue());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0001A()
        {
            try
            {
                Reports.TestDescription = "FM1186 : Show Pmt Details on Payee Chgs.";
                Login(AutoConfig.FASTHomeURL);;
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter values in Loan Charges screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.PrincipalBalanceChargesTable, "Loan Amount", buyerCredit: 2.00, sellerCharge: 30.00);

                Reports.TestStep = "Verify that system displays New load Impound Payment detail dialog.";
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.Enabled.ToString());


            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM3198: Verify the Payment details when Description in the charge line is empty.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //

                Reports.TestStep = "Verify the Buyer charge is disabled when description is empty.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge2.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.OutsideEscrowCompanyDetail.SellerCharge2.IsEnabled().ToString());

            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0003()
        {
            try
            {
                Reports.TestDescription = "ES12616_ES12617_FM1037_FM936_FM1038_FM1041_FM1658_FM1197_FM1901_FM4210_EWC1: Change the Pay To Value and change the Business party.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Survey screen.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.SurveyDetail.SurveyChargesTable, " ");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Verify the payment methods and GFE for survey screen.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("Survey", FastDriver.PaymentDetailsDlg.Description.FAGetValue());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem());
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Create a survey with charges.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.SurveyDetail.SurveyChargesTable, "Survey", newDescription: "FMUC0024-Survey", buyerCharge: 20.00, sellerCharge: 30.00);
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("FMUC0024-Survey", FastDriver.PaymentDetailsDlg.Description.FAGetValue());
                Support.AreEqual("$20.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue());
                Support.AreEqual("$20.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue());
                Support.AreEqual("$30.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue());
                Support.AreEqual("$30.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                
                Reports.TestStep = "Verify the check amount";
                Support.AreEqual("Check Amount: $ 50.00", FastDriver.SurveyDetail.CheckAmount.Text.Clean());
                
                Reports.TestStep = "Change the Business party & verify the Pay To value when the Business Party is changed.";
                FastDriver.SurveyDetail.FindGABCode("249");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("David W. Silver & Associates", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue());
                
                Reports.TestStep = "Enter payment details for New loan.";
                FastDriver.PaymentDetailsDlg.Description.FAClick();
                FastDriver.PaymentDetailsDlg.Description.FASetText(" ");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false));

            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0004()
        {
            try
            {
                Reports.TestDescription = "ES7508_ES10870_ES10874_ES10875_ES10882: Verify GFE Values for charges and fees for OTC.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                
                Reports.TestStep = "Modify first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "New Home Rate (Title Only)", buyerCharge: 5.99);
                FastDriver.FileFees.FeeDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0005()
        {
            try
            {
                Reports.TestDescription = "ES12606_ES12607_ES12608_ES12609_ES12610_ES12611_EWC3_EWC2: Verify for Charges that are partially paid or pre-paid outside the close.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                //FastDriver.NewLoan.LoanChargesGFE_7FutureRecordingFeescollectedbyLender_MB_PaymentDetails

            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0006()
        {
            try
            {
                #region Precondition

                var busOrg = new BusinessOrganizationParameters()
                {
                    EntityType = "Lender",
                    IDCode = Support.RandomString("AAAAZZ"),
                    Name1 = "FMUC0024 Test Name 1",
                    Name2 = "FMUC0024 Test Name 2",
                };

                Reports.TestDescription = "Add mortgage product to GAB ID and ES10876: Verify the LSP for 2nd+ instance of New loan.";
                Login(AutoConfig.FASTAdmURL);

                //

                Reports.TestStep = "Selecting Region to have Region-level access";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(FASTWCFHelpers.ClosingDisclosureSupport.IMDRegionBUID);

                //

                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.New.FAClick();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Create a new Bus Party of type OTC with License details.";
                FastDriver.BusPartyOrgSetUp.FillNewBusinessOrganizationForm(busOrg);
                FastDriver.BottomFrame.Done();
                FastDriver.AddressBookSearch.WaitForScreenToLoad();
                FastDriver.AddressBookSearch.SearchAddressBook(busOrg.IDCode);
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();

                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(2, 1, TableAction.DoubleClick);
                

                Reports.TestStep = "Click on Mortgage Product Add Remove button.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.MortgageProductsAddRemove.FAClick();
                FastDriver.MortgageProductsDlg.WaitForScreenToLoad();
                FastDriver.MortgageProductsDlg.New.FAClick();
                FastDriver.MortgageProductsDlg.WaitCreation(FastDriver.MortgageProductsDlg.MortgageProduct1);
                FastDriver.MortgageProductsDlg.MortgageProduct1.FASelectItem("50 - i Declare - Regular");
                FastDriver.MortgageProductsDlg.LoanType1.FASelectItem("Cal Vet");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();
                #endregion
                
                Reports.TestDescription = "ES10876: Verify the LSP for 2nd+ instance of New loan.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                
                Reports.TestStep = "Enter a new lender without navigating to newloan screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00");
                FastDriver.NewLoan.FindGABCode(busOrg.IDCode);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageProduct.FASelectItem("50 - i Declare - Regular");
                FastDriver.NewLoan.LoanDetailsProductOption.FASelectItem("Open");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("QA02, FAST");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03/16/2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08/03/2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12/12/2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FIRSTAM is not held responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1000.00");
                FastDriver.BottomFrame.Done();
         
            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
            

        }

        [TestMethod]
        public void FMUC0024_REG0007()
        {
            try
            {
                #region - Data Setup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("249");
                fileRequest.formType = FormType.CD;
                #endregion

                Reports.TestDescription = "ES10935_ES10936: Verify the payment details for refinance file and legacy loan.";
                Login(AutoConfig.FASTHomeURL);
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                //

                Reports.TestStep = "Click on Payment Details button of Interest Calculation section.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Verify the POBOB should be enabled for CD type of loans.";
                FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.Enabled.ToString());
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanDetailsTab.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NewLoan.FormType_CD.Selected.ToString());

                Reports.TestStep = "Verify for GFE payment details for legacy type of loan.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesGFE_7FutureRecordingFeescollectedbyLender_MB_PaymentDetails.Exists().ToString());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.Exists().ToString());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0008()
        {
            try
            {
                #region - Data Setup
                string lowerAmount = "1234567890.1";
                string exactAmount = "12345678901.12";
                string higherAmount = "1234567890123.123";
                #endregion

                Reports.TestDescription = "FD_1: Verify the field definitions.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //

                Reports.TestStep = "Give the GFE 3 new charges details.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", buyerCharge: 10.00, sellerCharge: 30.00, loanEstimate: 50.00);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();


                //

                Reports.TestStep = "Verify the field definitions for lower boundary.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(lowerAmount);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(lowerAmount);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText(lowerAmount);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText(lowerAmount);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(lowerAmount);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(lowerAmount);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText(lowerAmount);
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(lowerAmount);
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Verify the field definitions for exact boundary.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(exactAmount);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(exactAmount);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText(exactAmount);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText(exactAmount);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(exactAmount);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(exactAmount);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText(exactAmount);
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(exactAmount);
                FastDriver.PaymentDetailsDlg.PayTo.Click();
                Support.AreEqual(exactAmount.FormatAsMoney(true), FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue());
                Support.AreEqual(exactAmount.FormatAsMoney(true), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                Support.AreEqual(exactAmount.FormatAsMoney(true), FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue());
                Support.AreEqual(exactAmount.FormatAsMoney(true), FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue());
                Support.AreEqual(exactAmount.FormatAsMoney(true), FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue());
                Support.AreEqual(exactAmount.FormatAsMoney(true), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue());
                Support.AreEqual(exactAmount.FormatAsMoney(true), FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue());
                Support.AreEqual(exactAmount.FormatAsMoney(true), FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue());
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Verify the field definitions for upper boundary.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(higherAmount);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(higherAmount);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText(higherAmount);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText(higherAmount);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(higherAmount);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(higherAmount);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText(higherAmount);
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(higherAmount);
                FastDriver.PaymentDetailsDlg.PayTo.Click();
                Support.AreEqual("Value cannot be greater than $99,999,999,999.99", FastDriver.PaymentDetailsDlg.BuyerCharge.GetAttribute("title"));
                Support.AreEqual("Value cannot be greater than $99,999,999,999.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.GetAttribute("title"));
                Support.AreEqual("Value cannot be greater than $99,999,999,999.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.GetAttribute("title"));
                Support.AreEqual("Value cannot be greater than $99,999,999,999.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.GetAttribute("title"));
                Support.AreEqual("Value cannot be greater than $99,999,999,999.99", FastDriver.PaymentDetailsDlg.SellerCharge.GetAttribute("title"));
                Support.AreEqual("Value cannot be greater than $99,999,999,999.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.GetAttribute("title"));
                Support.AreEqual("Value cannot be greater than $99,999,999,999.99", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.GetAttribute("title"));
                Support.AreEqual("Value cannot be greater than $99,999,999,999.99", FastDriver.PaymentDetailsDlg.PaidbySellerOthers.GetAttribute("title"));
                FastDriver.DialogBottomFrame.ClickCancel();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0009()
        {
            try
            {
                Reports.TestDescription = "FD_2: Verify the field definitions.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //

                Reports.TestStep = "Verify the field definitions for description for lower boundary.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQR");
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQR", FastDriver.PaymentDetailsDlg.Description.FAGetValue());
                FastDriver.DialogBottomFrame.ClickCancel();

                //

                Reports.TestStep = "Verify the field definitions for exact boundary.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRS");
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRS", FastDriver.PaymentDetailsDlg.Description.FAGetValue());
                FastDriver.DialogBottomFrame.ClickCancel();

                //

                Reports.TestStep = "Verify the field definitions for description for upper boundary.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRST");
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRS", FastDriver.PaymentDetailsDlg.Description.FAGetValue());
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Cancel();

            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0010_PH()
        {
            try
            {
                Reports.TestDescription = "ES12612_ES12613_FM2512_FM1186_UserStory 594076_643678: BRs cannot be scripted.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("ES12612_ES12613_FM2512_FM1186_UserStory 594076_643678 (Add PrimaryPolicy check box and only display on OTC screen when charge type has MISMO type = Title Lender Insurance Premium and Title Owner Insurance Premium, otherwise checknbox is hidden.) These Flow have NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }


        [TestMethod]
        public void FMUC0024_REG0011()
        {
            try
            {
                Reports.TestDescription = "User Story 615066 : PDD-Revise Warning Message";

                if (AutoConfig.UseCDFormType)
                {

                    #region - Data Setup
                    var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                    #endregion

                    #region Login to file side
                    Login(AutoConfig.FASTHomeURL);
                    #endregion

                    #region Create File
                    FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));
                    #endregion

                    #region Validate User Story 615066 : PDD-Revise Warning Message
                    Reports.TestStep = "Navigate to Fee Entry Screen.";
                    FastDriver.FileFees.Open();

                    Reports.TestStep = "In Title and Escrow Tab Select any description Checkbox and Click on the PDD Button.";
                    FastDriver.FileFees.TitleandEscrow.FAClick();
                    FastDriver.FileFees.WaitForScreenToLoad();
                    string Desc = FastDriver.FileFees.TitleandEscrowTable.PerformTableAction(2, 2, TableAction.GetText).Message.ToString();
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", Desc, "Sel", TableAction.On);
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", Desc, "Det", TableAction.Click);

                    Reports.TestStep = "Remove the Loan estimate description in PDD.";
                    FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.FeePaymentDetailsDlg.LoanEstimatedDesc.Clear();
                    FastDriver.DialogBottomFrame.ClickDone();

                    Reports.TestStep = "Validate the message and click on NO.";
                    Support.AreEqual("Loan Estimate Description is required and has not been filled in. Do you want to populate it with the default Loan Estimate Description? If you select no, a description must be entered before you can exit the screen", FastDriver.WarningDlg.Handle(false));
                    FastDriver.WebDriver.HandleDialogMessage(true, false, 5);

                    Reports.TestStep = "Validate the blank Loan Estimate Description and PDD dialog.";
                    FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("", FastDriver.FeePaymentDetailsDlg.LoanEstimatedDesc.FAGetValue().ToString().ToLower(), true);

                    Reports.TestStep = "Validate the message and click on Yes.";
                    FastDriver.FeePaymentDetailsDlg.LoanEstimatedDesc.Clear();
                    FastDriver.DialogBottomFrame.ClickDone();
                    Support.AreEqual("Loan Estimate Description is required and has not been filled in. Do you want to populate it with the default Loan Estimate Description? If you select no, a description must be entered before you can exit the screen", FastDriver.WarningDlg.Handle(true));
                    FastDriver.WebDriver.HandleDialogMessage(true, false, 5);


                    Reports.TestStep = "Validate that Loan estimate description is filled with default description.";
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.FileFees.WaitForScreenToLoad();
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", Desc, "Sel", TableAction.On);
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", Desc, "Det", TableAction.Click);
                    FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("Title - " + Desc, FastDriver.FeePaymentDetailsDlg.LoanEstimatedDesc.FAGetValue().ToString().Trim(), true);
                    FastDriver.DialogBottomFrame.ClickDone();

                    Reports.TestStep = "Enter new description and Validate the same.";
                    FastDriver.FileFees.WaitForScreenToLoad();
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", Desc, "Sel", TableAction.On);
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", Desc, "Det", TableAction.Click);
                    FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.FeePaymentDetailsDlg.LoanEstimatedDesc.FASetText("Test Desc");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.FileFees.WaitForScreenToLoad();
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", Desc, "Det", TableAction.Click);
                    FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("Test Desc", FastDriver.FeePaymentDetailsDlg.LoanEstimatedDesc.FAGetValue().ToString().Trim(), true);

                    Reports.TestStep = "Remove LoanEstimatDesc and navigate away from PDD, Return to PDD validate the new description entered before in LoanEstimateDesc.";
                    FastDriver.FeePaymentDetailsDlg.LoanEstimatedDesc.Clear();
                    FastDriver.DialogBottomFrame.ClickDone();

                    Support.AreEqual("Loan Estimate Description is required and has not been filled in. Do you want to populate it with the default Loan Estimate Description? If you select no, a description must be entered before you can exit the screen", FastDriver.WarningDlg.Handle(true));
                    FastDriver.FileFees.WaitForScreenToLoad();
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", Desc, "Det", TableAction.Click);
                    FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("Title - " + Desc, FastDriver.FeePaymentDetailsDlg.LoanEstimatedDesc.FAGetValue().ToString().Trim(), true);
                    FastDriver.DialogBottomFrame.ClickDone();

                    #endregion
                }
                else
                {
                    Reports.StatusUpdate("This user sorty is not applicable for HUD form type.", true);
                }
            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0012()
        {
            try
            {
                Reports.TestDescription = "User Story 598749_643678:PDD - Rename Asterisk checkbox label - Asterisk for SS _ In PDD the radio buttons for B,C,H are moved up above Primary Polic Check box.";
                if (AutoConfig.UseCDFormType)
                {

                    #region - Data Setup
                    var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                    #endregion

                    #region Login to file side
                    Reports.TestStep = "Logint to file side.";
                    Login(AutoConfig.FASTHomeURL);
                    #endregion

                    #region Create File
                    Reports.TestStep = "Create file.";
                    FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));
                    #endregion

                    #region Validate User Story 598749:PDD - Rename Asterisk checkbox label - Asterisk for SS
                    Reports.TestStep = "Validate Asterisk for SS for Loan Charges Principal Balance Charges Payment Details Dialog.";
                    FastDriver.NewLoan.Open();
                    FastDriver.NewLoan.FindGABCode("247");
                    FastDriver.NewLoan.ClickChargesTab();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.Highlight();
                    FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Loan Charges Interest Calculation Payment Details Dialog.";
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.Highlight();
                    FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Loan Charges Credit Charge Points Payment Details Dialog.";
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.Highlight();
                    FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Loan Charges Origination Charge Payment Details Dialog.";
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.Highlight();
                    FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Loan Charges NewLoan Charges Payment Details Dialog.";
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.Highlight();
                    FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Loan Charges Lender Credits Payment Details Dialog.";
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.Highlight();
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Loan Charges Future Recording Fees Collected by Lender Payment Details Dialog.";
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesGFE_7FutureRecordingFeescollectedbyLender_MB_PaymentDetails.Highlight();
                    FastDriver.NewLoan.LoanChargesGFE_7FutureRecordingFeescollectedbyLender_MB_PaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Loan Charges Impounds Payment Details Dialog.";
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesmpountPaymentDetails.Highlight();
                    FastDriver.NewLoan.LoanChargesmpountPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Loan Charges Principal Reduction/Construction Hold back Payment Details Dialog.";
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.Highlight();
                    FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Navigate to Mortgage Broker tab.";
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.ClickMortgageBrokerTab();

                    Reports.TestStep = "Validate Asterisk for SS for Mortgage Broker, Mortgage Broker Charges Payment Details Dialog.";
                    FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                    FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.Highlight();
                    FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Mortgage Broker, Lender Credits Payment Details Dialog.";
                    FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                    FastDriver.NewLoan.MortgageGFE_6MortgageBrokerChargesPaymentDetails.Highlight();
                    FastDriver.NewLoan.MortgageGFE_6MortgageBrokerChargesPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Mortgage Broker, Future Recording Fee collected by Lender / MB Payment Details Dialog.";
                    FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                    FastDriver.NewLoan.MortgageGFE_7FutureRecordingFeescollectedbyLenderMBPaymentDetails.Highlight();
                    FastDriver.NewLoan.MortgageGFE_7FutureRecordingFeescollectedbyLenderMBPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Home Owner Association, Association Charges Payment Details Dialog.";
                    FastDriver.HomeownerAssociation.Open();
                    FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.Highlight();
                    FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Home Owner Association, Management Company Charges Payment Details Dialog.";
                    FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                    FastDriver.HomeownerAssociation.ManagementCompanyPaymentDetails.Highlight();
                    FastDriver.HomeownerAssociation.ManagementCompanyPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Home Owner Association, HOA Lien Payoff (Proration) Payment Details Dialog.";
                    FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                    FastDriver.HomeownerAssociation.ProrationPaymentDetails.Highlight();
                    FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Home Warranty, Home Warranty Charges Payment Details Dialog.";
                    FastDriver.HomeWarrantyDetail.Open();
                    FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.Highlight();
                    FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Home Warranty, Early Coverage Payment Details Dialog.";
                    FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                    FastDriver.HomeWarrantyDetail.PaymentDetailsEarlyCoverage.Highlight();
                    FastDriver.HomeWarrantyDetail.PaymentDetailsEarlyCoverage.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Inspection Repair(PEST), Inspection/Repair Charges Payment Details Dialog.";
                    FastDriver.InspectionRepairPest.Open();
                    FastDriver.InspectionRepairPest.PaymentDetails.Highlight();
                    FastDriver.InspectionRepairPest.PaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Inspection Repair(SEPTIC), Inspection/Repair Charges Payment Details Dialog.";
                    FastDriver.InspectionRepairSeptic.Open();
                    FastDriver.InspectionRepairSeptic.PaymentDetails.Highlight();
                    FastDriver.InspectionRepairSeptic.PaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Inspection Repair(OTHER), Inspection/Repair Charges Payment Details Dialog.";
                    FastDriver.InspectionRepairOther.Open();
                    FastDriver.InspectionRepairOther.PaymentDetails.Highlight();
                    FastDriver.InspectionRepairOther.PaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Lease, Lease Charges Payment Details Dialog.";
                    FastDriver.LeaseDetail.Open();
                    FastDriver.LeaseDetail.PaymentDetails.Highlight();
                    FastDriver.LeaseDetail.PaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Miscellaneous Disbursement, Lease Charges Payment Details Dialog.";
                    FastDriver.MiscDisbursementDetail.Open();
                    FastDriver.MiscDisbursementDetail.FindGABcode("247");
                    FastDriver.MiscDisbursementDetail.Description.FASetText("Test Desc");
                    FastDriver.MiscDisbursementDetail.PaymentDetails.Highlight();
                    FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Property Tax Check , Property Taxes Payment Details Dialog.";
                    FastDriver.PropertyTaxCheck.Open();
                    FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.Highlight();
                    FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Property Tax Check , Property Taxes Payment Details Dialog.";
                    FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                    FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.Highlight();
                    FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Survey , Survey Charges - Borrower Selected Services Payment Details Dialog.";
                    FastDriver.SurveyDetail.Open();
                    FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.Highlight();
                    FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Utility , Utility Charges Payment Details Dialog.";
                    FastDriver.UtilityDetail.Open();
                    FastDriver.UtilityDetail.UtilityChargesPaymentDetails.Highlight();
                    FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for PayOffLoan , Loan Charges Payment Details Dialog.";
                    FastDriver.PayoffLoanDetails.Open();
                    FastDriver.PayoffLoanDetails.FindGABCode("247");
                    FastDriver.PayoffLoanDetails.ClickChargesTab();
                    FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                    FastDriver.PayoffLoanCharges.PaymentDetails.Highlight();
                    FastDriver.PayoffLoanCharges.PaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for PayOffLoan , Interest Calculation Payment Details Dialog.";
                    FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                    FastDriver.PayoffLoanCharges.InterestCalculationPaymentDetails.Highlight();
                    FastDriver.PayoffLoanCharges.InterestCalculationPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for PayOffLoan , Payoff Loan Charges Payment Details Dialog.";
                    FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.Highlight();
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Assumption Loan , Unpaid Principal Loan Charges Payment Details Dialog.";
                    FastDriver.AssumptionLoanDetails.Open();
                    FastDriver.AssumptionLoanDetails.FindGABCode("247");
                    FastDriver.AssumptionLoanDetails.ClickChargesTab();
                    FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                    FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesPaymentDetails.Highlight();
                    FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Assumption Loan , Interest Proration Payment Details Payment Details Dialog.";
                    FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                    FastDriver.AssumptionLoanCharges.InterestProrationPaymentDetails.Highlight();
                    FastDriver.AssumptionLoanCharges.InterestProrationPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Assumption Loan , Assumption Loan Charges Payment Details Dialog.";
                    FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                    FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.Highlight();
                    FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for OEC , OEC Charges Payment Details Dialog.";
                    FastDriver.OutsideEscrowCompanyDetail.Open();
                    FastDriver.OutsideEscrowCompanyDetail.FindGAB("247");
                    FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("test desc");
                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.Highlight();
                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for OTC , Title Service Payment Details Dialog.";
                    FastDriver.OutsideTitleCompanyDetail.Open();
                    FastDriver.OutsideTitleCompanyDetail.FindGAB("247");
                    FastDriver.OutsideTitleCompanyDetail.TitleServicePaymentDetail.Highlight();
                    FastDriver.OutsideTitleCompanyDetail.TitleServicePaymentDetail.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for OTC , Lender's Policy and Endorsements Payment Details Dialog.";
                    FastDriver.OutsideTitleCompanyDetail.WaitForScreenToLoad();
                    FastDriver.OutsideTitleCompanyDetail.LenderPEPaymentDetails.Highlight();
                    FastDriver.OutsideTitleCompanyDetail.LenderPEPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for OTC , Owner's Policy and Endorsements Payment Details Dialog.";
                    FastDriver.OutsideTitleCompanyDetail.WaitForScreenToLoad();
                    FastDriver.OutsideTitleCompanyDetail.OwnerPEPaymentDetails.Highlight();
                    FastDriver.OutsideTitleCompanyDetail.OwnerPEPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for OTC , Recording Fees & Transfer Taxes Payment Details Dialog.";
                    FastDriver.OutsideTitleCompanyDetail.WaitForScreenToLoad();
                    FastDriver.OutsideTitleCompanyDetail.RFeesTTaxesPaymentDetails.Highlight();
                    FastDriver.OutsideTitleCompanyDetail.RFeesTTaxesPaymentDetails.FAClick();
                    Thread.Sleep(3000);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.PaymentDetailsDlg.AsteriskForSSinOTCRFeesTTaxesPaymentDetails.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Fee Entry , any Title and Escrow Fees Payment Details Dialog.";
                    FastDriver.FileFees.Open();
                    FastDriver.FileFees.TitleandEscrow.FAClick();
                    FastDriver.FileFees.WaitForScreenToLoad();
                    string Desc = FastDriver.FileFees.TitleandEscrowTable.PerformTableAction(2, 2, TableAction.GetText).Message.ToString();
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", Desc, "Sel", TableAction.On);
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", Desc, "Det", TableAction.Click);
                    FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.FeePaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    FastDriver.FileFees.WaitForScreenToLoad();
                    string Desc2 = FastDriver.FileFees.TitleandEscrowTable.PerformTableAction(3, 2, TableAction.GetText).Message.ToString();
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", Desc2, "Sel", TableAction.On);
                    FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", Desc2, "Det", TableAction.Click);
                    FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.FeePaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();

                    Reports.TestStep = "Validate Asterisk for SS for Fee Entry , any Recording and Tax Payment Details Dialog.";
                    FastDriver.FileFees.WaitForScreenToLoad();
                    FastDriver.FileFees.RecordingandTax.FAClick();
                    FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingandTaxTable);
                    string Desc3 = FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, 2, TableAction.GetText).Message.ToString();
                    FastDriver.FileFees.RecordingandTaxTable.PerformTableAction("Description", Desc3, "Sel", TableAction.On);
                    FastDriver.FileFees.RecordingandTaxTable.PerformTableAction("Description", Desc3, "Det", TableAction.Click);
                    FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.FeePaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);

                    FastDriver.FeePaymentDetailsDlg.SectionBtext.Highlight();
                    string SectionBTextLocation = FastDriver.FeePaymentDetailsDlg.SectionBtext.FAGetLocation().Y.ToString();
                    int Blocation = Convert.ToInt32(SectionBTextLocation);
                    string SectionCTextLocation = FastDriver.FeePaymentDetailsDlg.SectionCtext.FAGetLocation().Y.ToString();
                    int CLocation = Convert.ToInt32(SectionCTextLocation);
                    string SectionHTextLocation = FastDriver.FeePaymentDetailsDlg.SectionHtext.FAGetLocation().Y.ToString();
                    int HLocation = Convert.ToInt32(SectionHTextLocation);
                    string PrimaryPolicyTextLocation = FastDriver.FeePaymentDetailsDlg.PrimaryPolicyText.FAGetLocation().Y.ToString();
                    int PrimaryPolicyLocation = Convert.ToInt32(PrimaryPolicyTextLocation);

                    if ((Blocation < CLocation) && (CLocation < HLocation) && (HLocation < PrimaryPolicyLocation))
                    {
                        Reports.StatusUpdate("Section B, C and H are above the Primary Policy check box.", true);
                    }
                    FastDriver.DialogBottomFrame.ClickCancel();

                    FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingandTaxTable);
                    string Desc4 = FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(3, 2, TableAction.GetText).Message.ToString();
                    FastDriver.FileFees.RecordingandTaxTable.PerformTableAction("Description", Desc4, "Sel", TableAction.On);
                    FastDriver.FileFees.RecordingandTaxTable.PerformTableAction("Description", Desc4, "Det", TableAction.Click);
                    FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("true", FastDriver.FeePaymentDetailsDlg.AsteriskForSS.FAGetText().Contains("Asterisk for SS").ToString().Trim().ToLower(), true);
                    FastDriver.DialogBottomFrame.ClickCancel();
                    #endregion

                }
                else
                {
                    Reports.StatusUpdate("This user sorty is not applicable for HUD form type.", true);
                }
            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0013()
        {
            try
            {
                Reports.TestDescription = "US 678769: Verify the POC-L functionality on source screens and L notation on CD screen";

                //#region data setup
                //var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                //#endregion
                if (AutoConfig.UseCDFormType)
                {

                    Reports.TestStep = "Login to Fast IIS Application";
                    Login(AutoConfig.FASTHomeURL);

                    Reports.TestStep = "Create basic file";
                    CreateFileRequest fileRequest = new CreateFileRequest();
                    fileRequest = RequestFactory.GetCreateFileDefaultRequest();

                    fileRequest.File.Services = RequestFactory.GetServices(isTO: true, isEO: true, isSEO: false);
                    var response3 = FileService.CreateFile(fileRequest);
                    var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                    FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);


                    //condition 1
                    Reports.TestStep = "Navigate to Outside Escrow Company(Source Screen)";

                    FastDriver.OutsideEscrowCompanyDetail.Open();


                    Reports.TestStep = "Find GAB and enter Charges";
                    FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText("wf");
                    FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                    FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.Highlight();
                    FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("Test Description" + FAKeys.Tab);

                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.Highlight();
                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("20");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("40");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("60" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("30");
                    FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                    FastDriver.PaymentDetailsDlg.SectionB.FASetCheckbox(true);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();

                    Reports.TestStep = "Navigate to CD Screen and Verify the Charge Amount in appropriate section";
                    FastDriver.ClosingDisclosure.Open();
                    FastDriver.ClosingDisclosure.ExpandLoanCost();
                    FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                    Support.AreEqual("$20.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$40.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 3, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$30.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 4, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$50.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 5, TableAction.GetText).Message.Trim());
                    Support.AreEqual("(L)$60.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 6, TableAction.GetText).Message.Trim());

                    //condition 2
                    Reports.TestStep = "Navigate to Outside Escrow Company(Source Screen)";
                    FastDriver.OutsideEscrowCompanyDetail.Open();

                    Reports.TestStep = "Enter Charges";
                    FastDriver.OutsideEscrowCompanyDetail.LoanEstimate.FAClick();
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(3, 1, TableAction.SetText, "Test Description 2");
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(3, 2, TableAction.Click);
                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.Highlight();
                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("15");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("50");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("70" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                    FastDriver.PaymentDetailsDlg.DisplayLBorrower.Highlight();
                    FastDriver.PaymentDetailsDlg.DisplayLBorrower.FAClick();
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("20");
                    FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("10");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                    FastDriver.PaymentDetailsDlg.SectionB.FASetCheckbox(true);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();


                    Reports.TestStep = "Navigate to CD Screen and Verify the Charge Amount in appropriate section";
                    FastDriver.ClosingDisclosure.Open();
                    FastDriver.ClosingDisclosure.ExpandLoanCost();
                    FastDriver.ClosingDisclosure.WaitForScreenToLoad();

                    Support.AreEqual("$15.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(3, 2, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$50.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(3, 3, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$20.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(3, 4, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$10.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(3, 5, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$70.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(3, 6, TableAction.GetText).Message.Trim());

                    //condition 3
                    Reports.TestStep = "Navigate to Outside Escrow Company(Source Screen)";
                    FastDriver.OutsideEscrowCompanyDetail.Open();

                    Reports.TestStep = "Enter Charges";
                    FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(3, 5, TableAction.Click);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(4, 1, TableAction.SetText, "Test Description 3");
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(4, 2, TableAction.Click);
                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.Highlight();
                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("12");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("24");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("0");


                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("11");
                    FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("32");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("15");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                    FastDriver.PaymentDetailsDlg.SectionB.FASetCheckbox(true);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();


                    Reports.TestStep = "Navigate to CD Screen and Verify the Charge Amount in appropriate section";
                    FastDriver.ClosingDisclosure.Open();
                    FastDriver.ClosingDisclosure.ExpandLoanCost();
                    FastDriver.ClosingDisclosure.WaitForScreenToLoad();

                    Support.AreEqual("$12.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(4, 2, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$24.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(4, 3, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$11.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(4, 4, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$32.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(4, 5, TableAction.GetText).Message.Trim());
                    Support.AreEqual("", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(4, 6, TableAction.GetText).Message.Trim());

                    //condition 4

                    Reports.TestStep = "Navigate to Outside Escrow Company(Source Screen)";
                    FastDriver.OutsideEscrowCompanyDetail.Open();

                    Reports.TestStep = "Enter Charges";
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(4, 5, TableAction.Click);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(5, 1, TableAction.SetText, "Test Description 4");
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(5, 2, TableAction.Click);
                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.Highlight();
                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("5");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("15");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("0");
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                    //FastDriver.PaymentDetailsDlg.DisplayLBorrower.Highlight();
                    //FastDriver.PaymentDetailsDlg.DisplayLBorrower.FAClick();
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("10");
                    FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("20");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("30");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                    FastDriver.PaymentDetailsDlg.SectionC.FASetCheckbox(true);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();


                    Reports.TestStep = "Navigate to CD Screen and Verify the Charge Amount in appropriate section";
                    FastDriver.ClosingDisclosure.Open();
                    FastDriver.ClosingDisclosure.ExpandLoanCost();
                    FastDriver.ClosingDisclosure.WaitForScreenToLoad();

                    Support.AreEqual("$5.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidShopForTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$15.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidShopForTable.PerformTableAction(2, 3, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$10.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidShopForTable.PerformTableAction(2, 4, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$20.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidShopForTable.PerformTableAction(2, 5, TableAction.GetText).Message.Trim());
                    Support.AreEqual("", FastDriver.ClosingDisclosure.ServicesBorrowerDidShopForTable.PerformTableAction(2, 6, TableAction.GetText).Message.Trim());

                    //condition 5

                    Reports.TestStep = "Navigate to Outside Escrow Company(Source Screen)";
                    FastDriver.OutsideEscrowCompanyDetail.Open();

                    Reports.TestStep = "Enter Charges";
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(5, 5, TableAction.Click);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(6, 1, TableAction.SetText, "Test Description 5");
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(6, 2, TableAction.Click);
                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.Highlight();
                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("40");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("20");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("60" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("30");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("10" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                    FastDriver.PaymentDetailsDlg.SectionC.FASetCheckbox(true);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();

                    Reports.TestStep = "Navigate to CD Screen and Verify the Charge Amount in appropriate section";

                    FastDriver.ClosingDisclosure.Open();
                    FastDriver.ClosingDisclosure.ExpandLoanCost();
                    FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                    Support.AreEqual("$40.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidShopForTable.PerformTableAction(3, 2, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$20.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidShopForTable.PerformTableAction(3, 3, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$50.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidShopForTable.PerformTableAction(3, 4, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$30.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidShopForTable.PerformTableAction(3, 5, TableAction.GetText).Message.Trim());
                    Support.AreEqual("(L)$60.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidShopForTable.PerformTableAction(3, 6, TableAction.GetText).Message.Trim());

                    //condition 6

                    Reports.TestStep = "Navigate to Outside Escrow Company(Source Screen)";
                    FastDriver.OutsideEscrowCompanyDetail.Open();

                    Reports.TestStep = "Enter Charges";
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(6, 5, TableAction.Click);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(7, 1, TableAction.SetText, "Test Description 6");
                    FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(7, 2, TableAction.Click);
                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.Highlight();
                    FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("15");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("30");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("45" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");

                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("20");
                    FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("40");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("60" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                    FastDriver.PaymentDetailsDlg.DisplayLSeller.Highlight();
                    FastDriver.PaymentDetailsDlg.DisplayLSeller.FAClick();
                    FastDriver.PaymentDetailsDlg.SectionB.FASetCheckbox(true);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();


                    Reports.TestStep = "Navigate to CD Screen and Verify the Charge Amount in appropriate section";
                    FastDriver.ClosingDisclosure.Open();
                    FastDriver.ClosingDisclosure.ExpandLoanCost();
                    FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                    Support.AreEqual("$15.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(5, 2, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$30.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(5, 3, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$20.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(5, 4, TableAction.GetText).Message.Trim());
                    Support.AreEqual("$40.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(5, 5, TableAction.GetText).Message.Trim());
                    Support.AreEqual("(L)$45.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(5, 6, TableAction.GetText).Message.Trim());
                }
                else
                {
                    Reports.StatusUpdate("This user sorty is not applicable for HUD form type.", true);
                }
            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0014()
        {
            try
            {
                Reports.TestDescription = "Bug #868191: INC3064128 - 10.6 Issue - Title Fees not showing on SS, HUD Flag / Internal System Error";
                Reports.TestStep = "Log into FAST application.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a new file with Sale w/Mortage transaction type.";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a Title or Lender policy";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad(element: FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.SearchFees("Title - Lenders Policy").WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Locate added Fee, select it and click on Payment Details button";
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 3, TableAction.Click);

                Reports.TestStep = "Enter special characters in Additional Description field";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText(",!@#$%");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Add Buyer Charge and Seller Charge";
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.TitleandescrowTable);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "1064_Title_Lender_Policy ,!@#$%", buyerCharge: 8.00, sellerCharge: 8.00);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.TitleandescrowTable);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0015()
        {
            try
            {
                Reports.TestDescription = "User Story- 740222(Testcase #770307):Verify that, user is prevented from checking the Primary Policy checkbox on the OTC Lender Policy.";
                Reports.TestStep = "Login to Fast IIS Application";
                _IISLOGIN();


                Reports.TestStep = "Create a file with Owner and Lender Policy Liability Amounts";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)200000;
                fileRequest.File.FirstNewLoanAmount = (decimal)100000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Playback.Wait(500);

                Reports.TestStep = "Navigate to Fee Entry(File Fees) Screen";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.SelectTitleAndEndorsementFees();
                FastDriver.FileFees.CalculateFees.FAClick();
                Reports.TestStep = "Add the Lender and the associated Rate Type";
                FastDriver.CalculateFees.SelectTitleAndEndorsement();
                FastDriver.CalculateFees.Next.FAClick();
                Reports.TestStep = "Add the Fee Description and Charge To on the Calculation Summary Screen";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SelectFeeFromSummaryTableBasedOnFeeType();
                FastDriver.CalculateFees.SelectFASTFeeDescAndChargeTo("ALTA Expanded (Eagle Loan) Policy", "", "", "Buyer", "", "");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to OTC Screen";
                FastDriver.OTCDetail.Open();
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideTitleCompanyDetail.FindGAB("247");
                Reports.TestStep = "Enter Buyer Charge and Seller Charge and Click on the PDD";
                FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable.Highlight();
                // FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable, "Title - Lender Policy", 20, null, 10, null, null);
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction(2, 3, TableAction.SetTextByCellIndex, "10.00" + FAKeys.Tab); //Buyer Charge
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction(2, 5, TableAction.SetTextByCellIndex, "20.00" + FAKeys.Tab); //Seller Charge

                FastDriver.OutsideTitleCompanyDetail.PDDlendersPolicyandEndorsements.Highlight();
                FastDriver.OutsideTitleCompanyDetail.PDDlendersPolicyandEndorsements.FAClick();
                Reports.TestStep = "Check the Primary Policy CheckBox in the PDD";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Highlight();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.FASetCheckbox(true);
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("A Primary Policy is calculated on the Fee Entry screen and must be removed to select a Primary Policy on the Outside Title Company screen.");

                Reports.TestStep = "Verify that Primary Policy CheckBox is unchecked";
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Selected.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Navigate to Fee Entry Screen and Uncheck the Lender Policy";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to OTC Scren";
                FastDriver.OTCDetail.Open();
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                Reports.TestStep = "Check for the Primary Policy CheckBox in the PDD to be checked and disabled";
                FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable.PerformTableAction(2, 3, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Highlight();
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Selected.ToString());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Enabled.ToString());
                FastDriver.DialogBottomFrame.ClickDone();

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0016()
        {
            try
            {
                Reports.TestDescription = "User Story- 740222(Test Case #770311): Verify that, user is prevented from checking the Primary Policy checkbox on the OTC Owner Policy.";
                Reports.TestStep = "Login to Fast IIS Application";
                _IISLOGIN();


                Reports.TestStep = "Create a file with Owner and Lender Policy Liability Amounts";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)200000;
                fileRequest.File.FirstNewLoanAmount = (decimal)100000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Playback.Wait(500);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                FastDriver.FileHomepage.AddFileProduct("*ALTA Homeowners (Eagle Owner) Policy");
                Reports.TestStep = "Navigate to Fee Entry(File Fees) Screen";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.SelectTitleAndEndorsementFees();
                FastDriver.FileFees.CalculateFees.FAClick();
                Reports.TestStep = "Add the Owner Policy and the associated Rate Type";
                FastDriver.CalculateFees.SelectTitleAndEndorsement("ALTA Standard Owner Policy");
                FastDriver.CalculateFees.Next.FAClick();
                Reports.TestStep = "Add the Fee Description and Charge To on the Calculation Summary Screen";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SelectFeeFromSummaryTableBasedOnFeeType();
                FastDriver.CalculateFees.SelectFASTFeeDescAndChargeTo("ALTA Standard Owner Policy", "", "", "Buyer", "", "");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to OTC Screen";
                FastDriver.OTCDetail.Open();
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideTitleCompanyDetail.FindGAB("247");
                Reports.TestStep = "Enter Buyer Charge and Seller Charge and Click on the PDD";
                //FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.Highlight();
                FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable, "Title - Owner Policy (Optional)", 30, null, 40, null, null);
                //FastDriver.OutsideTitleCompanyDetail.PDDOwnersPolicyandEndorsements.Highlight();
                FastDriver.OutsideTitleCompanyDetail.PDDOwnersPolicyandEndorsements.FAClick();
                Reports.TestStep = "Check the Primary Policy CheckBox in the PDD";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                //FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Highlight();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.FASetCheckbox(true);
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("A Primary Policy is calculated on the Fee Entry screen and must be removed to select a Primary Policy on the Outside Title Company screen.");

                Reports.TestStep = "Verify that Primary Policy CheckBox is unchecked";
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Selected.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Navigate to Fee Entry Screen and Uncheck the Owner Policy";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to OTC Scren";
                FastDriver.OTCDetail.Open();
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideTitleCompanyDetail.PDDOwnersPolicyandEndorsements.FAClick();
                Reports.TestStep = "Check for the Primary Policy CheckBox in the PDD to be checked and disabled";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                //FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Highlight();
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Selected.ToString());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Enabled.ToString());
                FastDriver.DialogBottomFrame.ClickDone();


            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0017()
        {
            try
            {
                Reports.TestDescription = "User Story- 740222(Test Case 772148): Verify that, user is not prevented from having the Owner Primary Policy in OTC, when having FACC Lender Policy in Fee Entry";
                Reports.TestStep = "Login to Fast IIS Application";
                _IISLOGIN();

                Reports.TestStep = "Create a file with Owner and Lender Policy Liability Amounts";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)200000;
                fileRequest.File.FirstNewLoanAmount = (decimal)100000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Playback.Wait(500);

                Reports.TestStep = "Navigate to Fee Entry(File Fees) Screen";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.SelectTitleAndEndorsementFees();
                FastDriver.FileFees.CalculateFees.FAClick();
                Reports.TestStep = "Add the Lender and the associated Rate Type";
                FastDriver.CalculateFees.SelectTitleAndEndorsement();
                FastDriver.CalculateFees.Next.FAClick();
                Reports.TestStep = "Add the Fee Description and Charge To on the Calculation Summary Screen";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SelectFeeFromSummaryTableBasedOnFeeType();
                FastDriver.CalculateFees.SelectFASTFeeDescAndChargeTo("ALTA Expanded (Eagle Loan) Policy", "", "", "Buyer", "", "");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to OTC Screen";
                FastDriver.OTCDetail.Open();
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideTitleCompanyDetail.FindGAB("247");
                Reports.TestStep = "Enter Buyer Charge and Seller Charge and Click on the PDD for Owner Policy";
                FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.Highlight();
                FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable, "Title - Owner Policy (Optional)", 30, null, 40, null, null);
                FastDriver.OutsideTitleCompanyDetail.PDDOwnersPolicyandEndorsements.Highlight();
                FastDriver.OutsideTitleCompanyDetail.PDDOwnersPolicyandEndorsements.FAClick();
                Reports.TestStep = "Verify that the Primary Policy CheckBox is checked and disabled indicating the Owner Policy on OTC Screen is Primary";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Selected.ToString());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Enabled.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Verify for the description and the DOP values on OTC";
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                Support.AreEqual("ALTA Ext Loan Policy 1056.06 (6-17-06) - 1", FastDriver.OutsideTitleCompanyDetail.OTCLenderPolicyName.FAGetText());
                Support.AreEqual("Title - Owner Policy (Optional)", FastDriver.OutsideTitleCompanyDetail.OTCOwnerPolicyName.FAGetText());
                Support.AreEqual("$70.00", FastDriver.OutsideTitleCompanyDetail.OTCDisclosedOwnerPremium.FAGetValue());
                Support.AreEqual("False", FastDriver.OutsideTitleCompanyDetail.OTCDisclosedOwnerPremium.Enabled.ToString());

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0018()
        {
            try
            {
                Reports.TestDescription = "User Story- 740222(Test Case 772175): Verify that, user is not prevented from having the Lender Primary Policy in OTC, when having FACC Owner Policy in Fee Entry.";
                Reports.TestStep = "Login to Fast IIS Application";
                _IISLOGIN();


                Reports.TestStep = "Create a file with Owner and Lender Policy Liability Amounts";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)200000;
                fileRequest.File.FirstNewLoanAmount = (decimal)100000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Playback.Wait(500);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                FastDriver.FileHomepage.AddFileProduct("*ALTA Homeowners (Eagle Owner) Policy");
                Reports.TestStep = "Navigate to Fee Entry(File Fees) Screen";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.SelectTitleAndEndorsementFees();
                FastDriver.FileFees.CalculateFees.FAClick();
                Reports.TestStep = "Add the Owner Policy and the associated Rate Type";
                FastDriver.CalculateFees.SelectTitleAndEndorsement("ALTA Standard Owner Policy");
                FastDriver.CalculateFees.Next.FAClick();
                Reports.TestStep = "Add the Fee Description and Charge To on the Calculation Summary Screen";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SelectFeeFromSummaryTableBasedOnFeeType();
                FastDriver.CalculateFees.SelectFASTFeeDescAndChargeTo("ALTA Standard Owner Policy", "", "", "Buyer", "", "");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to OTC Screen";
                FastDriver.OTCDetail.Open();
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideTitleCompanyDetail.FindGAB("247");
                Reports.TestStep = "Enter Buyer Charge and Seller Charge and Click on the PDD for Lender policy";
                FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable.Highlight();
                FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable, "Title - Lender Policy", 20, null, 10, null, null);
                FastDriver.OutsideTitleCompanyDetail.PDDlendersPolicyandEndorsements.Highlight();
                FastDriver.OutsideTitleCompanyDetail.PDDlendersPolicyandEndorsements.FAClick();
                Reports.TestStep = "Verify that the Primary Policy CheckBox is checked and disabled indicating the Lender Policy on OTC Screen is Primary";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Selected.ToString());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Enabled.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Verify for the description and the DOP values on OTC";
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                Support.AreEqual("Title - Lender Policy", FastDriver.OutsideTitleCompanyDetail.OTCLenderPolicyName.FAGetText());
                Support.AreEqual("ALTA Extended Owners 1992 (1402.92)", FastDriver.OutsideTitleCompanyDetail.OTCOwnerPolicyName.FAGetText());
                Support.AreEqual("$833.00", FastDriver.OutsideTitleCompanyDetail.OTCDisclosedOwnerPremium.FAGetValue());
                Support.AreEqual("False", FastDriver.OutsideTitleCompanyDetail.OTCDisclosedOwnerPremium.Enabled.ToString());

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0019()
        {
            try
            {
                Reports.TestDescription = "User Story- 740222(Test Case 772354): User Story- 740222: Verify that, the user is prevented only for FACC fees only.";
                Reports.TestStep = "Login to Fast IIS Application";
                _IISLOGIN();


                Reports.TestStep = "Create a file with Owner and Lender Policy Liability Amounts";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)200000;
                fileRequest.File.FirstNewLoanAmount = (decimal)100000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Playback.Wait(500);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                FastDriver.FileHomepage.AddFileProduct("*ALTA Homeowners (Eagle Owner) Policy");
                Reports.TestStep = "Navigate to Fee Entry(File Fees) Screen";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.SelectTitleAndEndorsementFees();
                FastDriver.FileFees.CalculateFees.FAClick();
                Reports.TestStep = "Add the Lender and the associated Rate Type";
                FastDriver.CalculateFees.SelectTitleAndEndorsement();
                FastDriver.CalculateFees.Next.FAClick();
                Reports.TestStep = "Add the Fee Description and Charge To on the Calculation Summary Screen";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SelectFeeFromSummaryTableBasedOnFeeType();
                FastDriver.CalculateFees.SelectFASTFeeDescAndChargeTo("ALTA Expanded (Eagle Loan) Policy", "", "", "Buyer", "", "");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "User navigates to File Fees Screen and Adds an Owner Non-FACC Fee and enter charges for the Owner Non-FACC Fee";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddTitleAndScrowFee("Title - Owners Policy", "ALTA Std Owner Policy 1402.06 (6-17-06)", null);
                FastDriver.FileFees.Open();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "ALTA Std Owner Policy 1402.06 (6-17-06)", "Buyer Charge", TableAction.SetText, "20");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to OTC Screen";
                FastDriver.OTCDetail.Open();
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideTitleCompanyDetail.FindGAB("247");
                Reports.TestStep = "Enter Buyer Charge and Seller Charge for the Lender Policy and Click on the PDD";
                FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable.Highlight();
                FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable, "Title - Lender Policy", 20, null, 15, null, null);
                FastDriver.OutsideTitleCompanyDetail.PDDlendersPolicyandEndorsements.Highlight();
                FastDriver.OutsideTitleCompanyDetail.PDDlendersPolicyandEndorsements.FAClick();
                Reports.TestStep = "Check the Primary Policy CheckBox in the PDD and Verify that User cannot make this Lender Policy on OTC as Primary since we already have a FACC Lender Policy Fee";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Highlight();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.FASetCheckbox(true);
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("A Primary Policy is calculated on the Fee Entry screen and must be removed to select a Primary Policy on the Outside Title Company screen.");
                Reports.TestStep = "Verify that Primary Policy CheckBox is unchecked";
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Selected.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Enter Buyer Charge and Seller Charge for the Owner Policy and Click on the PDD";
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.Highlight();
                FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable, "Title - Owner Policy (Optional)", 30, null, 40, null, null);
                FastDriver.OutsideTitleCompanyDetail.PDDOwnersPolicyandEndorsements.Highlight();
                FastDriver.OutsideTitleCompanyDetail.PDDOwnersPolicyandEndorsements.FAClick();
                Reports.TestStep = "Check the Primary Policy CheckBox in the PDD and Verify that User can make this Owner Policy on OTC as Primary since we  have a Non-FACC Owner Policy Fee on Fee Entry screen";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Highlight();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.FASetCheckbox(true);

                FastDriver.DialogBottomFrame.ClickYes();

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideTitleCompanyDetail.PDDOwnersPolicyandEndorsements.Highlight();
                FastDriver.OutsideTitleCompanyDetail.PDDOwnersPolicyandEndorsements.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Reports.TestStep = "Verify that Primary Policy CheckBox is checked and disabled";
                //FastDriver.PaymentDetailsDlg.SwitchToContentFrame();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Highlight();
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Selected.ToString());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Enabled.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0024_REG0020()
        {
            try
            {
                Reports.TestDescription = "User Story- 740222(Test Case 770316 and 783800): Verify that, user is prevented from checking the Primary Policy checkbox on the OTC (Lender and Owner) Policy.";
                string LenderPolicy = "ALTA Extended Loan Policy 1992 (LP-10 Re-issue)", OwnerPolicy = "CLTA Standard Coverage 1084 1990";


                Reports.TestStep = "Login to Fast IIS Application";
                _IISLOGIN();


                Reports.TestStep = "Create a file with Owner and Lender Policy Liability Amounts";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)200000;
                fileRequest.File.FirstNewLoanAmount = (decimal)100000;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Playback.Wait(500);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                FastDriver.FileHomepage.AddFileProduct("*ALTA Homeowners (Eagle Owner) Policy");
                Reports.TestStep = "Navigate to Fee Entry(File Fees) Screen";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.SelectTitleAndEndorsementFees();
                FastDriver.FileFees.CalculateFees.FAClick();
                Reports.TestStep = "Add the LenderPolicy and the Owner Policy and their associated Rate Type";
                FastDriver.CalculateFees.SelectTitleAndEndorsement("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.CalculateFees.AddSimultaneousProducts(2, "ALTA Standard Owner Policy", "Basic");
                FastDriver.CalculateFees.ClickNext();
                Reports.TestStep = "Add the Fee Description and Charge To on the Calculation Summary Screen";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SelectFeeFromSummaryTableBasedOnFeeType();
                FastDriver.CalculateFees.SelectFASTFeeDescAndChargeTo(LenderPolicy, OwnerPolicy, string.Empty, "Buyer", "Seller", string.Empty);
                //FastDriver.CalculateFees.SelectFASTFeeDescAndChargeTo("ALTA Expanded (Eagle Loan) Policy", "", "", "Buyer", "", "");
                //FastDriver.CalculateFees.SelectFASTFeeDescAndChargeTo("ALTA Standard Owner Policy", "", "", "Seller", "", "");
                //FastDriver.CalculateFees.SelectFASTFeeDescAndChargeTo("ALTA Expanded (Eagle Loan) Policy", "ALTA Standard Owner Policy", "", "Buyer", "Seller", "");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to OTC Screen";
                FastDriver.OTCDetail.Open();
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideTitleCompanyDetail.FindGAB("247");
                Reports.TestStep = "Enter Buyer Charge and Seller Charge and Click on the PDD for Lender Policy";
                FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable.Highlight();
                //FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable, "Title - Lender Policy", 20, null, 10, null, null);
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction(2, 3, TableAction.SetTextByCellIndex, "10.00" + FAKeys.Tab); //Buyer Charge
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction(2, 5, TableAction.SetTextByCellIndex, "20.00" + FAKeys.Tab); //Seller Charge                
                FastDriver.OutsideTitleCompanyDetail.PDDlendersPolicyandEndorsements.Highlight();
                FastDriver.OutsideTitleCompanyDetail.PDDlendersPolicyandEndorsements.FAClick();
                Reports.TestStep = "Check the Primary Policy CheckBox in the PDD for Lender Policy";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Highlight();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.FASetCheckbox(true);
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("A Primary Policy is calculated on the Fee Entry screen and must be removed to select a Primary Policy on the Outside Title Company screen.");

                Reports.TestStep = "Verify that Primary Policy CheckBox is unchecked";
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Selected.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Enter Buyer Charge and Seller Charge and Click on the PDD for Owner Policy";
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.Highlight();
                //FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable, "Title - Owner Policy (Optional)", 30, null, 40, null, null);
                FastDriver.OTCDetail.OTCOwnerPolicyEndorsementTable.PerformTableAction(2, 3, TableAction.SetTextByCellIndex, "30.00" + FAKeys.Tab); //Buyer Charge
                FastDriver.OTCDetail.OTCOwnerPolicyEndorsementTable.PerformTableAction(2, 5, TableAction.SetTextByCellIndex, "40.00" + FAKeys.Tab); //Seller Charge
                FastDriver.OutsideTitleCompanyDetail.PDDOwnersPolicyandEndorsements.Highlight();
                FastDriver.OutsideTitleCompanyDetail.PDDOwnersPolicyandEndorsements.FAClick();
                Reports.TestStep = "Check the Primary Policy CheckBox in the PDD for Owner Policy";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Highlight();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.FASetCheckbox(true);
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("A Primary Policy is calculated on the Fee Entry screen and must be removed to select a Primary Policy on the Outside Title Company screen.");

                Reports.TestStep = "Verify that Primary Policy CheckBox is unchecked";
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Selected.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Navigate to Fee Entry Screen and Uncheck the Lender Policy and the Owner Policy";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(false);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to OTC Scren";
                FastDriver.OTCDetail.Open();
                Reports.TestStep = "Check for the Primary Policy CheckBox in the PDD for Owner Policy to be checked and disabled";
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideTitleCompanyDetail.PDDOwnersPolicyandEndorsements.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Highlight();
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Selected.ToString());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Enabled.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Check for the Primary Policy CheckBox in the PDD for Lender Policy to be checked and disabled";
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable.PerformTableAction(2, 3, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Highlight();
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Selected.ToString());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PrimaryPolicyChk.Enabled.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Navigate to Fee Entry Screen and verify the description and DOP";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.SwitchToContentFrame();
                Support.AreEqual("Title - Lender Policy", FastDriver.FileFees.TitleLenderPolicyName.FAGetText());
                Support.AreEqual("Title - Owner Policy (Optional)", FastDriver.FileFees.TitleOwnerPolicyName.FAGetText());
                Support.AreEqual("$100.00", FastDriver.FileFees.OwnerAdjAmnt.FAGetValue());
                Support.AreEqual("False", FastDriver.FileFees.OwnerAdjAmnt.Enabled.ToString());
                Reports.TestStep = "Navigate to OTC Screen and verify the description and DOP";
                FastDriver.OTCDetail.Open();
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                Support.AreEqual("Title - Lender Policy", FastDriver.OutsideTitleCompanyDetail.OTCLenderPolicyName.FAGetText());
                Support.AreEqual("Title - Owner Policy (Optional)", FastDriver.OutsideTitleCompanyDetail.OTCOwnerPolicyName.FAGetText());
                Support.AreEqual("$100.00", FastDriver.OutsideTitleCompanyDetail.OTCDisclosedOwnerPremium.FAGetValue());
                Support.AreEqual("False", FastDriver.OutsideTitleCompanyDetail.OTCDisclosedOwnerPremium.Enabled.ToString());


            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }


        #endregion

        #region - Useful methods

        private void Login(string Key)
        {

            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(Key, credentials, true);
        }

        public static int CreateFile()
        {
            var customFile = RequestFactory.GetCreateFileDefaultRequest();

            try
            {
                int? FileID = FileService.CreateFile(customFile).FileID;
                return (int)FileID;
            }
            catch (Exception)
            {

                throw new Exception("Unable to retrieve FileID.");
            }

        }

        #endregion


        #region PRIVATE METHODS

        private void _IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;// Support.GetRunCategoryOption("WEBSITE", "Home");
            UserName = AutoConfig.UserName;// UserName ?? Support.GetRunOption("User_Name");
            Password = AutoConfig.UserPassword;// Password ?? Support.GetRunOption("User_Password");
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
