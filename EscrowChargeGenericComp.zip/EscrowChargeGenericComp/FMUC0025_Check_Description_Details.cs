﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using AutoIt;
using System.Linq;


namespace EscrowChargeGenericComp
{
    /// <summary>
    /// Summary description for FMUC0025_Check_Description_Details
    /// </summary>
    [CodedUITest]
    public class FMUC0025_Check_Description_Details : MasterTestClass
    {
        #region BAT

        #region Test FMUC0025_BAT0001

        [TestMethod]
        public void FMUC0025_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Add/Edit Check Description Details";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Create an instance of inspection Repair Septic.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").SwitchToContentFrame();
                FastDriver.InspectionRepairSeptic.Name.FASetText(@"Pest 1 for HUD Testing Name 1");
                FastDriver.InspectionRepairSeptic.Find.FAClick();

                FastDriver.InspectionRepairSeptic.Attention.FASelectItem("Contact, Pest 1 for HUD");
                FastDriver.InspectionRepairSeptic.Reference.FASetText("Reference1");
                FastDriver.InspectionRepairSeptic.WithinDays.FASetText("5");
                FastDriver.InspectionRepairSeptic.OrderDate.FASetText("07-10-2012");
                FastDriver.InspectionRepairSeptic.DueDate.FASetText("12-10-2012");
                FastDriver.InspectionRepairSeptic.FollowUpDate.FASetText("10-10-2012");
                FastDriver.InspectionRepairSeptic.CompleteDate.FASetText("04-10-2013");
                FastDriver.InspectionRepairSeptic.ReportDate.FASetText("03-10-2013");
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, "Septic Inspection", editDescription: "SEPTICInspectionDESCRIPTION1", buyerCharge: 55.55, sellerCharge: 66.66);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("Check Amount: $ 122.21", FastDriver.InspectionRepairSeptic.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit the CheckDetails.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").SwitchToContentFrame();
                FastDriver.InspectionRepairSeptic.CheckDetails.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Validate the default for Check Details Dialog.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.WaitCreation(FastDriver.CheckDetailsDlg.Description, 5);
                Support.AreEqual("Inspection and/or Repairs", FastDriver.CheckDetailsDlg.Description.GetAttribute("value").Clean());

                Reports.TestStep = "Edit description in Inspection/Repair Pest.";
                FastDriver.CheckDetailsDlg.Description.FASetText(@"Check Description Edited");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText(@"Voucher info edited for Inpection/Repair Pest");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify pending check to Inspection/Repair.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.CheckAmount.FAClick();
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verify the check voucher info instance of.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Check Description Edited", FastDriver.EditDisbursement.VoucherDescription.GetAttribute("value").Clean());
                Support.AreEqual("Voucher info edited for Inpection/Repair Pest", FastDriver.EditDisbursement.VoucherMemo.GetAttribute("value").Clean());
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion

        #endregion

        #region Regression

        #region Test FMUC0025_REG0001

        [TestMethod]
        public void FMUC0025_REG0001()
        {
            try
            {
                Reports.TestDescription = "1188_1034_3199_1195_1194_1033_1035_2985_1187: Enter the check Description, Verify the default data, Delete the Default data, Veerify and edit description on Edit Disbursement scteen.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();

                Reports.TestStep = "Verify for FileHomePage.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileHomepage.ChangeOO.Displayed.ToString());

                Reports.TestStep = "Navigate to Lease Details screen and Click on New.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Verify that Status email checkbox is unchecked.";
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                Reports.StatusUpdate("WeeklyEmailStatus unchecked? -> " + (!FastDriver.LeaseDetail.WeeklyEmailStatus.Selected).ToString(), 
                    !FastDriver.LeaseDetail.WeeklyEmailStatus.Selected);

                Reports.TestStep = "Checking for check Desc Button Disable, Create Instance with charges so that Check Details Button will be enable.";
                Reports.StatusUpdate("CheckDetails is Disabled? -> " + (!FastDriver.LeaseDetail.CheckDetails.Enabled).ToString(), 
                    !FastDriver.LeaseDetail.CheckDetails.Enabled);
                FastDriver.LeaseDetail.GABcode.FASetText(@"Lease");
                FastDriver.LeaseDetail.Find.FAClick();

                Support.AreEqual("Rent/Lease Payment Due", FastDriver.LeaseDetail.ChargeDescription.GetAttribute("value").Clean());
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify that instance is Created.";
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                Reports.StatusUpdate("CheckDetails is Enabled? -> " + FastDriver.LeaseDetail.CheckDetails.Enabled.ToString(),
                    FastDriver.LeaseDetail.CheckDetails.Enabled);
                Reports.StatusUpdate("GlobalImage is Displayed? -> " + FastDriver.LeaseDetail.GlobalImage.Displayed.ToString(),
                    FastDriver.LeaseDetail.GlobalImage.Displayed);
                Support.AreEqual("LEASE", FastDriver.LeaseDetail.IDCodeLebel.Text.Clean());

                Reports.TestStep = "Click on Check details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.CheckDetails.FAClick();

                Reports.TestStep = "Click on cancel.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.WaitCreation(FastDriver.CheckDetailsDlg.Description, 5);
                FastDriver.DialogBottomFrame.ClickCancel();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active disbursement Summary and select pending check and click on edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                IWebElement element = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.GetCell).Element
                    .FindElements(By.TagName("span")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Support.AreEqual("lease name 1 lease name 2", element.Text.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verify check details.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Funds Due for Lease", FastDriver.EditDisbursement.VoucherDescription.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.EditDisbursement.VoucherMemo.GetAttribute("value").Clean());

                Reports.TestStep = "Click on Check details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.CheckDetails.FAClick();

                Reports.TestStep = "Validate the default for Check Details Dialog for Survey.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.WaitCreation(FastDriver.CheckDetailsDlg.Description, 5);
                Support.AreEqual("Funds Due for Lease", FastDriver.CheckDetailsDlg.Description.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.CheckDetailsDlg.VoucherInfo.GetAttribute("value").Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Check details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.CheckDetails.FAClick();

                Reports.TestStep = "Edit description for REB.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.WaitCreation(FastDriver.CheckDetailsDlg.Description, 5);
                FastDriver.CheckDetailsDlg.Description.FASetText("Description for REB");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Voucher Info for REB");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active disbursement Summary and select pending check and click on edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                element = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.GetCell).Element
                    .FindElements(By.TagName("span")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Support.AreEqual("lease name 1 lease name 2", element.Text.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verify check details after edit on Lease screen.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Description for REB", FastDriver.EditDisbursement.VoucherDescription.GetAttribute("value").Clean());
                Support.AreEqual("Voucher Info for REB", FastDriver.EditDisbursement.VoucherMemo.GetAttribute("value").Clean());

                Reports.TestStep = "Click on Check details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.CheckDetails.FAClick();

                Reports.TestStep = "Edit Check Desc And Voucher Information for Lease and save changes.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.WaitCreation(FastDriver.CheckDetailsDlg.Description, 5);
                FastDriver.CheckDetailsDlg.Description.FASetText("Edited Funds Due for Lease.");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Check Boucher Description.");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to Active disbursement Summary and select pending check and click on edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                element = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.GetCell).Element
                    .FindElements(By.TagName("span")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Support.AreEqual("lease name 1 lease name 2", element.Text.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verify for the Edited Check Details and Voucher Information entered on Lease Screen.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Edited Funds Due for Lease.", FastDriver.EditDisbursement.VoucherDescription.GetAttribute("value").Clean());
                Support.AreEqual("Check Boucher Description.", FastDriver.EditDisbursement.VoucherMemo.GetAttribute("value").Clean());

                Reports.TestStep = "Click on Check details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.CheckDetails.FAClick();

                Reports.TestStep = "Delete charge description and Voucher information.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.WaitCreation(FastDriver.CheckDetailsDlg.Description, 5);
                FastDriver.CheckDetailsDlg.Description.FASetText("");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to Active disbursement Summary and select pending check and click on edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                element = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.GetCell).Element
                    .FindElements(By.TagName("span")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Support.AreEqual("lease name 1 lease name 2", element.Text.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verify check details after delete on Lease screen.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.EditDisbursement.VoucherDescription.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.EditDisbursement.VoucherMemo.GetAttribute("value").Clean());

                Reports.TestStep = "Navigate to Lease detail screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                Reports.TestStep = "Click on Check details.";
                FastDriver.LeaseDetail.CheckDetails.FAClick();

                Reports.TestStep = "Validate that Check Description and Voucher Info got deleted.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.WaitCreation(FastDriver.CheckDetailsDlg.Description, 5);
                Support.AreEqual("", FastDriver.CheckDetailsDlg.Description.GetAttribute("value").Clean());
                Support.AreEqual("", FastDriver.CheckDetailsDlg.VoucherInfo.GetAttribute("value").Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Check details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.CheckDetails.FAClick();

                Reports.TestStep = "Edit Check Desc And Voucher Information for Lease and save changes.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.WaitCreation(FastDriver.CheckDetailsDlg.Description, 5);
                FastDriver.CheckDetailsDlg.Description.FASetText("Edited Funds Due for Lease.");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Check Boucher Description.");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to Active disbursement Summary and select pending check and click on edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                element = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.GetCell).Element
                    .FindElements(By.TagName("span")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Support.AreEqual("lease name 1 lease name 2", element.Text.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verify for the Edited Check Details and Voucher Information entered on Lease Screen.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Edited Funds Due for Lease.", FastDriver.EditDisbursement.VoucherDescription.GetAttribute("value").Clean());
                Support.AreEqual("Check Boucher Description.", FastDriver.EditDisbursement.VoucherMemo.GetAttribute("value").Clean());

                Reports.TestStep = "Navigate to Lease detail screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                Reports.TestStep = "Verify that instance is Created.";
                Reports.StatusUpdate("CheckDetails is Enabled? -> " + FastDriver.LeaseDetail.CheckDetails.Enabled.ToString(), FastDriver.LeaseDetail.CheckDetails.Enabled);
                Reports.StatusUpdate("GlobalImage is Enabled? -> " + FastDriver.LeaseDetail.GlobalImage.Enabled.ToString(), FastDriver.LeaseDetail.GlobalImage.Enabled);
                Support.AreEqual("LEASE", FastDriver.LeaseDetail.IDCodeLebel.Text.Clean());

                Reports.TestStep = "Navigate to Active disbursement Summary and select pending check and click on edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                element = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.GetCell).Element
                    .FindElements(By.TagName("span")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Support.AreEqual("lease name 1 lease name 2", element.Text.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verify for the Edited Check Details and Voucher Information entered on Lease Screen.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Edited Funds Due for Lease.", FastDriver.EditDisbursement.VoucherDescription.GetAttribute("value").Clean());
                Support.AreEqual("Check Boucher Description.", FastDriver.EditDisbursement.VoucherMemo.GetAttribute("value").Clean());

                Reports.TestStep = "Edit the Check Description and Voucher Description.";
                FastDriver.EditDisbursement.VoucherDescription.FASetText("Edited Funds Due for Lease from Edit Disb.");
                FastDriver.EditDisbursement.VoucherMemo.FASetText("Check Boucher Description from Edit Disb Screen.");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to Lease detail screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                Reports.TestStep = "Click on Check details.";
                FastDriver.LeaseDetail.CheckDetails.FAClick();

                Reports.TestStep = "Validate that Check Description and Voucher edited on Edit disb Screen.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.WaitCreation(FastDriver.CheckDetailsDlg.Description, 5);
                Support.AreEqual("Edited Funds Due for Lease from Edit Disb.", FastDriver.CheckDetailsDlg.Description.GetAttribute("value").Clean());
                Support.AreEqual("Check Boucher Description from Edit Disb Screen.", FastDriver.CheckDetailsDlg.VoucherInfo.GetAttribute("value").Clean());
                FastDriver.CheckDetailsDlg.Description.FASetText("Edited Funds Due for Lease.");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Check Boucher Description.");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #region Test FMUC0025_REG0002

        [TestMethod]
        public void FMUC0025_REG0002()
        {
            try
            {
                Reports.TestDescription = "FIELD_DEFINATION: Verify the Fields of check description Dialog and edit disbursement screen.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                CreateFile();
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileHomepage.ChangeOO.Displayed.ToString());
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.GABcode.FASetText(@"Lease");
                FastDriver.LeaseDetail.Find.FAClick();
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.LeaseDetail.CheckDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.WaitCreation(FastDriver.CheckDetailsDlg.Description, 5);
                FastDriver.CheckDetailsDlg.Description.FASetText("Edited Funds Due for Lease.");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Check Boucher Description.");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Lease detail screen.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                Reports.TestStep = "Click on Check details.";
                FastDriver.LeaseDetail.CheckDetails.FAClick();

                Reports.TestStep = "Delete charge description and Voucher information.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.WaitCreation(FastDriver.CheckDetailsDlg.Description, 5);
                FastDriver.CheckDetailsDlg.Description.FASetText("");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Check details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.CheckDetails.FAClick();

                Reports.TestStep = "Enter 45 Characters in Check Description Field.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.WaitCreation(FastDriver.CheckDetailsDlg.Description, 5);
                FastDriver.CheckDetailsDlg.Description.FASetText("abcdefghij1234567896!@X$YY&*()abcdefghij12345");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcde");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Check details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.CheckDetails.FAClick();

                Reports.TestStep = "Verify the Field Definition.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.WaitCreation(FastDriver.CheckDetailsDlg.Description, 5);
                Support.AreEqual("abcdefghij1234567896!@X$YY&*()abcdefghij12345", FastDriver.CheckDetailsDlg.Description.GetAttribute("value").Clean());
                Support.AreEqual("abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcde", FastDriver.CheckDetailsDlg.VoucherInfo.GetAttribute("value").Clean());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to Active disbursement Summary and select pending check and click on edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                IWebElement element = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.GetCell).Element
                    .FindElements(By.TagName("span")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Support.AreEqual("lease name 1 lease name 2", element.Text.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Validate the field definition for check Details.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("abcdefghij1234567896!@X$YY&*()abcdefghij12345", FastDriver.EditDisbursement.VoucherDescription.GetAttribute("value").Clean());
                Support.AreEqual("abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcdefghij1234567896!@X$%Y&*()abcdefghij1234567896abcde", FastDriver.EditDisbursement.VoucherMemo.GetAttribute("value").Clean());

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion
        #endregion

        #region HelpMethods

        private static void CreateFile(string TransactionType = "SALE", string BusinessSegment = "RESIDENTAL", string BusSourceGabCode = "HUDFLINSR1", string DirectebyIDCode = "HUDLEASE03",
            string NewLoanIDCode = "247", string AssBusPartyIDCode = "HUDASLNDR1")
        {
            CreateFileRequest fileRequest = new CreateFileRequest();
            fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            fileRequest.File.BusinessParties = new FileBusinessParty[]
            {
                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(BusSourceGabCode),   // HUDFLINSR1
                    RoleTypeObjectCD = "BUSSOURCE",
                    CustomerReferenceNumber = "1234567890",
                    AdditionalRole = new AdditionalRoleList() { eAddtionalRole = AdditionalRoleType.NewLender }
                },

                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(DirectebyIDCode),   // HUDLEASE03
                    RoleTypeObjectCD = "DirectedBy"
                },

                new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId(AssBusPartyIDCode), // HUDASLNDR1
                    RoleTypeObjectCD = "ASSOTDPTY"
                }
            };

            fileRequest.File.BusinessSegmentObjectCD = BusinessSegment; // RESIDENTIAL
            fileRequest.File.TransactionTypeObjectCD = TransactionType; // REFI           
            fileRequest.File.NewLoan.FileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId(NewLoanIDCode);  // 247

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
