﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System.Diagnostics;
using System;
using System.Collections.Generic;
using System.Windows.Input;
using FASTWCFHelpers.FastFileService;
using System.Text.RegularExpressions;

namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0060 : FASTHelpers
    {
        #region Custom Methods
        private string HandleDialogMessage(bool switchBackToFastWindow = true, bool clickAcceptButton = true, int timeout = 5, bool retryWithAutoIT = true)
        {
            var message = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow, clickAcceptButton, timeout, retryWithAutoIT);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.InterestBearingAccounts.SwitchToContentFrame();

            return message;
        }
        #endregion

        #region BAT
        [TestMethod]
        [Description("MF_001A_AF4: Open an IBA")]
        public void FMUC0060_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF_001A_AF4: Open an IBA";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: true, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                //
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var dateCreated = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                var transactionId = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                var docNo = FastDriver.InterestBearingAccounts.TransactionDocNum.FAGetText();
                #endregion

                #region Verify and validate the open IBA created
                Reports.TestStep = "Verify and validate the open IBA created";
                FastDriver.InterestBearingAccounts.Open();
                Support.AreEqual("01  Buyer1Firstname Buyer1Lastname  First American Trust, FSB  200.00  Open", FastDriver.InterestBearingAccounts.RecordSummaryTable.FAGetText(), "1st IBA Record");
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                Support.Match("Open IBA " + transactionId + " " + docNo + " 200\\.00 200\\.00 Pending Approval " + dateCreated + " USER ID: FASTTS\\\\FASTQA07", FastDriver.InterestBearingAccounts.TransactionTable.FAGetText(), "1st IBA Transaction");
                #endregion

                #region Verify IBA transaction status
                Reports.TestStep = "Verify IBA transaction status";
                FastDriver.InterestBearingAccounts.TransactionStatus.FAClick();
                FastDriver.IBATransactionStatusDlg.WaitForScreenToLoad();
                Support.stringHelper = new StringHelper() { NBSP = false, SP = true, CR = false, LF = false, SingleSP = true };
                Support.Match("Added " + dateCreated + " USER ID: FASTTS\\\\FASTQA07", FastDriver.IBATransactionStatusDlg.lblTransactionStatus.FAGetText().Clean(), "Transaction Status Label [0]");
                Support.Match("Pending Approval " + dateCreated + " USER ID: FASTTS\\\\FASTQA07", FastDriver.IBATransactionStatusDlg.lblTransactionStatus.FAGetText().Clean(), "Transaction Status Label [1]");
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("MF_001B_AF4: Verify for the event")]
        public void FMUC0060_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF_001B_AF4: Verify for the event";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var docNo = FastDriver.InterestBearingAccounts.TransactionDocNum.FAGetText();
                #endregion

                #region Deliver IBA transaction
                Reports.TestStep = "Deliver IBA transaction";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                var dateStarted = DateTime.UtcNow.ToPST().ToString("MM/dd/yyyy hh:'[0-9]{2}' tt 'PST'");
                FastDriver.PrintDlg.SendPrint("TEXT_FILE_PRINTER");
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 10000);
                var dateCompleted = DateTime.UtcNow.ToPST().ToString("MM/dd/yyyy hh:'[0-9]{2}' tt 'PST'");
                #endregion

                #region Verify the Print Delivery of IBA transaction in Event/Tracking Log
                Reports.TestStep = "Verify the Print Delivery of IBA transaction in Event/Tracking Log";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                Support.AreEqual("[Print]", FastDriver.EventTrackingLog.EventName.FAGetText(), "[0] EventName");
                Support.Match(dateStarted, FastDriver.EventTrackingLog.StartDate.FAGetText(), "[0] StartDate");
                Support.Match(dateCompleted, FastDriver.EventTrackingLog.CompletionDate.FAGetText(), "[0] CompletionDate");
                Support.AreEqual("Print Service", FastDriver.EventTrackingLog.Source0.FAGetText(), "[0] Source");
                Support.Match("File Number: " + File.FileNumber, FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : File Number");
                Support.Match("User Name: QA07, FAST", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : User Name");
                Support.Match("Documents: IBA Transaction Detail Report", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : Documents");
                Support.Match("Delivery Method: Print", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : Delivery Method");
                Support.Match("Delivery Status: Delivery Successful", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : Delivery Status");
                Support.Match("Imaging in Progress", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : Status");
                Support.Match("IBA Transaction Detail Report : ImageDoc Successful", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : IBA Transaction Detail Report");
                Support.AreEqual("FAST QA07", FastDriver.EventTrackingLog.User0.FAGetText(), "[0] User");
                #endregion

                #region Validate current available funds and IBA amount in File Business Summary
                Reports.TestStep = "Validate current available funds and IBA amount in File Business Summary";
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual("8,000.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText(), "EscrowFileBalanceSummary.NetDepositTotal");
                Support.AreEqual("200.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText(), "EscrowFileBalanceSummary.NetTotalDisbursements");
                Support.AreEqual("7,800.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText(), "EscrowFileBalanceSummary.CurrentAvailableFunds");
                #endregion

                #region Verify the Issued IBA disbursement in Active Disbursement Summary
                Reports.TestStep = "Verify the Issued IBA disbursement in Active Disbursement Summary";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.Match("Issued", FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] State");
                Support.Match("IBA", FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Funds");
                Support.Match(docNo, FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Document#");
                Support.Match(DateTime.Today.ToDateString(), FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Issue Date");
                Support.Match("200.00", FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Amount");
                Support.Match("IBA# fbo Buyer1Firstname Buyer1Lastname", FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Payee");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("MF_001B: Approve Open IBA")]
        public void FMUC0060_BAT0003()
        {
            try
            {
                Reports.TestDescription = "MF_001B: Approve Open IBA";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var transactionId = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                #endregion

                #region FAST Login IIS side with User_Name1
                Reports.TestStep = "FAST Login IIS side with User_Name1";
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };
                var url = AutoConfig.FASTHomeURL;
                FASTLogin.Login(url, credentials, true);
                #endregion

                #region Approve the IBA transaction
                Reports.TestStep = "Approve the IBA transaction"; 
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>("Home>Business Unit Processing>IBA Interface>IBA Transaction Approval");
                Playback.Wait(15000);
                FastDriver.IBATransactionApproval.WaitForScreenToLoad();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(3, transactionId, 1, TableAction.On);
                FastDriver.IBATransactionApproval.Approve.FAClick();
                Reports.StatusUpdate(this.HandleDialogMessage(true, true), true);
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [TestMethod]
        [Description("MF_001C: Verify Approved status for Open IBA")]
        public void FMUC0060_BAT0004()
        {
            try
            {
                Reports.TestDescription = "MF_001C: Verify Approved status for Open IBA";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var dateCreated = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                var transactionId = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                #endregion

                #region FAST Login IIS side with User_Name1
                Reports.TestStep = "FAST Login IIS side with User_Name1";
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };
                var url = AutoConfig.FASTHomeURL;
                FASTLogin.Login(url, credentials, true);
                #endregion

                #region Approve the IBA transaction
                Reports.TestStep = "Approve the IBA transaction";
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>("Home>Business Unit Processing>IBA Interface>IBA Transaction Approval");
                Playback.Wait(15000);
                FastDriver.IBATransactionApproval.WaitForScreenToLoad();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(3, transactionId, 1, TableAction.On);
                FastDriver.IBATransactionApproval.Approve.FAClick();
                Reports.StatusUpdate(this.HandleDialogMessage(true, true), true);
                var dateApprovedSent = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                Playback.Wait(3000);
                #endregion

                #region FAST Login IIS side with User_Name (file creator)
                Reports.TestStep = "FAST Login IIS side with User_Name (file creator)";
                FAST_Login_IIS(int.Parse(File.FileNumber));
                #endregion

                #region Verify the Approved Status for the IBA transaction
                Reports.TestStep = "Verify the Approved Status for the IBA transaction";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionStatus.FAClick();
                FastDriver.IBATransactionStatusDlg.WaitForScreenToLoad();
                Support.stringHelper = new StringHelper() { NBSP = false, SP = true, CR = false, LF = false, SingleSP = true };
                Support.Match("Added " + dateCreated + " USER ID: FASTTS\\\\FASTQA07", FastDriver.IBATransactionStatusDlg.lblTransactionStatus.FAGetText(), "Transaction Status Label [0]");
                Support.Match("Approved " + dateApprovedSent + " USER ID: FASTTS\\\\FASTQA06", FastDriver.IBATransactionStatusDlg.lblTransactionStatus.FAGetText(), "Transaction Status Label [1]");
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Change Beneficiary Information on IBA in ‘Open’ IBA Status")]
        public void FMUC0060_BAT0005()
        {
            try
            {
                Reports.TestDescription = "Change Beneficiary Information on IBA in ‘Open’ IBA Status";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                //
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                //var dateCreated = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:mm tt");
                var dateCreated = DateTime.Now.ToString("MM-dd-yyyy hh:mm tt");
                var transactionId = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                var docNo = FastDriver.InterestBearingAccounts.TransactionDocNum.FAGetText();
                #endregion

                #region Verify and validate the open IBA created
                Reports.TestStep = "Verify and validate the open IBA created";
                FastDriver.InterestBearingAccounts.Open();
                Support.stringHelper = new StringHelper() { NBSP = false, SP = true, CR = false, LF = false, SingleSP = true };
                Support.AreEqual("01  Buyer1Firstname Buyer1Lastname  First American Trust, FSB  200.00  Open", FastDriver.InterestBearingAccounts.RecordSummaryTable.FAGetText(), "1st IBA Record");
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                Support.AreEqual("Pending Approval " + DateTime.Now.ToDateString(), FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, "Open IBA", 6, TableAction.GetText).Message.Clean().Substring(0, 27), "1st IBA Transaction");
                #endregion

                #region Edit the Buyer type to Business Entity
                Reports.TestStep = "Edit the Buyer type to Business Entity";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Business Entity");
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("BuyerName");
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("12-3456789");
                FastDriver.BottomFrame.Done();
                //
                FastDriver.ReasonforchangeDlg.WaitForDialogToLoad();
                FastDriver.ReasonforchangeDlg.SetFields("Other", "FMUC0060_BAT0005");
                FastDriver.ReasonforchangeDlg.ClickOk();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                var dateEdited = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                #endregion

                #region Verify change on beneficiary information on IBA
                Reports.TestStep = "Verify change on beneficiary information on IBA";
                FastDriver.InterestBearingAccounts.Open();
                Support.AreEqual("01  BuyerName  First American Trust, FSB  200.00  Open", FastDriver.InterestBearingAccounts.RecordSummaryTable.FAGetText(), "1st IBA Record");
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                //var transactionId2 = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                //Support.Match("Change\\/Correct Beneficiary " + transactionId2 + " N\\/A 0\\.00 200\\.00 Pending Approval " + dateEdited + " USER ID: FASTTS\\\\FASTQA07", FastDriver.InterestBearingAccounts.TransactionTable.FAGetText(), "1st IBA Transaction");
                Support.AreEqual("Pending Approval " + DateTime.Now.ToDateString(), FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, @"Change/Correct Beneficiary", 6, TableAction.GetText).Message.Clean().Substring(0, 27), "1st IBA Transaction");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("AF8B: Approve Change Beneficiary")]
        public void FMUC0060_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF8B: Approve Change Beneficiary";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                #endregion

                #region Edit the Buyer type to Business Entity
                Reports.TestStep = "Edit the Buyer type to Business Entity";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Business Entity");
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("BuyerName");
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("12-3456789");
                FastDriver.BottomFrame.Done();
                //
                FastDriver.ReasonforchangeDlg.WaitForDialogToLoad();
                FastDriver.ReasonforchangeDlg.SetFields("Other", "FMUC0060_BAT0006 AF8B");
                FastDriver.ReasonforchangeDlg.ClickOk();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                var dateEdited = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                #endregion

                #region Validate change on IBA Beneficiary information
                Reports.TestStep = "Validate change on IBA Beneficiary information";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                var transactionId2 = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                #endregion

                #region FAST Login IIS side with User_Name1
                Reports.TestStep = "FAST Login IIS side with User_Name1";
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };
                var url = AutoConfig.FASTHomeURL;
                FASTLogin.Login(url, credentials, true);
                #endregion

                #region Approve the IBA transaction
                Reports.TestStep = "Approve the IBA transaction";
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>("Home>Business Unit Processing>IBA Interface>IBA Transaction Approval");
                Playback.Wait(15000);
                FastDriver.IBATransactionApproval.WaitForScreenToLoad();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(3, transactionId2, 1, TableAction.On);
                FastDriver.IBATransactionApproval.Approve.FAClick();
                Reports.StatusUpdate(this.HandleDialogMessage(true, true), true);
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("AF8C: Verify Approved status for Change Beneficiary")]
        public void FMUC0060_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF8C: Verify Approved status for Change Beneficiary";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var dateCreated = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                #endregion

                #region Edit the Buyer type to Business Entity
                Reports.TestStep = "Edit the Buyer type to Business Entity";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Business Entity");
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("BuyerName");
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("12-3456789");
                FastDriver.BottomFrame.Done();
                //
                FastDriver.ReasonforchangeDlg.WaitForDialogToLoad();
                FastDriver.ReasonforchangeDlg.SetFields("Other", "FMUC0060_BAT0007 AF8C");
                FastDriver.ReasonforchangeDlg.ClickOk();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                var dateEdited = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                #endregion

                #region Validate change on IBA Beneficiary information
                Reports.TestStep = "Validate change on IBA Beneficiary information";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                var transactionId2 = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                #endregion

                #region FAST Login IIS side with User_Name1
                Reports.TestStep = "FAST Login IIS side with User_Name1";
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };
                var url = AutoConfig.FASTHomeURL;
                FASTLogin.Login(url, credentials, true);
                #endregion

                #region Approve the IBA transaction
                Reports.TestStep = "Approve the IBA transaction";
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>("Home>Business Unit Processing>IBA Interface>IBA Transaction Approval");
                Playback.Wait(15000);
                FastDriver.IBATransactionApproval.WaitForScreenToLoad();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(3, transactionId2, 1, TableAction.On);
                FastDriver.IBATransactionApproval.Approve.FAClick();
                Reports.StatusUpdate(this.HandleDialogMessage(true, true), true);
                var dateApprovedSent = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                Playback.Wait(3000);
                #endregion

                #region FAST Login IIS side with User_Name (file creator)
                Reports.TestStep = "FAST Login IIS side with User_Name (file creator)";
                FAST_Login_IIS(int.Parse(File.FileNumber));
                #endregion

                #region Verify the Approved Status for the IBA transaction
                Reports.TestStep = "Verify the Approved Status for the IBA transaction";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                Support.stringHelper = new StringHelper() { NBSP = false, SP = true, CR = false, LF = false, SingleSP = true };
                Support.Match("Approved " + dateCreated + " USER ID: FASTTS\\\\FASTQA06", FastDriver.InterestBearingAccounts.TransactionTransactionStatusPane.FAGetText(), "Transaction Status [0]");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        //  Place Holders from FMUC0060_BAT0008 - FMUC0060_BAT0018
        #endregion

        #region REG
        [TestMethod]
        [Description("BR_ES9117A: Allow IBA creation in Title&Escrow file")]
        public void FMUC0060_REG0001()
        {
            try
            {
                Reports.TestDescription = "BR_ES9117A: Allow IBA creation in Title&Escrow file";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: true, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                //
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var dateCreated = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                var transactionId = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                var docNo = FastDriver.InterestBearingAccounts.TransactionDocNum.FAGetText();
                #endregion

                #region Verify and validate the open IBA created
                Reports.TestStep = "Verify and validate the open IBA created";
                FastDriver.InterestBearingAccounts.Open();
                Support.AreEqual("01  Buyer1Firstname Buyer1Lastname  First American Trust, FSB  200.00  Open", FastDriver.InterestBearingAccounts.RecordSummaryTable.FAGetText(), "1st IBA Record");
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                Support.Match("Open IBA " + transactionId + " " + docNo + " 200\\.00 200\\.00 Pending Approval " + dateCreated + " USER ID: FASTTS\\\\FASTQA07", FastDriver.InterestBearingAccounts.TransactionTable.FAGetText(), "1st IBA Transaction");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES9117B: Allow IBA creation in Title&SubEscrow file")]
        public void FMUC0060_REG0002()
        {
            try
            {
                Reports.TestDescription = "BR_ES9117B: Allow IBA creation in Title&SubEscrow file";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: true, isEO: false, isSEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                //
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var dateCreated = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                var transactionId = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                var docNo = FastDriver.InterestBearingAccounts.TransactionDocNum.FAGetText();
                #endregion

                #region Verify and validate the open IBA created
                Reports.TestStep = "Verify and validate the open IBA created";
                FastDriver.InterestBearingAccounts.Open();
                Support.AreEqual("01  Buyer1Firstname Buyer1Lastname  First American Trust, FSB  200.00  Open", FastDriver.InterestBearingAccounts.RecordSummaryTable.FAGetText(), "1st IBA Record");
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                Support.Match("Open IBA " + transactionId + " " + docNo + " 200\\.00 200\\.00 Pending Approval " + dateCreated + " USER ID: FASTTS\\\\FASTQA07", FastDriver.InterestBearingAccounts.TransactionTable.FAGetText(), "1st IBA Transaction");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES9117C: Allow IBA creation in Escrow file")]
        public void FMUC0060_REG0003()
        {
            try
            {
                Reports.TestDescription = "BR_ES9117C: Allow IBA creation in Escrow file";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true, isSEO: false);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                //
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var dateCreated = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                var transactionId = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                var docNo = FastDriver.InterestBearingAccounts.TransactionDocNum.FAGetText();
                #endregion

                #region Verify and validate the open IBA created
                Reports.TestStep = "Verify and validate the open IBA created";
                FastDriver.InterestBearingAccounts.Open();
                Support.AreEqual("01  Buyer1Firstname Buyer1Lastname  First American Trust, FSB  200.00  Open", FastDriver.InterestBearingAccounts.RecordSummaryTable.FAGetText(), "1st IBA Record");
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                Support.Match("Open IBA " + transactionId + " " + docNo + " 200\\.00 200\\.00 Pending Approval " + dateCreated + " USER ID: FASTTS\\\\FASTQA07", FastDriver.InterestBearingAccounts.TransactionTable.FAGetText(), "1st IBA Transaction");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES9117D: Allow IBA creation in Escrow&SubEscrow file")]
        public void FMUC0060_REG0004()
        {
            try
            {
                Reports.TestDescription = "BR_ES9117D: Allow IBA creation in Escrow&SubEscrow file";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true, isSEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                //
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var dateCreated = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                var transactionId = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                var docNo = FastDriver.InterestBearingAccounts.TransactionDocNum.FAGetText();
                #endregion

                #region Verify and validate the open IBA created
                Reports.TestStep = "Verify and validate the open IBA created";
                FastDriver.InterestBearingAccounts.Open();
                Support.AreEqual("01  Buyer1Firstname Buyer1Lastname  First American Trust, FSB  200.00  Open", FastDriver.InterestBearingAccounts.RecordSummaryTable.FAGetText(), "1st IBA Record");
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                Support.Match("Open IBA " + transactionId + " " + docNo + " 200\\.00 200\\.00 Pending Approval " + dateCreated + " USER ID: FASTTS\\\\FASTQA07", FastDriver.InterestBearingAccounts.TransactionTable.FAGetText(), "1st IBA Transaction");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES9117E: Restrict IBA creation in Title file")]
        public void FMUC0060_REG0005()
        {
            try
            {
                Reports.TestDescription = "BR_ES9117E: Restrict IBA creation in Title file";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: true, isEO: false, isSEO: false);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Try to add a Deposit In Escrow and verify it fails
                Reports.TestStep = "Try to add a Deposit In Escrow and verify it fails";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                Reports.StatusUpdate(this.HandleDialogMessage(true, true), true);
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.New.FAClick();
                Reports.StatusUpdate(this.HandleDialogMessage(true, true), true);
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES9119: Apply View Buyer/Seller SSN Security Activity")]
        public void FMUC0060_REG0006()
        {
            try
            {
                Reports.TestDescription = "BR_ES9119: Apply View Buyer/Seller SSN Security Activity";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select Other as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.ViewEdit.FAClick();
                Support.AreEqual("123-45-6789", FastDriver.InterestBearingAccounts.SSNTIN.FAGetValue(), "SSN/TIN View/Edit Input");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES9121: Prevent IBA Transaction Amount File Overdraft")]
        public void FMUC0060_REG0007()
        {
            try
            {
                Reports.TestDescription = "BR_ES9121: Prevent IBA Transaction Amount File Overdraft";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10000");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Reports.StatusUpdate(this.HandleDialogMessage(true, true), true);
                Support.AreEqual("0.00", FastDriver.InterestBearingAccounts.TransactionAmount.FAGetValue(), "TransactionAmount : Exceeded Available Funds : 10000");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES9141: Prevent Save for XML-incompatible Special Characters")]
        public void FMUC0060_REG0008()
        {
            try
            {
                Reports.TestDescription = "BR_ES9141: Prevent Save for XML-incompatible Special Characters";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = @"~ ` ! @ ^ & * [ { ]|",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: @"~ ` ! @ ^ & * [ { ]| Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.StatusUpdate(FastDriver.WebDriver.HandleDialogMessage(false, true), true);
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES9145: Prevent IBA Bank and IBA Type Changes")]
        public void FMUC0060_REG0009()
        {
            try
            {
                Reports.TestDescription = "BR_ES9145: Prevent IBA Bank and IBA Type Changes";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify IBA Beneficiary/Bank/Type cannot be changed for an open IBA transactions
                Reports.TestStep = "Verify IBA Beneficiary/Bank/Type cannot be changed for an open IBA transactions";
                FastDriver.InterestBearingAccounts.Open();
                Support.AreEqual("False", FastDriver.InterestBearingAccounts.Beneficiary.IsEnabled().ToString(), "Beneficiary : IsEnabled");
                Support.AreEqual("False", FastDriver.InterestBearingAccounts.IBABank.IsEnabled().ToString(), "IBABank : IsEnabled");
                Support.AreEqual("False", FastDriver.InterestBearingAccounts.IBAType.IsEnabled().ToString(), "IBAType : IsEnabled");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES11504A_ES11505A: Prevent adding IBA beneficiaries if required value Buyer Firstname is missing")]
        public void FMUC0060_REG0010()
        {
            try
            {
                Reports.TestDescription = "BR_ES11504A_ES11505A: Prevent adding IBA beneficiaries if required value Buyer Firstname is missing";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address 
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer:true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and try to create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and try to create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Verify that IBA Beneficiary cannot be added without the required buyer/seller information";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow:false, clickAcceptButton: true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES11504B_ES11505B: Prevent adding IBA beneficiaries if required value Buyer Lastname is missing")]
        public void FMUC0060_REG0011()
        {
            try
            {
                Reports.TestDescription = "BR_ES11504B_ES11505B: Prevent adding IBA beneficiaries if required value Buyer Lastname is missing";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and try to create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and try to create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Verify that IBA Beneficiary cannot be added without the required buyer/seller information";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES11504AC_ES11505C: Prevent adding IBA beneficiaries if required value Buyer SSN is missing")]
        public void FMUC0060_REG0012()
        {
            try
            {
                Reports.TestDescription = "BR_ES11504AC_ES11505C: Prevent adding IBA beneficiaries if required value Buyer SSN is missing";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and try to create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and try to create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Verify that IBA Beneficiary cannot be added without the required buyer/seller information";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES11504D_ES11505D: Prevent adding IBA beneficiaries if required value Buyer AddressLine1 is missing")]
        public void FMUC0060_REG0013()
        {
            try
            {
                Reports.TestDescription = "BR_ES11504D_ES11505D: Prevent adding IBA beneficiaries if required value Buyer AddressLine1 is missing";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and try to create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and try to create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Verify that IBA Beneficiary cannot be added without the required buyer/seller information";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES11504E_ES11505E: Prevent adding IBA beneficiaries if required value Buyer City is missing")]
        public void FMUC0060_REG0014()
        {
            try
            {
                Reports.TestDescription = "BR_ES11504E_ES11505E: Prevent adding IBA beneficiaries if required value Buyer City is missing";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and try to create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and try to create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Verify that IBA Beneficiary cannot be added without the required buyer/seller information";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES11504F_ES11505F: Prevent adding IBA beneficiaries if required value Buyer State is missing")]
        public void FMUC0060_REG0015()
        {
            try
            {
                Reports.TestDescription = "BR_ES11504F_ES11505F: Prevent adding IBA beneficiaries if required value Buyer State is missing";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and try to create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and try to create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Verify that IBA Beneficiary cannot be added without the required buyer/seller information";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES11504G_ES11505G: Prevent adding IBA beneficiaries if required value Buyer ZipCode is missing")]
        public void FMUC0060_REG0016()
        {
            try
            {
                Reports.TestDescription = "BR_ES11504G_ES11505G: Prevent adding IBA beneficiaries if required value Buyer ZipCode is missing";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and try to create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and try to create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Verify that IBA Beneficiary cannot be added without the required buyer/seller information";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES9126: Prevent entry of multiple pending transactions for an IBA")]
        public void FMUC0060_REG0017()
        {
            try
            {
                Reports.TestDescription = "BR_ES9126: Prevent entry of multiple pending transactions for an IBA";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                //
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var dateCreated = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                var transactionId = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                var docNo = FastDriver.InterestBearingAccounts.TransactionDocNum.FAGetText();
                //
                Reports.TestStep = "Verify Add button is preventing multiple pending transactions for an IBA";
                Support.AreEqual("False", FastDriver.InterestBearingAccounts.Add.IsEnabled().ToString(), "Add : IsEnabled");
                #endregion

                #region Verify and validate the open IBA created
                Reports.TestStep = "Verify and validate the open IBA created";
                FastDriver.InterestBearingAccounts.Open();
                Support.AreEqual("01  Buyer1Firstname Buyer1Lastname  First American Trust, FSB  200.00  Open", FastDriver.InterestBearingAccounts.RecordSummaryTable.FAGetText(), "1st IBA Record");
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                Support.Match("Open IBA " + transactionId + " " + docNo + " 200\\.00 200\\.00 Pending Approval " + dateCreated + " USER ID: FASTTS\\\\FASTQA07", FastDriver.InterestBearingAccounts.TransactionTable.FAGetText(), "1st IBA Transaction");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES9129A: Issue IBA Transaction Deposits and Disbursements")]
        public void FMUC0060_REG0018()
        {
            try
            {
                Reports.TestDescription = "BR_ES9129A: Issue IBA Transaction Deposits and Disbursements";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var docNo = FastDriver.InterestBearingAccounts.TransactionDocNum.FAGetText();
                #endregion

                #region Deliver IBA transaction
                Reports.TestStep = "Deliver IBA transaction";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                var dateStarted = DateTime.UtcNow.ToPST().ToString("MM/dd/yyyy hh:'[0-9]{2}' tt 'PST'");
                FastDriver.PrintDlg.SendPrint("TEXT_FILE_PRINTER");
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 10000);
                var dateCompleted = DateTime.UtcNow.ToPST().ToString("MM/dd/yyyy hh:'[0-9]{2}' tt 'PST'");
                #endregion

                #region Verify the Print Delivery of IBA transaction in Event/Tracking Log
                Reports.TestStep = "Verify the Print Delivery of IBA transaction in Event/Tracking Log";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                Support.AreEqual("[Print]", FastDriver.EventTrackingLog.EventName.FAGetText(), "[0] EventName");
                Support.Match(dateStarted, FastDriver.EventTrackingLog.StartDate.FAGetText(), "[0] StartDate");
                Support.Match(dateCompleted, FastDriver.EventTrackingLog.CompletionDate.FAGetText(), "[0] CompletionDate");
                Support.AreEqual("Print Service", FastDriver.EventTrackingLog.Source0.FAGetText(), "[0] Source");
                Support.Match("File Number: " + File.FileNumber, FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : File Number");
                Support.Match("User Name: QA07, FAST", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : User Name");
                Support.Match("Documents: IBA Transaction Detail Report", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : Documents");
                Support.Match("Delivery Method: Print", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : Delivery Method");
                Support.Match("Delivery Status: Delivery Successful", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : Delivery Status");
                Support.Match("Imaging in Progress", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : Status");
                Support.Match("IBA Transaction Detail Report : ImageDoc Successful", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : IBA Transaction Detail Report");
                Support.AreEqual("FAST QA07", FastDriver.EventTrackingLog.User0.FAGetText(), "[0] User");
                #endregion
                
                #region Validate current available funds and IBA amount in File Business Summary
                Reports.TestStep = "Validate current available funds and IBA amount in File Business Summary";
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual("8,000.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText(), "EscrowFileBalanceSummary.NetDepositTotal");
                Support.AreEqual("200.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText(), "EscrowFileBalanceSummary.NetTotalDisbursements");
                Support.AreEqual("7,800.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText(), "EscrowFileBalanceSummary.CurrentAvailableFunds");
                #endregion

                #region Verify the Issued IBA disbursement in Active Disbursement Summary
                Reports.TestStep = "Verify the Issued IBA disbursement in Active Disbursement Summary";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.Match("Issued", FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] State");
                Support.Match("IBA", FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Funds");
                Support.Match(docNo, FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Document#");
                Support.Match(DateTime.Today.ToDateString(), FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Issue Date");
                Support.Match("200.00", FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Amount");
                Support.Match("IBA# fbo Buyer1Firstname Buyer1Lastname", FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Payee");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES9123: Reduce Current Available Funds for Pending IBA Transactions")]
        public void FMUC0060_REG0019()
        {
            try
            {
                Reports.TestDescription = "BR_ES9123: Reduce Current Available Funds for Pending IBA Transactions";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var docNo = FastDriver.InterestBearingAccounts.TransactionDocNum.FAGetText();
                #endregion

                #region Deliver IBA transaction
                Reports.TestStep = "Deliver IBA transaction";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                var dateStarted = DateTime.UtcNow.ToPST().ToString("MM/dd/yyyy hh:'[0-9]{2}' tt 'PST'");
                FastDriver.PrintDlg.SendPrint("TEXT_FILE_PRINTER");
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 10000);
                var dateCompleted = DateTime.UtcNow.ToPST().ToString("MM/dd/yyyy hh:'[0-9]{2}' tt 'PST'");
                #endregion

                #region Verify the Print Delivery of IBA transaction in Event/Tracking Log
                Reports.TestStep = "Verify the Print Delivery of IBA transaction in Event/Tracking Log";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                Support.AreEqual("[Print]", FastDriver.EventTrackingLog.EventName.FAGetText(), "[0] EventName");
                Support.Match(dateStarted, FastDriver.EventTrackingLog.StartDate.FAGetText(), "[0] StartDate");
                Support.Match(dateCompleted, FastDriver.EventTrackingLog.CompletionDate.FAGetText(), "[0] CompletionDate");
                Support.AreEqual("Print Service", FastDriver.EventTrackingLog.Source0.FAGetText(), "[0] Source");
                Support.Match("File Number: " + File.FileNumber, FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : File Number");
                Support.Match("User Name: QA07, FAST", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : User Name");
                Support.Match("Documents: IBA Transaction Detail Report", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : Documents");
                Support.Match("Delivery Method: Print", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : Delivery Method");
                Support.Match("Delivery Status: Delivery Successful", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : Delivery Status");
                Support.Match("Imaging in Progress", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : Status");
                Support.Match("IBA Transaction Detail Report : ImageDoc Successful", FastDriver.EventTrackingLog.Comments.FAGetText(), "[0] Comments : IBA Transaction Detail Report");
                Support.AreEqual("FAST QA07", FastDriver.EventTrackingLog.User0.FAGetText(), "[0] User");
                #endregion

                #region Reduce Current Available Funds for Pending IBA Transactions
                Reports.TestStep = "Reduce Current Available Funds for Pending IBA Transactions";
                FAST_AdjustDeposit("8,000.00", 2, "FMUC0060_REG0019 BR_ES9123", correctAmt: "6,200.00");
                #endregion

                #region Validate current available funds and IBA amount in File Business Summary
                Reports.TestStep = "Validate current available funds and IBA amount in File Business Summary";
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual("6,200.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText(), "EscrowFileBalanceSummary.NetDepositTotal");
                Support.AreEqual("200.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText(), "EscrowFileBalanceSummary.NetTotalDisbursements");
                Support.AreEqual("6,000.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText(), "EscrowFileBalanceSummary.CurrentAvailableFunds");
                #endregion

                #region Verify the Issued IBA disbursement in Active Disbursement Summary
                Reports.TestStep = "Verify the Issued IBA disbursement in Active Disbursement Summary";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.Match("Issued", FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] State");
                Support.Match("IBA", FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Funds");
                Support.Match(docNo, FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Document#");
                Support.Match(DateTime.Today.ToDateString(), FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Issue Date");
                Support.Match("200.00", FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Amount");
                Support.Match("IBA# fbo Buyer1Firstname Buyer1Lastname", FastDriver.ActiveDisbursementSummary.Disbursement.FAGetText(), "[0] Payee");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("BR_ES11499_ES11500: Change Beneficiary Information on IBA in ‘Open’ IBA Status")]
        public void FMUC0060_REG0020()
        {
            try
            {
                Reports.TestStep = "BR_ES11499_ES11500: Change Beneficiary Information on IBA in ‘Open’ IBA Status";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                //
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var dateCreated = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:mm tt");
                var transactionId = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                var docNo = FastDriver.InterestBearingAccounts.TransactionDocNum.FAGetText();
                #endregion

                #region Verify and validate the open IBA created
                Reports.TestStep = "Verify and validate the open IBA created";
                FastDriver.InterestBearingAccounts.Open();
                Support.AreEqual("01  Buyer1Firstname Buyer1Lastname  First American Trust, FSB  200.00  Open", FastDriver.InterestBearingAccounts.RecordSummaryTable.FAGetText(), "1st IBA Record");
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                //Support.AreEqual("Open IBA " + transactionId + " " + docNo + " 200.00 200.00  Pending Approval " + dateCreated + " USER ID: FASTTS\\FASTQA07 ...", FastDriver.InterestBearingAccounts.TransactionTable.FAGetText(), "1st IBA Transaction");
                Support.AreEqual("Pending Approval " + DateTime.Now.ToDateString(), FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, @"Open IBA", 6, TableAction.GetText).Message.Clean().Substring(0, 27), "1st IBA Transaction");
                #endregion

                #region Edit the Buyer type to Business Entity
                Reports.TestStep = "Edit the Buyer type to Business Entity";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ChangeInstanceType(1, "Business Entity");
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("BuyerName");
                FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("12-3456789");
                FastDriver.BottomFrame.Done();
                //
                FastDriver.ReasonforchangeDlg.WaitForDialogToLoad();
                FastDriver.ReasonforchangeDlg.SetFields("Other", "FMUC0060_REG0020 BR_ES11499_ES11500");
                FastDriver.ReasonforchangeDlg.ClickOk();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                var dateEdited = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                #endregion

                #region Verify change on beneficiary information on IBA
                Reports.TestStep = "Verify change on beneficiary information on IBA";
                FastDriver.InterestBearingAccounts.Open();
                Support.AreEqual("01  BuyerName  First American Trust, FSB  200.00  Open", FastDriver.InterestBearingAccounts.RecordSummaryTable.FAGetText(), "1st IBA Record");
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                //var transactionId2 = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                //Support.Match("Change\\/Correct Beneficiary " + transactionId2 + " N\\/A 0\\.00 200\\.00 Pending Approval " + dateEdited + " USER ID: FASTTS\\\\FASTQA07", FastDriver.InterestBearingAccounts.TransactionTable.FAGetText(), "1st IBA Transaction");
                Support.AreEqual("Pending Approval " + DateTime.Now.ToDateString(), FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, @"Change/Correct Beneficiary", 6, TableAction.GetText).Message.Clean().Substring(0, 27), "1st IBA Transaction");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("FD1: Field Validations")]
        public void FMUC0060_REG0021()
        {
            try
            {
                Reports.TestDescription = "FD1: Field Validations";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select Other as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.ValidateOTHER();
                FastDriver.SelectIBABeneficiaryDlg.AddOtherBeneficiary(new FASTSelenium.DataObjects.IIS.IBABeneficiary()
                {
                    BeneficiaryName = "Hummer Simpson",
                    AddressLine1 = "2nd NW Road",
                    AddressLine2 = "Suite 25",
                    City = "Santa Ana",                    
                    State = "CA",
                    selectSSN = true,
                    SSNTINnumber = "123456789",
                    ZipCode = "92701",
                });
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.ViewEdit.FAClick();
                Support.AreEqual("123-45-6789", FastDriver.InterestBearingAccounts.SSNTIN.FAGetValue(), "SSN/TIN View/Edit Input");
                Support.AreEqual("True", FastDriver.InterestBearingAccounts.ProductInfo.IsEnabled().ToString(), "ProductInfo Button");
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                //
                Reports.TestStep = "Remove IBA Transaction";
                Support.AreEqual("True", FastDriver.InterestBearingAccounts.Remove.IsEnabled().ToString(), "Remove : IsEnabled");
                FastDriver.InterestBearingAccounts.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                #endregion

                #region Verify IBA transaction is removed
                Reports.TestStep = "Verify IBA transaction is removed";
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                Support.AreEqual("", FastDriver.InterestBearingAccounts.RecordSummaryTable.FAGetText(), "");
                FastDriver.BottomFrame.Save();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("FD2: Field Validations")]
        public void FMUC0060_REG0022()
        { 
            try
            {
                Reports.TestStep = "FD2: Field Validations";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("99,999,999,999.98", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select Other as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText(@"-1");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Support.AreEqual("?", FastDriver.InterestBearingAccounts.TransactionAmount.FAGetValue(), "TransactionAmount : Negative : -1");
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText(@"999999999999");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Support.AreEqual("?", FastDriver.InterestBearingAccounts.TransactionAmount.FAGetValue(), "TransactionAmount : Too Large : 999999999999");
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText(@"ABC");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Reports.StatusUpdate(this.HandleDialogMessage(true, true), true);
                Support.AreEqual("0.00", FastDriver.InterestBearingAccounts.TransactionAmount.FAGetValue(), "TransactionAmount : String : ABC");
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText(@"0.001");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Reports.StatusUpdate(this.HandleDialogMessage(true, true), true);
                Support.AreEqual("0.00", FastDriver.InterestBearingAccounts.TransactionAmount.FAGetValue(), "TransactionAmount : No Round/Floor : 0.001");
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText(@"0.999");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Reports.StatusUpdate(this.HandleDialogMessage(true, true), true);
                Support.AreEqual("0.99", FastDriver.InterestBearingAccounts.TransactionAmount.FAGetValue(), "TransactionAmount : No Round/Floor : 0.999");
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText(@"99999999999.99");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Reports.StatusUpdate(this.HandleDialogMessage(true, true), true);
                Support.AreEqual("0.99", FastDriver.InterestBearingAccounts.TransactionAmount.FAGetValue(), "TransactionAmount : Exceeded Max Digits : 99999999999.99");
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText(@"99999999999.98");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Support.AreEqual("99,999,999,999.98", FastDriver.InterestBearingAccounts.TransactionAmount.FAGetValue(), "TransactionAmount : OK : 99999999999.98");
                //
                Reports.TestStep = "Reset IBA Transaction";
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                #endregion

                #region Verify IBA transaction is removed
                Reports.TestStep = "Verify IBA transaction is removed";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.InterestBearingAccounts.RecordSummaryTable.FAGetText(), "");
                FastDriver.BottomFrame.Save();
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        //  Place Holders from FMUC0060_REG0023 - FMUC0060_REG0042

        [TestMethod]
        //Team                                    : ServReq-Team2
        //Iteration                               : r10
        //UserStory                               : User Story 879394:[ROOT CAUSE]INC3079869 FAST - One of two IBA account files emailed or previewed does not have details
        //TestCase                                : 885873
        //Appended By/ Created By                 : Shobhit Nagori
        [Description("US 879394: Verify Transaction Details in IBA Transasction summary report for Title&Escrow file")]
        public void FMUC0060_REG0043()
        {
            try
            {
                Reports.TestDescription = "US 879394: Verify Transaction Details in IBA Transasction summary report for Title&Escrow file";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: true, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                //
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var dateCreated = DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy hh:'[0-9]{2}' tt");
                var transactionId = FastDriver.InterestBearingAccounts.TransactionID.FAGetText();
                var docNo = FastDriver.InterestBearingAccounts.TransactionDocNum.FAGetText();
                #endregion

                #region Verify and validate the open IBA created
                Reports.TestStep = "Verify and validate the open IBA created";
                FastDriver.InterestBearingAccounts.Open();
                Support.AreEqual("01  Buyer1Firstname Buyer1Lastname  First American Trust, FSB  200.00  Open", FastDriver.InterestBearingAccounts.RecordSummaryTable.FAGetText(), "1st IBA Record");
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                Support.Match("Open IBA " + transactionId + " " + docNo + " 200\\.00 200\\.00 Pending Approval " + dateCreated + " USER ID: FASTTS\\\\FASTQA07", FastDriver.InterestBearingAccounts.TransactionTable.FAGetText(), "1st IBA Transaction");

                FastDriver.InterestBearingAccounts.DeliveryMethod.FASelectItem("Preview");
                FastDriver.InterestBearingAccounts.Deliver.FAClick();

                Playback.Wait(15000);
                Support.SavePDF(Reports.RUNRESULTDIR + "\\PDF");
                string PDFContents = Support.ReadPdfFile(Reports.RUNRESULTDIR + "\\PDF.pdf");
                Support.AreEqualTrim("True", PDFContents.Contains("Pending Approval").ToString());
                Support.AreEqualTrim("True", PDFContents.Contains(transactionId).ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        //Team                                    : ServReq
        //Iteration                               : r10
        //UserStory                               : User Story 748571:INC2374897 - Direct [Bug] - Spell Check missing from Email and Fax Modules
        //TestCase                                : 884495
        //Appended By/ Created By                 : Nikhil
        [TestMethod]
        [Description("Spell Check")]
        public void FMUC0060_REG0044()
        {
            try
            {
                Reports.TestDescription = "Spell Check-Email and Fax";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "WCF Create File and open in FAST";
                FAST_WCF_File_IIS(GAB: "HUDFLINSR1", isTO: false, isEO: true);
                #endregion

                #region Add buyer with the property address as the current address
                Reports.TestStep = "Add buyer with the property address as the current address";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer
                Reports.TestStep = "Add Deposit In Escrow: 8000 | Additional Closing Costs | Sanity | Buyer";
                this.FAST_DepositInEscrow("8000", receivedFrom: "Buyer", typeFund: "Cash", representing: "Additional Closing Costs", payorName: "Buyer1Firstname Buyer1Middlename Buyer1Lastname", descr: "Sanity");
                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                var docNo = FastDriver.InterestBearingAccounts.TransactionDocNum.FAGetText();
                #endregion

                #region Spell Check - Email and Fax
                Reports.TestStep = "Deliver Email and Fax";
                FastDriver.InterestBearingAccounts.Open();
                //Include Email and Fax
                FastDriver.InterestBearingAccounts.DeliveryMethod.FASelectItem("Email");
                FastDriver.InterestBearingAccounts.Deliver.FAClick();
                SpellCheck_Email();

                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.DeliveryMethod.FASelectItem("Fax");
                FastDriver.InterestBearingAccounts.Deliver.FAClick();
                SpellCheck_Fax();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Private Functions
        //SRT - r10
        private static void SpellCheck_Email()
        {
            FastDriver.EmailDlg.WaitForDialogToLoad();
            FastDriver.EmailDlg.Message.FASendKeys("Speling");
            FastDriver.EmailDlg.SpellCheck_Msg.FAClick();

            Reports.TestStep = "Click on check Spelling.";
            FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
            FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("Spelling");
            FastDriver.SpellingErrorDialog.Change.FAClick();

            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

            Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker get disabled";
            FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
            Support.AreEqual("True", FastDriver.SpellingErrorDialog.ChangeAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
            Support.AreEqual("True", FastDriver.SpellingErrorDialog.Change.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
            Support.AreEqual("True", FastDriver.SpellingErrorDialog.Ignore.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
            Support.AreEqual("True", FastDriver.SpellingErrorDialog.IgnoreAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
            //FastDriver.FileNotesEditor.WaitForScreeToLoad();
            //FastDriver.BottomFrame.Done();
            FastDriver.EmailDlg.SwitchToDialogContentFrame();
            FastDriver.EmailDlg.Cancel.FAClick();
        }

        private static void SpellCheck_Fax()
        {
            FastDriver.FaxDlg.WaitForScreenToLoad();
            FastDriver.FaxDlg.Message.FASendKeys("Speling");
            FastDriver.FaxDlg.checkSpell.FAClick();

            Reports.TestStep = "Click on check Spelling.";
            FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
            FastDriver.SpellingErrorDialog.SuggestedWords.FASelectItem("Spelling");
            FastDriver.SpellingErrorDialog.Change.FAClick();

            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

            Reports.TestStep = "Verify after clicking on OK all the buttons on Spell checker get disabled";
            FastDriver.SpellingErrorDialog.WaitForScreeToLoad();
            Support.AreEqual("True", FastDriver.SpellingErrorDialog.ChangeAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
            Support.AreEqual("True", FastDriver.SpellingErrorDialog.Change.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
            Support.AreEqual("True", FastDriver.SpellingErrorDialog.Ignore.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
            Support.AreEqual("True", FastDriver.SpellingErrorDialog.IgnoreAll.FAGetAttribute("class").Contains("cTBaDisabled").ToString(), "Verifying button is disabled after spelling is checked");
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
            //FastDriver.FileNotesEditor.WaitForScreeToLoad();
            //FastDriver.BottomFrame.Done();
            FastDriver.FaxDlg.SwitchToDialogContentFrame();
            FastDriver.FaxDlg.Cancel.FAClick();
        }
        #endregion Private Functions

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
