﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium;
using System.Collections.Generic;
using OpenQA.Selenium.Support.PageObjects;
using System.Reflection;
using System.Globalization;
using System.Linq.Expressions;
using SeleniumInternalHelpers;


namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0131_ClosingDisclosure_GoodFaithVariance : FASTHelpers
    {

        #region Regression

        #region ADMIN FEE CREATION

        #region ADMIN FEE CREATION - NON FACC

        [Description("Creating Recording Fees in admin")]
        public void RecordingNonFACCFeeCreation()
        {
            Reports.TestStep = "Create Recording Fees in Admin";

            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

            /****************/

            Reports.TestStep = "Navigate to Fee Setup and Add new fees of type Recording Fee";
            Reports.TestStep = "Add Recording Fee of type Recording Fees - E Recording Fee Deed1";
            FastDriver.LeftNavigation.Navigate<FeeSetup>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitForScreenToLoad(FastDriver.FeeList2.New);

            #region Create Recording Fees

            /****************/
            Reports.TestStep = "Add Recording Fee of type Recording Fees - E Recording Fee Deed1";
            FeesetupParameters_gfv feedetail = new FeesetupParameters_gfv()
            {
                FeeType = "Recording Fee - Deed",
                FeeDesc = "E Recording Fee Deed1",
                LoanEstimatedesc = "E Recording Fee Deed LEDesc.",
                DescEdit = true,
                thirdPartyPayee = true,
                bSection = "E",
                blineno = "1",
                sSection = "E",
                slineno = "1",
                DefaultChargeAmtfrom = "98763.5",
                DefaultChargeAmtTo = "Buyer",
            };
            FastDriver.FeeSetup.CreateFee(feedetail);

            /****************/
            Reports.TestStep = "Add Recording Fee of type Recording Fees - E Recording Fee Deed2";
            FeesetupParameters_gfv feedetail1 = new FeesetupParameters_gfv()
            {
                FeeType = "Recording Fee - Deed",
                FeeDesc = "E Recording Fee Deed2",
                LoanEstimatedesc = "E2 Recording Fee Description",
                DescEdit = true,
                thirdPartyPayee = true,
                bSection = "E",
                blineno = "1",
                sSection = "E",
                slineno = "1",
                DefaultPaymentMethod = "Check",
            };
            FastDriver.FeeSetup.CreateFee(feedetail1);

            /****************/
            Reports.TestStep = "Add Recording Fee of type Recording Fees - E Recording Fee Mortgage1";
            FeesetupParameters_gfv feedetail2 = new FeesetupParameters_gfv()
            {
                FeeDesc = "E Recording Fee Mortgage1",
                FeeType = "Recording Fee - Mortgage",
                LoanEstimatedesc = "E Rec Fee Mortgage Loan Est. Description",
                Geographictype = "None",
                DefaultChargeAmtfrom = "234232.56",
                DefaultChargeAmtTo = "Seller",
                thirdPartyPayee = true,
                thirdPPayeeName = "Added Payee Name in Admin screen max chr",
                bSection = "E",
                blineno = "1",
                sSection = "E",
                slineno = "1",
                DefaultPaymentMethod = "Check",
            };
            FastDriver.FeeSetup.CreateFee(feedetail2);

            

            /****************/
            Reports.TestStep = "Add Recording Fee of type Recording Fees - Recording Fee - Mortgage2";
            FeesetupParameters_gfv feedetail3 = new FeesetupParameters_gfv()
            {
                FeeDesc = "Recording Fee - Mortgage2",
                FeeType = "Recording Fee - Mortgage",
                LoanEstimatedesc = "E2 Recording Fee Mortgage",
                Geographictype = "None",
                FeeDistribution = "Escrow",
                FeeOwnigOfficeType = "Escrow Owning Office",
                thirdPartyPayee = true,
                thirdPPayeeName = "Payee Name updated",
                bSection = "E",
                blineno = "1",
                sSection = "E",
                slineno = "1",
            };
            FastDriver.FeeSetup.CreateFee(feedetail3);

            /****************/
            Reports.TestStep = "Add Recording Fee of type Recording Fees - E Recording Fee Misc. description1";
            FeesetupParameters_gfv feedetail4 = new FeesetupParameters_gfv()
            {
                FeeDesc = "E Recording Fee Misc. description1",
                FeeType = "Recording Fee - Miscellaneous",
                LoanEstimatedesc = "E Recording Fee Miscellaneous",
                Geographictype = "None",
                DefaultChargeAmtfrom = "233232312.76",
                DefaultChargeAmtTo = "Both",
                thirdPartyPayee = false,
                bSection = "E",
                blineno = "1",
                sSection = "E",
                slineno = "1",
            };
            FastDriver.FeeSetup.CreateFee(feedetail4);

            /****************/
            Reports.TestStep = "Add Recording Fee of type Recording Fees - E Recording Fee Misc. 2";
            FeesetupParameters_gfv feedetail5 = new FeesetupParameters_gfv()
            {
                FeeDesc = "E Recording Fee Misc. 2",
                FeeType = "Recording Fee - Miscellaneous",
                LoanEstimatedesc = "E2 Recording Fee Misc.",
                Geographictype = "None",
                thirdPartyPayee = false,
                bSection = "E",
                blineno = "1",
                sSection = "E",
                slineno = "1",
                DefaultPaymentMethod = "Check",
            };
            FastDriver.FeeSetup.CreateFee(feedetail5);

            /****************/
            Reports.TestStep = "Add Recording Fee of type Recording Fees - E Recording Fee - Release1";
            FeesetupParameters_gfv feedetail6 = new FeesetupParameters_gfv()
            {
                FeeDesc = "E Recording Fee - Release1",
                FeeType = "Recording Fee - Release",
                LoanEstimatedesc = "E Recording Fee - Release Loan est.",
                DescEdit = true,
                Geographictype = "None",
                DefaultChargeAmtfrom = "456.76",
                DefaultChargeAmtTo = "Split",
                thirdPartyPayee = true,
                thirdPPayeeName = "Payee Name Filter",
                bSection = "E",
                blineno = "1",
                sSection = "E",
                slineno = "1",
                DefaultPaymentMethod = "Check",
                FeeFilterName = "Filter Template for Customary Fees",
            };
            FastDriver.FeeSetup.CreateFee(feedetail6);

            /****************/
            Reports.TestStep = "Add Recording Fee of type Recording Fees - E Recording Fee - Release2";
            FeesetupParameters_gfv feedetail7 = new FeesetupParameters_gfv()
            {
                FeeDesc = "E Recording Fee - Release2",
                FeeType = "Recording Fee - Release",
                LoanEstimatedesc = "E2 Recording Fee - Release",
                DescEdit = true,
                Geographictype = "None",
                DefaultChargeAmtfrom = "456.76",
                DefaultChargeAmtTo = "Split",
                thirdPartyPayee = true,
                thirdPPayeeName = "",
                bSection = "E",
                blineno = "1",
                sSection = "E",
                slineno = "1",
                FeeFilterName = "Filter Template for Customary Fees",
            };
            FastDriver.FeeSetup.CreateFee(feedetail7);

            #endregion
        }

        [Description("Creating Transfer Taxes in admin")]
        public void TransferTaxNonFACCFeeCreation()
        {
            Reports.TestStep = "Create Transfer Taxs in Admin";

            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

            Reports.TestStep = "Navigate to Fee Setup and Add new fees of type Transfer Tax";
            Reports.TestStep = "Add Transfer Tax of type Transfer Taxs - E Transfer Tax Deed1";

            FastDriver.LeftNavigation.Navigate<FeeSetup>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitForScreenToLoad(FastDriver.FeeList2.New);

            #region Create Transfer Taxes
            /****************/
            Reports.TestStep = "Add Recording Fee of type Recording Fees - E Recording Fee Deed1";
            FeesetupParameters_gfv feedetail = new FeesetupParameters_gfv()
            {
                FeeType = "Transfer Tax - Deed",
                FeeDesc = "CD - E Transfer Tax Deed1",
                LoanEstimatedesc = "CD - E Transfer Tax Deed LEDesc.",
                DescEdit = true,
                Geographictype = "City",
                DefaultChargeAmtfrom = "98763.5",
                DefaultChargeAmtTo = "Buyer",
                thirdPartyPayee = true,
                bSection = "E",
                blineno = "2",
                sSection = "E",
                slineno = "2",
                
            };
            FastDriver.FeeSetup.CreateFee(feedetail);

            /****************/
            Reports.TestStep = "Add Transfer Tax of type Transfer Taxs - E Transfer Tax Deed2";

            Reports.TestStep = "Add Recording Fee of type Recording Fees - E Recording Fee Deed1";
            FeesetupParameters_gfv feedetail1 = new FeesetupParameters_gfv()
            {
                FeeType = "Transfer Tax - Deed",
                FeeDesc = "CD - E Transfer Tax Deed2",
                LoanEstimatedesc = "CD - E2 Transfer Tax Description",
                FeeDistribution = "Escrow",
                FeeOwnigOfficeType = "Escrow Owning Office",
                Geographictype = "City",
                thirdPartyPayee = true,
                DefaultPaymentMethod = "Check",
                bSection = "E",
                blineno = "2",
                sSection = "E",
                slineno = "2",
            };
            FastDriver.FeeSetup.CreateFee(feedetail1);

            /****************/
            Reports.TestStep = "Add Transfer Tax of type Transfer Taxs - E Transfer Tax Deed3";
            FeesetupParameters_gfv feedetail2 = new FeesetupParameters_gfv()
            {
                FeeType = "Transfer Tax - Deed",
                FeeDesc = "CD - E Transfer Tax Deed3",
                LoanEstimatedesc = "CD - E Rec Fee Deed Loan Est. Description",
                Geographictype = "City",
                bSection = "E",
                blineno = "2",
                sSection = "E",
                slineno = "2",
                DefaultChargeAmtfrom = "234232.56",
                DefaultChargeAmtTo = "Seller",
                thirdPartyPayee = true,
                thirdPPayeeName = "Added Payee Name in Admin screen max chr",
                DefaultPaymentMethod = "Check",
                FeeFilterName ="Filter Template for Customary Fees",
            };
            FastDriver.FeeSetup.CreateFee(feedetail2);

            /****************/
            Reports.TestStep = "Add Transfer Tax of type Transfer Tax – Miscellaneous";
            FeesetupParameters_gfv feedetail3 = new FeesetupParameters_gfv()
            {
                FeeType = "Transfer Tax - Miscellaneous",
                FeeDesc = "CD - Transfer Tax – Miscellaneous",
                LoanEstimatedesc = "CD - E2 Transfer Tax Miscellaneous",
                Geographictype = "None",
                bSection = "E",
                blineno = "2",
                sSection = "E",
                slineno = "2",
                FeeDistribution = "Escrow",
                FeeOwnigOfficeType = "Escrow Owning Office",
                thirdPartyPayee = true,
                thirdPPayeeName = "Payee Name updated",
            };
            FastDriver.FeeSetup.CreateFee(feedetail3);

            /****************/
            Reports.TestStep = "Add Transfer Tax of type Transfer Taxs - E Transfer Tax Misc. description1";
            FeesetupParameters_gfv feedetail4 = new FeesetupParameters_gfv()
            {
                FeeType = "Transfer Tax - Miscellaneous",
                FeeDesc = "CD - E Transfer Tax Misc. description1",
                LoanEstimatedesc = "CD - E Transfer Tax Miscellaneous",
                Geographictype = "None",
                bSection = "E",
                blineno = "2",
                sSection = "E",
                slineno = "2",
                thirdPartyPayee = true,
                thirdPPayeeName = "Payee Name updated",
                DefaultChargeAmtfrom = "233232312.76",
                DefaultChargeAmtTo = "Both",
            };
            FastDriver.FeeSetup.CreateFee(feedetail4);

            /****************/
            Reports.TestStep = "Add Transfer Tax of type Transfer Taxs - E Transfer Tax Misc. 2";
            FeesetupParameters_gfv feedetail5 = new FeesetupParameters_gfv()
            {
                FeeType = "Transfer Tax - Miscellaneous",
                FeeDesc = "CD - E Transfer Tax Misc. 2",
                LoanEstimatedesc = "CD - E2 Transfer Tax Misc.",
                Geographictype = "None",
                DefaultPaymentMethod = "Check",
                bSection = "E",
                blineno = "2",
                sSection = "E",
                slineno = "2",
                thirdPartyPayee = false,
                FeeFilterName = "Filter Template for Customary Fees",
            };
            FastDriver.FeeSetup.CreateFee(feedetail5);

            /****************/
            Reports.TestStep = "Add Transfer Tax of type Transfer Taxs - E Transfer Tax – Mortgage";
            FeesetupParameters_gfv feedetail6 = new FeesetupParameters_gfv()
            {
                FeeType = "Transfer Tax - Mortgage",
                FeeDesc = "CD - E Transfer Tax – Mortgage",
                LoanEstimatedesc = "CD - E2 Transfer Tax – Mortgage display",
                Geographictype = "County",
                bSection = "E",
                blineno = "2",
                sSection = "E",
                slineno = "2",
                thirdPartyPayee = false,
            };
            FastDriver.FeeSetup.CreateFee(feedetail6);

            /****************/
            Reports.TestStep = "Add Transfer Tax of type  E Transfer Tax – Mortgage";
            FeesetupParameters_gfv feedetail7 = new FeesetupParameters_gfv()
            {
                FeeType = "Transfer Tax - Mortgage",
                FeeDesc = "CD - E Transfer Tax – Mortgage1",
                LoanEstimatedesc = "CD - E Transfer Tax – Mortgage Loan est.",
                Geographictype = "City",
                bSection = "E",
                blineno = "2",
                sSection = "E",
                slineno = "2",
                thirdPartyPayee = true,
                thirdPPayeeName = "Payee Name Filter",
                DefaultChargeAmtfrom = "456.76",
                DefaultChargeAmtTo = "Split",
                DefaultPaymentMethod = "Check",
            };
            FastDriver.FeeSetup.CreateFee(feedetail7);


            /****************/
            Reports.TestStep = "Add Transfer Tax of type Transfer Taxs - E Transfer Tax – Mortgage2";
            FeesetupParameters_gfv feedetail8 = new FeesetupParameters_gfv()
            {
                FeeType = "Transfer Tax - Mortgage",
                FeeDesc = "CD - E Transfer Tax – Mortgage2",
                LoanEstimatedesc = "CD - E2 Transfer Tax - Mo",
                DescEdit = true,
                Geographictype = "State",
                bSection = "E",
                blineno = "2",
                sSection = "E",
                slineno = "2",
                thirdPartyPayee = true,
                thirdPPayeeName = " ",
                FeeFilterName = "Filter Template for Customary Fees",
            };
            FastDriver.FeeSetup.CreateFee(feedetail8);
            #endregion

        }

        public void TransferTaxFACCFeeCreation(string FeeType, string FeeDesc, string LoanEstDesc, string PaymentMethod, bool Thirdpartypayee = false, string Thirdpatypayeename = null, string Filter = null)
        {
            string GeotypeID;
            if (FeeType == "Transfer Tax - Miscellaneous")
            {
                GeotypeID = "None";
            }
            else
            {
                GeotypeID = "City";
            }
            FeesetupParameters_gfv feedetail = new FeesetupParameters_gfv()
            {
                FeeType = FeeType,
                FeeDesc = FeeDesc,
                LoanEstimatedesc = LoanEstDesc,
                Geographictype = GeotypeID,
                thirdPartyPayee = Thirdpartypayee,
                thirdPPayeeName = Thirdpatypayeename,
                bSection = "E",
                blineno = "2",
                sSection = "E",
                slineno = "2",
                SubjectToCalculation = true,
                DefaultPaymentMethod = PaymentMethod,
                FeeFilterName = Filter,
            };
            FastDriver.FeeSetup.CreateFee(feedetail);
        }
        
        /* Commented Code
        ////#region ADMIN FACC FEE CREATION - FACC
        ////public void RecordingFACCFeeCreation()
        ////{
        ////    FATAF.HtmlSupport OfficeSetupPayeeAssignments = new FATAF.HtmlSupport();
        ////    FATAF.HtmlSupport FeeList2 = new FATAF.HtmlSupport();
        ////    FATAF.HtmlSupport FeeSetup = new FATAF.HtmlSupport();
        ////    FATAF.HtmlSupport TabFrameBottom = new FATAF.HtmlSupport();
        ////    FATAF.HtmlSupport FeeFilter = new FATAF.HtmlSupport();
        ////    FATAF.HtmlSupport BottomFrameDlg = new FATAF.HtmlSupport();

        ////    Reports.TestStep = "Create Recording Fees in Admin";

        ////    Reports.TestStep = "Add Recording Fee of type Recording Fees - FACC E Recording Fee Deed";

        ////    FeeList2.SetParent("ADM.FeeList", "FeeList2");
        ////    FeeList2.GetControl("ADM.FeeList", "New").Click();

        ////    FeeSetup.SetParent("ADM.FeeSetup", "FeeSetup");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Form_Type").Set("Selecteditem", "CD");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Fee_Code").Set("Text", FATAF.General.RandomString("ANANA"));
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeType").Set("Selecteditem", "Recording Fee - Deed");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Description").Set("Text", "FACC E Recording Fee Deed");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "LoanEstimateDescription").Set("Text", "FACC Recording Fee - Deed");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "DescEditFlag").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SubjectTocalculation").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GeotypeID").Set("Selecteditem", "None");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeStatus").Set("Selecteditem", "Active");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GL_Code").Set("Selecteditem", "116900 Advance for Customer - Recording Fees");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "DefaultChargeAmtTo").Set("Selecteditem", "Buyer");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeDistribution").Set("Selecteditem", "Title");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeOwnigOfficeTypeCdID").Set("Selecteditem", "Title Owning Office");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyEditableCheckBox").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyNameDefault").Set("Text", "");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "DefaultPaymentMethod").Set("Selecteditem", "Fee");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerLine").Set("Text", "1");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerLine").Set("Text", "1");
        ////    TabFrameBottom.SetParent("TabFrameBottom", "TabFrameBottom");
        ////    TabFrameBottom.GetControl("TabFrameBottom", "Done").Click();

        ////    Reports.TestStep = "Add Recording Fee of type Recording Fees - FACC2 Recording Fee - Deed";
        ////    FeeList2.SetParent("ADM.FeeList", "FeeList2");
        ////    FeeList2.GetControl("ADM.FeeList", "New").Click();

        ////    FeeSetup.SetParent("ADM.FeeSetup", "FeeSetup");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Form_Type").Set("Selecteditem", "CD");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Fee_Code").Set("Text", FATAF.General.RandomString("ANANA"));
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeType").Set("Selecteditem", "Recording Fee - Deed");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Description").Set("Text", "FACC E Recording Fee Deed2");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "LoanEstimateDescription").Set("Text", "FACC2 Recording Fee - Deed");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SubjectTocalculation").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GeotypeID").Set("Selecteditem", "None");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeStatus").Set("Selecteditem", "Active");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GL_Code").Set("Selecteditem", "116900 Advance for Customer - Recording Fees");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeDistribution").Set("Selecteditem", "Escrow");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeOwnigOfficeTypeCdID").Set("Selecteditem", "Escrow Owning Office");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyEditableCheckBox").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyNameDefault").Set("Text", "");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "DefaultPaymentMethod").Set("Selecteditem", "Check");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerLine").Set("Text", "1");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerLine").Set("Text", "1");
        ////    TabFrameBottom.SetParent("TabFrameBottom", "TabFrameBottom");
        ////    TabFrameBottom.GetControl("TabFrameBottom", "Done").Click();

        ////    Reports.TestStep = "Add Recording Fee of type Recording Fees - FACC E Recording Fee Mortgage";

        ////    FeeList2.SetParent("ADM.FeeList", "FeeList2");
        ////    FeeList2.GetControl("ADM.FeeList", "New").Click();

        ////    FeeSetup.SetParent("ADM.FeeSetup", "FeeSetup");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Form_Type").Set("Selecteditem", "CD");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Fee_Code").Set("Text", FATAF.General.RandomString("ANANA"));
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeType").Set("Selecteditem", "Recording Fee - Mortgage");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Description").Set("Text", "FACC E Recording Fee Mortgage");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "LoanEstimateDescription").Set("Text", "FACC Recording Fee Mortgage");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SubjectTocalculation").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GeotypeID").Set("Selecteditem", "None");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeStatus").Set("Selecteditem", "Active");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GL_Code").Set("Selecteditem", "116900 Advance for Customer - Recording Fees");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "DefaultChargeAmtTo").Set("Selecteditem", "Seller");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeDistribution").Set("Selecteditem", "Title");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeOwnigOfficeTypeCdID").Set("Selecteditem", "Title Owning Office");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyEditableCheckBox").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyNameDefault").Set("Text", "Added Payee Name in Admin screen max chr");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "DefaultPaymentMethod").Set("Selecteditem", "Check");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerLine").Set("Text", "1");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerLine").Set("Text", "1");
        ////    TabFrameBottom.SetParent("TabFrameBottom", "TabFrameBottom");
        ////    TabFrameBottom.GetControl("TabFrameBottom", "Done").Click();

        ////    Reports.TestStep = "Add Recording Fee of type Recording Fees - FACC E Recording Fee - Mortgage2";
        ////    FeeList2.SetParent("ADM.FeeList", "FeeList2");
        ////    FeeList2.GetControl("ADM.FeeList", "New").Click();

        ////    FeeSetup.SetParent("ADM.FeeSetup", "FeeSetup");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Form_Type").Set("Selecteditem", "CD");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Fee_Code").Set("Text", FATAF.General.RandomString("ANANA"));
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeType").Set("Selecteditem", "Recording Fee - Mortgage");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Description").Set("Text", "FACC E Recording Fee - Mortgage2");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "LoanEstimateDescription").Set("Text", "FACC2 Recording Fee Mortgage");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SubjectTocalculation").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GeotypeID").Set("Selecteditem", "None");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeStatus").Set("Selecteditem", "Active");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GL_Code").Set("Selecteditem", "116900 Advance for Customer - Recording Fees");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeDistribution").Set("Selecteditem", "Escrow");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeOwnigOfficeTypeCdID").Set("Selecteditem", "Escrow Owning Office");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyEditableCheckBox").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyNameDefault").Set("Text", "Payee Name updated");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "DefaultPaymentMethod").Set("Selecteditem", "Fee");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerLine").Set("Text", "1");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerLine").Set("Text", "1");
        ////    TabFrameBottom.SetParent("TabFrameBottom", "TabFrameBottom");
        ////    TabFrameBottom.GetControl("TabFrameBottom", "Done").Click();

        ////    Reports.TestStep = "Add Recording Fee of type Recording Fees - FACC E Recording Fee Misc. description";

        ////    FeeList2.SetParent("ADM.FeeList", "FeeList2");
        ////    FeeList2.GetControl("ADM.FeeList", "New").Click();

        ////    FeeSetup.SetParent("ADM.FeeSetup", "FeeSetup");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Form_Type").Set("Selecteditem", "CD");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Fee_Code").Set("Text", FATAF.General.RandomString("ANANA"));
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeType").Set("Selecteditem", "Recording Fee - Miscellaneous");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Description").Set("Text", "FACC E Recording Fee Misc. description");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "LoanEstimateDescription").Set("Text", "FACC Recording Fee Miscellaneous");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SubjectTocalculation").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GeotypeID").Set("Selecteditem", "None");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeStatus").Set("Selecteditem", "Active");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GL_Code").Set("Selecteditem", "116900 Advance for Customer - Recording Fees");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "DefaultChargeAmtTo").Set("Selecteditem", "Both");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeDistribution").Set("Selecteditem", "Title");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeOwnigOfficeTypeCdID").Set("Selecteditem", "Title Owning Office");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyEditableCheckBox").Set("Checked", false);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "DefaultPaymentMethod").Set("Selecteditem", "Fee");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerLine").Set("Text", "1");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerLine").Set("Text", "1");
        ////    TabFrameBottom.SetParent("TabFrameBottom", "TabFrameBottom");
        ////    TabFrameBottom.GetControl("TabFrameBottom", "Done").Click();

        ////    Reports.TestStep = "Add Recording Fee of type Recording Fees - FACC E Recording Fee Misc. description2";

        ////    FeeList2.SetParent("ADM.FeeList", "FeeList2");
        ////    FeeList2.GetControl("ADM.FeeList", "New").Click();

        ////    FeeSetup.SetParent("ADM.FeeSetup", "FeeSetup");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Form_Type").Set("Selecteditem", "CD");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Fee_Code").Set("Text", FATAF.General.RandomString("ANANA"));
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeType").Set("Selecteditem", "Recording Fee - Miscellaneous");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Description").Set("Text", "FACC E Recording Fee Misc. description2");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "LoanEstimateDescription").Set("Text", "FACC2 Recording Fee Miscellaneous");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SubjectTocalculation").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GeotypeID").Set("Selecteditem", "None");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeStatus").Set("Selecteditem", "Active");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GL_Code").Set("Selecteditem", "116900 Advance for Customer - Recording Fees");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeDistribution").Set("Selecteditem", "Title");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeOwnigOfficeTypeCdID").Set("Selecteditem", "Title Owning Office");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyEditableCheckBox").Set("Checked", false);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "DefaultPaymentMethod").Set("Selecteditem", "Check");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerLine").Set("Text", "1");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerLine").Set("Text", "1");
        ////    TabFrameBottom.SetParent("TabFrameBottom", "TabFrameBottom");
        ////    TabFrameBottom.GetControl("TabFrameBottom", "Done").Click();

        ////    Reports.TestStep = "Add Recording Fee of type Recording Fees - FACC E Recording Fee – Release";

        ////    FeeList2.SetParent("ADM.FeeList", "FeeList2");
        ////    FeeList2.GetControl("ADM.FeeList", "New").Click();

        ////    FeeSetup.SetParent("ADM.FeeSetup", "FeeSetup");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Form_Type").Set("Selecteditem", "CD");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Fee_Code").Set("Text", FATAF.General.RandomString("ANANA"));
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeType").Set("Selecteditem", "Recording Fee - Release");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Description").Set("Text", "FACC E Recording Fee – Release");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "LoanEstimateDescription").Set("Text", "FACC Recording Fee - Release Loan est. maximum value display");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SubjectTocalculation").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GeotypeID").Set("Selecteditem", "None");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeStatus").Set("Selecteditem", "Active");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GL_Code").Set("Selecteditem", "116900 Advance for Customer - Recording Fees");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "DefaultChargeAmtTo").Set("Selecteditem", "Split");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeDistribution").Set("Selecteditem", "Title");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeOwnigOfficeTypeCdID").Set("Selecteditem", "Title Owning Office");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyEditableCheckBox").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyNameDefault").Set("Text", "Payee Name Filter");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "DefaultPaymentMethod").Set("Selecteditem", "Check");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerLine").Set("Text", "1");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerLine").Set("Text", "1");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "AddRemove").Click();
        ////    Playback.Wait(10000);
        ////    FeeFilter.SetParent("ADM.FeeFilterTemlateSummaryDlg", "FeeFilterTemlateSummaryDlg");

        ////    string Filter = string.Concat("#2^", "Filter Template for Customary Fees");
        ////    Filter = string.Concat(Filter, "^#1|ON");
        ////    FeeFilter.HtmlTableSet("ADM.FeeFilterTemlateSummaryDlg", "FeeFilterTable", Filter);


        ////    BottomFrameDlg.SetParent("BottomFrameDlg", "BottomFrameDlg");
        ////    BottomFrameDlg.GetControl("BottomFrameDlg", "Done").Click();
        ////    Playback.Wait(10000);

        ////    TabFrameBottom.SetParent("TabFrameBottom", "TabFrameBottom");
        ////    TabFrameBottom.GetControl("TabFrameBottom", "Done").Click();

        ////    Reports.TestStep = "Add Recording Fee of type Recording Fees - FACC E Recording Fee - Release2";




        ////    FeeList2.SetParent("ADM.FeeList", "FeeList2");
        ////    FeeList2.GetControl("ADM.FeeList", "New").Click();

        ////    FeeSetup.SetParent("ADM.FeeSetup", "FeeSetup");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Form_Type").Set("Selecteditem", "CD");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Fee_Code").Set("Text", FATAF.General.RandomString("ANANA"));
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeType").Set("Selecteditem", "Recording Fee - Release");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "Description").Set("Text", "FACC E Recording Fee - Release2");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "LoanEstimateDescription").Set("Text", "FACC E Recording Fee – Release");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SubjectTocalculation").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GeotypeID").Set("Selecteditem", "None");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeStatus").Set("Selecteditem", "Active");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "GL_Code").Set("Selecteditem", "116900 Advance for Customer - Recording Fees");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeDistribution").Set("Selecteditem", "Title");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "FeeOwnigOfficeTypeCdID").Set("Selecteditem", "Title Owning Office");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyEditableCheckBox").Set("Checked", true);
        ////    FeeSetup.GetControl("ADM.FeeSetup", "ThirdPartyNameDefault").Set("Text", "");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "DefaultPaymentMethod").Set("Selecteditem", "Fee");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "BuyerLine").Set("Text", "1");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerChargeSection").Set("Selecteditem", "E");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "SellerLine").Set("Text", "1");
        ////    FeeSetup.GetControl("ADM.FeeSetup", "AddRemove").Click();
        ////    Playback.Wait(10000);
        ////    FeeFilter.SetParent("ADM.FeeFilterTemlateSummaryDlg", "FeeFilterTemlateSummaryDlg");

        ////    FeeFilter.HtmlTableSet("ADM.FeeFilterTemlateSummaryDlg", "FeeFilterTable", Filter);

        ////    BottomFrameDlg.SetParent("BottomFrameDlg", "BottomFrameDlg");
        ////    BottomFrameDlg.GetControl("BottomFrameDlg", "Done").Click();
        ////    Playback.Wait(10000);

        ////    TabFrameBottom.SetParent("TabFrameBottom", "TabFrameBottom");
        ////    TabFrameBottom.GetControl("TabFrameBottom", "Done").Click();

        ////}

        ////#endregion*/
        #endregion

        #region ADMIN MAIN METHOD
        [TestMethod]
        public void AdminFeeCreation()
        {

            Reports.TestDescription = "Create Fees in Admin";

            Reports.TestStep = "Create Transfer Taxs in Admin";

            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

            Reports.TestStep = "Navigate to Fee Setup and Add new fees of type Transfer Tax";
            Reports.TestStep = "Add Transfer Tax of type Transfer Taxs - E Transfer Tax Deed1";

            FastDriver.LeftNavigation.Navigate<FeeSetup>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitForScreenToLoad(FastDriver.FeeList2.New);

            Reports.TestStep = "Login to Admin and create Recording Fees";
            RecordingNonFACCFeeCreation();

            /*****************/
            Reports.TestStep = "Pre-condition: Create fees in admin with Subject to calculation checkbox checked.";
            /////////////RecordingFACCFeeCreation();

            //******************/
            Reports.TestStep = "Precondition - Navigate to Admin - Create Non-FACC Transfer Tax";
            TransferTaxNonFACCFeeCreation();

            /*********************************/

            Reports.TestStep = "Precondition - Navigate to Admin - Create Non-FACC Transfer Tax";

            /****************/
            Reports.TestStep = "Navigate to Fee Setup and Add new fees of type Transfer Tax";

            TransferTaxFACCFeeCreation("Transfer Tax - Deed", "FACC E Transfer Tax Deed", "FACC Transfer Tax - Deed", "Fee", true, null, "Filter Template for Customary Fees");
            TransferTaxFACCFeeCreation("Transfer Tax - Deed", "FACC E Transfer Tax Deed2", "FACC2 Transfer Tax - Deed", "Check", true, "Added Payee Name in Admin screen max chr");
            TransferTaxFACCFeeCreation("Transfer Tax - Deed", "FACC E Transfer Tax Deed3", "FACC Transfer Tax Deed3", "Fee");

            TransferTaxFACCFeeCreation("Transfer Tax - Mortgage", "FACC E Transfer Tax – Mortgage1", "FACC Transfer Tax Mortgage", "Check", true, "");
            TransferTaxFACCFeeCreation("Transfer Tax - Mortgage", "FACC E Transfer Tax – Mortgage2", "FACC E Transfer Tax – Mortgage2", "Fee", true, "Added Payee Name in Admin screen max chr", "Filter Template for Customary Fees");
            TransferTaxFACCFeeCreation("Transfer Tax - Mortgage", "FACC E Transfer Tax Mortgage3", "FACC E Transfer Tax Mortgage3", "Check", false);

            TransferTaxFACCFeeCreation("Transfer Tax - Miscellaneous", "FACC E Transfer Tax Misc. description1", "FACC1 Transfer Tax Miscellaneous", "Fee", true, "");
            TransferTaxFACCFeeCreation("Transfer Tax - Miscellaneous", "FACC E Transfer Tax – Miscellaneous2", "FACC E Transfer Tax – Miscellaneous With Maximum Characterss", "Check", true, "Added Payee Name in Admin screen max chr");
            TransferTaxFACCFeeCreation("Transfer Tax - Miscellaneous", "FACC E Transfer Tax – Miscellaneous3", "FACC E Transfer Tax3 – Miscellaneous", "Fee", false, "", "Filter Template for Customary Fees");

        }
        #endregion

        #endregion

        [TestMethod]
        [Description("US300130, Verify Section A Charges in Good Faith Variance Screen")]
        public void FMUC0131_REG0001()
        {
            try
            {
                int rowCount;
                Reports.TestDescription = "US300130, Verify Section A Charges in Good Faith Variance Screen";

                #region Log into FAST application & Create a new file
                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Navigate to New Loan – Add GAB code and enter amount in Origination Charges (Section A)
                //**Navigate to New Loan – Add GAB code**//
                Reports.TestStep = "Navigate to New Loan Screen – Loan Charges Tab";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FindGABCode("BOA");
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                //**Enter Amount in New Loan – Loan Charges – Origination Charges (Section A)**//
                Reports.TestStep = "Enter Amount in New Loan – Loan Charges – Origination Charges (Section A)";

                //**Application Fee – Equal to Buyer Charge**//
                Reports.TestStep = "Application Fee – Enter Amount in Grid";
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", 2199.56, null, 450.56,null, 2199.56);

                //**Origination Fee– Greater than Buyer Charge**//
                Reports.TestStep = "Origination Fee– Enter Amount in PDD";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("856.34");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("342.12");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("2312.45");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateBuyerCharge());
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("3242.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("3423.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("3454.45");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateSellerCharge());
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("1546.89");
                FastDriver.DialogBottomFrame.ClickDone();

                //**Underwriting Fee– Less than Buyer Charge**//
                Reports.TestStep = "Underwriting Fee– Enter Amount in PDD";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("93423423.67");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("93423423.12");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("234234.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2342334.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("234123.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("213123.45");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("522246.89");
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                //**Adhoc Charge 1 – Lesser than Buyer Charge**//
                Reports.TestStep = "Adhoc Charge 1– Enter Amount in Grid";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Adhoc Charge 1");
                Keyboard.SendKeys("{TAB}");
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.OriginationChargesTable, "Adhoc Charge 1", 9876734333.34, null, 32434.67, null, 234234234.57);
                Keyboard.SendKeys("{TAB}");

                //**Second Adhoc Charge – Greater than Buyer Charge**//
                Reports.TestStep = "Second Adhoc Charge– Enter Amount in Grid";
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Second Adhoc Charge");
                Keyboard.SendKeys("{TAB}");
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.OriginationChargesTable, "Second Adhoc Charge", 34234.99, null, 32434.67, null, 53454.67);
                Keyboard.SendKeys("{TAB}");

                //**Third Adhoc Charge – Equal to Buyer Charge**//
                Reports.TestStep = "Third Adhoc Charge – Enter Amount in PDD";
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Third Adhoc Charge");
                Keyboard.SendKeys("{TAB}");
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.OriginationChargesTable, "Third Adhoc Charge"+FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Third Adhoc Charge", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("32433.45");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("32234.12");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("2312.45");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateBuyerCharge());
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("3242.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("3423.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("3454.45");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateSellerCharge());
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("64,667.57");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                #endregion

                #region Navigate to CD –GFV Screen and Verify Values in Good Faith Variance screen

                #region Good Faith Variance Rules
                ////**Navigate to CD Screen and Verify Values in Good Faith Variance screen**//

                ////**All the amounts will be displayed in 9.2 Format**//
                ///**Section A will be displayed as individual charges in below mentioned format:
                //    a.	Column 1 – <Section> <Line no. as displayed in CD Screen> <Charge Description as per CD> (E.g. A 01 10 % of Loan Amount (Points))
                //    b.	Column 2 (Loan Estimate Disclosed (Rounded)) – Loan Estimate Rounded Amount. (E.g. $0)	
                //    c.	Column 3 (Final (Borrower Paid)) – Sum of Buyer/Borrower At Closing and Before Closing. (E.g. $600.00)
                //    d.	Column 4 (Loan Estimate (Unrounded)) – Loan Estimate Unrounded Amount. (E.g. $0.00)
                //    e.	Column 5 (Amounts Exceeding 0% Good Faith Limit) – Final Amount – Loan Estimate Unrounded Amount (E.g. $600.00)
                //        i.	If Final Amount – Loan Estimate Unrounded Amount is a Positive value system will display the same in Column 5 else system will display $0.00
                //    **/

                ///**Last but one line (Before Total) in 0% category will be “ J 00 Lender Credits (See Lender Credit Analysis)”  – (Will be displayed as Negative Amount)
                //    a.	 Column 1 – J 00 Lender Credits (See Lender Credit Analysis) 
                //    b.	Column 2 (Loan Estimate Disclosed (Rounded)) – Sum of Non-Specific Lender Credits Loan Estimate Rounded amount from Loan Charge tab and Mortgage Broker tab (E.g. –$500)
                //    c.	Column 3 (Final (Borrower Paid)) – Total Amount of “Lender Credits Total (J) Excluding Good Faith Violation” under Lender Credit Analysis section. .(E.g. –$200.00)
                //    d.	Column 4 (Loan Estimate (Unrounded)) – Sum of Non-Specific Lender Credits Loan Estimate Unrounded amount from Loan Charge tab and Mortgage Broker tab. (E.g. –$500)
                //    e.	Column 5 (Amounts Exceeding 0% Good Faith Limit) – Final Amount – Loan Estimate Unrounded Amount (Positive Amount – E.g. $300.00)
                //        i.	If Final Amount – Loan Estimate Unrounded Amount is a Positive value system will display the same in Column 5 else system will display $0.00
                //    **/

                ////**Last line will be Increase in Closing Costs above legal limits - 0% Category – Sum of all (Amounts Exceeding 0% Good Faith Limit)**//

                ///** 1.	Non Specific Lender Credits – Sum of Non-Specific Lender Credits Buyer Credit amount from Loan Charge tab and Mortgage Broker tab (E.g. –$500.45)
                //    2.	Specific Lender Credits:
                //        a.	Displays Section A, Section B and Section E – Buyer Paid By Others Amount of Payment Method – POC – L/POC – MB/Lender / Mortgage Broker.
                //        b.	Section E – Sum of all Recording fees Paid By Others Amount will be displayed in single line.
                //        c.	Section E – Sum of all Transfer tax Paid By Others Amount will be displayed in single line.
                //    3.	Lender Credits Total (J) Excluding Good Faith Violation – Sum of Non Specific Lender Credits + Specific Lender Credits.**/

                ////**Last line below GFV 10% will be Increase in Closing Costs above legal limits – Total 0% and 10% Category = Sum of 0% + 10% (if amount is greater than Zero, system will display below line)**//
                #endregion

                Reports.TestStep = "Navigate to CD –GFV Screen and Verify Values in Good Faith Variance screen";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { 
                    { "A 02 Adhoc Charge 1", "$234,234,235", "$876,734,333.34", "$234,234,234.57", "$642,500,098.77" }, 
                    { "A 03 Application Fee", "$2,200", "$2,199.56", "$2,199.56", "$0.00" }, 
                    { "A 04 Origination Fee", "$1,547", "$1,198.46", "$1,546.89", "$0.00" }, 
                    { "A 05 Second Adhoc Charge", "$53,455", "$34,234.99", "$53,454.67", "$0.00" }, 
                    { "A 06 Third Adhoc Charge", "$64,668", "$64,667.57", "$64,667.57", "$0.00" }, 
                    { "A 07 Underwriting Fee", "$522,247", "$186,846,846.79", "$522,246.89", "$186,324,599.90" }, 
                    { "J 00 Lender Credits (See Lender Credit Analysis)", "$0", "-$236,546.90", "$0.00", "$0.00" }, 
                    { "Increase in Closing Costs above legal limits - 0% Category", "$828,824,698.67", "", "", "" } }, 
                    cat10Table: null,
                    lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "A 04 Origination Fee", "-$2,312.45" }, 
                    { "A 07 Underwriting Fee", "-$234,234.45" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "-$236,546.90" } }, 
                    increaseTotal: 828824698.67);

                //**Select to CD Screen and Edit Charge Description and Loan Estimate Amounts**//
                Reports.TestStep = "Select to CD Screen and Edit Charge Description and Loan Estimate Amounts";
                FastDriver.ClosingDisclosure.Open();
                //FastDriver.ClosingDisclosure.ClickCDTab();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.A, "Adhoc Charge 1", "Modified Description in CD");
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.A, "Underwriting Fee", "Edited in CD – Underwriting");
                Keyboard.SendKeys("{TAB}");
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.A, "Origination Fee", false, 789.66, 5);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.A, "Third Adhoc Charge", false, 34789.66, 7);

                //**Verify in CD – GFV Screen if system displays the content as edited by the user**//
                Reports.TestStep = "Verify in CD – GFV Screen if system displays the content as edited by the user";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { 
                    { "A 02 Application Fee", "$2,200", "$2,199.56", "$2,199.56", "$0.00" }, 
                    { "A 03 Edited in CD – Underwriting", "$522,247", "$186,846,846.79", "$522,246.89", "$186,324,599.90" },
                    { "A 04 Modified Description in CD", "$234,234,235", "$876,734,333.34", "$234,234,234.57", "$642,500,098.77" }, 
                    { "A 05 Origination Fee", "$790", "$1,198.46", "$789.66", "$408.80" }, 
                    { "A 06 Second Adhoc Charge", "$53,455", "$34,234.99", "$53,454.67", "$0.00" }, 
                    { "A 07 Third Adhoc Charge", "$34,790", "$64,667.57", "$34,789.66", "$29,877.91" }, 
                    { "J 00 Lender Credits (See Lender Credit Analysis)", "$0", "-$236,546.90", "$0.00", "$0.00" }, 
                    { "Increase in Closing Costs above legal limits - 0% Category", "$828,854,985.38", "", "", "" } },
                cat10Table: null,
                lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "A 03 Edited in CD – Underwriting", "-$234,234.45" }, 
                    { "A 05 Origination Fee", "-$2,312.45" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "-$236,546.90" } },
                increaseTotal: 828854985.38);

                #endregion

                #region Navigate to New Loan Screen and modify values in loan charges section
                //**Navigate to New Loan Screen and Enter Loan Amount**//
                Reports.TestStep = "Navigate to New Loan Screen and Enter Loan Amount";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("56900.67");
                
                //**Enter % of Loan Amounts (Points)**//
                Reports.TestStep = "Enter percentage in % of Loan Amounts (Points)";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText(@"45.75");

                //**Modify Amounts in PDD for Origination Charges**//
                Reports.TestStep = "Modify Amounts in Origination Charges Section";
                //**Application Fee**//
                Reports.TestStep = "Modify Application Fee Values";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description Edit in PDD");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("34324.12");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("9643.12");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateBuyerCharge());
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("123546.89");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("23244");
                FastDriver.DialogBottomFrame.ClickDone();

                //**Edited in CD – Underwriting**//
                Reports.TestStep = "Modify \"Edited in CD – Underwriting\" Values";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Edited in CD – Underwriting", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("45345.97");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("56756.67");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateBuyerCharge());
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("123546.89");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("23244");
                FastDriver.DialogBottomFrame.ClickDone();

                //**Modified Description in CD**//
                Reports.TestStep = "Modify \"Modified Description in CD\" Values";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.OriginationChargesTable, "Modified Description in CD", 96756.45, null, null, null, 3453.56);

                //**Second Adhoc Charge**//
                Reports.TestStep = "Modify \"Second Adhoc Charge\" Values";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Second Adhoc Charge", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("34,234.99");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.DisplayLBorrower.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateBuyerCharge());
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("32,434.67");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.DisplayLSeller.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateSellerCharge());
                FastDriver.DialogBottomFrame.ClickDone();

                //**Lender Credits**//
                Reports.TestStep = "Add \"Non-Specific Lender Credits\" Values in Lender credits section – New Loan | Loan Charges";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.Expand(FastDriver.NewLoan.LoanCharges_ExpandLenderCredits);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LenderCreditsTable, "Non-Specific Lender Credits", null, 67899.78, null, null, 56756.76);

                //**Lender Credits – Mortgage Broker**//
                Reports.TestStep = "Add \"Non-Specific Lender Credits\" Values in Lender credits section – New Loan | Mortgage Broker";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_LenderCreditTable, "Non-Specific Lender Credits", null, 7845.12, null, null, 7678.09);
                #endregion

                #region Verify in CD – GFV Screen if system displays the content as edited by the user
                //**Verify in CD – GFV Screen if system displays the content as edited by the user**//
                Reports.TestStep = "Verify in CD – GFV Screen if system displays the content as edited by the user";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { 
                    { "A 01 45.75 % of Loan Amount (Points)", "$0", "$26,032.06", "$0.00", "$26,032.06" }, 
                    { "A 02 Description Edit in PDD", "$23,244", "$34,324.12", "$123,546.89", "$0.00" }, 
                    { "A 03 Edited in CD – Underwriting", "$23,244", "$102,102.64", "$123,546.89", "$0.00"},
                    { "A 04 Modified Description in CD", "$3,454", "$96,756.45", "$3,453.56", "$93,302.89" }, 
                    { "A 05 Origination Fee", "$790", "$1,198.46", "$789.66", "$408.80" }, 
                    { "A 06 Second Adhoc Charge", "$53,455", "$34,234.99", "$53,454.67", "$0.00" }, 
                    { "A 07 Third Adhoc Charge", "$34,790", "$64,667.57", "$34,789.66", "$29,877.91" }, 
                    { "J 00 Lender Credits (See Lender Credit Analysis)", "-$64,435", "-$121,935.46", "-$64,434.85", "$0.00" }, 
                    { "Increase in Closing Costs above legal limits - 0% Category", "$149,621.66", "", "", "" } },
                cat10Table: null,
                lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "-$75,744.90" }, 
                    { "Specific Lender Credits", "" }, 
                    { "A 02 Description Edit in PDD", "-$9,643.12" }, 
                    { "A 05 Origination Fee", "-$2,312.45" }, 
                    { "A 06 Second Adhoc Charge", "-$34,234.99" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "-$121,935.46" } },
                increaseTotal: 149621.66);

                #endregion

                #region Navigate to New Loan Screen and Modify Lender Credits Amount
                //**Navigate to New Loan Screen and Modify Lender Credits Amount**//
                Reports.TestStep = "Navigate to New Loan Screen and Modify Lender Credits Amount";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LenderCreditsTable, "Non-Specific Lender Credits", null, 67899.78, null, null, 967899.78);
                #endregion

                #region Verify in CD – GFV Screen if system displays the content as edited by the user
                //**Verify in CD – GFV Screen if system displays the content as edited by the user**//
                Reports.TestStep = "Verify in CD – GFV Screen if system displays the content as edited by the user";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { 
                    { "A 01 45.75 % of Loan Amount (Points)", "$0", "$26,032.06", "$0.00", "$26,032.06" }, 
                    { "A 02 Description Edit in PDD", "$23,244", "$34,324.12", "$123,546.89", "$0.00" }, 
                    { "A 03 Edited in CD – Underwriting", "$23,244", "$102,102.64", "$123,546.89", "$0.00"},
                    { "A 04 Modified Description in CD", "$3,454", "$96,756.45", "$3,453.56", "$93,302.89" }, 
                    { "A 05 Origination Fee", "$790", "$1,198.46", "$789.66", "$408.80" }, 
                    { "A 06 Second Adhoc Charge", "$53,455", "$34,234.99", "$53,454.67", "$0.00" }, 
                    { "A 07 Third Adhoc Charge", "$34,790", "$64,667.57", "$34,789.66", "$29,877.91" }, 
                    { "J 00 Lender Credits (See Lender Credit Analysis)", "-$975,578", "-$121,935.46", "-$975,577.87", "$853,642.41" }, 
                    { "Increase in Closing Costs above legal limits - 0% Category", "$1,003,264.07", "", "", "" } },
                cat10Table: null,
                lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "-$75,744.90" }, 
                    { "Specific Lender Credits", "" }, 
                    { "A 02 Description Edit in PDD", "-$9,643.12" }, 
                    { "A 05 Origination Fee", "-$2,312.45" }, 
                    { "A 06 Second Adhoc Charge", "-$34,234.99" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "-$121,935.46" } },
                increaseTotal: 1003264.07);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US368196,US300130,US453668,US368326,US520920,US432034,US395858 – Verify Section B Charges in Good Faith Variance Screen")]
        public void FMUC0131_REG0002()
        {
            try
            {
                int rowCount;
                Reports.TestDescription = "US368196,US300130,US453668,US368326,US520920,US432034,US395858 – Verify Section B Charges in Good Faith Variance Screen";

                #region Log into FAST application & Create a new file
                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Navigate to New Loan – Add GAB code and enter amount in New Loan Charges (Section B) – 10%
                //**Navigate to New Loan – Add GAB code**//
                Reports.TestStep = "Navigate to New Loan Screen – Loan Charges Tab";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FindGABCode("WF");
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                //**Enter Amount in New Loan – Loan Charges – New Loan Charges (Section B) – 10%**//
                Reports.TestStep = "Enter Amount in New Loan – Loan Charges –  in New Loan Charges (Section B)";

                //**Appraisal Fee – Loan Estimate exists. No Buyer charge**//
                Reports.TestStep = "Appraisal Fee – Enter Amount in Grid";
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", null, null, 89.98, null, 200.45);
                Keyboard.SendKeys(FAKeys.TabAway);

                //**Credit Report – No Loan Estimate**//
                Reports.TestStep = "Credit Report – Enter Amount in PDD";
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("567.23");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("367.42");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("2322.34");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateBuyerCharge());
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("3242.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("3423.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("3454.45");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateSellerCharge());
                FastDriver.DialogBottomFrame.ClickDone();

                //**Flood Certification– Buyer Charge and Loan Estimate Exists**//
                Reports.TestStep = "Flood Certification– Enter Amount in PDD";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("93423423.67");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("93423423.12");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("234234.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2342334.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("234123.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("213123.45");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("522246.89");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                //**Adhoc Charge 1 – Buyer Charge and Loan Estimate Exists**//
                Reports.TestStep = "Adhoc Charge 1– Enter Amount in Grid";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                rowCount = FastDriver.NewLoan.NewLoanChargesTable.GetRowCount();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Adhoc Charge 1");
                Keyboard.SendKeys("{TAB}");
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "Adhoc Charge 1", 9876734333.34, null, 32434.67, null, 234234234.57);
                Keyboard.SendKeys("{TAB}");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Adhoc Charge 1", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LenderAffiliate.FASetCheckbox(false);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                //**Second Adhoc Charge – Loan Estimate exists. No Buyer charge**//
                Reports.TestStep = "Second Adhoc Charge– Enter Amount in Grid";
                rowCount = FastDriver.NewLoan.NewLoanChargesTable.GetRowCount();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Second Adhoc Charge");
                Keyboard.SendKeys("{TAB}");
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "Second Adhoc Charge", null, null, 32434.67, null, 53454.67);
                Keyboard.SendKeys("{TAB}");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Second Adhoc Charge", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LenderAffiliate.FASetCheckbox(false);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                //**Third Adhoc Charge – No Loan Estimate**//
                Reports.TestStep = "Third Adhoc Charge – Enter Amount in PDD";
                rowCount = FastDriver.NewLoan.NewLoanChargesTable.GetRowCount();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Third Adhoc Charge");
                Keyboard.SendKeys("{TAB}");
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "Third Adhoc Charge" + FAKeys.Tab);
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Third Adhoc Charge", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("32433.45");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("32234.12");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("2312.45");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateBuyerCharge());
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("3242.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("3423.45");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("3454.45");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateSellerCharge());
                FastDriver.PaymentDetailsDlg.LenderAffiliate.FASetCheckbox(false);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                #endregion

                #region Navigate to CD –GFV Screen and Verify Values in Good Faith Variance screen

                #region Good Faith Variance Rules
                ////**Navigate to CD Screen and Verify Values in Good Faith Variance screen**//

                ////**All the amounts will be displayed in 9.2 Format**//
                ///**Section A will be displayed as individual charges in below mentioned format:
                //    a.	Column 1 – <Section> <Line no. as displayed in CD Screen> <Charge Description as per CD> (E.g. A 01 10 % of Loan Amount (Points))
                //    b.	Column 2 (Loan Estimate Disclosed (Rounded)) – Loan Estimate Rounded Amount. (E.g. $0)	
                //    c.	Column 3 (Final (Borrower Paid)) – Sum of Buyer/Borrower At Closing and Before Closing. (E.g. $600.00)
                //    d.	Column 4 (Loan Estimate (Unrounded)) – Loan Estimate Unrounded Amount. (E.g. $0.00)
                //    e.	Column 5 (Amounts Exceeding 0% Good Faith Limit) – Final Amount – Loan Estimate Unrounded Amount (E.g. $600.00)
                //        i.	If Final Amount – Loan Estimate Unrounded Amount is a Positive value system will display the same in Column 5 else system will display $0.00
                //    **/

                ///**Last but one line (Before Total) in 0% category will be “ J 00 Lender Credits (See Lender Credit Analysis)”  – (Will be displayed as Negative Amount)
                //    a.	 Column 1 – J 00 Lender Credits (See Lender Credit Analysis) 
                //    b.	Column 2 (Loan Estimate Disclosed (Rounded)) – Sum of Non-Specific Lender Credits Loan Estimate Rounded amount from Loan Charge tab and Mortgage Broker tab (E.g. –$500)
                //    c.	Column 3 (Final (Borrower Paid)) – Total Amount of “Lender Credits Total (J) Excluding Good Faith Violation” under Lender Credit Analysis section. .(E.g. –$200.00)
                //    d.	Column 4 (Loan Estimate (Unrounded)) – Sum of Non-Specific Lender Credits Loan Estimate Unrounded amount from Loan Charge tab and Mortgage Broker tab. (E.g. –$500)
                //    e.	Column 5 (Amounts Exceeding 0% Good Faith Limit) – Final Amount – Loan Estimate Unrounded Amount (Positive Amount – E.g. $300.00)
                //        i.	If Final Amount – Loan Estimate Unrounded Amount is a Positive value system will display the same in Column 5 else system will display $0.00
                //    **/

                ////**Last line will be Increase in Closing Costs above legal limits - 0% Category – Sum of all (Amounts Exceeding 0% Good Faith Limit)**//

                ///** 1.	Non Specific Lender Credits – Sum of Non-Specific Lender Credits Buyer Credit amount from Loan Charge tab and Mortgage Broker tab (E.g. –$500.45)
                //    2.	Specific Lender Credits:
                //        a.	Displays Section A, Section B and Section E – Buyer Paid By Others Amount of Payment Method – POC – L/POC – MB/Lender / Mortgage Broker.
                //        b.	Section E – Sum of all Recording fees Paid By Others Amount will be displayed in single line.
                //        c.	Section E – Sum of all Transfer tax Paid By Others Amount will be displayed in single line.
                //    3.	Lender Credits Total (J) Excluding Good Faith Violation – Sum of Non Specific Lender Credits + Specific Lender Credits.**/

                ////**Last line below GFV 10% will be Increase in Closing Costs above legal limits – Total 0% and 10% Category = Sum of 0% + 10% (if amount is greater than Zero, system will display below line)**//
                #endregion

                Reports.TestStep = "Navigate to CD –GFV Screen and Verify Values in Good Faith Variance screen";
                FAST_VerifyGFaithVariance(cat0Table: new string [,]{
                    { "J 00 Lender Credits (See Lender Credit Analysis)", "$0", "-$236,556.79", "$0.00", "$0.00" }, 
                    { "Increase in Closing Costs above legal limits - 0% Category", "$828,824,698.67", "", "", "" }},
                    cat10Table: new string[,] { 
                    { "B 01 Adhoc Charge 1", "$234,234,235", "$234,234,234.57", "$234,234,234.57", "$876,734,333.34"}, 
                    { "B 02 Appraisal Fee", "$200", "$200.45", "$0.00", "$0.00" }, 
                    { "B 03 Credit Report", "$0", "$0.00", "$0.00", "$934.65" }, 
                    { "B 04 Flood Certification", "$522,247", "$522,246.89", "$522,246.89", "$186,846,846.79" }, 
                    { "B 05 Second Adhoc Charge", "$53,455", "$53,454.67", "$0.00", "$0.00" }, 
                    { "B 06 Third Adhoc Charge", "$0.00", "$0.00", "$0.00", "$64,667.57" }, 
                    { "Total Aggregate Fees", "$234,756,481.46", "$63,646,782.35", "", "" }, 
                    { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$23,475,648.00", "$828,890,300.89", "", "" }, 
                    { "Increase in Closing Costs above legal limits - 10% Category", "$805,414,652.89", "", "", "" }},
                    lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "B 03 Credit Report", "-$2,322.34" }, 
                    { "B 04 Flood Certification", "-$234,234.45" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "-$236,556.79" } },
                    increaseTotal: 805414652.89);

                //**Select to CD Screen and Edit Charge Description and Loan Estimate Amounts**//
                Reports.TestStep = "Select to CD Screen and Edit Charge Description and Loan Estimate Amounts";
                FastDriver.ClosingDisclosure.Open();
                //FastDriver.ClosingDisclosure.ClickCDTab();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.B, "Adhoc Charge 1", "CD Edit description to verify in GFV");
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.B, "Flood Certification", "Flood Certification edited");
                Keyboard.SendKeys("{TAB}");
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, "Flood Certification edited", false, 23453.34, 4);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, "Credit Report", false, 34789.66, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, "Third Adhoc Charge", false, 97764.54, 6);
                

                //**Verify in CD – GFV Screen if system displays the content as edited by the user**//
                Reports.TestStep = "Navigate to CD –GFV Screen and Verify Values in Good Faith Variance screen";
                FAST_VerifyGFaithVariance(cat0Table: new string[,]{
                    { "J 00 Lender Credits (See Lender Credit Analysis)", "$0", "-$236,556.79", "$0.00", "$0.00" }, 
                    { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" }},
                    cat10Table: new string[,] { 
                    { "B 01 Appraisal Fee", "$200", "$200.45", "$0.00", "$0.00" }, 
                    { "B 02 CD Edit description to verify in GFV", "$234,234,235", "$234,234,234.57", "$234,234,234.57", "$876,734,333.34"}, 
                    { "B 03 Credit Report", "$34,790", "$34,789.66", "$34,789.66", "$934.65" }, 
                    { "B 04 Flood Certification edited", "$23,453", "$23,453.34", "$23,453.34", "$186,846,846.79" }, 
                    { "B 05 Second Adhoc Charge", "$53,455", "$53,454.67", "$0.00", "$0.00" }, 
                    { "B 06 Third Adhoc Charge", "$97,765", "$97,764.54", "$97,764.54", "$64,667.57" }, 
                    { "Total Aggregate Fees", "$234,390,242.11", "$63,646,782.35", "", "" }, 
                    { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$23,439,024.00", "$829,256,540.24", "", "" }, 
                    { "Increase in Closing Costs above legal limits - 10% Category", "$805,817,516.24", "", "", "" }},
                    lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "B 03 Credit Report", "-$2,322.34" }, 
                    { "B 04 Flood Certification edited", "-$234,234.45" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "-$236,556.79" } },
                    increaseTotal: 805817516.24);

                #endregion

                #region Navigate to New Loan Screen and modify values in loan charges section
                //**Navigate to New Loan Screen and Enter Loan Amount**//
                Reports.TestStep = "Navigate to New Loan Screen and Enter Loan Amount";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();

                //**Add Buyer charge and update loan estimate amount for Appraisal Fee**//
                Reports.TestStep = "Add Buyer charge and update loan estimate amount for Appraisal Fee";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", 3453.45, null, null, null, 2334.98);

                //**Modify Amounts in PDD for NewLoan Charges Table**//
                Reports.TestStep = "Modify Amounts in NewLoan Charges Table Section";
                //**Credit Report**//
                Reports.TestStep = "Modify Credit Report Values";
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description Edit in PDD");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("2342.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("2434.52");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateBuyerCharge());
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("123546.89");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("23244");
                FastDriver.PaymentDetailsDlg.PartOf.Click();
                FastDriver.DialogBottomFrame.ClickDone();

                //**Flood Certification edited**//
                Reports.TestStep = "Modify \"Flood Certification edited\" Values";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification edited", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("45345.97");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("56756.67");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateBuyerCharge());
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);
                FastDriver.PaymentDetailsDlg.LenderAffiliate.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                //**CD Edit description to verify in GFV**//
                Reports.TestStep = "Modify \"CD Edit description to verify in GFV\" Values";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "CD Edit description to verify in GFV", 96756.45, null, null, null, 3453.56);

                //**Second Adhoc Charge**//
                Reports.TestStep = "Modify \"Second Adhoc Charge\" Values";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Second Adhoc Charge", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("34,234.99");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.DisplayLBorrower.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateBuyerCharge());
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("32,434.67");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.DisplayLSeller.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateSellerCharge());
                FastDriver.DialogBottomFrame.ClickDone();

                //**Third Adhoc Charge**//
                Reports.TestStep = "Modify \"Third Adhoc Charge\" Values";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Third Adhoc Charge", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("8343.34");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateBuyerCharge());
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("32,434.67");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateSellerCharge());
                FastDriver.PaymentDetailsDlg.LenderAffiliate.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                //**Lender Credits**//
                Reports.TestStep = "Add \"Non-Specific Lender Credits\" Values in Lender credits section – New Loan | Loan Charges";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.Expand(FastDriver.NewLoan.LoanCharges_ExpandLenderCredits);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LenderCreditsTable, "Non-Specific Lender Credits", null, 67899.78, null, null, 56756.76);

                //**Lender Credits – Mortgage Broker**//
                Reports.TestStep = "Add \"Non-Specific Lender Credits\" Values in Lender credits section – New Loan | Mortgage Broker";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_LenderCreditTable, "Non-Specific Lender Credits", null, 7845.12, null, null, 7678.09);

                //**Add amount for Mortgage Broker Charges in Mortgage Broker tab**//
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", 976332.13, null, 87633.34, null, 54454.56);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Adhoc Charge 1 Mortgage Broker", null, null, 32434.67, null, 32343.43);
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Mortgage Broker Adhoc Charge 2", 34534.34, null, 32434.67, null, null);
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Verify Loan Estimate", null, null, null, null, 54645.78);
                #endregion

                #region Verify in CD – GFV Screen if system displays the content as edited by the user
                //**Verify in CD – GFV Screen if system displays the content as edited by the user**//
                Reports.TestStep = "Navigate to CD –GFV Screen and Verify Values in Good Faith Variance screen";
                FAST_VerifyGFaithVariance(cat0Table: new string[,]{
                    { "B 06 Flood Certification edited", "Part of $23,453", "$102,102.64", "$23,453.34", "$78,649.30" }, 
                    { "B 09 Third Adhoc Charge", "$97,765", "$64,667.57", "$97,764.54", "$0.00" }, 
                    { "J 00 Lender Credits (See Lender Credit Analysis)", "-$64,435", "-$120,757.75", "-$64,434.85", "$0.00" }, 
                    { "Increase in Closing Costs above legal limits - 0% Category", "$78,649.30", "", "", "" }},
                    cat10Table: new string[,] { 
                    { "B 01 Adhoc Charge 1 Mortgage Broker", "$32,343", "$32,343.43", "$0.00", "$0.00" }, 
                    { "B 02 Appraisal Fee", "$2,335", "$2,334.98", "$2,334.98", "$3,453.45" }, 
                    { "B 03 Appraisal Fee", "$54,455", "$54,454.56", "$54,454.56", "$976,332.13" }, 
                    { "B 04 CD Edit description to verify in GFV", "$3,454", "$3,453.56", "$3,453.56", "$96,756.45"}, 
                    { "B 05 Description Edit in PDD ", "Part of $23,244", "$123,546.89", "$123,546.89", "$2,342.00"}, 
                    { "B 07 Mortgage Broker Adhoc Charge 2", "$0", "$0.00", "$0.00", "$34,534.34" }, 
                    { "B 08 Second Adhoc Charge", "$53,455", "$53,454.67", "$0.00", "$0.00" }, 
                    { "B 00 Verify Loan Estimate", "$54,646", "$54,645.78", "$0.00", "$0.00" }, 
                    { "Total Aggregate Fees", "$183,789.99", "$1,113,418.37", "", "" }, 
                    { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$18,379.00", "$929,628.38", "", "" }, 
                    { "Increase in Closing Costs above legal limits - 10% Category", "$911,249.38", "", "", "" }},
                    lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "-$75,744.90" }, 
                    { "Specific Lender Credits", "" }, 
                    { "B 05 Description Edit in PDD", "-$2,434.52" }, 
                    { "B 08 Second Adhoc Charge", "-$34,234.99" }, 
                    { "B 09 Third Adhoc Charge", "-$8,343.34" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "-$120,757.75" } },
                    increaseTotal: 989898.68);

                #endregion

                #region Navigate to New Loan Screen and Modify Lender Credits Amount
                //**Navigate to New Loan Screen and Modify Lender Credits Amount**//
                Reports.TestStep = "Navigate to New Loan Screen and Modify Lender Credits Amount";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LenderCreditsTable, "Non-Specific Lender Credits", null, null, null, null, 967899.78);

                //**Change Lender Affilated flag for below mentioned fees**//
                Reports.TestStep = @"Change Lender Affilated flag for below mentioned fees
                Adhoc Charge 1 Mortgage Broker,
                Appraisal Fee,
                Description Edit in PDD,
                Second Adhoc Charge,
                Verify Loan Estimate,
                Flood Certification edited,
                Third Adhoc Charge";

                //**Appraisal Fee**//
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LenderAffiliate.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                //**Description Edit in PDD**//
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Description Edit in PDD", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LenderAffiliate.FASetCheckbox(true);
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(false);
                FastDriver.DialogBottomFrame.ClickDone();

                //**Second Adhoc Charge**//
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Second Adhoc Charge", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LenderAffiliate.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                
                //**Flood Certification edited**//
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification edited", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LenderAffiliate.FASetCheckbox(false);
                FastDriver.DialogBottomFrame.ClickDone();

                //**Third Adhoc Charge**//
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Third Adhoc Charge", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LenderAffiliate.FASetCheckbox(false);
                FastDriver.DialogBottomFrame.ClickDone();

                //**Adhoc Charge 1 Mortgage Broker**//
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(1, "Adhoc Charge 1 Mortgage Broker", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LenderAffiliate.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                //**Verify Loan Estimate**//
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(1, "Verify Loan Estimate", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LenderAffiliate.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Verify in CD – GFV Screen if system displays the content as edited by the user
                //**Verify in CD – GFV Screen if system displays the content as edited by the user**//
                Reports.TestStep = "Navigate to CD –GFV Screen and Verify Values in Good Faith Variance screen";
                FAST_VerifyGFaithVariance(cat0Table: new string[,]{
                    { "B 02 Appraisal Fee", "$3,453", "$3,453.45", "$2,334.98", "$1,118.47" }, 
                    { "B 05 Description Edit in PDD", "$23,244", "$2,342.00", "$123,546.89", "0.00"}, 
                    { "J 00 Lender Credits (See Lender Credit Analysis)", "-$975,578", "-$120,757.75", "-$975,577.87", "$854,820.12" }, 
                    { "Increase in Closing Costs above legal limits - 0% Category", "$855,938.59", "", "", "" }},
                    cat10Table: new string[,] { 
                    { "B 03 Appraisal Fee", "$54,455", "$54,454.56", "$54,454.56", "$976,332.13" }, 
                    { "B 04 CD Edit description to verify in GFV", "$3,454", "$3,453.56", "$3,453.56", "$96,756.45"}, 
                    { "B 06 Flood Certification edited", "Part of $23,453", "$23,453.34", "$23,453.34", "$102,102.64" }, 
                    { "B 07 Mortgage Broker Adhoc Charge 2", "$0", "$0.00", "$0.00", "$34,534.34" }, 
                    { "B 09 Third Adhoc Charge", "$97,765", "$97,764.54", "$97,764.54", "$64,667.57" }, 
                    { "Total Aggregate Fees", "$179,126.00", "$1,274,393.13", "", "" }, 
                    { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$17,913.00", "$1,095,267.13", "", "" }, 
                    { "Increase in Closing Costs above legal limits - 10% Category", "$1,077,354.13", "", "", "" }},
                    lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "-$75,744.90" }, 
                    { "Specific Lender Credits", "" }, 
                    { "B 05 Description Edit in PDD", "-$2,434.52" }, 
                    { "B 08 Second Adhoc Charge", "-$34,234.99" }, 
                    { "B 09 Second Adhoc Charge", "-$8,343.34" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "-$120,757.75" } },
                    increaseTotal: 1933292.72);
                #endregion

                #region Navigate to New Loan, enter buyer charge and modify sections

                //**Navigate to New Loan, enter buyer charge and modify sections**//
                Reports.TestStep = @"Navigate to New Loan, enter buyer charge and modify sections
                                    Second Adhoc Charge, Third Adhoc Charge, Flood Certification edited, Appraisal Fee, Lender Credits, Lender Credits – Mortgage Broker, Lender Credits – Mortgage Broker ";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();

                //**Second Adhoc Charge**//
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Second Adhoc Charge", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("34346.23");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("0.23");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(FastDriver.PaymentDetailsDlg.CalculateBuyerCharge());
                FastDriver.DialogBottomFrame.ClickDone();

                //**Third Adhoc Charge**//
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Third Adhoc Charge", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SectionC.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();

                //**Flood Certification edited**//
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification edited", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SectionH.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();

                //**Appraisal Fee**//
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", null, null, null, null,5000.00);

                //**Lender Credits**//
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LenderCreditsTable, "Non-Specific Lender Credits", null, 10, null, null, 577.00);

                //**Lender Credits – Mortgage Broker**//
                Reports.TestStep = "Add \"Non-Specific Lender Credits\" Values in Lender credits section – New Loan | Mortgage Broker";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_LenderCreditTable, "Non-Specific Lender Credits", null, null, null, null, 100.00);
                #endregion

                #region Verify in CD – GFV Screen if system displays the content as edited by the user
                //**Verify in CD – GFV Screen if system displays the content as edited by the user**//
                Reports.TestStep = "Navigate to CD –GFV Screen and Verify Values in Good Faith Variance screen";
                FAST_VerifyGFaithVariance(cat0Table: new string[,]{
                    { "B 02 Appraisal Fee", "$5,000", "$3,453.45", "$5,000.00", "$0.00" }, 
                    { "B 05 Description Edit in PDD", "$23,244", "$2,342.00", "$123,546.89", "0.00"}, 
                    { "B 07 Second Adhoc Charge", "$53,454", "$34,346.23", "$53,454.67", "0.00"}, 
                    { "J 00 Lender Credits (See Lender Credit Analysis)", "-$677", "-$10,289.87", "-$677.00", "$0.00" }, 
                    { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" }},
                    cat10Table: new string[,] { 
                    { "B 03 Appraisal Fee", "$54,455", "$54,454.56", "$54,454.56", "$976,332.13" }, 
                    { "B 04 CD Edit description to verify in GFV", "$3,454", "$3,453.56", "$3,453.56", "$96,756.45"}, 
                    { "B 06 Mortgage Broker Adhoc Charge 2", "$0", "$0.00", "$0.00", "$34,534.34" }, 
                    { "Total Aggregate Fees", "$57,908.12", "$1,107,622.92", "", "" }, 
                    { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$5,791.00", "$1,049,714.80", "", "" }, 
                    { "Increase in Closing Costs above legal limits - 10% Category", "$1,043,923.80", "", "", "" }},
                    lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "-$7,855.12" }, 
                    { "Specific Lender Credits", "" }, 
                    { "B 05 Description Edit in PDD", "-$2,434.52" }, 
                    { "B 07 Second Adhoc Charge", "-$0.23" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "-$10,289.87" } },
                    increaseTotal: 1043923.80);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US368196,US453668,US368326,US368326,US432034,US432031,US395858  Fee Entry – Verify charges in Section E – Line 1 with all Recording Fee types.")]
        public void FMUC0131_REG0003()
        {
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion
                
                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file with New Loan Lender (214) and Mortgage Broker (BOA).";
                FAST_WCF_File_IIS(GAB: "BOA", GABRole: AdditionalRoleType.MortgageBroker, isTO: true, isEO: true, LenderID: "214", SPAmt: 0);
                #endregion

                #region FAST add fee to file
                Reports.TestStep = "Navigate to Fee Entry screen. Select Recording Fee and Tax. Click on Add Fees and add above created Fees (Without Filters).";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeDescription);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("E Recording Fee Deed1");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeSelect);
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);

                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("E Recording Fee Deed2");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeSelect);
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);

                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("E Recording Fee Mortgage1");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeSelect);
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);

                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Recording Fee - Mortgage2");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeSelect);
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);

                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("E Recording Fee Misc. description1");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeSelect);
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);

                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("E Recording Fee Misc. 2");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeSelect);
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release1", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release2", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release2", 4, TableAction.SetText, "5600");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release2", 5, TableAction.SetText, "4500.34");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Deed2", 4, TableAction.SetText, "2345.56");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Misc. 2", 5, TableAction.SetText, "89564.56");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Recording Fee - Mortgage2", 4, TableAction.SetText, "3423.23");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Recording Fee - Mortgage2", 5, TableAction.SetText, "563224.34");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Verify CD – Good Faith Variance
                Reports.TestStep = "Select Good Faith Variance Screen and verify the values displayed under Good Faith Analysis 10% Category";
                FAST_VerifyGFaithVariance(cat0Table: null, cat10Table: new string[,] { { "E 01 Recording Fees", "$0", "$0.00", "$0.00", "$233,342,673.43" }, { "Total Aggregate Fees", "$0.00", "$233,342,673.43", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$0.00", "$233,342,673.43", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$233,342,673.43", "", "", "" } }, lenderCredits: null, increaseTotal: 233342673.43);
                #endregion

                #region Enter Loan Estimate Unrounded Amount
                Reports.TestStep = "Select CD tab. Enter Loan Estimate Unrounded Amount. (E.g. 434323.45)";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.EditLoanEstimateSecE(ClosingDisclosure.RecordingFeeTransferTax.RecordingFee, 434323.45);
                #endregion

                #region Verify CD – Good Faith Variance after setting LEUnrounded
                Reports.TestStep = "Select Good Faith Variance screen and verify if Loan Estimate values are displayed";
                FAST_VerifyGFaithVariance(cat0Table: null, cat10Table: new string[,] { { "E 01 Recording Fees", "$434,323", "$434,323.45", "$434,323.45", "$233,342,673.43" }, { "Total Aggregate Fees", "$434,323.45", "$233,342,673.43", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$43,432.00", "$232,908,349.98", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$232,864,917.98", "", "", "" } }, lenderCredits: null, increaseTotal: 0);
                #endregion

                #region Edit LE Rounded amount in FileFee screen
                Reports.TestStep = @"Edit LE Rounded amount in FileFee screen and verify broken image link";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingLoanEstRounded.FASetText("5434323");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("True", FastDriver.FileFees.GTaxBrokenImage.IsDisplayed().ToString());
                #endregion

                #region Edit Recording fees
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release1", 4, TableAction.SetText, "4564.56");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release1", 5, TableAction.SetText, "0");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release2", 4, TableAction.SetText, "67542.45");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release2", 5, TableAction.SetText, "23243.34");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Deed1", 4, TableAction.SetText, "434.50");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Deed1", 5, TableAction.SetText, "565.50");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Deed2", 4, TableAction.SetText, "0");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Deed2", 5, TableAction.SetText, "23435.50");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Misc. 2", 4, TableAction.SetText, "43534");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Misc. 2", 5, TableAction.SetText, "87764");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Misc. description1", 4, TableAction.SetText, "4342.23");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Misc. description1", 5, TableAction.SetText, "2343.78");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Mortgage1", 4, TableAction.SetText, "0");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Mortgage1", 5, TableAction.SetText, "0.56");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Recording Fee - Mortgage2", 4, TableAction.SetText, "0.34");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Recording Fee - Mortgage2", 5, TableAction.SetText, "0");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD – Good Faith Variance after setting LEUnrounded
                Reports.TestStep = "Select Good Faith Variance screen and verify if Loan Estimate values are displayed";
                FAST_VerifyGFaithVariance(cat0Table: null, cat10Table: new string[,] { { "E 01 Recording Fees", "$5,434,323", "$434,323.45", "$434,323.45", "$120,418.08" }, { "Total Aggregate Fees", "$434,323.45", "$120,418.08", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$43,432.00", "$0.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } }, lenderCredits: null, increaseTotal: 0);
                #endregion

                #region Edit fee payment details in FileFees screen
                Reports.TestStep = "Edit fee payment details in FileFees screen";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release2", 3, TableAction.DoubleClick);
                var PDDDetails = new PaymentDetailsParameters()
                {
                    LEDescription = "Modified LE Description",
                    PayeeName = "Modified Payee Name",
                    PartOfCheckbox = true,
                    BuyerAtClosing = 34423.45,
                    BuyerBeforeClosing = 2234.55,
                    BuyerPaidbyOther = 7556.67,
                    BuyerPaidbyOtherPaymentMethod = "Mortgage Broker",
                    SellerPaidAtClosing = 7455.67,
                    SellerPaidBeforeClosing = 5676.76,
                    SellerPaidbyOthers = 8756,
                    SellerPaidbyOtherPaymentMthd = "Mortgage Broker"
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDDDetails);
                
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Deed2", 3, TableAction.DoubleClick);
                var PDDDetails1 = new PaymentDetailsParameters()
                {
                    LEDescription = "Deed2 Modified LE Description",
                    PayeeName = "Deed2 Modified Payee Name",
                    PartOfCheckbox = true,
                    BuyerAtClosing = 1500.87,
                    BuyerBeforeClosing = 4565.50,
                    BuyerPaidbyOther = 3345.50,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    SellerPaidAtClosing = 4544.49,
                    SellerPaidBeforeClosing = 34534.51,
                    SellerPaidbyOthers = 9243.50,
                    SellerPaidbyOtherPaymentMthd = "POC"
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDDDetails1);

                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Misc. description1", 3, TableAction.DoubleClick);
                var PDDDetails2 = new PaymentDetailsParameters()
                {
                    ChargeDescription = "E Recording Fee Misc. description1",
                    PartOfCheckbox = true,
                    BuyerAtClosing = 0,
                    BuyerLenderCheckbox = true,
                    SellerPaidAtClosing = 34423.56,
                    SellerPaidBeforeClosing = 45344.56,
                    SellerPaidbyOthers = 342323.45,
                    SellerPaidbyOtherPaymentMthd = "Lender",
                    SellerLenderCheckbox = true,
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDDDetails2);

                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Recording Fee - Mortgage2", 3, TableAction.DoubleClick);
                var PDDDetails3 = new PaymentDetailsParameters()
                {
                    PartOfCheckbox = true,
                    BuyerAtClosing = 560,
                    BuyerBeforeClosing = 670,
                    BuyerPaidbyOther = 345.44,
                    BuyerPaidbyOtherPaymentMethod = "Lender",
                    BuyerLenderCheckbox = false,
                    SellerPaidAtClosing = 0,
                };
                FastDriver.FileFees.SwitchToContentFrame();
                #endregion

                #region Verify CD – Good Faith Variance after modifying fee payment details
                Reports.TestStep = "Verify CD – Good Faith Variance after modifying fee payment details";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { 
                { "J 00 Lender Credits  (See Lender Credit Analysis)", "$0", "-$7,902.11", "$0.00", "$0.00" }, 
                { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } }, 
                cat10Table: new string[,] 
                { { "E 01 Recording Fees", "$5,434,323", "$434,323.45", "$434,323.45", "$92,487.43" }, 
                { "Total Aggregate Fees", "$434,323.45", "$92,487.43", "", "" }, 
                { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$43,432.00", "$0.00", "", "" }, 
                { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } },
                lenderCredits: new string[,]{ 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "E 01 Recording Fees", "-$7,902.11" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "-$7,902.11" } }, 
                    increaseTotal: 0);
                #endregion

                #region Edit and Verify Loan Estimate Unrounded Amount in CD Section E
                Reports.TestStep = "Select Closing Disclosure tab. Enter Loan Estimate unrounded amount. (E.g. 5,345.56)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FastDriver.ClosingDisclosure.ClickCDTab().WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.EditLoanEstimateSecE(ClosingDisclosure.RecordingFeeTransferTax.RecordingFee, 5345.56);
                #endregion

                #region Verify Good Faith Variance table
                Reports.TestStep = @"Select Good Faith Variance tab and verify the values displayed under Good Faith Variance 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits  (See Lender Credit Analysis)", "$0", "-$7,902.11", "$0.00", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } }, cat10Table: new string[,] { { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$92,487.43" }, { "Total Aggregate Fees", "$5,345.56", "$92,487.43", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$87,141.87", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$86,606.87", "", "", "" } }, lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "E 01 Recording Fees", "-$7,902.11" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$7,902.11" } }, increaseTotal: 0);
                #endregion

                #region Pay Recording/Tax
                Reports.TestStep = @"Click on Pay Recording/Tax button and add new Payees. (E.g. 415)";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.PayRecordingTax.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.WaitForScreenToLoad();
                FastDriver.RecordFeeTransferTaxDisb.New.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.GABcode.FASetText("415");
                FastDriver.RecordFeeTransferTaxDisb.Find.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.WaitCreation(FastDriver.RecordFeeTransferTaxDisb.GABLabel, 5);
                FastDriver.RecordFeeTransferTaxDisb.None.Click();
                FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, "E Recording Fee - Release2", 1, TableAction.On);
                FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, "E Recording Fee Deed1", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Edit Mortgage Fee charges
                Reports.TestStep = @"Updated amounts for E Recording Fee Mortgage1 => $0.00";
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Mortgage1", 4, TableAction.SetText, "0");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Mortgage1", 5, TableAction.SetText, "0");
                Reports.TestStep = @"Uncheck Recording Fee - Mortgage2.";
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Recording Fee - Mortgage2", 1, TableAction.Off);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter Buyer credits and LE amount for Lender in New Loan – Loan Charges tab
                Reports.TestStep = @"Navigate to New Loan – Loan Charges then enter Buyer Credit Amount and LE for Non-Specific Lender Credits.";
                FAST_UpdateLenderCredits(new string[,] { { "2", "", "", "", "56734", "", "", "34534" } });
                #endregion

                #region Verify Good Faith Variance table
                Reports.TestStep = @"Verify the values displayed under Good Faith Variance 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits  (See Lender Credit Analysis)", "–$34,534", "–$64,290.67", "–$34,534.00", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } }, cat10Table: new string[,] { { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$91,257.43" }, { "Total Aggregate Fees", "$5,345.56", "$91,257.43", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$85,911.87", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$85,376.87", "", "", "" } }, lenderCredits: new string[,] { { "Non-Specific Lender Credits", "–$56,734.00" }, { "Specific Lender Credits", "" }, { "E 01 Recording Fees", "–$7,556.67" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "–$64,290.67" } }, increaseTotal: 85376.87);
                #endregion

                #region Modify Buyer credits and LE amount for Lender in New Loan – Loan Charges tab
                Reports.TestStep = @"Navigate to New Loan – Loan Charges then enter Buyer Credit Amount and LE for Non-Specific Lender Credits.";
                FAST_UpdateLenderCredits(new string[,] { { "2", "", "", "", "56734", "", "", "134534.50" } });
                #endregion

                #region Modify fee Payment Details
                Reports.TestStep = "Modify fee Payment Details";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Deed1", 3, TableAction.DoubleClick);
                var PDDDetails4 = new PaymentDetailsParameters()
                {
                    LEDescription = "E Recording Fee Deed LEDesc.",
                    PayeeName = "First American Financial Corporation",
                    PartOfCheckbox = false,
                    BuyerAtClosing = 434.50,
                    SellerPaidAtClosing = 565.50,
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDDDetails4);

                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release2", 3, TableAction.DoubleClick);
                var PDDDetails5 = new PaymentDetailsParameters()
                {
                    LEDescription = "Modified LE Description",
                    PayeeName = "First American",
                    PartOfCheckbox = true,
                    BuyerAtClosing = 34423.45,
                    BuyerBeforeClosing = 2234.55,
                    BuyerPaidbyOther = 7556.67,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    SellerPaidAtClosing = 7455.67,
                    SellerPaidBeforeClosing = 5676.76,
                    SellerPaidbyOthers = 8756.00,
                    SellerPaidbyOtherPaymentMthd = "POC"
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDDDetails5);

                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Misc. description1", 3, TableAction.DoubleClick);
                var PDDDetails6 = new PaymentDetailsParameters()
                {
                    PartOfCheckbox = true,
                    BuyerAtClosing = 0,
                    SellerPaidAtClosing = 34423.56,
                    SellerPaidBeforeClosing = 45344.56,
                    SellerPaidbyOthers = 342323.45,
                    SellerPaidbyOtherPaymentMthd = "Lender",
                    SellerLenderCheckbox = false
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDDDetails6);

                FastDriver.FileFees.SwitchToContentFrame();
                #endregion

                #region Verify Good Faith Variance table
                Reports.TestStep = @"Verify the values displayed under Good Faith Variance 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits  (See Lender Credit Analysis)", "–$134,535", "–$56,734.00", "–$134,534.50", "$77,800.50" }, { "Increase in Closing Costs above legal limits - 0% Category", "$77,800.50", "", "", "" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$91,257.43" }, { "Total Aggregate Fees", "$5,345.56", "$91,257.43", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$85,911.87", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$85,376.87", "", "", "" } }, lenderCredits: new string[,] { { "Non-Specific Lender Credits", "–$56,734.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "–$56,734.00" } },
                    increaseTotal: 163177.37);
                #endregion

                #region Update Future Recording Fees in New Loan Screen.
                Reports.TestStep = @"Add Buyer Charge for any future recording Fee. (E.g. Future Recording Fee - Assignment:  Buyer Charge $999.99)
                
                                                     4.	Add Buyer Charge in PDD Future Recording Fee - Deed. Modify the payee name.
                                                            a.	Future Recording Fee - Deed:
                                                                Buyer Charge At Closing - $1000.50
                                                                Uncheck Use Default and Change Payee Name - Modified Payee Name
                                                            b.	Modify Charge Description to Modified Future Recording
                
                                                      5. Add Buyer Charge in PDD Future Recording Fee - Mortgage. Remove the payee name.
                                                            a.	Future Recording Fee - Mortgage:
                                                                Buyer Charge At Closing - $2423423
                                                                Uncheck Use Default and Remove Payee Name
                                                        ";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderBuyerCharge.FASetText("999.99");

                FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable.PerformTableAction(1, "Future Recording Fee - Assignment", 2, TableAction.DoubleClick);
                var details = new PaymentDetailsParameters
                {
                    BuyerAtClosing = 1000.50,
                    UseDefaultModify = false,
                    UpdateDescription = true,
                    PayeeName = "Modified Payee Name",
                    ChargeDescription = "Modified Future Recording",
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(details);

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable.PerformTableAction(1, "Future Recording Fee - Deed", 2, TableAction.DoubleClick);
                var details1 = new PaymentDetailsParameters
                {
                    BuyerAtClosing = 2423423,
                    UseDefaultModify = false,
                    PayeeName = " ",
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(details1);
                #endregion

                #region Update Future Recording Fees in Mortgage Broker tab.
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.Mortgage_FutureRecFeesTable.PerformTableAction(1, "Future Recording Fee - Assignment", 3, TableAction.SetText, "233129024.68");


                FastDriver.NewLoan.Mortgage_FutureRecFeesTable.PerformTableAction(1, "Future Recording Fee - Deed", 2, TableAction.DoubleClick);
                var details2 = new PaymentDetailsParameters
                {
                    BuyerAtClosing = 34234,
                    UseDefaultModify = false,
                    PayeeName = "Payee Name Mortgage Broker",
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(details2);

                #endregion

                #region Verify CD Good Faith Variance after updating Lender Credits
                Reports.TestStep = "Verify CD Good Faith Variance after updating Lender Credits";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits (See Lender Credit Analysis)", "-$134,535", "-$56,734.00", "-$134,534.50", "$77,800.50" }, { "Increase in Closing Costs above legal limits - 0% Category", "$77,800.50", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$56,734.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$56,734.00" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$235,678,939.61" }, { "Total Aggregate Fees", "$5,345.56", "$235,678,939.61", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$235,673,594.05", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$235,673,059.05", "", "", "" } },
                    increaseTotal: 235750859.55);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("US368196,US453668,US368326,US368326,US432034,US432031,US395858 OTC – Verify charges in Section E – Line 1 with all Recording Fee types")]
        public void FMUC0131_REG0004()
        {
            try
            {
                Reports.TestDescription = "OTC – Verify charges in Section E – Line 1 with all Recording Fee types";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file with New Loan Lender (214) and Mortgage Broker (BOA).";
                FAST_WCF_File_IIS(GAB: "BOA", GABRole: AdditionalRoleType.MortgageBroker, isTO: true, isEO: true, LenderID: "214", SPAmt: 0);
                #endregion

                #region Enter OTC's bussiness party
                Reports.TestStep = "Navigate to OTC Screen.  Enter GAB Code. (E.g. 415)";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.GABcode.FASetText("415");
                FastDriver.OTCDetail.Find.FAClick();
                FastDriver.OTCDetail.WaitCreation(FastDriver.OTCDetail.GABcodeLabel);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Set OTC's Recording Tax Fee LE Unrounded amount $7000.49
                Reports.TestStep = @"Set the Unrounded Amount:7000.49:";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.WaitForScreenToLoad(FastDriver.OTCDetail.GRCLoanEstimateUnroundedAmount);
                FastDriver.OTCDetail.GRCLoanEstimateUnroundedAmount.FASetText("7000.49");
                Keyboard.SendKeys(FAKeys.TabAway);

                #endregion

                #region Add OTC's Recording fees
                Reports.TestStep = "Click on Add Recording Fees button under Recording Fees & Transfer Taxes. Add Fees which were created in admin.";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.AddRecordingFees.FAClick();
                FastDriver.AddOTCFees.WaitForScreenToLoad();
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee Deed1", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee Deed2", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee Mortgage1", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee Misc. description1", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee Misc. 2", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee - Release1", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee - Release2", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "Recording Fee - Mortgage2", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter values for OTC's Recording fees
                Reports.TestStep = @"Enter values for OTC's Recording fees";
                FastDriver.OTCDetail.WaitForScreenToLoad();
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed2", 3, TableAction.SetText, "2345.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed2", 4, TableAction.SetText, "2345.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Misc. 2", 3, TableAction.SetText, "89564.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Misc. 2", 4, TableAction.SetText, "89564.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "Recording Fee - Mortgage2", 3, TableAction.SetText, "3423.23");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "Recording Fee - Mortgage2", 4, TableAction.SetText, "563224.34");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release2", 3, TableAction.SetText, "5600");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release2", 4, TableAction.SetText, "4500.34");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Good Faith Variance 10% Analisys table
                Reports.TestStep = "Select Good Faith Variance Screen and verify the values displayed under Good Faith Analysis 10% Category:";
                FAST_VerifyGFaithVariance(cat10Table: new string[,] { 
                { "E 01 Recording Fees", "$7,000", "$7,000.49", "$7,000.49", "$233,432,237.99" }, 
                { "Total Aggregate Fees", "$7,000.49", "$233,432,237.99", "", "" }, 
                { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$700.00", "$233,425,237.50", "", "" }, 
                { "Increase in Closing Costs above legal limits - 10% Category", "$233,424,537.50", "", "", "" } },
                lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } }, 
                increaseTotal: 233424537.50
                );
                #endregion

                #region Edit LE Unrounded amount in CD Section E
                Reports.TestStep = "Select CD tab. Enter Loan Estimate Unrounded Amount. (E.g. 434323.45)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FastDriver.ClosingDisclosure.ClickCDTab().WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Other_Costs.FAClick();
                FastDriver.ClosingDisclosure.EditLoanEstimateSecE(ClosingDisclosure.RecordingFeeTransferTax.RecordingFee, 434323.45);
                Keyboard.SendKeys(FAKeys.TabAway);
                #endregion

                #region Verify CD Good Faith Variance 10%
                Reports.TestStep = "Select Good Faith Variance screen and verify if Loan Estimate values are displayed";
                FAST_VerifyGFaithVariance(cat10Table: new string[,] { 
                { "E 01 Recording Fees", "$434,323", "$434,323.45", "$434,323.45", "$233,432,237.99" }, 
                { "Total Aggregate Fees", "$434,323.45", "$233,432,237.99", "", "" }, 
                { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$43,432.00", "$232,997,914.54", "", "" }, 
                { "Increase in Closing Costs above legal limits - 10% Category", "$232,954,482.54", "", "", "" } },
                lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } }, 
                increaseTotal: 232954482.54);
                #endregion

                #region Update LE Amount in OTC
                Reports.TestStep = @"Edit LE Amount values in OTC Screen";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.GRCLoanEstimateRoundedAmount.FASetText("5434323");
                Keyboard.SendKeys(FAKeys.TabAway);

                #endregion

                #region Enter values for OTC's Recording fees
                Reports.TestStep = @"Enter values for OTC's Recording fees";
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed1", 3, TableAction.SetText, "434.50");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed1", 4, TableAction.SetText, "565.50");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed2", 3, TableAction.SetText, "0");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed2", 4, TableAction.SetText, "23435.50");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Misc. 2", 3, TableAction.SetText, "43534");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Misc. 2", 4, TableAction.SetText, "87764");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Misc. description1", 3, TableAction.SetText, "4342.23");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Misc. description1", 4, TableAction.SetText, "2343.78");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Mortgage1", 3, TableAction.SetText, "0");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Mortgage1", 4, TableAction.SetText, "0.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "Recording Fee - Mortgage2", 3, TableAction.SetText, "0.34");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "Recording Fee - Mortgage2", 4, TableAction.SetText, "0");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release1", 3, TableAction.SetText, "4564.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release1", 4, TableAction.SetText, "0");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release2", 3, TableAction.SetText, "67542.45");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release2", 4, TableAction.SetText, "23243.34");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Good Faith Variance 10% category table
                Reports.TestStep = @"Select Good Faith Variance screen and verify the values displayed in Good Faith Variance screen.";
                FAST_VerifyGFaithVariance(cat10Table: new string[,] { 
                { "E 01 Recording Fees", "$5,434,323", "$434,323.45", "$434,323.45", "$120,418.08" }, 
                { "Total Aggregate Fees", "$434,323.45", "$120,418.08", "", "" }, 
                { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$43,432.00", "$0.00", "", "" }, 
                { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } },
                lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } }
                );
                #endregion

                #region Edit PDD for OTC's Recording fees
                Reports.TestStep = @"Edit PDD for OTC's Recording fees";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release2", 1, TableAction.DoubleClick);
                var PDDDetails = new PaymentDetailsParameters
                {
                    LEDescription = "Modified Loan Estimate Description",
                    PayeeName = "Modified Payee Name",
                    PartOfCheckbox = false,
                    BuyerAtClosing = 34423.45,
                    BuyerBeforeClosing = 2234.55,
                    BuyerPaidbyOther = 7556.67,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    SellerPaidAtClosing = 7455.67,
                    SellerPaidBeforeClosing = 5676.76,
                    SellerPaidbyOthers = 8756,
                    SellerPaidbyOtherPaymentMthd = "POC"
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDDDetails);

                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed2", 1, TableAction.DoubleClick);
                var PDDDetails1 = new PaymentDetailsParameters
                {
                    LEDescription = "Deed2 Modified Loan Estimate Description",
                    PayeeName = "Deed2 Modified Payee Name",
                    PartOfCheckbox = false,
                    BuyerAtClosing = 1500.87,
                    BuyerBeforeClosing = 4565.50,
                    BuyerPaidbyOther = 34534.51,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    SellerPaidAtClosing = 4544.49,
                    SellerPaidBeforeClosing = 3345.50,
                    SellerPaidbyOthers = 9243.50,
                    SellerPaidbyOtherPaymentMthd = "POC"
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDDDetails1);

                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Misc. description1", 1, TableAction.DoubleClick);
                var PDDDetails2 = new PaymentDetailsParameters
                {
                    PartOfCheckbox = false,
                    BuyerAtClosing = 4342.23,
                    SellerPaidAtClosing = 34423.56,
                    SellerPaidBeforeClosing = 45344.56,
                    SellerPaidbyOthers = 342323.45,
                    SellerPaidbyOtherPaymentMthd = "POC"
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDDDetails2);

                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "Recording Fee - Mortgage2", 1, TableAction.DoubleClick);
                var PDDDetails3 = new PaymentDetailsParameters
                {
                    PartOfCheckbox = true,
                    BuyerAtClosing = 560.00,
                    BuyerBeforeClosing = 670.00,
                    BuyerPaidbyOther = 345.44,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDDDetails3);
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                #endregion

                #region Verify CD Good Faith Variance after modifying recording fees PDD
                Reports.TestStep = "Verify CD Good Faith Variance after modifying recording fees PDD";
                FAST_VerifyGFaithVariance(cat10Table: new string[,] { 
                { "E 01 Recording Fees", "$5,434,323", "$434,323.45", "$434,323.45", "$96,829.66" }, 
                { "Total Aggregate Fees", "$434,323.45", "$96,829.66", "", "" }, 
                { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$43,432.00", "$0.00", "", "" }, 
                { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } },
                lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } });
                #endregion

                #region Update LE Unrounded amount in CD Section E
                Reports.TestStep = "Select Closing Disclosure tab. Enter Loan Estimate unrounded amount. (E.g. 5,345.56)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FastDriver.ClosingDisclosure.ClickCDTab().WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Other_Costs.FAClick();
                FastDriver.ClosingDisclosure.EditLoanEstimateSecE(ClosingDisclosure.RecordingFeeTransferTax.RecordingFee, 5345.56);
                Keyboard.SendKeys(FAKeys.TabAway);
                #endregion

                #region Verify CD Good Faith Variance after modifying LE Unrounded
                Reports.TestStep = "Verify CD Good Faith Variance after modifying LE Unrounded";
                FAST_VerifyGFaithVariance(cat10Table: new string[,] { 
                { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$96,829.66" }, 
                { "Total Aggregate Fees", "$5,345.56", "$96,829.66", "", "" }, 
                { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$91,484.10", "", "" }, 
                { "Increase in Closing Costs above legal limits - 10% Category", "$90,949.10", "", "", "" } },
                lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } }, 
                    increaseTotal: 90949.10);
                #endregion

                #region Update Buyer  and Seller amounts for E Recording Fee Mortgage1
                Reports.TestStep = @"Update Buyer  and Seller amounts for E Recording Fee Mortgage1";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Mortgage1", 3, TableAction.SetText, "0");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Mortgage1", 4, TableAction.SetText, "0");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter Buyer credits and LE amount for Lender in New Loan - Loan Charges tab
                Reports.TestStep = @"Navigate to New Loan - Loan Charges then enter Buyer Credit Amount and LE for Non-Specific Lender Credits.";
                FAST_UpdateLenderCredits(new string[,] { { "2", "", "", "", "56734", "", "", "34534" } });
                #endregion

                #region Verify CD Good Faith Variance after setting Lender Credits
                Reports.TestStep = "Verify CD Good Faith Variance after setting Lender Credits";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits (See Lender Credit Analysis)", "-$34,534", "-$56,734.00", "-$34,534.00", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$56,734.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$56,734.00" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$96,829.66" }, { "Total Aggregate Fees", "$5,345.56", "$96,829.66", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$91,484.10", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$90,949.10", "", "", "" } },
                    increaseTotal: 90949.10);
                #endregion

                #region Update Buyer credits and LE amount for Lender in New Loan - Loan Charges tab
                Reports.TestStep = @"Update Buyer credits and LE amount for Lender in New Loan - Loan Charges tab";
                FAST_UpdateLenderCredits(new string[,] { { "2", "", "", "", "56734", "", "", "134534.50" } });
                #endregion

                #region Verify CD Good Faith Variance after updating Lender Credits
                Reports.TestStep = "Verify CD Good Faith Variance after updating Lender Credits";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits (See Lender Credit Analysis)", "-$134,535", "-$56,734.00", "-$134,534.50", "$77,800.50" }, { "Increase in Closing Costs above legal limits - 0% Category", "$77,800.50", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$56,734.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$56,734.00" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$96,829.66" }, { "Total Aggregate Fees", "$5,345.56", "$96,829.66", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$91,484.10", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$90,949.10", "", "", "" } },
                    increaseTotal: 168749.60);
                #endregion

                #region Update Future Recording Fees in New Loan Screen.
                Reports.TestStep = @"Add Buyer Charge for any future recording Fee. (E.g. Future Recording Fee - Assignment:  Buyer Charge $999.99)
                
                                                     4.	Add Buyer Charge in PDD Future Recording Fee - Deed. Modify the payee name.
                                                            a.	Future Recording Fee - Deed:
                                                                Buyer Charge At Closing - $1000.50
                                                                Uncheck Use Default and Change Payee Name - Modified Payee Name
                                                            b.	Modify Charge Description to Modified Future Recording
                
                                                      5. Add Buyer Charge in PDD Future Recording Fee - Mortgage. Remove the payee name.
                                                            a.	Future Recording Fee - Mortgage:
                                                                Buyer Charge At Closing - $2423423
                                                                Uncheck Use Default and Remove Payee Name
                                                        ";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderBuyerCharge.FASetText("999.99");
                
                FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable.PerformTableAction(1, "Future Recording Fee - Assignment", 2, TableAction.DoubleClick);
                var details = new PaymentDetailsParameters
                {
                    BuyerAtClosing = 1000.50,
                    UseDefaultModify = false,
                    UpdateDescription = true,
                    PayeeName = "Modified Payee Name",
                    ChargeDescription = "Modified Future Recording",
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(details);

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable.PerformTableAction(1, "Future Recording Fee - Deed", 2, TableAction.DoubleClick);
                var details1 = new PaymentDetailsParameters
                {
                    BuyerAtClosing = 2423423,
                    UseDefaultModify = false,
                    PayeeName = " ",
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(details1);
                #endregion

                #region Update Future Recording Fees in Mortgage Broker tab.
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.Mortgage_FutureRecFeesTable.PerformTableAction(1, "Future Recording Fee - Assignment", 3, TableAction.SetText,"233123452.45");
                

                FastDriver.NewLoan.Mortgage_FutureRecFeesTable.PerformTableAction(1, "Future Recording Fee - Deed", 2, TableAction.DoubleClick);
                var details2 = new PaymentDetailsParameters
                {
                    BuyerAtClosing = 34234,
                    UseDefaultModify = false,
                    PayeeName = "Payee Name Mortgage Broker",
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(details2);

                #endregion

                #region Verify CD Good Faith Variance after updating Lender Credits
                Reports.TestStep = "Verify CD Good Faith Variance after updating Lender Credits";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits (See Lender Credit Analysis)", "-$134,535", "-$56,734.00", "-$134,534.50", "$77,800.50" }, { "Increase in Closing Costs above legal limits - 0% Category", "$77,800.50", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$56,734.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$56,734.00" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$235,678,939.61" }, { "Total Aggregate Fees", "$5,345.56", "$235,678,939.61", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$235,673,594.05", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$235,673,059.05", "", "", "" } },
                    increaseTotal: 235750859.55);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("US432033,US453668 Fee Entry – Verify charges in Section E – Line 2 with all Transfer Tax Fee types.")]
        public void FMUC0131_REG0005()
        {
            try
            {
                Reports.TestDescription = "Fee Entry – Verify charges in Section E – Line 2 with all Transfer Tax Fee types.";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file with New Lender(WF), Mortgage Broker(312), Sales Price ($56700), Loan Amount($74545.56), City (Santa Ana), State (CA) and County(Orange).";
                FAST_WCF_File_IIS(GAB: "312", GABRole: AdditionalRoleType.MortgageBroker, isTO: true, isEO: true, SPAmt: 56700, loanAmt: (decimal)74545.56, LenderID: "WF");
                #endregion

                #region FAST add fee to file
                Reports.TestStep = "Navigate to Fee Entry screen. Select Recording Fee and Tax. Click on Add Fees and add above created Fees (Without Filters).";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeDescription);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CD - E Transfer Tax Deed1");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeSelect);
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CD - E Transfer Tax Deed2");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeSelect);
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CD - Transfer Tax – Miscellaneous");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeSelect);
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CD - E Transfer Tax Misc. description1");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeSelect);
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CD - E Transfer Tax – Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeSelect);
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CD - E Transfer Tax – Mortgage1");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeSelect);
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax – Mortgage2", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax Misc. 2", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax Deed3", 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax – Mortgage", 4, TableAction.SetText, "5000.50");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax – Mortgage", 5, TableAction.SetText, "4560.67");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax – Mortgage2", 4, TableAction.SetText, "567.67");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax Deed2", 4, TableAction.SetText, "2343.56");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax Misc. 2", 4, TableAction.SetText, "34234.56");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax Misc. 2", 5, TableAction.SetText, "23433.43");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - Transfer Tax – Miscellaneous", 5, TableAction.SetText, "3433.45");

                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$0", "$233,373,450.93", "$0.00", "$233,373,450.93" }, { "Increase in Closing Costs above legal limits - 0% Category", "$233,373,450.93", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 233373450.93);
                #endregion

                #region Enter Loan Estimate Unrounded amount. (E.g. 598765.55)
                Reports.TestStep = @"Enter Loan Estimate Unrounded amount. (E.g. 598765.55)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FastDriver.ClosingDisclosure.ClickCDTab().WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.EditLoanEstimateSecE(ClosingDisclosure.RecordingFeeTransferTax.TransferTax, 598765.55);
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$598,766", "$233,373,450.93", "$598,765.55", "$232,774,685.38" }, { "Increase in Closing Costs above legal limits - 0% Category", "$232,774,685.38", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 232774685.38);
                #endregion

                #region Navigate to Fee Entry Screen | Recording and Tax tab and verify if system displays the Loan Estimate Unrounded and Rounded amount.
                Reports.TestStep = @"Navigate to Fee Entry Screen | Recording and Tax tab and verify if system displays the Loan Estimate Unrounded and Rounded amount.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                Support.AreEqual("$598,765.55", FastDriver.FileFees.TranTaxLoanEstUnrounded.FAGetValue());
                Support.AreEqual("$598,766.00", FastDriver.FileFees.TranTaxLoanEstRounded.FAGetValue());
                #endregion

                #region Modify Recoring Fee buyer/seller amount
                Reports.TestStep = @"Modify Recoring Fee buyer/seller amount";
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax Deed1", 4, TableAction.SetText, "5698.49");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax Deed1", 5, TableAction.SetText, "2312.50");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax Deed2", 4, TableAction.SetText, "2343.56");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax Deed2", 5, TableAction.SetText, "3433.45");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - Transfer Tax – Miscellaneous", 4, TableAction.SetText, "43543.78");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax – Mortgage", 4, TableAction.SetText, "85754.67");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "CD - E Transfer Tax – Mortgage1", 4, TableAction.SetText, "228.38");
                #endregion

                #region Modify Loan Estimate Unrounded amount. (E.g. 463434.45)
                Reports.TestStep = @"Modify Loan Estimate Unrounded amount. (E.g. 463434.45)";
                FastDriver.FileFees.TranTaxLoanEstUnrounded.FASetText("463434.45");
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { 
                { "E 02+ Transfer Taxes", "$463,434", "$233,404,683.87", "$463,434.45", "$232,941,249.42" }, 
                { "Increase in Closing Costs above legal limits - 0% Category", "$232,941,249.42", "", "", "" } },
                lenderCredits: new string[,] { 
                { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                increaseTotal: 232941249.42);
                #endregion

                #region Enter Loan Estimate Rounded amount. (E.g. 3423.45)
                Reports.TestStep = @"Enter Loan Estimate Rounded amount. (E.g. 3423.45)";
                FastDriver.ClosingDisclosure.ClickCDTab().WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.EditLoanEstimateSecE(ClosingDisclosure.RecordingFeeTransferTax.TransferTax, null, 3423.45);
                #endregion

                #region Try to remove the Charge description for any of the charge
                Reports.TestStep = @"Try to Remove the Charge description for any of the charge.";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.OCSectionEplusTable);
                FastDriver.ClosingDisclosure.OCSectionEplusTable.PerformTableAction(3, 1, TableAction.SetText, " ");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Loan Estimate Description cannot be blank.", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                Keyboard.SendKeys(FAKeys.TabAway);
                #endregion

                #region Modify Charge description for “CD - E2 Transfer Tax - Mo”
                Reports.TestStep = @"Modify Charge description for “CD - E2 Transfer Tax - Mo” to “transf modified charge description with maximum characters in CD Screen";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.OCSectionEplusTable.PerformTableAction(1, "CD - E2 Transfer Tax - Mo", 1, TableAction.SetText, "transf modified charge description within maximum characters in CD Screen");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Fee Entry Screen | Recording and Tax tab and verify if system displays the Loan Estimate Unrounded and Rounded amount.
                Reports.TestStep = @"Navigate to Fee Entry Screen | Recording and Tax tab and verify if system displays the Loan Estimate Unrounded and Rounded amount.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                Support.AreEqual("$463,434.45", FastDriver.FileFees.TranTaxLoanEstUnrounded.FAGetValue());
                Support.AreEqual("$3,423.00", FastDriver.FileFees.TranTaxLoanEstRounded.FAGetValue());
                #endregion

                #region Open PDD for the below mentioned fees and modify the values in PDD
                Reports.TestStep = @"Open PDD for the below mentioned fees and modify the values in PDD.";
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, "CD - E Transfer Tax Deed1", 3, TableAction.DoubleClick);
                var pdddetails = new PaymentDetailsParameters()
                {
                    BuyerAtClosing = 500.56,
                    BuyerBeforeClosing = 232.34,
                    BuyerPaidbyOther = 789.45,
                    BuyerPaidbyOtherPaymentMethod = "Lender",
                    SellerPaidAtClosing = 895.56,
                    SellerPaidBeforeClosing = 234.51,
                    SellerPaidbyOthers = 678.67,
                    SellerPaidbyOtherPaymentMthd = "Lender",
                    LEDescription = "Source Screen Updated Description",
                    PayeeName = "Source - Wells Fargo Payee Name",
                    BuyerDoubleAsteriskChecked = true
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(pdddetails);
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, "CD - E Transfer Tax Deed2", 3, TableAction.DoubleClick);
                var pdddetails1 = new PaymentDetailsParameters()
                { 
                    BuyerAtClosing = 2343.56, 
                    SellerPaidAtClosing = 0, 
                    SellerPaidBeforeClosing = 3432.45, 
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(pdddetails1);
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, "CD - E Transfer Tax Deed3", 3, TableAction.DoubleClick);
                var pdddetails2 = new PaymentDetailsParameters()
                { 
                    BuyerAtClosing = 3454.75, 
                    BuyerBeforeClosing = 7684.23, 
                    BuyerPaidbyOther = 8656.56, 
                    BuyerPaidbyOtherPaymentMethod = "POC", 
                    SellerPaidAtClosing = 5675.50, 
                    SellerPaidBeforeClosing = 3232.34, 
                    SellerPaidbyOthers = 9865.23, 
                    SellerPaidbyOtherPaymentMthd = "POC", 
                    LEDescription = "Updated Description in Source Screen", 
                    PayeeName = "Bank of American Payee Name with Max Characters", 
                    BuyerDoubleAsteriskChecked = true 
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(pdddetails2);
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, "CD - E Transfer Tax Misc. description1", 3, TableAction.DoubleClick);
                var pdddetails3 = new PaymentDetailsParameters()
                {
                    BuyerAtClosing = 34545.23,
                    BuyerBeforeClosing = 90678.89,
                    BuyerPaidbyOther = 4356.09,
                    BuyerPaidbyOtherPaymentMethod = "Mortgage Broker",
                    SellerPaidAtClosing = 233232312.76,
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(pdddetails3);
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, "CD - E Transfer Tax – Mortgage2", 3, TableAction.DoubleClick);
                var pdddetails4 = new PaymentDetailsParameters()
                {
                    BuyerAtClosing = 228.38,
                    BuyerDoubleAsteriskChecked = true, 
                    SellerPaidAtClosing = 7845.23, 
                    SellerPaidBeforeClosing = 76342.34, 
                    SellerPaidbyOthers = 4342.45, 
                    SellerPaidbyOtherPaymentMthd = "Lender", 
                    SellerLenderCheckbox = false, 
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(pdddetails4);
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { 
                { "E 02+ Transfer Taxes", "$3,423", "$303,429.33", "$463,434.45", "$0.00" }, 
                { "J 00 Lender Credits (See Lender Credit Analysis)", "$0", "-$5,145.54", "$0.00", "$0.00" }, 
                { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } },
                lenderCredits: new string[,] { 
                { "Non-Specific Lender Credits", "$0.00" }, 
                { "Specific Lender Credits", "" }, 
                { "E 02+ Transfer Taxes", "-$5,145.54" },
                { "Lender Credits Total (J) Excluding Good Faith Violation", "-$5,145.54" } });
                #endregion

                #region Navigate to Fee Entry Screen. Enter Loan Estimate Unrounded amount. (E.g. 3423.45)
                Reports.TestStep = @"Navigate to Fee Entry Screen. Enter Loan Estimate Unrounded amount. (E.g. 3423.45)";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.TranTaxLoanEstUnrounded.FASetText("3423.45");
                Keyboard.SendKeys(FAKeys.TabAway);
                #endregion

                #region Navigate to Fee Entry Screen. Click on Pay Recording/Tax button and add new Payee. (E.g. 615)
                Reports.TestStep = @"Navigate to Fee Entry Screen. Click on Pay Recording/Tax button and add new Payee. (E.g. 615)";
                FAST_AddFileFeesRec_Payee("BOA", new string[] { "CD - E Transfer Tax – Mortgage1", "CD - E Transfer Tax Misc. description1" });
                #endregion

                #region Open PDD for the below mentioned fees and modify the values in PDD
                Reports.TestStep = @"Open PDD for the below mentioned fees and modify the values in PDD.";
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2,"CD - E Transfer Tax Deed3",3,TableAction.DoubleClick);
                var PDDedit1 = new PaymentDetailsParameters()
                { 
                    BuyerAtClosing = 34534.34, 
                    BuyerBeforeClosing = 6754.7, 
                    BuyerPaidbyOther = 3423.67, 
                    BuyerPaidbyOtherPaymentMethod = "POC", 
                    BuyerDoubleAsteriskChecked = false,
                    SellerPaidAtClosing = 5675.50,
                    SellerPaidBeforeClosing = 3232.34,
                    SellerPaidbyOthers = 9865.23,
                    SellerPaidbyOtherPaymentMthd = "POC",
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDDedit1);
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, "CD - E Transfer Tax – Mortgage2", 3, TableAction.DoubleClick);
                var PDDedit2 = new PaymentDetailsParameters()
                { 
                    BuyerDoubleAsteriskChecked = false, 
                    SellerPaidbyOtherPaymentMthd = "Lender", 
                    SellerLenderCheckbox = true 
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDDedit2);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, "CD - Transfer Tax – Miscellaneous", 3, TableAction.DoubleClick);
                var PDDedit3 = new PaymentDetailsParameters() 
                { 
                    SellerPaidAtClosing = 10.50, 
                    SellerPaidBeforeClosing = 30.34, 
                    SellerPaidbyOthers = 40.23, 
                    SellerPaidbyOtherPaymentMthd = "Mortgage Broker", 
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDDedit3);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                #endregion

                #region Update Lender Credits in New Loan Screen | Loan Charges & Mortgage Tab
                Reports.TestStep = @"Update Lender Credits in New Loan Screen | Loan Charges & Mortgage Tab.";
                FAST_UpdateLenderCredits(new string[,] { { "2", "", "", "", "5600.67", "", "", "7856.56" } }, new string[,] { { "2", "", "", "", "234.34", "", "", "343.34" } });
                #endregion              

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { 
                { "E 02+ Transfer Taxes", "$3,423", "$333,579.39", "$3,423.45", "$330,155.94" }, 
                { "J 00 Lender Credits (See Lender Credit Analysis)", "-$8,200", "-$10,980.55", "-$8,199.90", "$0.00" }, 
                { "Increase in Closing Costs above legal limits - 0% Category", "$330,155.94", "", "", "" } },
                    lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "-$5,835.01" }, 
                    { "Specific Lender Credits", "" }, 
                    { "E 02+ Transfer Taxes", "-$5,145.54" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "-$10,980.55" } },
                    increaseTotal: 330155.94);
                #endregion

           }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("US530784 Fee Entry - Verify Section B Charges with/without Sales Tax in Good Faith Variance screen")]
        public void FMUC0131_REG0006()
        {
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region Create a file
                Reports.TestStep = "Create a new file";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.SalesPriceAmount = (decimal)300000;
                fileRequest.File.NewLoan.NewLoanAmount = (decimal)200000;
                fileRequest.File.NewLoan.LiabilityAmount = (decimal)200000;
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Rockwall";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "TX";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Rockwall";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                #region Navigate to Fee Entry Screen and add Fees with and Without Salestax
                Reports.TestStep = "Navigate to Fee Entry Screen and add Fees with and Without Salestax";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "CLTA 116.4 Contiguity of Parcels", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "CLTA 116.4 Contiguity of Parcels", 4, TableAction.SetText, "123");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "CLTA 116.4 Contiguity of Parcels", "Seller Charge", TableAction.SetText, "123");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "CA Withhold Assistance Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "CA Withhold Assistance Fee", 4, TableAction.SetText,"55.67");
                Keyboard.SendKeys(FAKeys.TabAway);
                #endregion

                #region Navigate to CD - GFV Screen and verify the values displayed.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { 
                { "B 01 Title - CA Withhold Assistance Fee", "$0", "$55.67", "$0.00", "$55.67" }, 
                { "B 01 Title - CA Withhold Assistance Fee - Sales Tax", "$0", "$5.34", "$0.00", "$5.34" }, 
                { "B 02 Title - CLTA 116.4 Contiguity of Parcels", "$0", "$123.00", "$0.00", "$123.00" }, 
                { "Increase in Closing Costs above legal limits - 0% Category", "$184.01", "", "", "" } },
                    lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 184.01);
                #endregion

                #region Navigate to Closing Disclosure tab and Loan Estimate amount
                FastDriver.ClosingDisclosure.ClickCDTab();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, "Title - CA Withhold Assistance Fee", false, 30.45,1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, "Title - CLTA 116.4 Contiguity of Parcels", false, 200.87, 2);
                #endregion

                #region Navigate to CD - GFV Screen and verify the values displayed.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { 
                { "B 01 Title - CA Withhold Assistance Fee", "$30", "$55.67", "$30.45", "$25.22" }, 
                { "B 01 Title - CA Withhold Assistance Fee - Sales Tax", "$0", "$5.34", "$0.00", "$5.34" }, 
                { "B 02 Title - CLTA 116.4 Contiguity of Parcels", "$201", "$123.00", "$200.87", "$0.00" }, 
                { "Increase in Closing Costs above legal limits - 0% Category", "$30.56", "", "", "" } },
                    lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 30.56);
                #endregion

                #region Change "Display Sales Tax on CD" option in Fee Entry screen.
                Reports.TestStep = "Change \"Display Sales Tax on CD\" option in Fee Entry screen.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItem("Separate line");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "CLTA 116.4 Contiguity of Parcels", 4, TableAction.SetText, "23.34");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "CLTA 116.4 Contiguity of Parcels", "Loan Estimate Unrounded", TableAction.SetText, "13.04");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "CA Withhold Assistance Fee", 4, TableAction.SetText, "155.67");
                Keyboard.SendKeys(FAKeys.TabAway);
                #endregion

                #region Navigate to CD - GFV Screen and verify the values displayed.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { 
                { "B 01 Title - CA Withhold Assistance Fee", "$30", "$155.67", "$30.45", "$125.22" }, 
                { "B 02 Title - CA Withhold Assistance Fee - Sales Tax", "$0", "$14.94", "$0.00", "$14.94" }, 
                { "B 03 Title - CLTA 116.4 Contiguity of Parcels", "$13", "$23.34", "$13.04", "$10.30" }, 
                { "Increase in Closing Costs above legal limits - 0% Category", "$150.46", "", "", "" } },
                    lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 150.46);
                #endregion

                #region Change "Display Sales Tax on CD" option in Fee Entry screen.
                Reports.TestStep = "Change \"Display Sales Tax on CD\" option in Fee Entry screen.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItem("Section H");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "CA Withhold Assistance Fee", 3,TableAction.DoubleClick);
                var pdddetails = new PaymentDetailsParameters()
                {
                    BuyerAtClosing = 10.45,
                    BuyerBeforeClosing = 13.55,
                    BuyerPaidbyOther = 34.34,
                    BuyerPaidbyOtherPaymentMethod = "Lender",
                    LoanEstimateUnrounded = 30.55
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(pdddetails);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                FastDriver.FileFees.SwitchToContentFrame();
                #endregion

                #region Navigate to CD - GFV Screen and verify the values displayed.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { 
                { "B 01 Title - CA Withhold Assistance Fee", "$31", "$24.00", "$30.55", "$0.00" }, 
                { "B 02 Title - CLTA 116.4 Contiguity of Parcels", "$13", "$23.34", "$13.04", "$10.30"}, 
                { "J 00 Lender Credits (See Lender Credit Analysis)", "$0", "-$34.34", "$0.00", "$0.00" }, 
                { "Increase in Closing Costs above legal limits - 0% Category", "$10.30", "", "", "" } },
                    lenderCredits: new string[,] { 
                    { "Non-Specific Lender Credits", "$0.00" }, 
                    { "Specific Lender Credits", "" }, 
                    { "B 01 Title - CA Withhold Assistance Fee", "-$34.34" }, 
                    { "Lender Credits Total (J) Excluding Good Faith Violation", "-$34.34" } },
                    increaseTotal: 10.30);
                #endregion

                #region Change "Display Sales Tax on CD" option in Fee Entry screen and change Lender Affiliated.
                Reports.TestStep = "Change \"Display Sales Tax on CD\" option in Fee Entry screen and change Lender Affiliated";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItem("Include with Fee");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "CA Withhold Assistance Fee", 3, TableAction.DoubleClick);
                var pdddetails1 = new PaymentDetailsParameters()
                {
                    LenderAffiliate = false,
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(pdddetails1,false);
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "CLTA 116.4 Contiguity of Parcels", 3, TableAction.DoubleClick);
                var pdddetails2 = new PaymentDetailsParameters()
                {
                    LenderAffiliate = false,
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(pdddetails2,false);
                FastDriver.FileFees.SwitchToContentFrame();
                #endregion

                ////#region Navigate to CD - GFV Screen and verify the values displayed.
                ////Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0%, 10% and Lender Credit Analysis.";
                ////FAST_VerifyGFaithVariance(cat0Table: new string[,] { 
                ////{ "J 00 Lender Credits (See Lender Credit Analysis)", "$0", "-$34.34", "$0.00", "$0.00" }, 
                ////{ "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } },
                ////cat10Table: new string[,]{
                ////    { "B 01 Title - CA Withhold Assistance Fee", "$31", "$24.00", "$30.55", "$0.00" }, 
                ////{ "B 02 Title - CLTA 116.4 Contiguity of Parcels", "$13", "$23.34", "$13.04", "$10.30"}, 
                ////},
                ////    lenderCredits: new string[,] { 
                ////    { "Non-Specific Lender Credits", "$0.00" }, 
                ////    { "Specific Lender Credits", "" }, 
                ////    { "B 01 Title - CA Withhold Assistance Fee", "-$34.34" }, 
                ////    { "Lender Credits Total (J) Excluding Good Faith Violation", "-$34.34" } },
                ////    increaseTotal: 10.30
                ////    );
                ////#endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        /// <summary>Need to add Fee related scenario on completeing Full Loan Policy and Owner Policy userstories.
        /// Need to add Fee related scenario on completeing Full Loan Policy and Owner Policy userstories.
        /// </summary>
        /// 


        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }
}