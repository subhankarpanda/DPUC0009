﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Windows.Forms;

namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0029 : MasterTestClass
    {
        #region BAT

        #region Test FMUC0029_BAT0002

        [TestMethod]
        public void FMUC0029_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF1_00: 1. Login and create an order with Seller's broker and Seller's Attorney  as additional role";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create file in UI

                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                Reports.TestStep = "Create an order in UI with Seller's broker and Seller's Attorney as additional role.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Seller's Attorney");
                Playback.Wait(3000);
                FastDriver.QuickFileEntry.DirectedBYAddtionalRole.FASelectItem("Seller's Broker");
                Playback.Wait(3000);
                FastDriver.QuickFileEntry.CreateStandardFile();

                #endregion Create file in UI

                #region Verify in FileHomePage

                Reports.TestStep = "Change the Business Source on File Home Page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual("Seller's Attorney", FastDriver.FileHomepage.BusinessPartyAddtionalRole.FAGetSelectedItem());
                Support.AreEqual("Seller's Broker", FastDriver.FileHomepage.DirectedByAddtionalRole.FAGetSelectedItem());

                #endregion Verify in FileHomePage
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_BAT0002

        #region Test FMUC0029_BAT0003

        [TestMethod]
        public void FMUC0029_BAT0003()
        {
            try
            {
                Reports.TestDescription = "MF1_01: 1. Navigate to Deposits outside escrow  and validate the pre datas in Deposit outside escrow after creating order with Seller's broker and Seller's Attorney  as additional role";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Create an order in WCF with Seller's broker and Seller's Attorney as additional role.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersAttorney,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersBroker,
                            CommissionAmount = 0,
                            CommissionPercent = 0
                        },
                    }
                };
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #endregion Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Navigate to Deposit outside escrow and prevalidate the data in Deposit outside escrow.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                Support.AreEqual(@"Seller's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem());
                Support.AreEqual(@"Lease 3 for HUD Testing Name 1 Lease 3 for HUD Testing Name 2", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetText());
                Support.AreEqual(@"Seller's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetSelectedItem());
                Support.AreEqual(@"Mortgage Lender 1 Name 1 Mortgage Lender 1 Name 2", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetText());
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_BAT0003

        #region Test FMUC0029_BAT0004

        [TestMethod]
        public void FMUC0029_BAT0004()
        {
            try
            {
                Reports.TestDescription = "MF1_02: 1. Enter amount for Seller's broker and validate the amount in deposit outside screen";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Create an order in WCF with Seller's broker and Seller's Attorney as additional role.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersAttorney,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersBroker,
                            CommissionAmount = 0,
                            CommissionPercent = 0
                        },
                    }
                };
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #endregion Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Navigate to Deposit outside escrow and set values for seller's broker.";

                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("500.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Seller's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FASetText(@"Seller's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText(@"500.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText(@"0.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the amount entered for seller's broker.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                Support.AreEqual(@"500.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue(), "TotalDeposit");
                Support.AreEqual(@"Seller's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem(), "EarnerstMoneyHeldBy_0.FAGetSelectedItem");
                Support.AreEqual(@"Seller's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetText(), "EarnerstMoneyName_0");
                Support.AreEqual(@"500.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_BAT0004

        #region Test FMUC0029_BAT0005

        [TestMethod]
        public void FMUC0029_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF1: 1. Enter Amount for Seller's attorney and validate the values entered";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Create an order in WCF with Seller's broker and Seller's Attorney as additional role.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersAttorney,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersBroker,
                            CommissionAmount = 0,
                            CommissionPercent = 0
                        },
                    }
                };
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #endregion Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Enter Amount for Seller's Attorney.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"500.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem(@"Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FASetText("Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText(@"0.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText(@"500.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the amount entered for seller's attorney.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                Support.AreEqual(@"500.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue());
                Support.AreEqual(@"Seller's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem());
                Support.AreEqual(@"Seller's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetText());
                Support.AreEqual(@"500.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_BAT0005

        #region Test FMUC0029_BAT0006

        [TestMethod]
        public void FMUC0029_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF3: Set excess Deposit Amount (on an Existing Deposit)";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Create an order in WCF with Seller's broker and Seller's Attorney as additional role.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersAttorney,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersBroker,
                            CommissionAmount = 0,
                            CommissionPercent = 0
                        },
                    }
                };
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #endregion Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Enter Excess deposit amount for (existing deposit).";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"800.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText(@"0.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText(@"0.00");
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText("800.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate for Excess deposit amount for existing deposit.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                Support.AreEqual(@"800.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue());
                Support.AreEqual(@"800.00", FastDriver.DepositOutsideEscrow.ExcessDeposit.FAGetValue());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_BAT0006

        #region Test FMUC0029_BAT0007

        [TestMethod]
        public void FMUC0029_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF5: Record Amount to be Disbursed as Proceeds(on Existing deposits)";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Create an order in WCF with Seller's broker and Seller's Attorney as additional role.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersAttorney,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersBroker,
                            CommissionAmount = 0,
                            CommissionPercent = 0
                        },
                    }
                };
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #endregion Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Record Amount to be Disbursed as Proceeds (on a Existing Deposit).";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"2,000.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("0.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText("0.00");
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText("0.00");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("2000.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate for Record Amount to be Disbursed as Proceeds (on a Existing Deposit).";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                Support.AreEqual(@"2,000.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue(), "TotalDeposit");
                Support.AreEqual(@"2,000.00", FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FAGetValue(), "DisbursedasProceeds");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_BAT0007

        #region Test FMUC0029_BAT0009

        [TestMethod, Obsolete]
        public void FMUC0029_BAT0009()
        {
            try
            {
                Reports.TestDescription = "AF5_02: Navigate to Deposit outside escrow and validate the values";
                Reports.StatusUpdate("This test method is clubbed with method BAT08", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_BAT0009

        #region Test FMUC0029_BAT0010

        [TestMethod]
        public void FMUC0029_BAT0010()
        {
            try
            {
                Reports.TestDescription = "AF2: 1. Enter Details for Buyer's broker and validate the values entered (On new deposits)";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Create an order in WCF with Seller's broker and Seller's Attorney as additional role.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersBroker,
                            CommissionAmount = 0,
                            CommissionPercent = 0
                        },
                    }
                };
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #endregion Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Enter Excess Deposit Amount (on a New Deposit).";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"900.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem(@"Buyer's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FASetText(@"Buyer's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText(@"400.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText(@"0.00");
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText(@"500.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate Excess Deposit Amount (on a New Deposit).";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                Support.AreEqual(@"900.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue());
                Support.AreEqual(@"Buyer's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem());
                Support.AreEqual(@"Buyer's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetText());
                Support.AreEqual(@"400.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue(), "EarnerstMoneyAmount");
                Support.AreEqual(@"500.00", FastDriver.DepositOutsideEscrow.ExcessDeposit.FAGetValue(), "ExcessDeposit");
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_BAT0010

        #region Test FMUC0029_BAT0011

        [TestMethod]
        public void FMUC0029_BAT0011()
        {
            try
            {
                Reports.TestDescription = "AF4_00: Record Amount to be Disbursed as Proceeds(on New deposits), AF4_02: Validate the values.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Create an order in WCF with Seller's broker and Seller's Attorney as additional role.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersBroker,
                            CommissionAmount = 0,
                            CommissionPercent = 0
                        },
                    }
                };
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #endregion Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Record Amount to be Disbursed as Proceeds (on a New Deposit).";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"600.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem(@"Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FASetText(@"Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText(@"400.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText(@"0.00");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText(@"200.00");
                FastDriver.BottomFrame.Save();

                Reports.TestDescription = "AF4_02: Navigate to Deposit outside escrow and validate the values";
                Reports.TestStep = "Record Amount to be Disbursed as Proceeds (on a New Deposit).";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                Support.AreEqual(@"600.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue(), "TotalDeposit");
                Support.AreEqual(@"Seller's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem(), "EarnerstMoneyHeldBy");
                Support.AreEqual(@"Seller's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetText(), "EarnerstMoneyName");
                Support.AreEqual(@"400.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue(), "EarnerstMoneyName");
                Support.AreEqual(@"200.00", FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FAGetValue(), "DisbursedasProceeds");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_BAT0011

        #region Test FMUC0029_BAT0013

        [TestMethod, Obsolete]
        public void FMUC0029_BAT0013()
        {
            try
            {
                Reports.TestDescription = "AF4_02: Navigate to Deposit outside escrow and validate the values";
                Reports.StatusUpdate("This test method is clubbed with method BAT11", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_BAT0013

        #region Test FMUC0029_Prad_8_3_BAT0014

        [TestMethod]
        public void FMUC0029_Prad_8_3_BAT0014()
        {
            try
            {
                Reports.TestDescription = "AF4_00: 1. Record Amount to be Disbursed as Proceeds (on a New Deposit).";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Create an order in WCF with Seller's broker and Seller's Attorney as additional role.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersBroker,
                            CommissionAmount = 0,
                            CommissionPercent = 0
                        },
                    }
                };
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #endregion Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Create the Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.GABcode.FASetText("HUDBUYATT1");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneyDetail.Type.FASelectItem(@"Attorney- Primary");
                FastDriver.AttorneyDetail.BuyerCharge.FASetText("50.00");
                FastDriver.AttorneyDetail.SellerCharge.FASetText("50.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create the Seller Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.GABcode.FASetText(@"HUDSELATT1");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneyDetail.Type.FASelectItem(@"Attorney- Primary");
                FastDriver.AttorneyDetail.BuyerCharge.FASetText("50.00");
                FastDriver.AttorneyDetail.SellerCharge.FASetText("50.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter total deposit amount.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();

                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"200.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem(@"Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem(@"Buyer's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText(@"50.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText(@"50.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Total deposit must equal total money distribution.";
                Support.AreEqual(@"Total deposit must equal total money distribution", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify Earnest Money Distribution and Enter Excess deposit amount.";
                FastDriver.DepositOutsideEscrow.WaitForScreenToLoad();
                Support.AreEqual(@"200.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue(), "TotalDeposit");
                Support.AreEqual(@"100.00", FastDriver.DepositOutsideEscrow.EarnestMoneyDistribution.FAGetText(), "EarnestMoneyDistribution");
                Support.AreEqual(@"Seller's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem(), "EarnerstMoneyHeldBy_0");
                Support.AreEqual(@"Buyer's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetSelectedItem(), "EarnerstMoneyHeldBy_1");
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText(@"50");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Total deposit must equal total money distribution.";
                Support.AreEqual(@"Total deposit must equal total money distribution", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify Earnest Money Distribution and Enter Disbursed as Proceeds amount.";
                FastDriver.DepositOutsideEscrow.WaitForScreenToLoad();
                Support.AreEqual(@"200.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue(), "TotalDeposit");
                Support.AreEqual(@"150.00", FastDriver.DepositOutsideEscrow.EarnestMoneyDistribution.FAGetText(), "EarnestMoneyDistribution");
                Support.AreEqual(@"Seller's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem(), "EarnerstMoneyHeldBy_0");
                Support.AreEqual(@"Buyer's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetSelectedItem(), "EarnerstMoneyHeldBy_1");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText(@"50.00");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Verify Earnest Money Distribution and Earnest Money Amount are equal.";
                FastDriver.DepositOutsideEscrow.WaitForScreenToLoad();
                Support.AreEqual(@"200.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue(), "TotalDeposit");
                Support.AreEqual(@"200.00", FastDriver.DepositOutsideEscrow.EarnestMoneyDistribution.FAGetText(), "EarnestMoneyDistribution");
                Support.AreEqual(@"Seller's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem(), "EarnerstMoneyHeldBy_0");
                Support.AreEqual(@"Buyer's Attorney", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetSelectedItem(), "EarnerstMoneyHeldBy_1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify Earnest Money Held by  Seller Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                Support.AreEqual("$ 100.00", FastDriver.AttorneyDetail.TotalCharges.FAGetText(), "TotalCharges");
                Support.AreEqual("$ 50.00", FastDriver.AttorneyDetail.EarnestMoney.FAGetText(), "EarnestMoney");
                Support.AreEqual("$ 50.00", FastDriver.AttorneyDetail.NetcheckAmount.FAGetText(), "NetcheckAmount");

                Reports.TestStep = "Verify Earnest Money Held by  Buyer Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").WaitForScreenToLoad();
                Support.AreEqual("$ 100.00", FastDriver.AttorneyDetail.TotalCharges.FAGetText(), "TotalCharges");
                Support.AreEqual("$ 50.00", FastDriver.AttorneyDetail.EarnestMoney.FAGetText(), "EarnestMoney");
                Support.AreEqual("$ 50.00", FastDriver.AttorneyDetail.NetcheckAmount.FAGetText(), "NetcheckAmount");

                Reports.TestStep = "Verify that : Earnest Money Held by Buyer Attorney will reduce the holding party's disbursement.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("50.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Buyer's Attorney 1 for HUD Test Name 1 B", "Amount", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify that : Earnest Money Held by Seller Attorney will reduce the holding party's disbursement.";
                Support.AreEqual("50.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Seller's Attorney 1 for HUD Test Name 1", "Amount", TableAction.GetText).Message.Trim());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_Prad_8_3_BAT0014

        #region Test FMUC0029_Prad_8_3_BAT0015

        [TestMethod]
        public void FMUC0029_Prad_8_3_BAT0015()
        {
            try
            {
                Reports.TestDescription = "AF5_00: Record Amount to be Disbursed as Proceeds (on an Existing Deposit)";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Create an order in WCF with Seller's broker and Seller's Attorney as additional role.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersBroker,
                            CommissionAmount = 0,
                            CommissionPercent = 0
                        },
                    }
                };
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #endregion Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Create the Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.GABcode.FASetText("HUDBUYATT1");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneyDetail.Type.FASelectItem(@"Attorney- Primary");
                FastDriver.AttorneyDetail.BuyerCharge.FASetText("50.00");
                FastDriver.AttorneyDetail.SellerCharge.FASetText("50.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create the Seller Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.GABcode.FASetText(@"HUDSELATT1");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneyDetail.Type.FASelectItem(@"Attorney- Primary");
                FastDriver.AttorneyDetail.BuyerCharge.FASetText("50.00");
                FastDriver.AttorneyDetail.SellerCharge.FASetText("50.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter total deposit amount.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"200.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem(@"Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem(@"Buyer's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText(@"50.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText(@"50.00");
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText(@"50");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText(@"50.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Reduce the Holding money earnest amount for Buyer Attoney and seller attorney.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText(@"40.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText(@"40.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Total deposit must equal total money distribution.";
                Support.AreEqual(@"Total deposit must equal total money distribution", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Adjust the  Total Deposit.";
                FastDriver.DepositOutsideEscrow.WaitForScreenToLoad();
                Support.AreEqual(@"200.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue());
                Support.AreEqual(@"180.00", FastDriver.DepositOutsideEscrow.EarnestMoneyDistribution.FAGetText());
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"180.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify Earnest Money Held by  Seller Attorney after reducing amount.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                Support.AreEqual("$ 100.00", FastDriver.AttorneyDetail.TotalCharges.FAGetText());
                Support.AreEqual("$ 40.00", FastDriver.AttorneyDetail.EarnestMoney.FAGetText());
                Support.AreEqual("$ 60.00", FastDriver.AttorneyDetail.NetcheckAmount.FAGetText());

                Reports.TestStep = "Verify Earnest Money Held by  Buyer Attorney after reducing amount.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").WaitForScreenToLoad();
                Support.AreEqual("$ 100.00", FastDriver.AttorneyDetail.TotalCharges.FAGetText());
                Support.AreEqual("$ 40.00", FastDriver.AttorneyDetail.EarnestMoney.FAGetText());
                Support.AreEqual("$ 60.00", FastDriver.AttorneyDetail.NetcheckAmount.FAGetText());

                Reports.TestStep = "Verify that : Earnest Money Held by Buyer Attorney will reduce the holding party's disbursement.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("60.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Buyer's Attorney 1 for HUD Test Name 1 B", "Amount", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify that : Earnest Money Held by Seller Attorney will reduce the holding party's disbursement.";
                Support.AreEqual("60.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Seller's Attorney 1 for HUD Test Name 1", "Amount", TableAction.GetText).Message.Trim());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_Prad_8_3_BAT0015

        #region Test FMUC0029_Prad_8_3_BAT0016

        [TestMethod]
        public void FMUC0029_Prad_8_3_BAT0016()
        {
            try
            {
                Reports.TestDescription = "AFXXXX :1. Enter a Deposit when Earnest Money Held Exceeds Commission and Verfiy.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Create an order in WCF with Seller's broker and Seller's Attorney as additional role.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersBroker,
                            CommissionAmount = 0,
                            CommissionPercent = 0
                        },
                    }
                };
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #endregion Create an order in WCF with Seller's broker and Seller's Attorney as additional role

                Reports.TestStep = "Create instance for Buyers (Selling) Broker and verify the Credit Seller Earnest Money in excess of Commission amount is ZERO when earnet money is not present in file.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(1, "1", 1, TableAction.Click);
                
                if (FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.IsEnabled())
                {
                    FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                }

                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create instance for Sellers (Listing) Broker and verify the Credit Seller Earnest Money in excess of Commission amount is ZERO when earnet money is not present in file.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();

                if (FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.IsEnabled())
                {
                    FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                }

                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue(), "CreditSellerEarnestMoneyinexcesstextBox");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Earnest Money amount and Earnest money distribution equally for Buyer Broker and seller Broker.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"60.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem(@"Seller's Broker");
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testi", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetText());
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText(@"30.00");
                
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem(@"Buyer's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FASetText(@"Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText(@"30.00");
                SendKeys.SendWait("{TAB}");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify when earnest money is greater than commision amout Credit Seller Earnest Money in excess of Commission check Box will be checked and the difference amount will be displayed in text Box for Buyer selling broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 4, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText());
                Support.AreEqual(@"true", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.GetAttribute("checked"));
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());
                Support.AreEqual(@"-30.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText());

                Reports.TestStep = "Enter commission amount less than earnest and verify diffference between earnest amount and commision amount.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("10.00");
                Keyboard.SendKeys("{TAB}");

                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText());
                Support.AreEqual(@"true", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.FAGetAttribute("checked"));
                Support.AreEqual(@"20.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());
                Support.AreEqual(@"-20.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText());

                Reports.TestStep = "Enter commission equal to earnest and verify diffference between earnest amount and commision amount.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("30.00");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText());

                Reports.TestStep = "Verify when earnest money is greater than commision amout Credit Seller Earnest Money in excess of Commission check Box will be checked and the difference amount will be displayed in text Box for seller listing Broker.";

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText());

                Reports.TestStep = "Verify when earnest money is greater than commision amout Credit Seller Earnest Money in excess of Commission check Box will be checked and the difference amount will be displayed in text Box for Buyer selling broker.";
                FastDriver.LeftNavigation.Navigate<HomePage>("Home");

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 4, TableAction.Click);
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();

                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText());

                Reports.TestStep = "Enter commission amount less than earnest and verify diffference between earnest amount and commision amount.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("10.00");
                Keyboard.SendKeys("{TAB}");

                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText());
                Support.AreEqual(@"true", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.FAGetAttribute("checked"));
                Support.AreEqual(@"20.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());
                Support.AreEqual(@"-20.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText());

                Reports.TestStep = "Enter disburse as proceed amout.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"70.00");
                Support.AreEqual(@"Seller's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testi", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetText());
                Support.AreEqual(@"30.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue());
                Support.AreEqual(@"Buyer's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetSelectedItem());
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testi", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetText());
                Support.AreEqual(@"30.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FAGetValue());
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText(@"10.00");
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_Prad_8_3_BAT0016

        #endregion BAT

        #region REG

        #region Test FMUC0029_REG0001

        [TestMethod]
        public void FMUC0029_REG0001()
        {
            try
            {
                Reports.TestDescription = "BR_FM1446_FM1447_EW_1_FM1475_FM1075_FM1076_FM1476_FM5223_FM1477_FM1478_FM1479:  Negative amounts not allowed and validate that deposit is never negative . Validate that Total deposit must equal total money distribution.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create an order in WCF with basic information and Sales price.

                Reports.TestStep = "Create an order with basic information and Sales price.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = 1000;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #endregion Create an order in WCF with basic information and Sales price.

                Reports.TestStep = "Enter negative amount in Deposit.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText(@"-100.00");
                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Validate that negative amount is not allowed to enter.";
                Support.AreEqual(@"?", FastDriver.DepositOutsideEscrow.ExcessDeposit.FAGetValue(), "DepositOutsideEscrow.ExcessDeposit.FAGetValue");

                Reports.TestStep = "Enter total deposit less than total money distribution.";
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"100");
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText(@"1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Total deposit must equal total money distribution.";
                Support.AreEqual(@"True", FastDriver.WebDriver.HandleDialogMessage().Contains("deposit must equal total money distribution").ToString(), "DialogMessage.Contains 'deposit must equal total money distribution'");

                Reports.TestStep = "Enter Total deposit and Excess Deposit amount.";
                FastDriver.DepositOutsideEscrow.WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"600.00");
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText(@"600.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate that amount is equal to difference of Sales price and total deposit amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("400.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Amount", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Enter Disbursed amount.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"600.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FASetText(@"Seller broker name");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText(@"100.00");
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText(@"300.00");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText(@"200.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Home.";
                FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.TreeView.FindElement(By.LinkText("Home")).Click();

                Reports.TestStep = "Click on Ok button. (If exists)";
                FastDriver.WebDriver.HandleDialogMessage();
                Reports.TestStep = "Change the disbursed amount.";

                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText(@"400.00");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText(@"100.00");
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_REG0001

        #region Test FMUC0029_REG0002

        [TestMethod]
        public void FMUC0029_REG0002()
        {
            try
            {
                Reports.TestDescription = "BR_ES7499_ES7500: Validate the Earnest Money Deposit in the Sub Escrow file ,Excess Deposit in the Sub Escrow file  and Disbursed as Proceeds in the Sub Escrow file";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create a Title Sub Escrow File with WCF.

                Reports.TestStep = "Create a Title Sub Escrow File.";
                var fileRequest = _CreateTitleSubEscrowFile();

                #endregion Create a Title Sub Escrow File with WCF.

                Reports.TestStep = "Validate the System does not add it to Other File Charges to OEC or Other File Credits to OEC.";

                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyTable.FAGetText().Contains("OEC Net").ToString(), "OutsideEscrowCompanyTable Contains 'OEC Net'");
                Support.AreEqual("True", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyTable.FAGetText().Contains("Check Amount").ToString(), "OutsideEscrowCompanyTable Contains 'Check Amount'");
                Support.AreEqual("0.00", FastDriver.OutsideEscrowCompanyDetail.NetCheckAmt.FAGetText().Trim(), "OutsideEscrowCompanyDetail.NetCheckAmt");

                Reports.TestStep = "Navigate to Deposit outside escrow and set values for seller's broker.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"500.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem(@"Seller's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FASetText(@"Seller's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText(@"500.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the System does not add it to Other File Charges to OEC or Other File Credits to OEC.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                string abc = FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyTable.FAGetText();
                Support.AreEqual("True", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyTable.FAGetText().Contains("Outside Escrow").ToString(), "OutsideEscrowCompanyTable Contains 'Outside Escrow'");
                Support.AreEqual("True", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyTable.FAGetText().Contains("Company Charges").ToString(), "OutsideEscrowCompanyTable Contains 'Company Charges'");
                Support.AreEqual("True", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyTable.FAGetText().Contains("0.00").ToString(), "OutsideEscrowCompanyTable Contains '0.00'");

                Reports.TestStep = "Create an REB instance with commission amount and seller charge.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();

                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText(@"HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("700.00");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText(@"200.00");
                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Validate that commission amount entered in REB appears in OEC screen.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyTable.FAGetText().Contains("OEC Net").ToString(), "OutsideEscrowCompanyTable Contains 'OEC Net'");
                Support.AreEqual("True", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyTable.FAGetText().Contains("Check Amount").ToString(), "OutsideEscrowCompanyTable Contains 'Check Amount'");
                Support.AreEqual("True", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyTable.FAGetText().Contains("-200.00").ToString(), "OutsideEscrowCompanyTable Contains '-200.00'");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_REG0002

        #region Test FMUC0029_REG0003

        [TestMethod]
        public void FMUC0029_REG0003()
        {
            try
            {
                Reports.TestDescription = "BR_ES7501: Disbursed as Proceeds in the Sub Escrow file";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create a Title Sub Escrow File with WCF.

                Reports.TestStep = "Create a Title Sub Escrow File.";
                var fileRequest = _CreateTitleSubEscrowFile();

                #endregion Create a Title Sub Escrow File with WCF.

                Reports.TestStep = "Record Amount to be Disbursed as Proceeds (on a New Deposit).";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"600.00");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem(@"Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FASetText(@"Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText(@"400.00");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText(@"200.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the amount is equal to disbursed amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("200.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Amount", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Validate the Net check amount in OEC screen";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                Support.AreEqual("200.00", FastDriver.OutsideEscrowCompanyDetail.NetCheckAmt.FAGetText().Trim(), "OutsideEscrowCompanyDetail.NetCheckAmt");

                Reports.TestStep = "Validate the net check amount for OEC in File balance summary screen";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("200.00", FastDriver.EscrowFileBalanceSummary.BuyerNetCheck.FAGetText().Trim(), "EscrowFileBalanceSummary.BuyerNetCheck");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_REG0003

        #region Test FMUC0029_REG0004

        [TestMethod]
        public void FMUC0029_REG0004()
        {
            try
            {
                Reports.TestDescription = "BR_FieldDefination: Validate the fields";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                #region Create an order in WCF with basic information and Sales price.

                Reports.TestStep = "Create an order with basic information and Sales price.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = 1000;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                #endregion Create an order in WCF with basic information and Sales price.

                Reports.TestStep = "Validate the earnest money held by field.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                Support.AreEqualTrim(@"326", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetValue().Trim());

                Reports.TestStep = "Validate the default value of amount in all currency fields.";
                Support.AreEqual(@"0.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.DepositOutsideEscrow.ExcessDeposit.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FAGetValue());
                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    Support.AreEqual(@"0.00", FastDriver.DepositOutsideEscrow.Curefor0Tolerance_Amount.FAGetValue());
                    Support.AreEqual(@"0.00", FastDriver.DepositOutsideEscrow.Curefor10Tolerance_Amount.FAGetValue());
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_REG0004

        #region Test FMUC0029_REG0006

        [TestMethod]
        public void FMUC0029_REG0006()
        {
            try
            {
                Reports.TestDescription = "EW3: Place HOLDER: Verify manually User enters an amount into the Disbursed as Proceeds field and saves the Deposit Outside Escrow screen but does not have the correct security level to enter the Deposit In Escrow";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_REG0006

        #region Test FMUC0029_REG0007

        [TestMethod]
        public void FMUC0029_REG0007()
        {
            try
            {
                Reports.TestDescription = "ES7501 : Disbursed as Proceeds in the Sub Escrow file.";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                #endregion data setup

                #region Login

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion Login

                Reports.TestStep = "Create Title & SubEscrow basic Order with Buyer name.";
                var fileRequest = _CreateTitleSubEscrowFile();

                Reports.TestStep = "Earnest Money Amount and disbursed as proceed.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"180.00");
                Support.AreEqual(@"180.00", FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue());
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText(@"180.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Create Instance and verify the Other File Credits to OEC Amount.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText("HUDFLINSR1");
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                Support.AreEqual(@"0.00", FastDriver.OutsideEscrowCompanyDetail.OtherFileCharges.FAGetText());
                Support.AreEqual(@"180.00", FastDriver.OutsideEscrowCompanyDetail.OtherFileCredits.FAGetText());

                Reports.TestStep = "Verify that : The system will create a created/pending disbursement to the OEC.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "180.00", "Payee", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify Net Check,Actual File Balance,Project File Balance for Escrow file with Disbursed as Proceeds amount..";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual(@"SHORT", FastDriver.EscrowFileBalanceSummary.Inbalance.FAGetText(), "Inbalance");
                Support.AreEqual(@"180.00", FastDriver.EscrowFileBalanceSummary.BuyerNetCheck.FAGetText(), "BuyerNetCheck");
                Support.AreEqual(@"180.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText(), "FileBalance");
                Support.AreEqual(@"180.00-", FastDriver.EscrowFileBalanceSummary.ProjectedFileBalanceAmount.FAGetText(), "ProjectedFileBalanceAmount");
                Support.AreEqual(@"180.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText(), "NetTotalDisbursements");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test FMUC0029_REG0007

        #endregion REG

        #region Private Methods

        private OrderDetailsResponse _CreateTitleSubEscrowFile()
        {
            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";

            customizableFileRequest.File.Properties = new Property[]
            {
                new Property()
                {
                    PropertyAddress = new PhysicalAddress[]
                    {
                        new PhysicalAddress()
                        {
                            State = "CA",
                            City = "ALBANY",
                            County = "ALAMEDA",
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        }
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                }
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        }
                };

            customizableFileRequest.File.Services = new Service[]
                    {
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "TO"
                        },
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "SEO"
                        }
                    };
            customizableFileRequest.File.SalesPriceAmount = 1000;

            customizableFileRequest.File.Buyers[0].Type = "Individual";
            customizableFileRequest.File.Buyers[0].FirstName = "Buyer1Firstname";
            customizableFileRequest.File.Buyers[0].LastName = "Buyer1Lastname";

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            return File;
        }

        #endregion Private Methods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}