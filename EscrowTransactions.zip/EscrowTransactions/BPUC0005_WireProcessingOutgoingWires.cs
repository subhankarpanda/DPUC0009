﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;

namespace EscrowTransactions
{
    [CodedUITest]
    [DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class BPUC0005 : MasterTestClass
    {

        #region BAT

         [TestMethod]
        [Description("CMF_001: Approve and Transmit Outgoing Wires in Wirelink Region")]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void BPUC0005_BAT0001_WIRELINK_REGION()
        {
            //This test case has been combined with BPUC0005_BAT0002,BPUC0005_BAT0003,BPUC0005_BAT0004 and BPUC0005_BAT0005
            try
            {
                Reports.TestDescription = "MF_001: Approve and Transmit Outgoing Wires & MF_002: Approve and Transmit Outgoing Wires & AF1_AF2_001: View Details for a Wire and Approve Wire where Negative Current File Balance Exceeds Offices Overdraft Limit & AF3_AF4_001: Outgoing Wire Summary: View, Search and Report Outgoing Wires and results exceed grid capacity & AF5_001: Outgoing Wire Status Writes to Event Log.";

                //#region MF_002: Approve and Transmit Outgoing Wires. |BPUC0005_BAT0001|
                Reports.TestStep = "MF_001: Approve and Transmit Outgoing Wires. |BPUC0005_BAT0001|";

                #region Login
                _IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                Reports.TestStep = "Navigate to Wire Link Testing - DO NOT USE office";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("9919");

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFileInWireLinkRegion();
                #endregion

                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.FileHomepage.Open();
                var FileNumber = FastDriver.FileHomepage.GetFileNumber();

                Reports.TestStep = "Create a new Utility Instance.";
                FastDriver.UtilityDetail.Open();

                FastDriver.UtilityDetail.FindGABcode("HUDFLINSR1");

                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText("Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText("50.00");

                Reports.TestStep = "Validate Data for a new Instance.";
                Support.AreEqual("Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue());
                Support.AreEqual("50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue());
                Support.AreEqual("50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue());

                FastDriver.BottomFrame.Done();

                #region Scan a Document
                Reports.TestStep = "Scan and update a Document.";

                FastDriver.DocumentRepository.Open();

                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Open button and load the image document.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)

                Reports.TestStep = "Save the TIF Doc.";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");

                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(); FastDriver.DocumentRepository.DocumentsTab.FAClick();

                Reports.TestStep = "Verify that Document is uploaded to the FAST.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "PO-Invoice AFFIX INV", 4, TableAction.Click);

                #endregion Scan a Document

                Reports.TestStep = "Click on amount and edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the wire.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);

                Reports.TestStep = "Click on Wire button.";
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();

                Reports.TestStep = "Disburse the wire.";
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();

                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.Quit();

                #endregion

                #region MF_002: Approve and Transmit Outgoing Wires. |BPUC0005_BAT0002|
                Reports.TestStep = "MF_002: Approve and Transmit Outgoing Wires. |BPUC0005_BAT0002|";

                #region Login
                _IISLOGIN();

                #endregion

                Reports.TestStep = "Navigate to Wire Link Testing - DO NOT USE office";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("9919");

                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Select a wire.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval");

                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                #endregion

                #region AF1_AF2_001: View Details for a Wire and Approve Wire where Negative Current File Balance Exceeds Offices Overdraft Limit |BPUC0005_BAT0003|
                Reports.TestStep = "AF1_AF2_001: View Details for a Wire and Approve Wire where Negative Current File Balance Exceeds Offices Overdraft Limit |BPUC0005_BAT0003|";

                Reports.TestStep = "Click on View details button.";
                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(3, FileNumber, 3, TableAction.Click);
                FastDriver.WireDisbursementApproval.ViewDetails.FAClick();

                Reports.TestStep = "Clickn on thumbnail image.";
                Playback.Wait(5000);
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                FastDriver.IssueWireDisbursement.DocumentSourceTable.PerformTableAction(2, "PO-Invoice AFFIX INV", 1, TableAction.DoubleClick);

                //Click on CLoseButton on the webDialog
                Reports.TestStep = "Click On Close Button on the WebDialog";
                Playback.Wait(5000);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.WebDriver.SwitchTo().DefaultContent();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "button.ui-dialog-titlebar-close").FAClick();
                    FastDriver.IssueWireDisbursement.WaitForScreenToLoad();

                    return FastDriver.IssueWireDisbursement.Approved.IsEnabled();
                }, 20);

                Reports.TestStep = "Approve.";
                Playback.Wait(5000);
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                FastDriver.IssueWireDisbursement.Approved.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Save followed by Done button.";
                Playback.Wait(5000);
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Re-fresh the Out-going Wire Approval Screen and Search for updated records";
                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                Reports.TestStep = "Select a wire.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(3, FileNumber, 1, TableAction.On);
                Playback.Wait(5000);

                if (FastDriver.WireDisbursementApproval.Transmit.IsEnabled())
                {
                    FastDriver.WireDisbursementApproval.Transmit.FAClick();
                    Playback.Wait(5000);
                    FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                    if (!FastDriver.WireDisbursementApproval.Transmit.IsEnabled())
                    {
                        Reports.StatusUpdate("Transmit button is disabled after transmitting the data", true);

                    }
                    else
                    {
                        Reports.StatusUpdate("Transmit button is not disabled after transmitting the data", false);

                    }

                }
                else
                {
                    Reports.StatusUpdate("Transmit button is NOT ENABLED for transmitting the data", false);
                }


                #endregion

                #region AF5_001: Outgoing Wire Status Writes to Event Log. |BPUC0005_BAT0005|
                Reports.TestStep = "AF5_001: Outgoing Wire Status Writes to Event Log. |BPUC0005_BAT0005|";
                Reports.StatusUpdate("AF5_001: Outgoing Wire Status Writes to Event Log. |BPUC0005_BAT0005|", true);

                Reports.TestStep = "Verifying the Wire event.";
                FastDriver.EventTrackingLog.Open();
                Playback.Wait(5000);

                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Playback.Wait(5000);

                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Wire]", "Event", TableAction.Click);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("CMF_001: Approve and Transmit Outgoing Wires.")]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void BPUC0005_BAT0001()
        {
            //This test case has been combined with BPUC0005_BAT0002,BPUC0005_BAT0003,BPUC0005_BAT0004 and BPUC0005_BAT0005
            //This test covers triage item: 923103 - INC3245465 - MASTER 10.08 Triage - Cannot approve FAST outgoing wires

            try
            {
                Reports.TestDescription = "MF_001: Approve and Transmit Outgoing Wires & MF_002: Approve and Transmit Outgoing Wires & AF1_AF2_001: View Details for a Wire and Approve Wire where Negative Current File Balance Exceeds Offices Overdraft Limit & AF3_AF4_001: Outgoing Wire Summary: View, Search and Report Outgoing Wires and results exceed grid capacity & AF5_001: Outgoing Wire Status Writes to Event Log.";

                #region MF_002: Approve and Transmit Outgoing Wires. |BPUC0005_BAT0001|
                Reports.TestStep = "MF_001: Approve and Transmit Outgoing Wires. |BPUC0005_BAT0001|";
                Reports.StatusUpdate("MF_001: Approve and Transmit Outgoing Wires |BPUC0005_BAT0001|", true);

                #region Login
                _IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.FileHomepage.Open();
                var FileNumber = FastDriver.FileHomepage.GetFileNumber();

                Reports.TestStep = "Create a new Utility Instance.";
                FastDriver.UtilityDetail.Open();

                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");

                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText("Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText("50.00");

                Reports.TestStep = "Validate Data for a new Instance.";
                Support.AreEqual("Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue());
                Support.AreEqual("50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue());
                Support.AreEqual("50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue());

                FastDriver.BottomFrame.Done();

                #region Scan a Document
                Reports.TestStep = "Scan and update a Document.";

                FastDriver.DocumentRepository.Open();

                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Open button and load the image document.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)

                Reports.TestStep = "Save the TIF Doc.";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");

                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(); FastDriver.DocumentRepository.DocumentsTab.FAClick();

                Reports.TestStep = "Verify that Document is uploaded to the FAST.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "PO-Invoice AFFIX INV", 4, TableAction.Click);

                #endregion Scan a Document

                Reports.TestStep = "Click on amount and edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the wire.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);

                Reports.TestStep = "Click on Wire button.";
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();

                Reports.TestStep = "Disburse the wire.";
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();

                FastDriver.PasswordConfirmationDlg.ConfirmPassword();

                #endregion

                #region MF_002: Approve and Transmit Outgoing Wires. |BPUC0005_BAT0002|
                Reports.TestStep = "MF_002: Approve and Transmit Outgoing Wires. |BPUC0005_BAT0002|";
                Reports.StatusUpdate("MF_002: Approve and Transmit Outgoing Wires. |BPUC0005_BAT0002|", true);

                Reports.TestStep = "Verify activity rights for " + AutoConfig.UserName + " and add accordingly.";

                #region Admin Login
                _ADMLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                Reports.TestStep = "Select office - QA automation region - Do NOT TOUCH";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "navigate to Employee security - Enter userid and search";
                FastDriver.EmployeeSecurity.Open();
                FastDriver.EmployeeSecurity.SearchAndSelectEmployee(AutoConfig.UserName);
                Playback.Wait(5000);
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();

                int ExpandButtonRow = FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction(2, AutoConfig.SelectedRegionBUID, 1, TableAction.Click).CurrentRow;
                FastDriver.BusinessUnitRoleAssignment.ExpandButton(ExpandButtonRow + 1).FAClick();

                FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction(2, AutoConfig.SelectedOfficeBUID, 2, TableAction.Click);
                FastDriver.BusinessUnitRoleAssignment.AddRemoveRolesButton.FAClick();
                FastDriver.RoleSelectionDialog.WaitForScreenToLoad();

                FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction("Role Name", "IT - all", "Select", TableAction.On);
                FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction("Role Name", "Office Administrator", "Select", TableAction.On);

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();

                if (FastDriver.TrackChangeHistoryDialog.IsPresent())
                {

                    FastDriver.TrackChangeHistoryDialog.WaitForScreenToLoad();
                    FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText("123");
                    FastDriver.TrackChangeHistoryDialog.UserNotes.FASetText("Adding roles");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
                }

                FastDriver.BottomFrame.Done();

                #region Login
                _IISLOGIN();

                #endregion

                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Select a wire.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval");

                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(DateTime.Today.AddDays(Convert.ToInt32("1")).ToString("MM/dd/yyyy").Replace("/", "-"));

                for (int DropDownCount = 0; DropDownCount < FastDriver.WireDisbursementApproval.BankAccounts.FAGetDropdownOptions().Count; DropDownCount++)
                {

                    FastDriver.WireDisbursementApproval.BankAccounts.FASelectItemByIndex(DropDownCount);
                    FastDriver.WireDisbursementApproval.FindNow.FAClick();
                    FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                    if (FastDriver.WireDisbursementApproval.WireDisbursementTable.FAGetText().Contains(FileNumber))
                    {
                        FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(3, FileNumber, 3, TableAction.Click);
                        FastDriver.WireDisbursementApproval.Method.FASelectItem("Preview");
                        FastDriver.WireDisbursementApproval.Deliver.FAClick();
                        FastDriver.WebDriver.WaitForDeliveryWindow("Preview");
                        FastDriver.WebDriver.ClosePreviewWindow();
                        break;
                    }


                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region AF1_AF2_001: View Details for a Wire and Approve Wire where Negative Current File Balance Exceeds Offices Overdraft Limit |BPUC0005_BAT0003|
                Reports.TestStep = "AF1_AF2_001: View Details for a Wire and Approve Wire where Negative Current File Balance Exceeds Offices Overdraft Limit |BPUC0005_BAT0003|";
                Reports.StatusUpdate("AF1_AF2_001: View Details for a Wire and Approve Wire where Negative Current File Balance Exceeds Offices Overdraft Limit |BPUC0005_BAT0003|", true);

                Reports.TestStep = "Click on View details button.";
                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.ViewDetails.FAClick();

                Reports.TestStep = "Clickn on thumbnail image.";
                Playback.Wait(5000);
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                FastDriver.IssueWireDisbursement.DocumentSourceTable.PerformTableAction(2, "PO-Invoice AFFIX INV", 1, TableAction.DoubleClick);

                //Click on CLoseButton on the webDialog
                Reports.TestStep = "Click On Close Button on the WebDialog";
                Playback.Wait(5000);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.WebDriver.SwitchTo().DefaultContent();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "button.ui-dialog-titlebar-close").FAClick();
                    FastDriver.IssueWireDisbursement.WaitForScreenToLoad();

                    return FastDriver.IssueWireDisbursement.Approved.IsEnabled();
                }, 20);

                Reports.TestStep = "Approve.";
                Playback.Wait(5000);
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                FastDriver.IssueWireDisbursement.Approved.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Save followed by Done button.";
                Playback.Wait(5000);
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Re-fresh the Out-going Wire Approval Screen and Search for updated records";
                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                Reports.TestStep = "Select a wire.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(DateTime.Today.AddDays(Convert.ToInt32("1")).ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("All Accounts");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(3, FileNumber, 1, TableAction.On);
                Playback.Wait(5000);

                if (FastDriver.WireDisbursementApproval.Transmit.IsEnabled())
                {
                    FastDriver.WireDisbursementApproval.Transmit.FAClick();
                    Playback.Wait(5000);
                    FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                    if (!FastDriver.WireDisbursementApproval.Transmit.IsEnabled())
                    {
                        Reports.StatusUpdate("Transmit button is disabled after transmitting the data", true);

                    }
                    else
                    {
                        Reports.StatusUpdate("Transmit button is not disabled after transmitting the data", false);

                    }

                }
                else
                {
                    Reports.StatusUpdate("Transmit button is NOT ENABLED for transmitting the data", false);
                }


                #endregion

                #region AF3_AF4_001: Outgoing Wire Summary: View, Search and Report Outgoing Wires and results exceed grid capacity. |BPUC0005_BAT0004|
                Reports.TestStep = "AF3_AF4_001: Outgoing Wire Summary: View, Search and Report Outgoing Wires and results exceed grid capacity. |BPUC0005_BAT0004|";
                Reports.StatusUpdate("AF3_AF4_001: Outgoing Wire Summary: View, Search and Report Outgoing Wires and results exceed grid capacity. |BPUC0005_BAT0004|", true);

                Reports.TestStep = "Select a Transmitted wire.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementSummary>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Summary").WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.WireDisbursementSummary.WaitForScreenToLoad();

                for (int DropDownCount = 0; DropDownCount < FastDriver.WireDisbursementSummary.BankAccounts.FAGetDropdownOptions().Count; DropDownCount++)
                {

                    FastDriver.WireDisbursementSummary.BankAccounts.FASelectItemByIndex(DropDownCount);
                    FastDriver.WireDisbursementSummary.FindNow.FAClick();
                    FastDriver.WireDisbursementSummary.WaitForScreenToLoad();
                    if (FastDriver.WireDisbursementSummary.OutGoingWireTable.FAGetText().Contains(FileNumber))
                    {
                        FastDriver.WireDisbursementSummary.OutGoingWireTable.PerformTableAction(1, FileNumber, 7, TableAction.Click);
                        Support.AreEqual("100.00", FastDriver.WireDisbursementSummary.OutGoingWireTable.PerformTableAction(1, FileNumber, 7, TableAction.GetText).Message.Clean());
                        FastDriver.WireDisbursementApproval.Method.FASelectItem("Preview");
                        FastDriver.WireDisbursementApproval.Deliver.FAClick();
                        FastDriver.WebDriver.WaitForDeliveryWindow("Preview");
                        FastDriver.WebDriver.ClosePreviewWindow();
                        break;
                    }


                }

                #endregion

                #region AF5_001: Outgoing Wire Status Writes to Event Log. |BPUC0005_BAT0005|
                Reports.TestStep = "AF5_001: Outgoing Wire Status Writes to Event Log. |BPUC0005_BAT0005|";
                Reports.StatusUpdate("AF5_001: Outgoing Wire Status Writes to Event Log. |BPUC0005_BAT0005|", true);

                Reports.TestStep = "Verifying the Wire event.";
                FastDriver.EventTrackingLog.Open();
                Playback.Wait(5000);

                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Playback.Wait(5000);

                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Wire]", "Event", TableAction.Click);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_BAT0001")]
        public void BPUC0005_BAT0002()
        {
            // This test case has been combined with BPUC0005_BAT0001
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_BAT0001";
                Reports.TestStep = "See test case BPUC0005_BAT0001.";
                Reports.StatusUpdate("See test case BPUC0005_BAT0001.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_BAT0001")]
        public void BPUC0005_BAT0003()
        {
            // This test case has been combined with BPUC0005_BAT0001
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_BAT0001";
                Reports.TestStep = "See test case BPUC0005_BAT0001.";
                Reports.StatusUpdate("See test case BPUC0005_BAT0001.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_BAT0001")]
        public void BPUC0005_BAT0004()
        {
            // This test case has been combined with BPUC0005_BAT0001
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_BAT0001";
                Reports.TestStep = "See test case BPUC0005_BAT0001.";
                Reports.StatusUpdate("See test case BPUC0005_BAT0001.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_BAT0001")]
        public void BPUC0005_BAT0005()
        {
            // This test case has been combined with BPUC0005_BAT0001
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_BAT0001";
                Reports.TestStep = "See test case BPUC0005_BAT0001.";
                Reports.StatusUpdate("See test case BPUC0005_BAT0001.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        #region REGRESSION

        [TestMethod]
        [Description("BP7708: Restrict User to Approve Issue Wire Disbursements.")]
        public void BPUC0005_REG0001()
        {
            try
            {
                Reports.TestDescription = "BP7708: Restrict User to Approve Issue Wire Disbursements";

                #region Admin Login
                _ADMLOGIN();
                #endregion

                Reports.TestStep = "Select office - QA automation region - Do NOT TOUCH";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Click on the required role and click edit button.";

                FastDriver.RoleMaintenanceSummary.Open();
                FastDriver.RoleMaintenanceSummary.Table.PerformTableAction(1, "IT no OO", 1, TableAction.Click);
                FastDriver.RoleMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Verify the role is present in the rights list.";
                FastDriver.RoleSetup.WaitForScreenToLoad();

                Support.AreEqual("Office Business Unit Processing Activity Group", FastDriver.RoleSetup.SelectedRightsTable.PerformTableAction(2, "Wire Interface - Outgoing Wire Approval", 3, TableAction.GetText).Message);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("BP7709_1: Wires that Qualify for Approval.")]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void BPUC0005_REG0002()
        {
            //This test case has been combined with BPUC0005_REG0003,BPUC0005_REG0004
            try
            {
                Reports.TestDescription = "BP7709_1: Wires that Qualify for Approval";

                #region BP7709_1: Wires that Qualify for Approval. |BPUC0005_REG0002|
                Reports.TestStep = "BP7709_1: Wires that Qualify for Approval. |BPUC0005_REG0002|";
                Reports.StatusUpdate("BP7709_1: Wires that Qualify for Approval. |BPUC0005_REG0002|", true);

                #region Login
                _IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.FileHomepage.Open();
                var FileNumber = FastDriver.FileHomepage.GetFileNumber();


                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Edit Disbursement -Wire.";

                FastDriver.ActiveDisbursementSummary.Open();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                Playback.Wait(5000);

                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Click on Scan button for scan.";
                //FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Escrow Closing>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.Open();

                FastDriver.DocumentRepository.Scan_DocsTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Open button and load the image document.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)

                Reports.TestStep = "Save the TIF Doc.";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");

                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(); FastDriver.DocumentRepository.DocumentsTab.FAClick();

                Reports.TestStep = "Verify that Document is uploaded to the FAST.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "PO-Invoice AFFIX INV", 4, TableAction.Click);

                Reports.TestStep = "Click Edit on Created Status.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add button for Wire Instruction.";

                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                Playback.Wait(5000);
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region BP7709_2: Wires that Qualify for Approval. |BPUC0005_REG0003|
                Reports.TestStep = "BP7709_2: Wires that Qualify for Approval. |BPUC0005_REG0003|";
                Reports.StatusUpdate("BP7709_2: Wires that Qualify for Approval. |BPUC0005_REG0003|", true);

                Reports.TestStep = "Login and Navigate to file.";

                #region Login
                _IISLOGIN();
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Click edit on Pend Wire.";
                FastDriver.ActiveDisbursementSummary.Open();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "HW name 1 HW name 2", "Payee", TableAction.Click);

                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Wire Instruction Image.";
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Image.FADoubleClick();

                //Click on CLoseButton on the webDialog
                Reports.TestStep = "Click On Close Button on the WebDialog";
                Playback.Wait(5000);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.WebDriver.SwitchTo().DefaultContent();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "button.ui-dialog-titlebar-close").FAClick();
                    FastDriver.EditDisbursement.WaitForScreenToLoad();

                    return FastDriver.EditDisbursement.Approve1.IsEnabled();
                }, 20);

                Reports.TestStep = "Approve Document repository for wire.";
                FastDriver.EditDisbursement.Approve1.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                #endregion

                #region BP7709_BP7710_BP7721_BP7712_BP13855_EWC4_FD: Restrict Void or Terminate Transmittal of Approved Wires /Pending Transmittal Status. |BPUC0005_REG0004|
                Reports.TestStep = "BP7709_BP7710_BP7721_BP7712_BP13855_EWC4_FD: Restrict Void or Terminate Transmittal of Approved Wires /Pending Transmittal Status. |BPUC0005_REG0003|";
                Reports.StatusUpdate("BP7709_BP7710_BP7721_BP7712_BP13855_EWC4_FD: Restrict Void or Terminate Transmittal of Approved Wires /Pending Transmittal Status. |BPUC0005_REG0003|", true);

                Reports.TestStep = "Login and Navigate to file.";

                #region Login
                _IISLOGIN();
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Click on Wire All button.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.WireAll.FAClick();

                Playback.Wait(5000);
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                Playback.Wait(5000);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Reason for lost");
                FastDriver.PasswordConfirmationDlg.Password.FASetText(AutoConfig.CheckPrintingPassword);
                FastDriver.DialogBottomFrame.ClickDone();

                Playback.Wait(5000);
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Verify Approval status.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(DateTime.Today.ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(DateTime.Today.ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("All Accounts");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                Reports.TestStep = "Click on Transmit.";
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(3, FileNumber, 3, TableAction.Click);
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(3, FileNumber, 1, TableAction.On);

                Playback.Wait(5000);
                if (FastDriver.WireDisbursementApproval.Transmit.IsEnabled())
                {
                    FastDriver.WireDisbursementApproval.Transmit.FAClick();
                    Playback.Wait(5000);
                }
                Reports.TestStep = "Verify Transmitted status.";

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.LeftNavigation.Navigate<WireDisbursementSummary>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Summary").WaitForScreenToLoad();

                    Playback.Wait(5000);
                    FastDriver.WireDisbursementSummary.WaitForScreenToLoad();
                    FastDriver.WireDisbursementSummary.BankAccounts.FASelectItem("All Accounts");
                    FastDriver.WireDisbursementSummary.FindNow.FAClick();
                    FastDriver.WireDisbursementSummary.WaitForScreenToLoad();

                    return FastDriver.WireDisbursementSummary.OutGoingWireTable.PerformTableAction(1, FileNumber, 3, TableAction.GetText).Message.Clean().Equals("Transmitted");
                }, 20);


                Support.AreEqual("Transmitted", FastDriver.WireDisbursementSummary.OutGoingWireTable.PerformTableAction(1, FileNumber, 3, TableAction.GetText).Message, "Verifying Wire status");

                Reports.TestStep = "Verify Transmit button is disabled.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                Support.AreEqual(false.ToString(), FastDriver.WireDisbursementApproval.Transmit.IsEnabled().ToString());

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_REG0002")]
        public void BPUC0005_REG0003()
        {
            // This test case has been combined with BPUC0005_REG0002
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_REG0002";
                Reports.TestStep = "See test case BPUC0005_REG0002.";
                Reports.StatusUpdate("See test case BPUC0005_REG0002.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_REG0002")]
        public void BPUC0005_REG0004()
        {
            // This test case has been combined with BPUC0005_REG0002
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_REG0002";
                Reports.TestStep = "See test case BPUC0005_REG0002.";
                Reports.StatusUpdate("See test case BPUC0005_REG0002.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("BP13856_BP13867: Approval Rules for wires < $20 Million.")]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void BPUC0005_REG0005()
        {
            //This test case has been combined with BPUC0005_REG0006,BPUC0005_REG0007
            try
            {
                Reports.TestDescription = "BP13856_BP13867: Approval Rules for wires < $20 Million &  BP13858_BP13868_BP13869: Approval of Wires and Batch Transmission/Enable Approved Checkbox/Disable Approved Checkbox & BP13858_BP13860: Approval of Wires and Batch Transmission.";

                #region BP13856_BP13867: Approval Rules for wires < $20 Million |BPUC0005_REG0005|
                Reports.TestStep = "BP13856_BP13867: Approval Rules for wires < $20 Million |BPUC0005_REG0005|";
                Reports.StatusUpdate("BP13856_BP13867: Approval Rules for wires < $20 Million |BPUC0005_REG0005|", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.FileHomepage.Open();
                var FileNumber = FastDriver.FileHomepage.GetFileNumber();


                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.DocumentRepository.Open();

                FastDriver.DocumentRepository.Scan_DocsTab.FAClick();//Correct the Scan to Scan_DocsTab
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Open button and load the image document.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)

                Reports.TestStep = "Save the TIF Doc.";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");

                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(); FastDriver.DocumentRepository.DocumentsTab.FAClick();

                Reports.TestStep = "Verify that Document is uploaded to the FAST.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "PO-Invoice AFFIX INV", 4, TableAction.Click);

                Reports.TestStep = "Click edit on Pend Wire.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "HW name 1 HW name 2", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";

                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                Playback.Wait(5000);

                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Add a Lease charge.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.FindGABcode("LEASE");

                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc" + FAKeys.Tab);
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeaseDetail.WaitForScreenToLoad();


                Reports.TestStep = "Click edit on Pend Wire.";
                FastDriver.ActiveDisbursementSummary.Open();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "lease name 1 lease name 2", "Payee", TableAction.Click);

                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                Playback.Wait(5000);

                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                FastDriver.UtilityDetail.Open();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");

                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText("Utility Charge" + FAKeys.Tab);
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText("50.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.UtilityDetail.WaitForScreenToLoad();

                Reports.TestStep = "Click edit on Pend Wire.";
                FastDriver.ActiveDisbursementSummary.Open();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Utility Company 1 for HUD Test Name 1 Ut", "Payee", TableAction.Click);

                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                Playback.Wait(5000);

                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                #endregion

                #region BP13858_BP13868_BP13869: Approval of Wires and Batch Transmission/Enable Approved Checkbox/Disable Approved Checkbox. |BPUC0005_REG0006|
                Reports.TestStep = "BP13858_BP13868_BP13869: Approval of Wires and Batch Transmission/Enable Approved Checkbox/Disable Approved Checkbox. |BPUC0005_REG0006|";
                Reports.StatusUpdate("BP13858_BP13868_BP13869: Approval of Wires and Batch Transmission/Enable Approved Checkbox/Disable Approved Checkbox. |BPUC0005_REG0006|", true);

                Reports.TestStep = "Login and Navigate to file.";

                #region Login
                _IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Click edit on Pend Wire.";
                FastDriver.ActiveDisbursementSummary.Open();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "HW name 1 HW name 2", "Payee", TableAction.Click);

                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Wire Instruction Image.";
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Image.FADoubleClick();

                //Click on CLoseButton on the webDialog
                Reports.TestStep = "Click On Close Button on the WebDialog";
                Playback.Wait(5000);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.WebDriver.SwitchTo().DefaultContent();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "button.ui-dialog-titlebar-close").FAClick();
                    FastDriver.EditDisbursement.WaitForScreenToLoad();

                    return FastDriver.EditDisbursement.Approve1.IsEnabled();
                }, 20);

                Reports.TestStep = "Approve Document repository for wire.";
                FastDriver.EditDisbursement.Approve1.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "lease name 1 lease name 2", "Payee", TableAction.Click);

                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Wire Instruction Image.";
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Image.FADoubleClick();

                //Click on CLoseButton on the webDialog
                Reports.TestStep = "Click On Close Button on the WebDialog";
                Playback.Wait(5000);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.WebDriver.SwitchTo().DefaultContent();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "button.ui-dialog-titlebar-close").FAClick();
                    FastDriver.EditDisbursement.WaitForScreenToLoad();

                    return FastDriver.EditDisbursement.Approve1.IsEnabled();
                }, 20);

                Reports.TestStep = "Approve Document repository for wire.";
                FastDriver.EditDisbursement.Approve1.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Utility Company 1 for HUD Test Name 1 Ut", "Payee", TableAction.Click);

                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Wire Instruction Image.";
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Image.FADoubleClick();

                //Click on CLoseButton on the webDialog
                Reports.TestStep = "Click On Close Button on the WebDialog";
                Playback.Wait(5000);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.WebDriver.SwitchTo().DefaultContent();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "button.ui-dialog-titlebar-close").FAClick();
                    FastDriver.EditDisbursement.WaitForScreenToLoad();

                    return FastDriver.EditDisbursement.Approve1.IsEnabled();
                }, 20);

                Reports.TestStep = "Approve Document repository for wire.";
                FastDriver.EditDisbursement.Approve1.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                #endregion

                #region BP13858_BP13860: Approval of Wires and Batch Transmission. |BPUC0005_REG0007|
                Reports.TestStep = "BP13858_BP13860: Approval of Wires and Batch Transmission. |BPUC0005_REG0007|";
                Reports.StatusUpdate("BP13858_BP13860: Approval of Wires and Batch Transmission. |BPUC0005_REG0007|", true);

                Reports.TestStep = "Login and Navigate to file.";

                #region Login
                _IISLOGIN();
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Click on Wire All button.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.WireAll.FAClick();

                Playback.Wait(5000);
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                Playback.Wait(5000);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Reason for lost");
                FastDriver.PasswordConfirmationDlg.Password.FASetText(AutoConfig.CheckPrintingPassword);
                FastDriver.DialogBottomFrame.ClickDone();

                Playback.Wait(5000);
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Verify Approval status.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(DateTime.Today.ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(DateTime.Today.ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("All Accounts");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                Reports.TestStep = "Click on Transmit.";
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(3, FileNumber, 3, TableAction.Click);
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(3, FileNumber, 1, TableAction.On);

                Playback.Wait(5000);
                if (FastDriver.WireDisbursementApproval.Transmit.IsEnabled())
                {
                    FastDriver.WireDisbursementApproval.Transmit.FAClick();
                    Playback.Wait(5000);
                }

                Reports.TestStep = "Verify Transmitted status.";

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.LeftNavigation.Navigate<WireDisbursementSummary>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Summary").WaitForScreenToLoad();

                    Playback.Wait(5000);
                    FastDriver.WireDisbursementSummary.WaitForScreenToLoad();
                    FastDriver.WireDisbursementSummary.BankAccounts.FASelectItem("All Accounts");
                    FastDriver.WireDisbursementSummary.FindNow.FAClick();
                    Playback.Wait(5000);
                    FastDriver.WireDisbursementSummary.WaitForScreenToLoad();
                    FastDriver.WireDisbursementSummary.OutGoingWireTable.PerformTableAction(1, FileNumber, 3, TableAction.Click);
                    return FastDriver.WireDisbursementSummary.OutGoingWireTable.PerformTableAction(1, FileNumber, 3, TableAction.GetText).Message.Clean().Equals("Transmitted");
                }, 120);


                Support.AreEqual("Transmitted", FastDriver.WireDisbursementSummary.OutGoingWireTable.PerformTableAction(1, FileNumber, 3, TableAction.GetText).Message, "Verifying Wire status");

                Reports.TestStep = "Verify Transmit button is disabled.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                Support.AreEqual(false.ToString(), FastDriver.WireDisbursementApproval.Transmit.IsEnabled().ToString());

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_REG0005")]
        public void BPUC0005_REG0006()
        {
            // This test case has been combined with BPUC0005_REG0005
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_REG0005";
                Reports.TestStep = "See test case BPUC0005_REG0005.";
                Reports.StatusUpdate("See test case BPUC0005_REG0005.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_REG0005")]
        public void BPUC0005_REG0007()
        {
            // This test case has been combined with BPUC0005_REG0005
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_REG0005";
                Reports.TestStep = "See test case BPUC0005_REG0005.";
                Reports.StatusUpdate("See test case BPUC0005_REG0005.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("BP13859_BP13857_BP13873: Approval Rules for wires equal to or greater than $20 Million & BP13857_BP13861_BP13865_BP13870_BP13871: Wire Approval Rules for Issue Wire Disbursement screen & BP13857_BP13862_BP13863_BP13866_BP13874_BP13864: Wire Approval Statuses / Allow Rejection for wire(s).")]
        [DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void BPUC0005_REG0008()
        {
            //This test case has been combined with BPUC0005_REG0009,BPUC0005_REG0010
            try
            {
                Reports.TestDescription = "BP13859_BP13857_BP13873: Approval Rules for wires equal to or greater than $20 Million";

                #region  BP13859_BP13857_BP13873: Approval Rules for wires equal to or greater than $20 Millions. |BPUC0005_REG0008|
                Reports.TestStep = "BP13859_BP13857_BP13873: Approval Rules for wires equal to or greater than $20 Millions. |BPUC0005_REG0008|";
                Reports.StatusUpdate("BP13859_BP13857_BP13873: Approval Rules for wires equal to or greater than $20 Millions. |BPUC0005_REG0008|", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.FileHomepage.Open();
                var FileNumber = FastDriver.FileHomepage.GetFileNumber();


                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("20000000.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("25.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();


                Reports.TestStep = "Click on Upload button.";

                FastDriver.DocumentRepository.UploadImgDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "");

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(); FastDriver.DocumentRepository.DocumentsTab.FAClick();

                Reports.TestStep = "Verify that Document is uploaded to the FAST.";
                Playback.Wait(5000);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous", 4, TableAction.Click);

                Reports.TestStep = "Click Edit on Created Status.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";

                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                Playback.Wait(5000);

                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify Approval 1 and 2 is disabled.";
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(false.ToString(), FastDriver.EditDisbursement.Approve1.IsEnabled().ToString());
                Support.AreEqual(false.ToString(), FastDriver.EditDisbursement.Approval2.IsEnabled().ToString());

                #endregion

                #region BP13857_BP13861_BP13865_BP13870_BP13871: Wire Approval Rules for Issue Wire Disbursement screen. |BPUC0005_REG0009|
                Reports.TestStep = "BP13857_BP13861_BP13865_BP13870_BP13871: Wire Approval Rules for Issue Wire Disbursement screen. |BPUC0005_REG0009|";
                Reports.StatusUpdate("BP13857_BP13861_BP13865_BP13870_BP13871: Wire Approval Rules for Issue Wire Disbursement screen. |BPUC0005_REG0009|", true);

                Reports.TestStep = "Login and Navigate to file.";

                #region Login
                _IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);

                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Wire Instruction Image.";
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Image.FADoubleClick();

                //Click on CLoseButton on the webDialog
                Reports.TestStep = "Click On Close Button on the WebDialog";
                Playback.Wait(5000);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.WebDriver.SwitchTo().DefaultContent();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "button.ui-dialog-titlebar-close").FAClick();
                    FastDriver.EditDisbursement.WaitForScreenToLoad();

                    return FastDriver.EditDisbursement.Approve1.IsEnabled();
                }, 20);

                Reports.TestStep = "Approve Approval 1 and Verify Approval2 is disabled.";
                FastDriver.EditDisbursement.Approve1.FASetCheckbox(true);

                Support.AreEqual(false.ToString(), FastDriver.EditDisbursement.Approval2.IsEnabled().ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                #endregion

                #region BP13857_BP13862_BP13863_BP13866_BP13874_BP13864: Wire Approval Statuses/Allow Rejection for wire(s). |BPUC0005_REG0010|
                Reports.TestStep = "BP13857_BP13862_BP13863_BP13866_BP13874_BP13864: Wire Approval Statuses / Allow Rejection for wire(s). | BPUC0005_REG0010 |";
                Reports.StatusUpdate("BP13857_BP13862_BP13863_BP13866_BP13874_BP13864: Wire Approval Statuses/Allow Rejection for wire(s). |BPUC0005_REG0010|", true);

                Reports.TestStep = "Login and Navigate to file.";

                #region Login
                _IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1487");

                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);

                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Wire Instruction Image.";
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Image.FADoubleClick();

                //Click on CLoseButton on the webDialog
                Reports.TestStep = "Click On Close Button on the WebDialog";
                Playback.Wait(5000);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.WebDriver.SwitchTo().DefaultContent();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    Playback.Wait(5000);
                    FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "button.ui-dialog-titlebar-close").FAClick();
                    FastDriver.EditDisbursement.WaitForScreenToLoad();

                    return FastDriver.EditDisbursement.Approval2.IsEnabled();
                }, 20);

                Reports.TestStep = "Approve Approval 2 and Verify Approval1 is checked.";
                FastDriver.EditDisbursement.Approval2.FASetCheckbox(true);

                Support.AreEqual(true.ToString(), FastDriver.EditDisbursement.Approve1.IsSelected().ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.WireAll.FAClick();

                Playback.Wait(5000);
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                Playback.Wait(5000);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Reason for lost");
                FastDriver.PasswordConfirmationDlg.Password.FASetText(AutoConfig.CheckPrintingPassword);
                FastDriver.DialogBottomFrame.ClickDone();

                Playback.Wait(5000);
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Click on View Details.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(DateTime.Today.AddDays(-1).ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(DateTime.Today.AddDays(1).ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("All Accounts");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(3, FileNumber, 3, TableAction.Click);

                FastDriver.WireDisbursementApproval.ViewDetails.FAClick();


                Reports.TestStep = "Click on Doc.";
                Playback.Wait(5000);
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                FastDriver.IssueWireDisbursement.Miscellaneous.FAClick();

                Reports.TestStep = "Click On close Image.";
                Playback.Wait(5000);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.IssueWireDisbursement.CloseImageGIF.FAClick();
                    Playback.Wait(5000);
                    return !FastDriver.IssueWireDisbursement.CloseImageGIF.IsDisplayed();

                }, 20);

                Reports.TestStep = "Check on Rejected.";
                FastDriver.IssueWireDisbursement.Rejected.FASetCheckbox(true);

                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                Reports.TestStep = "Verify Rejected Status.";

                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(DateTime.Today.AddDays(-1).ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(DateTime.Today.AddDays(1).ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("All Accounts");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Status", "Rejected", "Status", TableAction.Click);

                Reports.TestStep = "Verifying Pending status for Wire";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                Playback.Wait(5000);
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Wire]", "Event", TableAction.Click);

                Support.AreEqual(true.ToString(), FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Wire]", "Comments", TableAction.GetText).Message.Contains("Status: Pre-Approved").ToString(), "Verifying Row [Wire] contains \"Status: Pre-Approved\" on Comments column");
                Support.AreEqual(true.ToString(), FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Wire]", "Comments", TableAction.GetText).Message.Contains("Status: Approved").ToString(), "Verifying Row [Wire] contains \"Status: Approved\" on Comments column");
                Support.AreEqual(true.ToString(), FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Wire]", "Comments", TableAction.GetText).Message.Contains("Status: Issued").ToString(), "Verifying Row [Wire] contains \"Status: Issued\" on Comments column");
                Support.AreEqual(true.ToString(), FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Wire]", "Comments", TableAction.GetText).Message.Contains("Status: Rejected").ToString(), "Verifying Row [Wire] contains \"Status: Rejected\" on Comments column");


                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_REG0008")]
        public void BPUC0005_REG0009()
        {
            // This test case has been combined with BPUC0005_REG0008
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_REG0008";
                Reports.TestStep = "See test case BPUC0005_REG0008.";
                Reports.StatusUpdate("See test case BPUC0005_REG0008.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_REG0008")]
        public void BPUC0005_REG0010()
        {
            // This test case has been combined with BPUC0005_REG0008
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_REG0008";
                Reports.TestStep = "See test case BPUC0005_REG0008.";
                Reports.StatusUpdate("See test case BPUC0005_REG0008.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("EWC5_1: User rejects a wire on approval screen and selects Save or Transmit Now.")]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void BPUC0005_REG0011()
        {
            //This test case has been combined with BPUC0005_REG0009,BPUC0005_REG0010
            try
            {
                Reports.TestDescription = "EWC5_1: User rejects a wire on approval screen and selects Save or Transmit Now";

                #region EWC5_1: User rejects a wire on approval screen and selects Save or Transmit No. |BPUC0005_REG0011|
                Reports.TestStep = "EWC5_1: User rejects a wire on approval screen and selects Save or Transmit No. |BPUC0005_REG0011|";
                Reports.StatusUpdate("EWC5_1: User rejects a wire on approval screen and selects Save or Transmit No. |BPUC0005_REG0011|", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = CreateFile();
                #endregion

                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.FileHomepage.Open();
                var FileNumber = FastDriver.FileHomepage.GetFileNumber();


                Reports.TestStep = "Add a Lease charge.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.FindGABcode("LEASE");

                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc" + FAKeys.Tab);
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeaseDetail.WaitForScreenToLoad();

                #region Scan a Document
                Reports.TestStep = "Click on Scan button for scan.";

                FastDriver.DocumentRepository.Open();

                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Open button and load the image document.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)

                Reports.TestStep = "Save the TIF Doc.";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");

                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad(); FastDriver.DocumentRepository.DocumentsTab.FAClick();

                Reports.TestStep = "Verify that Document is uploaded to the FAST.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "PO-Invoice AFFIX INV", 4, TableAction.Click);

                #endregion Scan a Document

                Reports.TestStep = "Edit Disbursement -Wire.";

                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";

                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                Playback.Wait(5000);

                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                #endregion

                #region EWC5_2: User rejects a wire on approval screen and selects Save or Transmit Now. |BPUC0005_REG0012|
                Reports.TestStep = "EWC5_2: User rejects a wire on approval screen and selects Save or Transmit Now. |BPUC0005_REG0012|";
                Reports.StatusUpdate("EWC5_2: User rejects a wire on approval screen and selects Save or Transmit Now. |BPUC0005_REG0012|", true);

                Reports.TestStep = "Login and Navigate to file.";

                #region Login
                _IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.ActiveDisbursementSummary.Open();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);

                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Wire Instruction Image.";
                Playback.Wait(5000);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Image.FADoubleClick();

                //Click on CLoseButton on the webDialog
                Reports.TestStep = "Click On Close Button on the WebDialog";
                Playback.Wait(5000);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.WebDriver.SwitchTo().DefaultContent();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "button.ui-dialog-titlebar-close").FAClick();
                    FastDriver.EditDisbursement.WaitForScreenToLoad();

                    return FastDriver.EditDisbursement.Approve1.IsEnabled();
                }, 20);

                Reports.TestStep = "Approve Document repository for wire.";
                FastDriver.EditDisbursement.Approve1.FASetCheckbox(true);

                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                #endregion

                #region EWC5_3: User rejects a wire on approval screen and selects Save or Transmit Now. |BPUC0005_REG0013|
                Reports.TestStep = "EWC5_3: User rejects a wire on approval screen and selects Save or Transmit Now. | BPUC0005_REG0013 |";
                Reports.StatusUpdate("EWC5_3: User rejects a wire on approval screen and selects Save or Transmit Now. |BPUC0005_REG0013|", true);

                FastDriver.ActiveDisbursementSummary.WireAll.FAClick();

                Playback.Wait(5000);
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                Playback.Wait(5000);

                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();

                Playback.Wait(5000);
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Playback.Wait(5000);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();


                #endregion

                #region EWC5_4: User rejects a wire on approval screen and selects Save or Transmit Now. |BPUC0005_REG0014|
                Reports.TestStep = "EWC5_4: User rejects a wire on approval screen and selects Save or Transmit Now. | BPUC0005_REG0014|";
                Reports.StatusUpdate("EWC5_4: User rejects a wire on approval screen and selects Save or Transmit Now. |BPUC0005_REG0014|", true);

                Reports.TestStep = "Login and Navigate to file.";

                #region Login
                _IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                #endregion

                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1487");

                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Click on Wire Approval.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(DateTime.Today.ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(DateTime.Today.ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("All Accounts");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(3, FileNumber, 1, TableAction.On);

                Reports.TestStep = "Click on Home.";
                FastDriver.LeftNavigation.ClickHome();
                Reports.TestStep = "User attempts to navigate off screen via any method without transmit selected approved wires.";
                Support.AreEqual("You must transmit or deselect the selected wires", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Click on View Details.";
                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.ViewDetails.FAClick();

                Reports.TestStep = "Click On Image.";
                Playback.Wait(5000);
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                FastDriver.IssueWireDisbursement.Miscellaneous.FAClick();

                Reports.TestStep = "Click On close Image.";
                Playback.Wait(5000);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.IssueWireDisbursement.CloseImageGIF.FAClick();
                    Playback.Wait(5000);
                    return !FastDriver.IssueWireDisbursement.CloseImageGIF.IsDisplayed();

                }, 20);

                Reports.TestStep = "Check on Rejected.";
                FastDriver.IssueWireDisbursement.Rejected.FASetCheckbox(true);

                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                Reports.TestStep = "Search for the record and verify for Rejected Status.";

                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(DateTime.Today.AddDays(-1).ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(DateTime.Today.AddDays(1).ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("All Accounts");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Status", "Rejected", "Status", TableAction.Click);

                Reports.TestStep = "Validate Alert for Rejection of approved wire.";
                FastDriver.LeftNavigation.Navigate<MyFASTToday>("Home>Order Entry>My Fast Today").SwitchToContentFrame();
                Playback.Wait(5000);

                FastDriver.MyFASTToday.WaitForScreenToLoad();
                FastDriver.MyFASTToday.AlertType.FASelectItem("Electronic Wire");

                Playback.Wait(5000);
                FastDriver.MyFASTToday.WaitForScreenToLoad();

                var splittedUser = AutoConfig.UserNameSecondary.Split('\\');
                var reverseUser = splittedUser[1].Substring(4, 4) + ", " + splittedUser[1].Substring(0, 4);
                reverseUser = reverseUser.ToUpper();
                FastDriver.MyFASTToday.AlertUser.FASelectItem(reverseUser);


                Support.AreEqual("Electronic Wire: Rejected from approval.", FastDriver.MyFASTToday.SummaryAlertsTable.PerformTableAction("File Number", FileNumber, "Message", TableAction.GetText).Message);

                #endregion

                #region BP7728_BP7698_BP7723: Report Wires Previously Transmitted/Transmitted Status. |BPUC0005_REG0015|
                Reports.TestStep = "BP7728_BP7698_BP7723: Report Wires Previously Transmitted/Transmitted Status. | BPUC0005_REG0015|";
                Reports.StatusUpdate("BP7728_BP7698_BP7723: Report Wires Previously Transmitted/Transmitted Status. |BPUC0005_REG0015|", true);

                Reports.TestStep = "Search for the record and verify for Rejected Status.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                Playback.Wait(5000);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(DateTime.Today.ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(DateTime.Today.ToString("MM/dd/yyyy").Replace("/", "-"));
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("All Accounts");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Status", "Rejected", "Status", TableAction.Click);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_REG0011")]
        public void BPUC0005_REG0012()
        {
            // This test case has been combined with BPUC0005_REG0011
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_REG0011";
                Reports.TestStep = "See test case BPUC0005_REG0011.";
                Reports.StatusUpdate("See test case BPUC0005_REG0011.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_REG0011")]
        public void BPUC0005_REG0013()
        {
            // This test case has been combined with BPUC0005_REG0011
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_REG0011";
                Reports.TestStep = "See test case BPUC0005_REG0011.";
                Reports.StatusUpdate("See test case BPUC0005_REG0011.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_REG0011")]
        public void BPUC0005_REG0014()
        {
            // This test case has been combined with BPUC0005_REG0011
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_REG0011";
                Reports.TestStep = "See test case BPUC0005_REG0011.";
                Reports.StatusUpdate("See test case BPUC0005_REG0011.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("This test case has been combined with BPUC0005_REG0011")]
        public void BPUC0005_REG0015()
        {
            // This test case has been combined with BPUC0005_REG0011
            try
            {
                Reports.TestDescription = "This test case has been combined with BPUC0005_REG0011";
                Reports.TestStep = "See test case BPUC0005_REG0011.";
                Reports.StatusUpdate("See test case BPUC0005_REG0011.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        [Description("BP9934_BP9935_BP9902_BP7727_BP9903_BP7715: Email alert if Wire is rejected")]
        public void BPUC0005_REG0016_PH()
        {
            try
            {
                Reports.TestDescription = "TBP9934_BP9935_BP9902_BP7727_BP9903_BP7715: Email alert if Wire is rejected";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY.", false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        [Description("BR13866_BP13875_EWC7_EWC1_EWC6_BP7729: Accept and Display Incoming Wires from Incoming Wires screen")]
        public void BPUC0005_REG0017_PH()
        {
            try
            {
                Reports.TestDescription = "BR13866_BP13875_EWC7_EWC1_EWC6_BP7729: Accept and Display Incoming Wires from Incoming Wires screen";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY.", false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void BPUC0005_REG0018()
        {
            try
            {

                Reports.TestDescription = "INC1076894 - Direct - Outgoing Wire Summary/Approval screens should default to Primary Disburse Account";
                Reports.TestStep = "Log into FAST application.";
                _ADMLOGIN();

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to Office Setup screen";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Bank Accounts and locate Primary Disbursement account";
                FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
                FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
                FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction(6, "Yes", 6, TableAction.Click);

                Reports.TestStep = "Navigate to Bank Accounts and locate Primary Disbursement account";
                string defaultAccount = FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction(6, "Yes", 4, TableAction.GetText).Message.Clean();
                Support.AreEqual(true, FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction(4, defaultAccount, 1, TableAction.GetText).Message.Clean().Equals("Active"), "Verifying " + defaultAccount + " is listed as active");
                Support.AreEqual(true, FastDriver.OfficeSetupBankAccounts.DisburseAcct.IsSelected(), "Verifying " + defaultAccount + " is listed as a disburse acct.");
                Support.AreEqual(true, FastDriver.OfficeSetupBankAccounts.PrimaryDisburse.IsSelected(), "Verifying " + defaultAccount + " is listed as a primary disburse acct.");
                Support.AreEqual(true, FastDriver.OfficeSetupBankAccounts.WirelinkInterfaceAccount.IsSelected(), "Verifying " + defaultAccount + " is listed as a Wirelink Interface acct.");
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST IIS application.";
                _IISLOGIN();

                Reports.TestStep = "Create a file";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Verifying that account listed as Primary Disbursement is listed as the default option.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.WireDisbursementApproval.BankAccounts.FAGetSelectedItem().Contains(defaultAccount), "Verifying that account listed as Primary Disbursement is listed as the default option.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region PRIVATE METHODS

        private FormType CreateFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";

            customizableFileRequest.File.Properties = new Property[]
            {
                new Property()
                {
                    PropertyAddress = new PhysicalAddress[]
                    {
                        new PhysicalAddress()
                        {
                            State = "CA",
                            City = "ALBANY",
                            County = "ALAMEDA",
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        }
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                }
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        }
                };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return customizableFileRequest.formType;
        }

        private FormType CreateFileInWireLinkRegion()
        {
            int regionID = 2075;
            int officeBUID = 9919;

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";

            customizableFileRequest.File.Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = regionID, 
                                BUID = officeBUID, 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = regionID, 
                                BUID = officeBUID, 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    };

            customizableFileRequest.File.Properties = new Property[]
            {
                new Property()
                {
                    PropertyAddress = new PhysicalAddress[]
                    {
                        new PhysicalAddress()
                        {
                            State = "CA",
                            City = "ALBANY",
                            County = "ALAMEDA",
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        }
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                }
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionID),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        }
                };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return customizableFileRequest.formType;
        }
        private void _IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void _ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);

        }


        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
