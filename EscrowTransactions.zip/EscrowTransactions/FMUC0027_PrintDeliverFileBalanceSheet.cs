﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using System.Runtime.Serialization;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using System.Collections.ObjectModel;
using System.Threading;


namespace EscrowTransactions
{
    [CodedUITest, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class FMUC0027_PrintDeliverFileBalanceSheet : MasterTestClass
    {

        #region BAT
        #region Test FMUC0027_BAT0001

        [TestMethod]
        public void FMUC0027_BAT0001()
        {

            try
            {
                Reports.TestDescription = "MF1: Print/Deliver File Balance Sheet.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                defaultRequest.File.TransactionTypeObjectCD = "CD"; //"Construction Disbursement";

                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE",
                        } 
                    };

                defaultRequest.File.BusinessParties = BusinessParties;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);


                Reports.TestStep = "Verify fields in Filehomepage for full sanity.";
                Reports.TestStep = "Navigate to File balance summary screen";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>(@"Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                Reports.TestStep = "Perform Print Deliveries.";
                FastDriver.PrintEscrowSetlleStmt.Method.FASelectItem("Print");
                FastDriver.PrintEscrowSetlleStmt.Deliver.FAClick();

                Reports.TestStep = "Perform Print";
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                
                FastDriver.WebDriver.WaitForDeliveryWindow("Print"); 

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }


        #endregion Test FMUC0027_BAT0001
        #endregion BAT

        #region REGRESSION
        #region Test FMUC0027_REG0001

        [TestMethod]
        public void FMUC0027_REG0001()
        {
            try
            {
                Reports.TestDescription = "SETUP: Checking for the activity is assigned to the USER for the Deposit in Escrow Screen.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTAdmURL, Credentials, true);

                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>Others>Select Office");
                FastDriver.OfficeSetupOffice.SwitchToContentFrame();

                FastDriver.SecuritySelectRegionOffice.SearchbyBUID.FASetText(AutoConfig.SelectedRegionBUID);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.SecuritySelectRegionOffice.RegionsTable.PerformTableAction(1, "First American Corporation", 1, TableAction.Click);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on the required role and click edit button.";
                FastDriver.LeftNavigation.Navigate<RoleMaintenanceSummary>(@"Home>System Maintenance>Security Maintenance>Role Maintenance");
                FastDriver.RoleMaintenanceSummary.SwitchToContentFrame();

                FastDriver.RoleMaintenanceSummary.Table.PerformTableAction(1, "IT no OO", 1, TableAction.Click);


                FastDriver.RoleMaintenanceSummary.Edit.FAClick();
                FastDriver.RoleSetup.SwitchToContentFrame();

                Reports.TestStep = "Validate the fee entry right is available for Escrow File Entry Activity.";
                string values = FastDriver.RoleSetup.SelectedRightsTable.PerformTableAction(2, "Escrow File Entry Activity", 2, TableAction.GetText).Message.ToString();

                if (values != "Escrow File Entry Activity")
                {
                    Support.Fail("Fee entry not found");
                }
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion Test FMUC0027_REG0001
        #region Test FMUC0027_REG0002

        [TestMethod]
        public void FMUC0027_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM3684_FM3685_FM3690_FM1112_FM1139_FM1140_FM1113_FM1131_FM1134_FM1181_FM3259_FM3317: Creating Different type of Deposits based on Type of Funds from Deposit in Escrow screen and generating Preview From File Balance Summa";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE",
                        } 
                    };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                {
                    new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                {                                    
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA",
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                } 
                            } 
                        } 
                };
                var Buyer1 = new BuyerSeller[] { 
                    new BuyerSeller()
                    {
                        FirstName = "",
                        LastName = "",
                        Type = ""
                    }
                };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                //Filling in Property Information
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("247");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem("No Program Type");
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5,000.00");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseFirstname");
                FastDriver.QuickFileEntry.Buyer2SpouseLastName.FASetText("Buyer2SpouseLastname");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseFirstname");
                FastDriver.QuickFileEntry.Seller2SpouseLastName.FASetText("Seller2SpouseLastname");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify fields in Filehomepage for full sanity.";
                FastDriver.FileHomepage.GetUrl();
                FastDriver.FileHomepage.SwitchToContentFrame();

                Support.AreEqual("True", FastDriver.FileHomepage.ChangeOO.Displayed.ToString());
                Support.AreEqual("Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem().ToString());
                Support.AreEqual("5,000.00", FastDriver.FileHomepage.TermsDatesPrice.FAGetValue().Trim());
                Support.AreEqual("J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Trim());
                Support.AreEqual("Single Family Residence", FastDriver.FileHomepage.PropertyType.FAGetSelectedItem().ToString());
                Support.AreEqual("Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetValue().Trim());
                Support.AreEqual("Block1", FastDriver.FileHomepage.PropertyBlock.FAGetValue().Trim());
                Support.AreEqual("Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetValue().Trim());
                Support.AreEqual("Prop1APN1", FastDriver.FileHomepage.PropertyPropTaxAPN1.FAGetValue().Trim());
                Support.AreEqual("9845012345", FastDriver.FileHomepage.PropertyPropTaxAPN2.FAGetValue().Trim());
                Support.AreEqual("J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Trim());
                Support.AreEqual("JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Trim());
                Support.AreEqual("JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Trim());
                Support.AreEqual("ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Trim());
                Support.AreEqual("CA", FastDriver.FileHomepage.PropertyState.FAGetSelectedItem().ToString());
                Support.AreEqual("ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Trim());
                Support.AreEqual("Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem().ToString());
                Support.AreEqual("Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Trim());
                Support.AreEqual("Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Trim());
                Support.AreEqual("Husband/Wife", FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem().ToString());
                Support.AreEqual("Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().Trim());
                Support.AreEqual("Buyer2Lastname", FastDriver.FileHomepage.Buyer2LastName.FAGetValue().Trim());
                Support.AreEqual("True", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue().Trim().Contains("Buyer2SpouseFirstn").ToString());
                Support.AreEqual("True", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue().Trim().Contains("Buyer2SpouseLastn").ToString());
                Support.AreEqual("Seller1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Trim());
                Support.AreEqual("Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue().Trim());
                Support.AreEqual("Husband/Wife", FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem().ToString());
                Support.AreEqual("Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().Trim());
                Support.AreEqual("Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue().Trim());
                Support.AreEqual("True", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue().Trim().Contains("Seller2SpouseFirstn").ToString());
                Support.AreEqual("True", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue().Trim().Contains("Seller2SpouseLastn").ToString());

                Reports.TestStep = "Create Loan Instance and Enter charges Under Charges TAB.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("3000");
                FastDriver.NewLoan.FindGABCode("247");


                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                if (IsFormTypeCD())
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BuyerCharge.IsEnabled().ToString());
                }
                else 
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                }

                Reports.TestStep = "Click on Done";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Enter the Estimated settlement date.";
                
                string cDate = string.Empty;
                cDate = DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString();

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();

                if (!cDate.Equals(FastDriver.TermsDatesStatus.StatusDate.FAGetAttribute("value")))
                {
                    FastDriver.TermsDatesStatus.StatusDate.FASetText(cDate);
                }



                FastDriver.TermsDatesStatus.EstimattedSettlementDate.FASetText("8-20-2012");
                FastDriver.TermsDatesStatus.DisbursementDate.FAClick();
                Keyboard.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Validate Message on change the Estimated Date on TDS..";
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Prorate As of Date?", FastDriver.WebDriver.HandleDialogMessage(false,false,5));
                FastDriver.WebDriver.HandleDialogMessage(true, false,5);


                Reports.TestStep = "Deposit cash";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Comments before Save");


                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnSave.FAClick();


                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 3);

                Reports.TestStep = "Deposit a cash more than sales price.";
                DepositCash("6000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Comments before Save");


                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnSave.FAClick();



                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(false, true, 3);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 3);

                DepositCash("6.00", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnSave.FAClick();

                Reports.TestStep = "Validate the Static Message on Deposit in Escrow Screen on Deposit More Amount.";
                string ActualMessage = FastDriver.WebDriver.HandleDialogMessage(false, true, 3);
                string ExpectedMessage = @"Important! The credit to party contains total cash or similar deposits in excess of $10,000. Form 8300 is required to be completed and filed with the IRS within 15 days.";
                Support.AreEqual(ExpectedMessage, ExpectedMessage);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 3);

                //string data = "The credit to party contains total cash or similar deposits in excess of $10,000.";

                //Support.AreEqual("True", value.Contains(data).ToString());

                //data = "PLEASE CONSULT WITH YOUR MANAGEMENT TO DETERMINE WHETHER  FORM 8300 IS REQUIRED TO BE FILED.";
                //Support.AreEqual("True", value.Contains(data).ToString());

  
                Reports.TestStep = "Verify for the Message on FBS screen after deposit more than 10,000.00.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                string value = FastDriver.EscrowFileBalanceSummary.Thisfilecom8300isrequired.FAGetText();
                Support.AreEqual("# This file contains individual cash equivalent instruments in amounts of $10,000 or less, whose sum is in excess of $10,000.00. Please investigate whether form 8300 is required to be filed.", value);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Comments before Save");
                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnSave.FAClick();

                Reports.TestStep = "Validate the Static Message on Deposit in Escrow Screen on Deposit More Amount.";
                value = FastDriver.WebDriver.HandleDialogMessage(false, true, 3).Clean();
                string data = @"Important! The credit to party contains total cash or similar deposits in excess of $10,000. Form 8300 is required to be completed and filed with the IRS within 15 days.";
                Support.AreEqual(data, value);

                data = "PLEASE CONSULT WITH YOUR MANAGEMENT TO DETERMINE WHETHER  FORM 8300 IS REQUIRED TO BE FILED.";
                //Support.AreEqual("True", value.Contains(data).ToString());

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 3);


                Reports.TestStep = "Verify for the Message on FBS screen after deposit extra amount after 10,00.00.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                value = FastDriver.EscrowFileBalanceSummary.Thisfilecom8300isrequired.FAGetText();
                Support.AreEqual("# This file contains individual cash equivalent instruments in amounts of $10,000 or less, whose sum is in excess of $10,000.00. Please investigate whether form 8300 is required to be filed.", value);
                
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Estimated settlement date.";

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();

                value = DateTime.Now.ToDateString();
                value = value.Replace("/", "-");

                FastDriver.TermsDatesStatus.EstimattedSettlementDate.FASetText("8-21-2012" + FAKeys.Tab);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false, 3);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false, 3);

                Reports.TestStep = "Enter the settlement date and disbursement date.";
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("0-21-2012");
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("8/21/2012");

                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Perform Preview Deliveries in Escrow File Balance Summary Screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                FastDriver.EscrowFileBalanceSummary.Method("Preview");
                FastDriver.EscrowFileBalanceSummary.Deliver();                

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        
        #endregion Test FMUC0027_REG0002
        #region Test FMUC0027_REG0003

        [TestMethod]
        public void FMUC0027_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM1109_78_79_19_33_77_47_44_FM956_57_58_ES10055_56_FM3605_16_FM3320_21_26_FM3325_ES7429_FM3247_A: Creating Deposit from Deposit in Escrow screen and Adjusting the created deposit.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            
                        } 
                    };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                {
                    new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                {                                    
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA",
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                } 
                            } 
                        } 
                };
                var Buyer1 = new BuyerSeller[] { 
                    new BuyerSeller()
                    {
                        FirstName = "",
                        LastName = "",
                        Type = ""
                    }
                };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                //Filling in Property Information
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Create Order.";
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Outside Title Company");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem("No Program Type");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5,000.00");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseFirstname");
                FastDriver.QuickFileEntry.Buyer2SpouseLastName.FASetText("Buyer2SpouseLastname");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseFirstname");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();

                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText("Notes Data including - * # Specialcharacter :) !");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Loan Instance and Enter charges Under Charges TAB.";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("3000");
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.FAClick();                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                if (IsFormTypeCD())
                {
                    Reports.TestStep = "Verify the Buyer charge Field Disiabled in Payment Details Dialog.";
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BuyerCharge.IsEnabled().ToString());
                }
                else
                {
                    
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                }


                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Estimated settlement date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                string cDate = string.Empty;
                cDate = DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString();

                if (!cDate.Equals(FastDriver.TermsDatesStatus.StatusDate.FAGetValue()))
                {
                    FastDriver.TermsDatesStatus.StatusDate.FASetText(cDate);
                }

                string curDate = DateTime.Now.ToDateString();
                curDate = curDate.Replace("/", "-");

                FastDriver.TermsDatesStatus.EstimattedSettlementDate.FASetText("8-22-2012" + FAKeys.Tab);
                
                Reports.TestStep = "Validate Message on change the Estimated Date on TDS..";
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Prorate As of Date?", FastDriver.WebDriver.HandleDialogMessage(false, false));

                Reports.TestStep = "Validate Message on change the Estimated Date on TDS..";
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Funding Date for Loans?", FastDriver.WebDriver.HandleDialogMessage(false, false));                

                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer");

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);


                Reports.TestStep = "Click on deposits created and Adjust it.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.SwitchToContentFrame();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Change Adjustment Reason to Input Error.";
                FastDriver.DepositAdjustment.SwitchToContentFrame();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Input Error");
                FastDriver.DepositAdjustment.Comment.FASetText("Adjusted to Input Error");

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Perform Preview Deliveries.";
                FastDriver.DepositAdjustment.SwitchToContentFrame();
                FastDriver.DepositAdjustment.Method.FASelectItem("Preview");
                FastDriver.DepositAdjustment.Deliver.FAClick();

                FastDriver.WebDriver.WaitForDeliveryWindow();


                FastDriver.BottomFrame.Done();



            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0027_REG0004

        [TestMethod]
        public void FMUC0027_REG0004()
        {

            try
            {
                Reports.TestDescription = "FM1109_78_79_19_33_77_47_44_FM956_57_58_ES10055_56_FM3605_16_FM3320_21_26_FM3325_ES7429_FM3247_B: Creating charges on Different screen and Preview From File Balance Summary Screen.";

                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            
                        } 
                    };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                {
                    new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                {                                    
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA",
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                } 
                            } 
                        } 
                };
                var Buyer1 = new BuyerSeller[] { 
                    new BuyerSeller()
                    {
                        FirstName = "",
                        LastName = "",
                        Type = ""
                    }
                };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                //Filling in Property Information
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Create Order.";
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Outside Title Company");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem("No Program Type");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5,000.00");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseFirstname");
                FastDriver.QuickFileEntry.Buyer2SpouseLastName.FASetText("Buyer2SpouseLastname");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseFirstname");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();

                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText("Notes Data including - * # Specialcharacter :) !");

                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Set an instance of Home warranty details.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty");
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                FastDriver.HomeWarrantyDetail.GABcode.FASetText("HW1");
                FastDriver.HomeWarrantyDetail.Find.FAClick();

                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                Reports.TestStep = "Enter charges in Payment Details Dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);


                Reports.TestStep = "Set an instance.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association");
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("HOA2");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();

                Reports.TestStep = "Enter charges in Payment Details Dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                
                Reports.TestStep = "Set an instance of the Lease Details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.SwitchToContentFrame();

                FastDriver.LeaseDetail.GABcode.FASetText("HUDLEASE03");
                FastDriver.LeaseDetail.Find.FAClick();
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Enter charges in Payment Details Dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Set an instance of the Outside Escrow Company Detail.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company");
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText("HUDOUTESC1");
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();

                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("OEC");
                
                Reports.TestStep = "Click on Payment details and enter charges.";
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Enter charges in Payment Details Dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Set an instance of OTC details.";
                FastDriver.LeftNavigation.Navigate<OTCDetail>("Home>Order Entry>Outside Title Company");
                FastDriver.OTCDetail.SwitchToContentFrame();

                FastDriver.OTCDetail.GABcode.FASetText("814");
                FastDriver.OTCDetail.Find.FAClick();

                FastDriver.OTCDetail.OTCTitleServicesBuyerCharge.FASetText("10");
                FastDriver.OTCDetail.OTCTitleServicesSellerCharge.FASetText("10");

                Reports.TestStep = "Verify the Additional Role of Business Source as Outside Title Company and Click on Payment Details button.";
                Support.AreEqual("Outside Title Company", FastDriver.OTCDetail.Type.FAGetSelectedItem().ToString());
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.FAClick();

                Reports.TestStep = "Enter charges in Payment Details Dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Set an instance for Survey Details.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey");
                FastDriver.SurveyDetail.SwitchToContentFrame();

                FastDriver.SurveyDetail.GABcode.FASetText("247");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Enter charges in Payment Details Dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                EnterFeeInTitleEscrowTab();

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disb Summary and Fee amount row.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent("Overdraft Confirmation"))
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad("Overdraft Confirmation", FastDriver.OverdraftConfirmationDlg.ReasonForLoss);
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                else
                {
                    Reports.TestStep = "Enter password confimation details dialog info.";
                    FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                    FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
                    FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");
                    
                    if (FastDriver.PasswordConfirmationDlg.LossPassword.IsDisplayed())
                        FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);
                    
                    Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                    FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                
                Reports.TestStep = "Change File status to Closed.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.ChangeFileStatusDlg.FileStatus.FASelectItem("Closed");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Print the checks.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItem("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print");
                
                Reports.TestStep = "Perform Preview Deliveries in Escrow File Balance Summary Screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                FastDriver.PrintEscrowSetlleStmt.Method.FASelectItem("Preview");
                FastDriver.PrintEscrowSetlleStmt.Deliver.FAClick();


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        #endregion
        #region Test FMUC0027_REG0005

        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0027_REG0005()
        {
            try
            {

                Reports.TestDescription = "FM1109_78_79_19_33_77_47_44_FM956_57_58_ES10055_56_FM3605_16_FM3320_21_26_FM3325_ES7429_FM3247_C: Converting pending charges to wire Check and Wire,and Creating IBA Transaction(First_User).";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            
                        } 
                    };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                {
                    new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                {                                    
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA",
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                } 
                            } 
                        } 
                };
                var Buyer1 = new BuyerSeller[] { 
                    new BuyerSeller()
                    {
                        FirstName = "",
                        LastName = "",
                        Type = ""
                    }
                };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                //Filling in Property Information
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Create Order.";
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Outside Title Company");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem("No Program Type");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5,000.00");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseFirstname");
                FastDriver.QuickFileEntry.Buyer2SpouseLastName.FASetText("Buyer2SpouseLastname");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseFirstname");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();

                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText("Notes Data including - * # Specialcharacter :) !");

                FastDriver.BottomFrame.Done();             

                #region Navigate to Document Repository screen and Click on Scan button
                Reports.TestStep = "Navigate to Document Repository screen and Click on Scan button.";
                FastDriver.DocumentRepository.Open();
                
                Playback.Wait(3000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                Playback.Wait(5000);
                FastDriver.DocumentRepository.Scan.FAClick();

                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
               
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(5000); //wait for Save Document dialog (bacause we are using AutoIt to handle it) 
                FastDriver.BottomFrame.Done();



                Reports.TestStep = "Save the TIF Doc.";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");

                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 30);
                #endregion

                Reports.TestStep = "Verify for scanned Document.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.ScannedDoc.FAClick();

                Reports.TestStep = "Deposit a cash.";                               
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer","",  "Comments Before Save");

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnSave.FAClick();


                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 3);

                Reports.TestStep = "Change the description and charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.SwitchToContentFrame();

                FastDriver.LeaseDetail.GABcode.FASetText("HUDLEASE03");
                FastDriver.LeaseDetail.Find.FAClick();

                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty");

                FastDriver.HomeWarrantyDetail.GABcode.FASetText("248");
                FastDriver.HomeWarrantyDetail.Find.FAClick();

                if (IsFormTypeCD())
                {
                    Support.AreEqual("False", FastDriver.HomeWarrantyDetail.paidSeller.Displayed.ToString());
                    Support.AreEqual("False", FastDriver.HomeWarrantyDetail.BuyerBroker.Displayed.ToString());
                }
                else
                {
                    FastDriver.HomeWarrantyDetail.paidSeller.FASetText("250.00");
                    FastDriver.HomeWarrantyDetail.BuyerBroker.FASetText("350.00");
                }

                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.WebDriver.HandleDialogMessage(true, true,3);
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("300.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("275.00");
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.HomeWarrantyDetail.EarlyCoverageChargeDescription.FASetText("Home Warranty - Early Coverage");
                FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FASetText("699.00");
                FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FASetText("845.00");

                FastDriver.BottomFrame.Done();

                SetDefaultCheckPrinter();

                Reports.TestStep = "To Issue the check click the Print all button in Active Disbursement Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3,"Check", 1,TableAction.Click);

                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.SwitchToContentFrame();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Select Wire Instructions");
                FastDriver.SelectWireInstructionsDlg.SwitchToDialogContentFrame();

                FastDriver.SelectWireInstructionsDlg.Instruction1.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.EditDisbursement.SwitchToContentFrame();
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBankAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Beneficiary Note 1");

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Wire Button.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();

                Reports.TestStep = "Disburse the wire.";
                FastDriver.DisburseWires.SwitchToContentFrame();
                FastDriver.DisburseWires.Disburse.FAClick();

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts");
                FastDriver.InterestBearingAccounts.SwitchToContentFrame();

                FastDriver.InterestBearingAccounts.New.FAClick();

                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Select IBA Beneficiary");
                FastDriver.SelectIBABeneficiaryDlg.SwitchToDialogContentFrame();
                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();

                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText("Beneficiary TFS_104164");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText("Address Line 1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText("Address Line 2");
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText("Santa ana");
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem("CA");
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText("92727");
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText("123456789");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select IBA bank.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.SwitchToContentFrame();
                FastDriver.InterestBearingAccounts.Details.FAClick();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Select IBA Bank");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.SwitchToContentFrame();

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.Transactions.FAClick();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                
                FastDriver.BottomFrame.Save();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0027_REG0006

        [TestMethod]
        public void FMUC0027_REG0006()
        {
            Reports.TestDescription = "FM1109_78_79_19_33_77_47_44_FM956_57_58_ES10055_56_FM3605_16_FM3320_21_26_FM3325_ES7429_FM3247_D: Approving IBA(Second_User).";
            try
            {
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Approve the Transaction.";
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>("Home>Business Unit Processing>IBA Interface>IBA Transaction Approval");
                FastDriver.IBATransactionApproval.SwitchToContentFrame();

                FastDriver.IBATransactionApproval.Select_None.FAClick();

                FastDriver.IBATransactionApproval.CheckTransactionaApproval();

                FastDriver.IBATransactionApproval.Approve.FAClick();

                FastDriver.WebDriver.HandleDialogMessage(true, true, 3);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        #endregion Test FMUC0027_REG0006        
        #region Test FMUC0027_REG0007

        [TestMethod]
        public void FMUC0027_REG0007()
        {
            try
            {
                Reports.TestDescription = "FM1109_78_79_19_33_77_47_44_FM956_57_58_ES10055_56_FM3605_16_FM3320_21_26_FM3325_ES7429_FM3247_E: Verifeing for the completion on IBA transaction(First_User).";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                Reports.TestStep = "Perform preview delivery.";
                FastDriver.PrintEscrowSetlleStmt.Method.FASelectItem("Preview");
                FastDriver.PrintEscrowSetlleStmt.Deliver.FAClick();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0027_REG0008

        [TestMethod]
        public void FMUC0027_REG0008()
        {

            try
            {
                Reports.TestDescription = "FM951_FM4922_FM1130_FM1142_FM3254_FM1133_FM3317: Checking for the fund Received check box Working fine in Escrow File Balance Summary screen and New Loan Screen.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            
                        } 
                    };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                {
                    new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                {                                    
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA",
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                } 
                            } 
                        } 
                };
                var Buyer1 = new BuyerSeller[] { 
                    new BuyerSeller()
                    {
                        FirstName = "",
                        LastName = "",
                        Type = ""
                    }
                };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                //Filling in Property Information
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Create Order.";
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Outside Title Company");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem("No Program Type");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5,000.00");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseFirstname");
                FastDriver.QuickFileEntry.Buyer2SpouseLastName.FASetText("Buyer2SpouseLastname");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseFirstname");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();

                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText("Notes Data including - * # Specialcharacter :) !");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Loan Instance and Enter charges Under Charges TAB.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                if (IsFormTypeCD())
                {
                    Reports.TestStep = "Verify the Buyer charge Field Disiabled in Payment Details Dialog.";
                    Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BuyerCharge.IsEnabled().ToString());

                }
                else 
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";

                }

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0027_REG0009

        [TestMethod]
        public void FMUC0027_REG0009()
        {

            try
            {
                Reports.TestDescription = "FM3606_FM3607_FM3608_FM3609: Validating the Message Issued Amount exceed Actual Amount aftre printing all checks and adding more charges.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            
                        } 
                    };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                {
                    new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                {                                    
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA",
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                } 
                            } 
                        } 
                };
                var Buyer1 = new BuyerSeller[] { 
                    new BuyerSeller()
                    {
                        FirstName = "",
                        LastName = "",
                        Type = ""
                    }
                };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                //Filling in Property Information
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Create Order.";
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Outside Title Company");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem("No Program Type");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5,000.00");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseFirstname");
                FastDriver.QuickFileEntry.Buyer2SpouseLastName.FASetText("Buyer2SpouseLastname");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseFirstname");
                FastDriver.QuickFileEntry.Seller2SpouseLastName.FASetText("Seller2SpouseLastname");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();

                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText("Notes Data including - * # Specialcharacter :) !");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify fields in Filehomepage for full sanity.";
                FastDriver.FileHomepage.GetUrl();
                FastDriver.FileHomepage.SwitchToContentFrame();

                Support.AreEqual("True", FastDriver.FileHomepage.ChangeOO.Displayed.ToString());
                Support.AreEqual("Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem().ToString());
                Support.AreEqual("5,000.00", FastDriver.FileHomepage.TermsDatesPrice.FAGetValue().Trim());
                Support.AreEqual("J305", FastDriver.FileHomepage.PropertyName.FAGetValue().Trim());
                Support.AreEqual("Single Family Residence", FastDriver.FileHomepage.PropertyType.FAGetSelectedItem().ToString());
                Support.AreEqual("Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetValue().Trim());
                Support.AreEqual("Block1", FastDriver.FileHomepage.PropertyBlock.FAGetValue().Trim());
                Support.AreEqual("Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetValue().Trim());
                Support.AreEqual("Prop1APN1", FastDriver.FileHomepage.PropertyPropTaxAPN1.FAGetValue().Trim());
                Support.AreEqual("9845012345", FastDriver.FileHomepage.PropertyPropTaxAPN2.FAGetValue().Trim());
                Support.AreEqual("J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Trim());
                Support.AreEqual("JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Trim());
                Support.AreEqual("JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Trim());
                Support.AreEqual("ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Trim());
                Support.AreEqual("CA", FastDriver.FileHomepage.PropertyState.FAGetSelectedItem().ToString());
                Support.AreEqual("ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetValue().Trim());
                Support.AreEqual("Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem().ToString());
                Support.AreEqual("Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Trim());
                Support.AreEqual("Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Trim());
                Support.AreEqual("Husband/Wife", FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem().ToString());
                Support.AreEqual("Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetValue().Trim());
                Support.AreEqual("Buyer2Lastname", FastDriver.FileHomepage.Buyer2LastName.FAGetValue().Trim());
                Support.AreEqual("True", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetValue().Trim().Contains("Buyer2SpouseFirstn").ToString());
                Support.AreEqual("True", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetValue().Trim().Contains("Buyer2SpouseLastn").ToString());
                Support.AreEqual("Seller1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Trim());
                Support.AreEqual("Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetValue().Trim());
                Support.AreEqual("Husband/Wife", FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem().ToString());
                Support.AreEqual("Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetValue().Trim());
                Support.AreEqual("Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetValue().Trim());
                Support.AreEqual("True", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetValue().Trim().Contains("Seller2SpouseFirstn").ToString());
                Support.AreEqual("True", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetValue().Trim().Contains("Seller2SpouseLastn").ToString());

                Reports.TestStep = "Create Loan Instance and Enter charges Under Charges TAB.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("3000");
                FastDriver.NewLoan.FindGABCode("247");

                Reports.TestStep = "Enter the Estimated settlement date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();

                FastDriver.TermsDatesStatus.EstimattedSettlementDate.FASetText("08-20-2012" + FAKeys.Tab);

                Reports.TestStep = "Validate Message on change the Estimated Date on TDS..";
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Prorate As of Date?", FastDriver.WebDriver.HandleDialogMessage(false, false));

                Reports.TestStep = "Validate Message on change the Estimated Date on TDS..";
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Funding Date for Loans?", FastDriver.WebDriver.HandleDialogMessage(true, false));

                Reports.TestStep = "Deposit cash";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Comments before Save");


                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnSave.FAClick();


                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 3);

                Reports.TestStep = "Deposit a cash more than sales price.";
                DepositCash("6000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Comments before Save");


                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnSave.FAClick();



                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(false, true, 3);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 3);




                Reports.TestStep = "Set an instance of Home warranty details.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty");

                FastDriver.HomeWarrantyDetail.GABcode.FASetText("HW1");
                FastDriver.HomeWarrantyDetail.Find.FAClick();

                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                if (IsFormTypeCD())
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");

                }
                else
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                }

                Reports.TestStep = "Click on Done";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                SetDefaultCheckPrinter();

                Reports.TestStep = "Print All checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();
                Reports.TestStep = "Perform Print";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                if (FastDriver.PasswordConfirmationDlg.ReasonForLoss.Displayed)
                {
                    Reports.TestStep = "Enter password confimation details dialog info.";
                    FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                    FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                    FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                


                FastDriver.WebDriver.WaitForDeliveryWindow();


                Reports.TestStep = "Navigate to Home Warranty screen & changing charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty");
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                if (IsFormTypeCD())
                {
                    Reports.TestStep = "Change the Charges on HomeWarrantyDetail screen.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("3.33");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("3.33");

                }
                else
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("3.33");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                

                Reports.TestStep = "Validate Message change Charges after Print the checks.";
                string value = FastDriver.WebDriver.HandleDialogMessage();
                string data = "A check has been issued for the previously entered charges.";
                Support.AreEqual("True", value.Contains(data).ToString());

                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                value = FastDriver.EscrowFileBalanceSummary.Thisfilecom8300isrequired.FAGetText();
                Support.AreEqual("# This file contains individual cash equivalent instruments in amounts of $10,000 or less, whose sum is in excess of $10,000.00. Please investigate whether form 8300 is required to be filed.", value);

                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        #endregion
        #region Test FMUC0027_REG0010

        [TestMethod]
        public void FMUC0027_REG0010()
        {

            try
            {
                Reports.TestDescription = "FM3256: Delivering Preview from File Balance summary screen after checking Received Check Box.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            
                        } 
                    };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                {
                    new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                {                                    
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA",
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                } 
                            } 
                        } 
                };
                var Buyer1 = new BuyerSeller[] { 
                    new BuyerSeller()
                    {
                        FirstName = "",
                        LastName = "",
                        Type = ""
                    }
                };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                //Filling in Property Information
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Create Order.";
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Outside Title Company");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem("No Program Type");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5,000.00");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseFirstname");
                FastDriver.QuickFileEntry.Buyer2SpouseLastName.FASetText("Buyer2SpouseLastname");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseFirstname");
                FastDriver.QuickFileEntry.Seller2SpouseLastName.FASetText("Seller2SpouseLastname");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();

                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText("Notes Data including - * # Specialcharacter :) !");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Loan Instance and Enter charges Under Charges TAB.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("3000");

                FastDriver.NewLoan.FindGABCode("247");


                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                if(IsFormTypeCD())
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BuyerCharge.IsEnabled().ToString());
                }
                else
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Set an instance of Home warranty details.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty");
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("HW1");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                if (IsFormTypeCD())
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");

                }
                else
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Set an instance.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association");
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("HOA2");
                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                if (IsFormTypeCD())
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");

                }
                else
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Set an instance of the Lease Details.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.SwitchToContentFrame();

                FastDriver.LeaseDetail.GABcode.FASetText("HOA2");
                FastDriver.LeaseDetail.Find.FAClick();

                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                if (IsFormTypeCD())
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");

                }
                else
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Print All Checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                if (FastDriver.PasswordConfirmationDlg.ReasonForLoss.Displayed)
                {
                    Reports.TestStep = "Enter password confimation details dialog info.";
                    FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                    FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                    FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);
                    FastDriver.DialogBottomFrame.ClickDone();
                }

                FastDriver.WebDriver.WaitForDeliveryWindow();

                Reports.TestStep = "Set an instance for Survey Details.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey");
                FastDriver.SurveyDetail.SwitchToContentFrame();

                FastDriver.SurveyDetail.GABcode.FASetText("247");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                if (IsFormTypeCD())
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");

                }
                else
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "");
                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage(true, false, 3);

                Reports.TestStep = "Set an instance of the Outside Escrow Company Detail.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company");
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText("HUDOUTESC1");
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("OEC");

                Reports.TestStep = "Click on Payment details and enter charges.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company");
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                if (IsFormTypeCD())
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");

                }
                else
                {
                    Reports.TestStep = "Enter charges in Payment Details Dialog.";
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                PreviewSettlementStatement(true);

                Reports.TestStep = "Check the Lender Amount Checkbox on FBS Screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                if (!(FastDriver.EscrowFileBalanceSummary.Recieved.IsSelected().ToString() == "True"))
                {
                    FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(true);
                    Thread.Sleep(5000);
                    FastDriver.EscrowFileBalanceSummary.Open();
                }

                Reports.TestStep = "Enter charges to New loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("300000000" + FAKeys.Tab);

                FastDriver.WebDriver.HandleDialogMessage(true, true, 3);

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.RecapTab.FAClick();


                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                PreviewSettlementStatement(true);



            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0027_REG0011

        [TestMethod]
        public void FMUC0027_REG0011()
        {

            try
            {
                Reports.TestDescription = "FM974_FM1114: Delivering Preview from Escrow File balance summary screen Contains Buyer Information.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            
                        } 
                    };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                {
                    new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                {                                    
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA",
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                } 
                            } 
                        } 
                };
                var Buyer1 = new BuyerSeller[] { 
                    new BuyerSeller()
                    {
                        FirstName = "",
                        LastName = "",
                        Type = ""
                    }
                };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                //Filling in Property Information
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Create Order.";
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Outside Title Company");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem("No Program Type");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5,000.00");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseFirstname");
                FastDriver.QuickFileEntry.Buyer2SpouseLastName.FASetText("Buyer2SpouseLastname");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseFirstname");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();

                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();

                FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText("Notes Data including - * # Specialcharacter :) !");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");

                Reports.TestStep = "Perform preview delivery.";
                FastDriver.PrintEscrowSetlleStmt.Method.FASelectItem("Preview");
                FastDriver.PrintEscrowSetlleStmt.Deliver.FAClick();


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0027_REG0012

        [TestMethod]
        public void FMUC0027_REG0012()
        {

            try
            {
                Reports.TestDescription = "FM3612_FM3613_FM3614_FM1122_FM1124_FM1126_FM1128_FM3252_FM3254_FM1137_FM3318_FM1122_FM3321: Re-label Refinance Transaction, No Seller Labels,Buyer Becomes Borrower,Buyer's seller's Funds Due,Buyer seller Held Funds.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            
                        } 
                    };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                {
                    new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                {                                    
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA",
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                } 
                            } 
                        } 
                };
                var Buyer1 = new BuyerSeller[] { 
                    new BuyerSeller()
                    {
                        FirstName = "",
                        LastName = "",
                        Type = ""
                    }
                };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                //Filling in Property Information
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Create Order.";
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Outside Title Company");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Refinance");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem("No Program Type");
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Get File No. From File Home Page.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.SwitchToContentFrame();

                Support.AreEqual("True", FastDriver.FileHomepage.ChangeOO.Displayed.ToString());

                Reports.TestStep = "Enter charges to New loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("300000000");
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                FastDriver.NewLoan.RecapTab.FAClick();

                Reports.TestStep = "Set an instance of Home warranty details and verifying that for refinance or loan transaction file type Buyer becomes Borrower and seller is not available.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty");
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                FastDriver.HomeWarrantyDetail.GABcode.FASetText("HW1");
                FastDriver.HomeWarrantyDetail.Find.FAClick();

                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("10.01");
                try
                {
                    Support.AreEqual("False", FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.Displayed.ToString());
                }
                catch (Exception ex2)
                {
                    Reports.Result(true);
                }
                

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Print All Checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                
                FastDriver.WebDriver.WaitForWindowAndSwitch("Overdraft Confirmation");                
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();

                FastDriver.WebDriver.WaitForDeliveryWindow();

                Reports.TestStep = "Create instance on lease and Verify that Buyer becomes Borrower and Seller is not available.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.SwitchToContentFrame();

                FastDriver.LeaseDetail.GABcode.FASetText("Lease");
                FastDriver.LeaseDetail.Find.FAClick();

                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.01");
                try
                {
                    Support.AreEqual("False", FastDriver.LeaseDetail.SellerCharge.Displayed.ToString());
                }
                catch (Exception ex2)
                {
                    Reports.Result(true);
                }
                
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");

                PreviewSettlementStatement();

                Reports.TestStep = "Check the Lender Amount Checkbox on FBS Screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(true);
                Thread.Sleep(5000);
                FastDriver.EscrowFileBalanceSummary.Open();
                Reports.TestStep = "Verify Fund Received Check box is on, as updated on File balance summary screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();
                string value = FastDriver.NewLoan.LoanDetailsFundsReceived.FAGetAttribute("Checked");


                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                PreviewSettlementStatement();


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region Test FMUC0027_REG0013_PH

        [TestMethod]
        public void FMUC0027_REG0013_PH()
        {

            try
            {
                Reports.TestDescription = "FM1115_FM962_FM1116_FM1191_FM1149_FM1150_FM1151_FM1192_FM1193_FM3318_FM3319_FM1148_FM960_FM1180: Cant Automate Please verify these BRs Manually as we have to verify in PDF.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                //Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            //Assert.AreEqual(true, Reports.TestResult, "TestSuccess:Refer Test Reports for Details");

        }
        #endregion Test
        #region Test FMUC0027_REG0014_PH

        [TestMethod]
        public void FMUC0027_REG0014_PH()
        {

            try
            {
                Reports.TestDescription = "FM1122_FM4956_FM1137_FM1128__FM3252_FM1138_FM1124_FM1126_FM3617_FM3603_FM1110_FM1141: Cant Automate Please verify these BRs Manually as we have to verify in PDF.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                //Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            //Assert.AreEqual(true, Reports.TestResult, "TestSuccess:Refer Test Reports for Details");

        }
        #endregion Test
        #region Test FMUC0027_REG0015_Prad_8_3

        [TestMethod]
        public void FMUC0027_REG0015_Prad_8_3()
        {

            try
            {
                Reports.TestDescription = "FM1128 : Compute Projected Balance for Transaction type Sale w/Mortgage.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            
                        } 
                    };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                {
                    new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                {                                    
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA",
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                } 
                            } 
                        } 
                };
                var Buyer1 = new BuyerSeller[] { 
                    new BuyerSeller()
                    {
                        FirstName = "",
                        LastName = "",
                        Type = ""
                    }
                };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify Net Check,Actual File Balance,Project File Balance.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());

                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected Loan Funding: $ 0.00").ToString());
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected File Balance: $ 0.00").ToString());

                Reports.TestStep = "Create instance and enter new loan amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("500");
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validate the data in Escrow File Balance Summary.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                Support.AreEqual("500.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                Support.AreEqual("500.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());
                Support.AreEqual("500.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());

                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected Loan Funding: $ 500.00").ToString());
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Funds Deposited with OTC: $ 0.00").ToString());

                Reports.TestStep = "Set Received check Box and verify Projected File Balance.";
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                Support.AreEqual("500.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                Support.AreEqual("500.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());
                
                FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(true);
                Thread.Sleep(5000);
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual("500.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());
                Support.AreEqual(true, FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected Loan Funding: $ 0.00"), "Projected Loan Funding: $ 0.00");
                Support.AreEqual(true, FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Funds Deposited with OTC: $ 0.00"), "Funds Deposited with OTC: $ 0.00");

                Reports.TestStep = "Enter Charges Retained by Outside Title Co.";
                FastDriver.LeftNavigation.Navigate<OTCDetail>("Home>Order Entry>Outside Title Company");
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.GABcode.FASetText("Hudflinsr1");
                FastDriver.OTCDetail.Find.FAClick();
                FastDriver.OTCDetail.ChargesRetained.FASetText("35.00");
                FastDriver.OTCDetail.Type.FASelectItem("Outside Title Company");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Verify File Balance Summary after entering amount to OTC.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                Support.AreEqual("500.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                Support.AreEqual("500.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());

                FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(false);
                Thread.Sleep(5000);
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual("500.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected Loan Funding: $ 500.00").ToString(), "Projected Loan Funding: $ 500.00");
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Funds Deposited with OTC: $ 35.00-").ToString(), "Funds Deposited with OTC: $ 35.00-");
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected File Balance: $ 35.00-").ToString(), "Projected File Balance: $ 35.00-");


        
                #region Test FMUC0027_REG0016_Prad_8_3

                        Reports.TestDescription = "FM1128 : Compute Projected Balance for Transaction type Sale w/Mortgage.";
                
                        Reports.TestStep = "Create  Buyers (Selling) Broker instance.";
                        FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                        FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                        FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();

                        FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                        FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                        FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                        FastDriver.BottomFrame.Done();

                        Reports.TestStep = "Create  Sellers (Listing) Broker instance.";
                        FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                        FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                        FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                        FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                        FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                        FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                        FastDriver.BottomFrame.Done();

                        Reports.TestStep = "Enter Earnest Money amount and Earnest money distribution equally for Buyer Broker and seller Broker.";
                        FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                        FastDriver.DepositOutsideEscrow.SwitchToContentFrame();

                        FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("60.00");
                        FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Seller's Broker");
                        Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testi", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetText());
                        FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("40.00");
                        FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem("Buyer's Broker");
                        Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetText());
                        FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText("20.00");

                        FastDriver.BottomFrame.Save();
                
                        Reports.TestStep = "Enter Commission amount and verify the earnest amount excess.";
                        FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                        FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                        FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                        FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                        FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("20.00" + FAKeys.Tab);

                        Support.AreEqual("20.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetAttribute("value"));
                        FastDriver.BottomFrame.Done();

                        Reports.TestStep = "Enter Commission amount and verify the earnest amount excess.";
                        FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                        FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                        FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                        FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                        FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("20.00" + FAKeys.Tab);

                        Support.AreEqual("20.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetAttribute("value"));
                        FastDriver.BottomFrame.Done();

                        Reports.TestStep = "Verify for Seller's Funds Due,Listing Broker's Funds Due,Selling Broker's Funds Due.";
                        FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                        FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                        Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                        Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());

                        FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(false);
                        Thread.Sleep(5000);
                        FastDriver.EscrowFileBalanceSummary.Open();
                        Support.AreEqual("560.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Seller's Funds Due: $ 20.00").ToString());
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Listing Broker's Funds Due: $ 20.00").ToString());
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Selling Broker's Funds Due: $ 20.00").ToString());

                        Reports.TestStep = "Verify for Project File Balance.";
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                        Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                        Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());

                        FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(true);
                        Thread.Sleep(5000);
                        FastDriver.EscrowFileBalanceSummary.Open();
                        Support.AreEqual("560.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Seller's Funds Due: $ 20.00").ToString());
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Listing Broker's Funds Due: $ 20.00").ToString());
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected File Balance: $ 500.00").ToString());

                        Reports.TestStep = "Enter Buyer Charge";
                        FastDriver.LeftNavigation.Navigate<OTCDetail>("Home>Order Entry>Outside Title Company");
                        FastDriver.OTCDetail.SwitchToContentFrame();
                        FastDriver.OTCDetail.ChargesRetained.FASetText("580.00");
                        FastDriver.BottomFrame.Done();

                        Reports.TestStep = "Verify Buyer Seller Fund Due.";
                        FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                        FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                        Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                        Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());

                        FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(false);
                        Thread.Sleep(5000);
                        FastDriver.EscrowFileBalanceSummary.Open();
                        Support.AreEqual("560.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Buyer's Funds Due: $ 0.00").ToString());
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Listing Broker's Funds Due: $ 20.00").ToString());
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected File Balance: $ 580.00").ToString());

                #endregion
                #region Test FMUC0027_REG0017_Prad_8_3
                Reports.TestDescription = "FM1128 : Compute Projected Balance for Transaction type Sale w/Mortgage.";
                Reports.TestStep = "Enter Commission amount and verify the earnest amount excess.";

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("10.00" + FAKeys.Tab);

                Support.AreEqual("30.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetAttribute("value"));

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Other Broker Funds Due and Projected File Balance.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());

                FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(false);
                Thread.Sleep(5000);
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual("560.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Other RE Broker's Funds Due: $ 0.00").ToString());
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Listing Broker's Funds Due: $ 30.00").ToString());
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected File Balance: $ 580.00").ToString());

                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }



        [TestMethod]
        [Description("This test case has been combined with FMUC0027_REG0015_Prad_8_3")]
        public void FMUC0027_REG0016_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0027_REG0015_Prad_8_3";
                Reports.TestStep = "See test case FMUC0027_REG0015_Prad_8_3.";
                Reports.StatusUpdate("See test case FMUC0027_REG0015_Prad_8_3.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        [Description("This test case has been combined with FMUC0027_REG0015_Prad_8_3")]
        public void FMUC0027_REG0017_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0027_REG0015_Prad_8_3";
                Reports.TestStep = "See test case FMUC0027_REG0015_Prad_8_3.";
                Reports.StatusUpdate("See test case FMUC0027_REG0015_Prad_8_3.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion
        #region Test FMUC0027_REG0018_Prad_8_3

        [TestMethod]
        public void FMUC0027_REG0018_Prad_8_3()
        {
            try
            {

                Reports.TestDescription = "FM1128 : Compute Projected Balance for Transaction type Refinance.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                        {
                            new FileBusinessParty()
                            {
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("249"),
                                RoleTypeObjectCD = "BUSSOURCE",
                            
                            } 
                        };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                    {
                        new Property() 
                            {
                                PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                                {
                                    new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                    {                                    
                                        State = "CA", 
                                        City = "ALBANY", 
                                        County = "ALAMEDA", 
                                        Country = "USA",
                                        AddrLine1 = "J305",
                                        AddrLine2 = "JJEJAMQ",
                                        AddrLine3 = "JJEJAMQ",
                                    } 
                                } 
                            } 
                    };
                var Buyer1 = new BuyerSeller[] { 
                        new BuyerSeller()
                        {
                            FirstName = "",
                            LastName = "",
                            Type = ""
                        }
                    };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Create Order.";
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("249");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Refinance");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem("No Program Type");
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");

                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");

                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Verify Net Check,Actual File Balance,Project File Balance.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());

                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected Loan Funding: $ 0.00").ToString());
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected File Balance: $ 0.00").ToString());

                Reports.TestStep = "Create instance and enter new loan amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("500");
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the data in Escrow File Balance Summary.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                Support.AreEqual("500.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                Support.AreEqual("500.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());
                Support.AreEqual("500.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());

                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected Loan Funding: $ 500.00").ToString(), "Projected Loan Funding: $ 500.00");
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Funds Deposited with OTC: $ 0.00").ToString(), "Funds Deposited with OTC: $ 0.00");

                Reports.TestStep = "Set Received check Box and verify Projected File Balance.";
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                Support.AreEqual("500.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                Support.AreEqual("500.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());
                FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(true);
                Thread.Sleep(5000);
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual("500.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected Loan Funding: $ 0.00").ToString(), "Projected Loan Funding: $ 0.00");
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Funds Deposited with OTC: $ 0.00").ToString(), "Funds Deposited with OTC: $ 0.00");

                Reports.TestStep = "Enter Charges Retained by Outside Title Co.";
                FastDriver.LeftNavigation.Navigate<OTCDetail>("Home>Order Entry>Outside Title Company");
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.GABcode.FASetText("Hudflinsr1");
                FastDriver.OTCDetail.Find.FAClick();
                FastDriver.OTCDetail.ChargesRetained.FASetText("35.00");
                FastDriver.OTCDetail.Type.FASelectItem("Outside Title Company");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify File Balance Summary after entering amount to OTC.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                Support.AreEqual("500.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                Support.AreEqual("500.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());

                FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(false);
                Thread.Sleep(5000);
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual("500.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());
            



                #region Test FMUC0027_REG0019_Prad_8_3


                    try
                    {
                        Reports.TestDescription = "FM1128 : Compute Projected Balance for Transaction type Refinance.";
                        FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                        FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                        FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "New", 2, TableAction.Click);
                        FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                        FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                        FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                        FastDriver.BottomFrame.Done();

                        Reports.TestStep = "Create  Sellers (Listing) Broker instance.";
                        FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                        FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                        FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                        FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                        FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                        FastDriver.BottomFrame.Done();

                        Reports.TestStep = "Create  Buyer (Selling) Broker instance.";
                        FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                        FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                        FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();

                        FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                        FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                        FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                        FastDriver.BottomFrame.Done();

                        Reports.TestStep = "Enter Earnest Money amount and Earnest money distribution equally for Buyer Broker and seller Broker.";
                        FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                        FastDriver.DepositOutsideEscrow.SwitchToContentFrame();

                        FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("60.00");
                        FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Seller's Broker");
                        Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testi", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetText());
                        FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("30.00");
                        FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem("Buyer's Broker");
                        Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetText());
                        FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText("30.00");

                        FastDriver.BottomFrame.Save();


                        Reports.TestStep = "Verify for Seller's Funds Due,Listing Broker's Funds Due,Selling Broker's Funds Due.";
                        FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                        FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                        Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                        Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());

                        if (!(FastDriver.EscrowFileBalanceSummary.Recieved.IsSelected()))
                        {
                            FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(true);
                            Thread.Sleep(5000);
                            FastDriver.EscrowFileBalanceSummary.Open();
                        }                        

                        Support.AreEqual("560.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());

                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Listing Broker's Funds Due: $ 30.00").ToString(), "Listing Broker's Funds Due: $ 30.00");
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Selling Broker's Funds Due: $ 30.00").ToString(), "Selling Broker's Funds Due: $ 30.00");

                        Reports.TestStep = "Verify for Project File Balance for Refinance File.";
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                        Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                        Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());

                        if (!(FastDriver.EscrowFileBalanceSummary.Recieved.IsSelected()))
                        {
                            FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(true);
                            Thread.Sleep(5000);
                            FastDriver.EscrowFileBalanceSummary.Open();
                        }  

                        Support.AreEqual("560.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());

                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Listing Broker's Funds Due: $ 30.00").ToString(), "Listing Broker's Funds Due: $ 30.00");
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected File Balance: $ 440.00-").ToString(), "Projected File Balance: $ 440.00-");

                        Reports.TestStep = "Enter Buyer Charge";
                        FastDriver.LeftNavigation.Navigate<OTCDetail>("Home>Order Entry>Outside Title Company");
                        FastDriver.OTCDetail.SwitchToContentFrame();
                        FastDriver.OTCDetail.ChargesRetained.FASetText("580.00");
                        FastDriver.BottomFrame.Done();

                        Reports.TestStep = "Verify Brokers Fund Due Fund Due.";
                        FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                        FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                        Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                        Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                        Support.AreEqual("560.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());

                        if (!(FastDriver.EscrowFileBalanceSummary.Recieved.IsSelected()))
                        {
                            FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(true);
                            Thread.Sleep(5000);
                            FastDriver.EscrowFileBalanceSummary.Open();
                        }

                        Support.AreEqual("560.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Borrower's Funds Due $ 0.00").ToString(), "Borrower's Funds Due $ 0.00");
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Listing Broker's Funds Due: $ 30.00").ToString(), "Listing Broker's Funds Due: $ 30.00");
                        Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected File Balance: $ 440.00-").ToString(), "Projected File Balance: $ 440.00-");

                    }
                    catch (Exception ex)
                    {
                        Support.Fail(ex.Message);
                    }

                #endregion
                #region Test FMUC0027_REG0020_Prad_8_3

                    Reports.TestDescription = "FM1128 : Compute Projected Balance for Transaction type Refinance.";
                    Reports.TestStep = "Enter Buyer Seller charge for Other RE Broker.";
                    FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                    FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                    FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryNew.FAClick();
                    FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                    FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                    FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("10.00");
                    if (!(FastDriver.RealEstateBrokerAgent.CreditSellerBroker.IsSelected()))
                    {
                        FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                    }
                    FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText("20.00");

                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Verify Other Broker Funds Due and Projected File Balance for Refinance File.";
                    FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                    FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                    Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                    Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText());
                    Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText());
                    Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText());
                    Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                    Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                    Support.AreEqual("550.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText());
                    Support.AreEqual("550.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());

                    if (!(FastDriver.EscrowFileBalanceSummary.Recieved.IsSelected()))
                    {
                        FastDriver.EscrowFileBalanceSummary.Recieved.FASetCheckbox(true);
                        Thread.Sleep(5000);
                        FastDriver.EscrowFileBalanceSummary.Open();
                    }

                    Support.AreEqual("550.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText());
                    Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Other RE Broker's Funds Due: $ 10.00").ToString());
                    Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Listing Broker's Funds Due: $ 10.00").ToString());
                    Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected File Balance: $ 440.00-").ToString());
                    #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        [Description("This test case has been combined with FMUC0027_REG0018_Prad_8_3")]
        public void FMUC0027_REG0019_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0027_REG0018_Prad_8_3";
                Reports.TestStep = "See test case FMUC0027_REG0018_Prad_8_3.";
                Reports.StatusUpdate("See test case FMUC0027_REG0018_Prad_8_3.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        [TestMethod]
        [Description("This test case has been combined with FMUC0027_REG0018_Prad_8_3")]
        public void FMUC0027_REG0020_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0027_REG0018_Prad_8_3";
                Reports.TestStep = "See test case FMUC0027_REG0018_Prad_8_3.";
                Reports.StatusUpdate("See test case FMUC0027_REG0018_Prad_8_3.", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion
        #region Test FMUC0027_REG0021_Prad_8_3
        [TestMethod]
        public void FMUC0027_REG0021_Prad_8_3()
        {

            try
            {
                Reports.TestDescription = "FMXXXX :Selling Broker’s Funds Due.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            
                        } 
                    };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                {
                    new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                {                                    
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA",
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                } 
                            } 
                        } 
                };
                var Buyer1 = new BuyerSeller[] { 
                    new BuyerSeller()
                    {
                        FirstName = "",
                        LastName = "",
                        Type = ""
                    }
                };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Create Order.";
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Outside Title Company");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Refinance");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem("No Program Type");
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create  Buyers (Selling) Broker instance.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();

                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Commission Amount and verify Net Check Amount.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 1, TableAction.Click);
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("30.00" + FAKeys.Tab);

                Support.AreEqual("30.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify that when Net Check Amount is zero or positive number then no amount is displayed in the Listing Broker’s Funds Due.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                string value = FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText();
                Support.AreEqual("True", value.Contains("Listing Broker's Funds Due: $ 0.00").ToString());

                Reports.TestStep = "Enter Earnest Money Amount and Buyer's  Broker earnest Money Deposit.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                FastDriver.DepositOutsideEscrow.SwitchToContentFrame();

                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("60.00");
                value = FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue();
                Support.AreEqual("60.00", value);
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Buyer's Broker");

                value = FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetValue();
                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", value);

                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("60.00");

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify net check Amount is Negative value.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 1, TableAction.Click);
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                
                Support.AreEqual("-30.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify that when Net Check Amount is Negative non zero then net check amount is displayed in the Selling Broker’s Funds Due.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                value = FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText();
                Support.AreEqual("True", value.Contains("Selling Broker's Funds Due: $ 30.00").ToString());



            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        #endregion
        #region Test FMUC0027_REG0022_Prad_8_3

        [TestMethod]
        public void FMUC0027_REG0022_Prad_8_3()
        {

            try
            {
                Reports.TestDescription = "FMXXXX :Listing Broker’s Funds Due.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            
                        } 
                    };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                {
                    new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                {                                    
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA",
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                } 
                            } 
                        } 
                };
                var Buyer1 = new BuyerSeller[] { 
                    new BuyerSeller()
                    {
                        FirstName = "",
                        LastName = "",
                        Type = ""
                    }
                };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Create Order.";
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Outside Title Company");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Refinance");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem("No Program Type");
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");

                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create  Sellers (Listing) Broker instance.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();

                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Commission Amount and verify Net Check Amount.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 1, TableAction.Click);
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("30.00" + FAKeys.Tab);

                Support.AreEqual("30.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify that when Net Check Amount is zero or positive number then no amount is displayed in the Listing Broker’s Funds Due.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                string value = FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText();
                Support.AreEqual("True", value.Contains("Listing Broker's Funds Due: $ 0.00").ToString());

                Reports.TestStep = "Enter Earnest Money Amount and Seller's  Broker earnest Money Deposit.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                FastDriver.DepositOutsideEscrow.SwitchToContentFrame();

                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("60.00");
                value = FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue();
                Support.AreEqual("60.00", value);
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Seller's Broker");

                value = FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetValue();
                Support.AreEqual("Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testi", value);

                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("60.00");

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify net check Amount is Negative value.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 1, TableAction.Click);
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();

                Support.AreEqual("-30.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify that when Net Check Amount is Negative non zero then net check amount is displayed in the Listing Broker’s Funds Due.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                value = FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText();
                Support.AreEqual("True", value.Contains("Listing Broker's Funds Due: $ 30.00").ToString());


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion
        #region Test FMUC0027_REG0023_Prad_8_3

        [TestMethod]
        public void FMUC0027_REG0023_Prad_8_3()
        {

            try
            {
                Reports.TestDescription = "FMXXXX :Other RE Broker’s Funds Due.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            
                        } 
                    };
                defaultRequest.File.BusinessParties = BusinessParties;
                var Property = new Property[]
                {
                    new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                {                                    
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA",
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                } 
                            } 
                        } 
                };
                var Buyer1 = new BuyerSeller[] { 
                    new BuyerSeller()
                    {
                        FirstName = "",
                        LastName = "",
                        Type = ""
                    }
                };

                defaultRequest.File.Properties = Property;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();

                Reports.TestStep = "Create Order.";
                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem("Outside Title Company");
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Refinance");
                FastDriver.QuickFileEntry.ProgramType.FASelectItem("No Program Type");
                FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);

                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");

                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Instance for Other Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();

                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Commission Amount and verify Net Check Amount for Other Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 1, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("30.00" + FAKeys.Tab);

                Support.AreEqual("30.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify that when Net Check Amount is zero or positive number then no amount is displayed in the Listing Broker’s Funds Due.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                string value = FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText();
                Support.AreEqual("True", value.Contains("Listing Broker's Funds Due: $ 0.00").ToString());

                Reports.TestStep = "Enter Buyer Seller charge for Other RE Broker and verify negative net check amount..";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>("Home>Order Entry>Real Estate Broker/Agent");
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(2, "Flood Insurance 1 for HUD Testing Name 1", 1, TableAction.Click);

                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();

                if(!(FastDriver.RealEstateBrokerAgent.CreditSellerBroker.IsSelected()))
                {
                    FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                }
                                
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText("60.00" + FAKeys.Tab);

                Support.AreEqual("-30.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify that when Net Check Amount is Negative non zero then net check amount is displayed in the Other Broker’s Funds Due.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();

                value = FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText();
                Support.AreEqual("True", value.Contains("Other RE Broker's Funds Due: $ 30.00").ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion
        #region Test FMUC0027_REG0024_Prad_8_3_PH

        [TestMethod]
        public void FMUC0027_REG0024_Prad_8_3_PH()
        {

            try
            {
                Reports.TestDescription = "Field_Defination : Please Preview the PDF and verify the Field Defination manually.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                //Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            //Assert.AreEqual(true, Reports.TestResult, "TestSuccess:Refer Test Reports for Details");

        }
        #endregion Test

        #endregion Test


        #region PRIVATE METHODS
        public void SetDefaultCheckPrinter()
        {
            Reports.TestStep = "Set default check printer";
            FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
            FastDriver.PrinterConfiguration.SetDefaultPrinter();
        }

        private static void EnterFeeInTitleEscrowTab()
        {
            Reports.TestStep = "Enter first fee in Title and escrow.";
            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry");
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.NewHomeRateTitleOnly.FASetCheckbox(true);
            FastDriver.FileFees.NewHomeRateBuyerCharge.FASetText("1.99");
            FastDriver.FileFees.NewHomeRateSellerCharge.FASetText("2.99");

            //string value  = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, "New Home Rate (Tile Only)", 1, TableAction.GetInputValue).Message.ToString();

        }
        private static void PreviewSettlementStatement(bool ClosePreviewWindow = false)
        { 
            Reports.TestStep = "Perform preview delivery.";
            FastDriver.PrintEscrowSetlleStmt.Method.FASelectItem("Preview");
            FastDriver.PrintEscrowSetlleStmt.Deliver.FAClick();

            if (ClosePreviewWindow) {
                FastDriver.WebDriver.WaitForDeliveryWindow();
                FastDriver.WebDriver.ClosePreviewWindow();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            }
        }
        private static void DepositCash(string Amount, string TypeOfFund, string Representing, string Description, string RecievingFrom, string Payor, string Comment=null)
        {
            Reports.TestStep = "Deposit cash.";
            FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
            FastDriver.DepositInEscrow.SwitchToContentFrame();

            FastDriver.DepositInEscrow.Amount.FASetText(Amount);
            FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(TypeOfFund);
            FastDriver.DepositInEscrow.Representing.FASelectItem(Representing);
            FastDriver.DepositInEscrow.Description.FASetText(Description);
            FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(RecievingFrom);
            FastDriver.DepositInEscrow.Comment.FASetText(Comment);

        }
        private static void setUniversalDate()
        {
            string cDate = string.Empty;
            cDate = DateTime.Now.ToUniversalTime().AddHours(-12.5).ToDateString();

            FastDriver.TermsDatesStatus.Open();
            FastDriver.TermsDatesStatus.SwitchToContentFrame();

            if(!cDate.Equals(FastDriver.TermsDatesStatus.StatusDate.FAGetAttribute("value")))
            {
                FastDriver.TermsDatesStatus.StatusDate.FASetText(cDate);
            }
        }
        private bool IsFormTypeCD()
        {
            return AutoConfig.FormType.ToUpper() == "CD";
        }
        private OrderDetailsResponse _CreateFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD:FormType.HUD;
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.SalesPriceAmount = 5000;
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        } 
                };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File;
        }

        private void _IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void _ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);

        }

        private bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }
     
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}