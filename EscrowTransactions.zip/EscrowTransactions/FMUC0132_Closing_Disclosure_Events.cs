﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using System.Threading;
using FASTWCFHelpers.FastFileService;
using System.Collections.Generic;


namespace EscrowTransactions 
{
    [CodedUITest]
    public class FMUC0132 : FASTHelpers
    {
        #region Dependency
        //If script is failing for start and completion time then change machine's time zone to UTC (without daylight  saving) and re-execute the test cases for this usecase
        //to check any other failure.
        //Refer Bug #834926" for more details.
        #endregion
        #region BAT
        #region Test FMUC0132_BAT0001
        [TestMethod]
        public void FMUC0132_BAT0001()
        {
            try
            {
                Reports.TestDescription = "System shall display events related to CD Delivery - Print/Preview Delivery";
                Reports.TestStep = "Log into FAST application."; 
                IISLOGIN();
                Reports.TestStep = "Create new file with sales amount.";
                Dictionary<string,int> FileData= CreateFile();
                string FileNumber = FileData["FileNumber"].ToString() ;
                Reports.TestStep = "Go to closing disclosure and open cd events dlg.";
                FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                Reports.TestStep = "Validate CD Events Category.";
                FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                string CDEvents=FastDriver.ClosingDisclosureEventsLog.CDEventsCategory.FAGetAllTextFromSelect();
                Support.AreEqualTrim("True", CDEvents.Contains("ALL").ToString());
                Support.AreEqualTrim("True", CDEvents.Contains("CD Delivery").ToString());
                Support.AreEqualTrim("True", CDEvents.Contains("Lender Updates to CD").ToString());
                FastDriver.ClosingDisclosureEventsLog.CloseCDEventsDlg();
                Reports.TestStep = "Enter data in projected payments.";
                FastDriver.ClosingDisclosure.Open();
                EnterDataInProjectedPayments();
                //
                Reports.TestStep = "Perform print delivery";
                Dictionary<string, DateTime> DeliveryTime = PerformDeliveryInCD("Print");
                FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                Reports.TestStep = "Validate CD Event Log";
                FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("[Print]").ToString());
                
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateSourceForEvent("[Print]", "Print Service").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateStartDateForEvent("[Print]", DeliveryTime["StartTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateCompletionDateForEvent("[Print]", DeliveryTime["CompletionTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateUserNameForEvent("[Print]", "FAST QA07").ToString());
                string Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent("[Print]");
                Support.AreEqualTrim("True", Comment.Contains(FileNumber).ToString());
                Support.AreEqualTrim("True", Comment.Contains("Delivery Successful").ToString());
                FastDriver.ClosingDisclosureEventsLog.CloseCDEventsDlg();
                Reports.TestStep = "Perform Preview delivery";
                DeliveryTime=PerformDeliveryInCD("Preview");
                FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                //
                Reports.TestStep = "Validate CD Event Log";
                FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                string Event = "[Print Preview]";
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent(Event).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateSourceForEvent(Event, "Print Service").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateStartDateForEvent(Event, DeliveryTime["StartTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateCompletionDateForEvent(Event, DeliveryTime["CompletionTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateUserNameForEvent(Event, "FAST QA07").ToString());
                Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent(Event);
                Support.AreEqualTrim("True", Comment.Contains(FileNumber).ToString());
                Support.AreEqualTrim("True", Comment.Contains("Delivery Successful").ToString());
                FastDriver.ClosingDisclosureEventsLog.CloseCDEventsDlg();
            }
            catch(Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Test
        #region Test FMUC0132_BAT0002
        [TestMethod]
        public void FMUC0132_BAT0002()
        {
            try
            {
                Reports.TestDescription = "System shall display events related to CD Delivery - ImageDoc Delivery";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create new file.";
                Dictionary<string, int> FileData = CreateFile();
                string FileNumber = FileData["FileNumber"].ToString();
                Reports.TestStep = "Go to closing disclosure.";
                FastDriver.ClosingDisclosure.Open();
                Reports.TestStep = "Enter data in projected payments.";
                EnterDataInProjectedPayments();
                Reports.TestStep = "Perform Image delivery";
                Dictionary<string, DateTime> DeliveryTime = new Dictionary<string, DateTime>();
                DeliveryTime=PerformDeliveryInCD("Imagedoc");
                //
                Reports.TestStep = "Open CD Event Log";
                FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                Reports.TestStep = "Validate CD Event Log";
                FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                string Event = "[ImageDoc]";
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent(Event).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateSourceForEvent(Event, "ImageDoc Service").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateStartDateForEvent(Event, DeliveryTime["StartTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateCompletionDateForEvent(Event, DeliveryTime["CompletionTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateUserNameForEvent(Event, "FAST QA07").ToString());
                string Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent(Event);
                Support.AreEqualTrim("True", Comment.Contains(FileNumber).ToString());
                Support.AreEqualTrim("True", ValidateDeliveryStatus(Event, "ImageDoc Successful").ToString());
                FastDriver.ClosingDisclosureEventsLog.CloseCDEventsDlg();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        //
        #endregion Test
        #region Test FMUC0132_BAT0003
        [TestMethod]
        public void FMUC0132_BAT0003()
        {
            try
            {
                Reports.TestDescription = "System shall display events related to CD Delivery - Email and Fax Delivery";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create new file.";
                Dictionary<string, int> FileData = CreateFile();
                string FileNumber = FileData["FileNumber"].ToString();
                Reports.TestStep = "Go to closing disclosure.";
                FastDriver.ClosingDisclosure.Open();
                Reports.TestStep = "Enter data in projected payments.";
                EnterDataInProjectedPayments();
                Reports.TestStep = "Perform Email delivery";
                Dictionary<string, DateTime> DeliveryTime = new Dictionary<string, DateTime>();
                DeliveryTime =PerformDeliveryInCD("Email");
                Reports.TestStep = "Open CD Event Log";
                FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                Reports.TestStep = "Validate CD Event Log";
                FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("[E-mail]").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateSourceForEvent("[E-mail]", "Email Service").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateStartDateForEvent("[E-mail]", DeliveryTime["StartTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateCompletionDateForEvent("[E-mail]", DeliveryTime["CompletionTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateUserNameForEvent("[E-mail]", "FAST QA07").ToString());
                string Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent("[E-mail]");
                Support.AreEqualTrim("True", Comment.Contains(FileNumber).ToString());
                Support.AreEqualTrim("True", ValidateDeliveryStatus("[E-mail]").ToString());
                FastDriver.ClosingDisclosureEventsLog.CloseCDEventsDlg();
                Reports.TestStep = "Perform Email delivery";
                DeliveryTime=PerformDeliveryInCD("Fax");
                Reports.TestStep = "Open CD Event Log";
                FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                Reports.TestStep = "Validate CD Event Log";
                FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("[Fax]").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateSourceForEvent("[Fax]", "Fax Service").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateStartDateForEvent("[Fax]", DeliveryTime["StartTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateCompletionDateForEvent("[Fax]", DeliveryTime["CompletionTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateUserNameForEvent("[Fax]", "FAST QA07").ToString());
                Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent("[Fax]");
                Support.AreEqualTrim("True", Comment.Contains(FileNumber).ToString());
                Support.AreEqualTrim("True", ValidateDeliveryStatus("[Fax]").ToString());
                FastDriver.ClosingDisclosureEventsLog.CloseCDEventsDlg();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion Test
        #endregion
        #region REG
        #region Test FMUC0132_REG0001
        [TestMethod]
        public void FMUC0132_REG0001()
        {
            try
            {
                Reports.TestDescription = "System will display events according to event categories in the drop down";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create new file.";
                Dictionary<string, int> FileData = CreateFile();
                string FileNumber = FileData["FileNumber"].ToString();
                int FileId = FileData["FileId"];
                Reports.TestStep = "Go to closing disclosure.";
                FastDriver.ClosingDisclosure.Open();
                Reports.TestStep = "Enter data in projected payments.";
                EnterDataInProjectedPayments();
                Reports.TestStep = "Perform print delivery";
                PerformDeliveryInCD("Print");
                //
                Reports.TestStep = "Go to closing disclosure.";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.tabClosingDisclosure.FAClick();
                FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                Reports.TestStep = "Mismo posting";
                FASTWCFHelpers.FastClosingDisclosureService.OperationResponse Response = LenderUpdatesSingleWindow.MISMOPosting(FileId);
                string ReqId = Response.StatusDescription.Split('-')[1].Replace("QCStagingID:", " ").Trim();
                //
                Reports.TestStep = "Open CD Event Log";
                FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                Reports.TestStep = "Validate that default event category is ALL and displays both the events";
                Support.AreEqualTrim("True",FastDriver.ClosingDisclosureEventsLog.CDEventsCategory.FAGetSelectedItem().Equals("ALL").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("Lender Updates to CD Received").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("[Print]").ToString());
                Reports.TestStep = "Validate that the latest event is displayed first";
                Support.AreEqualTrim("True",ValidateCDEventSortOrder().ToString());
                Reports.TestStep = "Select CD delivery in drop down and validate log";
                FastDriver.ClosingDisclosureEventsLog.CDEventsCategory.FASelectItem("CD Delivery");
                FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("[Print]").ToString());
                Support.AreEqualTrim("False", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("Lender Updates to CD Received").ToString());
                Reports.TestStep = "Select Lender Updates to CD in drop down and validate log";
                FastDriver.ClosingDisclosureEventsLog.CDEventsCategory.FASelectItem("Lender Updates to CD");
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("Lender Updates to CD Received").ToString());
                Support.AreEqualTrim("False", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("[Print]").ToString());
                FastDriver.ClosingDisclosureEventsLog.CloseCDEventsDlg();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0132_REG0002
        [TestMethod]
        public void FMUC0132_REG0002()
        {
            try
            {
                Reports.TestDescription = "System shall display events from Lender Updates to CD-Lender Updates to CD Received";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create new file.";
                Dictionary<string, int> FileData = CreateFile();
                string FileNumber = FileData["FileNumber"].ToString();
                int FileId = FileData["FileId"];
                Reports.TestStep = "Go to closing disclosure.";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.tabClosingDisclosure.FAClick();
                FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                Reports.TestStep = "Enter data in projected payments.";
                string MortgageInsurance = "1001";
                string EstimatedTaxesInsuranceAssessments = "2001";
                EnterDataInProjectedPayments(MortgageInsurance, EstimatedTaxesInsuranceAssessments);

                Reports.TestStep = "Mismo posting";
                Dictionary<string, DateTime> DeliveryTime = new Dictionary<string, DateTime>();
                DeliveryTime["StartTime"] = DateTime.Now;
                FASTWCFHelpers.FastClosingDisclosureService.OperationResponse Response=  LenderUpdatesSingleWindow.MISMOPosting(FileId);
                DeliveryTime["CompletionTime"] = DateTime.Now;
                string ReqId = Response.StatusDescription.Split('-')[1].Replace("QCStagingID:", " ").Trim();
                Reports.TestStep = "Go to closing disclosure events log.";
                FastDriver.ClosingDisclosure.Open();
                Reports.TestStep = "Open CD Event Log";
                FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                Reports.TestStep = "Validate CD Event Log";
                FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("Lender Updates to CD Received").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateSourceForEvent("Lender Updates to CD Received", "FAST").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateStartDateForEvent("Lender Updates to CD Received", DeliveryTime["StartTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateCompletionDateForEvent("Lender Updates to CD Received", DeliveryTime["CompletionTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateUserNameForEvent("Lender Updates to CD Received", "FAST").ToString());
                string Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent("Lender Updates to CD Received");
                Support.AreEqualTrim("True", Comment.Contains(ReqId).ToString());
                Support.AreEqualTrim("True", Comment.Contains("Lender Updates to Closing Disclosure received successfully.").ToString());
                Reports.TestStep = "Display PDF icon on Lender Updates to CD Received event.";
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidatePDFIconForLenderUpdateReceived("Lender Updates to CD Received").ToString());
                //
                Reports.TestStep = "Lender provided CD Data in PDF";
                FastDriver.ClosingDisclosureEventsLog.OpenPDF("Lender Updates to CD Received");
                Support.SavePDF(Reports.RUNRESULTDIR + "\\PDF");
                string PDFContents = Support.ReadPdfFile( Reports.RUNRESULTDIR + "\\PDF.pdf");
                Support.AreEqualTrim("True", PDFContents.Contains("Mortgage Insurance + 1,001.00").ToString());
                Support.AreEqualTrim("True", PDFContents.Contains("2,001.00").ToString());    
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0132_REG0003
        [TestMethod]
        public void FMUC0132_REG0003()
        {
            try
            {
                Reports.TestDescription = "System shall display events from Lender Updates to CD-Lender Updates to CD Partial";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create new file.";
                Dictionary<string, int> FileData = CreateFile();
                string FileNumber = FileData["FileNumber"].ToString();
                int FileId = FileData["FileId"];
                Reports.TestStep = "Go to closing disclosure.";
                FastDriver.ClosingDisclosure.Open();
                Reports.TestStep = "Enter data in projected payments.";
                EnterDataInProjectedPayments();
                Reports.TestStep = "Mismo posting";
                Dictionary<string, DateTime> DeliveryTime = new Dictionary<string, DateTime>();
                FASTWCFHelpers.FastClosingDisclosureService.OperationResponse Response = LenderUpdatesSingleWindow.MISMOPosting(FileId);
                string ReqId = Response.StatusDescription.Split('-')[1].Replace("QCStagingID:", " ").Trim();
                Reports.TestStep = "Update projected payments.";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                UpdateDataInProjectedPayments();
                Reports.TestStep = "Accept Lender Updates.";
                DeliveryTime["StartTime"] = DateTime.Now;
                FastDriver.ClosingDisclosure.AcceptLenderUpdate();
                DeliveryTime["CompletionTime"] = DateTime.Now;
                Reports.TestStep = "Open CD Event Log";
                FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                Reports.TestStep = "Validate CD Event Log";
                FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("Lender Updates Review Partial").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateSourceForEvent("Lender Updates Review Partial", "FAST Application").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateStartDateForEvent("Lender Updates Review Partial", DeliveryTime["StartTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateCompletionDateForEvent("Lender Updates Review Partial", DeliveryTime["CompletionTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateUserNameForEvent("Lender Updates Review Partial", @"FASTTS\FASTQA07").ToString());
                string Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent("Lender Updates Review Partial");
                Support.AreEqualTrim("True", Comment.Contains(ReqId).ToString());
                Support.AreEqualTrim("True", Comment.Contains("Review of Lender Updates to CD section \"Projected Payments\" accepted.").ToString());
                FastDriver.ClosingDisclosureEventsLog.CloseCDEventsDlg();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0132_REG0004
        [TestMethod]
        public void FMUC0132_REG0004()
        {
            try
            {
                Reports.TestDescription = "System shall display events from Lender Updates to CD-Lender Updates to CD Completed (Review accepted)";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create new file.";
                Dictionary<string, int> FileData = CreateFile();
                string FileNumber = FileData["FileNumber"].ToString();
                int FileId = FileData["FileId"];
                Reports.TestStep = "Go to closing disclosure.";
                FastDriver.ClosingDisclosure.Open();
                Reports.TestStep = "Enter data in projected payments.";
                EnterDataInProjectedPayments();
                Reports.TestStep = "Mismo posting";
                Dictionary<string, DateTime> DeliveryTime = new Dictionary<string, DateTime>();
                FASTWCFHelpers.FastClosingDisclosureService.OperationResponse Response = LenderUpdatesSingleWindow.MISMOPosting(FileId);
                string ReqId = Response.StatusDescription.Split('-')[1].Replace("QCStagingID:", " ").Trim();
                Reports.TestStep = "Update projected payments.";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                UpdateDataInProjectedPayments();
                Reports.TestStep = "Accept on Lender Updates.";
                FastDriver.ClosingDisclosure.AcceptLenderUpdate();
                FastDriver.ClosingDisclosure.AcceptLenderUpdateForAdditionalInfo();

                Reports.TestStep = "Click on Additional lender updates.";
                DeliveryTime["StartTime"] = DateTime.Now;
                FastDriver.ClosingDisclosure.ClickReviewedOnAdditionalLenderUpdate();
                DeliveryTime["CompletionTime"] = DateTime.Now;
                //
                Reports.TestStep = "Open CD Event Log";
                FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                Reports.TestStep = "Validate CD Event Log";
                FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("Lender Updates Review Completed").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateSourceForEvent("Lender Updates Review Completed", "FAST Application").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateStartDateForEvent("Lender Updates Review Completed", DeliveryTime["StartTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateCompletionDateForEvent("Lender Updates Review Completed", DeliveryTime["CompletionTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateUserNameForEvent("Lender Updates Review Completed", @"FASTTS\FASTQA07").ToString());
                string Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent("Lender Updates Review Completed");
                Support.AreEqualTrim("True", Comment.Contains(ReqId).ToString());
                Support.AreEqualTrim("True", Comment.Contains("Lender Updates to CD reviewed and completed.").ToString());
                FastDriver.ClosingDisclosureEventsLog.CloseCDEventsDlg();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0132_REG0005
        [TestMethod]
        public void FMUC0132_REG0005()
        {
            try
            {
                Reports.TestDescription = "System shall display events from Lender Updates to CD-Lender Updates to CD Completed (Review Rejected)";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create new file.";
                Dictionary<string, int> FileData = CreateFile();
                string FileNumber = FileData["FileNumber"].ToString();
                int FileId = FileData["FileId"];
                Reports.TestStep = "Go to closing disclosure.";
                FastDriver.ClosingDisclosure.Open();
                Reports.TestStep = "Enter data in projected payments.";
                EnterDataInProjectedPayments();
                Reports.TestStep = "Mismo posting";
                Dictionary<string, DateTime> DeliveryTime = new Dictionary<string, DateTime>();
                FASTWCFHelpers.FastClosingDisclosureService.OperationResponse Response = LenderUpdatesSingleWindow.MISMOPosting(FileId);
                string ReqId = Response.StatusDescription.Split('-')[1].Replace("QCStagingID:", " ").Trim();
                Reports.TestStep = "Update projected payments.";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                UpdateDataInProjectedPayments();
                Reports.TestStep = "Reject Lender Updates.";
                DeliveryTime["StartTime"] = DateTime.Now;
                FastDriver.ClosingDisclosure.RejectLenderUpdate();
                DeliveryTime["CompletionTime"] = DateTime.Now;
                Reports.TestStep = "Open CD Event Log";
                FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                Reports.TestStep = "Validate CD Event Log";
                FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("Lender Updates Review Partial").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateSourceForEvent("Lender Updates Review Partial", "FAST Application").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateStartDateForEvent("Lender Updates Review Partial", DeliveryTime["StartTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateCompletionDateForEvent("Lender Updates Review Partial", DeliveryTime["CompletionTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateUserNameForEvent("Lender Updates Review Partial", @"FASTTS\FASTQA07").ToString());
                string Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent("Lender Updates Review Partial");
                Support.AreEqualTrim("True", Comment.Contains(ReqId).ToString());
                Support.AreEqualTrim("True", Comment.Contains("Review of Lender Updates to CD section \"Projected Payments\" rejected.").ToString());
                Support.AreEqualTrim("True", Comment.Contains("Rejected for testing").ToString());
                FastDriver.ClosingDisclosureEventsLog.CloseCDEventsDlg();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0132_REG0006_PH
        [TestMethod]
        public void FMUC0132_REG0006_PH()
        {
                Reports.TestDescription = @"When Loan Purpose is Refinance, Home Equity Loan or Construction - system shall display the Lender CD in Borrower Only client format CD template.";
                Assert.Inconclusive("This scenario cannot be automated as it involves PDF format validation");
        }

        #endregion Test
        #region Test FMUC0132_REG0007
        [TestMethod]
        public void FMUC0132_REG0007()
        {
            Reports.TestDescription = @"Wintrack delivery ";
            try{
            Reports.TestStep = "Log into FAST application.";
            IISLOGIN();
            Reports.TestStep = "Create new file.";
            string Interface = "WINTRACK";
            Dictionary<string, int> FileData = CreateOrderForInterfaces(Interface);
            string FileNumber = FileData["FileNumber"].ToString();
            int FileId = FileData["FileId"];
            Reports.TestStep = "Go to closing disclosure.";
            FastDriver.ClosingDisclosure.Open();
            Reports.TestStep = "Enter data in projected payments.";
            EnterDataInProjectedPayments();
            Reports.TestStep = "Perform print delivery";
            Dictionary<string, DateTime> DeliveryTime = PerformDeliveryInCD(Interface);
            Reports.TestStep = "Open CD Event Log";
            FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
            Reports.TestStep = "Validate CD Event Log";
            FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
            Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("[Interface Doc Delivery]").ToString());
            Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateSourceForEvent("[Interface Doc Delivery]", "FAST TS").ToString());
            Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateStartDateForEvent("[Interface Doc Delivery]", DeliveryTime["StartTime"]).ToString());
            Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateCompletionDateForEvent("[Interface Doc Delivery]", DeliveryTime["CompletionTime"]).ToString());
            Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateUserNameForEvent("[Interface Doc Delivery]", @"FAST QA07").ToString());
            string Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent("[Interface Doc Delivery]");
            Support.AreEqualTrim("True", Comment.Contains(Interface).ToString());
            Support.AreEqualTrim("True", ValidateDeliveryStatus("[Interface Doc Delivery]").ToString());
                        }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0132_REG0008_PH
        [TestMethod]
        public void FMUC0132_REG0008_PH()
        {
            Reports.TestDescription = @"FastWeb delivery";
            Assert.Inconclusive("This flow cannot be automated. Please perform it manually");


        }
        #endregion Test
        //
        #region Test FMUC0132_REG0009
        [TestMethod]
        public void FMUC0132_REG0009()
        {
            try
            {
                Reports.TestDescription = @"LA.COM delivery ";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create new file.";
                string Interface = "LA.COM";
                Dictionary<string, int> FileData = CreateOrderForInterfaces(Interface);
                string FileNumber = FileData["FileNumber"].ToString();
                int FileId = FileData["FileId"];
                Reports.TestStep = "Go to closing disclosure.";
                FastDriver.ClosingDisclosure.Open();
                Reports.TestStep = "Enter data in projected payments.";
                EnterDataInProjectedPayments();
                Reports.TestStep = "Perform print delivery";
                Dictionary<string, DateTime> DeliveryTime = PerformDeliveryInCD(Interface);
                Reports.TestStep = "Open CD Event Log";
                FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                Reports.TestStep = "Validate CD Event Log";
                FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("[Interface Doc Delivery]").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateSourceForEvent("[Interface Doc Delivery]", "FAST TS").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateStartDateForEvent("[Interface Doc Delivery]", DeliveryTime["StartTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateCompletionDateForEvent("[Interface Doc Delivery]", DeliveryTime["CompletionTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateUserNameForEvent("[Interface Doc Delivery]", @"FAST QA07").ToString());
                string Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent("[Interface Doc Delivery]");
                Support.AreEqualTrim("True", Comment.Contains(Interface).ToString());
                Support.AreEqualTrim("True", ValidateDeliveryStatus("[Interface Doc Delivery]").ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0132_REG0010
        [TestMethod]
        public void FMUC0132_REG0010()
        {
            Reports.TestDescription = @"LVIS delivery ";
            try
            {
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "Create new file.";
                string Interface = "LVIS";
                Dictionary<string, int> FileData = CreateOrderForInterfaces(Interface);
                string FileNumber = FileData["FileNumber"].ToString();
                int FileId = FileData["FileId"];
                Reports.TestStep = "Go to closing disclosure.";
                FastDriver.ClosingDisclosure.Open();
                Reports.TestStep = "Enter data in projected payments.";
                EnterDataInProjectedPayments();
                Reports.TestStep = "Perform print delivery";
                Dictionary<string, DateTime> DeliveryTime = PerformDeliveryInCD(Interface);
                Reports.TestStep = "Open CD Event Log";
                FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                Reports.TestStep = "Validate CD Event Log";
                FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("[Interface Doc Delivery]").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateSourceForEvent("[Interface Doc Delivery]", "FAST TS").ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateStartDateForEvent("[Interface Doc Delivery]", DeliveryTime["StartTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateCompletionDateForEvent("[Interface Doc Delivery]", DeliveryTime["CompletionTime"]).ToString());
                Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateUserNameForEvent("[Interface Doc Delivery]", @"FAST QA07").ToString());
                string Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent("[Interface Doc Delivery]");
                Support.AreEqualTrim("True", Comment.Contains(Interface).ToString());
                Support.AreEqualTrim("True", ValidateDeliveryStatus("[Interface Doc Delivery]").ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0132_REG0011
        [TestMethod]
        public void FMUC0132_REG0011()
        {
            try
            {
                Reports.TestDescription = @"Lender Updates Review Excluded";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = @"Check build number as this event is available in FAST from 10.7 onwards";
                string Version = FastDriver.HomePage.VersionNumber.FAGetText().Clean();
                if (!(Convert.ToDouble(Version.Substring(0, 5)) >= 10.07))
                    Reports.StatusUpdate("The event - Lender Updates Review Excluded is is available in FAST from 10.7 onwards", true);
                else
                {
                    Reports.TestStep = "Create new file.";
                    Dictionary<string, int> FileData = CreateFile();
                    string FileNumber = FileData["FileNumber"].ToString();
                    int FileId = FileData["FileId"];
                    Reports.TestStep = "Go to closing disclosure.";
                    FastDriver.ClosingDisclosure.Open();
                    FastDriver.ClosingDisclosure.tabClosingDisclosure.FAClick();
                    FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                    Reports.TestStep = "Enter data in projected payments.";
                string MortgageInsurance = "1001";
                string EstimatedTaxesInsuranceAssessments = "2001";
                EnterDataInProjectedPayments(MortgageInsurance, EstimatedTaxesInsuranceAssessments);
                    Reports.TestStep = "Mismo posting 1 - To simulate multiple lender updates scenario";
                    Dictionary<string, DateTime> DeliveryTime1 = new Dictionary<string, DateTime>();
                    DeliveryTime1["StartTime"] = DateTime.Now;
                    FASTWCFHelpers.FastClosingDisclosureService.OperationResponse Response1 = LenderUpdatesSingleWindow.MISMOPosting(FileId);
                    DeliveryTime1["CompletionTime"] = DateTime.Now;
                    string ReqId1 = Response1.StatusDescription.Split('-')[1].Replace("QCStagingID:", " ").Trim();
                    Reports.TestStep = "Mismo posting 2 - To simulate multiple lender updates scenario";
                    FastDriver.ClosingDisclosure.Open();
                    Dictionary<string, DateTime> DeliveryTime2 = new Dictionary<string, DateTime>();
                    DeliveryTime2["StartTime"] = DateTime.Now;
                    FASTWCFHelpers.FastClosingDisclosureService.OperationResponse Response2 = LenderUpdatesSingleWindow.MISMOPosting(FileId);
                    DeliveryTime2["CompletionTime"] = DateTime.Now;
                    string ReqId2 = Response2.StatusDescription.Split('-')[1].Replace("QCStagingID:", " ").Trim();
                    Reports.TestStep = "Accept  Lender Updates.";
                    FastDriver.ClosingDisclosure.AcceptLenderUpdate();
                    //Reports.TestStep = "Click on Additional lender updates.";
                    //FastDriver.ClosingDisclosure.ClickReviewedOnAdditionalLenderUpdate();
                    Reports.TestStep = "Open CD Event Log";
                    FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                    Reports.TestStep = "Validate CD Event Log";
                    FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
                    Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateEvent("Lender Updates Review Excluded").ToString());
                    Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateSourceForEvent("Lender Updates Review Excluded", "FAST").ToString());
                    Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateStartDateForEvent("Lender Updates Review Excluded", DeliveryTime1["StartTime"]).ToString());
                    Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateCompletionDateForEvent("Lender Updates Review Excluded", DeliveryTime1["CompletionTime"]).ToString());
                    Support.AreEqualTrim("True", FastDriver.ClosingDisclosureEventsLog.ValidateUserNameForEvent("Lender Updates Review Excluded", @"FAST").ToString());
                    string Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent("Lender Updates Review Excluded");
                    Support.AreEqualTrim("True", Comment.Contains(ReqId1).ToString());
                    Support.AreEqualTrim("True", Comment.Contains("Request is excluded").ToString());
                    FastDriver.ClosingDisclosureEventsLog.CloseCDEventsDlg();
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0132_REG0012_PH
        [TestMethod]
        public void FMUC0132_REG0012_PH()
        {
            Reports.TestDescription = @"1) Display informational message when unable to display Lender CD 2) Display watermark on Lender CD ";
                Assert.Inconclusive("This flow cannot be automated. Please perform it manually");
                
        }
        #endregion Test
        #endregion

        #region PrivateMethods
        private void IISLOGIN(string UserName = null, string Password = null, bool CleanSession = true)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, CleanSession);

        }
        //
        private Dictionary<string, int> CreateFile(string TransactionType = "SALE", decimal SalesPriceAmount = 5000)
        {
            try
            {
                Reports.TestStep = "Create new file.";
                Dictionary<string, int> FileData = new Dictionary<string, int>();
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.SalesPriceAmount = SalesPriceAmount;
                int FileId = (int)FileService.CreateFile(defaultRequest).FileID;
                string FileNumber = FileService.GetOrderDetails(FileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);
                FileData.Add("FileId", FileId);
                FileData.Add("FileNumber", Convert.ToInt32(FileNumber));
                return FileData;
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to create QFE", ex);
            }
        }
        //
        private Dictionary<string, int> CreateOrderForInterfaces(string SOURCE)
        {
            Dictionary<string, int> FileData = new Dictionary<string, int>();
            try
            {
                Reports.TestStep = "Create a " + SOURCE + " file";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();

                fileRequest.Source = SOURCE;

                int FileId = (int)FileService.CreateFile(fileRequest).FileID;
                var File = FileService.GetOrderDetails(FileId);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FileData.Add("FileId", FileId);
                FileData.Add("FileNumber", Convert.ToInt32(File.FileNumber));
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return FileData;
        }
        //
        private Dictionary<string, DateTime> PerformDeliveryInCD(string DeliveryMethod)
        {
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
            Dictionary<string, DateTime> DeliveryTime =new Dictionary<string, DateTime>();
            DateTime DeliveryStartTime=new DateTime();
            DateTime DeliveryCompletionTime = new DateTime();
            FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
            FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            FastDriver.ClosingDisclosure.WaitForDeliveryOptionsScreenToLoad(FastDriver.ClosingDisclosure.DeliveryMethod);
            if (!FastDriver.ClosingDisclosure.Draft.IsSelected())
                FastDriver.ClosingDisclosure.Draft.FASetCheckbox(true);
            FastDriver.ClosingDisclosure.Combined.FASetCheckbox(true);
            if (!FastDriver.ClosingDisclosure.DeliveryButton.IsEnabled())
                Reports.StatusUpdate("Delivery button is not enabled", false);
            else
            {
                DeliveryStartTime = DateTime.Now;
                FastDriver.ClosingDisclosure.DeliveryButton.ScrollIntoView();
                PerformDelivery(DeliveryMethod, FastDriver.ClosingDisclosure);
                DeliveryCompletionTime = DateTime.Now;
            }

            FastDriver.ClosingDisclosure.WaitForDeliveryOptionsScreenToLoad(FastDriver.ClosingDisclosure.DeliveryMethod);
            DeliveryTime.Add("StartTime", DeliveryStartTime);
            DeliveryTime.Add("CompletionTime", DeliveryCompletionTime);
            return DeliveryTime;
        }

        private void EnterDataInProjectedPayments(string MortgageInsurance = "1001", string EstimatedTaxesInsuranceAssessments="2001")
        {
            FastDriver.ClosingDisclosure.WaitForScreenToLoad();
            FastDriver.ClosingDisclosure.tabClosingDisclosure.ScrollIntoView();
            FastDriver.ClosingDisclosure.tabClosingDisclosure.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
            if (!FastDriver.ClosingDisclosure.ProjectedPayment_ddlYearRanges1.IsDisplayed())
            FastDriver.ClosingDisclosure.Projected_Payments.FAClick();
            FastDriver.ClosingDisclosure.ProjectedPayment_ddlYearRanges1.FASelectItem("Year");
            if (!FastDriver.ClosingDisclosure.Section3_MortgageInsurance.IsDisplayed())
                FastDriver.ClosingDisclosure.Section3_MortgageInsurance.ScrollIntoView();
            FastDriver.ClosingDisclosure.Section3_MortgageInsurance.FASetText(MortgageInsurance);
            FastDriver.ClosingDisclosure.Section3_EstimatedTaxesInsuranceAssessments.FASetText(EstimatedTaxesInsuranceAssessments);
            FastDriver.BottomFrame.Done();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            FastDriver.ClosingDisclosure.Open();
        }
        //
        private void UpdateDataInProjectedPayments(string MortgageInsurance = "1002", string EstimatedTaxesInsuranceAssessments = "2002")
        {
            FastDriver.ClosingDisclosure.WaitForScreenToLoad();
            FastDriver.ClosingDisclosure.tabClosingDisclosure.ScrollIntoView();
            FastDriver.ClosingDisclosure.tabClosingDisclosure.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
            if (!FastDriver.ClosingDisclosure.ProjectedPayment_ddlYearRanges1.IsDisplayed())
            FastDriver.ClosingDisclosure.Projected_Payments.FAClick();
            FastDriver.ClosingDisclosure.ProjectedPayment_ddlYearRanges1.FASelectItem("Year");
            if (!FastDriver.ClosingDisclosure.Section3_MortgageInsurance.IsDisplayed())
                FastDriver.ClosingDisclosure.Section3_MortgageInsurance.ScrollIntoView();
            FastDriver.ClosingDisclosure.Section3_MortgageInsurance.FASetText(MortgageInsurance);
            FastDriver.ClosingDisclosure.Section3_EstimatedTaxesInsuranceAssessments.FASetText(EstimatedTaxesInsuranceAssessments);
            FastDriver.BottomFrame.Done();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            FastDriver.ClosingDisclosure.Open();

        }
        //
        private bool ValidateCDEventSortOrder()
        {
            int RowCount = FastDriver.ClosingDisclosureEventsLog.EventTable.GetRowCount();
            bool Result = false;
            for (int i = 1; i <= RowCount; i++)
            {
                string Event = FastDriver.ClosingDisclosureEventsLog.EventTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                string ActualStartDate1 = FastDriver.ClosingDisclosureEventsLog.EventTable.PerformTableAction(i, 2, TableAction.GetText).Message;
                string ActualStartDate2 = FastDriver.ClosingDisclosureEventsLog.EventTable.PerformTableAction(++i, 2, TableAction.GetText).Message;

                DateTime StartDate1, StartDate2;
                bool isConverted1 = DateTime.TryParse(ActualStartDate1.Substring(0,19).Trim(), out StartDate1);
                bool isConverted2 = DateTime.TryParse(ActualStartDate2.Substring(0, 19).Trim(), out StartDate2);
                if (isConverted1 && isConverted2)
                {
                    if (StartDate1.CompareTo(StartDate2)>=0)
                        Result = true;
                }
                else
                {
                    Reports.StatusUpdate("Strings are not in correct format", false);
                }
            }
            return Result;

        }
        //
        private bool ValidateDeliveryStatus(string Event, string DeliveryStatus = "Delivery Successful")
        {
            FastDriver.ClosingDisclosureEventsLog.CDEventsCategory.ScrollIntoView();
            for (int i = 0; i < 16; i++) // delay of 5 min
            {
                string Comment = FastDriver.ClosingDisclosureEventsLog.GetCommentForEvent(Event);
                if (!Comment.Contains(DeliveryStatus))
                {
                    Thread.Sleep(20000);
                    FastDriver.ClosingDisclosureEventsLog.CloseCDEventsDlg();
                    FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                }
                else
                    return true;
            }
            return false;
        }

        #endregion
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}

