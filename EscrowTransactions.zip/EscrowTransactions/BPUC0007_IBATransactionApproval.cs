﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.Common;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;


namespace EscrowTransactions
{
    [CodedUITest]
    public class BPUC0007_IBATransactionApproval : MasterTestClass
    {

        #region BAT

        [TestMethod]
        [Description("Approve IBA Transactions && Login with second user & Approve IBA Transaction")]
        public void BPUC0007_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1: Approve IBA Transactions &&  MF1_1: Login with second user & Approve IBA Transaction";
                FASqlHelpers.DisableSymantecWireApprovalFlag();

                #region MF1: Approve IBA Transactions
                Reports.TestStep = "MF1: Approve IBA Transactions";
                Reports.StatusUpdate("MF1: Approve IBA Transactions", true);

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";
                DepositData.Comments = "Comments Before Save";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile();
                #endregion

                #region Deposit a cash
                Reports.TestStep = "Deposit a cash.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();

                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItem("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.DepositInEscrow.SwitchToContentFrame();

                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.InterestBearingAccounts.Open();

                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();

                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText("Beneficiary Name1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText("Address Line 1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText("Address Line 2");
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText("Santa ana");
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem("CA");
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText("92727");
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText("123456789");
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.TransactionTab.FAClick();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();

                #endregion

                #endregion

                #region MF1_1: Login with second user & Approve IBA Transaction

                Reports.TestStep = "MF1_1: Login with second user & Approve IBA Transaction";
                Reports.StatusUpdate("MF1_1: Login with second user & Approve IBA Transaction", true);

                #region Login
                _IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                #region Navigate to File
                Reports.TestStep = "Enter file number.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileData.FileNumber);
                #endregion

                #region Approve the Transaction
                Reports.TestStep = "Approve the Transaction.";
                FastDriver.IBATransactionApproval.Open();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(2, FileData.FileNumber.ToString(), 1, TableAction.On);

                FastDriver.IBATransactionApproval.WaitForApproveEnabled();
                FastDriver.IBATransactionApproval.Approve.Click();
                FastDriver.WebDriver.HandleDialogMessage();

               // FastDriver.IBATransactionPastBankCutoffTimeDlg.WaitForScreenToLoad();
               // FastDriver.IBATransactionPastBankCutoffTimeDlg.TransactionsTable.PerformTableAction(1, 1, TableAction.Click);
               // FastDriver.DialogBottomFrame.ClickDone();

               //FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify system removes the File Number after approving the IBA.";
                FastDriver.IBATransactionApproval.Open();
                Support.AreEqual(false.ToString(), FastDriver.IBATransactionApproval.TransactionTable.FAGetText().Contains(FileData.FileNumber.ToString()).ToString());

                Reports.TestStep = "Search for the record approved.";
                FastDriver.IBATransactionSummary.Open();

                string FromDate = DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("MM/dd/yyyy");
                FromDate = FromDate.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(FromDate);

                string ToDate = DateTime.Today.AddDays(Convert.ToInt32("1")).ToString("MM/dd/yyyy");
                ToDate = ToDate.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(ToDate);


                FastDriver.IBATransactionSummary.FindNow.FAClick();
                FastDriver.IBATransactionSummary.WaitForTransactionTableResults();

                FastDriver.IBATransactionSummary.Table.PerformTableAction(1, FileData.FileNumber.ToString(), 1, TableAction.Click);
                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verifying for the approved transaction && Approve partial withdrawn.")]
        public void BPUC0007_BAT0003()
        {
            try
            {
                Reports.TestDescription = "MF1_2: verifying for the approved transaction && MF1_3: Approve partial withdrawn.";
                FASqlHelpers.DisableSymantecWireApprovalFlag();

                #region MF1: Approve IBA Transactions - Dependency

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";
                DepositData.Comments = "Comments Before Save";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile();
                #endregion

                #region Deposit a cash
                Reports.TestStep = "Deposit a cash.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();

                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItem("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.DepositInEscrow.SwitchToContentFrame();

                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.InterestBearingAccounts.Open();

                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();

                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText("Beneficiary Name1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText("Address Line 1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText("Address Line 2");
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText("Santa ana");
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem("CA");
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText("92727");
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText("123456789");
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();

                Reports.TestStep = "Enter the Transaction Amount and saving.";

                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.TransactionTab.FAClick();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();

                #endregion

                #endregion

                #region MF1_1: Login with second user & Approve IBA Transaction - Dependency

                #region Login
                _IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                #region Navigate to File
                Reports.TestStep = "Enter file number.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileData.FileNumber);
                #endregion

                #region Approve the Transaction
                Reports.TestStep = "Approve the Transaction.";
                FastDriver.IBATransactionApproval.Open();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(2, FileData.FileNumber.ToString(), 1, TableAction.On);

                FastDriver.IBATransactionApproval.WaitForApproveEnabled();
                FastDriver.IBATransactionApproval.Approve.Click();

                //FastDriver.IBATransactionPastBankCutoffTimeDlg.WaitForScreenToLoad();
                //FastDriver.IBATransactionPastBankCutoffTimeDlg.TransactionsTable.PerformTableAction(1, 1, TableAction.Click);
                //FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify system removes the File Number after approvin the IBA.";
                FastDriver.IBATransactionApproval.Open();
                Support.AreEqual(false.ToString(), FastDriver.IBATransactionApproval.TransactionTable.FAGetText().Contains(FileData.FileNumber.ToString()).ToString());
                FastDriver.IBATransactionApproval.WaitForScreenToLoad();

                Reports.TestStep = "Search for the record approved.";
                FastDriver.IBATransactionSummary.Open();

                string FromDate = DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("MM/dd/yyyy");
                FromDate = FromDate.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(FromDate);

                string ToDate = DateTime.Today.AddDays(Convert.ToInt32("1")).ToString("MM/dd/yyyy");
                ToDate = ToDate.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(ToDate);


                FastDriver.IBATransactionSummary.FindNow.FAClick();
                Playback.Wait(5000);
                FastDriver.IBATransactionSummary.WaitForTransactionTableResults();

                FastDriver.IBATransactionSummary.Table.PerformTableAction(1, FileData.FileNumber.ToString(), 1, TableAction.Click);
                #endregion

                #endregion

                #region MF1_2: Verifying for the approved transaction

                Reports.TestStep = "MF1_2: Verifying for the approved transaction";
                Reports.StatusUpdate("MF1_2: Verifying for the approved transaction", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Navigate to File
                Reports.TestStep = "Enter file number.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileData.FileNumber);
                #endregion

                Reports.TestStep = "Navigate to IBA screen and checking for the status. Add button is enabled once transaction is completed.";

                FastDriver.InterestBearingAccounts.WaitForTransactionCompleted();

                Reports.TestStep = "Add Partial Withdrawal.";
                FastDriver.InterestBearingAccounts.Add.FAClick();
                FastDriver.AddIBATransactionDlg.WaitForScreenToLoad();
                FastDriver.AddIBATransactionDlg.PartialWithdrawal.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.SwitchToContentFrame();
                FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, "Partial Withdrawal", 4, TableAction.SetText, "5.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();

                #endregion

                #region MF1_3: Approve partial withdrawn.

                Reports.TestStep = "MF1_3: Approve partial withdrawn.";
                Reports.StatusUpdate("MF1_3: Approve partial withdrawn.", true);

                #region Login
                _IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                #region Navigate to File
                Reports.TestStep = "Enter file number.";
                FastDriver.HomePage.WaitForHomeScreen();
                Playback.Wait(5000);
                FastDriver.TopFrame.SearchFileByFileNumber(FileData.FileNumber);

                #endregion

                #region Approve the Partial Withdrawn Transaction
                Reports.TestStep = "Approve the Partial Withdrawn Transaction.";
                FastDriver.IBATransactionApproval.Open();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(4, "Partial Withdrawal", 1, TableAction.On);
                FastDriver.IBATransactionApproval.Approve.FAClick();
                
                //FastDriver.IBATransactionPastBankCutoffTimeDlg.WaitForScreenToLoad();
                //FastDriver.IBATransactionPastBankCutoffTimeDlg.TransactionsTable.PerformTableAction(1, 1, TableAction.Click);
                //FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();

                #endregion

                #region Verify system removes the File Number after approvin the IBA
                Reports.TestStep = "Verify system removes the File Number after approvin the IBA.";
                FastDriver.IBATransactionApproval.Open();
                Support.AreEqual(false.ToString(), FastDriver.IBATransactionApproval.TransactionTable.FAGetText().Contains(FileData.FileNumber.ToString()).ToString());

                Reports.TestStep = "Verify for Partial Transaction is Approved.";
                FastDriver.IBATransactionSummary.Open();

                FromDate = DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("MM/dd/yyyy");
                FromDate = FromDate.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(FromDate);

                ToDate = DateTime.Today.AddDays(Convert.ToInt32("1")).ToString("MM/dd/yyyy");
                ToDate = ToDate.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(ToDate);

                FastDriver.IBATransactionSummary.FileNo.FASetText(FileData.FileNumber.ToString());
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                FastDriver.IBATransactionSummary.WaitForTransactionTableResults();

                FastDriver.IBATransactionSummary.Table.PerformTableAction(3, "Partial Withdrawal", 1, TableAction.GetText);

                Reports.TestStep = "Verify for partial withdrawn.";
                FastDriver.DepositSummary.Open();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(8, "IBA Partial Withdrawal", 8, TableAction.Click);
                #endregion

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("ADM Set Up,Enter cut off time 2 hour more than current time && Cancel IBA Transaction Approval Before Cutoff Time &&  AF1_1: Login with second user & cancel the IBA Transaction")]
        public void BPUC0007_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF1: ADM Set Up,Enter cut off time 2 hour more than current time && AF1: Cancel IBA Transaction Approval Before Cutoff Time &&  AF1_1: Login with second user & cancel the IBA Transaction";
                FASqlHelpers.DisableSymantecWireApprovalFlag();

                #region ADM Set Up,Enter cut off time 2 hour more than current time

                Reports.TestStep = "ADM Set Up,Enter cut off time 2 hour more than current time";
                Reports.StatusUpdate("ADM Set Up,Enter cut off time 2 hour more than current time", true);


                #region Login
                _ADMLOGIN();
                #endregion

                #region Enter IBA cutoff time

                Reports.TestStep = "Enter IBA cutoff time.";
                FastDriver.LeftNavigation.Navigate<IBABankSetup>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>IBA Bank Setup");
                string DailyCutoff = DateTime.Now.AddHours(Convert.ToInt32("-11")).ToString("hh:mm:ss");
                FastDriver.IBABankSetup.DailyCutOff.FASetText(DailyCutoff + FAKeys.Tab);
                FastDriver.IBABankSetup.SwitchToContentFrame();

                #endregion

                #endregion

                #region AF1: Cancel IBA Transaction Approval Before Cutoff Time

                Reports.TestStep = "AF1: Cancel IBA Transaction Approval Before Cutoff Time";
                Reports.StatusUpdate("AF1: Cancel IBA Transaction Approval Before Cutoff Time", true);

                #region DataSetup
                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";
                DepositData.Comments = "Comments Before Save";
                #endregion

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile();
                #endregion

                #region Deposit a cash
                Reports.TestStep = "Deposit a cash.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();

                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItem("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.DepositInEscrow.SwitchToContentFrame();

                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.InterestBearingAccounts.Open();

                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();

                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText("Beneficiary Name1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText("Address Line 1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText("Address Line 2");
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText("Santa ana");
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem("CA");
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText("92727");
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText("123456789");
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();

                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.TransactionTab.FAClick();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();

                #endregion

                #endregion

                #region AF1_1: Login with second user & cancel the IBA Transaction

                Reports.TestStep = "AF1_1: Login with second user & cancel the IBA Transaction";
                Reports.StatusUpdate("AF1_1: Login with second user & cancel the IBA Transaction", true);

                #region Login
                _IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                #region Navigate to File
                Reports.TestStep = "Enter file number.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileData.FileNumber);
                #endregion

                #region Approve the Transaction
                Reports.TestStep = "Approve the Transaction.";
                FastDriver.IBATransactionApproval.Open();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(2, FileData.FileNumber.ToString(), 1, TableAction.On);

                FastDriver.IBATransactionApproval.WaitForApproveEnabled();
                FastDriver.IBATransactionApproval.Approve.Click();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Reports.TestStep = "Verify for the selected checkbox.";
                FastDriver.IBATransactionApproval.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.IBATransactionApproval.TransactionTable.FAGetText().Contains(FileData.FileNumber.ToString()).ToString());


                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("AF1: ADM Set Up,Enter cut off time 2 hour less than current time &&  AF3: Cancel IBA Transaction Approval After Cutoff Time.")]
        public void BPUC0007_BAT0008()
        {
            try
            {
                Reports.TestDescription = "AF1: ADM Set Up,Enter cut off time 2 hour less than current time &&  AF3: Cancel IBA Transaction Approval After Cutoff Time.";
                FASqlHelpers.DisableSymantecWireApprovalFlag();

                #region AF1: ADM Set Up,Enter cut off time 2 hour less than current time

                Reports.TestStep = "AF1: ADM Set Up,Enter cut off time 2 hour less than current time.";
                Reports.StatusUpdate("AF1: ADM Set Up,Enter cut off time 2 hour less than current time.", true);


                #region Login
                _ADMLOGIN();
                #endregion

                #region Enter IBA cutoff time

                Reports.TestStep = "Enter IBA cutoff time.";
                FastDriver.LeftNavigation.Navigate<IBABankSetup>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>IBA Bank Setup");
                string DailyCutoff = DateTime.Now.AddHours(Convert.ToInt32("-15")).ToString("hh:mm:ss");
                FastDriver.IBABankSetup.DailyCutOff.FASetText(DailyCutoff + FAKeys.Tab);
                FastDriver.IBABankSetup.SwitchToContentFrame();

                #endregion

                #endregion

                #region AF3: Cancel IBA Transaction Approval After Cutoff Time.

                Reports.TestStep = "AF3: Cancel IBA Transaction Approval After Cutoff Time.";
                Reports.StatusUpdate("AF3: Cancel IBA Transaction Approval After Cutoff Time.", true);

                #region DataSetup
                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";
                DepositData.Comments = "Comments Before Save";
                #endregion

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile();
                #endregion

                #region Deposit a cash
                Reports.TestStep = "Deposit a cash.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();

                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItem("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.DepositInEscrow.SwitchToContentFrame();

                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.InterestBearingAccounts.Open();

                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();

                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText("Beneficiary Name1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText("Address Line 1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText("Address Line 2");
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText("Santa ana");
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem("CA");
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText("92727");
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText("123456789");
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();

                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.TransactionTab.FAClick();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();

                #endregion

                #region Login
                _IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                #region Navigate to File
                Reports.TestStep = "Enter file number.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileData.FileNumber);
                #endregion

                #region Approve the Transaction
                Reports.TestStep = "Approve the Transaction.";
                FastDriver.IBATransactionApproval.Open();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(2, FileData.FileNumber.ToString(), 1, TableAction.On);

                FastDriver.IBATransactionApproval.WaitForApproveEnabled();
                FastDriver.IBATransactionApproval.Approve.Click();
                Reports.TestStep = "Verify Message on IBA Transaction screen.";
                Support.AreEqual("Approval will issue deposits \r\nin the FAST file and include them \r\nin the next Trust32 Extract, \r\nand send IBA transactions to \r\nthe Bank. Continue?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));

                //FastDriver.IBATransactionPastBankCutoffTimeDlg.WaitForScreenToLoad();
                //FastDriver.IBATransactionPastBankCutoffTimeDlg.TransactionsTable.PerformTableAction(1, 1, TableAction.Click);
                //FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify for the selected checkbox.";
                FastDriver.IBATransactionApproval.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.IBATransactionApproval.TransactionTable.FAGetText().Contains(FileData.FileNumber.ToString()).ToString());


                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("AF1: ADM Set Up,Enter cut off time 2 hour less than current time &&  AF3: Cancel IBA Transaction Approval After Cutoff Time.")]
        public void BPUC0007_BAT0010()
        {
            try
            {
                Reports.TestDescription = "AF1: ADM Set Up,Enter cut off time 2 hour more than current time.";
                FASqlHelpers.DisableSymantecWireApprovalFlag();

                #region AF1: ADM Set Up,Enter cut off time 2 hour more than current time.

                Reports.TestStep = "AF1: ADM Set Up,Enter cut off time 2 hour more than current time.";
                Reports.StatusUpdate("AF1: ADM Set Up,Enter cut off time 2 hour more than current time.", true);


                #region Login
                _ADMLOGIN();
                #endregion

                #region Enter IBA cutoff time

                Reports.TestStep = "Enter IBA cutoff time.";
                FastDriver.LeftNavigation.Navigate<IBABankSetup>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>IBA Bank Setup");
                string DailyCutoff = DateTime.Now.AddHours(Convert.ToInt32("-15")).ToString("hh:mm:ss");
                FastDriver.IBABankSetup.DailyCutOff.FASetText(DailyCutoff + FAKeys.Tab);
                FastDriver.IBABankSetup.SwitchToContentFrame();

                #endregion

                #endregion

                #region AF2: Approve IBA Transactions After IBA Bank Daily Cutoff Time.

                Reports.TestStep = "AF2: Approve IBA Transactions After IBA Bank Daily Cutoff Time.";
                Reports.StatusUpdate("AF2: Approve IBA Transactions After IBA Bank Daily Cutoff Time.", true);

                #region DataSetup
                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";
                DepositData.Comments = "Comments Before Save";
                #endregion

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile();
                #endregion

                #region Deposit a cash
                Reports.TestStep = "Deposit a cash.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();

                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItem("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.DepositInEscrow.SwitchToContentFrame();

                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.InterestBearingAccounts.Open();

                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();

                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText("Beneficiary Name1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText("Address Line 1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText("Address Line 2");
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText("Santa ana");
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem("CA");
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText("92727");
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText("123456789");
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();

                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.TransactionTab.FAClick();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();

                #endregion

                #region Login
                _IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                #region Navigate to File
                Reports.TestStep = "Enter file number.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileData.FileNumber);
                #endregion

                #region Approve the Transaction
                Reports.TestStep = "Approve the Transaction.";
                FastDriver.IBATransactionApproval.Open();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(2, FileData.FileNumber.ToString(), 1, TableAction.On);

                FastDriver.IBATransactionApproval.WaitForApproveEnabled();
                FastDriver.IBATransactionApproval.Approve.Click();
                FastDriver.WebDriver.HandleDialogMessage();

                //FastDriver.IBATransactionPastBankCutoffTimeDlg.WaitForScreenToLoad();
                //FastDriver.IBATransactionPastBankCutoffTimeDlg.TransactionsTable.PerformTableAction(1, 1, TableAction.Click);
                //FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify system removes the File Number after approvin the IBA.";
                FastDriver.IBATransactionApproval.SwitchToContentFrame();
                Support.AreEqual(false.ToString(), FastDriver.IBATransactionApproval.TransactionTable.FAGetText().Contains(FileData.FileNumber.ToString()).ToString());


                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region REGRESSION

        [TestMethod]
        [Description("BP10031_BP10032_001_EW1: Create IBA Beneficiary transaction && MF1_1: Login with second user & Approve IBA Transaction && BP10032_003: Login as user 1 and Verify Approved IBA")]
        public void BPUC0007_REG0001()
        {
            try
            {
                Reports.TestDescription = "BP10031_BP10032_001_EW1: Create IBA Beneficiary transaction && MF1_1: Login with second user & Approve IBA Transaction && BP10032_003: Login as user 1 and Verify Approved IBA";

                #region BP10031_BP10032_001_EW1: Create IBA Beneficiary transaction

                Reports.TestStep = "BP10031_BP10032_001_EW1: Create IBA Beneficiary transaction";
                Reports.StatusUpdate("BP10031_BP10032_001_EW1: Create IBA Beneficiary transaction", true);

                #region Data Setup
                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";
                DepositData.Comments = "Comments Before Save";
                #endregion

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile();
                #endregion

                #region Navigate to IBA screen and click on new button
                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.InterestBearingAccounts.Open();

                FastDriver.InterestBearingAccounts.New.FAClick();
                Reports.TestStep = "click on new for blank verification.";
                Support.AreEqual("File does not have funds available to open an IBA", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();

                #endregion

                #region Deposit a cash
                Reports.TestStep = "Deposit a cash.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region Navigate to IBA screen and create a new Beneficiary
                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.InterestBearingAccounts.Open();

                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();

                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText("Beneficiary Name1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText("Address Line 1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText("Address Line 2");
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText("Santa ana");
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem("CA");
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText("92727");
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText("123456789");
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();

                #endregion

                #region Navigate to IBA screen and selecting the IBA Bank.
                Reports.TestStep = "Navigate to IBA screen and selecting the IBA Bank.";
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.TransactionTab.FAClick();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();

                Reports.TestStep = "Verify that same user cannot approve IBA.";
                FastDriver.IBATransactionApproval.Open();
                Support.AreEqual(false.ToString(), FastDriver.IBATransactionApproval.TransactionTable.FAGetText().Contains(FileData.FileNumber.ToString()).ToString(), "Verify if the Transaction table does not cotain the created transaction");
                #endregion

                #endregion

                #region MF1_1: Login with second user & Approve IBA Transaction

                Reports.TestStep = "MF1_1: Login with second user & Approve IBA Transaction";
                Reports.StatusUpdate("MF1_1: Login with second user & Approve IBA Transaction", true);

                #region Login
                _IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                #region Navigate to File
                Reports.TestStep = "Enter file number.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileData.FileNumber);
                #endregion

                #region Approve the Transaction
                Reports.TestStep = "Approve the Transaction.";
                FastDriver.IBATransactionApproval.Open();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(2, FileData.FileNumber.ToString(), 1, TableAction.On);

                FastDriver.IBATransactionApproval.WaitForApproveEnabled();
                FastDriver.IBATransactionApproval.Approve.Click();

                FastDriver.WebDriver.HandleDialogMessage();

                #endregion

                #endregion

                #region BP10032_003: Login as user 1 and Verify Approved IBA
                Reports.TestStep = "BP10032_003: Login as user 1 and Verify Approved IBA";
                Reports.StatusUpdate("BP10032_003: Login as user 1 and Verify Approved IBA", true);

                #region Login
                _IISLOGIN();
                #endregion

                #region Navigate to File
                Reports.TestStep = "Enter file number.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileData.FileNumber);
                #endregion

                #region Navigate to IBA screen and checking for the status. Add button is enabled once transaction is completed
                Reports.TestStep = "Navigate to IBA screen and checking for the status. Add button is enabled once transaction is completed.";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.TransactionTab.FAClick();
                FastDriver.InterestBearingAccounts.WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(4, "10.00", 7, TableAction.Click);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.IBATransactionStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "perform preview.";
                FastDriver.InterestBearingAccounts.SwitchToContentFrame();
                FastDriver.InterestBearingAccounts.DeliveryMethod.FASelectItem("Preview");
                FastDriver.InterestBearingAccounts.Deliver.FAClick();

                FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);

                #endregion


                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region PRIVATE METHODS

        private OrderDetailsResponse _CreateFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";

            customizableFileRequest.File.Properties = new Property[]
            {
                new Property()
                {
                    PropertyAddress = new PhysicalAddress[]
                    {
                        new PhysicalAddress()
                        {
                            State = "CA",
                            City = "ALBANY",
                            County = "ALAMEDA",
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        }
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                }
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        }
                };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File;
        }

        private void _IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void _ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);

        }

        private bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}