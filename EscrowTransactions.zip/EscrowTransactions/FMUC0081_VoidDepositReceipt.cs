﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;


namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0081 : MasterTestClass
    {
        #region BAT
        [TestMethod]
        public void FMUC0081_BAT0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[] 
                    { 
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY" 
                        }
                    };
                #endregion

                Reports.TestDescription = "MF1_00: Void the Deposit";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad(FastDriver.DepositInEscrow.Amount);
                FastDriver.DepositInEscrow.Deposit(new DepositParameters() { Amount = 10.00, TypeofFunds = "Cash", Representing = "Additional Closing Costs", Description = "Sanity Deposit In Escrow", ReceivedFrom = "Buyer" });
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Create a Deposit and click on History button.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad(FastDriver.DepositInEscrow.History);
                FastDriver.DepositInEscrow.History.FAClick();

                Reports.TestStep = "Navigate to Deposit Summary and validate the Deposit amount.";
                FastDriver.DepositSummary.WaitForScreenToLoad(FastDriver.DepositSummary.Receipts_DepositActivitytable);
                var val = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "10.00", "Description", TableAction.GetText).Message.Clean();
                Support.AreEqual("Sanity Deposit In Escrow", val, "Amount 10.00 Description");
                FastDriver.DepositSummary.Void.FAClick();

                Reports.TestStep = "Deposit Summary.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Reason to void the Deposit");
                FastDriver.VoidDlg.OK.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Void", false, 15);

                Reports.TestStep = "Navigate to Deposit Summary and validate the Deposit void.";
                FastDriver.DepositSummary.WaitForScreenToLoad(FastDriver.DepositSummary.Receipts_DepositActivitytable);
                val = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Status", "Void", "Description", TableAction.GetText).Message.Clean();
                Support.AreEqual("Reason to void the Deposit", val, "Void Description");

                Reports.TestStep = "Navigate to Deposit Summary and validate the Deposit Totals.";
                Support.AreEqual("False", FastDriver.DepositSummary.Net3300.IsVisible().ToString(), "Net3300 IsVisible");

                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.Net3300.IsVisible().ToString(), "Net3300 IsVisible");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0081_BAT0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[] 
                    { 
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY" 
                        }
                    };
                #endregion

                Reports.TestDescription = "MF1_01: Cancel the Void";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad(FastDriver.DepositInEscrow.Amount);
                FastDriver.DepositInEscrow.Deposit(new DepositParameters() { Amount = 10.00, TypeofFunds = "Cash", Representing = "Additional Closing Costs", Description = "Sanity Deposit In Escrow", ReceivedFrom = "Buyer" });
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Create a Deposit and click on History button.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad(FastDriver.DepositInEscrow.History);
                FastDriver.DepositInEscrow.History.FAClick();

                Reports.TestStep = "Navigate to Deposit Summary and validate the Deposit amount.";
                FastDriver.DepositSummary.WaitForScreenToLoad(FastDriver.DepositSummary.Receipts_DepositActivitytable);
                var val = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "10.00", "Description", TableAction.GetText).Message.Clean();
                Support.AreEqual("Sanity Deposit In Escrow", val, "Amount 10.00 Description");
                FastDriver.DepositSummary.Void.FAClick();

                Reports.TestStep = "Deposit Summary.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Reason to void the Deposit");
                FastDriver.VoidDlg.Cancel.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Void", false, 15);

                Reports.TestStep = "Navigate to Deposit Summary and validate the Deposit amount.";
                FastDriver.DepositSummary.WaitForScreenToLoad(FastDriver.DepositSummary.Receipts_DepositActivitytable);
                val = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "10.00", "Payor", TableAction.GetText).Message.Clean();
                Support.AreEqual("Buyer1Firstname Buyer1Lastname", val, "Amount 10.00 Description");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region REG
        [TestMethod]
        public void FMUC0081_REG0001() //merges REG0001 and REG0002
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[] 
                    { 
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY" 
                        }
                    };
                #endregion

                Reports.TestDescription = "BR_FM3883: Validate transmission date";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad(FastDriver.DepositInEscrow.Amount);
                FastDriver.DepositInEscrow.Deposit(new DepositParameters() { Amount = 10.00, TypeofFunds = "Cash", Representing = "Additional Closing Costs", Description = "Sanity Deposit In Escrow", ReceivedFrom = "Buyer" });
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Navigate to Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad(FastDriver.DepositSummary.Receipts_DepositActivitytable);

                Reports.TestStep = "Highlight the deposit for 10$.";
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "10.00", "Amount", TableAction.Click);

                Reports.TestStep = "Click on View Details button.";
                FastDriver.DepositSummary.ViewDetails.FAClick();

                Reports.TestStep = "Verify the Transmission Date is Blank.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.DepositInEscrow.TransmissionDate.FAGetValue().Clean(), "TransmissionDate");

                Reports.TestStep = "Navigate to Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad(FastDriver.DepositSummary.Receipts_DepositActivitytable);

                Reports.TestStep = "Highlight the deposit for 10$.";
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "10.00", "Amount", TableAction.Click);

                Reports.TestStep = "Click on Void button.";
                FastDriver.DepositSummary.Void.FAClick();

                Reports.TestStep = "Deposit Summary.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Reason to void the Deposit");
                FastDriver.VoidDlg.OK.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Void", false, 15);

                Reports.TestStep = "BR_FM3884: Cannot void a void tx: Verify Void Button is Disabled.";
                FastDriver.DepositSummary.WaitForScreenToLoad(FastDriver.DepositSummary.Void);
                Support.AreEqual("False", FastDriver.DepositSummary.Void.IsEnabled().ToString(), "Void IsEnabled");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0081_REG0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[] 
                    { 
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY" 
                        }
                    };
                #endregion

                Reports.TestDescription = "MF1_00: Void the Deposit";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad(FastDriver.DepositInEscrow.Amount);
                FastDriver.DepositInEscrow.Deposit(new DepositParameters() { Amount = 10.00, TypeofFunds = "Cash", Representing = "Additional Closing Costs", Description = "Sanity Deposit In Escrow", ReceivedFrom = "Buyer" });
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Navigate to Deposit Summary and validate the payor and Tp.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad(FastDriver.DepositSummary.Receipts_DepositActivitytable);
                var val = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Tp", "R", "Payor", TableAction.GetText).Message.Clean();
                Support.AreEqual("Buyer1Firstname Buyer1Lastname", val, "Tp R Payor");

                Reports.TestStep = "Navigate to Deposit Summary and validate the Deposit amount.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad(FastDriver.DepositSummary.Receipts_DepositActivitytable);
                val = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Description", "Sanity Deposit In Escrow", "Amount", TableAction.GetText).Message.Clean();
                Support.AreEqual("10.00", val, "Deposit amount");
                FastDriver.DepositSummary.Void.FAClick();

                Reports.TestStep = "Deposit Summary.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Reason to void the Deposit");
                FastDriver.VoidDlg.OK.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Void", false, 15);

                Reports.TestStep = "Navigate to Deposit Summary and validate the Deposit void.";
                FastDriver.DepositSummary.WaitForScreenToLoad(FastDriver.DepositSummary.Receipts_DepositActivitytable);
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Status", "Void", "Description", TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0081_REG0004() //merges REG0004, REG0005 A, B and C, and REG0006
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[] 
                    { 
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY" 
                        }
                    };
                #endregion

                Reports.TestDescription = "BR_FM3882: Void receipt not yet in accounting";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad(FastDriver.DepositInEscrow.Amount);
                FastDriver.DepositInEscrow.Deposit(new DepositParameters() { Amount = 10.00, TypeofFunds = "Cash", Representing = "Additional Closing Costs", Description = "Sanity Deposit In Escrow", ReceivedFrom = "Buyer" });
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "FROM REG0005A: Verify for build extract enabled status";
                FastDriver.LeftNavigation.Navigate<TrustAccounting>("Home>Business Unit Processing>Trust Accounting Interface").WaitForScreenToLoad(FastDriver.TrustAccounting.DiscardExtract);
                Support.AreEqual("True", FastDriver.TrustAccounting.DiscardExtract.IsEnabled().ToString(), "DiscardExtract IsEnabled");

                Reports.TestStep = "FROM REG0005B: Verify for build extract enabled status";
                FastDriver.TrustAccounting.DiscardExtract.FAClick();

                Reports.TestStep = "FROM REG0005C: BR_FM3882_1; Verify for build extract enabled status";
                FastDriver.TrustAccounting.WaitForScreenToLoad(FastDriver.TrustAccounting.BuildExtract);
                Support.AreEqual("True", FastDriver.TrustAccounting.BuildExtract.IsEnabled().ToString(), "BuildExtract IsEnabled");

                Reports.TestStep = "FROM REG0006: BR_FM3882_2: BR_FM3882_1(This test will pass if build extract is enabled)";
                FastDriver.TrustAccounting.BuildExtract.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Naviagte to Trust32 screen.";
                FastDriver.LeftNavigation.Navigate<TrustAccounting>("Home>Business Unit Processing>Trust Accounting Interface").WaitForScreenToLoad(FastDriver.TrustAccounting.TransmitNow);

                Reports.TestStep = "Click on Trasmit Now button.";
                FastDriver.TrustAccounting.TransmitNow.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Navigate to Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad(FastDriver.DepositSummary.Receipts_DepositActivitytable);

                Reports.TestStep = "Highlight the deposit for 10$.";
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "10.00", "Amount", TableAction.Click);

                Reports.TestStep = "Click on View Details button.";
                FastDriver.DepositSummary.ViewDetails.FAClick();

                Reports.TestStep = "Verify the Transmission Date is present.";
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DepositInEscrow.TransmissionDate.FAGetValue(), "TransmissionDate");

                Reports.TestStep = "Navigate to Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad(FastDriver.DepositSummary.Receipts_DepositActivitytable);

                Reports.TestStep = "Highlight the deposit for 10$.";
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "10.00", "Amount", TableAction.Click);

                Reports.TestStep = "Verify Void Button is Disabled.";
                Support.AreEqual("False", FastDriver.DepositSummary.Void.IsEnabled().ToString(), "Void IsEnabled");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0081_REG0007()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[] 
                    { 
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY" 
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY" 
                        }
                    };
                #endregion

                Reports.TestDescription = "FD_1: Verify Void Dialog accepts 45 chars";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad(FastDriver.DepositInEscrow.Amount);
                FastDriver.DepositInEscrow.Deposit(new DepositParameters() { Amount = 10.00, TypeofFunds = "Cash", Representing = "Additional Closing Costs", Description = "Sanity Deposit In Escrow", ReceivedFrom = "Buyer" });
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Navigate to Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad(FastDriver.DepositSummary.Receipts_DepositActivitytable);

                Reports.TestStep = "Highlight the deposit for 10$.";
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "10.00", "Amount", TableAction.Click);

                Reports.TestStep = "Click on Void button.";
                FastDriver.DepositSummary.Void.FAClick();

                Reports.TestStep = "Verify Void Reason for 44 Chars.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Enteringfortyfourcharacterstoverifyvoidreaso");
                Support.AreEqual("Enteringfortyfourcharacterstoverifyvoidreaso", FastDriver.VoidDlg.VoidReason.FAGetValue().Clean(), "VoidReason");

                Reports.TestStep = "Clear data.";
                FastDriver.VoidDlg.VoidReason.FASetText("");

                Reports.TestStep = "Verify Void Reason for 45 Chars.";
                FastDriver.VoidDlg.VoidReason.FASetText("Enteringfortyfourcharacterstoverifyvoidreason");
                Support.AreEqual("Enteringfortyfourcharacterstoverifyvoidreason", FastDriver.VoidDlg.VoidReason.FAGetValue().Clean(), "VoidReason");
                FastDriver.VoidDlg.OK.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Void", false, 15);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}