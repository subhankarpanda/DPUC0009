﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.Common;
using FASTWCFHelpers.FastFileService;

namespace EscrowTransactions
{
    [CodedUITest]
    [DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class FMUC0093 : MasterTestClass
    {

        #region REG

        #region FMUC0093_REG0001
        [TestMethod]
        public void FMUC0093_REG0001()
        {
            try
            {
                Reports.TestDescription = "MFA_AF_001: Assign File Charges to HUD-1 Line numbers and Verify Number Assignment in Charge Process";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic HUD file";
                CreateBasicHUDFile();

                Reports.TestStep = "Navigate to New Loan screen, enter GAB code click Find";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                Reports.TestStep = "Click Loan Charges tab, enter loan charges details.";
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercharge.FASetText("40.00");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesdescription8.FASetText("Test HUD Line 808");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FASetText("");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge8.FASetText("80.00");
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback.FAClick();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_BuyerCharge.FASetText("90.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "To select earthquake insurance and click on Edit button in Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Insurancerows.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "To enter data in earthquake insurance.";
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                FastDriver.InsuranceEarth.EarthGABcode.FASetText("HUDFRINSR1");
                FastDriver.InsuranceEarth.EarthFind.FAClick();
                FastDriver.InsuranceEarth.EarthBuyerCharge.FASetText("600.00");

                Reports.TestStep = "ASSIGN FILE CHARGES TO HUD-1 LINE NUMBERS.";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand104Section.FAClick();

                Reports.TestStep = "Validate line 104+";
                Support.AreEqual("104", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess104textbox.FAGetValue().Clean());
                Support.AreEqual("104", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess105textbox.FAGetValue().Clean());
                FastDriver.AssignChargestoHUD1LineNumbers.Expand808Section.FAClick();
                Support.AreEqual("808", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808textbox.FAGetValue().Clean());
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();
                Support.AreEqual("904", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FAGetValue().Clean());

                Reports.TestStep = "To change the HUD line numbers.";
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess105textbox.FASetText("104");
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808textbox.FASetText("810");
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FASetText("910");

                Reports.TestStep = "To verify the HUD line numbers are edited.";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand104Section.FAClick();
                Support.AreEqual("104", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess104textbox.FAGetValue().Clean());
                Support.AreEqual("104", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess105textbox.FAGetValue().Clean());
                FastDriver.AssignChargestoHUD1LineNumbers.Expand808Section.FAClick();
                Support.AreEqual("810", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808textbox.FAGetValue().Clean());
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();
                Support.AreEqual("910", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FAGetValue().Clean());

                Reports.TestStep = "To verify the value of Hudline Number 104,808 and 904.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.ClickChargesTab();
                Support.AreEqual("HUD1 line Number : 104", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercharge.FAGetAttribute("title").Clean());
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FASetText("");
                Support.AreEqual("HUD1 line Number : 808", FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge8.FAGetAttribute("title").Clean());
                Support.AreEqual("HUD1 line Number : 104", FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_BuyerCharge.FAGetAttribute("title").Clean());

                Reports.TestStep = "To select earthquake insurance and click on Edit button in Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Insurancerows.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "To verify HUD1 line number 904.";
                Support.AreEqual("HUD1 line Number : 910", FastDriver.InsuranceEarth.EarthBuyerCharge.FAGetAttribute("title").Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        /*
         * Legacy HUD is no longer support
        #region FMUC0093_REG0002
        [TestMethod]
        public void FMUC0093_REG0002()
        {
            try
            {
                Reports.TestDescription = "MFB_AF_001: Assign File Charges to HUD-1 Line numbers and Verify Number Assignment in Charge Process in legacy file";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic HUD file";
                CreateBasicHUDFile("HUDFLINSR1");

                Reports.TestStep = "Navigate to New Loan screen, enter GAB code click Find";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                Reports.TestStep = "Set an instance of the Lease Details with charge amount.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.GABcode.FASetText("HUDLEASE03");
                FastDriver.LeaseDetail.Find.FAClick();
                FastDriver.LeaseDetail.BuyerCharge.FASetText("0.8");

                Reports.TestStep = "ASSIGN FILE CHARGES TO HUD-1 LINE NUMBER 1303.";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand1303Section.FAClick();
                Support.AreEqual("1303", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess1303textbox.FAGetValue().Clean());

                Reports.TestStep = "To change the HUD line numbers in 1303.";
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess1303textbox.FASetText("1306");

                Reports.TestStep = "To verify the HUD line number 1303 is edited.";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand1303Section.FAClick();
                Support.AreEqual("1306", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess1303textbox.FAGetValue().Clean());

                Reports.TestStep = "To verify the edited HUD line number of the Buyer charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                Support.AreEqual("HUD1 line Number : 1306", FastDriver.LeaseDetail.BuyerCharge.FAGetAttribute("title").Clean());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion
        */

        #region FMUC0093_REG0002
        [TestMethod]
        public void FMUC0093_REG0002()
        {
            try
            {
                Reports.TestDescription = "BR_ES10909A: Conditions to Display Charges";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic HUD file";
                CreateBasicHUDFile("HUDFLINSR1");

                Reports.TestStep = "Enter Principal Balance Buyer Charge.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercharge.FASetText("40.00");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesdescription8.FASetText("Test HUD Line 808");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FASetText("");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge8.FASetText("80.00");
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback.FAClick();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_BuyerCharge.FASetText("90.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "To select earthquake insurance and click on Edit button in Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Insurancerows.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "To enter data in earthquake insurance.";
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                FastDriver.InsuranceEarth.EarthGABcode.FASetText("HUDFRINSR1");
                FastDriver.InsuranceEarth.EarthFind.FAClick();
                FastDriver.InsuranceEarth.EarthBuyerCharge.FASetText("600.00");

                Reports.TestStep = "Expand 104+ section.";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand104Section.FAClick();

                Reports.TestStep = "ASSIGN FILE CHARGES TO HUD-1 LINE NUMBERS.";
                Support.AreEqual("104", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess104textbox.FAGetValue().Clean());

                Reports.TestStep = "Expand 808+ section.";
                FastDriver.AssignChargestoHUD1LineNumbers.Expand808Section.FAClick();
                Support.AreEqual("808", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808textbox.FAGetValue().Clean());

                Reports.TestStep = "Expand 904+ section.";
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();
                Support.AreEqual("904", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FAGetValue().Clean());

                Reports.TestStep = "To change the HUD line numbers.";
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess105textbox.FASetText("104");
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808textbox.FASetText("810");
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FASetText("910");

                Reports.TestStep = "Expand 104+ section, 808+ section, and 904+ section";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand104Section.FAClick();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand808Section.FAClick();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();

                Reports.TestStep = "To verify the HUD line numbers are edited.";
                Support.AreEqual("104", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess104textbox.FAGetValue().Clean());
                Support.AreEqual("810", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808textbox.FAGetValue().Clean());
                Support.AreEqual("910", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FAGetValue().Clean());

                Reports.TestStep = "To verify the value of Hudline Number 104,808 and 904.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.ClickChargesTab();
                Support.AreEqual("HUD1 line Number : 104", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercharge.FAGetAttribute("title").Clean());
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FASetText("");
                Support.AreEqual("HUD1 line Number : 808", FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge8.FAGetAttribute("title").Clean());
                Support.AreEqual("HUD1 line Number : 104", FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_BuyerCharge.FAGetAttribute("title").Clean());

                Reports.TestStep = "To select earthquake insurance and click on Edit button in Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Insurancerows.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "To verify HUD1 line number 904.";
                Support.AreEqual("HUD1 line Number : 910", FastDriver.InsuranceEarth.EarthBuyerCharge.FAGetAttribute("title").Clean());
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region FMUC0093_REG0003
        [TestMethod]
        public void FMUC0093_REG0003()
        {
            try
            {
                Reports.TestDescription = "BR_ES10910_ES10914_ES10912_ES10911: Hud-1 Line Numbered Sections";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic HUD file";
                CreateBasicHUDFile("HUDFLINSR1");

                Reports.TestStep = "Select the Fire Insurance from Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "Create an instance of fire Insurance.";
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("HUDFRINSR1");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("100.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Flood Insurance from Summary.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "Create an instance of Flood Insurance.";
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                FastDriver.Insuranceflood.FloodGABcode.FASetText("HUDFRINSR1");
                FastDriver.Insuranceflood.FloodFind.FAClick();
                Playback.Wait(5000);
                FastDriver.Insuranceflood.FloodBuyercharge.FASetText("100.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Wind Insurance from Summary.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "Create an instance of Wind Insurance.";
                FastDriver.InsuranceWind.WaitForScreenToLoad();
                FastDriver.InsuranceWind.WindGABcode.FASetText("HUDFRINSR1");
                FastDriver.InsuranceWind.WindFind.FAClick();
                FastDriver.InsuranceWind.WindBuyerCharge.FASetText("100.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Earthquake Insurance from Summary.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "To enter data in earthquake insurance.";
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                FastDriver.InsuranceEarth.EarthGABcode.FASetText("HUDFRINSR1");
                FastDriver.InsuranceEarth.EarthFind.FAClick();
                FastDriver.InsuranceEarth.EarthBuyerCharge.FASetText("600.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create an instance of other Insurance.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "To enter data in other insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherGABcode.FASetText("HUDFRINSR1");
                FastDriver.InsuranceOther.OtherFind.FAClick();
                FastDriver.InsuranceOther.OtherInsuranceChargeDescription.FASetText("Insurance Premium Description");
                FastDriver.InsuranceOther.OtherBuyerCharge.FASetText("100.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Expand 904+ section.";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();

                Reports.TestStep = "To verify the 904 line no-second row.";
                Support.AreEqual("904", FastDriver.AssignChargestoHUD1LineNumbers.Row2ChargeProcess904textbox.FAGetValue().Clean());
                Support.AreEqual("Wind insurance premium", FastDriver.AssignChargestoHUD1LineNumbers.Row2Description.FAGetText().Clean());

                Reports.TestStep = "To verify the 904 line no-fourth row.";
                Support.AreEqual("904", FastDriver.AssignChargestoHUD1LineNumbers.Row4ChargeProcess904textbox.FAGetValue().Clean());
                Support.AreEqual("Insurance Premium Description", FastDriver.AssignChargestoHUD1LineNumbers.Row4Description.FAGetText().Clean());

                Reports.TestStep = "To verify the 904 line no-first row.";
                Support.AreEqual("904", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FAGetValue().Clean());
                Support.AreEqual("Flood insurance premium", FastDriver.AssignChargestoHUD1LineNumbers.Row1Description.FAGetText().Clean());

                Reports.TestStep = "To verify the 904 line no-third row.";
                Support.AreEqual("904", FastDriver.AssignChargestoHUD1LineNumbers.Row3ChargeProcess904textbox.FAGetValue().Clean());
                Support.AreEqual("Earthquake insurance premium", FastDriver.AssignChargestoHUD1LineNumbers.Row3Description.FAGetText().Clean());

                Reports.TestStep = "To change line no for 904 line no-first row and second row.";
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FASetText("906");
                FastDriver.AssignChargestoHUD1LineNumbers.Row2ChargeProcess904textbox.FASetText("905");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Expand 904+ section.";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();

                Reports.TestStep = "To verify the 904 line no-fourth row.";
                Support.AreEqual("906", FastDriver.AssignChargestoHUD1LineNumbers.Row4ChargeProcess904textbox.FAGetValue().Clean());
                Support.AreEqual("Flood insurance premium", FastDriver.AssignChargestoHUD1LineNumbers.Row4Description.FAGetText().Clean());

                Reports.TestStep = "To verify the 904 line no-first row.";
                Support.AreEqual("904", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FAGetValue().Clean());
                Support.AreEqual("Earthquake insurance premium", FastDriver.AssignChargestoHUD1LineNumbers.Row1Description.FAGetText().Clean());

                Reports.TestStep = "To verify the 904 line no-second row.";
                Support.AreEqual("904", FastDriver.AssignChargestoHUD1LineNumbers.Row2ChargeProcess904textbox.FAGetValue().Clean());
                Support.AreEqual("Insurance Premium Description", FastDriver.AssignChargestoHUD1LineNumbers.Row2Description.FAGetText().Clean());

                Reports.TestStep = "To verify the 904 line no-third row.";
                Support.AreEqual("905", FastDriver.AssignChargestoHUD1LineNumbers.Row3ChargeProcess904textbox.FAGetValue().Clean());
                Support.AreEqual("Wind insurance premium", FastDriver.AssignChargestoHUD1LineNumbers.Row3Description.FAGetText().Clean());

                Reports.TestStep = "To change line no for 904 line no-first row.";
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FASetText("905");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Error message for assign same HUD line no to multiple charges in Assign HUD-1 Line Number screen.";
                Support.AreEqual("The HUD line number 905 cannot be used twice", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean());
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Expand 904+ section.";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();

                Reports.TestStep = "To change line no for 904 line no-third row.";
                FastDriver.AssignChargestoHUD1LineNumbers.Row3ChargeProcess904textbox.FASetText("904");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Flood Insurance from Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "To verify HUD1 line number 904.";
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                Support.AreEqual("HUD1 line Number : 906", FastDriver.Insuranceflood.FloodBuyercharge.FAGetAttribute("title"));

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region FMUC0093_REG0004
        [TestMethod]
        public void FMUC0093_REG0004()
        {
            try
            {
                Reports.TestDescription = "BR_ES10915_ES10913 : Prevent Editing 1303+ Section";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic HUD file";
                CreateBasicHUDFile("HUDFLINSR1");

                Reports.TestStep = "Set an instance of the Lease Details with charge amount.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.GABcode.FASetText("HUDLEASE03");
                FastDriver.LeaseDetail.Find.FAClick();
                FastDriver.LeaseDetail.BuyerCharge.FASetText("0.8");

                Reports.TestStep = "Expand 1303+ section.";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand1303Section.FAClick();

                Reports.TestStep = "To verify that HUD-Line no 1303 does not exist in HUD file.";
                Support.AreEqual("False", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess1303textbox.IsDisplayed().ToString());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region FMUC0093_REG0005
        [TestMethod]
        public void FMUC0093_REG0005()
        {
            try
            {
                Reports.TestDescription = "BR_ES10913A_FDchgprss_Fdhudeno_Fdchgdesc: Line Number Entry Ranges";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic HUD file";
                CreateBasicHUDFile("HUDFLINSR1");

                Reports.TestStep = "Enter Principal Balance Buyer Charge.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("HUDASLNDR1");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                Reports.TestStep = "Click Loan Charges tab, enter loan charges details.";
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercharge.FASetText("40.00");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesdescription8.FASetText("Test HUD Line 808");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FASetText("");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge8.FASetText("80.00");
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback.FAClick();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_BuyerCharge.FASetText("90.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "To select earthquake insurance and click on Edit button in Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "To enter data in earthquake insurance.";
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                FastDriver.InsuranceEarth.EarthGABcode.FASetText("HUDFRINSR1");
                FastDriver.InsuranceEarth.EarthFind.FAClick();
                FastDriver.InsuranceEarth.EarthBuyerCharge.FASetText("600.00");

                Reports.TestStep = "Expand 104+, 808+, and 904+ sections";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand104Section.FAClick();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand808Section.FAClick();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();

                Reports.TestStep = "ASSIGN FILE CHARGES TO HUD-1 LINE NUMBERS.";
                Support.AreEqual("808", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808textbox.FAGetValue().Clean());
                Support.AreEqual("904", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FAGetValue().Clean());

                Reports.TestStep = "To change the HUD line numbers.";
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess105textbox.FASetText("104");
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808textbox.FASetText("810");
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FASetText("910");

                Reports.TestStep = "Expand 104+, 808+, and 904+ sections";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand104Section.FAClick();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand808Section.FAClick();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();

                Reports.TestStep = "To verify the HUD line numbers are edited.";
                Support.AreEqual("104", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess104textbox.FAGetValue().Clean());
                Support.AreEqual("104", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess105textbox.FAGetValue().Clean());
                Support.AreEqual("810", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808textbox.FAGetValue().Clean());
                Support.AreEqual("910", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FAGetValue().Clean());

                Reports.TestStep = "To verify the value of Hudline Number 104,808 and 904.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.ClickChargesTab();
                Support.AreEqual("HUD1 line Number : 104", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercharge.FAGetAttribute("title").Clean());
                Support.AreEqual("HUD1 line Number : 808", FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge8.FAGetAttribute("title").Clean());
                Support.AreEqual("HUD1 line Number : 104", FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_BuyerCharge.FAGetAttribute("title").Clean());

                Reports.TestStep = "To select earthquake insurance and click on Edit button in Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "To verify HUD1 line number 904.";
                Support.AreEqual("HUD1 line Number : 910", FastDriver.InsuranceEarth.EarthBuyerCharge.FAGetAttribute("title").Clean());

                Reports.TestStep = "Expand 808+ and 904+ sections";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand808Section.FAClick();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();

                Reports.TestStep = "To change the HUD line numbers.";
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808textbox.FASetText("850");
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FASetText("950");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Expand 808+ and 904+ sections";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand808Section.FAClick();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();

                Reports.TestStep = "To verify the HUD line numbers are edited.";
                Support.AreEqual("850", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808textbox.FAGetValue().Clean());
                Support.AreEqual("950", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FAGetValue().Clean());

                Reports.TestStep = "To verify the value of Hudline Number 808";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.ClickChargesTab();
                Support.AreEqual("HUD1 line Number : 808", FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge8.FAGetAttribute("title").Clean());

                Reports.TestStep = "To select earthquake insurance and click on Edit button in Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "To verify HUD1 line number 904.";
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                Support.AreEqual("HUD1 line Number : 950", FastDriver.InsuranceEarth.EarthBuyerCharge.FAGetAttribute("title").Clean());

                Reports.TestStep = "Expand 808+ and 904+ sections";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand808Section.FAClick();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();

                Reports.TestStep = "To change the HUD line numbers.";
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808textbox.FASetText("899");
                FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FASetText("999");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Expand 808+ and 904+ sections";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand808Section.FAClick();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();

                Reports.TestStep = "To verify the HUD line numbers are edited.";
                Support.AreEqual("899", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808textbox.FAGetValue().Clean());
                Support.AreEqual("999", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904textbox.FAGetValue().Clean());

                Reports.TestStep = "To verify the value of Hudline Number 104,808 and 904.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.ClickChargesTab();
                Support.AreEqual("HUD1 line Number : 808", FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge8.FAGetAttribute("title").Clean());

                Reports.TestStep = "To select earthquake insurance and click on Edit button in Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "To verify HUD1 line number 904.";
                Support.AreEqual("HUD1 line Number : 999", FastDriver.InsuranceEarth.EarthBuyerCharge.FAGetAttribute("title").Clean());

                Reports.TestStep = "Expand 104+, 808+, and 904+ sections";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand104Section.FAClick();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand808Section.FAClick();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand904Section.FAClick();

                Reports.TestStep = "To verify the HUD Line description and charge processes.";
                Support.AreEqual("Construction holdback", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess105Row1Description.FAGetText().Clean());
                Support.AreEqual("New Loan 1 Charges", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess105Row1chargeprocess.FAGetText().Clean());
                Support.AreEqual("Test HUD Line 808", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808Row1Description.FAGetText().Clean());
                Support.AreEqual("New Loan 1 Lender", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess808Row1chargeprocess.FAGetText().Clean());
                Support.AreEqual("Insurance - Earthquake", FastDriver.AssignChargestoHUD1LineNumbers.ChargeProcess904Row1chargeprocess.FAGetText().Clean());
                Support.AreEqual("Earthquake insurance premium", FastDriver.AssignChargestoHUD1LineNumbers.Row1Description.FAGetText().Clean());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region FMUC0093_REG0006
        [TestMethod]
        public void FMUC0093_REG0006()
        {
            try
            {
                Reports.TestDescription = "ESXXXX : 404+ Charges prioritized order";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic HUD file";
                CreateBasicHUDFile("HUDFLINSR1");

                Reports.TestStep = "Create Misc Adjustment Instance.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.description2.FASetText("Misc Adj Desc 1" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.AdjustmentMisc.SellerCredit2.FASetText("5.00");
                FastDriver.BottomFrame.Done();

                FastDriver.WebDriver.WaitForActionToComplete(() => 
                {
                    Reports.TestStep = "Create a Assumption Loan Instance with Charges.";
                    FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                    FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR1");
                    FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                    FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                    FastDriver.AssumptionLoanCharges.WaitForScreenToLoad(FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCredit1);
                    FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCredit1.FASetText("4.00");
                    FastDriver.BottomFrame.Done();
                    return true;
                }, timeout: 60, idleInterval: 10);

                Reports.TestStep = "Create Instance, Enter TAX ID,FIELD DEF for Description ,Buyer Charge, Buyer Credit ,seller Charge and Seller Credit Tex Boxes.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.Reference.FASetText("12345678");
                FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FASetText("AlphaNumeric45CharactersAsChargeDescription10212");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("12345678910.2345");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.FASetText("12345678910.2345");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("12345678910.2345");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FASetText("12345678910.2345");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Credit Buyer's (Selling) Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("600.00");
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("700.00");
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Credit to Buyer Seller" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText("75.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter charges to New loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("300000000");
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Give the GFE 3 new charges details.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FASetText("10.00");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCredit.FASetText("20.00");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCharge.FASetText("30.00");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCredit.FASetText("40.00");

                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Enter 2nd loan instance.";
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("250");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCredit.FASetText("5.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Expand 404+ section.";
                FastDriver.LeftNavigation.Navigate<AssignChargestoHUD1LineNumbers>(@"Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers").WaitForScreenToLoad();
                FastDriver.AssignChargestoHUD1LineNumbers.Expand404Section.FAClick();

                Reports.TestStep = "Verify the contents of Charge Group of 404+ section.";
                Support.AreEqual("Adjustments", FastDriver.AssignChargestoHUD1LineNumbers.FourZeroFourSectionTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Verify the contents of Charge Group of 404+ section.";
                Support.AreEqual("Real Estate Broker Credits", FastDriver.AssignChargestoHUD1LineNumbers.FourZeroFourSectionTable.PerformTableAction(4, 2, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Verify the contents of Charge Group of 404+ section.";
                Support.AreEqual("Assumption Loan", FastDriver.AssignChargestoHUD1LineNumbers.FourZeroFourSectionTable.PerformTableAction(6, 3, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Verify the contents of Charge Group of 404+ section.";
                Support.AreEqual("New Loan 2+ Lender", FastDriver.AssignChargestoHUD1LineNumbers.FourZeroFourSectionTable.PerformTableAction(8, 3, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Verify the contents of Charge Group of 404+ section.";
                Support.AreEqual("New Loan 1 Lender", FastDriver.AssignChargestoHUD1LineNumbers.FourZeroFourSectionTable.PerformTableAction(10, 3, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Verify the contents of Charge Group of 404+ section.";
                Support.AreEqual("Property Tax Check", FastDriver.AssignChargestoHUD1LineNumbers.FourZeroFourSectionTable.PerformTableAction(12, 3, TableAction.GetText).Message.Clean());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion REG

        #region Private Methods

        private void LoginFastFileSite(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void CreateBasicHUDFile(string GABCode = "HUDFLINSR1")
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.EmployeeObjectCD = "";
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode);
            customizableFileRequest.formType = FormType.HUD;
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        #endregion Private Methods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
