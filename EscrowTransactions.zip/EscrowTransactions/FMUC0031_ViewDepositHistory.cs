﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.Common;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.DataObjects.IIS;

namespace EscrowTransactions
{
    [CodedUITest]
    [DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class FMUC0031 : MasterTestClass
    {

        #region REG

        #region FMUC0031_REG0001
        [TestMethod]
        public void FMUC0031_REG0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Create Deposits and View Deposit Summary";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposit In Escrow screen";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Making a cash deposit.";
                #region deposit data
                var deposit = new DepositParameters()
                {
                    Amount = 101.01,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receit History screen, validate deposit details";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, deposit.Amount.ToString().FormatAsMoney(), 5, TableAction.GetText).Message);
                Support.AreEqual(deposit.Payor, FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, deposit.Amount.ToString().FormatAsMoney(), 7, TableAction.GetText).Message);
                Support.AreEqual(deposit.Description, FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, deposit.Amount.ToString().FormatAsMoney(), 8, TableAction.GetText).Message);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region FMUC0031_REG0002
        [TestMethod]
        public void FMUC0031_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM1344_FM1395_FM1452_FM3231_FM3232_FM3233 : Adjustment amounts";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposit In Escrow screen";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Making a cash deposit.";
                #region deposit data
                var deposit = new DepositParameters()
                {
                    Amount = 10.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receit History screen, select the deposit, click Adjust";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, deposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.Adjust.FAClick();

                Reports.TestStep = "Enter adjustment information";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("NSF");
                FastDriver.DepositAdjustment.Comment.FASetText("Adjusted for NSF");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the NSF Adjustment";
                FastDriver.DepositReceiptHistory.WaitForScreenToLoad();
                Support.AreEqual("NSF " + DateTime.Now.ToDateString(), FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, deposit.Amount.ToString().FormatAsMoney() + "-", 8, TableAction.GetText).Message);

                Reports.TestStep = "Create a direct deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Making a direct deposit with manual receipt number";
                FastDriver.DepositInEscrow.Manual.FAClick();
                string manualReceiptNumber = Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(manualReceiptNumber, clearFirst: false);
                #region deposit data
                var directDeposit = new DepositParameters()
                {
                    Amount = 55.00,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(directDeposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Enter manual deposit reason";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receit History screen, select the deposit, click Adjust";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, directDeposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.Adjust.FAClick();

                Reports.TestStep = "Enter adjustment information";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Bank Acct");
                FastDriver.DepositAdjustment.Payorname.FASetText("BuyerName Changed");
                FastDriver.DepositAdjustment.CorrectBankAccountEnabled.FASelectItemByIndex(2);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Correct Bank acct Adjustment.";
                FastDriver.DepositReceiptHistory.WaitForScreenToLoad();
                Support.AreEqual("Correct Bank Acct " + DateTime.Now.ToDateString(), FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, "0.00", 8, TableAction.GetText).Message);

                Reports.TestStep = "Deposit a cash for 1000$ with Fund type as Credit card.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Making a credit card deposit.";
                #region deposit data
                var cardDeposit = new DepositParameters()
                {
                    Amount = 1000.00,
                    TypeofFunds = "Credit Card",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(cardDeposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receit History screen, select the deposit, click Adjust";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, cardDeposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.Adjust.FAClick();

                Reports.TestStep = "Enter adjustment information";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("1500.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Correct Ammount Adjustment.";
                FastDriver.DepositReceiptHistory.WaitForScreenToLoad();
                Support.AreEqual("Adjusted", FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, cardDeposit.Amount.ToString().FormatAsMoney(), 1, TableAction.GetText).Message);
                Support.AreEqual("Correct Amount " + DateTime.Now.ToDateString(), FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, cardDeposit.Amount.ToString().FormatAsMoney() + "-", 8, TableAction.GetText).Message);
                Support.AreEqual("Correct Amount " + DateTime.Now.ToDateString(), FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, "1,500.00", 8, TableAction.GetText).Message);

                Reports.TestStep = "Validation for Cancel type adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Deposit a personal check";
                FastDriver.DepositInEscrow.Manual.FAClick();
                string manualReceiptNumber2 = Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(manualReceiptNumber2, clearFirst: false);
                #region deposit data
                var checkDeposit = new DepositParameters()
                {
                    Amount = 333.00,
                    TypeofFunds = "Personal Check",
                    Representing = "Initial Deposit",
                    Description = "Initial Deposit",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer",
                    CheckNumber = "1234567889",
                    ABANumber = "1234567895",
                    BankName = "23testbank",
                    AccountNumber = "1234567895"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(checkDeposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Enter manual deposit reason";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receit History screen, select the deposit, click Adjust";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, checkDeposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.Adjust.FAClick();

                Reports.TestStep = "Enter adjustment information";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Test Comments while adjust");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Correct Ammount Adjustment.";
                FastDriver.DepositReceiptHistory.WaitForScreenToLoad();
                Support.AreEqual("Cancel " + DateTime.Now.ToDateString(), FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, checkDeposit.Amount.ToString().FormatAsMoney() + "-", 8, TableAction.GetText).Message);

                Reports.TestStep = "Validation for Correct Document Number type adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Deposit a casher's check";
                FastDriver.DepositInEscrow.Manual.FAClick();
                string manualReceiptNumber3 = Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(manualReceiptNumber3, clearFirst: false);
                #region deposit data
                var cashierCheckDeposit = new DepositParameters()
                {
                    Amount = 444.00,
                    TypeofFunds = "Cashier's Check",
                    Representing = "Initial Deposit",
                    Description = "Initial Deposit",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer",
                    CheckNumber = "1234567889",
                    ABANumber = "1234567895",
                    BankName = "23testbank",
                    AccountNumber = "1234567895"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(cashierCheckDeposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Enter manual deposit reason";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receit History screen, select the deposit, click Adjust";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, cashierCheckDeposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.Adjust.FAClick();

                Reports.TestStep = "Enter adjustment information";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Document No");
                string manualReceiptNumber4 = Support.RandomString("NNNNNNNN");
                FastDriver.DepositAdjustment.CorrectDocumentNoEdit.FASetText(manualReceiptNumber4, clearFirst: false);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Correct Ammount Adjustment.";
                FastDriver.DepositReceiptHistory.WaitForScreenToLoad();
                Support.AreEqual("Correct Document No " + DateTime.Now.ToDateString(), FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(4, manualReceiptNumber4, 8, TableAction.GetText).Message);
                Support.AreEqual("Correct Document No " + DateTime.Now.ToDateString(), FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, cashierCheckDeposit.Amount.ToString().FormatAsMoney() + "-", 8, TableAction.GetText).Message);


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region FMUC0031_REG0003
        [TestMethod]
        public void FMUC0031_REG0003()
        {
            try
            {
                Reports.TestDescription = "ES10062: Prevent Deposit For Credit to Buyer/Seller in Sub Escrow File";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a Tile and Sub-Escrow file";
                CreateTitleAndSubEscrowFile();

                Reports.TestStep = "Navigate to Deposit In Escrow screen";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Making a cash deposit.";
                #region deposit data
                var deposit = new DepositParameters()
                {
                    Amount = 10.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receit History screen, select the deposit, click View Details button";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, deposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.FAClick();

                Reports.TestStep = "Validate deposit details information";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoBuyer.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoSeller.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoOther.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.DepositInEscrow.CredittoOther.IsSelected().ToString());

                Reports.TestStep = "Create Direct Deposit(Manual).";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Making a direct deposit with manual receipt number";
                FastDriver.DepositInEscrow.Manual.FAClick();
                string manualReceiptNumber = Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(manualReceiptNumber, clearFirst: false);
                #region deposit data
                var directDeposit = new DepositParameters()
                {
                    Amount = 8000.00,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(directDeposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Enter manual deposit reason";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receit History screen, select the deposit, click View Details button";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, directDeposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.FAClick();

                Reports.TestStep = "Validate deposit details information";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoBuyer.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoSeller.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoOther.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.DepositInEscrow.CredittoOther.IsSelected().ToString());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region FMUC0031_REG0004
        [TestMethod]
        public void FMUC0031_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM1452: Warning if (-) net deposit amt";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposit In Escrow screen";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Making a cash deposit.";
                #region deposit data
                var cashDeposit = new DepositParameters()
                {
                    Amount = 8000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(cashDeposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receit History screen, select the deposit, click Ad Hoc Adjustment button";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, cashDeposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.AdHocAdjustment.FAClick();

                Reports.TestStep = "Enter adjustment information";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string docNumber1 = Support.RandomString("NNNNNNN");
                FastDriver.DepositAdjustment.AdhocDocNumber.FASetText(docNumber1, clearFirst: false);
                FastDriver.DepositAdjustment.AdhocAmount.FASetText("100.00");
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("NSF");
                FastDriver.DepositAdjustment.Comment.FASetText("Adjusted for NSF");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receit History screen, validate negative deposit amount";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                Support.AreEqual("100.00-", FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(4, docNumber1, 6, TableAction.GetText).Message);

                Reports.TestStep = "Create a direct deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Making a direct deposit with manual receipt number";
                FastDriver.DepositInEscrow.Manual.FAClick();
                string manualReceiptNumber = Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(manualReceiptNumber, clearFirst: false);
                #region deposit data
                var directDeposit = new DepositParameters()
                {
                    Amount = 55.00,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(directDeposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Enter manual deposit reason";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receit History screen, select the deposit, click Ad Hoc Adjustment button";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, directDeposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.AdHocAdjustment.FAClick();

                Reports.TestStep = "Enter adjustment information";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string docNumber2 = Support.RandomString("NNNNNNN");
                FastDriver.DepositAdjustment.AdhocDocNumber.FASetText(docNumber2, clearFirst: false);
                FastDriver.DepositAdjustment.AdhocAmount.FASetText("100.00");
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("NSF");
                FastDriver.DepositAdjustment.Comment.FASetText("Adjusted for NSF");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receit History screen, validate negative deposit amount";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                Support.AreEqual("100.00-", FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(4, docNumber2, 6, TableAction.GetText).Message);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region FMUC0031_REG0005
        [TestMethod]
        public void FMUC0031_REG0005()
        {
            try
            {
                Reports.TestDescription = "FD_1: Workpane Specific Buttons / Icons";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposit/Receit History screen, Validate the status of buttons on Initial load of Summary screen.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.DepositReceiptHistory.ViewDetails.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.DepositReceiptHistory.Adjust.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.DepositReceiptHistory.AdHocAdjustment.IsEnabled().ToString());

                Reports.TestStep = "Navigate to Deposit In Escrow screen, make a cash deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                #region deposit data
                var cashDeposit = new DepositParameters()
                {
                    Amount = 10.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(cashDeposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit History, validate the status of buttons after adding a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.DepositReceiptHistory.ViewDetails.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.DepositReceiptHistory.Adjust.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.DepositReceiptHistory.AdHocAdjustment.IsEnabled().ToString());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region FMUC0031_REG0006
        [TestMethod]
        public void FMUC0031_REG0006()
        {
            try
            {
                // Can't fully test this flow as IBA can't not be open/close on the same day
                // In order for the IBA to show on Deposit/Receipt History, it has to be closed.
                Reports.TestDescription = "ES10066: Show IBA Deposit Receipts on Deposit/Receipt History";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposit In Escrow screen, make a cash deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                #region deposit data
                var cashDeposit = new DepositParameters()
                {
                    Amount = 1000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(cashDeposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                Playback.Wait(250);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Beneficiary, 10);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad(timeout: 15);
                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText(@"Abc" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText(@"Address Line 1" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText(@"Address Line 2" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText(@"Santa ana" + FAKeys.Tab); ;
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem(@"CA"); ;
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText(@"92727" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText(@"123456789" + FAKeys.Tab);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Transactions, 10);
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab().WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText(@"100.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to Active Disbursement Summary screen, validate IBA transaction";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("100.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "IBA", 7, TableAction.GetText).Message.Clean());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region FMUC0031_REG0007
        [TestMethod]
        public void FMUC0031_REG0007()
        {
            try
            {
                Reports.TestDescription = "Adjust and Ad-Hoc Adjustment buttons are disabled for master file";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposit In Escrow screen, make a cash deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                #region deposit data
                var cashDeposit = new DepositParameters()
                {
                    Amount = 1000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(cashDeposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to File Homepage screen, check 'Use As Master File'";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.UseAsMasterFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Navigate to Deposit/Receipt History screen, validate View Details=enable, Adjust=disable, Ad Hoc Adjustment=disalbe";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.DepositReceiptHistory.ViewDetails.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.DepositReceiptHistory.Adjust.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.DepositReceiptHistory.AdHocAdjustment.IsEnabled().ToString());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0031_REG0008
        [TestMethod]
        public void FMUC0031_REG0008()
        {
            try
            {
                Reports.TestDescription = "Deliver deposit receipt";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposit In Escrow screen, make a cash deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                #region deposit data
                var cashDeposit = new DepositParameters()
                {
                    Amount = 1000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(cashDeposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receipt History screen, perform Print delivery";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, cashDeposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.Method.FASelectItem("Print");
                FastDriver.DepositReceiptHistory.Deliver.FAClick();
                FastDriver.DepositReceiptHistory.PrintDepositReceipt();

                Reports.TestStep = "Perform Preview delivery";
                FastDriver.DepositReceiptHistory.WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, cashDeposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.Method.FASelectItem("Preview");
                FastDriver.DepositReceiptHistory.Deliver.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 300);

                Reports.TestStep = "Perform Email delivery";
                FastDriver.DepositReceiptHistory.WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, cashDeposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.Method.FASelectItem("Email");
                FastDriver.DepositReceiptHistory.Deliver.FAClick();
                FastDriver.DepositReceiptHistory.EmailDepositReceipt();

                Reports.TestStep = "Perform Fax delivery";
                FastDriver.DepositReceiptHistory.WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, cashDeposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.Method.FASelectItem("Fax");
                FastDriver.DepositReceiptHistory.Deliver.FAClick();
                FastDriver.DepositReceiptHistory.FaxDepositReceipt();

                Reports.TestStep = "Perform Imagedoc delivery";
                FastDriver.DepositReceiptHistory.WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, cashDeposit.Amount.ToString().FormatAsMoney(), 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.Method.FASelectItem("Imagedoc");
                FastDriver.DepositReceiptHistory.Deliver.FAClick();
                FastDriver.DepositReceiptHistory.ImagedocDepositReceipt();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0031_REG0009_PH

        [TestMethod]
        public void FMUC0031_REG0009_PH()
        {
            try
            {


                Reports.TestDescription = "US632641 & US700123: Date issue on Deposit icon Tooltip";
                
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", true);
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion REG

        #region Private Methods

        private void LoginFastFileSite(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void CreateBasicFileWithSpecifiedGAB(string GABCode = "HUDFLINSR1")
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.EmployeeObjectCD = "";
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode);
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        private void CreateTitleAndSubEscrowFile(string GABCode = "HUDFLINSR1")
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.EmployeeObjectCD = "";
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode);
            customizableFileRequest.File.Services[0].ServiceTypeObjectCD = "TO";
            customizableFileRequest.File.Services[1].ServiceTypeObjectCD = "SEO";
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        #endregion Private Methods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
