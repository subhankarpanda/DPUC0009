﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.Common;
using System.Linq;
using System.Windows.Forms;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;

namespace EscrowTransactions
{
    [CodedUITest]
    [DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class BPUC0004 : MasterTestClass
    {
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void BPUC0004_REG0001()
        {
            try
            {
                Reports.TestDescription = "BP7821_001: User 1 Delivers Outgoing Wires with Pending status";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile();

                CreateOutgoingPendingWire();
               
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }   
        }



        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void BPUC0004_REG0002()
        {
            try
            {
                string bankAccountNumber;
                Reports.TestDescription = "BP7821_002: First login with User 1 and create an outgoing wire in Pending status. Then,  login as User 2 to approve the outgoing wire, which has been created by User 1.";

                
                Reports.StatusUpdate("TEST PRE_CONDITION BLOCK FOR BEGINNING THE CREATION OF AN OUTGOING WIRE WITH PENDING STATUS !", true);
                
                Reports.TestStep = "Login to FAST IIS with the first user ID.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile();

                ApproveOutgoingPendingWire(fileNumber, out bankAccountNumber);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void BPUC0004_REG0003()
        {
            try
            {
                string bankAccountNumber;
                Reports.TestDescription = "BP7821_003: Login as User 1 and verify Approved wire status is complete";


                Reports.StatusUpdate("TEST PRE_CONDITION BLOCK FOR BEGINNING THE CREATION OF AN OUTGOING WIRE WITH THE PENDING STATUS !", true);

                Reports.TestStep = "Login to FAST IIS with the first user ID.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile();

                if (!ApproveOutgoingPendingWire(fileNumber : fileNumber, bankAccountNumber : out bankAccountNumber, IsToAddPreconditonDescription : true))
                {
                    Reports.StatusUpdate("One or more test pre-conditions fail ! Terminating the test...", false);
                    return;
                    //throw new Exception("One or more test Pre-conditions fail ! Terminating the test...");
                }

                Reports.StatusUpdate("ACTUAL TESTING PART STARTS... ", true);
                Reports.TestStep = "Login as User 1";
                this.LoginToIIS();

                Reports.TestStep = "Open the file created through the first user ID.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Select the wire.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();
                

                Reports.TestStep = "Disburse the wire.";
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();

                //Check if Overdraft Confirmation dialog or Password Confirmation dialog appears and blocks the execution.
                HandleOverdraftConfirmationOrPasswordConfirmationDialog();
                //FASTLibrary.FASTLibrary.PasswordOrOverdraftConfirmationDialog();

                Reports.TestStep = "Validate status for Issued check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                var DisbursementIssuedAs = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Issued", 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("Wire", DisbursementIssuedAs);


                Reports.TestStep = "Select a wire.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.OutgoingWireApproval>(@"Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem(bankAccountNumber + " Automation Bank");

                Reports.TestStep = "Click Find Now button.";
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad(FastDriver.WireDisbursementApproval.WireDisbursementTable);

                //In case the the search happens at the beginning of a new PST day, but the wire creation occurred the previous day, the following block should take care of this scenario.
                var wireDisbursementRequestsRowCnt = FastDriver.WireDisbursementApproval.WireDisbursementTable.GetRowCount();
                if (wireDisbursementRequestsRowCnt <= 0)
                {
                    Reports.TestStep = "No requests found ! It could be a beginning of a new day in PST. Perform a new search by reducing one day in the Issue Date From field.";
                    var fromDate = Convert.ToDateTime(FastDriver.WireDisbursementApproval.IssueDateFrom.FAGetValue()).AddDays(-1);
                    FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(fromDate.ToDateString());
                    FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(fromDate.AddDays(1).ToDateString());
                    FastDriver.WireDisbursementApproval.FindNow.FAClick();
                    FastDriver.WireDisbursementApproval.WaitForScreenToLoad(FastDriver.WireDisbursementApproval.WireDisbursementTable);
                }

                Reports.TestStep = "Select the wire that has the current available funds at -31.00.";
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("File #", fileNumber, "Sel", TableAction.On);
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Curr. Avail Funds", "-31.00", "Sel", TableAction.On);
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Curr. Avail Funds", "-31.00", "Status", TableAction.Click);
                
                Reports.TestStep = "Deliver using Preview method.";
                PerformDelivery("Preview");

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        #region Test BPUC0004_REG0004_PH

        [TestMethod]
        public void BPUC0004_REG0004_PH()
        {

            try
            {
                Reports.TestDescription = "UncoveredBRs: BP7822_BP7823_BP7824_BP7825_BP7826_BP7827_BP7828_BP7829_BP7830_BP7831_BP7832_BP7833_BP7834_BP7835_BP7836_BP7837_BP7838_BP7839_BP7840_PlaceHolder";
                
                Reports.TestStep = "Dummy test to use it as a Place holder for non-automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated. Please perform this MANUALLY !");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion Test

        //Team                                    : ServReq
        //Iteration                               : r10
        //UserStory                               : User Story 748571:INC2374897 - Direct [Bug] - Spell Check missing from Email and Fax Modules
        //TestCase                                : 884495
        //Appended By/ Created By                 : Nikhil
        [TestMethod]
        public void BPUC0004_REG0005()
        {
            try
            {
                string bankAccountNumber;
                Reports.TestDescription = "BP7821_003: Login as User 1 and verify Approved wire status is complete";


                Reports.StatusUpdate("TEST PRE_CONDITION BLOCK FOR BEGINNING THE CREATION OF AN OUTGOING WIRE WITH THE PENDING STATUS !", true);

                Reports.TestStep = "Login to FAST IIS with the first user ID.";
                this.LoginToIIS();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile();

                if (!ApproveOutgoingPendingWire(fileNumber: fileNumber, bankAccountNumber: out bankAccountNumber, IsToAddPreconditonDescription: true))
                {
                    Reports.StatusUpdate("One or more test pre-conditions fail ! Terminating the test...", false);
                    return;
                    //throw new Exception("One or more test Pre-conditions fail ! Terminating the test...");
                }

                Reports.StatusUpdate("ACTUAL TESTING PART STARTS... ", true);
                Reports.TestStep = "Login as User 1";
                this.LoginToIIS();

                Reports.TestStep = "Open the file created through the first user ID.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Select the wire.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();


                Reports.TestStep = "Disburse the wire.";
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();

                //Check if Overdraft Confirmation dialog or Password Confirmation dialog appears and blocks the execution.
                HandleOverdraftConfirmationOrPasswordConfirmationDialog();
                //FASTLibrary.FASTLibrary.PasswordOrOverdraftConfirmationDialog();

                Reports.TestStep = "Validate status for Issued check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                var DisbursementIssuedAs = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Issued", 3, TableAction.GetText).Message.ToString();
                Support.AreEqual("Wire", DisbursementIssuedAs);


                Reports.TestStep = "Select a wire.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.OutgoingWireApproval>(@"Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem(bankAccountNumber + " Automation Bank");

                Reports.TestStep = "Click Find Now button.";
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad(FastDriver.WireDisbursementApproval.WireDisbursementTable);

                //In case the the search happens at the beginning of a new PST day, but the wire creation occurred the previous day, the following block should take care of this scenario.
                var wireDisbursementRequestsRowCnt = FastDriver.WireDisbursementApproval.WireDisbursementTable.GetRowCount();
                if (wireDisbursementRequestsRowCnt <= 0)
                {
                    Reports.TestStep = "No requests found ! It could be a beginning of a new day in PST. Perform a new search by reducing one day in the Issue Date From field.";
                    var fromDate = Convert.ToDateTime(FastDriver.WireDisbursementApproval.IssueDateFrom.FAGetValue()).AddDays(-1);
                    FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(fromDate.ToDateString());
                    FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(fromDate.AddDays(1).ToDateString());
                    FastDriver.WireDisbursementApproval.FindNow.FAClick();
                    FastDriver.WireDisbursementApproval.WaitForScreenToLoad(FastDriver.WireDisbursementApproval.WireDisbursementTable);
                }

                Reports.TestStep = "Select the wire that has the current available funds at -31.00.";
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("File #", fileNumber, "Sel", TableAction.On);
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Curr. Avail Funds", "-31.00", "Sel", TableAction.On);
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Curr. Avail Funds", "-31.00", "Status", TableAction.Click);


                #region Spell Check
                Reports.TestStep = "Spell check-email and fax";
                FastDriver.WireDisbursementApproval.Method.FASelectItem("Email");
                FastDriver.WireDisbursementApproval.Deliver.FAClick();
                FastDriver.SpellingErrorDlg.SpellCheck_Email();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        #region Private Methods

        private void LoginToIIS(bool IsSecondUserToUse=false)
        {
            #region data setup
            //string credentials = ""
            Credentials credentials;
            if (IsSecondUserToUse)
            {
                credentials = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };
            }
            else
            {
                credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            }
            #endregion

            try
            {
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            }
            catch (Exception)
            {
                throw new Exception("Login is unsuccessful ! Aborting the test !");
            }
        }


        private static bool WaitForFrameAndSwitchByFrameId(string frameId)
        {
            bool outcome = false;
            FastDriver.OverdraftConfirmationDlg.Wait.Until(d =>
            {
                try
                {
                    d.SwitchTo().Frame(FastDriver.WebDriver.FAFindElement(ByLocator.Id,frameId));
                    outcome = true;
                    return outcome;
                }
                catch (OpenQA.Selenium.NoSuchFrameException)
                {
                    outcome = false;
                    //return false;
                    return outcome;
                }
            });
            return outcome;
        }

        private static string GetTopDialogFrameId()
        {
            try
            {
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                var elements = FastDriver.WebDriver.FAFindElements(ByLocator.XPath,"//iframe[@class='dialog-iframe'][starts-with(@id, 'FAFDialog_')]");
                return elements.LastOrDefault().GetAttribute("id");
            }
            catch (Exception)
            {
                return "";
            }
        }

        private void HandleOverdraftConfirmationOrPasswordConfirmationDialog()
        {
            FastDriver.WebDriver.SwitchTo().DefaultContent();

            Reports.TestStep = "Check if Overdraft Confirmation dialog appears and blocks the execution.";
            try
            {
                if (WaitForFrameAndSwitchByFrameId(GetTopDialogFrameId()))
                {

                    if (FastDriver.WebDriver.FAFindElement(ByLocator.XPath,"//td/p[contains(text(),'Disbursement amount exceeds Available Funds. Continue?')]").IsDisplayed())
                    {
                        FastDriver.WebDriver.FAFindElement(ByLocator.Id,"btnOK").FAClick(); //need to check if any changes are there in 10.6 wrt to this dialog 
                        Reports.StatusUpdate("Overdraft Confirmation dialog has appeared and handled successfully !", true);
                    }
                }
            }
            catch (Exception err)
            {
                Reports.StatusUpdate("Overdraft Confirmation dialog hasn't appeared or some other exception has occurred ! :" + err.Message, true);
            }

            //Reports.TestStep = "Check if Password Confirmation dialog appears and blocks the execution.";
            Reports.TestStep = "Check if Overdraft Reason dialog appears and blocks the execution.";
            Reports.StatusUpdate("Checking for Overdraft Reason dialog...", true);
            try
            {
                if (WaitForFrameAndSwitchByFrameId(GetTopDialogFrameId()))
                {

                    if (WaitForFrameAndSwitchByFrameId("fraPageWin"))
                    {
                        if (FastDriver.PasswordConfirmationDlg.ReasonForLoss.IsVisible(20))
                        {
                            //FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                            //FastDriver.PasswordConfirmationDlg.WaitCreation(FastDriver.PasswordConfirmationDlg.ReasonForLoss);
                            FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(10);
                            FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("AUT Reason");
                            FastDriver.DialogBottomFrame.ClickDone();
                            Reports.StatusUpdate("Overdraft Reason dialog has appeared and been handled successfully !", true);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                //Reports.StatusUpdate("Password Confirmation dialog hasn't appeared or some other exception has occurred :" + err.Message, true);
                Reports.StatusUpdate("Overdraft Reason dialog hasn't appeared or some other exception has occurred :" + err.Message, true);
            }
            //Playback.Wait(2000);
        }
       
        private bool CreateOutgoingPendingWire()
        {
            try
            {
                Reports.TestStep = "Create an instance of Home Warranty.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                FastDriver.HomeWarrantyDetail.GABcode.FASetText(@"HW1");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText(@"Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText(@"13");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText(@"18");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                try
                {
                    FastDriver.DocumentRepository.Scan.FAClick();
                }
                catch
                {
                    FastDriver.DocumentRepository.Scan_DocsTab.FAClick();
                }


                Reports.TestStep = "Click on Open button and load the image document.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.WaitCreation(FastDriver.ImagingWorkBench.Open);

                //Mouse.Click((HtmlControl)FALibHS.GetControl("IIS.ImagingWorkBench", "Open"), new Point(5, 5));
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)

                /*if (!File.Exists(Reports.DEPLOYDIR + "\\LoadTestImage 513k.tif"))
                {
                    General.GetEmbeddedImages("AutoSupport", "support.LoadTestImage 513k.tif", Reports.DEPLOYDIR + "\\LoadTestImage 513k.tif");
                }*/
                FastDriver.SaveDocumentDlg.SaveDocumentUsingCodedUI("Escrow: Payoff Demand/Bills", "PO-Commission Instructions", "AFFIX INV", "AFFIX INV");


                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "31.00", "Payee", TableAction.Click);
                var payee = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "31.00", "Payee", TableAction.GetText).Message.ToString();
                Support.AreEqual("HW name 1 HW name 2 ", payee);


                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "To save the disbursement as pending wire.";


                FastDriver.EditDisbursement.DisburseAs.FASelectItemBySendingKeys(@"Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText(@"12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText(@"ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText(@"ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText(@"12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText(@"12356465");

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.Add.FAClick();
                //Playback.Wait(2000);

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                if (!FastDriver.SelectWireInstructionsDlg.Instruction1.IsSelected())
                {
                    FastDriver.SelectWireInstructionsDlg.Instruction1.FAClick();
                }
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Save();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                return true;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Error occurred while creating an outgoing pending wire ! Error Message :" + ex.Message, false);
                return false;
            }
        }

        private bool ApproveOutgoingPendingWire(string fileNumber, out string bankAccountNumber, bool IsToAddPreconditonDescription=false)
        {
            try
            {
                Reports.StatusUpdate("Process starts for creating the pending wire !", true);
                if (!CreateOutgoingPendingWire())
                {
                    Reports.StatusUpdate("Test pre-condition for creating the pending wire fails ! Terminating the test...", false);
                    bankAccountNumber = "";
                    return false;
                }

                Reports.StatusUpdate("END OF THE TEST PRE-CONDITION BLOCK FOR THE CREATION OF AN OUTGOING WIRE WITH PENDING STATUS !", true);


                if (IsToAddPreconditonDescription)
                {
                    Reports.StatusUpdate("BEGINNING OF THE TEST PRE-CONDITION BLOCK FOR APPROVING THE OUTGOING WIRE THAT IS IN PENDING STATUS !", true);
                }
                Reports.TestStep = "Login to FAST IIS with a different user ID from the first one.";
                this.LoginToIIS(true);

                Reports.TestStep = "Open the file created through the first user ID.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                //var fileNumber = CreateFile();

              /*  Reports.TestStep = "Search the file number on File Search page with search parameters being Country, Region and File Number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForScreenToLoad();

                FastDriver.FileSearch.Country.FASelectItem("USA");
                FastDriver.FileSearch.WaitForScreenToLoad();
                FastDriver.FileSearch.Numbers.FASetText(fileNumber);
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.WaitForScreenToLoad();
                //FALibHS.GetControl("IIS.FileSearch", "Region").Set(HtmlComboBox.PropertyNames.SelectedItem, FASTLibrary.FASTLibrary.RegionInUse);

                Reports.TestStep = "Click on Find Now button after entering the file number.";
                FastDriver.FileSearch.RetryFileSearch();*/
                //Playback.Wait(10000);

                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "31.00", "Payee", TableAction.Click);
                var Disbursementstatus = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "31.00", "Status", TableAction.GetText).Message.ToString();
                Support.AreEqual("Pending", Disbursementstatus);

                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Miscellaneous Image.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                bankAccountNumber = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();

                FastDriver.EditDisbursement.smsfastFases2thumbnailgif.Highlight();
                FastDriver.EditDisbursement.smsfastFases2thumbnailgif.FAClick();

                Playback.Wait(8000);
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                try
                { 
                    if(FastDriver.EditDisbursement.TIFFEmptyWindowHeader.IsVisible(30))
                    {
                        Reports.StatusUpdate("The TIFF dialog must have opened.", true); 
                    }

                    if(CodedUIInteractions.HandleDownloadPrompt())
                    {
                        Reports.StatusUpdate("Opened the TIFF image successfully !", true);
                    }
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                    if (FastDriver.EditDisbursement.TIFFEmptyWindowCloseButton.IsVisible())
                    {
                        FastDriver.EditDisbursement.TIFFEmptyWindowCloseButton.FAClick();
                    }
                }

                catch(Exception err)
                {
                    Reports.StatusUpdate("Could not open TIFF image document or some exception while opening the TIFF file. Exception : " + err.Message, false); 
                }


               

                FastDriver.WebDriver.HandleDialogMessage();//in case any alerts exists.

                Reports.TestStep = "Click on approval check box.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                if (!FastDriver.EditDisbursement.Approve1.IsSelected())
                {
                    FastDriver.EditDisbursement.Approve1.FAClick();
                }

                FastDriver.BottomFrame.Save();
                Playback.Wait(6000);


                Reports.TestStep = "Validate that pending check is approved.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                var cellElement = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "31.00", 4, TableAction.GetCell).Element;
                bool IsDisbursementApproved = GetElementForDisbursementApproval(cellElement); //.IsVisible(10);
                Reports.StatusUpdate("Has disbursement been approved ?", IsDisbursementApproved == true);
                

                if (IsToAddPreconditonDescription)
                {
                    Reports.StatusUpdate("END OF THE TEST PRE-CONDITION BLOCK FOR APPROVING THE OUTGOING WIRE THAT WAS IN PENDING STATUS !", true);
                }

                return true;
            }

            catch(Exception ex)
            {
                Reports.StatusUpdate("Error occurred while approving an outgoing pending wire ! Error Message :" + ex.Message, false);
                bankAccountNumber = "";
                return false;
            }
        }






        private bool GetElementForDisbursementApproval(OpenQA.Selenium.IWebElement element)
        {
            return element.FAFindElement(ByLocator.XPath,".//span/img[contains(@src,'Approval.GIF')]").IsDisplayed();
        }


        #region File Creation
        private string CreateFile(bool OnDemandRequest = false, string GABCode = "", bool IsAutoNumber = true)
        {
            string fileNumber = "";
            try
            {
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = BuildCreateFileRequest();
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            }
            catch
            {
                return "";
            }
            return fileNumber;
        }


        private CreateFileRequest BuildCreateFileRequest()
        {
            var x = new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,
                
                #region File
                File = new File()
                {
                    SalesPriceAmount = 5000,
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "COMMERCIAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    
                    
                    BusinessParties = new FileBusinessParty[] 
                    { 
                        
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        },
                    },
                    
                   
                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[]
                    { 
                        new Property() 
                        {
                            Name = "J305",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",
                            ProperyTypeCdID = 15, //Single Family Residence
                            
                            Taxes = new Taxes[]
                            {
                                new Taxes()
                                {
                                     APN = "Prop1APN1",
                                },
                                new Taxes()
                                {
                                     APN = "9845012345",
                                }
                            },
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA" 
                                    
                                } 
                            } 
                        } 
                    },
                    Buyers = new BuyerSeller[] 
                    { 
                        new BuyerSeller() 
                        { 
                            Type = "Individual",
                            SSN = "123-45-6789",
                            FirstName = "Buyer1Firstname",
                            LastName = "Buyer1Lastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband And Wife",
                            FirstName = "Buyer2Firstname",
                            LastName = "Buyer2Lastname",
                            SpouseFirstName = "Buyer2SpouseName",
                            SpouseLastName = "Buyer2Lastname"
                        }
                    },
                    Sellers = new BuyerSeller[] 
                    {
                        new BuyerSeller() 
                        {
                            Type = "Individual",
                            SSN = "987-65-4321",
                            FirstName = "Seller1FirstName",
                            LastName = "Seller1SpouLastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband And Wife",
                            FirstName = "Seller2Firstname",
                            LastName = "Seller2Lastname",
                            SpouseFirstName = "Seller2SpouseName",
                            SpouseLastName = "Seller2SpouLastname"
                        }
                    },

                    
                  /*  NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                    {
                        LoanNumber = "WCF_DefaultLoanNumber",
                        NewLoanAmount = 5000.00m,
                        LiabilityAmount = 5000.00m,
                        BenMortgageeTextID = 0,
                        FileBusinessParty = new FileBusinessParty
                        {
                            Name = "Nhat Nguyen",
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        },
                        LoanTypeCdID = 0,
                        FundDate = DateTime.Today
                    },*/

                    FileNotes = new FileNote[] 
                    { 
                        new FileNote()
                        {
                            TypeCdID = 695, //EPIC
                            Note = @"Notes Data including - * # Specialcharacter :) !"
                        }
                    }
                }
                #endregion
            };
            

            return x;
        }

        #endregion


        #region Delivery Functions

        private bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                if (Message.Contains("No printer") || Message.Contains("error while populating printers"))
                {
                    Reports.StatusUpdate("Printer is not configured", false);
                }
                else if (string.IsNullOrEmpty(Message))
                {
                    return false;
                }

                return true;
            }
            catch (OpenQA.Selenium.NoAlertPresentException)
            {
                return false;
            }
        }

        private bool HandleDeliveryFailure(string deliveryMethod, int timeoutSeconds)
        {
            try
            {
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, timeoutSeconds);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return true;
            }
            catch (OpenQA.Selenium.WebDriverTimeoutException)
            {
                Reports.StatusUpdate(string.Format("'{0}' failed after {1} seconds.", deliveryMethod, timeoutSeconds), false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return false;
            }
        }

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Random ran=new Random();
                int ranNumber= ran.Next(250);
                Playback.Wait(5000);
                PDFFilePath = PDFFilePath.Replace(".PDF", ranNumber + ".PDF");

                Keyboard.SendKeys("^{S}", System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", System.Windows.Input.ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true);

                Keyboard.SendKeys("{F4}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This close the dialog

                Keyboard.SendKeys("{N}", System.Windows.Input.ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Keyboard.SendKeys("{F4}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        private void PerformDelivery(string deliveryMethod)
        {
            Reports.TestStep = "Perfom the " + deliveryMethod + " delivery method.";
            FastDriver.WireDisbursementApproval.Method.FASelectItem(deliveryMethod);
            FastDriver.WireDisbursementApproval.Deliver.FAClick();

            switch (deliveryMethod)
            {
                case "Email":
                    {
                        FastDriver.EmailDlg.WaitForDialogToLoad();
                        FastDriver.EmailDlg.SendEmail();
                        FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, 200);
                        break;
                    }
                case "Print":
                    {
                        if (!isAlertPresent())
                        {
                           // FastDriver.WebDriver.WaitForWindowAndSwitch(windowName: "Print", timeoutSeconds: 20);
                            FastDriver.PrintDlg.WaitForScreenToLoad();
                            FastDriver.PrintDlg.SelectPrinter();
                            FastDriver.PrintDlg.ClickPrint();
                            HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 200 ? 200 : int.Parse(AutoConfig.WaitTime) * 3);
                        }
                        else
                        {
                            Reports.StatusUpdate("Printer is not configured correctly", false);
                        }
                        break;
                    }
                case "Fax":
                    {
                        FastDriver.FaxDlg.WaitForScreenToLoad();
                        FastDriver.FaxDlg.SendFax();
                        FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, 200);
                        break;
                    }
                case "Preview":
                    {
                        //FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, 200);
                        if (HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 250 ? 250 : int.Parse(AutoConfig.WaitTime) * 3))
                        {
                            Reports.TestStep = "Save PDF file";
                            string tempPdfFile = @"C:\Temp\temp.PDF";
                            SavePDFFile(tempPdfFile);
                        }
                        break;
                    }
            }
        }

        #endregion

        #endregion

       /* [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }*/
    }
   
}
