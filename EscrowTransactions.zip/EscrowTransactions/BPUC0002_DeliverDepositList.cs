﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.Common;
using System.Windows.Forms;

namespace EscrowTransactions
{
    [CodedUITest]
    [DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class BPUC0002 : MasterTestClass
    {

        [TestMethod]
        public void BPUC0002_REG0001()
        {
            try
            {
                Reports.TestDescription = "BP7796_BP7820: Deliver deposit list";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Executing Pre-requisite for REG0001";
                REG0001_PreRequisite();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile();


                Reports.TestStep = "Navigate to Depost In Escrow page.";
                //Reports.CaptureImage((UITestControl)FALibHS.sBrowserWindow);
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                FastDriver.DepositInEscrow.Amount.FASetText(@"10.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(@"Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem(@"Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText(@"Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(@"Buyer");
                FastDriver.DepositInEscrow.Comment.FASetText("Comments Before Save");
                
                
                FastDriver.BottomFrame.Save();
                
                Reports.TestStep = "Click on Cancel button for Printing Deposit Receipt.";
                FastDriver.WebDriver.HandleDialogMessage(true,false,20);
                Playback.Wait(5000);   //need this wait

                Reports.TestStep = "Create a deposit list with select the dates.";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();

                if (FastDriver.DepositList.New.IsVisible(10) && FastDriver.DepositList.New.IsEnabled())
                {
                    FastDriver.DepositList.New.FAClick();
                    var IssueDateFrom = DateTime.Now.ToDateString();
                    FastDriver.DepositList.IssueDateFrom.FASetText(@IssueDateFrom);
                    var IssueDateTo = DateTime.Now.ToDateString();
                    FastDriver.DepositList.IssueDateTo.FASetText(@IssueDateTo);
                    FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
                    Playback.Wait(20000);
                    FastDriver.DepositList.ReceiptsTable.PerformTableAction(3,"10.00",1,TableAction.On);

                    Reports.TestStep = "Click on find now button.";
                    FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();

                    FastDriver.DepositList.FindNow.FAClick();

                    Reports.TestStep = "Verify for status pending.";
                    FastDriver.DepositList.WaitForScreenToLoad();
                    FastDriver.DepositList.DepositListTable.PerformTableAction(2,"Pending",2,TableAction.Click);

                    Reports.TestStep = "Print deposit list ==> Print the checks.";
                    PerformDelivery("Print");
                    FastDriver.DepositList.WaitForScreenToLoad();

                    Reports.TestStep = "Select table and Click on Edit button.";
                    FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.Click);

                    FastDriver.DepositList.Edit.FAClick();

                    Reports.TestStep = "Click on Complete button.";
                    FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);

                    FastDriver.DepositList.ReceiptsTable.PerformTableAction(3, "10.00", 1, TableAction.On);
                    FastDriver.DepositList.Complete.FAClick();

                    Reports.TestStep = "Print the checks.";
                    FastDriver.PrintDlg.WaitForScreenToLoad();
                    FastDriver.PrintDlg.ClickCancel();

                    Reports.TestStep = "Click on find now button.";
                    FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                    FastDriver.DepositList.FindNow.FAClick();

                    Reports.TestStep = "Verify for status Complete.";
                    FastDriver.DepositList.WaitForScreenToLoad();
                    FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Complete", 2, TableAction.Click);
                    var completedValue = FastDriver.DepositList.DepositListTable.PerformTableAction(2,"Complete",3, TableAction.GetText).Message.ToString();
                    Reports.StatusUpdate("Is the value of the deposit in Complete status is equal to 10.00 ?", completedValue == "10.00");

                    Reports.TestStep = "Print deposit list ==> Print the checks.";
                    PerformDelivery("Print");
                    FastDriver.DepositList.WaitForScreenToLoad();

                    //completedValue = "0.00";
                    //completedValue = FastDriver.DepositList.DepositListTable.PerformTableAction(2,"Complete",3,TableAction.GetText).ToString();
                    //Reports.StatusUpdate("Is the value of the deposit in Complete status is equal to 10.00 ?", completedValue == "10.00");

                    Reports.TestStep = "Click on edit button.";
                    FastDriver.DepositList.Edit.FAClick();

                    Reports.TestStep = "Click on Exclude button.";
                    FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                    FastDriver.DepositList.ReceiptsTable.PerformTableAction(3, "10.00", 1, TableAction.Off);
                    FastDriver.DepositList.Exclude.FAClick();

                    Reports.TestStep = "Exclude a receipt entering the comments.";
                    FastDriver.ExclusionCommentDlg.WaitForScreenToLoad();
                    FastDriver.ExclusionCommentDlg.Comments.FASetText(@"Reason1 for exclusion");
                    FastDriver.DialogBottomFrame.ClickDone();

                    Reports.TestStep = "Click on find now button.";
                    FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                    FastDriver.DepositList.FindNow.FAClick();

                    Reports.TestStep = "verify for status Complete-edit.";
                    FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Complete-Edit", 2, TableAction.Click);
                    
                    Reports.TestStep = "Print deposit list ==> Print the checks.";
                    PerformDelivery("Print");
                }
                else
                {
                    Reports.StatusUpdate("Pending Deposit List exists... clear them and re-run the script !", false);
                }
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }   
        }

        #region Test BPUC0002_REG0002_PH

        [TestMethod]
        public void BPUC0002_REG0002_PH()
        {
            try
            {
                Reports.TestDescription = "UncoveredBRs: BP7797_BP7798_BP7799_BP7800_BP7801_BP7802_BP7803_BP7804_BP7805_BP7806_BP7807_BP7808_BP7809_BP7810_BP7811_BP7812_BP7813_BP7814_BP7815_BP7816_BP7817_BP7818_BP7819";


                Reports.TestStep = "Dummy test to use it as a Place Holder for non-automated scenarios.";
                Assert.Inconclusive("This flow has NOT been automated. Please perform this MANUALLY !");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion Test


        //Team                                    : ServReq
        //Iteration                               : r10
        //UserStory                               : User Story 748571:INC2374897 - Direct [Bug] - Spell Check missing from Email and Fax Modules
        //TestCase                                : 884495
        //Appended By/ Created By                 : Nikhil
        [TestMethod]
        public void BPUC0002_REG0003()
        {
            try
            {
                Reports.TestDescription = "BP7796_BP7820: Deliver deposit list";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();

                Reports.TestStep = "Executing Pre-requisite for REG0001";
                REG0001_PreRequisite();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile();


                Reports.TestStep = "Navigate to Depost In Escrow page.";
                //Reports.CaptureImage((UITestControl)FALibHS.sBrowserWindow);
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                FastDriver.DepositInEscrow.Amount.FASetText(@"10.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(@"Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem(@"Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText(@"Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(@"Buyer");
                FastDriver.DepositInEscrow.Comment.FASetText("Comments Before Save");


                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button for Printing Deposit Receipt.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);
                Playback.Wait(5000);   //need this wait

                Reports.TestStep = "Create a deposit list with select the dates.";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();

                if (FastDriver.DepositList.New.IsVisible(10) && FastDriver.DepositList.New.IsEnabled())
                {
                    FastDriver.DepositList.New.FAClick();
                    var IssueDateFrom = DateTime.Now.ToDateString();
                    FastDriver.DepositList.IssueDateFrom.FASetText(@IssueDateFrom);
                    var IssueDateTo = DateTime.Now.ToDateString();
                    FastDriver.DepositList.IssueDateTo.FASetText(@IssueDateTo);
                    FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
                    Playback.Wait(20000);
                    FastDriver.DepositList.ReceiptsTable.PerformTableAction(3, "10.00", 1, TableAction.On);

                    Reports.TestStep = "Click on find now button.";
                    FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();

                    FastDriver.DepositList.FindNow.FAClick();

                    Reports.TestStep = "Verify for status pending.";
                    FastDriver.DepositList.WaitForScreenToLoad();
                    FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.Click);

                    Reports.TestStep = "Print deposit list ==> Print the checks.";
                    PerformDelivery("Print");
                    FastDriver.DepositList.WaitForScreenToLoad();

                    Reports.TestStep = "Select table and Click on Edit button.";
                    FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.Click);

                    FastDriver.DepositList.Edit.FAClick();

                    Reports.TestStep = "Click on Complete button.";
                    FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);

                    FastDriver.DepositList.ReceiptsTable.PerformTableAction(3, "10.00", 1, TableAction.On);
                    FastDriver.DepositList.Complete.FAClick();

                    Reports.TestStep = "Print the checks.";
                    FastDriver.PrintDlg.WaitForScreenToLoad();
                    FastDriver.PrintDlg.ClickCancel();

                    Reports.TestStep = "Click on find now button.";
                    FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                    FastDriver.DepositList.FindNow.FAClick();

                    Reports.TestStep = "Verify for status Complete.";
                    FastDriver.DepositList.WaitForScreenToLoad();
                    FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Complete", 2, TableAction.Click);
                    var completedValue = FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Complete", 3, TableAction.GetText).Message.ToString();
                    Reports.StatusUpdate("Is the value of the deposit in Complete status is equal to 10.00 ?", completedValue == "10.00");

                    #region Spell Check
                    Reports.TestStep = "Spell check-email and fax";
                    FastDriver.DepositList.Method.FASelectItem("Email");
                    FastDriver.FileFees.Deliver.FAClick();
                    FastDriver.SpellingErrorDlg.SpellCheck_Email();
                    
                    #endregion
                }
                else
                {
                    Reports.StatusUpdate("Pending Deposit List exists... clear them and re-run the script !", false);
                }
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        #region Private Methods

        private void LoginToIIS()
        {
            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            #endregion

            try
            {
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            }
            catch (Exception ex)
            {
                throw new Exception("Login is unsuccessful ! Aborting the test !");
            }
        }


        #region Pre-requisites
        private bool REG0001_PreRequisite()
        {
            try
            {
                Reports.TestStep = "Navigate to Deposit List";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();

                Reports.TestStep = "Check if Pending Deposit List exists";
                if (!FastDriver.DepositList.New.IsEnabled())
                {
                    Reports.TestStep = "Pending Deposit List Exists. Clear all Pending deposit Lists.";
                    FastDriver.DepositList.FindNow.FAClick();


                    Reports.TestStep = "Select the Pending Deposit List";
                    FastDriver.DepositList.WaitForScreenToLoad();
                    FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.Click);


                    Reports.TestStep = "Click Edit button";
                    FastDriver.DepositList.Edit.FAClick();


                    Reports.TestStep = "Click Find Now in Edit Deposit List Screen";
                    FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                    FastDriver.DepositList.DepositListEdit_FindNow.FAClick();

                    Reports.TestStep = "Check Select All Check Box";
                    FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                    // var aa = FastDriver.DepositList.SelectAll.FAGetAttribute("checked").ToString();
                    if ((FastDriver.DepositList.SelectAll.FAGetAttribute("checked") ?? "false") == "false")
                    {
                        FastDriver.DepositList.SelectAll.FAClick();
                        FastDriver.WebDriver.HandleDialogMessage();
                        FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                    }

                    Reports.TestStep = "Check if complete button is enabled";
                    if (FastDriver.DepositList.Complete.IsEnabled())
                    {
                        FastDriver.DepositList.Complete.FAClick();

                        Reports.TestStep = "Print Dialog is displayed. Click Cancel button.";
                        FastDriver.PrintDlg.WaitForScreenToLoad();
                        FastDriver.PrintDlg.ClickCancel();

                        FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                        FastDriver.DepositList.WaitForScreenToLoad();

                        Reports.TestStep = "Check if Complete button is disabled.";
                        if (!FastDriver.DepositList.Complete.IsEnabled())
                        {
                            Reports.TestStep = "Complete button is disabled. Navigate to deposit List";

                            FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();

                            Reports.TestStep = "Check if New button is enabled";
                            if (FastDriver.DepositList.New.IsEnabled())
                            {
                                Reports.TestStep = "New button is enabled.End of Pre-requisite";
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        #endregion



        #region File Creation

        private string CreateFile(bool OnDemandRequest = false, string GABCode = "", bool IsAutoNumber = true)
        {
            string fileNumber = "";
            try
            {
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = BuildCreateFileRequest();
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            }
            catch
            {
                return "";
            }
            return fileNumber;
        }


        private CreateFileRequest BuildCreateFileRequest()
        {
            var x = new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,
                
                #region File
                File = new File()
                {
                    SalesPriceAmount = 5000,
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "COMMERCIAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    
                    
                    BusinessParties = new FileBusinessParty[] 
                    { 
                        
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        },
                    },
                    
                   
                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[]
                    { 
                        new Property() 
                        {
                            Name = "J305",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",
                            ProperyTypeCdID = 15, //Single Family Residence
                            
                            Taxes = new Taxes[]
                            {
                                new Taxes()
                                {
                                     APN = "Prop1APN1",
                                },
                                new Taxes()
                                {
                                     APN = "9845012345",
                                }
                            },
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA" 
                                    
                                } 
                            } 
                        } 
                    },
                    Buyers = new BuyerSeller[] 
                    { 
                        new BuyerSeller() 
                        { 
                            Type = "Individual",
                            SSN = "123-45-6789",
                            FirstName = "Buyer1Firstname",
                            LastName = "Buyer1Lastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband And Wife",
                            FirstName = "Buyer2Firstname",
                            LastName = "Buyer2Lastname",
                            SpouseFirstName = "Buyer2SpouseName",
                            SpouseLastName = "Buyer2Lastname"
                        }
                    },
                    Sellers = new BuyerSeller[] 
                    {
                        new BuyerSeller() 
                        {
                            Type = "Individual",
                            SSN = "987-65-4321",
                            FirstName = "Seller1FirstName",
                            LastName = "Seller1SpouLastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband And Wife",
                            FirstName = "Seller2Firstname",
                            LastName = "Seller2Lastname",
                            SpouseFirstName = "Seller2SpouseName",
                            SpouseLastName = "Seller2SpouLastname"
                        }
                    },

                    
                  /*  NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                    {
                        LoanNumber = "WCF_DefaultLoanNumber",
                        NewLoanAmount = 5000.00m,
                        LiabilityAmount = 5000.00m,
                        BenMortgageeTextID = 0,
                        FileBusinessParty = new FileBusinessParty
                        {
                            Name = "Nhat Nguyen",
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        },
                        LoanTypeCdID = 0,
                        FundDate = DateTime.Today
                    },*/

                    FileNotes = new FileNote[] 
                    { 
                        new FileNote()
                        {
                            TypeCdID = 695, //EPIC
                            Note = @"Notes Data including - * # Specialcharacter :) !"
                        }
                    }
                }
                #endregion
            };
            

            return x;
        }

        #endregion


        #region Delivery Functions

        private bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                if (Message.Contains("No printer") || Message.Contains("error while populating printers"))
                {
                    Reports.StatusUpdate("Printer is not configured", false);
                }
                else if (string.IsNullOrEmpty(Message))
                {
                    return false;
                }

                return true;
            }
            catch (OpenQA.Selenium.NoAlertPresentException)
            {
                return false;
            }
        }





        private bool HandleDeliveryFailure(string deliveryMethod, int timeoutSeconds)
        {
            try
            {
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, timeoutSeconds);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return true;
            }
            catch (OpenQA.Selenium.WebDriverTimeoutException)
            {
                Reports.StatusUpdate(string.Format("'{0}' failed after {1} seconds.", deliveryMethod, timeoutSeconds), false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return false;
            }
        }





        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Random ran=new Random();
                int ranNumber= ran.Next(250);
                Playback.Wait(5000);
                PDFFilePath = PDFFilePath.Replace(".PDF", ranNumber + ".PDF");

                Keyboard.SendKeys("^{S}", System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", System.Windows.Input.ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true);

                Keyboard.SendKeys("{F4}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This close the dialog

                Keyboard.SendKeys("{N}", System.Windows.Input.ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Keyboard.SendKeys("{F4}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }



        private void PerformDelivery(string deliveryMethod)
        {
            Reports.TestStep = "Perfom the " + deliveryMethod + " delivery method.";
            FastDriver.DepositList.Method.FASelectItem(deliveryMethod);
            FastDriver.FileFees.Deliver.FAClick();

            switch (deliveryMethod)
            {
                case "Email":
                    {
                        FastDriver.EmailDlg.WaitForDialogToLoad();
                        FastDriver.EmailDlg.SendEmail();
                        FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, 200);
                        break;
                    }
                case "Print":
                    {
                        if (!isAlertPresent())
                        {
                           // FastDriver.WebDriver.WaitForWindowAndSwitch(windowName: "Print", timeoutSeconds: 20);
                            FastDriver.PrintDlg.WaitForScreenToLoad();
                            FastDriver.PrintDlg.SelectPrinter();
                            FastDriver.PrintDlg.ClickPrint();
                            HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 200 ? 200 : int.Parse(AutoConfig.WaitTime) * 3);
                        }
                        else
                        {
                            Reports.StatusUpdate("Printer is not configured correctly", false);
                        }
                        break;
                    }
                case "Fax":
                    {
                        FastDriver.FaxDlg.WaitForScreenToLoad();
                        FastDriver.FaxDlg.SendFax();
                        FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, 200);
                        break;
                    }
                case "Preview":
                    {
                        //FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, 200);
                        if (HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 250 ? 250 : int.Parse(AutoConfig.WaitTime) * 3))
                        {
                            Reports.TestStep = "Save PDF file";
                            string tempPdfFile = @"C:\Temp\temp.PDF";
                            SavePDFFile(tempPdfFile);
                        }
                        break;
                    }
            }
            FastDriver.DepositList.WaitForScreenToLoad();
        }




        #endregion

        #endregion





        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
