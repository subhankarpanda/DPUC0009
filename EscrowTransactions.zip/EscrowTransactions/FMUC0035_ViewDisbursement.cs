﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium.Support.UI;
using System.Linq;
using FASTSelenium.DataObjects.IIS;


namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0035_ViewDisbursement : MasterTestClass
    {
        #region BAT
        [TestMethod]
        public void FMUC0035_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF_01: To create issued feetransfer,check and created wire disbursements in Active Disbursement Summary";

                //
                //
                Reports.TestStep = "Login To Fast";
                this.Login();
                // 
                // 
                Reports.TestStep = "Create Order.";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                #region GUI FIle Creation
                //FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                //FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                //FastDriver.QuickFileEntry.WaitForScreenToLoad();
                //FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("HUDFLINSR1");
                //FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                //FastDriver.QuickFileEntry.DirectedBYFind.FAClick();

                //if (!FastDriver.QuickFileEntry.Title.Selected)
                //    FastDriver.QuickFileEntry.Title.FAClick();

                //if (!FastDriver.QuickFileEntry.Escrow.Selected)
                //    FastDriver.QuickFileEntry.Escrow.FAClick();

                //FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                //FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000"+FAKeys.Tab);
                //FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                //FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
                //FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                //FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                //FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                //FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                //FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                //FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                //FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                //FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                //FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                //FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                //FastDriver.QuickFileEntry.PropertyCity.FASetText("ALAMEDA");
                //FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                //FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                //FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                //FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                //FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                //FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                //FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                //FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                //FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                //FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                //FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                //FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                //FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                //FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                //FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                //FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                //Playback.Wait(2000);
                //FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                //FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                //Playback.Wait(2000);
                //FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
                //FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !");
                //FastDriver.BottomFrame.Done();
                //FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion GUI FIle Creation
                // 
                // 
                Reports.TestStep = "Navigate to Survey & entering GAB.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Change the description and charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                this.EnterFeeInTitleEscrowTab();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "Validate that active disbursement screen is loaded.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "To validate the disbursements.";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.FeeAmount.Exists().ToString(), "Validates Feeamount Exists");
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.FeeTransferDocumentCode.Exists().ToString(), "Validates FeeTransferDocumentCode Exists");
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.CheckAmount1.Exists().ToString(), "Validates CheckAmount1 Exists");
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.CheckAmount2.Exists().ToString(), "Validates CheckAmount2 Exists");

                // 
                // 
                Reports.TestStep = "To click on Fee Transfer button in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

               // if (IsOverDraftConfirmationDialogPresent())
               // {
                try
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
               
               catch(Exception)
               {
                   this.FillPasswordConfirmationDlg();
               }

                //
                //
                Reports.TestStep = "Click on Cancel on ChangeFileStatusDlg.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...",false);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow();
                // 
                // 
                Reports.TestStep = "To Issue the check using the Print button in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                // 
                // 
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod: "Print", timeoutSeconds: 1000);


                //
                // 
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                // 
                // 
                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItemBySendingKeys("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBankAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Beneficiary Note 1");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "To validate net disbursement amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.NetDisbursementAmount.Exists().ToString());

                // 
                // 
                Reports.TestStep = "Validate the wire is created";
                Support.AreEqual("Wire", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Funds", TableAction.GetText).Message.Clean());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF_01: To View Summary of Disbursement History";


                //
                //
                Reports.TestStep = "Login To Fast";
                this.Login();
                // 
                // 
                Reports.TestStep = "Create Order.";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Navigate to Survey & entering GAB.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Change the description and charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                this.EnterFeeInTitleEscrowTab();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "Validate that active disbursement screen is loaded.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "To validate the disbursements.";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.FeeAmount.Exists().ToString(), "Validates Feeamount Exists");
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.FeeTransferDocumentCode.Exists().ToString(), "Validates FeeTransferDocumentCode Exists");
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.CheckAmount1.Exists().ToString(), "Validates CheckAmount1 Exists");
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.CheckAmount2.Exists().ToString(), "Validates CheckAmount2 Exists");

                // 
                // 
                Reports.TestStep = "To click on Fee Transfer button in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

               // if (IsOverDraftConfirmationDialogPresent())
                try
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                catch( Exception)
                {
                    this.FillPasswordConfirmationDlg();
                }

                //
                //
                Reports.TestStep = "Click on Cancel on ChangeFileStatusDlg.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...",false);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 400);
                // 
                // 
                Reports.TestStep = "To Issue the check using the Print button in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                // 
                // 
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod: "Print", timeoutSeconds: 1000);


                //
                // 
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                // 
                // 
                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItemBySendingKeys("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBankAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Beneficiary Note 1");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "To validate net disbursement amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.NetDisbursementAmount.Exists().ToString());

                // 
                // 
                Reports.TestStep = "Validate the wire is created";
                Support.AreEqual("Wire", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Funds", TableAction.GetText).Message.Clean());

                // 
                // 
                Reports.TestStep = "Navigate to Disbursement History.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Verify that Disbursement History screen is loaded.";
                Support.AreEqual("True", FastDriver.DisbursementHistory.ViewDetails.Exists().ToString());

                // 
                // 
                Reports.TestStep = "Validate the Issued Fee Transfer in Disbursement History.";
                Support.AreEqual("4.98", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Issued", 7, TableAction.GetText).Message.Clean());

                // 
                // 
                Reports.TestStep = "Validate the Issued Check in Disbursement History.";
                Support.AreEqual("Issued", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(7, "4,986.01", 1, TableAction.GetText).Message.Clean());

                // 
                // 
                Reports.TestStep = "Validate the Created Wire in Disbursement History.";
                Support.AreEqual("21.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Created", 7, TableAction.GetText).Message.Clean());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_BAT0003()
        {
            try
            {
                //
                //
                Reports.TestStep = "Login To Fast";
                this.Login();
                // 
                // 
                Reports.TestStep = "Create Order.";
                this.CreateFileWithWCF(RequestFactory.GetCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                Playback.Wait(4000);
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("3,880.00");

                // 
                // 
                Reports.TestStep = "Click on split button after select reb1.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();

                // 
                // 
                Reports.TestStep = "Entering Percentage.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.SplitDisbursement.SwitchToContentFrame();
                FastDriver.SplitDisbursement.WaitCreation(FastDriver.SplitDisbursement.Remove);
                FastDriver.SplitDisbursement.SplitDistributionPercentage.FASetText("100");
                FastDriver.BottomFrame.Save();
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "Validate split amount";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("M", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Split", "S.", TableAction.GetText).Message.ToString());
                Support.AreEqual("M", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "3,880.00", "S.", TableAction.GetText).Message.ToString());

                // 
                // 
                Reports.TestStep = "Validate the Pending amount";
                Support.AreEqual("D", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "S.", TableAction.GetText).Message.ToString());
                Support.AreEqual("3,880.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("S.", "D", "Amount", TableAction.GetText).Message.Clean().ToString());

                // 
                // 
                Reports.TestStep = "Navigate to Home Warranty screen.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "There is an amount in Seller/Buyer Charge Not to Exceed field, and total of Buyer Charge and Seller Charge amounts exceed this limit.";
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("350.00" + FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Validate out of balance";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Split", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("S.", "M*", "Status", TableAction.GetText).Message.Clean().ToString());
                Support.AreEqual("M*", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "350.00", "S.", TableAction.GetText).Message.Clean().ToString());

                // 
                // 
                Reports.TestStep = "Validate out of balance";
                Support.AreEqual("Split", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("S.", "M*", "Status", TableAction.GetText).Message.Clean().ToString());
                Support.AreEqual("3,880.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("S.", "D*", "Amount", TableAction.GetText).Message.Clean().ToString());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF_01_4: Validate out of balance";

                //
                //
                Reports.TestStep = "Login To Fast";
                this.Login();
                // 
                // 
                Reports.TestStep = "Create Order.";
                this.CreateFileWithWCF(RequestFactory.GetCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                Playback.Wait(4000);
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("3,880.00");

                // 
                // 
                Reports.TestStep = "Click on split button after select reb1.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();

                // 
                // 
                Reports.TestStep = "Entering Percentage.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.SplitDisbursement.SwitchToContentFrame();
                FastDriver.SplitDisbursement.WaitCreation(FastDriver.SplitDisbursement.Remove);
                FastDriver.SplitDisbursement.SplitDistributionPercentage.FASetText("100");
                FastDriver.BottomFrame.Save();
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "Verify for the Split Status.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("M", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Split", "S.", TableAction.GetText).Message.ToString());

                // 
                // 
                Reports.TestStep = "Verify for the Pend Status.";
                Support.AreEqual("D", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "S.", TableAction.GetText).Message.ToString());

                // 
                // 
                Reports.TestStep = "Navigate to Home Warranty screen.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "There is an amount in Seller/Buyer Charge Not to Exceed field, and total of Buyer Charge and Seller Charge amounts exceed this limit.";
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("350.00" + FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Verify for the out of balance";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("M*", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Split", "S.", TableAction.GetText).Message.Clean());
                Support.AreEqual("M*", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "350.00", "S.", TableAction.GetText).Message.Clean());

                // 
                // 
                Reports.TestStep = "Verify for the out of balance";
                Support.AreEqual("D*", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Pending", "S.", TableAction.GetText).Message.Clean());
                Support.AreEqual("D*", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "3,880.00", "S.", TableAction.GetText).Message.Clean());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion BAT

        #region REG
        [TestMethod]
        public void FMUC0035_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM2635_FM2636_FM4198: Created/Pending disbursements";

                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                //this.GetDetailedCreateFileDefaultRequest();
                // 
                // 
                Reports.TestStep = "Navigate to Survey & entering GAB.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");

                // 
                // 
                Reports.TestStep = "Edit the instance and save the changes made.";
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00" + FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Validate that active disbursement screen is loaded.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Validate the enable button.";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.PrintAll.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.DisburseAll.Enabled.ToString());

                // 
                // 
                Reports.TestStep = "Select the pending status and verify the enabled disabled button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Amount", TableAction.Click);
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.Note.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.Print.Enabled.ToString());
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.PrintAll.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.Edit.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.Manual.Enabled.ToString());
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.Wire.Enabled.ToString());
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.WireAll.Enabled.ToString());
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.DisburseAll.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.Split.Enabled.ToString());
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.Void.Enabled.ToString());
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.FeeTransfer.Enabled.ToString());

                //
                Reports.TestStep = "Validate FM4198  Disbursement Payee Name";
                Reports.TestStep = "Click on split in Summary page.";
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.SplitDisbursement.SwitchToContentFrame();
                FastDriver.SplitDisbursement.WaitCreation(FastDriver.SplitDisbursement.Remove);
                // 
                Reports.TestStep = "Enter amount to split and saves changes made.";
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("10.00" + FAKeys.Tab + FAKeys.Tab);
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FASetText("11.00");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                //
                Reports.TestStep = "Validate that the user must enter a Payee name before the disbursement can be issued.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "", "Payee", TableAction.Click);
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.Print.Enabled.ToString());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 1, TableAction.Click);

                //
                Reports.TestStep = "Validate that the Disburse all will not include disbursement with no payee name.";
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.DisburseAll.Enabled.ToString());
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "11.00", "Amount", TableAction.Click);
                this.EnterFeeInTitleEscrowTab();

                //
                //
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                //
                Reports.TestStep = "Disuburse the fee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.98", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                // 

                //if (IsOverDraftConfirmationDialogPresent())
                try
                {
                    FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad(FastDriver.PasswordConfirmationDlg.LossPassword);
                    this.FillPasswordConfirmationDlg();
                    
                }
                catch(Exception)
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }

                //
                //
                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...",false);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 1000);

                //
                Reports.TestStep = "Validate the Issued status for disbursed Fee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Fee Transfer", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Issued", "Funds", TableAction.GetText).Message);

                //
                Reports.TestStep = "Validate the newly created Fee after disbursing one fee.";
                Reports.TestStep = "Enter second fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                bool feeExists = false;

                for (int i = 1; i < FastDriver.FileFees.TitleandescrowTable.GetRowCount(); i++)
                {
                    if (FastDriver.FileFees.TitleandescrowTable.PerformTableAction(i, 2, TableAction.GetText).Message.Clean() == "New Home Rate Eagle Owner")
                    {
                        feeExists = true;
                        break;
                    }
                }
               
                    if (feeExists)
                    {
                        FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Owner", "Sel", TableAction.On);
                        FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Owner", "Buyer Charge", TableAction.SetText, "5.00");
                        FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Owner", "Seller Charge", TableAction.SetText, "10.00");
                    }

                    else
                    {
                        FastDriver.FileFees.AddFees.FAClick();
                        FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                        FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                        FastDriver.FileFees.FindNow.FAClick();
                        FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.AddFeeTable);
                        FastDriver.FileFees.AddFeeTable.PerformTableAction("Description", "New Home Rate Eagle Owner", "Sel", TableAction.Click);
                        FastDriver.BottomFrame.Done();
                        Playback.Wait(2000);
                        FastDriver.FileFees.WaitForScreenToLoad();
                        FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 1, TableAction.On);
                        FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Owner", "Buyer Charge", TableAction.SetText, "5.00");
                        FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Owner", "Seller Charge", TableAction.SetText, "10.00");
                        FastDriver.BottomFrame.Done();
                    }

                //
                //
                Reports.TestStep = "Validate the created second fee in Disbursement summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Fee Transfer", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.GetText).Message);

                //breakpoint

                // 
                Reports.TestStep = "Create an AD-HOC instance of REB.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.FAClick();

                // 
                // 
                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization");
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText("REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText("Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem("CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText("Alameda");
                FastDriver.BusOrgAdhocDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Enter commission Amount.";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("30");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                // 
                // 
                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("Hudflinsr1");
                Playback.Wait(2000);
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");

                // 
                // 
                Reports.TestStep = "Click on Done.";
                Playback.Wait(3000);

                // 
                // 
                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItemBySendingKeys("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItemBySendingKeys("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItemBySendingKeys("Buyer");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Playback.Wait(10000);

                // 
                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                // 
                Reports.TestStep = "Verify the payee name as Seller.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Support.AreEqual("Seller1FirstName Seller1Lastname", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4,954.01", "Payee", TableAction.GetText).Message.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);

                // 
                // 
                Reports.TestStep = "Navigate to Deposit in Escrow for a title only file..";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Enter amount greater than seller.";
                FastDriver.DepositInEscrow.Amount.FASetText("6000.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItemBySendingKeys("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItemBySendingKeys("Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Test");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItemBySendingKeys("Buyer");
                FastDriver.BottomFrame.Save();
                Playback.Wait(20000);

                // 
                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                // 
                Reports.TestStep = "Verify the payee name as Buyer.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Buyer1Firstname Buyer1Lastname", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "6,001.01", "Payee", TableAction.GetText).Message.Clean());

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM2637_FM2638: Represent check to seller";

                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                // 
                Reports.TestStep = "Create an AD-HOC instance of REB.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.FAClick();

                // 
                // 
                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization");
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText("REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText("Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem("CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText("Alameda");
                FastDriver.BusOrgAdhocDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Enter commission Amount.";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("30");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                // 
                // 
                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("Hudflinsr1");
                Playback.Wait(2000);
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");

                // 
                // 
                Reports.TestStep = "Click on Done.";
                Playback.Wait(3000);

                // 
                // 
                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItemBySendingKeys("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItemBySendingKeys("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItemBySendingKeys("Buyer");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Playback.Wait(10000);

                // 
                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                // 
                Reports.TestStep = "Verify the payee name as Seller.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Support.AreEqual("Seller1FirstName Seller1Lastname", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4,967.00", "Payee", TableAction.GetText).Message.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);

                // 
                // 
                Reports.TestStep = "Navigate to Deposit in Escrow for a title only file..";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Enter amount greater than seller.";
                FastDriver.DepositInEscrow.Amount.FASetText("6000.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItemBySendingKeys("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItemBySendingKeys("Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Test");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItemBySendingKeys("Buyer");
                FastDriver.BottomFrame.Save();
                Playback.Wait(20000);

                // 
                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                // 
                Reports.TestStep = "Verify the payee name as Buyer.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Buyer1Firstname Buyer1Lastname", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "6,008.00", "Payee", TableAction.GetText).Message.Clean());

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0003()
        {
            try
            {

                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                // 
                Reports.TestStep = "Create an AD-HOC instance of REB.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.FAClick();

                // 
                // 
                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization");
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText("REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText("Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem("CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText("Alameda");
                FastDriver.BusOrgAdhocDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Enter commission Amount.";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("30");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                // 
                // 
                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("Hudflinsr1");
                Playback.Wait(2000);
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");

                // 
                // 
                Reports.TestStep = "Click on Done.";
                Playback.Wait(3000);

                // 
                // 
                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItemBySendingKeys("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItemBySendingKeys("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItemBySendingKeys("Buyer");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                Playback.Wait(10000);

                // 
                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                // 
                Reports.TestStep = "Verify the payee name as Seller.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Support.AreEqual("Seller1FirstName Seller1Lastname", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4,967.00", "Payee", TableAction.GetText).Message.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);

                // 
                // 
                Reports.TestStep = "Navigate to Deposit in Escrow for a title only file..";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Enter amount greater than seller.";
                FastDriver.DepositInEscrow.Amount.FASetText("6000.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItemBySendingKeys("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItemBySendingKeys("Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Test");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItemBySendingKeys("Buyer");
                FastDriver.BottomFrame.Save();
                Playback.Wait(20000);

                // 
                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                // 
                Reports.TestStep = "Verify the payee name as Buyer.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Buyer1Firstname Buyer1Lastname", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "6,008.00", "Payee", TableAction.GetText).Message.Clean());

                //breakpoint


                Reports.TestDescription = "FM1765: History display order";

                // 
                // 
                Reports.TestStep = "Set an instance for Survey Details with charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                Playback.Wait(2000);
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("200.00");

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "Click on Print button.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "30.00", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                // 
                // 
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint();
                //FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod: "Print", timeoutSeconds: 1000);

                //
                Reports.TestStep = "Validate History display order.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "30.00", "Status", TableAction.GetText).Message.Clean());
                //line 1204
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM2286_FM2287_FM2621: Summarize disbursement information";

                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("Hudflinsr1");
                Playback.Wait(2000);
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "Validate the status and payee name.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Flood Insurance 1 for HUD Testing Name 1", "Status", TableAction.GetText).Message);
                Support.AreEqual("5.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Flood Insurance 1 for HUD Testing Name 1", "Amount", TableAction.GetText).Message.Clean());
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Verify the same Payee name in Disbursement History.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(8, "Flood Insurance 1 for HUD Testing Name 1", 8, TableAction.Click);
                Support.AreEqual("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Payee", "Flood Insurance 1 for HUD Testing Name 1", "Amount", TableAction.GetText).Message.Clean());
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Change the amounts entered for the charge Survey.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("12.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("13.00");

                //
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                //
                // 
                Reports.TestStep = "Validate the Changed amounts in Disbursement summary.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("25.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Payee", "Flood Insurance 1 for HUD Testing Name 1", "Amount", TableAction.GetText).Message.Clean());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM2252_FM2253: Split disbursement must reconcile";

                //
                //
                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("Hudflinsr1");
                Playback.Wait(2000);
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "Validate that active disbursement screen is loaded.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "select Pend status.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.SwitchToContentFrame();
                FastDriver.SplitDisbursement.WaitCreation(FastDriver.SplitDisbursement.Remove);

                // 
                // 
                Reports.TestStep = "Enter amount to split and saves changes made.";
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("2998.20" + FAKeys.Tab);
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FASetText("1998.80");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "Validate that amount is split and master amount shows M.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("M", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Split", "S.", TableAction.GetText).Message.Clean());

                // 
                // 
                Reports.TestStep = "Validate that One is in Pending.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);

                // 
                // 
                Reports.TestStep = "Validate that One is  in Created amount.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);

                // 
                // 
                Reports.TestStep = "Change the Seller charge field.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Validate the out of balance indicator.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("S.", "M*", "S.", TableAction.Click);
                Support.AreEqual("D*", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "S.", TableAction.GetText).Message.Clean());
                Support.AreEqual("D*", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "S.", TableAction.GetText).Message.Clean());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0006()
        {
            try
            {
                Reports.TestDescription = "FVDH: Field Validation for Disbursment History";

                //
                //
                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("Hudflinsr1");
                Playback.Wait(2000);
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "Validate that active disbursement screen is loaded.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "select Pend status.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.SwitchToContentFrame();
                FastDriver.SplitDisbursement.WaitCreation(FastDriver.SplitDisbursement.Remove);

                // 
                // 
                Reports.TestStep = "Enter amount to split and saves changes made.";
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("2998.20" + FAKeys.Tab);
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FASetText("1998.80");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "Validate that amount is split and master amount shows M.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("M", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Split", "S.", TableAction.GetText).Message.Clean());

                // 
                // 
                Reports.TestStep = "Validate that One is in Pending.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);

                // 
                // 
                Reports.TestStep = "Validate that One is  in Created amount.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);

                // 
                // 
                Reports.TestStep = "Change the Seller charge field.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Validate the out of balance indicator.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("S.", "M*", "S.", TableAction.Click);
                Support.AreEqual("D*", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "S.", TableAction.GetText).Message.Clean());
                Support.AreEqual("D*", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "S.", TableAction.GetText).Message.Clean());

                //breakpoint
                //
                Reports.TestStep = "Verify the disable Buttons in Disbursement History when highlighted disbursement is not issued.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("S.", "", "S.", TableAction.Click);
                Support.AreEqual("False", FastDriver.DisbursementHistory.ViewDetails.Enabled.ToString());
                Support.AreEqual("False", FastDriver.DisbursementHistory.Adjust.Enabled.ToString());
                Support.AreEqual("True", FastDriver.DisbursementHistory.AdHocAdjustment.Enabled.ToString());

                //
                //
                Reports.TestStep = "Navigate to disbursement summary and issue a pending disbursement.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "3.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                // 
                // 
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint();
               // if (IsOverDraftConfirmationDialogPresent())
                try
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                catch(Exception)
                {
                    this.FillPasswordConfirmationDlg();
                }
                //FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod: "Print", timeoutSeconds: 1000);

                //
                //
                Reports.TestStep = "Verify the enable Buttons in Disbursement History when highlighted disbursement is issued..";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
                Support.AreEqual("True", FastDriver.DisbursementHistory.ViewDetails.Enabled.ToString());
                Support.AreEqual("True", FastDriver.DisbursementHistory.Adjust.Enabled.ToString());
                Support.AreEqual("True", FastDriver.DisbursementHistory.AdHocAdjustment.Enabled.ToString());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0007()
        {
            try
            {
                Reports.TestDescription = "ES7575: Title/Escrow and Recording/Tax Fee Display Amount";

                //
                //
                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Add a fee in Fee Entry.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "11.11");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "22.22");

                // 
                // 
                Reports.TestStep = "Validate the amount is equal to disbursed amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("33.33", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "33.33", "Amount", TableAction.GetText).Message.Clean());

                // 
                // 
                Reports.TestStep = "Add fees from Recording tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction("Description", "Monument Fee", "Sel", TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction("Description", "Monument Fee", "Buyer Charge", TableAction.SetText, "13.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                // 
                Reports.TestStep = "Validate the sum of Title/Escrow and Recording/Tax Fee Display Amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("46.33", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "46.33", "Amount", TableAction.GetText).Message.Clean());
                Support.AreEqual("Fee Transfer", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "46.33", "Funds", TableAction.GetText).Message.Clean());

                //
                Reports.TestStep = "Validate the Payment method and sum amount_Record Tax is changed to Check from fee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.PayRecordingTax.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.WaitForScreenToLoad(FastDriver.RecordFeeTransferTaxDisb.New);
                FastDriver.RecordFeeTransferTaxDisb.New.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.GABcode.FASetText("247");
                FastDriver.RecordFeeTransferTaxDisb.Find.FAClick();
                Playback.Wait(5000);

                FastDriver.RecordFeeTransferTaxDisb.WaitForScreenToLoad(FastDriver.RecordFeeTransferTaxDisb.ChargeSelection);
                FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction("Description", "Monument Fee", "Sel", TableAction.On);

                //
                Reports.TestStep = "Validate the sum of Title/Escrow and Recording/Tax Fee Display Amount and Payment Method.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Fee Transfer", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "33.33", "Funds", TableAction.GetText).Message.Clean());
                Support.AreEqual("Check", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "13.00", "Funds", TableAction.GetText).Message.Clean());

                // 
                //
                Reports.TestStep = "Validate the Payment method and sum amount_Record Tax is changed to Fee from Check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.PayRecordingTax.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.WaitForScreenToLoad();
                FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction("Description", "Monument Fee", "Sel", TableAction.Off);
                FastDriver.RecordFeeTransferTaxDisb.Remove.FAClick();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Validate the sum of Title/Escrow and Recording/Tax Fee Display Amount and Payment Method.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Fee Transfer", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "46.33", "Funds", TableAction.GetText).Message.Clean());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]

        public void FMUC0035_REG0008()
        {
            try
            {
                Reports.TestDescription = "ES9896: Deliver Disbursement reports";
                //
                //
                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                //
                Reports.TestStep = "Add a lease charge";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");

                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                this.EnterFeeInTitleEscrowTab();

                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                this.EnterFeeInTitleEscrowTab();

                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                // 
                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("Hudflinsr1");
                Playback.Wait(2000);
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00" + FAKeys.Tab);

                // 
                Reports.TestStep = "Click on Scan button for scan.";


                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
               // FastDriver.DocumentRepository.Scan_DocsTab.FAClick();
                //FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //Playback.Wait(100000000);
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.Scan_FiltrTempTab);
                FastDriver.DocumentRepository.Scan_FiltrTempTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to hFastDriver.OpenImageDlg.OpenImage(this.ReadConfig("sharedLocation", () => AutoConfig.WFEServerName) + @"\LoadTestImage 513k.tif");
                // FastDriver.OpenImageDlg.OpenImage(@"C:\TFS2\Main_QA\Selenium\FASTSelenium\DocPrep\bin\Debug\Common\Support" + @"\ImageHaving12Pages.tif");
                // FastDriver.OpenImageDlg.OpenImage(@"C:" + @"\test.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow:false);
                Playback.Wait(4000); //wait for Save Document dialog (wbacause we are using AutoIt to handle it)
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "INST-Estimated Settlement Statement", "PO-Invoice", imageTrigger: "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                // 
                Reports.TestStep = "Validate the status and payee name.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Flood Insurance 1 for HUD Testing Name 1", "Status", TableAction.GetText).Message.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Flood Insurance 1 for HUD Testing Name 1", "Status", TableAction.Click);
                FastDriver.BottomFrame.Done();

                // 
                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                // 
                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.Add.FAClick();

                // 
                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Select Wire Instructions");
                FastDriver.SelectWireInstructionsDlg.SwitchToDialogContentFrame();
                if (!FastDriver.SelectWireInstructionsDlg.Instruction1.Selected)
                    FastDriver.SelectWireInstructionsDlg.Instruction1.FAClick();
                FastDriver.SelectWireInstructionsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Beneficiary Note 1");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                //
                Reports.TestStep = "Validate Deliver Disbursement  for Check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Check", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Funds", TableAction.GetText).Message.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                // Playback.Wait(100000000);
                // 
                // 
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint(); 
                
                //if (IsOverDraftConfirmationDialogPresent())
                try
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                catch(Exception)
                {
                    this.FillPasswordConfirmationDlg();
                }
                // FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod: "Print", timeoutSeconds: 1000);

                //
                Reports.TestStep = "Validate Deliver Disbursement  for Check from view details screen.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("C", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Issued", 3, TableAction.GetText).Message.Clean());
                Support.AreEqual("21.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Issued", 7, TableAction.GetText).Message.Clean());
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Issued", 7, TableAction.Click);
                FastDriver.DisbursementHistory.ViewDetails.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.ReleaseHold);

                //
                Reports.TestStep = "Validate Deliver Disbursement  for Fees.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("4.98", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Amount", TableAction.GetText).Message.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                Playback.Wait(5000);

                //if (IsOverDraftConfirmationDialogPresent())
                try
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                catch(Exception)
                {
                    this.FillPasswordConfirmationDlg();
                }

                //
                //
                Reports.TestStep = "Click on Cancel on ChangeFileStatusDlg.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 400);


                //
                Reports.TestStep = "Validate Deliver Disbursement  for Fee Transfer from view details screen.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("F", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(7, "4.98", 3, TableAction.GetText).Message.Clean());
                Support.AreEqual("Issued", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(7, "4.98", 1, TableAction.GetText).Message.Clean());
                FastDriver.DisbursementHistory.ViewDetails.FAClick();
                Support.AreEqual("True", FastDriver.DisbursementHistory.Deliver.Exists().ToString());
                FastDriver.DisbursementHistory.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow();

                //
                Reports.TestStep = "Validate Deliver Disbursement  for Wire.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("5.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Amount", TableAction.GetText).Message.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();
                Playback.Wait(2000);

                //
                Reports.TestStep = "Click on Disburse.";
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
               // if (IsOverDraftConfirmationDialogPresent())
                try
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                catch(Exception)
                {
                    this.FillPasswordConfirmationDlg();
                }
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //
                Reports.TestStep = "Validate Deliver Disbursement  for Wire from view details screen.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "W", 7, TableAction.GetText).Message.Clean());
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "W", 7, TableAction.Click);
                FastDriver.DisbursementHistory.ViewDetails.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.Deliver);
                FastDriver.EditDisbursement.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0009()
        {
            try
            {
                Reports.TestDescription = "ES10058_ES10059: Display IBA Disbursements on Active Disbursement Summary";

                //
                Reports.TestStep = "Login To Fast";
                this.Login();


                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                this.DepositCash("1000.00", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");
                FastDriver.BottomFrame.Save();

                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.RecordSummaryTable);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Add other Beneficiary details.";
                if (!FastDriver.SelectIBABeneficiaryDlg.OthersSelect.Selected)
                    FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText("Beneficiary Name1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText("Address Line 1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText("Address Line 2");
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText("Santa Ana");
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem("CA");
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText("92727");
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText("123456789");

                // 
                // 
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.SelectIBABeneficiaryDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Enter IBA Bank Account. Let the default account be selected.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                // 
                Reports.TestStep = "Select a IBA product if it is empty.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                if (string.IsNullOrEmpty(FastDriver.InterestBearingAccounts.IBAType.FAGetSelectedItem()))
                    FastDriver.InterestBearingAccounts.IBAType.FASelectItemBySendingKeys("4 FAST");
                FastDriver.InterestBearingAccounts.IBAType.SendKeys(FAKeys.Tab);
                // 
                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.TransactionTab.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.TransactionAmount);
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("2.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Save the document number.";
                Playback.Wait(10000);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                string docNumber = FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean();

                // 
                Reports.TestStep = "Verify the Fund is displayed as IBA.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("IBA# fbo Beneficiary Name1", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "IBA", "Payee", TableAction.GetText).Message.Clean());
                Support.AreEqual(docNumber, FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Issued", "Document #", TableAction.GetText).Message.Clean());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0010()
        {
            try
            {
                Reports.TestDescription = "ES9923 : Track adjustments to a disbursement / deposit in the Event Log";
                //
                Reports.TestStep = "Login To Fast";
                this.Login();


                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                this.DepositCash("1000.00", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");
                FastDriver.BottomFrame.Save();

                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.RecordSummaryTable);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Add other Beneficiary details.";
                if (!FastDriver.SelectIBABeneficiaryDlg.OthersSelect.Selected)
                    FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText("Beneficiary Name1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText("Address Line 1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText("Address Line 2");
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText("Santa Ana");
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem("CA");
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText("92727");
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText("123456789");

                // 
                // 
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.SelectIBABeneficiaryDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Enter IBA Bank Account. Let the default account be selected.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                // 
                Reports.TestStep = "Select a IBA product if it is empty.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                if (string.IsNullOrEmpty(FastDriver.InterestBearingAccounts.IBAType.FAGetSelectedItem()))
                    FastDriver.InterestBearingAccounts.IBAType.FASelectItemBySendingKeys("4 FAST");
                FastDriver.InterestBearingAccounts.IBAType.SendKeys(FAKeys.Tab);
                // 
                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.TransactionTab.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.TransactionAmount);
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("2.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Save the document number.";
                Playback.Wait(10000);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                string docNumber = FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean();

                // 
                Reports.TestStep = "Verify the Fund is displayed as IBA.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("IBA# fbo Beneficiary Name1", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "IBA", "Payee", TableAction.GetText).Message.Clean());
                Support.AreEqual(docNumber, FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Issued", "Document #", TableAction.GetText).Message.Clean());
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);

                //Breakpoint
                this.DepositCash("6.00", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");
                FastDriver.BottomFrame.Save();

                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                Reports.TestStep = "Highlight the deposit for 200$.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                Support.AreEqual("1,000.00", FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Tp", "R", "Amount", TableAction.GetText).Message.Clean());
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Change Adjustment Reason to Input Error.";
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Input Error");
                FastDriver.DepositAdjustment.Comment.FASetText("ADjusted to Input Error");
                FastDriver.BottomFrame.Save();

                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                Reports.TestStep = "Verifying for deposit adjustment";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                Playback.Wait(1000);
                //FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                 //FastDriver.EventTrackingLog.WaitForScreenToLoad();
                //FastDriver.EventTrackingLog.SwitchToContentFrame();
                 FastDriver.WebDriver.WaitForActionToComplete(() =>
                 {
                     return FastDriver.EventTrackingLog.EventTable.Text.Contains("[Deposit Adjustment]");
                 }, timeout: 220, idleInterval: 5);
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Deposit Adjustment]", "Event", TableAction.Click);
                Support.AreEqual("True", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Adjustment Reason").ToString());
                Support.AreEqual("True", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Document Number").ToString());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0011()
        {
            try
            {
                Reports.TestDescription = "ES13568 : Service Fees section - Display only Pending Service Fees";

                //
                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                this.DepositCash("1000.00", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");
                FastDriver.BottomFrame.Save();

                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.RecordSummaryTable);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Add other Beneficiary details.";
                if (!FastDriver.SelectIBABeneficiaryDlg.OthersSelect.Selected)
                    FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText("Beneficiary Name1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText("Address Line 1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText("Address Line 2");
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText("Santa Ana");
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem("CA");
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText("92727");
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText("123456789");

                // 
                // 
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.SelectIBABeneficiaryDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Enter IBA Bank Account. Let the default account be selected.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                // 
                Reports.TestStep = "Select a IBA product if it is empty.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                if (string.IsNullOrEmpty(FastDriver.InterestBearingAccounts.IBAType.FAGetSelectedItem()))
                    FastDriver.InterestBearingAccounts.IBAType.FASelectItemBySendingKeys("4 FAST");
                FastDriver.InterestBearingAccounts.IBAType.SendKeys(FAKeys.Tab);
                // 
                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.TransactionTab.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.TransactionAmount);
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("2.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();

                //
                Reports.TestStep = "Save the document number.";
                Playback.Wait(10000);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                string docNumber = FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean();

                // 
                Reports.TestStep = "Verify the Fund is displayed as IBA.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("IBA# fbo Beneficiary Name1", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "IBA", "Payee", TableAction.GetText).Message.Clean());
                Support.AreEqual(docNumber, FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Issued", "Document #", TableAction.GetText).Message.Clean());
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);

                //Breakpoint
                this.DepositCash("6.00", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");
                FastDriver.BottomFrame.Save();

                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                Reports.TestStep = "Highlight the deposit for 200$.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                Support.AreEqual("1,000.00", FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Tp", "R", "Amount", TableAction.GetText).Message.Clean());
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Change Adjustment Reason to Input Error.";
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Input Error");
                FastDriver.DepositAdjustment.Comment.FASetText("ADjusted to Input Error");
                FastDriver.BottomFrame.Save();

                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                // 
                Reports.TestStep = "Verifying for deposit adjustment";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                Playback.Wait(1000);

                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                //FastDriver.EventTrackingLog.SwitchToContentFrame();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Deposit Adjustment]", "Event", TableAction.Click);
                Support.AreEqual("True", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Adjustment Reason").ToString());
                Support.AreEqual("True", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Document Number").ToString());
                //BreakPoint

                // 
                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.ClickNew();

                // 
                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.WaitCreation(FastDriver.PayeeSearchDlg.OfficeTable);
                int tableCount = FastDriver.PayeeSearchDlg.OfficeTable.GetRowCount();
                FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction(tableCount, 1, TableAction.On);

                // 
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.PayeeSearchDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                // 
                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("999.00" + FAKeys.Tab);

                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                // 
                Reports.TestStep = "Verify the Pend service fee.";
                Support.AreEqual("Pending Service Fee Transfers exist. Do you wish to navigate away from this page?", FastDriver.WebDriver.HandleDialogMessage());

                // 
                // 
                Reports.TestStep = "Verify the Transfer All Pend Service Fees with Fee Transfer option.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.TransferAllServiceFees.Enabled.ToString());
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.ServiceFeeTable.PerformTableAction("Amount", "999.00", "Status", TableAction.GetText).Message.Clean());


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0012()
        {
            try
            {
                Reports.TestDescription = "ES13569_ES13570: Transfer All Pending Service Fees with Fee Transfer, No Service Fee Transfer Report";

                //
                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                this.DepositCash("1000.00", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");
                FastDriver.BottomFrame.Save();

                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                // 
                Reports.TestStep = "Select Service Fee from Fee Entry nav tree and select offices";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.ClickNew();

                // 
                Reports.TestStep = "Create Service Fee Transaction";
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.WaitCreation(FastDriver.PayeeSearchDlg.OfficeTable);
                int tableCount = FastDriver.PayeeSearchDlg.OfficeTable.GetRowCount();
                FastDriver.PayeeSearchDlg.OfficeTable.PerformTableAction(tableCount, 1, TableAction.On);

                // 
                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.PayeeSearchDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                // 
                Reports.TestStep = "Enter Service Fees";
                FastDriver.ServiceFee.WaitForScreenToLoad();
                FastDriver.ServiceFee.ServiceFeeAmount.FASetText("999.00" + FAKeys.Tab);

                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                // 
                Reports.TestStep = "Verify the Pend service fee.";
                Support.AreEqual("Pending Service Fee Transfers exist. Do you wish to navigate away from this page?", FastDriver.WebDriver.HandleDialogMessage());

                // 
                // 
                Reports.TestStep = "Verify the Transfer All Pend Service Fees with Fee Transfer option.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.TransferAllServiceFees.Enabled.ToString());
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.ServiceFeeTable.PerformTableAction("Amount", "999.00", "Status", TableAction.GetText).Message.Clean());
                //Breakpoint

                // 
                Reports.TestStep = "Navigating to Service Fee screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();

                // 
                Reports.TestStep = "Click on Tranfer All button.";
                FastDriver.ServiceFee.TransferAll.FAClick();
                Playback.Wait(5000);

                // 
                Reports.TestStep = "Highlight the required row";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();
                FastDriver.ServiceFee.Table.PerformTableAction(1, "Transmitted", 1, TableAction.Click);

                // 
                Reports.TestStep = "Click on Transfer details button";
                FastDriver.ServiceFee.TransferDetaiLs.FAClick();
                FastDriver.TransferDetailsDlg.WaitForScreenToLoad();
                FastDriver.TransferDetailsDlg.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.TransferDetailsDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0013()
        {
            try
            {
                Reports.TestDescription = "ES13111_ES13110_1: Check Trial Balance Note  checkbox in ADM";
                //
                Reports.TestStep = "Login To Fast";
                this.Login(true);

                // 
                Reports.TestStep = "To Enable trial Balance checkbox.";

                if (AutoConfig.SelectedOfficeName == "QA AUTOMATION OFFICE - CD")
                {
                    FastDriver.LeftNavigation.Navigate<ProcessingRegionSetup>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>AUTOCD").WaitForScreenToLoad();

                }

                else
                {
                    FastDriver.LeftNavigation.Navigate<ProcessingRegionSetup>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST").WaitForScreenToLoad();
                }

                if (!FastDriver.ProcessingRegionSetup.EnableTrialBalance.Selected)
                    FastDriver.ProcessingRegionSetup.EnableTrialBalance.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0014()
        {
            try
            {
                Reports.TestDescription = "ES13111_ES13110_2: Allow User to Enter Trial Balance Note";


                //
                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                // this.DepositCash("1000.00", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");
                //FastDriver.BottomFrame.Save();

                // 
                // 
                Reports.TestStep = "Validate that active disbursement screen is loaded.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Verify the Note button is enabled.";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.Note.Enabled.ToString(), "Validates Button Note is Enabled");

                // 
                Reports.TestStep = "Click on Note button.";
                FastDriver.ActiveDisbursementSummary.Note.FAClick();
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Enter data in Textbox.";
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("Balance Note accept value asdfgshxfshvxvhvxgsxcgbxjxchshshsed" + FAKeys.Tab);
                FastDriver.TrialBalanceNoteDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                // 
                Reports.TestStep = "Validate the Trial Balance note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                //Support.AreEqual("True", FastDriver.FileNotes.Table.PerformTableAction("Created By", "FASTQA07", "Note", TableAction.GetText).Message.Clean().Contains("Balance Note accept value asdfgshxfshvxvhvxgsxcgbxjxchshshsed").ToString());
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Balance Note accept value asdfgshxfshvxvhvxgsxcgbxjxchshshsed").ToString());

                // 
                Reports.TestStep = "Click on Trial Balance note.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                FastDriver.EscrowFileBalanceSummary.TrialBalanceNote.FAClick();

                // 
                Reports.TestStep = "Enter a note from File Balance Summary screen.";
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("Note From File Balance Summary");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                // 
                Reports.TestStep = "Validate the Trial Balance note entered from File Balance Summary screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Note From File Balance Summary").ToString());
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Balance Note accept value asdfgshxfshvxvhvxgsxcgbxjxchshshsed").ToString());

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0016()
        {
            try
            {
                Reports.TestDescription = "TBNFV: Field validation of Trial Balance Note";
                //
                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                Reports.TestStep = "Enter invalid data in Balance Note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Note.FAClick();
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText(@"Enter special characters like @#""/");
                FastDriver.TrialBalanceNoteDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();

                // 
                Reports.TestStep = "Verify the Error message in Balance Note Dialog.";
                Support.AreEqual("Please enter a valid Trial Balance Note.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false));

                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                // 
                Reports.TestStep = "Click on Note button.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Note.FAClick();

                // 
                // 
                Reports.TestStep = "Enter invalid data in Balance Note length max 61.";
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("dfsgdfgbvcbgfjnhgfcbxd12234fbfgnfgmfn fngfghjhmb nfgnfnnhhjhyt687877");
                FastDriver.TrialBalanceNoteDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();

                // 
                Reports.TestStep = "Verify the Error message in Balance Note Dialog.";
                string message = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                Support.AreEqual("True", message.Contains("Error: Internal Comment length of 68 exceeds maximum of 61.").ToString());
                Support.AreEqual("True", message.Contains("Reduce the size of the internal comment to 61 or less to save.").ToString());


                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                  

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0035_REG0016A()
        {
            try
            {
                Reports.TestDescription = "TBNFV: Field validation For Print All checks button.";

                //
                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                Reports.TestStep = "Navigate to Survey screen.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                // 
                Reports.TestStep = "Navigate to Survey & entering GAB.";
                FastDriver.SurveyDetail.FindGABCode("247");

                // 
                Reports.TestStep = "Edit the instance and save the changes made.";
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00" + FAKeys.Tab);

                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                // 
                Reports.TestStep = "Validate that active disbursement screen is loaded.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                // 
                Reports.TestStep = "Validate the enable button.";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.PrintAll.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.DisburseAll.Enabled.ToString());

                // 
                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                Keyboard.SendKeys("^L");
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod: "Print", timeoutSeconds: 1000);

                //FastDriver.ServiceFee.TransferDetaiLs.FAClick();
                //FastDriver.TransferDetailsDlg.WaitForScreenToLoad();
                //Keyboard.SendKeys("^L");
                ////FastDriver.WebDriver.HandleDialogMessage();
                //FastDriver.PrintDlg.WaitForScreenToLoad();
                //FastDriver.PrintDlg.ClickCancel();
                //FastDriver.TransferDetailsDlg.WaitForScreenToLoad();
                ////FastDriver.TransferDetailsDlg.SwitchToDialogBottomFrame();
                //FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0016B()
        {
            try
            {
                Reports.TestDescription = "TBNFV: Field validation For Print All checks button.";

                //
                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                Reports.TestStep = "Create Fast Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                Reports.TestStep = "Navigate to Survey screen.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                // 
                Reports.TestStep = "Navigate to Survey & entering GAB.";
                FastDriver.SurveyDetail.FindGABCode("247");

                // 
                Reports.TestStep = "Edit the instance and save the changes made.";
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00" + FAKeys.Tab);

                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                // 
                Reports.TestStep = "Validate that active disbursement screen is loaded.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                // 
                Reports.TestStep = "Validate the enable button.";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.PrintAll.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.DisburseAll.Enabled.ToString());

                // 
                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod: "Print", timeoutSeconds: 1000);

                //breakpoint
                // 
                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.HomeWarrantyDetail.paidSeller.FASetText("Home Warranty");
                    FastDriver.HomeWarrantyDetail.BuyerBroker.FASetText("300.00" + FAKeys.Tab);
                }

                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("300.00" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("275.00" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.EarlyCoverageChargeDescription.FASetText("Home Warranty - Early Coverage" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FASetText("699.00" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FASetText("845.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                // 
                Reports.TestStep = "Validate that active disbursement screen is loaded.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                // 
                Reports.TestStep = "Validate the enable button.";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.PrintAll.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.DisburseAll.Enabled.ToString());

                // 
                Reports.TestStep = "Select Issued Disb and verify Print All Button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.PrintAll.Enabled.ToString());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0016C()
        {
            try
            {
                Reports.TestDescription = "TBNFV: Field validation For Print All checks button.";


                //
                Reports.TestStep = "Login To Fast";
                this.Login();

                // 
                Reports.TestStep = "Click on skip button to go to QFE.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();

                // 
                Reports.TestStep = "Create a Master file.";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                Playback.Wait(2000);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.UseAsMasterFile.FASetCheckbox(true);
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Navigate to Survey & entering GAB.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                Playback.Wait(2000);

                // 
                Reports.TestStep = "Edit the instance and save the changes made.";
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00" + FAKeys.Tab);

                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);

                // 
                Reports.TestStep = "In order to issue a disbursement, the file may not be designated as a Master File";
                FastDriver.HomePage.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.TreeView.FindElement(By.LinkText("Home")).FAClick();
                FastDriver.LeftNavigation.TreeView.FindElement(By.LinkText("Order Entry")).FAClick();
                FastDriver.LeftNavigation.TreeView.FindElement(By.LinkText("Escrow Closing")).SendKeys("+");
                Playback.Wait(2000);
                FastDriver.LeftNavigation.TreeView.FindElement(By.LinkText("Disbursements")).SendKeys("+");
                Playback.Wait(2000);
                FastDriver.LeftNavigation.TreeView.FindElement(By.LinkText("Active Disbursement Summary")).FAClick();
                Support.AreEqual("In order to issue a disbursement, the file may not be designated as a Master File.", FastDriver.WebDriver.HandleDialogMessage());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        //SRT FMUC0035_REG0016D,FMUC0035_REG0016E
        [TestMethod]
        public void FMUC0035_REG0016D()
        {
            try
            {
                Reports.TestDescription = "System shall display New Check box for Reorder File Notes. (Existing Office)";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                //FastDriver.LeftNavigation<FASTSelenium.PageObjects.SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                //FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);


                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "9879", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.Selected)
                {
                    FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.FASetCheckbox(true);
                }
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestDescription = "Create a New File and Navigate to Active Disbursement screen and enter the Trail Balance Note";

                Reports.TestStep = "Login To Fast IIS server";
                this.Login();
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                FastDriver.SecuritySelectRegionOffice.EnterBUID("2578");
                Reports.TestStep = "Create a Basic file";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                Playback.Wait(2000);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickRefiFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickRefiFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickRefiFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //FastDriver.TopFrame.SearchFileByFileNumber("51855");
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to Active Disbursement scree and Add Trail Balance Note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                Playback.Wait(5000);
                Reports.TestStep = "Verify the Note button is enabled.";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.Note.Enabled.ToString(), "Validates Button Note is Enabled");
                Playback.Wait(4000);
                Reports.TestStep = "Click on Note button.";
                FastDriver.ActiveDisbursementSummary.Note.FAClick();
                Playback.Wait(4000);
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter data in Textbox.";
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("Trail Balance Note" + FAKeys.Tab);
                FastDriver.TrialBalanceNoteDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(4000);
                Reports.TestStep = "Validate the Trial Balance note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                //Support.AreEqual("True", FastDriver.FileNotes.Table.PerformTableAction("Created By", "FASTQA07", "Note", TableAction.GetText).Message.Clean().Contains("Balance Note accept value asdfgshxfshvxvhvxgsxcgbxjxchshshsed").ToString());
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Trail Balance Note").ToString());

                Reports.TestStep = "Navigate to Active Disbursement scree and Update the Trail Balance Note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                Playback.Wait(5000);
                Reports.TestStep = "Verify the Note button is enabled.";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.Note.Enabled.ToString(), "Validates Button Note is Enabled");
                Playback.Wait(4000);
                Reports.TestStep = "Click on Note button.";
                FastDriver.ActiveDisbursementSummary.Note.FAClick();
                Playback.Wait(4000);
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter data in Textbox.";
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("Updated Trail Balance Note" + FAKeys.Tab);
                FastDriver.TrialBalanceNoteDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(4000);
                Reports.TestStep = "Validate the Trial Balance note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                //Support.AreEqual("True", FastDriver.FileNotes.Table.PerformTableAction("Created By", "FASTQA07", "Note", TableAction.GetText).Message.Clean().Contains("Balance Note accept value asdfgshxfshvxvhvxgsxcgbxjxchshshsed").ToString());
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Updated Trail Balance Note").ToString());
            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0016E()
        {
            try
            {
                Reports.TestDescription = "System shall display New Check box for Reorder File Notes. (Existing Office)";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                //FastDriver.LeftNavigation<FASTSelenium.PageObjects.SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                //FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);


                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "9879", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.Selected)
                {
                    FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.FASetCheckbox(false);
                }
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestDescription = "Create a New File and Navigate to Active Disbursement screen and enter the Trail Balance Note";

                Reports.TestStep = "Login To Fast IIS server";
                this.Login();
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                FastDriver.SecuritySelectRegionOffice.EnterBUID("2578");
                Reports.TestStep = "Create a Basic file";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                Playback.Wait(2000);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickRefiFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickRefiFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickRefiFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //FastDriver.TopFrame.SearchFileByFileNumber("51855");
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to Active Disbursement scree and Add Trail Balance Note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                Playback.Wait(5000);
                Reports.TestStep = "Verify the Note button is enabled.";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.Note.Enabled.ToString(), "Validates Button Note is Enabled");
                Playback.Wait(4000);
                Reports.TestStep = "Click on Note button.";
                FastDriver.ActiveDisbursementSummary.Note.FAClick();
                Playback.Wait(4000);
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter data in Textbox.";
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("Trail Balance Note" + FAKeys.Tab);
                FastDriver.TrialBalanceNoteDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(4000);
                Reports.TestStep = "Validate the Trial Balance note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                //Support.AreEqual("True", FastDriver.FileNotes.Table.PerformTableAction("Created By", "FASTQA07", "Note", TableAction.GetText).Message.Clean().Contains("Balance Note accept value asdfgshxfshvxvhvxgsxcgbxjxchshshsed").ToString());
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Trail Balance Note").ToString());

                Reports.TestStep = "Navigate to Active Disbursement scree and Update the Trail Balance Note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                Playback.Wait(5000);
                Reports.TestStep = "Verify the Note button is enabled.";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.Note.Enabled.ToString(), "Validates Button Note is Enabled");
                Playback.Wait(4000);
                Reports.TestStep = "Click on Note button.";
                FastDriver.ActiveDisbursementSummary.Note.FAClick();
                Playback.Wait(4000);
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter data in Textbox.";
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("Updated Trail Balance Note" + FAKeys.Tab);
                FastDriver.TrialBalanceNoteDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(4000);
                Reports.TestStep = "Validate the Trial Balance note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                //Support.AreEqual("True", FastDriver.FileNotes.Table.PerformTableAction("Created By", "FASTQA07", "Note", TableAction.GetText).Message.Clean().Contains("Balance Note accept value asdfgshxfshvxvhvxgsxcgbxjxchshshsed").ToString());
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Updated Trail Balance Note").ToString());
            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }


        [TestMethod]
        public void FMUC0035_REG0017_PH()
        {

            try
            {
                Reports.TestDescription = "ES9919_ES9920_ES9921_ES9922_ES12804_ES12805_ES13113_ES13330_ES13331_ES13339_ES13340_ES13341_ES14701_ES14991_ES14990: Interface related.";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

                // 
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            //Assert.AreEqual(true, Reports.TestResult, "TestSuccess:Refer Test Reports for Details");

        }


        [TestMethod]
        public void FMUC0035_REG0018()
        {
            try
            {
                Reports.TestDescription = "Active Disbursement Issued Check TRACK Note";
                Reports.TestDescription = "System shall display New Check box for Reorder File Notes. (Existing Office)";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration


                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);


                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.Selected)
                {
                    FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.FASetCheckbox(true);
                }
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestDescription = "Create a New File and Navigate to Active Disbursement screen and enter the Track Note";

                Reports.TestStep = "Login To Fast IIS server";
                this.Login();
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                FastDriver.SecuritySelectRegionOffice.EnterBUID("1487");
                Reports.TestStep = "Create a Basic file";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                Playback.Wait(2000);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin1.FASetText("#2 First American Way");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin2.FASetText("Test Address 2");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin3.FASetText("Test Address 3");
                FastDriver.QuickRefiFileEntry.PropertyCity.FASetText("Santa Clara");
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickRefiFileEntry.PropertyZip.FASetText("92706");
                FastDriver.QuickRefiFileEntry.PropertyCounty.FASetText("Santa Clara");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //FastDriver.TopFrame.SearchFileByFileNumber("51855");
                Playback.Wait(3000);

                Reports.TestStep = "Set an instance for Survey Details with charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                Reports.TestStep = "Navigate to disbursement summary and issue a pending Check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                Reports.TestStep = "Click on Deliver Button.";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();

                Reports.TestStep = "Navigate to disbursement summary, Select Issued Check and Enter the TRACK note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Issued", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.FASetText("Issued Check TRACK Note." + FAKeys.Tab);
                FastDriver.TrackDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Validate the Track note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Issued Check TRACK Note.").ToString());

                Reports.TestStep = "Navigate to disbursement summary, Select Issued Check and Update the TRACK note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Issued", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.FASetText("Issued Check TRACK Note UPDATED." + FAKeys.Tab);
                FastDriver.TrackDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Validate the UPDATED Track note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Issued Check TRACK Note UPDATED.").ToString());
            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0019()
        {
            try
            {
                Reports.TestDescription = "Active Disbursement Transferred Fee TRACK Note";
                Reports.TestDescription = "System shall display New Check box for Reorder File Notes. (Existing Office)";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration


                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);


                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.Selected)
                {
                    FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.FASetCheckbox(true);
                }
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestDescription = "Create a New File and Navigate to Active Disbursement screen and enter the Track Note";

                Reports.TestStep = "Login To Fast IIS server";
                this.Login();
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                FastDriver.SecuritySelectRegionOffice.EnterBUID("1487");
                Reports.TestStep = "Create a Basic file";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                Playback.Wait(2000);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin1.FASetText("#2 First American Way");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin2.FASetText("Test Address 2");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin3.FASetText("Test Address 3");
                FastDriver.QuickRefiFileEntry.PropertyCity.FASetText("Santa Clara");
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickRefiFileEntry.PropertyZip.FASetText("92706");
                FastDriver.QuickRefiFileEntry.PropertyCounty.FASetText("Santa Clara");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //FastDriver.TopFrame.SearchFileByFileNumber("53861");
                Playback.Wait(3000);

                Reports.TestStep = "Add a fee in Fee Entry Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "11.11");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                Reports.TestStep = "Navigate to disbursement summary and Transfer the Fee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                //FastDriver.ChangeFileStatusDlg.FileStatus.FASelectItem("Open");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint();
                Playback.Wait(10000);
                Reports.TestStep = "Navigate to disbursement summary, Select Transferred Fee and Enter the TRACK note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.FASetText("Transferred Fee TRACK Note." + FAKeys.Tab);
                FastDriver.TrackDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Validate the Track note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Transferred Fee TRACK Note.").ToString());

                Reports.TestStep = "Navigate to disbursement summary, Select Issued Check and Update the TRACK note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.FASetText("Transferred Fee TRACK Note " + FAKeys.Tab);

                var TRACK = FastDriver.TrackDlg.TrackInfo.FAGetText().ToString();
                FastDriver.TrackDlg.TrackInfo.FASetText(TRACK + "UPDATED.");
                FastDriver.TrackDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Validate the UPDATED Track note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Transferred Fee TRACK Note UPDATED.").ToString());
            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\Hello.pdf")]
        public void FMUC0035_REG0020()
        {
            try
            {
                Reports.TestDescription = "Active Disbursement Issued Wire TRACK Note";
                Reports.TestDescription = "System shall display New Check box for Reorder File Notes. (Existing Office)";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration


                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);


                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.Selected)
                {
                    FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.FASetCheckbox(true);
                }
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestDescription = "Create a New File and Navigate to Active Disbursement screen and enter the Track Note";

                Reports.TestStep = "Login To Fast IIS server";
                this.Login();
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                FastDriver.SecuritySelectRegionOffice.EnterBUID("1487");
                Reports.TestStep = "Create a Basic file";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                Playback.Wait(2000);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin1.FASetText("#2 First American Way");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin2.FASetText("Test Address 2");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin3.FASetText("Test Address 3");
                FastDriver.QuickRefiFileEntry.PropertyCity.FASetText("Santa Clara");
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickRefiFileEntry.PropertyZip.FASetText("92706");
                FastDriver.QuickRefiFileEntry.PropertyCounty.FASetText("Santa Clara");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //FastDriver.TopFrame.SearchFileByFileNumber("53888");
                Playback.Wait(3000);

                Reports.TestStep = "Set an instance for Survey Details with charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Upload Wire Instruction Document in Document Repository Screen.";
                Reports.TestStep = "Click on Upload button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                //Playback.Wait(10000);
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.DocumentRepository.Upload.Click();
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                Playback.Wait(6000);
                var a = Reports.DEPLOYDIR;
                string abc = Reports.DEPLOYDIR + @"\Hello.pdf";
                FastDriver.UploadDocumentDlg.UploadFile(abc);
                FastDriver.SaveDocumentDlg.SaveDocument("Escrow: Misc", "SEC-WireInstOut", "test");
                Playback.Wait(2000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocumentRepository.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.DocumentRepository.SwitchToContentFrame();
                Support.AreEqual("Imaged", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "SEC-WireInstOut test", 9, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Set an instance for Survey Details with charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                Reports.TestStep = "Navigate to disbursement summary and issue a pending Check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                Playback.Wait(1000);
                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Select Wire Instructions");
                FastDriver.SelectWireInstructionsDlg.SwitchToDialogContentFrame();
                if (!FastDriver.SelectWireInstructionsDlg.Instruction1.Selected)
                    FastDriver.SelectWireInstructionsDlg.Instruction1.FAClick();
                FastDriver.SelectWireInstructionsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Beneficiary Note 1");
                FastDriver.BottomFrame.Save();
                Playback.Wait(1000);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Disburse.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Wire", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.Click();
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                // if (IsOverDraftConfirmationDialogPresent())
                try
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }
                catch (Exception)
                {
                    this.FillPasswordConfirmationDlg();
                }

                Reports.TestStep = "Navigate to disbursement summary, Select Transferred Fee and Enter the TRACK note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Wire", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.FASetText("Disbursed Wire TRACK Note." + FAKeys.Tab);
                FastDriver.TrackDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Validate the Track note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Disbursed Wire TRACK Note.").ToString());

                Reports.TestStep = "Navigate to disbursement summary, Select Disbursed Wire and Update the TRACK note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Wire", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.FASetText("Disbursed Wire TRACK Note " + FAKeys.Tab);

                var TRACK = FastDriver.TrackDlg.TrackInfo.FAGetText().ToString();
                FastDriver.TrackDlg.TrackInfo.FASetText(TRACK + "UPDATED.");
                FastDriver.TrackDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Validate the UPDATED Track note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Disbursed Wire TRACK Note UPDATED.").ToString());
            }

            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0035_REG0021()
        {
            try
            {
                Reports.TestDescription = "Active Disbursement Issued IBA TRACK Note";

                Reports.TestDescription = "System shall display New Check box for Reorder File Notes. (Existing Office)";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration


                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);


                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.Selected)
                {
                    FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.FASetCheckbox(true);
                }
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestDescription = "Create a New File and Navigate to Active Disbursement screen and enter the Track Note";

                Reports.TestStep = "Login To Fast IIS server";
                this.Login();
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                FastDriver.SecuritySelectRegionOffice.EnterBUID("1487");
                Reports.TestStep = "Create a Basic file";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                Playback.Wait(2000);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin1.FASetText("#2 First American Way");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin2.FASetText("Test Address 2");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin3.FASetText("Test Address 3");
                FastDriver.QuickRefiFileEntry.PropertyCity.FASetText("Santa Clara");
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickRefiFileEntry.PropertyZip.FASetText("92706");
                FastDriver.QuickRefiFileEntry.PropertyCounty.FASetText("Santa Clara");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //FastDriver.TopFrame.SearchFileByFileNumber("53923");
                Playback.Wait(3000);

                Reports.TestStep = "Add buyer with the property address as the current address";

                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Perform a Cash Deposit";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Perform a cash deposit.";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 500.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    CreditToSeller = false,
                    Comments = "Comments Before Save",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);


                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("200");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to disbursement summary, Select Issued IBA and Enter the TRACK note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "IBA", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.FASetText("IBA TRACK Note." + FAKeys.Tab);
                FastDriver.TrackDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Validate the Track note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("IBA TRACK Note.").ToString());

                Reports.TestStep = "Navigate to disbursement summary, Select Issued IBA and Update the TRACK note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "IBA", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.FASetText("IBA TRACK Note " + FAKeys.Tab);

                var TRACK = FastDriver.TrackDlg.TrackInfo.FAGetText().ToString();
                FastDriver.TrackDlg.TrackInfo.FASetText(TRACK + "UPDATED.");
                FastDriver.TrackDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Validate the UPDATED Track note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("IBA TRACK Note UPDATED.").ToString());

                //

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void FMUC0035_REG0022()
        {
            try
            {
                Reports.TestDescription = "Active Disbursement Issued Check, Fee Transferred, IBA TRACK Note";

                Reports.TestDescription = "System shall display New Check box for Reorder File Notes. (Existing Office)";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration


                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);


                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.Selected)
                {
                    FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.FASetCheckbox(true);
                }
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestDescription = "Create a New File and Navigate to Active Disbursement screen and enter the Track Note";

                Reports.TestStep = "Login To Fast IIS server";
                this.Login();
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                FastDriver.SecuritySelectRegionOffice.EnterBUID("1487");
                Reports.TestStep = "Create a Basic file";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                Playback.Wait(2000);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin1.FASetText("#2 First American Way");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin2.FASetText("Test Address 2");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin3.FASetText("Test Address 3");
                FastDriver.QuickRefiFileEntry.PropertyCity.FASetText("Santa Clara");
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickRefiFileEntry.PropertyZip.FASetText("92706");
                FastDriver.QuickRefiFileEntry.PropertyCounty.FASetText("Santa Clara");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //FastDriver.TopFrame.SearchFileByFileNumber("54032");
                Playback.Wait(3000);

                Reports.TestStep = "Add buyer with the property address as the current address";

                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Perform a Cash Deposit";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Perform a cash deposit.";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 30.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    CreditToSeller = false,
                    Comments = "Comments Before Save",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);

                Reports.TestStep = "Add a fee in Fee Entry Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "20");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Set an instance for Survey Details with charge amount.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("100.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("25");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();



                Reports.TestStep = "Navigate to disbursement summary and Transfer the Fee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                //FastDriver.ChangeFileStatusDlg.FileStatus.FASelectItem("Open");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint();
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to disbursement summary and issue a pending Check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                Reports.TestStep = "Click on Deliver Button.";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint();
                //FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");
                if (FastDriver.PasswordConfirmationDlg.LossPassword.IsDisplayed())
                    FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to disbursement summary, Select Issued IBA, Check, Wire and Update the TRACK note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "IBA", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.FASetText("Fee, Check and IBA TRACK Note." + FAKeys.Tab);
                FastDriver.TrackDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the Track note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Fee, Check and IBA TRACK Note.").ToString());

                Reports.TestStep = "Navigate to disbursement summary, Select Issued IBA, Check, Wire and Update the TRACK note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "IBA", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.FASetText("Fee, Check and IBA TRACK Note UPDATED." + FAKeys.Tab);
                FastDriver.TrackDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the Track note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Fee, Check and IBA TRACK Note UPDATED").ToString());

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void FMUC0035_REG0023()
        {
            try
            {
                Reports.TestDescription = "TRACK Note shall NOT Re-Order in Active Disbursement";
                Reports.TestDescription = "Active Disbursement Issued Check, Fee Transferred, IBA TRACK Note";

                Reports.TestDescription = "System shall display New Check box for Reorder File Notes. (Existing Office)";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration


                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);


                Reports.TestStep = "Navigate to Office Summary.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office and click on Edit.";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                if (!FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.Selected)
                {
                    FastDriver.OfficeSetupOffice.SortFileNotesnewesttooldest.FASetCheckbox(false);
                }
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestDescription = "Create a New File and Navigate to Active Disbursement screen and enter the Track Note";

                Reports.TestStep = "Login To Fast IIS server";
                this.Login();
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();

                FastDriver.SecuritySelectRegionOffice.EnterBUID("1487");
                Reports.TestStep = "Create a Basic file";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("248");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                Playback.Wait(2000);
                FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin1.FASetText("#2 First American Way");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin2.FASetText("Test Address 2");
                FastDriver.QuickRefiFileEntry.PropertyBookAddrLin3.FASetText("Test Address 3");
                FastDriver.QuickRefiFileEntry.PropertyCity.FASetText("Santa Clara");
                FastDriver.QuickRefiFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickRefiFileEntry.PropertyZip.FASetText("92706");
                FastDriver.QuickRefiFileEntry.PropertyCounty.FASetText("Santa Clara");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                //FastDriver.TopFrame.SearchFileByFileNumber("54032");
                Playback.Wait(3000);

                Reports.TestStep = "Add buyer with the property address as the current address";

                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters()
                {
                    First = "Buyer1Firstname",
                    Middle = "Buyer1Middlename",
                    Last = "Buyer1Lastname",
                    SSN = "123-45-6789",
                    CurrentSetToProperty = true,
                });
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Perform a Cash Deposit";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Perform a cash deposit.";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 30.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    CreditToSeller = false,
                    Comments = "Comments Before Save",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);

                Reports.TestStep = "Add a fee in Fee Entry Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "20");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Set an instance for Survey Details with charge amount.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("100.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to IBA screen and create a new Beneficiary";
                FastDriver.InterestBearingAccounts.Open();
                //
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitCreation(FastDriver.InterestBearingAccounts.SummarySeq);
                //
                Reports.TestStep = "Select buyer as beneficiary";
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Select IBA Bank details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                FastDriver.DialogBottomFrame.ClickDone();
                //
                Reports.TestStep = "Enter the Transaction Amount and saving";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("25");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();



                Reports.TestStep = "Navigate to disbursement summary and Transfer the Fee.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                //FastDriver.ChangeFileStatusDlg.FileStatus.FASelectItem("Open");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint();
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to disbursement summary and issue a pending Check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                Reports.TestStep = "Click on Deliver Button.";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint();
                //FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");
                if (FastDriver.PasswordConfirmationDlg.LossPassword.IsDisplayed())
                    FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to disbursement summary, Select Issued IBA, Check, Wire and Update the TRACK note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "IBA", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.FASetText("Fee, Check and IBA TRACK Note." + FAKeys.Tab);
                FastDriver.TrackDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the Track note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Fee, Check and IBA TRACK Note.").ToString());

                Reports.TestStep = "Navigate to disbursement summary, Select Issued IBA, Check, Wire and Update the TRACK note.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "IBA", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.FASetText("Fee, Check and IBA TRACK Note UPDATED." + FAKeys.Tab);
                FastDriver.TrackDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the Track note entered from Active Disbursement screen.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.FileNotes.Table.FAGetText().Contains("Fee, Check and IBA TRACK Note UPDATED").ToString());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        private void SetBuyerCharge(IWebElement TableCharges, string DescriptionRow, string BuyerCreditValue)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 3, TableAction.SetText, BuyerCreditValue);

        }


        #endregion REG
        #region Custom Class Methods
        private void Login(bool admLogin = false)
        {
            if (!admLogin)
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,                // AutoConfig.UserName,
                    Password = AutoConfig.UserPassword            //AutoConfig.UserPassword
                };
                // FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            }
            else
            {
                var credentials = new Credentials()
                {
                    // UserName = AutoConfig.UserName,
                    //Password = AutoConfig.UserPassword
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                // FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            }

        }


        private string ReadConfig(string key, Func<string> readConfig)
        {
            string configValue = "";
            try
            {
                configValue = readConfig.Invoke();
            }
            catch (Exception)
            {
                throw new Exception(string.Format("There was an error reading the selected environment from AutoConfig.XML. {0} key not found.", key));
            }

            if (configValue == string.Empty)
                throw new Exception(string.Format("Please provide a config value for key '{0}' under environment '{1}' in AutoConfig.XML.", key, Support.TESTENVIRONMENT));

            return configValue;
        }

        private bool IsOverDraftConfirmationDialogPresent()
        {
            try
            {
                string windowName = "Overdraft Confirmation";
               // string url = windowName.ToLower().StartsWith("url:") ? "with \"" + windowName.Substring(4) + "\" in url" : windowName;
                WebDriverWait wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(20));
                wait.Until(w => { return FastDriver.WebDriver.WindowIsDisplayed(windowName); });
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }

        }
        private void CreateFileWithWCF(CreateFileRequest fileRequest)
        {
            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        }

        private void EnterFeeInTitleEscrowTab()
        {
            Reports.TestStep = "Enter first fee in Title and escrow.";
            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99");
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99");
        }

        private void FillPasswordConfirmationDlg()
        {
            Reports.TestStep = "Enter password confimation details dialog info.";
            FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
            FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
            FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
            FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");
            FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);
            Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
            FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();
        }

        private void DepositCash(string Amount, string TypeOfFund, string Representing, string Description, string ReceivedFrom, string Payor, string Comment = null)
        {
            FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
            FastDriver.DepositInEscrow.Amount.FASetText(Amount);
            FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(TypeOfFund);
            FastDriver.DepositInEscrow.Representing.FASelectItem(Representing);
            FastDriver.DepositInEscrow.Description.FASetText(Description);
            FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(ReceivedFrom);
            FastDriver.DepositInEscrow.Payor.FASetText(Payor);
            if (Comment != null)
                FastDriver.DepositInEscrow.Comment.FASetText(Comment);
        }

        public CreateFileRequest GetDetailedCreateFileDefaultRequest()
        {
            #region CreateFileRequest
            return new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,
                File = new File()
                {
                    SalesPriceAmount = 5000.00m,
                    LiabilityAmount = 3000.00m,
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "RESIDENTAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    BusinessParties = new FileBusinessParty[] 
                    { 
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        } 
                    },
                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[]
                    { 
                        new Property() 
                        {
                            Name = "J305",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",
                            Tract = "Tract",
                            Building = "Building",
                            Book = "Book",
                            Page = "Page",
                            Section = "section",
                            Township = "Township",
                            Range = "Range",
                            Parcel = "Parcel",
                            Condominium = "Subdivision1",
                            PropertyTypeObjectCD = "SF",
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA" 
                                }
                            },
                            Taxes = new FASTWCFHelpers.FastFileService.Taxes[]
                            {
                                new FASTWCFHelpers.FastFileService.Taxes()
                                {
                                    TaxID = "Prop1APN1",
                                    GenTaxCheck = false,
                                    TotalInstallmentTax = 500

                                },
                                new FASTWCFHelpers.FastFileService.Taxes()
                                {
                                    TaxID = "9845012345",
                                    TaxYear = "2006-2007",
                                    GenTaxCheck = false,
                                    TotalInstallmentTax = 0
                                }
                            }                        
                        } 
                    },
                    Buyers = new BuyerSeller[] 
                    { 
                        new BuyerSeller() 
                        { 
                            Type = "Individual",
                            SSN = "123-45-6789",
                            FirstName = "Buyer1Firstname",
                            LastName = "Buyer1Lastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband and Wife",
                            FirstName = "Buyer2Firstname",
                            LastName = "Buyer2Lastname",
                            SpouseFirstName = "Buyer2SpouseName",
                            SpouseLastName = "Buyer2Lastname"
                        }
                    },
                    Sellers = new BuyerSeller[] 
                    {
                        new BuyerSeller() 
                        {
                            Type = "Individual",
                            SSN = "987-65-4321",
                            FirstName = "Seller1FirstName",
                            LastName = "Seller1Lastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband and Wife",
                            FirstName = "Seller2Firstname",
                            LastName = "Seller2Lastname",
                            SpouseFirstName = "Seller2SpouseName",
                            SpouseLastName = "Seller2Lastname"
                        }
                    },
                    NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                    {
                        LoanNumber = "WCF_DefaultLoanNumber",
                        NewLoanAmount = 5000.00m,
                        LiabilityAmount = 5000.00m,
                        BenMortgageeTextID = 0,
                        FileBusinessParty = new FileBusinessParty
                        {
                            Name = "Nhat Nguyen",
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        },
                        LoanTypeCdID = 0,
                        FundDate = DateTime.Today
                    },
                    FileNotes = new FileNote[] 
                    { 
                        new FileNote()
                        {
                            TypeCdID = 695, //EPIC
                            Note = @"Notes Data including - * # Specialcharacter :) !"
                        }
                    }
                }
            };
            #endregion
        }


        #endregion Custom Class Methods

        #region Class CleanUp
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
        #endregion Class Cleanup
    }
}
