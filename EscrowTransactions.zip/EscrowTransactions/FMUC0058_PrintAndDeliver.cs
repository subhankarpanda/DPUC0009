﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.PageObjects.ADM;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using FASTWCFHelpers;

namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0058 : MasterTestClass
    {
        #region BAT

        #region FMUC0058_BAT0001
        [TestMethod]
        public void FMUC0058_BAT0001()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("MF1_01: Logint TO FAST Application and creating a file.", "", true);
                #endregion

                #region Seller Details
                Reports.TestStep = "Enter Seller Details with 1099 S details";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();

                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "Seller1FirstName Seller1Lastname", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Individual");
                Playback.Wait(2000);

                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Seller First Name");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Seller Last Name");
                FastDriver.BuyerSellerSetup.IndividualsClassification.FASelectItemBySendingKeys("1099-S");
                FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
                Playback.Wait(3000);

                FastDriver.BottomFrame.Done();

                #region Select HUD Type as Legacy on New Loan
                Reports.TestStep = " Select HUD Type as Legacy on New Loan";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                Playback.Wait(10000);
                FastDriver.NewLoan.LoanDetailsHUDType_Legacy.FAClick();
                #endregion

                #region Navigate to TDS screen and Enter Sales price and TAB
                Reports.TestStep = "Navigate to TDS screen and Enter Sales price and TAB";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem().ToString());
                FastDriver.TermsDatesStatus.SetSalesPriceAmount("45464");
                //Support.SendKeys(FAKeys.Tab);
                #endregion

                #region Click on Ok Button
                //Reports.TestStep = "Click on Ok Button";
                //FastDriver.ConfirmationDlg.WaitForScreenToLoad();
                //FastDriver.ConfirmationDlg.OK.FAClick();
                #endregion

                #region Click on Cancel Button
                //Reports.TestStep = "Click the Cancel Button";
                //FastDriver.ConfirmationDlg.WaitForScreenToLoad();
                //FastDriver.ConfirmationDlg.Cancel.FAClick();
                #endregion

                #region Navigate to TDS screen and Enter
                Reports.TestStep = "Navigate to TDS screen and Enter";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem().ToString());
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(@"07-12-2012");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                #endregion

                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_BAT0002
        [TestMethod]
        public void FMUC0058_BAT0002()
        {
            //This test have some changes in comparison with it TestCase for lack of updated documentation.
            try
            {
                #region Login & Create File
                this.basicSteps("AF1: Navigating to Proration Tax sceen, entering Buyer Charge, Navigating to 1099-S Screen.");
                #endregion

                #region Click on Edit on Proration Tax screen.
                Reports.TestStep = "Click on Edit on Proration Tax screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                #endregion

                #region Verify the Proration Details screen.
                Reports.TestStep = "Verify the proration Details screen";
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.ProrationDetail.CreditSeller.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.IsSelected().ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.Amount.FAGetText());
                Support.AreEqual("", FastDriver.ProrationDetail.FromDate.FAGetText());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.IsSelected().ToString());
                Support.AreEqual("YEAR", FastDriver.ProrationDetail.Per.FAGetSelectedItem().ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.ToDate.FAGetValue().ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.IsSelected().ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.IsSelected().ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.FAGetText().ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.FAGetText().ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.FAGetText().ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.FAGetText().ToString());
                #endregion

                #region NavigatetTo Proration Tax screen and Enter Buyer Charge
                Reports.TestStep = "Navigate to Proration Tax screen and Enter Buyer Charge";
                FastDriver.ProrationDetail.Amount.FASetText("300");
                FastDriver.ProrationDetail.BuyerCharge.FASetText("300");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to 10099-S screen and verify for property description
                Reports.TestStep = "Navigate to 10099-S screen and verify for property description";
                FastDriver.LeftNavigation.Navigate<_1099S> (@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("J305, JJEJAMQ, JJEJAMQ, ALBANY, CA 9270", FastDriver._1099S.PropertyDescription.FAGetValue());
              //  Playback.Wait(100000000);
                FastDriver._1099S.PropertyConsideration.FAClick();
                Support.AreEqual("300.00", FastDriver._1099S.BuyersRETaxAmountLabel.FAGetText().ToString());
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Cancel Button
                Reports.TestStep = "Click on Cancel Button";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                #endregion

                #region Navigate to 1099-S screen and enter data
                Reports.TestStep = "Navigate to 1099-S screen and enter data.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.ActiveReadyForExtract.FAClick();
                //FastDriver._1099S.ActiveZip.FASetText("23659");
                FastDriver.BottomFrame.Save();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_BAT0003
        [TestMethod]
        public void FMUC0058_BAT0003()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("AF2: Creating AD-HOC Entry");
                #endregion

                #region Navigate to 1099-S and Create Ad-Hoc
                Reports.TestStep = "Navigate to 1099-S and Create Ad-Hoc";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("J305, JJEJAMQ, JJEJAMQ, ALBANY, CA 9270", FastDriver._1099S.PropertyDescription.FAGetValue().ToString());
                FastDriver._1099S.AdHoc.FAClick();
                Support.AreEqual("J305, JJEJAMQ, JJEJAMQ, ALBANY, CA 9270", FastDriver._1099S.PropertyDescription.FAGetValue().ToString());
                Support.AreEqual("S=Social Security Number", FastDriver._1099S.SSNTINType.FAGetSelectedItem().ToString());
                FastDriver._1099S.SSNTIN.FASetText("123456789");
                FastDriver._1099S.ActiveFirstName.FASetText("Ad-HOC First Name");
                FastDriver._1099S.ActiveMiddleName.FASetText("A");
                FastDriver._1099S.ActiveLastName.FASetText("Ad-HOC Last Name");
                FastDriver._1099S.ActiveAddress.FASetText("Ad-HOC Address");
                FastDriver._1099S.ActiveCity.FASetText("Santa Ana");
                FastDriver._1099S.ActivecboState.FASelectItemBySendingKeys("CA");
                FastDriver._1099S.ActiveZip.FASetText("12345");
                FastDriver.BottomFrame.Save();
                Support.MessageHandler(true);
                #endregion

                #region Additional Step
                Reports.TestStep = "Creating an Settlement Date (Additional Step)";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("03-15-2016");
                FastDriver.BottomFrame.Done();
                Support.MessageHandler(true);
                #endregion

                #region Navigate to 1099-S screen and check Ready For Extract checkbox
                Reports.TestStep = "Navigate to 1099-S screen and check Ready for Extract checkbox";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.ActiveReadyForExtract.FAClick();
                FastDriver.BottomFrame.Save();
                Support.MessageHandler(true);
                #endregion

                #region Perform Preview Delivery
                Reports.TestStep = "Perform Preview Delivery";
                Playback.Wait(10000);
                Support.SendKeys("^L");
                FastDriver._1099S.WaitForScreenToLoad();

                #endregion

                #region Print the checks
                Playback.Wait(5000);
                Support.MessageHandler();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                Playback.Wait(1000);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_BAT0004
        [TestMethod]
        public void FMUC0058_BAT0004()
        {
            try
            {
                #region Login Fast AMD
                this.basicSteps("Defect_80762: Validating the defect.", "ADM");
                #endregion

                #region Enter 1099-S Activity Date
                Reports.TestStep = "Enter 1099-S Activity Date";
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878");
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                Support.AreEqual("QA Automation Office - DO NOT TOUCH", FastDriver.OfficeSetupOffice.OfficeName.FAGetValue().ToString());
                Support.AreEqual("Residential", FastDriver.OfficeSetupOffice.BusinessSegment.FAGetSelectedItem());
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("07-12-2012");
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_BAT0005
        [TestMethod]
        public void FMUC0058_BAT0005()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("Defect_80762_02: Validating the defect");
                #endregion

                #region Click on skip button to go on QFE
                //Test Step done on basicSteps().
                Reports.TestStep = "Click on skip button to go on QFE";
                Reports.StatusUpdate("Test Step done with WebServices", true);
                #endregion

                #region Create Order
                //Order Created on basicSteps().
                Reports.TestStep = "Create Order";
                Reports.StatusUpdate("Test Step done with WebServices", true);
                #endregion

                #region Enter Seller Seller Details with 1099-S details
                Reports.TestStep = "Enter Seller Detail with 1099-S details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers");
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "Seller1FirstName Seller1Lastname", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Individual");
                Support.AreEqual("Individual", FastDriver.BuyerSellerSetup.BuyerTypes.FAGetSelectedItem().ToString());
                Playback.Wait(2000);
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Seller First Name");
                Support.AreEqual("Seller First Name", FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue().ToString());
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Seller Last Name");
                Support.AreEqual("Seller Last Name", FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue().ToString());
                FastDriver.BuyerSellerSetup.IndividualsClassification.FASelectItemBySendingKeys("1099-S");
                FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #endregion

        #region REG

        #region FMUC0058_REG0001
        [TestMethod]
        public void FMUC0058_REG0001()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6512_ES6513_EXPECTEDFailure: Create file and Validate the BRs.Validate the date manually");
                #endregion

                #region Changing TermsDatesSalesPrice
                Reports.TestStep = "Changing TermsDatesSalesPrice for this Test";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("250001");
                Support.SendKeys("{TAB}");
                Support.MessageHandler(true);
                Support.MessageHandler(true);
                FastDriver.BottomFrame.Done();
                #endregion
                
                #region Navigate to TDS screen and Enter the current date as settlement date.
                Reports.TestStep = "Navigate to TDS screen and Enter the current date as settlement date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Now.ToString("M-d-yyyy"));
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                #endregion

                #region Navigate to "Home/Order Entry/Sellers"
                Reports.TestStep = "Navigate to Home>Order Entry>Sellers";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers");
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date
                Reports.TestStep = "Navigate to TDS screen and Enter the settlement date as past date to current system date";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Today.AddDays(Convert.ToInt32("-2")).ToString("M-d-yyyy"));
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                #endregion

                #region Select Proration Tax1 and click on Edit button
                Reports.TestStep = "Select Proration Ta1 and click on Edit button";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                #endregion

                #region Change the per Field to DAY
                Reports.TestStep = "Change the per Field to DAY";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("DAY");
                Playback.Wait(1000);
                #endregion

                #region Verify for RE tax
                Reports.TestStep = "Verify for RE tax";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                Support.AreEqual("0.00", FastDriver._1099S.Ten99sSTable.PerformTableAction(4, 4, TableAction.GetText).Message.Clean());
                #endregion

                #region Verify for Settlement date
                Reports.TestStep = "Verify for Settlement date";
                Support.AreEqual(DateTime.Today.AddDays(Convert.ToInt32("-2")).ToString("M-d-yyyy"), FastDriver._1099S.Ten99sSTable.PerformTableAction(1, 4, TableAction.GetText).Message.Clean());
                #endregion

                #region Verify for sale price
                Reports.TestStep = "Verify for sale price";
                Support.AreEqual("250,001.00", FastDriver._1099S.Ten99sSTable.PerformTableAction(2, 4, TableAction.GetText).Message.Clean());
                #endregion

                #region Enter Property Description
                Reports.TestStep = "Enter Property Description";
                FastDriver._1099S.PropertyDescription.FASetText("Property Description Modified");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify Property Description
                Reports.TestStep = "Verify Property Description";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("Property Description Modified", FastDriver._1099S.PropertyDescription.FAGetValue());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0002
        [TestMethod]
        public void FMUC0058_REG0002()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6514: Select Property Description Type");
                #endregion

                #region Verify for Blank AbbreviatedLegalDescription
                Reports.TestStep = "Verify for Blank AbbreviatedLegalDescription";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.AbbreviatedLegalDescription.FAClick();
                Support.AreEqual("", FastDriver._1099S.PropertyDescription.FAGetValue());
                #endregion

                #region Verify for Blank APN                
                Reports.TestStep = "Verify for Blank APN";
                FastDriver._1099S.APN.FAClick();
                Support.AreEqual("", FastDriver._1099S.PropertyDescription.FAGetValue());
                FastDriver.BottomFrame.Reset();
                Playback.Wait(7000);
                #endregion

                #region Click on Ok Button
                Reports.TestStep = "Click on Ok Button";
                Support.MessageHandler(true);
                #endregion

                #region Navigate to property tax info and Enter Abbreviated Legal Desc and APN.
                Reports.TestStep = "Navigate to property tax info and Enter Abbreviated Legal Desc and APN.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.Table.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.LegalDescriptionTab.FAClick();
                FastDriver.PropertyTaxInfoLegal.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoLegal.AbbrLegalDesciptionComments.FASetText("AbbrevatedLegalDescriptionComment");
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.New.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASetText("9876543210");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok Button
                Reports.TestStep = "Click on Ok button";
                Support.MessageHandler(true);
                #endregion

                #region Verify for blank AbbreviatedLegalDescription
                Reports.TestStep = "Verify for blank AbbreviatedLegalDescription";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.AbbreviatedLegalDescription.FAClick();
                Support.AreEqual("AbbrevatedLegalDescriptionComment", FastDriver._1099S.PropertyDescription.FAGetValue());
                #endregion

                #region Verify for blank APN
                Reports.TestStep = "Verify for blank APN";
                FastDriver._1099S.APN.FAClick();
                Support.AreEqual("9876543210", FastDriver._1099S.PropertyDescription.FAGetValue());
                FastDriver.BottomFrame.Save();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0003
        [TestMethod]
        public void FMUC0058_REG0003()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6515_ES6516_ES6517_ES6939_ES6941_ES6518_ES6519_Precondition: Enter Activity date in the Adm side", "ADM");
                #endregion

                #region Enter 1099-S Activity Date from Office setup.
                Reports.TestStep = "Enter 1099-S Activity Date from Office setup.";
                Playback.Wait(15000);
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878");
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("08-10-2011");
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0004
        [TestMethod]
        public void FMUC0058_REG0004()
        {
            try
            {
                #region Login to Admin site and retrieve the Owmning office 1099 date.
                this.Login("Login to Admin site","ADM");
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>STEST>Offices>7878").WaitForScreenToLoad();
                //DateTime owningOfficeDate = DateTime.Parse(FastDriver.OfficeSetupOffice.ActivityDate1099s.FAGetValue());
                string originalOwningofficeDate = FastDriver.OfficeSetupOffice.ActivityDate1099s.FAGetValue();
                //DateTime settlementDate = owningOfficeDate.Subtract(2);
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("10-10-2010");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance");
                FastDriver.WebDriver.Quit();
                #endregion Login to Admin site and retrieve the Owmning office 1099 date.
                
                #region Login & Create File
                //this.basicSteps("BR_ES6515_ES6516_ES6517_ES6939_ES6941_ES6518_ES6519: Create file with multiple sellers and Validate the BRs related to Gross Proceeds.");
                this.Login("BR_ES6515_ES6516_ES6517_ES6939_ES6941_ES6518_ES6519: Create file with multiple sellers and Validate the BRs related to Gross Proceeds.");
                #endregion

                //Customized Creation of File.
                this.CustomFileCreation();

                #region Verify for the seller name concatenation and the sequence of the display
                Reports.TestStep = "Verify for the seller name concatenation and the sequence of the display";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("S1FN S1MN S1LN Sir", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S1FN S1MN S1LN Sir", 1, TableAction.GetText).Message.Clean(), "Verifies the content of  SellerORAo-HOc is: S1FN S1MN S1LN Sir");
                Support.AreEqual("260,000.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "260,000.00", 5, TableAction.GetText).Message.Clean(), "Verifies the content of  GrossProceedDollor is: 260,000.00");
                #endregion

                #region Verify on the Seller Name
                Reports.TestStep = "Verify on the Seller Name.";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("S2FN S2MN S2LN Dr", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S2FN S2MN S2LN Dr", 1, TableAction.GetText).Message.Clean(), "Verifying that seller name is: S2FN S2MN S2LN Dr");
                #endregion

                #region Verify on the Seller Name
                Reports.TestStep = "Verify on the Seller Name.";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("S2SFN S2SMN S2SLN Sir", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S2SFN S2SMN S2SLN Sir", 1, TableAction.GetText).Message.Clean(), "Verifying that seller name is: S2SFN S2SMN S2SLN Sir");
                #endregion

                #region Verify on the Seller Name
                Reports.TestStep = "Verify on the Seller Name.";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("TrustShortName", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "TrustShortName", 1, TableAction.GetText).Message.Clean(), "Verifying that seller name is: TrustShortName");
                #endregion

                #region Endure the 1099S page is displayed in the browser
                Reports.TestStep = "Endure the 1099S page is displayed in the browser";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "TrustShortName", 1, TableAction.Click);
                Playback.Wait(3000);
                FASTHelpers.KeyboardSendKeys("520.00");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify for Gross Prceeds cannot be Zero. And click on Ok Button.
                Reports.TestStep = "Verify for Gross Proceeds cannot be Zero, and click on OK button.";
                Support.AreEqual("Total of Gross Proceeds for all records exceeds Sale Price.", FastDriver.WebDriver.HandleDialogMessage(), "Verifying that the message is: 'Gross Proceeds cannot be Zero'");
                #endregion

                #region Check the ready for extract check box and validate that it is checked
                Reports.TestStep = "Check the ready for extract check box and validate that it is checked.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.ActiveReadyForExtract.FAClick();
                Support.AreEqual("True", FastDriver._1099S.ActiveReadyForExtract.IsSelected().ToString().Clean(), "Verifying that the message is: True");
                FastDriver.WebDriver.Quit();
                #endregion

                #region Login to Admin site and Restore the Owmning office 1099 date.
                this.Login("Login to Admin site", "ADM");
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>STEST>Offices>7878").WaitForScreenToLoad();
                //DateTime owningOfficeDate = DateTime.Parse(FastDriver.OfficeSetupOffice.ActivityDate1099s.FAGetValue());
                //DateTime settlementDate = owningOfficeDate.Subtract(2);
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText(originalOwningofficeDate);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...",false);
                FastDriver.WebDriver.Quit();
                #endregion Login to Admin site and Restore the Owmning office 1099 date.
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0005
        [TestMethod]
        public void FMUC0058_REG0005()
        {
            try
            {
                #region Login & Create File
                //this.basicSteps("[FMUC0058_REG0005] BR_ES6522_ES6523_ES6942_ES6943_ES6944_ES6524: Create file with multiple sellers and Validate the BRs related to Buyers RE Tax.");
                this.Login("[FMUC0058_REG0005] BR_ES6522_ES6523_ES6942_ES6943_ES6944_ES6524: Create file with multiple sellers and Validate the BRs related to Buyers RE Tax.");
                #endregion

                //Customized creation of file
                this.CustomFileCreation();

                #region Select Proration Tax1 and click on Edit button
                this.SelectProrationTax1AndClickEdit();
                #endregion

                #region Change the per Field to DAY
                this.ChangePerFieldToDay();
                #endregion

                #region Click on Done.
                this.ClickOnDone();
                #endregion

                #region Click on New button
                this.ClickOnNew();
                #endregion

                #region Change the per field to MONTH
                this.ChangePerFieldToMonth();
                #endregion

                #region Navigate to 1099S screen
                this.NavigateTo1099S();
                #endregion

                #region Enter Gross Proceeds for the second record
                Reports.TestStep = "Enter Gross Proceeds for the seconds record.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S2FN S2MN S2LN Dr", 1, TableAction.Click);
                FASTHelpers.KeyboardSendKeys("12.00");
                #endregion

                #region Enter Gross Proceeds for the third record
                Reports.TestStep = "Gross Proceeds for the third record";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S2SFN S2SMN S2SLN Sir", 1, TableAction.Click);
                FASTHelpers.KeyboardSendKeys("500.00");
                #endregion

                #region Enter Gross Proceeds for the fourth record
                Reports.TestStep = "Enter Gross Proceeds for the fourth record";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "TrustShortName", 1, TableAction.Click);
                FASTHelpers.KeyboardSendKeys("500.00");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok Button
                Reports.TestStep = "Click on Ok Button";
                Support.MessageHandler(true);
                #endregion

                #region Verify whether the RE Tax is calculated properly for the second seller
                Reports.TestStep = "Verify whether the RE Tax is calculated properly for the second seller";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S1FN S S1LN Sir", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                FASTHelpers.KeyboardSendKeys("{TAB}");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                FASTHelpers.KeyboardSendKeys("100.00");
                #endregion

                #region Click on Save
                Reports.TestStep = "Click on Save";
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
                #endregion

                #region Verify for -Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax. and click on OK button.
                Reports.TestStep = " Verify for -Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax. and click on OK button.";
                Support.AreEqual("Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax.", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean(), "verify for -Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax. and click on OK button.");
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true, timeout: 5);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true, timeout: 5);
                FastDriver._1099S.WaitForScreenToLoad();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0006
        [TestMethod]
        public void FMUC0058_REG0006()
        {
            try
            {
                #region Set Activity Time to 2011
                this.SetUpActivityDateADM();
                #endregion

                #region Login & Create File
                this.basicSteps("[FMUC0058_REG0006] BR_ES6527_ES6528_ES6529_ES6544: Create file with multiple sellers and Validate BRs related to Payee Indicator and SSN/TIN Type", "", false, false);
                #endregion

                #region Navigate to the seller screen and add a Trust Estate seller
                Reports.TestStep = "Navigate to the seller screen and add a Trust Estate seller.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers");
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Trust/Estate");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("TrustShortName");
                FastDriver.BuyerSellerSetup.TrustSSNtext.FASetText("147852963");
                FastDriver.BuyerSellerSetup.TrustLastNameFor1099SReporting.FASetText("TrustLastName");
                FastDriver.BuyerSellerSetup.TrustSSNtype.FASelectItemBySendingKeys("1099-S");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for second seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("second", 3);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Select Proration Tax1 and Click on Edit Button
                this.SelectProrationTax1AndClickEdit();
                #endregion

                #region Change the per Field to DAY
                this.ChangePerFieldToDay();
                #endregion

                #region Click on Done.
                this.ClickOnDone();
                #endregion

                #region Click on New button
                this.ClickOnNew();
                #endregion

                #region Change the per field to MONTH
                this.ChangePerFieldToMonth();
                #endregion

                #region Add Adhoc record and enter correspnd address SSN TIN details
                Reports.TestStep = "Add Adhoc record and enter correspnd address SSN TIN details";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.AdHoc.FAClick();
                FASTHelpers.KeyboardSendKeys("600.00");
                Support.AreEqual("S=Social Security Number", FastDriver._1099S.SSNTINType.FAGetSelectedItem().ToString(), "Verifying that the selected value in SSNTINTType is: S=Social Security Number");
                FastDriver._1099S.SSNTIN.FASetText("1122334455");
                Support.AreEqual("1122334455", FastDriver._1099S.SSNTIN.FAGetValue().Clean(), "Verifying that the value of SSNTIN is: 1122334455");
                FastDriver._1099S.ActiveFirstName.FASetText("AdhocFirstName");
                FastDriver._1099S.ActiveMiddleName.FASetText("M");
                FastDriver._1099S.ActiveLastName.FASetText("AdhocLastName");
                FastDriver._1099S.ActiveAddress.FASetText("AdhocAddress");
                FastDriver._1099S.ActiveCity.FASetText("Irvine");
                FastDriver._1099S.ActivecboState.FASelectItemBySendingKeys("CA");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                FastDriver._1099S.ActiveZip.FASetText("92604");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Ensure the IEMessage window is displayed
                Reports.TestStep = "Ensure the IEMessage windows is displayed";
                FastDriver.WebDriver.HandleDialogMessage(false);
                FastDriver._1099S.WaitForScreenToLoad();
                #endregion

                #region Verify for the data saved for Adhoc entry
                Reports.TestStep = "Verify for the data saved for Adhoc entry.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocFirstName M AdhocLastName", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                FASTHelpers.KeyboardSendKeys("200.00");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("600.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocFirstName M AdhocLastName", 5, TableAction.GetText).Message.Clean(), "Verifying that GrossProceeedDollor is 200.00");
                Support.AreEqual("112-23-3445", FastDriver._1099S.SSNTIN.FAGetValue().Clean(), "Verifying that the value of SSNTIN is: 112-23-3445");
                Support.AreEqual("AdhocFirstName", FastDriver._1099S.ActiveFirstName.FAGetValue().Clean(), "Verifying that the value of ActiveFirstName is: AdhocFirstName");
                Support.AreEqual("M", FastDriver._1099S.ActiveMiddleName.FAGetValue().Clean(), "Verifying that the value of ActiveMiddleName is: M");
                Support.AreEqual("AdhocLastName", FastDriver._1099S.ActiveLastName.FAGetValue().Clean(), "Verifying that the value of ActiveLastName is: AdhocLastName");
                Support.AreEqual("AdhocAddress", FastDriver._1099S.ActiveAddress.FAGetValue().Clean(), "Verifying that the value of ActiveAddress is: AdhocAddress");
                Support.AreEqual("Irvine", FastDriver._1099S.ActiveCity.FAGetValue().Clean(), "Verifying that the value of ActiveCity is: Irvine");
                Support.AreEqual("CA", FastDriver._1099S.ActivecboState.FAGetSelectedItem().Clean(), "Verifying that the value of ActivecboState is: CA");
                Support.AreEqual("92604", FastDriver._1099S.ActiveZip.FAGetValue().Clean(), "Verifying that the value of SSNTIN is: 92604");
                #endregion

                #region Update Adhoc entry record information
                Reports.TestStep = "Update Adhoc entry record information";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.SSNTINType.FASelectItemBySendingKeys("T=Tax ID Number");
                Support.AreNotEqual("T = Tax ID Number", FastDriver._1099S.SSNTINType.FAGetSelectedItem().Clean(), "Verifying that the Selected Item is: T = Tax ID Number");
                Support.AreEqual("11-2233445", FastDriver._1099S.SSNTIN.FAGetValue().Clean(), "Verifying that the value of SSNTIN is: 11-2233445");
                //TestCase does not specify this step, but is necesary.
                FastDriver._1099S.PayeeIndicator.FASelectItemBySendingKeys("C = BusinessEntity");
                FastDriver._1099S.ActiveShortName.FASetText("AdhocBusinessEntityShortName");
                FastDriver._1099S.ActiveAddress.FASetText("AdhocAddressUpdated");
                FastDriver._1099S.ActiveCity.FASetText("Multonamah");
                FastDriver._1099S.ActivecboState.FASelectItemBySendingKeys("OR");
                FastDriver._1099S.ActiveZip.FASetText("92707");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify the updated Adhoc entry record information
                Reports.TestStep = "Verifying the updated Adhoc entry record information";
                FastDriver.WebDriver.HandleDialogMessage(false);
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocBusinessEntityShortName", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("T=Tax ID Number", FastDriver._1099S.SSNTINType.FAGetSelectedItem().Clean(), "Verify that the value of SSTINT Type is: T=Tax ID Number");
                Support.AreEqual("11-2233445", FastDriver._1099S.SSNTIN.FAGetValue().Clean(), "Verifying that the value of SSNTIN is: 11-2233445");
                Support.AreEqual("AdhocBusinessEntityShortName", FastDriver._1099S.ActiveShortName.FAGetValue().Clean(), "Verifying that the value of ActiveShortName is: AdhocBusinessEntityShortName");
                Support.AreEqual("AdhocAddressUpdated", FastDriver._1099S.ActiveAddress.FAGetValue().Clean(), "Verifying that the value of ActiveAddress is: AdhocAddressUpdated");
                Support.AreEqual("Multonamah", FastDriver._1099S.ActiveCity.FAGetValue().Clean(), "Verifying that the value of ActiveCity is: Multonamah");
                Support.AreEqual("OR", FastDriver._1099S.ActivecboState.FAGetValue().Clean(), "Verifying that the value of ActivecboState is: OR");
                Support.AreEqual("92707", FastDriver._1099S.ActiveZip.FAGetValue().Clean(), "Verifying that the value of ActivecboState is: 92707");
                #endregion

                #region Verify Assign Payee Indicator por Individual sellers
                Reports.TestStep = "Verify Assign Payee Indicator for Individual sellers";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S1FN S S1LN Sir", 1, TableAction.Click);
                #endregion

                #region Verifying Assign Payee Indicator dropdown disabled for Individual Sellers
                Reports.TestStep = "Verifying Assign Payee Indicator dropdown disabled for Individual Sellers";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver._1099S.PayeeIndicator.IsEnabled().ToString(), "Verifying that Assing Payee Indicator dropdown is disabled for individual seller is disabled.");
                #endregion

                #region Verify Assign Payee Indicator for Husband Wife Sellers.
                Reports.TestStep = "Verify Assign Payee Indicator for Husband Wife Sellers.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S2FN S2MN S2LN Dr", 1, TableAction.Click);
                #endregion

                #region Verifying Assign Payee Indicator dropdown disabled for Husband Wife Sellers
                Reports.TestStep = "Verifying Assign Payee Indicator dropdown disabled for HUsband Wife Sellers";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver._1099S.PayeeIndicator.IsEnabled().ToString(), "Verifying that Assing Payee Indicator dropdown is disabled for individual seller is disabled.");
                #endregion

                #region Verify Assign Payee Indicator for Husband Wife Sellers
                Reports.TestStep = "Verify Assign Payee Indicator for Husband Wife Sellers";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S2SFN S2SMN S2SLN Sir", 1, TableAction.Click);
                #endregion

                #region Verifying Assign Payee Indicator dropdown disabled for Husband Wife Sellers
                Reports.TestStep = "Verifying Assign Payee Indicator dropdown disabled for HUsband Wife Sellers";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver._1099S.PayeeIndicator.IsEnabled().ToString(), "Verifying that Assing Payee Indicator dropdown is disabled for individual seller is disabled.");
                #endregion

                #region Verify Assign Payee Indicator for Trust Estate Seller
                Reports.TestStep = "Verify Assign Payee Indicator for Trust Estate Seller";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "TrustShortName", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("S=Social Security Number", FastDriver._1099S.SSNTINType.FAGetSelectedItem().ToString(), "Verifying that the SSNTINType is: S = Social Security Number");
                #endregion

                #region Verify ASsign Payee Indicator for Business Entity seller.
                Reports.TestStep = "Verify Assign Payee Indicator for Business Entity seller.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocBusinessEntityShortName", 1, TableAction.Click);
                Support.AreEqual("T=Tax ID Number", FastDriver._1099S.SSNTINType.FAGetSelectedItem().ToString().Clean(), "Verifying that the SSNTINType is: T=Tax ID Number");
                Support.AreEqual("11-2233445", FastDriver._1099S.SSNTIN.FAGetValue().ToString().Clean(), "Verifying that the SSNTIN is: 11-2233445");
                #endregion

                #region Change SSNTIN Type to T=Tax ID Number type for Trust Estate seller.
                this.PerformSSNTINTypeChange("Change SSNTIN Type to T = Tax ID Number type for Trust Estate seller.", "TrustLastName, TrustShortName", "T=Tax ID Number", true, "300.00", true);
                #endregion

                #region Click the Ok Button.
                Reports.TestStep = "Click the Ok Button";
                FastDriver.WebDriver.HandleDialogMessage(true);
                #endregion

                #region Verify SSNTIN Type changed to T = Tax ID NUmber type for Trust Estate Seller
                this.SSNTINTypeChangeVerification("Verify SSNTIN Type changed to T = Tax ID Number type for Trust Estate seller.", "TrustLastName, TrustShortName", "T=Tax ID Number", "14-7852963");
                #endregion
                
                #region Change SSN TIN Tupe to F = Foreign Seller type for Trust Estate Seller
                this.PerformSSNTINTypeChange("Change SSNTIN Type to T = Tax ID Number type for Trust Estate seller.", "TrustLastName, TrustShortName", "F=Foreign Seller");
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Verify SSN TIN Type changed to F = Foreign Seller type for Trust Estate seller
                this.SSNTINTypeChangeVerification("Verify SSN TIN Type changed to F = Foreign Seller type for Trust Estate seller.", "TrustLastName, TrustShortName", "F=Foreign Seller", "14-7852963");
                #endregion

                #region Change SSN TIN Type to N = Did Not Provide for Trust Estate Seller
                this.PerformSSNTINTypeChange("Change SSN TIN Type to N = Did Not Provide for Trust Estate Seller.", "TrustLastName, TrustShortName", "N=Did Not Provide");
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Verify SSN TIN Type changed to N = Did Not Provide type for Trust Estate seller.
                this.SSNTINTypeChangeVerification("Verify SSN TIN Type changed to N = Did Not Provide type for Trust Estate seller.", "TrustLastName, TrustShortName", "N=Did Not Provide", "14-7852963");
                #endregion

                #region Change SSN TIN Type to S=Social Security Number
                this.PerformSSNTINTypeChange("Change SSN TIN Type to S=Social Security Number", "AdhocBusinessEntityShortName", "S=Social Security Number", true, "300.00", true);
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Verify SSN TIN Type changed to S = Social Security Number type for Business Entity seller
                this.SSNTINTypeChangeVerification("Verify SSN TIN Type changed to S = Social Security Number type for Business Entity seller", "AdhocBusinessEntityShortName", "S=Social Security Number", "112-23-3445", "300.00", true);
                #endregion

                #region Change SSN TIN Type to F=Foreign Seller type for Business Entity seller
                this.PerformSSNTINTypeChange("Change SSN TIN Type to F=Foreign Seller type for Business Entity seller", "AdhocBusinessEntityShortName", "F=Foreign Seller");
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Verify SSN TIN Type changed to F = Foreign Seller type for Business Entity seller
                this.SSNTINTypeChangeVerification("Verify SSN TIN Type changed to F = Foreign Seller type for Business Entity seller", "AdhocBusinessEntityShortName", "F=Foreign Seller", "11-2233445");
                #endregion

                #region Change SSN TIN Type to N=Did Not Provide type for Business Entity seller
                this.PerformSSNTINTypeChange("Change SSN TIN Type to N=Did Not Provided type for Business Entity seller", "AdhocBusinessEntityShortName", "N=Did Not Provide");
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Verify SSN TIN Type changed to F = Foreign Seller type for Business Entity seller
                this.SSNTINTypeChangeVerification("Verify SSN TIN Type changed to N=Did Not Provided type for Business Entity seller", "AdhocBusinessEntityShortName", "N=Did Not Provide", "11-2233445");
                #endregion

                #region Add Adhoc record and enter correspond address SSN TIN details
                Reports.TestStep = "Add Adhoc record and enter correspond address SSN TIN details";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.AdHoc.FAClick();
                FASTHelpers.KeyboardSendKeys("700.00");
                Support.AreEqual("S=Social Security Number", FastDriver._1099S.SSNTINType.FAGetSelectedItem().ToString(), "Verifying that the selected value in SSNTINTType is: S=Social Security Number");
                FastDriver._1099S.SSNTIN.FASetText("1122334455");
                Support.AreEqual("1122334455", FastDriver._1099S.SSNTIN.FAGetValue().Clean(), "Verifying that the value of SSNTIN is: 1122334455");
                FastDriver._1099S.ActiveFirstName.FASetText("AdhocFirstName");
                FastDriver._1099S.ActiveMiddleName.FASetText("M");
                FastDriver._1099S.ActiveLastName.FASetText("AdhocLastName");
                FastDriver._1099S.ActiveAddress.FASetText("AdhocAddress");
                FastDriver._1099S.ActiveCity.FASetText("Irvine");
                FastDriver._1099S.ActivecboState.FASelectItemBySendingKeys("CA");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                FastDriver._1099S.ActiveZip.FASetText("92604");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Ensure the IEMessage window is displayed
                Reports.TestStep = "Ensure the IEMessage windows is displayed";
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver._1099S.WaitForScreenToLoad();
                #endregion

                #region Verify for the data saved for Adhoc entry
                Reports.TestStep = "Verify for the data saved for Adhoc entry.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(6, 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                FASTHelpers.KeyboardSendKeys("700.00");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("700.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocFirstName M AdhocLastName", 5, TableAction.GetText).Message.Clean(), "Verifying that GrossProceeedDollor is 200.00");
                Support.AreEqual("112-23-3445", FastDriver._1099S.SSNTIN.FAGetValue().Clean(), "Verifying that the value of SSNTIN is: 112-23-3445");
                Support.AreEqual("AdhocFirstName", FastDriver._1099S.ActiveFirstName.FAGetValue().Clean(), "Verifying that the value of ActiveFirstName is: AdhocFirstName");
                Support.AreEqual("M", FastDriver._1099S.ActiveMiddleName.FAGetValue().Clean(), "Verifying that the value of ActiveMiddleName is: M");
                Support.AreEqual("AdhocLastName", FastDriver._1099S.ActiveLastName.FAGetValue().Clean(), "Verifying that the value of ActiveLastName is: AdhocLastName");
                Support.AreEqual("AdhocAddress", FastDriver._1099S.ActiveAddress.FAGetValue().Clean(), "Verifying that the value of ActiveAddress is: AdhocAddress");
                Support.AreEqual("Irvine", FastDriver._1099S.ActiveCity.FAGetValue().Clean(), "Verifying that the value of ActiveCity is: Irvine");
                Support.AreEqual("CA", FastDriver._1099S.ActivecboState.FAGetSelectedItem().Clean(), "Verifying that the value of ActivecboState is: CA");
                Support.AreEqual("92604", FastDriver._1099S.ActiveZip.FAGetValue().Clean(), "Verifying that the value of SSNTIN is: 92604");
                #endregion

                #region Change Payee Indicator for Adhoc seller
                this.PerformSSNTINTypeChange("Change Payee Indicator for Adhoc seller", "AdhocFirstName M AdhocLastName", "T=Tax ID Number", true, "", false, "1122334455", true, "AdhocTrustEstateShortName", true);
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Verify Payee indicator, SSNTIN type and SSNTIN Number format for adhoc selller
                this.SSNTINTypeChangeVerification("Verify Payee indicator, SSNTIN type and SSNTIN Number format for adhoc selller", "AdhocFirstName M AdhocLastName", "T=Tax ID Number", "11-2233445", "", false, "AdhocTrustEstateShortName", true);
                #endregion

                #region Change Payee indicator for Adhoc seller
                this.PerformSSNTINTypeChange("Change Payee Indicator for Adhoc seller", "AdhocTrustEstateShortName", "T=Tax ID Number", true, "", false, "1122334455", true, "AdhocBusinessShortName", true);
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Verify payee indicator, SSNTIN type an SSNTIN Number format for Adhoc seller
                FastDriver._1099S.WaitForScreenToLoad();
                this.SSNTINTypeChangeVerification("Verify payee indicator, SSNTIN type an SSNTIN Number format for Adhoc seller", "AdhocTrustEstateShortName", "T=Tax ID Number", "11-2233445", "", false, "AdhocBusinessShortName", true);
                #endregion

                #region Change SSTIN type to change SSNTIN Number format for Adhoc Seller
                this.PerformSSNTINTypeChange("Change SSTIN type to change SSNTIN Number format for Adhoc Seller", "AdhocBusinessShortName", "S=Social Security Number", true, "", false, "112-23-3445");
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Verify SSNTIN type and SSNTINNumber format for adhoc seller
                this.SSNTINTypeChangeVerification("Verify SSNTIN Type and SSTINNumber format for adhoc Seller", "AdhocBusinessShortName", "S=Social Security Number", "112-23-3445");
                #endregion

                #region Update SSNTIN type, blank SSNTIN Number and check ready for extract checkbox for Trust Estate seller
                Reports.TestStep = "Update SSTIN type, blank SSNTIN Number and check for exract checkbox for Trust Estate seller.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "TrustLastName, TrustShortName", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.SSNTINType.FASelectItemBySendingKeys("N=Did Not Provide");
                FastDriver._1099S.SSNTIN.FASetText("");
                FastDriver._1099S.ActiveReadyForExtract.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Verify SSNTIN type, blank SSNTIN NUmber and Ready for extract check box for Trust Estate seller
                Reports.TestStep = "Verify SSNTIN type, blank SSNTIN NUmber and Ready for extract check box for Trust Estate seller";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "TrustLastName, TrustShortName", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("N=Did Not Provide", FastDriver._1099S.SSNTINType.FAGetSelectedItem().ToString().Clean(), "Verifying that SSNTINT Type is: N=Did Not Provide");
                Support.AreEqual("", FastDriver._1099S.SSNTIN.FAGetText() , "Verifying that SSNTINT Number is: blank");
                Support.AreEqual("True", FastDriver._1099S.ActiveReadyForExtract.IsEnabled().ToString().Clean(), "Verifying that ActiveReadyForExtract is checked.");
                #endregion

                #region Set Activity Time to Today
                this.SetUpActivityDateADM(true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC_0058_REG0006, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0007
        //Merged with FMUC005_REG0006
        [TestMethod]
        public void FMUC0058_REG0007()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0058_REG0006";
                Reports.TestStep = "See test case FMUC0058_REG0006.";
                Reports.StatusUpdate("See test case FMUC0058_REG0006.", true);
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0007, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0008
        [TestMethod]
        public void FMUC0058_REG0008()
        {
            try
            {
                #region Set Activity Time to 2011
                this.SetUpActivityDateADM();
                #endregion

                #region Login & Create File
                this.basicSteps("BR_ES6532_ES6535_ES6961: File Settlement Date Later than Current System Date", "", false, false, 250001);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Check the Ready For Extract checkbox and click on save button
                Reports.TestStep = "Check the Ready for Extract checkbox and click on save button.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.ActiveReadyForExtract.FAClick();                                
                FastDriver.BottomFrame.Save();
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate("Navigate to TDS screen and Enter the settlement date as date later than the current system date.", "2");
                #endregion

                #region Click the Ok Button.
                Reports.TestStep = "Click the Ok Button";
                FastDriver.WebDriver.HandleDialogMessage(true);
                #endregion

                #region Check the Ready for Extract checkbox and click on save button
                Reports.TestStep = "Check the Ready for Extract checkbox and click on save button.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.ActiveReadyForExtract.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify for Settlement Date is later than today's date. Ok Message
                Reports.TestStep = "Verify for Settlement Date is later than today's date. Ok Message";
                Support.AreEqual("Settlement Date is later than today's date.", FastDriver.WebDriver.HandleDialogMessage(false).Clean(), "Settlement Date is later than today's date.");
                #endregion

                #region Verify ready for extract checkbox unchecked
                Reports.TestStep = "Verify Ready for Extract checkbox unchecked";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.ActiveReadyForExtract.FAClick();
                Support.AreEqual("False", FastDriver._1099S.ActiveReadyForExtract.IsSelected().ToString().Clean(), "Verify that Active Ready for Extract is cheched");
                #endregion

                #region Click the Ok Button.
                Reports.TestStep = "Click the Ok Button";
                FastDriver.WebDriver.HandleDialogMessage(true);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Click the Ok Button.
                Reports.TestStep = "Click the Ok Button";
                FastDriver.WebDriver.HandleDialogMessage(true);
                #endregion

                #region Check the Ready for Extract checkbox and click on save button
                Reports.TestStep = "Check the Ready for Extract checkbox and click on save button.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.ActiveReadyForExtract.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Modify the seller record data and save it
                Reports.TestStep = "Modify the seller record data and save it.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.ActiveFirstName.FASetText("First");
                FastDriver._1099S.ActiveMiddleName.FASetText("M");
                FastDriver._1099S.ActiveLastName.FASetText("Last");
                FastDriver._1099S.ActiveAddress.FASetText("Address123");
                FastDriver._1099S.ActiveCity.FASetText("New York");
                FastDriver._1099S.ActivecboState.FASelectItemBySendingKeys("NY");
                FastDriver._1099S.ActiveZip.FASetText("92707");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify ready for extract checkbox unchecked
                Reports.TestStep = "Verify Ready for Extract checkbox unchecked";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver._1099S.ActiveReadyForExtract.IsEnabled().ToString().Clean(), "Verify that Active Ready for Extract is cheched");
                #endregion

                #region Set Activity Time to Today
                this.SetUpActivityDateADM(true);
                #endregion
            }
            catch (Exception ex)
            {

                FailTest("The test FMUC0058_REG0008, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0009

        [TestMethod]
        public void FMUC0058_REG0009()
        {
            try
            {
                #region Set Activity Time to 2011
                this.SetUpActivityDateADM();
                #endregion

                #region Login & Create File
                this.basicSteps("BR_ES6536: Unmark Ready for Extract Automatically if User Changes Requi", "", false, false, 250001);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Check the Ready For Extract checkbox and click on save button
                Reports.TestStep = "Check the Ready for Extract checkbox and click on save button.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.ActiveReadyForExtract.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Navigate to TDS screen and Enter blank settlement date
                Reports.TestStep = "Navigate to TDS screen and Enter blank settlement date";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify ready for extract checkbox unchecked
                Reports.TestStep = "Verify Ready for Extract checkbox checked";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver._1099S.ActiveReadyForExtract.IsSelected().ToString().Clean(), "Verify that Active Ready for Extract is cheched");
                #endregion

                #region Click the Ok Button.
                Reports.TestStep = "Click the Ok Button";
                FastDriver.WebDriver.HandleDialogMessage(true);
                #endregion

                #region Set Activity Time to Today
                this.SetUpActivityDateADM(true);
                #endregion 
            }
            catch (Exception ex)
            {

                FailTest("The test FMUC_REG0009, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0010
        [TestMethod]
        public void FMUC0058_REG0010()
        {
            try
            {
                #region Set Activity Time to 2011
                this.SetUpActivityDateADM();
                #endregion

                #region Login & Create File
                this.basicSteps("BR_ES6537: Unmark a 1099-S Record Ready for Extract Manually", "", false, false, 250001);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Check the Ready For Extract checkbox and click on save button
                Reports.TestStep = "Check the Ready for Extract checkbox and click on save button.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.ActiveReadyForExtract.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify Ready for Extract checkbox checked
                Reports.TestStep = "Verify Ready for Extract checkbox checked";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver._1099S.ActiveReadyForExtract.IsSelected().ToString().Clean(), "Verify that Active Ready for Extract is cheched");
                #endregion

                #region Uncheck the Ready For Extract checkbox and click on save button
                Reports.TestStep = "Check the Ready for Extract checkbox and click on save button.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.ActiveReadyForExtract.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify Ready for Extract checkbox unchecked
                Reports.TestStep = "Verify Ready for Extract checkbox checked";
                Support.AreEqual("False", FastDriver._1099S.ActiveReadyForExtract.IsSelected().ToString().Clean(), "Verify that Active Ready for Extract is cheched");
                #endregion
            }
            catch (Exception ex)
            {

                FailTest("The test FMUC0058_REG0010, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0011
        [TestMethod]
        public void FMUC0058_REG0011()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6543_1: Enter Ad Hoc 1099-S Recipients", "", false, false, 250001);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Navigate to "Home>Order Entry>Terms/Dates/Status"
                Reports.TestStep = "Navigate to Home>Order Entry>Terms/Dates/Status";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("10,000,000,000.00");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                #endregion

                #region Verify for Sale Price exceeds maximun for regular 1099-S creation. Please create a manual 1099-S for the seller. Message.
                Reports.TestStep = "Verify for Sale Price exceeds maximun for regular 1099-S creation. Please create a manual 1099-S for the seller. Message.";
                Support.AreEqual("Sale Price exceeds maximum for regular 1099-S creation. Please create a manual 1099-S for the seller.", FastDriver.WebDriver.HandleDialogMessage(false).Clean(), "Verify that the message is: Sale Price exceeds maximum for regular 1099-S creation. Please create a manual 1099-S for the seller.");
                Playback.Wait(1000);
                #endregion

                #region Click on Cancel button
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                #endregion

                #region Click on Cancel button
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                #endregion

                #region Navigate to TDS screen and Enter sales Price more than 10,000,000,001.00
                Reports.TestStep = "Navigate to TDS screen and Enter sales Price more than 10,000,000,001.00";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("10,000,000,001.00");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                #endregion

                #region Verify for Sale Price exceeds maximum for regular 1099-S creation. Please create a manual 1099-S for the seller. Message.
                Reports.TestStep = "Verify for Sale Price exceeds maximum for regular 1099-S creation. Please create a manual 1099-S for the seller. Message.";
                Support.AreEqual("Sale Price exceeds maximum for regular 1099-S creation. Please create a manual 1099-S for the seller.", FastDriver.WebDriver.HandleDialogMessage(false).Clean(), "Verify that the message is: Sale Price exceeds maximum for regular 1099-S creation. Please create a manual 1099-S for the seller.");
                Playback.Wait(1000);
                #endregion

                #region Click on Cancel button
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                #endregion

                #region Click on Cancel button
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                #endregion

                #region Navigate to 1099S screen and verify for Adhoc button disabled
                Reports.TestStep = "Navigate to 1099S screen and verify for Adhoc button disabled.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver._1099S.AdHoc.IsEnabled().ToString().Clean(), "Verify that Adhoc Button is disabled.");
                FastDriver._1099S.ActiveReadyForExtract.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion
            }
            catch (Exception ex)
            {

                FailTest("The test FMUC0058_REG0011, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0012
        [TestMethod]
        public void FMUC0058_REG0012()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6543_2: Enter Ad Hoc 1099-S Recipients", "", false, false, 250001);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to "Home>Order Entry>Terms/Dates/Status"
                Reports.TestStep = "Navigate to Home>Order Entry>Terms/Dates/Status";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("9,999,999,999.00");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                #endregion

                #region Click on Ok Button
                Reports.TestStep = "Click on Ok Button";
                FastDriver.WebDriver.HandleDialogMessage(false);
                #endregion

                #region Click on Ok Button
                Reports.TestStep = "Click on Ok Button";
                FastDriver.WebDriver.HandleDialogMessage(false);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Navigate to 1099S screen
                this.NavigateTo1099S();
                #endregion

                #region Add Adhoc record and enter correspond address SSN TIN details
                Reports.TestStep = "Add Adhoc record and enter correspond address SSN TIN details.";
                FastDriver._1099S.AdHoc.FAClick();
                FastDriver._1099S.WaitForScreenToLoad();
                FASTHelpers.KeyboardSendKeys("700.00");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                Support.AreEqual("S=Social Security Number", FastDriver._1099S.SSNTINType.FAGetSelectedItem().ToString().Clean(), "Verifying that SSNTINT Type is: S=Social Security Number");
                FastDriver._1099S.SSNTIN.FASetText("1122334455");
                FastDriver._1099S.ActiveFirstName.FASetText("AdhocFirstName");
                FastDriver._1099S.ActiveMiddleName.FASetText("M");
                FastDriver._1099S.ActiveLastName.FASetText("AdhocLastName");
                FastDriver._1099S.ActiveAddress.FASetText("AdhocAddress");
                FastDriver._1099S.ActiveCity.FASetText("Irvine");
                FastDriver._1099S.ActivecboState.FASelectItemBySendingKeys("CA");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                FastDriver._1099S.ActiveZip.FASetText("92604");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Ensure de IEMessage windows is displayed
                this.ClickOkButton();
                #endregion

                #region Verify for the data saved for Adhoc entry
                Reports.TestStep = "Verify for the data saved for Adhoc entry";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocFirstName M AdhocLastName", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("700.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocFirstName M AdhocLastName", 5, TableAction.GetText).Message.Clean(), "Verifying that GrossProceedDollor is: 700.00");
                Support.AreEqual("112-23-3445", FastDriver._1099S.SSNTIN.FAGetValue().ToString().Clean(), "Verifying that SSNTINT is: 112-23-3445");
                Support.AreEqual("AdhocFirstName", FastDriver._1099S.ActiveFirstName.FAGetValue().ToString().Clean(), "Verifying that ActiveFirstName is: AdhocFirstName");
                Support.AreEqual("M", FastDriver._1099S.ActiveMiddleName.FAGetValue().ToString().Clean(), "Verifying that ActiveMiddleName is: M");
                Support.AreEqual("AdhocLastName", FastDriver._1099S.ActiveLastName.FAGetValue().ToString().Clean(), "Verifying that ActiveLastName is: AdhocLastName");
                Support.AreEqual("AdhocAddress", FastDriver._1099S.ActiveAddress.FAGetValue().ToString().Clean(), "Verifying that ActiveAddress is: AdhocAddress");
                Support.AreEqual("Irvine", FastDriver._1099S.ActiveCity.FAGetValue().ToString().Clean(), "Verifying that ActiveCity is: Irvine");
                Support.AreEqual("CA", FastDriver._1099S.ActivecboState.FAGetSelectedItem().ToString().Clean(), "Verifying that ActivecboState is: CA");
                Support.AreEqual("92604", FastDriver._1099S.ActiveZip.FAGetValue().ToString().Clean(), "92604");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0012, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0013
        [TestMethod]
        public void FMUC0058_REG0013()
        {
            try
            {
                #region Login to Admin site and retrieve the Owmning office 1099 date.
                this.Login("Login to Admin site", "ADM");
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>STEST>Offices>7878").WaitForScreenToLoad();
                //DateTime owningOfficeDate = DateTime.Parse(FastDriver.OfficeSetupOffice.ActivityDate1099s.FAGetValue());
                string originalOwningofficeDate = FastDriver.OfficeSetupOffice.ActivityDate1099s.FAGetValue();
                //DateTime settlementDate = owningOfficeDate.Subtract(2);
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("10-10-2010");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance");
                FastDriver.WebDriver.Quit();
                #endregion Login to Admin site and retrieve the Owmning office 1099 date.

                #region Login & Create File
                this.basicSteps("BR_ES6548_ES6961_ES6962_ES6549_ES6978: Validate the BRs", "", false, false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("second", 3);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Modify data for the first record.
                Reports.TestStep = "Modify data for the first record.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, 1, TableAction.Click);
                this.ModifyDataOfSelectedAdhoc("1234567890", "Seller1FirstName", "K", "Seller1LastName", "45 Bluejay", "Irvine", "CA", "92707");
                #endregion

                #region Select the second record and modify data.
                Reports.TestStep = "Select the second record and modify data.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S2FN S2MN S2LN Dr", 1, TableAction.Click);
                this.ModifyDataOfSelectedAdhoc("741852963", "Seller2FirstName", "M", "Seller2LastName", "1st American way", "Santa Ana", "CA", "92707", true, "700.00");
                #endregion

                #region Add Adhoc record and enter correspond address SSN TIN details
                Reports.TestStep = "Ad Adhoc record and enter correspond address SSN TIN details.";
                FastDriver._1099S.AdHoc.Click();
                this.ModifyDataOfSelectedAdhoc("1122334455", "AdhocFirstName", "M", "AdhocLastName", "AdhocAddress", "Irvine", "CA", "92604", true, "700.00", true, "S=Social Security Number");

                #endregion

                #region Verify data cached for the first record
                this.CheckActiveValuesOn1099SSummaryTable("Verify data cached for the first record", "Seller1FirstName K Seller1LastNa", "123-45-6789", "Seller1FirstName", "K", "Seller1LastName", "45 Bluejay", "Irvine", "CA", "92707");
                #endregion

                #region Verify data cached for second record.
                this.CheckActiveValuesOn1099SSummaryTable("Verify data cached for second record", "Seller2FirstName M Seller2LastNa", "741-85-2963", "Seller2FirstName", "M", "Seller2LastName", "1st American way", "Santa Ana", "CA", "92707", true, "700.00");
                #endregion

                #region Verify for the data saved for adhoc entry
                this.CheckActiveValuesOn1099SSummaryTable("Verify for the data saved for adhoc entry", "AdhocFirstName M AdhocLastName", "112-23-3445", "AdhocFirstName", "M", "AdhocLastName", "AdhocAddress", "Irvine", "CA", "92604", true, "700.00");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Check Ready for Extract checkbox and click on save button for the second record.
                Reports.TestStep = "Check Ready for Extract Checkbox an click on save button for the second record";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "Seller2FirstName M Seller2LastNa", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                if (!FastDriver._1099S.ActiveReadyForExtract.IsSelected())
                {
                    FastDriver._1099S.ActiveReadyForExtract.FAClick();
                }

                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Verify ready for extract checkbox checked
                Reports.TestStep = "Verify ready for extract checkbox checked.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "Seller2FirstName M Seller2LastNa", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver._1099S.ActiveReadyForExtract.IsSelected().ToString().Clean(), "Verify that ActiveReadyForExtract is checked.");
                #endregion

                #region Select the second record and deliver the 1099S document.
                Reports.TestStep = "Select the second record and deliver the 1099S document";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "Seller2FirstName M Seller2LastNa", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                FASTHelpers.KeyboardSendKeys("^l");
                #endregion

                #region Print the checks
                Reports.TestStep = "Print the checks";
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                Playback.Wait(5000);
                #endregion

                #region Login to Admin site and Restore the Owmning office 1099 date.
                this.Login("Login to Admin site", "ADM");
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>STEST>Offices>7878").WaitForScreenToLoad();
                //DateTime owningOfficeDate = DateTime.Parse(FastDriver.OfficeSetupOffice.ActivityDate1099s.FAGetValue());
                //DateTime settlementDate = owningOfficeDate.Subtract(2);
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText(originalOwningofficeDate);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.Quit();
                #endregion Login to Admin site and Restore the Owmning office 1099 date.

            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0013, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0014
        [TestMethod]
        public void FMUC0058_REG0014()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6963_ES6960: Validate the BRs", "", false, false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Navigate to 1099 screen
                this.NavigateTo1099S();
                #endregion

                #region Modify first record information
                Reports.TestStep = "Modify first record information.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, 1, TableAction.Click);
                this.ModifyDataOfSelectedAdhoc("123456789", "S1FNModified", "K", "S1LNModified", "Line1Line2Line3Line4Modified", "New York", "NY", "92707");
                #endregion

                #region Verify exit without save message and click on Ok button
                Reports.TestStep = "Verify exit without save message and click on Ok button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home");
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(false).Clean(), "Verify that the message is: Exit without saving changes?");
                Playback.Wait(1000);
                #endregion

                #region Verify Resets information in all records to last saved version. Continue? Message
                Reports.TestStep = "Verify Resets information in all records to last saved version. Continue? Message";
                Support.AreEqual("Resets information in all records to last saved version. Continue?", FastDriver.WebDriver.HandleDialogMessage(false).Clean(), "Verify that the message is: Resets information in all records to last saved version. Continue?");
                Playback.Wait(1000);
                #endregion

                #region Navigate to 1099S scren.
                this.NavigateTo1099S();
                #endregion

                #region Verify for first record information
                this.CheckActiveValuesOn1099SSummaryTable("Verify for first record information", "S1FN S1MN S1LN Sir", "987-65-4321", "S1FN", "S", "S1LN Sir", "Line1Line2Line3Line4", "Santa Ana", "CA", "92604");
                #endregion

                #region Modify first record information
                Reports.TestStep = "Modify first record information.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, 1, TableAction.Click);
                this.ModifyDataOfSelectedAdhoc("123456789", "S1FNModified", "K", "S1LN SirModified", "Line1Line2Line3Line4Modified", "New York", "NY", "92707");
                #endregion

                #region Verify exit without save message and click on Cancel button
                Reports.TestStep = "Verify exit without save message and click on Cancel button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home");
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(false, false).Clean(), "Verify that the message is: Exit without saving changes?");
                Playback.Wait(1000);
                #endregion

                #region Verify for first record information
                FastDriver._1099S.WaitForScreenToLoad();
                this.CheckActiveValuesOn1099SSummaryTable("Verify for first record information", "S1FN S S1LN Sir", "123-45-6789", "S1FNModified", "K", "S1LN SirModified", "Line1Line2Line3Line4Modified", "New York", "NY", "92707");
                #endregion

                #region Click on Reset button
                Reports.TestStep = "Click on Rest button.";
                FastDriver.BottomFrame.Reset();
                #endregion

                #region MyRegion
                this.ClickOkButton();
                #endregion

                #region Click on Save button
                Reports.TestStep = "Click on save button.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Navigate to the seller screen and select the first seller
                Reports.TestStep = "Navigate to the seller screen and select the first seller.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers");
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, 1, TableAction.Click);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0014 couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0015

        [TestMethod]
        public void FMUC0058_REG0015()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6960_1: Login to File side and validate error warning message Owning Office's 1099-S Activity Date is missing.", "", false, false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0015, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0016
        [TestMethod]
        public void FMUC0058_REG0016()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6960_2: Remove the 1099S Activity date", "ADM");
                #endregion

                #region Remove 1099-S Activity Date from Office 
                Reports.TestStep = "Remove 1099-S Activity Date from Office.";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("");
                FastDriver.BottomFrame.Done();
                Playback.Wait(1000);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0016, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0017
        [TestMethod]
        public void FMUC0058_REG0017()
        {
            try
            {   
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6960_3: Login to File side and validate error warning message Owning Office's 1099-S Activity Date is missing.", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false);
                #endregion

                #region Enter Settlement Date for 1099S.
                Reports.TestStep = "Enter Settlement Date for 1099S.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("08-21-2012");
                FastDriver.TermsDatesStatus.DaystoExpirationdate.FASetText("16");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to de seller screen select the set property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to the seller screen and add a Trust Estate Seller
                Reports.TestStep = "Navifate to the seller screen and add Trust Estate Seller.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers");
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Trust/Estate");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("TrustShortName");
                FastDriver.BuyerSellerSetup.TrustSSNtext.FASetText("147852963");
                FastDriver.BuyerSellerSetup.TrustLastNameFor1099SReporting.FASetText("TrustLastName");
                FastDriver.BuyerSellerSetup.TrustSSNtype.FASelectItemBySendingKeys("1099-S");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to 1099S screen
                this.NavigateTo1099S();
                #endregion

                #region Click on Save button
                Reports.TestStep = "Click on Save button.";
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify for Own Offce's 1099-S Activity Date is miss. and click on Ok Button
                //Reports.TestStep = "Verify for Own Offce's 1099-S Activity Date is miss. and click on Ok Button";
                //Support.AreEqual("Owning Office’s 1099 - S Activity Date is missing.", FastDriver.WebDriver.HandleDialogMessage().Clean(), "Veryfing that the message says: Owning Office’s 1099-S Activity Date is missing.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0017, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0018
        [TestMethod]
        public void FMUC0058_REG0018()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6960_2: Enter the 1099S Activity date", "ADM");
                #endregion

                #region Remove 1099-S Activity Date from Office 
                Reports.TestStep = "Enter 1099-S Activity Date from Office.";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("");
                FastDriver.BottomFrame.Done();
                Playback.Wait(1000);
                #endregion
            }
            catch (Exception ex)
            {

                FailTest("The test FMUC0058_REG0018, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0019
        [TestMethod]
        public void FMUC0058_REG0019()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6960_5: Verify for - Settlement Date is missing. message", "", false, false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter blank settlement date
                Reports.TestStep = "Navigate to TDS screen and Enter blank settlement date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to 1099S screen
                this.NavigateTo1099S();
                #endregion

                #region Modify first name forthe seller record
                FastDriver._1099S.ActiveFirstName.FASetText("S1FNModified");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify for Settlement Date is missing and Click on Ok Button
                Reports.TestStep = "Verify for Settlement Date is missing and Click on Ok Button";
                Support.AreEqual("Settlement Date is missing.", FastDriver.WebDriver.HandleDialogMessage(false).Clean(), "Settlement Date is missing.");
                #endregion

                #region Navigate to TDS screen and enter the settlement date as past date to de current system date
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion
            }
            catch (Exception ex)
            {

                FailTest("The test FMUC0058_REG0019, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0020
        [TestMethod]
        public void FMUC0058_REG0020()
        {
            try
            {
                #region Login & Create File
                this.Login("BR_ES6960_6: Verify for - Sale Price is missing. message");
                #endregion

                #region Click on skip button to go to QFE
                Reports.TestStep = "Click on skip button to go to QFE";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                #endregion

                #region Create Order with two sellers for 1099-S with Sale Price more than 250000
                Reports.TestStep = "Create Order.0";
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("HUDFLINSR1");
                
                if (!FastDriver.QuickFileEntry.Title.IsSelected())
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.IsSelected())
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sales w/Mortgage");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FASTHelpers.KeyboardSendKeys("^D");
                #endregion

                #region Navigate to the seller screen and add a Trust Estate seller.
                Reports.TestStep = "Navigate to the seller screen and add a Trust Estate seller.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Trust/Estate");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("TrustShortName");
                FastDriver.BuyerSellerSetup.TrustSSNtext.FASetText("147852963");
                FastDriver.BuyerSellerSetup.TrustLastNameFor1099SReporting.FASetText("TrustLastName");
                FastDriver.BuyerSellerSetup.TrustSSNtype.FASelectItemBySendingKeys("1099-S");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to TDS screen and enter de current date as settlement date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate("Navigate to TDS screen and enter de current date as settlement date.", "0");
                #endregion

                #region Navidate to 1099S screen
                this.NavigateTo1099S();
                #endregion

                #region Modify first name for the first seller record and remove gross proceeds
                Reports.TestStep = "Modify first name for the first seller record and remove gross proceeds.";
                FASTHelpers.KeyboardSendKeys("");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                FastDriver._1099S.ActiveShortName.FASetText("TrustLastName, TrustShortName - Modified");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify for Settlement Date is missing and Click on Ok Button
                Reports.TestStep = "verify for -Sale Price is miss. and click on OK button.";
                Support.AreEqual("Sale Price is missing. Zip code is missing.", FastDriver.WebDriver.HandleDialogMessage(false).Clean(), "Verifying that message says: Sales Price is missing.");
                #endregion
            }
            catch (Exception ex)
            {

                FailTest("The test FMUC0058_REG0020, couldn't be completed because: " + ex.Message);
            }
        }

        #endregion

        #region FMUC0058_REG0021
        [TestMethod]
        public void FMUC0058_REG0021()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6960_7: Verify for - Property Description is missing. message", "", false, false);
                #endregion

                #region Navigate to TDS screen and Enter the current date as settlement date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate("Navigate to TDS screen and Enter the current date as settlement date.", "0");
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to the seller screen and add Trust Estate Seller.
                this.NewTrustEstateSeller();
                #endregion

                #region Navigate to Home>Order Entry>Escrow Closing>1099-S
                Reports.TestStep = "Navigate to Home>Order Entry>Escrow Closing>1099-S";
                FastDriver._1099S.Open();
                #endregion

                #region Remove Property description for the first seller record
                FASTHelpers.KeyboardSendKeys("260000.00");
                FastDriver._1099S.PropertyDescription.FASetText("");
                FastDriver.BottomFrame.Save();
                #endregion

                #region verify for -Property Description is miss. and click on OK button.
                Reports.TestStep = "verify for - Property Description is miss. and click on OK button.";
                Support.AreEqual("Property Description is missing.", FastDriver.WebDriver.HandleDialogMessage(false).Clean(), "Verifying that message says: Property Description is missing.");
                #endregion

                //FMUC0058_REG0022
                this.VerifyEmptyFieldOn1099S(TestDescription: "Enter Property description for the first seller record and remove SSNTIN and save.", FieldAdded: "Property descriptio", FieldRemoved: "SSN/TIN", 
                                             PropertyName: _1099S._1099SActiveProperty.PropertyDescription, PropertyValue: "PropertyDesc", PropertyToBlankName: _1099S._1099SActiveProperty.SSNTINT, page: FastDriver._1099S);

                //FMUC0058_REG0023
                this.VerifyEmptyFieldOn1099S(TestDescription: "BR_ES6960_10: Verify for - Last Name is missing. messag", FieldAdded: "SSNTIN", FieldRemoved: "First Name", 
                                             PropertyName: _1099S._1099SActiveProperty.SSNTINT, PropertyValue: "1122334455", PropertyToBlankName: _1099S._1099SActiveProperty.ActiveFirstName, page: FastDriver._1099S);

                //FMUC0058_REG0024
                this.VerifyEmptyFieldOn1099S(TestDescription: "BR_ES6960_10: Verify for - Last Name is missing. messag", FieldAdded: "FirstName", FieldRemoved: "Last Name",
                                             PropertyName: _1099S._1099SActiveProperty.ActiveFirstName, PropertyValue: "FirstName", PropertyToBlankName: _1099S._1099SActiveProperty.ActiveLastName, page: FastDriver._1099S);

                //FMUC0058_REG0025
                this.VerifyEmptyFieldOn1099S(TestDescription: "BR_ES6960_11: Verify for - Address is missing. message", FieldAdded: "LastName", FieldRemoved: "Address",
                                             PropertyName: _1099S._1099SActiveProperty.ActiveLastName, PropertyValue: "LastName", PropertyToBlankName: _1099S._1099SActiveProperty.ActiveAddress, page: FastDriver._1099S);

                //FMUC0058_REG0026
                this.VerifyEmptyFieldOn1099S(TestDescription: "BR_ES6960_12: Verify for - City is missing. message", FieldAdded: "Address", FieldRemoved: "City",
                                             PropertyName: _1099S._1099SActiveProperty.ActiveAddress, PropertyValue: "1st American Way", PropertyToBlankName: _1099S._1099SActiveProperty.ActiveCity, page: FastDriver._1099S);

                //FMUC0058_REG0027
                this.VerifyEmptyFieldOn1099S(TestDescription: "BR_ES6960_13: Verify for - State is missing. message", FieldAdded: "City", FieldRemoved: "State",
                                            PropertyName: _1099S._1099SActiveProperty.ActiveCity, PropertyValue: "NewYork", PropertyToBlankName: _1099S._1099SActiveProperty.ActivecboState, page: FastDriver._1099S);

                //FMUC0058_REG0028
                this.VerifyEmptyFieldOn1099S(TestDescription: "BR_ES6960_14: Verify for - Zip code is missing. message", FieldAdded: "ActivecboState", FieldRemoved: "Zip code",
                                             PropertyName: _1099S._1099SActiveProperty.ActivecboState, PropertyValue: "NY", PropertyToBlankName: _1099S._1099SActiveProperty.ActiveZip, page: FastDriver._1099S);

                //FMUC0058_REG0029
                this.VerifyEmptyFieldOn1099S(TestDescription: "BR_ES6960_15: Verify for Foreign Address is missing. message", FieldAdded: "Foreign Country Seller", FieldRemoved: "Foreign Address",
                                             PropertyName: _1099S._1099SActiveProperty.ForeignCountrySeller, PropertyValue: "True", PropertyToBlankName: _1099S._1099SActiveProperty.ActiveForeignAddress, page: FastDriver._1099S);
                
                
            }
            catch (Exception ex)
            {

                FailTest("The test FMUC0058_REG0021, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0022
        //Merged with FMUC0058_REG0021
        [TestMethod]
        public void FMUC0058_REG0022()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0058_REG0021";
                Reports.TestStep = "See test case FMUC0058_REG0021.";
                Reports.StatusUpdate("See test case FMUC0058_REG0021.", true);
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0022, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0023
        //Merged with FMUC0058_REG0021
        [TestMethod]
        public void FMUC0058_REG0023()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0058_REG0021";
                Reports.TestStep = "See test case FMUC0058_REG0023.";
                Reports.StatusUpdate("See test case FMUC0058_REG0023.", true);
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0023, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0024
        //Merged with FMUC0058_REG0021
        [TestMethod]
        public void FMUC0058_REG0024()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0058_REG0021";
                Reports.TestStep = "See test case FMUC0058_REG0024.";
                Reports.StatusUpdate("See test case FMUC0058_REG0024.", true);
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0024, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0025
        //Merged with FMUC0058_REG0021
        [TestMethod]
        public void FMUC0058_REG0025()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0058_REG0021";
                Reports.TestStep = "See test case FMUC0058_REG0025.";
                Reports.StatusUpdate("See test case FMUC0058_REG0025.", true);
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0025, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0026
        //Merged with FMUC0058_REG0021
        [TestMethod]
        public void FMUC0058_REG0026()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0058_REG0021";
                Reports.TestStep = "See test case FMUC0058_REG0026.";
                Reports.StatusUpdate("See test case FMUC0058_REG0026.", true);
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0026, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0027
        //Merged with FMUC0058_REG0021
        [TestMethod]
        public void FMUC0058_REG0027()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0058_REG0021";
                Reports.TestStep = "See test case FMUC0058_REG0027.";
                Reports.StatusUpdate("See test case FMUC0058_REG0027.", true);
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0027, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0028
        //Merged with FMUC0058_REG0021
        [TestMethod]
        public void FMUC0058_REG0028()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0058_REG0021";
                Reports.TestStep = "See test case FMUC0058_REG0028.";
                Reports.StatusUpdate("See test case FMUC0058_REG0028.", true);
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0028, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0029
        [TestMethod]
        //Merged with FMUC0058_REG0021
        public void FMUC0058_REG0029()
        {
            try
            {
                Reports.TestDescription = "This test case has been combined with FMUC0058_REG0021";
                Reports.TestStep = "See test case FMUC0058_REG0029.";
                Reports.StatusUpdate("See test case FMUC0058_REG0029.", true);
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0029, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0030
        [TestMethod]
        public void FMUC0058_REG0030()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6960_16: Verify for Short Name is missing. message", "", false, false);
                #endregion

                #region Navigate to the seller screen and add a Trust Estate seller.
                this.NavigateToSellerAndAddTrustEstateSeller();;
                #endregion

                #region Navigate to the seller screen and add a Business Entity seller.
                this.NavigateToSellerAndAddBusinessEntitySeller();
                #endregion

                #region Navigate to 1099S screen
                this.NavigateTo1099S();
                #endregion

                #region Highlight Trust Estate Seller
                Reports.TestStep = "Highlight Trust Estate Seller";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "TrustShortName", 1, TableAction.Click);
                #endregion

                #region Click on Ok
                this.ClickOkButton();
                #endregion

                #region Remove Short name for Trust Estate Seller and click save
                Reports.TestStep = "Remove Short name for Trust Estate Seller and click save";
                FastDriver._1099S.WaitForScreenToLoad();
                FASTHelpers.KeyboardSendKeys("100.00");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                FastDriver._1099S.ActiveShortName.FASetText("");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify for -Short Name is missing and click on Ok Button
                this.VerifyMessageOnAlert(TestStep: "Verify for -Short Name is missing and click on Ok Button", CompareString: "Settlement Date is missing. Short Name is missing.", ReportString: "Short Name is missing.");
                #endregion

                #region Click the Ok Button
                this.ClickOkButton();
                #endregion

                #region Click on SellerOrAdhocName
                Reports.TestStep = "Click on SellerOrAdhocName";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "BusinessEntityShortName", 1, TableAction.Click);
                #endregion

                #region Click on Ok
                this.ClickOkButton();
                #endregion

                #region Remove Short name for Business Entity Seller and click save
                Reports.TestStep = "Remove Short name for Business Entity Seller and click save.";
                FastDriver._1099S.WaitForScreenToLoad();
                FASTHelpers.KeyboardSendKeys("200.00");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                FastDriver._1099S.ActiveShortName.FASetText("");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify for -Short Name is missing and click on Ok Button
                this.VerifyMessageOnAlert(TestStep: "Verify for -Short Name is missing and click on Ok Button", CompareString: "Settlement Date is missing. Short Name is missing.", ReportString: "Short Name is missing.");
                #endregion

                #region Click on Ok
                this.ClickOkButton();
                #endregion

                #region Click on Ok
                this.ClickOkButton();
                #endregion

                #region Click on Save Button
                Reports.TestStep = "Click on Save Button.";
                FastDriver.BottomFrame.Save();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0030, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0031
        [TestMethod]
        public void FMUC0058_REG0031()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6960_17: Verify for Sale Price is not fully distributed., Gross Proceeds is missing., Messages", "", false, false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Select Proration Tax1 and click on Edit button & Change the per Field to DAY
                this.ProrationTax1AndEditPerField();
                #endregion

                #region Navigate to 1099S screen
                this.NavigateTo1099S();
                #endregion

                #region Enter 200 gross proceeds for first seller
                Reports.TestStep = "Enter $200 gross proceed for first seller.";
                FASTHelpers.KeyboardSendKeys("200.00");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify for - Sale Price is not fully distributed and click on Ok button.
                this.VerifyMessageOnAlert(TestStep: "Verify for -Sale Price is not fully distributed and click on Ok Button", CompareString: "Sale Price is not fully distributed.", ReportString: "Sale Price is not fully distributed.");
                #endregion

                #region Press the Adhoc button
                Reports.TestStep = "Press the Adhoc button.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.AdHoc.FAClick();
                #endregion

                #region Click on Ok Button
                this.ClickOkButton();
                #endregion

                #region Add Adhoc record and enter correspond address SSN TIN details
                Reports.TestStep = "Add Adhoc record and enter correspond address SSN TIN details";
                this.ModifyDataOfSelectedAdhoc(SSNTIN: "1122334455", ActiveFirstName: "AdhocFirstName", ActiveMiddleName: "M", ActiveLastName: "AdhocLastName", ActiveAddress: "AdhocAddress", ActiveCity: "Irvine", ActivecboState: "CA", 
                                               ActiveZip: "92604", SetGross: true, GrossValue: "700.00", CheckSSNTINTType: true, SSNTINTType: "S=Social Security Number");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Remove gross proceeds dollar amount for Adhoc record.
                Reports.TestStep = "Remove gross proceeds dollar amount for Adhoc record.";
                FASTHelpers.KeyboardSendKeys(FAKeys.Space);
                #endregion

                #region HighlightfFirst Seller
                Reports.TestStep = "Hightlight first seller";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, 1, TableAction.Click);
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Remove gross proceeds dollar amount for first record.
                Reports.TestStep = "Remove gross proceeds dollar amount for first record.";
                FASTHelpers.KeyboardSendKeys(FAKeys.Space);
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok button
                this.ClickOkButton(WaitFor1099S: false);
                #endregion

                #region "Verify for -Gross Proceed and cannot be Zero and click on Ok Button
                this.VerifyMessageOnAlert(TestStep: "Verify for -Gross Proceed and cannot be Zero and click on Ok Button", 
                                                           CompareString: "Gross Proceeds cannot be Zero.", ReportString: "Gross Proceeds cannot be Zero.");
                #endregion

                #region Verify gross proceeds dollar amount for first record is zero.
                Reports.TestStep = "Verify gross proceeds dollar amount for first record is zero.";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("0.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S1FN S S1LN Sir", 5, TableAction.GetInputValue).Message.Clean(), "Verifying that Gross Proceed in first row is: 0.00");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("The test FMUCM0058_REG0031, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0032
        [TestMethod]
        public void FMUC0058_REG0032()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6960_18: Verify for Settlement Date is earlier than Owning Office's 1099-S Activity Date. Message", "", false, false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Enter settlement date less than 1099S activity date
                Reports.TestStep = "Entersettlement date less than 1099S activity date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("08-21-2000");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                #endregion

                #region Navigate to 1099S
                this.NavigateTo1099S();
                #endregion

                #region Modify LastName and click safe for first record
                Reports.TestStep = "Modify LastName and click safe for first record.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, 1, TableAction.Click);
                FASTHelpers.KeyboardSendKeys("249301.00");
                FastDriver._1099S.ActiveLastName.FASetText("ModifiedName");
                FastDriver.BottomFrame.Save();
                #endregion

                #region verify for -Settlement Date is earlier than Own Office’s 1099-S Activity Date. and click on OK button.
                this.VerifyMessageOnAlert(TestStep: "verify for -Settlement Date is earlier than Own Office’s 1099-S Activity Date. and click on OK button.", 
                                                           CompareString: "Settlement Date is earlier than Owning Office’s 1099-S Activity Date. Sale Price is not fully distributed.", 
                                                           ReportString: "Settlement Date is earlier than Own Office’s 1099-S Activity Date.");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0032, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0033
        [TestMethod]
        public void FMUC0058_REG0033()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6525_ES6960: Validate BRs related to Buyer RE tax", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false, SalesPriceValue: 250001);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date
                this.NavigateToTDSAndSetSettlementDateAsPastDate(HandleDialogMessage: false);
                #endregion

                #region Select Proration Tax1 and click on Edit button & Change the per Field to DAY
                this.ProrationTax1AndEditPerField();
                #endregion

                #region Navigate to 1099S screen
                this.NavigateTo1099S();
                #endregion

                #region Modify Buyers Re tax and click save for first record
                FASTHelpers.KeyboardSendKeys("{TAB}{TAB}100.00");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify for -Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax. and click on OK button.
                this.VerifyMessageOnAlert(TestStep: "Verify for -Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax. and click on OK button." , 
                                                           CompareString: "Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax.", 
                                                           ReportString: "Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax.");
                #endregion

                #region Verify for -Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax. and click on OK button.
                this.VerifyMessageOnAlert(TestStep: "Verify for -Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax. and click on OK button.",
                                                           CompareString: "Buyer's Part of R.E. Tax $ does not equal file's total Buyer's Part of R.E. Tax $.",
                                                           ReportString: "Buyer's Part of R.E. Tax $ does not equal file's total Buyer's Part of R.E. Tax $.", HandleDialog: false, WaitTime: true);
                #endregion

                #region Navigate to 1099S screen
                this.NavigateTo1099S(ClickOnMessage: true);
                #endregion

                #region Verify Buyer RE tax.
                Reports.TestStep = "Verify gross proceeds dollar amount for first record is zero.";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("0.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S1FN S1MN S1LN Sir", 7, TableAction.GetInputValue).Message.Clean(), "Verifying that Gross Proceed in first row is: 100.00");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0033, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0034
        [TestMethod]
        public void FMUC0058_REG0034()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6964: Validate BRs related to Buyer RE tax", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false, SalesPriceValue: 250001);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date
                this.NavigateToTDSAndSetSettlementDateAsPastDate(HandleDialogMessage: false);
                #endregion

                #region Navigate to 1099S screen
                this.NavigateTo1099S();
                #endregion

                #region Add Adhoc record and enter correspond address SSN TIN details
                Reports.TestStep = "Add Adhoc record and enter correspond address SSN TIN details.";
                FastDriver._1099S.AdHoc.FAClick();
                FastDriver._1099S.WaitForScreenToLoad();
                FASTHelpers.KeyboardSendKeys("700.00{TAB}{TAB}300.00");
                this.ModifyDataOfSelectedAdhoc(SSNTIN: "1122334455", ActiveFirstName: "AdhocFirstName", ActiveMiddleName: "M", ActiveLastName: "AdhocLastName", ActiveAddress: "AdhocAddress",
                                               ActiveCity: "Irvine", ActivecboState: "CA", ActiveZip: "92604", CheckSSNTINTType: true, SSNTINTType: "S=Social Security Number");
                FastDriver.BottomFrame.Save();
                #endregion

                
                #region Verify for -Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax. and click on OK button.
                this.VerifyMessageOnAlert(TestStep: "Verify for -Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax. and click on OK button.",
                                                           CompareString: "Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax.",
                                                           ReportString: "Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax.");
                #endregion

                #region Verify for - Total of Gross Proceeds for all records exceeds Sale Price amd click on Ok button
                this.VerifyMessageOnAlert(TestStep: "Verify for - Total of Gross Proceeds for all records exceeds Sale Price. and click on OK button.",
                                                           CompareString: "Total of Gross Proceeds for all records exceeds Sale Price.",
                                                           ReportString: "Total of Gross Proceeds for all records exceeds Sale Price.");
                #endregion

                #region Verify for -Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax. and click on OK button.
                this.VerifyMessageOnAlert(TestStep: "Verify for -Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax. and click on OK button.",
                                                           CompareString: "Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax.",
                                                           ReportString: "Buyer's Part of R.E. Tax exceeds file's total Buyer's Part of R.E. Tax.");
                #endregion

                #region Verify Adhoc record and correspond address SSN TIN details.
                FastDriver._1099S.WaitForScreenToLoad();
                Reports.TestStep = "Verify Adhoc record and correspond address SSN TIN details.";
                Support.AreEqual("700.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(4, 5, TableAction.GetInputValue).Message.Clean(), "Verifying that GrossProceedDollor is: 700.00");
                Support.AreEqual("300.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(4, 7, TableAction.GetInputValue).Message.Clean(), "Verifying that GrossProceedDollor is: 300.00");
                Support.AreEqual("112-23-3445", FastDriver._1099S.SSNTIN.FAGetValue().Clean(), "Verifying that SSNTIN is: 112-23-3445.");
                Support.AreEqual("AdhocFirstName", FastDriver._1099S.ActiveFirstName.FAGetValue().Clean(), "Verifying that ActiveFirstName is: AdhocFirstName.");
                Support.AreEqual("M", FastDriver._1099S.ActiveMiddleName.FAGetValue().Clean(), "Verifying that ActiveMiddleName is: M.");
                Support.AreEqual("AdhocLastName", FastDriver._1099S.ActiveLastName.FAGetValue().Clean(), "Verifying that ActiveLastName is: AdhocLastName.");
                Support.AreEqual("AdhocAddress", FastDriver._1099S.ActiveAddress.FAGetValue().Clean(), "Verifying that ActiveAddress is: AdhocAddress.");
                Support.AreEqual("Irvine", FastDriver._1099S.ActiveCity.FAGetValue().Clean(), "Verifying that ActiveCity is: Irvine.");
                Support.AreEqual("CA", FastDriver._1099S.ActivecboState.FAGetSelectedItem().ToString().Clean(), "Verifying that ActivecboState is: CA.");
                Support.AreEqual("92604", FastDriver._1099S.ActiveZip.FAGetValue().Clean(), "Verifying that ActiveZip is: 92604");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0034, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0035
        [TestMethod]
        public void FMUC0058_REG0035()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6538_ES6539_ES6540_ES6541: Validate the BRs", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false);
                #endregion

                #region Navigate to the seller screen and add a Trust Estate seller
                this.NavigateToSellerAndAddTrustEstateSeller();
                #endregion

                #region Navigate to the seller screen and add a Business Entity seller
                this.NavigateToSellerAndAddBusinessEntitySeller();
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress(seller: "first", row: 2);
                #endregion

                #region Navigate to the seller screen select the set to property radio buttonfor forward address for second seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress(seller: "second", row: 3);
                #endregion

                #region Navigate to TDS screen Enter the settlement date as past date to current system date
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Navigate to Home/Orden Entry/Escrow Closing/1099-S
                this.NavigateTo1099S();
                #endregion

                #region Verify the data populated for first record - Individual seller
                this.CheckActiveValuesOn1099SSummaryTable(TestStep: "Verify the data populated for first record - Individual seller.", RowName: "S1FN S1MN S1LN Sir", SSNTIN: "987-65-4321", ActiveFirstName: "S1FN", ActiveMiddleName: "S",
                                                          ActiveLastName: "S1LN Sir", ActiveAddress: "Line1Line2Line3Line4", ActiveCity: "Santa Ana", ActivecboState: "CA", ActiveZip: "92604", CheckGross: true, GrossValue: "260,000.00",
                                                          CheckPayeeIndicator: true, PayeeIndicator: "I=Individual", CheckSSNTINType: true, SSNTINType: "S=Social Security Number", CheckForeignCountrySeller: true, ForeignCountrySeller: "False",
                                                          CheckActiveForeignAddress: true, ActiveForeignAddress: "False");
                #endregion

                #region Highlight Second seller record - husband and wife seller and verify
                this.CheckActiveValuesOn1099SSummaryTable(TestStep: "Highlight Second seller record - husband and wife seller and verify.", RowName: "S2FN S2MN S2LN Dr", SSNTIN: "112-23-3445", ActiveFirstName: "S2FN", ActiveMiddleName: "S",
                                                          ActiveLastName: "S2LN Dr", ActiveAddress: "Line1Line2Line3Line4", ActiveCity: "Santa Ana", ActivecboState: "CA", ActiveZip: "92604", CheckGross: false, GrossValue: "500.00",
                                                          CheckPayeeIndicator: true, PayeeIndicator: "I=Husband/Wife", CheckSSNTINType: true, SSNTINType: "S=Social Security Number", SetGross: true);
                #endregion

                #region Highlight Third seller record - husband and wife seller and verify.
                this.CheckActiveValuesOn1099SSummaryTable(TestStep: "Highlight Third seller record - husband and wife seller and verify.", RowName: "S2SFN S2SMN S2SLN Sir", SSNTIN: "554-43-3221", ActiveFirstName: "S2SFN", ActiveMiddleName: "S",
                                                          ActiveLastName: "S2SLN Sir", ActiveAddress: "Line1Line2Line3Line4", ActiveCity: "Santa Ana", ActivecboState: "CA", ActiveZip: "92604", CheckGross: false, GrossValue: "400.00",
                                                          CheckPayeeIndicator: true, PayeeIndicator: "I=Husband/Wife", CheckSSNTINType: true, SSNTINType: "S=Social Security Number", SetGross: true);
                #endregion

                #region Highlight fourth seller record - Trust Estate and verify
                this.CheckActiveValuesOn1099SSummaryTable(TestStep: "Highlight fourth seller record - Trust Estate and verify.", RowName: "TrustShortName", SSNTIN: "147-85-2963", ActiveFirstName: "", ActiveMiddleName: "",
                                                          ActiveLastName: "", ActiveAddress: "Line1Line2Line3Line4", ActiveCity: "Santa Ana", ActivecboState: "CA", ActiveZip: "92604", CheckGross: false, GrossValue: "300.00",
                                                          CheckPayeeIndicator: true, PayeeIndicator: "C=Trust/Estate", CheckSSNTINType: true, SSNTINType: "S=Social Security Number", SetGross: true, CheckActiveShortName: true,
                                                          ActiveShortName: "TrustLastName, TrustShortName");
                #endregion

                #region Highlight fifth seller record - Business Entity and verify
                this.CheckActiveValuesOn1099SSummaryTable(TestStep: "Highlight fifth seller record - Business Entity and verify", RowName: "BusinessEntityShortName", SSNTIN: "58-2693471", ActiveFirstName: "", ActiveMiddleName: "",
                                                          ActiveLastName: "", ActiveAddress: "Line1Line2Line3Line4", ActiveCity: "Santa Ana", ActivecboState: "CA", ActiveZip: "92604", CheckGross: false, GrossValue: "200.00",
                                                          CheckPayeeIndicator: true, PayeeIndicator: "C=Business Entity", CheckSSNTINType: true, SSNTINType: "T=Tax ID Number", SetGross: true, CheckActiveShortName: true,
                                                          ActiveShortName: "BusinessEntityShortName");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok Button
                this.ClickOkButton(WaitFor1099S: true);
                #endregion

                #region  Highlight first record - Individual seller and update the data
                Reports.TestStep = "Highlight first record - Individual seller and update the data.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S1FN S S1LN Sir", 1, TableAction.Click);
                this.ModifyDataOfSelectedAdhoc(SSNTIN: "1122334455", ActiveFirstName: "S1FNM", ActiveMiddleName: "M", ActiveLastName: "S1LN SirM",
                                               ActiveAddress: "Line1Line2Line3Line4Modified", ActiveCity: "New York", ActivecboState: "NY", ActiveZip: "92707");
                Support.AreEqual("260,000.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S1FN S S1LN Sir", 5, TableAction.GetText).Message.Clean(), "Verifying that GrossProceedDollor is: 260,000.00");
                #endregion

                #region Highlight Second seller record - husband and wife seller and update the data
                Reports.TestStep = "Highlight Second seller record - husband and wife seller and update the data.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S2FN S S2LN Dr", 1, TableAction.Click);
                this.ModifyDataOfSelectedAdhoc(SSNTIN: "5544332211", ActiveFirstName: "S2FNM", ActiveMiddleName: "K", ActiveLastName: "S2LN DrM",
                                               ActiveAddress: "Line1Line2Line3Line4Modified", ActiveCity: "New York", ActivecboState: "NY", ActiveZip: "92707");
                Support.AreEqual("500.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S2FN S S2LN Dr", 5, TableAction.GetText).Message.Clean(), "Verifying that GrossProceedDollor is: 500.00");
                #endregion

                #region Highlight Third seller record - husband and wife seller and update the data
                Reports.TestStep = "Highlight Third seller record - husband and wife seller and update the data.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S2SFN S S2SLN Sir", 1, TableAction.Click);
                this.ModifyDataOfSelectedAdhoc(SSNTIN: "147852963", ActiveFirstName: "S2SFNM", ActiveMiddleName: "P", ActiveLastName: "S2SLN SirM",
                                               ActiveAddress: "Line1Line2Line3Line4Modified", ActiveCity: "New York", ActivecboState: "NY", ActiveZip: "92707");
                Support.AreEqual("400.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S2SFN S S2SLN Sir", 5, TableAction.GetText).Message.Clean(), "Verifying that GrossProceedDollor is: 400.00");
                #endregion

                #region Highlight fourth seller record - Trust Estate and update the data.
                Reports.TestStep = "Highlight fourth seller record - Trust Estate and update the data.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "TrustLastName, TrustShortName", 1, TableAction.Click);
                this.ModifyDataOfSelectedAdhoc(SSNTIN: "896523147", CheckActiveShortName: true, ActiveShortName: "TrustLastName, TrustShortNameM",
                                               ActiveAddress: "Line1Line2Line3Line4Modified", ActiveCity: "New York", ActivecboState: "NY", ActiveZip: "92707");
                Support.AreEqual("300.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "TrustLastName, TrustShortName", 5, TableAction.GetText).Message.Clean(), "Verifying that GrossProceedDollor is: 300.00");
                #endregion

                #region Highlight fifth seller record - Business Entity and update the data
                Reports.TestStep = "Highlight fifth seller record - Business Entity and update the data.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "BusinessEntityShortName", 1, TableAction.Click);
                this.ModifyDataOfSelectedAdhoc(SSNTIN: "456789152", CheckActiveShortName: true, ActiveShortName: "BusinessEntityShortNameM",
                                               ActiveAddress: "Line1Line2Line3Line4Modified", ActiveCity: "New York", ActivecboState: "NY", ActiveZip: "92707");
                Support.AreEqual("200.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "BusinessEntityShortName", 5, TableAction.GetText).Message.Clean(), "Verifying that GrossProceedDollor is: 200.00");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok Button
                this.ClickOkButton(WaitFor1099S: true);
                #endregion

                #region Navigate to 1099S
                this.NavigateTo1099S(true);
                #endregion

                #region Highlight first record - Individual seller and verify.
                this.CheckActiveValuesOn1099SSummaryTable(TestStep: "Highlight first record - Individual seller and verify.", RowName: "S1FNM M S1LN SirM", SSNTIN: "112-23-3445", ActiveFirstName: "S1FNM", ActiveMiddleName: "M",
                                                          ActiveLastName: "S1LN SirM", ActiveAddress: "Line1Line2Line3Line4Modified", ActiveCity: "New York", ActivecboState: "NY", ActiveZip: "92707", CheckGross: true, GrossValue: "260,000.00");
                #endregion

                #region Highlight Second seller record - husband and wife seller and verify
                this.CheckActiveValuesOn1099SSummaryTable(TestStep: "Highlight Second seller record - husband and wife seller and verify", RowName: "S2FNM K S2LN DrM", SSNTIN: "554-43-3221", ActiveFirstName: "S2FNM", ActiveMiddleName: "K",
                                                          ActiveLastName: "S2LN DrM", ActiveAddress: "Line1Line2Line3Line4Modified", ActiveCity: "New York", ActivecboState: "NY", ActiveZip: "92707", CheckGross: true, GrossValue: "500.00");
                #endregion

                #region Highlight Third seller record - husband and wife seller and verify
                this.CheckActiveValuesOn1099SSummaryTable(TestStep: "Highlight Third seller record - husband and wife seller and verify", RowName: "S2SFNM P S2SLN SirM", SSNTIN: "147-85-2963", ActiveFirstName: "S2SFNM", ActiveMiddleName: "P",
                                                          ActiveLastName: "S2SLN SirM", ActiveAddress: "Line1Line2Line3Line4Modified", ActiveCity: "New York", ActivecboState: "NY", ActiveZip: "92707", CheckGross: true, GrossValue: "400.00");
                #endregion

                #region Highlight fourth seller record - Trust Estate and verify.
                this.CheckActiveValuesOn1099SSummaryTable(TestStep: "Highlight fourth seller record - Trust Estate and verify.", RowName: "TrustLastName, TrustShortNameM", SSNTIN: "896-52-3147", ActiveShortName: "TrustLastName, TrustShortNameM",
                                                          ActiveAddress: "Line1Line2Line3Line4Modified", ActiveCity: "New York", ActivecboState: "NY", ActiveZip: "92707", CheckGross: true, GrossValue: "300.00", CheckActiveShortName: true);
                #endregion

                #region Highlight fifth seller record - Business Entity and verify.
                this.CheckActiveValuesOn1099SSummaryTable(TestStep: "Highlight fifth seller record - Business Entity and verify.", RowName: "BusinessEntityShortNameM", SSNTIN: "45-6789152", ActiveShortName: "BusinessEntityShortNameM",
                                                          ActiveAddress: "Line1Line2Line3Line4Modified", ActiveCity: "New York", ActivecboState: "NY", ActiveZip: "92707", CheckGross: true, GrossValue: "200.00", CheckActiveShortName: true);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0035, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0036
        [TestMethod]
        public void FMUC0058_REG0036()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6542_1: Validate the BRs", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress(seller: "first", row: 2);
                #endregion

                #region Navigate to TDS screen Enter the settlement date as past date to current system date
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Navigate to Home/Orden Entry/Escrow Closing/1099-S
                this.NavigateTo1099S();
                #endregion

                #region  Highlight first record - Individual seller and update the data
                Reports.TestStep = "Extra Step: Setting Enviroment.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S1FN S1MN S1LN Sir", 1, TableAction.Click);
                this.ModifyDataOfSelectedAdhoc(SSNTIN: "1122334455", ActiveFirstName: "S1FNM", ActiveMiddleName: "M", ActiveLastName: "S1LN SirM",
                                               ActiveAddress: "Line1Line2Line3Line4Modified", ActiveCity: "New York", ActivecboState: "NY", ActiveZip: "92707");
                FastDriver.BottomFrame.Save();
                FastDriver._1099S.WaitForScreenToLoad();
                #endregion

                #region Check Foreign country seller and verify other fields.
                Reports.TestStep = "Check Foreign country seller and verify other fields.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S1FNM M S1LN SirM", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("260,000.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "S1FNM M S1LN SirM", 5, TableAction.GetText).Message.Clean(), "Verifying that Gross Proceed is: 260,000.00");
                FastDriver._1099S.ForeignCountrySeller.FAClick();
                Support.AreEqual("False", FastDriver._1099S.ActiveAddress.IsEnabled().ToString().Clean() , "Verifying that ActiveAddress is: False");
                Support.AreEqual("False", FastDriver._1099S.ActiveCity.IsEnabled().ToString().Clean(), "Verifying that ActiveCity is: False");
                Support.AreEqual("False", FastDriver._1099S.ActivecboState.IsEnabled().ToString().Clean(), "Verifying that ActivecboState is: False");
                Support.AreEqual("False", FastDriver._1099S.ActiveZip.IsEnabled().ToString().Clean(), "Verifying that ActiveZip is: False");
                Support.AreEqual("Line1Line2Line3Line4Modified New York NY 92707", FastDriver._1099S.ActiveForeignAddress.FAGetValue().ToString().Clean(), "Verifying that ActiveForeignAddress is: Line1Line2Line3Line4Modified New York NY 92707");
                #endregion

                #region Update Foreign Address
                Reports.TestStep = "Update Foreign Address.";
                FastDriver._1099S.ActiveForeignAddress.FASetText("Line1Line2Line3Line4Modified New York NY 92707Modified");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click the Ok Button
                this.ClickOkButton();
                #endregion

                #region Verify the updated Foreign Address.
                Reports.TestStep = "Verify the Updated Foreign Address";
                Support.AreEqual("Line1Line2Line3Line4Modified New York NY 92707Modified", 
                                 FastDriver._1099S.ActiveForeignAddress.FAGetValue().ToString().Clean() , 
                                 "Verifying that Active Foreign Addres is: Line1Line2Line3Line4Modified New York NY 92707Modified");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0036, couldn't be completed because: " + ex.Message);
            }
        }

        #endregion

        #region FMUC0058_REG0037
        [TestMethod]
        public void FMUC0058_REG0037()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6542_2: Validate the BRs", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress(seller: "first", row: 2);
                #endregion

                #region Navigate to TDS screen Enter the settlement date as past date to current system date
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Navigate to Home/Orden Entry/Escrow Closing/1099-S
                this.NavigateTo1099S();
                #endregion

                #region Add Adhoc record and enter correspond address SSN TIN details and verify foreign country seller info
                Reports.TestStep = "Add Adhoc record and enter correspond address SSN TIN details and verify foreign country seller info.";
                FastDriver._1099S.AdHoc.FAClick();
                this.ModifyDataOfSelectedAdhoc(SSNTIN: "1122334455", ActiveFirstName: "AdhocFirstName" , ActiveMiddleName: "M" , ActiveLastName: " AdhocLastName", ActiveAddress: "AdhocAddress", ActiveCity: "Irvine",
                                               ActivecboState: "CA", ActiveZip: "92604", SetGross: true, GrossValue: "700.00");
                Support.AreEqual("False", FastDriver._1099S.ActiveForeignAddress.IsEnabled().ToString().Clean(), "Verifying that ActiveForeignAddress is: False.");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok Button
                this.ClickOkButton();
                #endregion

                #region Verify data by check Foreign country seller check box
                Reports.TestStep = "Verify data by check Foreign country seller check box.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(4, 1, TableAction.Click);
                Support.AreEqual("700.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocFirstName M AdhocLastName", 5, TableAction.GetText).Message.Clean(), "Verifying that SSNTIN is: 700.00");
                Support.AreEqual("112-23-3445", FastDriver._1099S.SSNTIN.FAGetValue().ToString().Clean(), "Verifying that SSNTIN is: 112-23-3445");
                FastDriver._1099S.ForeignCountrySeller.FAClick();
                Support.AreEqual("False", FastDriver._1099S.ActiveAddress.IsEnabled().ToString().Clean(), "Verifying that ActiveAddress is: False");
                Support.AreEqual("False", FastDriver._1099S.ActiveCity.IsEnabled().ToString().Clean(), "Verifying that ActiveCity is: False");
                Support.AreEqual("False", FastDriver._1099S.ActivecboState.IsEnabled().ToString().Clean(), "Verifying that ActivecboState is: False");
                Support.AreEqual("False", FastDriver._1099S.ActiveZip.IsEnabled().ToString().Clean(), "Verifying that ActiveZip is: False");
                Support.AreEqual("AdhocAddress Irvine CA 92604", FastDriver._1099S.ActiveForeignAddress.FAGetValue().ToString().Clean(), "Verifying that ActiveForeignAddress is: AdhocAddress Irvine CA 92604");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Verify data in Foreign address and update it
                Reports.TestStep = "Verify data in Foreign address and update it.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocFirstName M AdhocLastName", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.ActiveForeignAddress.FASetText("AdhocAddress irvine CA 92604Modified");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Verify data in Foreign Address Field
                Reports.TestStep = "Verify data in Foreign Address Field.";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocFirstName M AdhocLastName", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("AdhocAddress irvine CA 92604Modified", FastDriver._1099S.ActiveForeignAddress.FAGetValue().ToString().Clean(), "Verifying that ActiveForeignAddress is: AdhocAddress irvine CA 92604Modified");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0037, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0038
        [TestMethod]
        public void FMUC0058_REG0038()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6521_ES6974_1: Validate Gross Proceeds related error warning messages for multiple records", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for seconds seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("second", 3);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion


            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0038, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0047
        [TestMethod]
        public void FMUC0058_REG0047()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6521_1_ES6974_1: Validate for single 1099s and Property service check box is unchecked and then checked", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Verify the data populated for first record-Individual seller
                Reports.TestStep = "Verify the data populated for first record - Individual seller.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("260,000.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, 5, TableAction.GetText).Message.Clean(), "Verifying that GrossProceedDollor is: 260,000.00");
                #endregion

                #region Verify for Property or services received as part of consideration check box unchecked
                Reports.TestStep = "Verify for Property or services received as part of consideration check box unchecked.";
                Support.AreEqual("False", FastDriver._1099S.PropertyConsideration.IsSelected().ToString().Clean(), "Verifying that Property Consideration is: False");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Increase Gross Proceed Dollar amount for first record
                Reports.TestStep = "Increase Gross Procees Dollar amount for first record.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FASTHelpers.KeyboardSendKeys("265000{TAB}");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate a Message and click on Cancel
                Reports.TestStep = "Validate a Message and click on Cancel.";
                Support.AreEqual("Gross proceeds exceeds Sale Price.", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean(), "Verifying that the message is: Gross proceeds exceeds Sale Price.");
                #endregion

                #region Click on Reset on the Botton framework
                Reports.TestStep = "Click on Reset on the Bottom Framework.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Verify for - Resets information in all records to last saved version. Continue?
                this.VerifyMessageOnAlert(TestStep: "Verify for - Resets information in all records to last saved version. Continue?", CompareString: "Resets information in all records to last saved version. Continue?",
                                          ReportString: "Resets information in all records to last saved version. Continue?.", WaitTime: false, HandleDialog: true);
                #endregion

                #region Check Property or services received check box and save the record
                Reports.TestStep = "Check Property or services received check box and save the record.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.PropertyConsideration.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify the data populated for first record - Individual seller
                Reports.TestStep = "Verify the data populated for first record - Individual seller.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("260,000.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, 5, TableAction.GetText).Message.Clean(), "Verifying that GrossProceedDollor is: 260,000.00");
                #endregion

                #region Increase gross proceed dollar amount for first record
                Reports.TestStep = "Increase gross proceed dollar amount for first record.";
                FastDriver._1099S.GrossProceedDollor.FASetText("265000");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate a Message and click on Cancel
                Reports.TestStep = "Validate a Message and click on Cancel.";
                Support.AreEqual("Gross proceeds exceeds Sale Price.", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean(), "Verifying that the message is: Gross proceeds exceeds Sale Price.");
                #endregion

                #region Click on Reset on the Botton framework
                Reports.TestStep = "Click on Reset on the Bottom Framework.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Verify for - Resets information in all records to last saved version. Continue?
                this.VerifyMessageOnAlert(TestStep: "Verify for - Resets information in all records to last saved version. Continue?", CompareString: "Resets information in all records to last saved version. Continue?",
                                          ReportString: "Resets information in all records to last saved version. Continue?.", WaitTime: true, HandleDialog: true);
                #endregion

                #region Click on Save button on the bottom framework
                Reports.TestStep = "Click on Save button on the bottom framework.";
                FastDriver.BottomFrame.Save();
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("260,000.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, 5, TableAction.GetText).Message.Clean(), "Verifying that GrossProceedDollor is: 260,000.00");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0047, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0048
        [TestMethod]
        public void FMUC0058_REG0048()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6521_2_ES6974_2: Validate for multiple 1099s and Property service check box is unchecked and then checked", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Verify the data populated for first record - Individual Seller.
                Reports.TestStep = "Verif the data populated for first record - Individual Seller.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("260,000.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, 5, TableAction.GetText).Message.Clean(), "Verifying that Gross Proceed is: 260,000.00");
                #endregion

                #region Verify for Property or services received as part of consideration checkbox unchecked
                Reports.TestStep = "Verify for Property or services received as part of consideration checkbox unchecked.";
                Support.AreEqual("False", FastDriver._1099S.PropertyConsideration.IsSelected().ToString().Clean(), "Verifying that Property Consideration is: False");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Increase Gross Proceeds dollar amount for first record
                Reports.TestStep = "Increase Gross Proceed dollar amount for first record.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FASTHelpers.KeyboardSendKeys("265000{TAB}");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate a message and click on Cancel
                Reports.TestStep = "Validate a message and click on Cancel";
                Support.AreEqual("Gross proceeds exceeds Sale Price.", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean(), "Verifying that the message is: Gross proceeds exceeds Sale Price.");
                #endregion

                #region Click on Reset
                Reports.TestStep = "Click on Reset.";
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Click on Ok Button
                Reports.TestStep = "Click on Ok Button";
                Support.AreEqual("Resets information in all records to last saved version. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean(), "Verifying that the message is: Resets information in all records to last saved version. Continue?.");
                #endregion

                #region Check Property or services received check box and save the record
                Reports.TestStep = "Check Property or services received check box and save the record.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.PropertyConsideration.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify the data populated for first record - Individual Seller
                Reports.TestStep = "Verify the data populated for first record - Individual seller.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("260,000.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, 5, TableAction.GetText).Message.Clean(), "Verifying that Gross Proceed is: 260,000.00");
                #endregion

                #region Increase gross proceed dollar amount for first record
                Reports.TestStep = "Increase gross proceed dollar amount for first record.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FASTHelpers.KeyboardSendKeys("265000{TAB}");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate a Message and click on Cancel
                Reports.TestStep = "Validate a Message and click on Cancel.";
                Support.AreEqual("Gross proceeds exceeds Sale Price.", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean(), "Verifying that the message is: Gross proceeds exceeds Sale Price.");
                #endregion

                #region Click on Reset
                Reports.TestStep = "Click on Reset.";
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Click on Ok Button
                Reports.TestStep = "Click on Ok Button";
                Support.AreEqual("Resets information in all records to last saved version. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean(), "Verifying that the message is: Resets information in all records to last saved version. Continue?.");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0048, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0049
        [TestMethod]
        public void FMUC0058_REG0049()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6521_ES6974_2: Validate Gross Proceeds related error warning messages for multiple records", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false, SalesPriceValue: 250001);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0049, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0051
        [TestMethod]
        public void FMUC0058_REG0051()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "TT_1:", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false, SalesPriceValue: 250001);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Navigate to Home/Orden Entry/Escrow Closing/1099-S
                this.NavigateTo1099S();
                #endregion

                #region Add Adhoc record and enter correspond info
                Reports.TestStep = "Add Adhoc record and enter correspond info.";
                FASTHelpers.KeyboardSendKeys("%A");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("Create Ad Hoc 1099-S recipient", FastDriver._1099S.AdHoc.GetAttribute("title").Clean(), "Verifying that the HelpText: Create Ad Hoc 1099-S recipient");
                this.ModifyDataOfSelectedAdhoc(SSNTIN: "1122334455", ActiveFirstName: "AdhocFirstName", ActiveMiddleName: "AdhocMiddleName", ActiveLastName: " AdhocLastName", ActiveAddress: "AdhocAddress", ActiveCity: "Irvine",
                                               ActivecboState: "CA", ActiveZip: "92604", SetGross: true, GrossValue: "200.00", CheckSSNTINTType: true, SSNTINTType: "S=Social Security Number");
                Support.AreEqual("False", FastDriver._1099S.ActiveForeignAddress.IsEnabled().ToString().Clean(), "Verifying that ActiveForeignAddress is: False.");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok Button
                Reports.TestStep = "Click on Ok Button";
                Support.AreEqual("Total of Gross Proceeds for all records exceeds Sale Price.", FastDriver.WebDriver.HandleDialogMessage().Clean(), "Verifying that the message is: Total of Gross Proceeds for all records exceeds Sale Price.");
                #endregion

                #region Verify Adhoc entry and enter correspond info and few tooltips.
                Reports.TestStep = "Verify Adhoc entry and enter correspond info and few tooltips.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocFirstName A AdhocLastName", 5, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("Void 1099-S to IRS", FastDriver._1099S.Void.GetAttribute("title").Clean(), "Verifying that Void HelpText is: Void 1099-S to IRS");
                Support.AreEqual("Delete Ad Hoc 1099-S", FastDriver._1099S.Remove.GetAttribute("title").Clean(), "Verifying that Remove HelpText is: Delete Ad Hoc 1099-S");
                Support.AreEqual("200.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocFirstName A AdhocLastName", 5, TableAction.GetInputValue).Message.Clean(), "Verifying that Gross Proceed is: 200.00");
                Support.AreEqual("S=Social Security Number", FastDriver._1099S.SSNTINType.FAGetSelectedItem().Clean(), "Verifying that - is: S=Social Security Number");
                Support.AreEqual("112-23-3445", FastDriver._1099S.SSNTIN.FAGetValue().Clean(), "Verifying that SSNTINT is: 112-23-3445");
                Support.AreEqual("AdhocFirstName", FastDriver._1099S.ActiveFirstName.FAGetValue().Clean(), "Verifying that ActiveFirstName is: AdhocFirstName");
                Support.AreEqual("A", FastDriver._1099S.ActiveMiddleName.FAGetValue().Clean(), "Verifying that ActiveMiddleName is: AdhocMiddleName");
                Support.AreEqual("AdhocLastName", FastDriver._1099S.ActiveLastName.FAGetValue().Clean(), "Verifying that ActiveLasttName is: AdhocLastName");
                Support.AreEqual("AdhocAddress", FastDriver._1099S.ActiveAddress.FAGetValue().Clean(), "Verifying that ActiveAddress is: AdhocAddress");
                Support.AreEqual("Irvine", FastDriver._1099S.ActiveCity.FAGetValue().Clean(), "Verifying that ActiveCity is: Irvine");
                Support.AreEqual("CA", FastDriver._1099S.ActivecboState.FAGetSelectedItem().Clean(), "Verifying that ActivecboState is: CA");
                Support.AreEqual("92604", FastDriver._1099S.ActiveZip.FAGetValue().Clean(), "Verifying that ActiveZip is: 92604");
                #endregion

                #region Modify Adhoc entry and enter correspond info
                Reports.TestStep = "Modify Adhoc entry and enter correspond info.";
                FastDriver._1099S.ActiveFirstName.FASetText("AdhocFirstNameModified");
                FastDriver._1099S.ActiveMiddleName.FASetText("K");
                FastDriver._1099S.ActiveLastName.FASetText("AdhocLastNameModified");
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Click on Ok button
                Reports.TestStep = "Click on Ok Button";
                Support.AreEqual("Resets information in all records to last saved version. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean(),
                                 "Verifying that the message is: Resets information in all records to last saved version. Continue?");
                #endregion

                #region Verify Adhoc entry and enter correspond info
                Reports.TestStep = "Verify Adhoc entry and enter correspond info.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocFirstName A AdhocLastName", 5, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("200.00", FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "AdhocFirstName A AdhocLastName", 5, TableAction.GetInputValue).Message.Clean(), "Verifying that Gross Proceed is: 200.00");
                Support.AreEqual("S=Social Security Number", FastDriver._1099S.SSNTINType.FAGetSelectedItem().Clean(), "Verifying that - is: S=Social Security Number");
                Support.AreEqual("112-23-3445", FastDriver._1099S.SSNTIN.FAGetValue().Clean(), "Verifying that SSNTINT is: 112-23-3445");
                Support.AreEqual("AdhocFirstName", FastDriver._1099S.ActiveFirstName.FAGetValue().Clean(), "Verifying that ActiveFirstName is: AdhocFirstName");
                Support.AreEqual("A", FastDriver._1099S.ActiveMiddleName.FAGetValue().Clean(), "Verifying that ActiveMiddleName is: AdhocMiddleName");
                Support.AreEqual("AdhocLastName", FastDriver._1099S.ActiveLastName.FAGetValue().Clean(), "Verifying that ActiveLasttName is: AdhocLastName");
                Support.AreEqual("AdhocAddress", FastDriver._1099S.ActiveAddress.FAGetValue().Clean(), "Verifying that ActiveAddress is: AdhocAddress");
                Support.AreEqual("Irvine", FastDriver._1099S.ActiveCity.FAGetValue().Clean(), "Verifying that ActiveCity is: Irvine");
                Support.AreEqual("CA", FastDriver._1099S.ActivecboState.FAGetSelectedItem().Clean(), "Verifying that ActivecboState is: CA");
                Support.AreEqual("92604", FastDriver._1099S.ActiveZip.FAGetValue().Clean(), "Verifying that ActiveZip is: 92604");
                FastDriver.BottomFrame.Save();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0051, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0053
        [TestMethod]
        public void FMUC0058_REG0053()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "FD_1: Validate Field Validations", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false, SalesPriceValue: 250001);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Select Proration Tax1 and click on Edit button
                this.ProrationTax1AndEditPerField();
                #endregion

                #region Navigate to 1099-S screen
                this.NavigateTo1099S();
                #endregion

                #region Enter the values less than boundaries in the fields
                Reports.TestStep = "Enter the values less than boundaries in the fields.";
                FastDriver._1099S.PropertyDescription.FASetText("1234567890 ABCDEFGHIJ 1234567890 12345");
                FastDriver._1099S.GrossProceedPercentage.FASetText("999.9998");
                FastDriver._1099S.BuyerPartofRETAXPercentage.FASetText("999.9998");
                Support.AreEqual("I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity", FastDriver._1099S.PayeeIndicator.FAGetAllTextFromSelect() , "Verifying that Payee have: I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity");
                Support.AreEqual("S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide", FastDriver._1099S.SSNTINType.FAGetAllTextFromSelect(), "Verifying that Payee have: S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide");
                FastDriver._1099S.ActiveFirstName.FASetText("1234567890 ABCDEFGHIJ 123456");
                FastDriver._1099S.ActiveMiddleName.FASetText("A");
                FastDriver._1099S.ActiveLastName.FASetText("1234567890 ABCDEFGHIJ 1234567890 1234567890 12345");
                FastDriver._1099S.ActiveAddress.FASetText("1234567890 ABCDEFGHIJ 1234567890 123456");
                FastDriver._1099S.ActiveCity.FASetText("1234567890 ABCDEFGHIJ 123456");
                FastDriver._1099S.ActiveZip.FASetText("9260");
                FastDriver._1099S.ActiveZip.FASendKeys(FAKeys.Tab);
                FASTHelpers.KeyboardSendKeys("{TAB}");
                #endregion

                #region Validate values less than boundaries in the fields
                Reports.TestStep = "Validates values less than boundaries in the fields.";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("1234567890 ABCDEFGHIJ 1234567890 12345", FastDriver._1099S.PropertyDescription.FAGetValue().Clean(), "Verifying that PropertyDescription is: 1234567890 ABCDEFGHIJ 1234567890 12345");
                Support.AreEqual("999.9998", FastDriver._1099S.GrossProceedPercentage.FAGetValue().Clean(), "Verifying that GrossProceedPercentage is: 999.9998");
                Support.AreEqual("999.9998", FastDriver._1099S.BuyerPartofRETAXPercentage.FAGetValue().Clean(), "Verifying that BuyerPartofRETAXPercentage is: 999.9998");
                Support.AreEqual("I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity", FastDriver._1099S.PayeeIndicator.FAGetAllTextFromSelect(), "Verifying that Payee have: I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity");
                Support.AreEqual("S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide", FastDriver._1099S.SSNTINType.FAGetAllTextFromSelect(), "Verifying that Payee have: S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide");
                Support.AreEqual("1234567890 ABCDEFGHIJ 123456", FastDriver._1099S.ActiveFirstName.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 123456");
                Support.AreEqual("A", FastDriver._1099S.ActiveMiddleName.FAGetValue().Clean(), "Verifying that Property Description is: A");
                Support.AreEqual("1234567890 ABCDEFGHIJ 1234567890 1234567890 12345", FastDriver._1099S.ActiveLastName.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 1234567890 1234567890 12345");
                Support.AreEqual("1234567890 ABCDEFGHIJ 1234567890 123456", FastDriver._1099S.ActiveAddress.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 1234567890 123456");
                Support.AreEqual("1234567890 ABCDEFGHIJ 123456", FastDriver._1099S.ActiveCity.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 123456");
                Support.AreEqual("?????", FastDriver._1099S.ActiveZip.FAGetValue().Clean(), "Verifying that Property Description is: ?????");
                #endregion

                #region Correct the Zip code
                Reports.TestStep = "Correct the Zip code.";
                FastDriver._1099S.ActiveZip.FASetText("92604");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate values less than boundaries in the fields after save
                Reports.TestStep = "Validate values less than boundaries in the fields after save.";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("1234567890 ABCDEFGHIJ 1234567890 12345", FastDriver._1099S.PropertyDescription.FAGetValue().Clean(), "Verifying that PropertyDescription is: 1234567890 ABCDEFGHIJ 1234567890 12345");
                Support.AreEqual("999.9998", FastDriver._1099S.GrossProceedPercentage.FAGetValue().Clean(), "Verifying that GrossProceedPercentage is: 999.9998");
                Support.AreEqual("999.9998", FastDriver._1099S.BuyerPartofRETAXPercentage.FAGetValue().Clean(), "Verifying that BuyerPartofRETAXPercentage is: 999.9998");
                Support.AreEqual("I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity", FastDriver._1099S.PayeeIndicator.FAGetAllTextFromSelect(), "Verifying that Payee have: I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity");
                Support.AreEqual("S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide", FastDriver._1099S.SSNTINType.FAGetAllTextFromSelect(), "Verifying that Payee have: S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide");
                Support.AreEqual("1234567890 ABCDEFGHIJ 123456", FastDriver._1099S.ActiveFirstName.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 123456");
                Support.AreEqual("A", FastDriver._1099S.ActiveMiddleName.FAGetValue().Clean(), "Verifying that Property Description is: A");
                Support.AreEqual("1234567890 ABCDEFGHIJ 1234567890 1234567890 12345", FastDriver._1099S.ActiveLastName.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 1234567890 1234567890 12345");
                Support.AreEqual("1234567890 ABCDEFGHIJ 1234567890 123456", FastDriver._1099S.ActiveAddress.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 1234567890 123456");
                Support.AreEqual("1234567890 ABCDEFGHIJ 123456", FastDriver._1099S.ActiveCity.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 123456");
                Support.AreEqual("92604", FastDriver._1099S.ActiveZip.FAGetValue().Clean(), "Verifying that Property Description is: 92604");
                #endregion

                #region Enter the values less than boundaries in the fields
                Reports.TestStep = "Enter the values less than boundaries in the fields.";
                FastDriver._1099S.PropertyDescription.FASetText("1234567890 ABCDEFGHIJ 1234567890 12345");
                FastDriver._1099S.GrossProceedPercentage.FASetText("999.9998");
                FastDriver._1099S.BuyerPartofRETAXPercentage.FASetText("999.9998");
                Support.AreEqual("I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity", FastDriver._1099S.PayeeIndicator.FAGetAllTextFromSelect(), "Verifying that Payee have: I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity");
                Support.AreEqual("S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide", FastDriver._1099S.SSNTINType.FAGetAllTextFromSelect(), "Verifying that Payee have: S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide");
                FastDriver._1099S.ActiveFirstName.FASetText("1234567890 ABCDEFGHIJ 123456");
                FastDriver._1099S.ActiveMiddleName.FASetText("A");
                FastDriver._1099S.ActiveLastName.FASetText("1234567890 ABCDEFGHIJ 1234567890 1234567890 12345");
                FastDriver._1099S.ActiveAddress.FASetText("1234567890 ABCDEFGHIJ 1234567890 123456");
                FastDriver._1099S.ActiveCity.FASetText("1234567890 ABCDEFGHIJ 123456");
                FastDriver._1099S.ActiveZip.FASetText("92604");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate values less than boundaries in the fields after save.
                Reports.TestStep = "Validate values less than boundaries in the fields after save.";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("1234567890 ABCDEFGHIJ 1234567890 12345", FastDriver._1099S.PropertyDescription.FAGetValue().Clean(), "Verifying that PropertyDescription is: 1234567890 ABCDEFGHIJ 1234567890 12345");
                Support.AreEqual("999.9998", FastDriver._1099S.GrossProceedPercentage.FAGetValue().Clean(), "Verifying that GrossProceedPercentage is: 999.9998");
                Support.AreEqual("999.9998", FastDriver._1099S.BuyerPartofRETAXPercentage.FAGetValue().Clean(), "Verifying that BuyerPartofRETAXPercentage is: 999.9998");
                Support.AreEqual("I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity", FastDriver._1099S.PayeeIndicator.FAGetAllTextFromSelect(), "Verifying that Payee have: I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity");
                Support.AreEqual("S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide", FastDriver._1099S.SSNTINType.FAGetAllTextFromSelect(), "Verifying that Payee have: S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide");
                Support.AreEqual("1234567890 ABCDEFGHIJ 123456", FastDriver._1099S.ActiveFirstName.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 123456");
                Support.AreEqual("A", FastDriver._1099S.ActiveMiddleName.FAGetValue().Clean(), "Verifying that Property Description is: A");
                Support.AreEqual("1234567890 ABCDEFGHIJ 1234567890 1234567890 12345", FastDriver._1099S.ActiveLastName.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 1234567890 1234567890 12345");
                Support.AreEqual("1234567890 ABCDEFGHIJ 1234567890 123456", FastDriver._1099S.ActiveAddress.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 1234567890 123456");
                Support.AreEqual("1234567890 ABCDEFGHIJ 123456", FastDriver._1099S.ActiveCity.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 123456");
                Support.AreEqual("92604", FastDriver._1099S.ActiveZip.FAGetValue().Clean(), "Verifying that Property Description is: 92604");
                #endregion

                #region Enter the values more than boundary values of the fields
                Reports.TestStep = "Enter the values more than boundary values of the fields.";
                FastDriver._1099S.PropertyDescription.FASetText("1234567890 ABCDEFGHIJ 1234567890 12345");
                FastDriver._1099S.GrossProceedPercentage.FASetText("1000.00");
                FastDriver._1099S.BuyerPartofRETAXPercentage.FASetText("1000.00");
                Support.AreEqual("I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity", FastDriver._1099S.PayeeIndicator.FAGetAllTextFromSelect(), "Verifying that Payee have: I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity");
                Support.AreEqual("S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide", FastDriver._1099S.SSNTINType.FAGetAllTextFromSelect(), "Verifying that Payee have: S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide");
                FastDriver._1099S.ActiveFirstName.FASetText("1234567890 ABCDEFGHIJ 123456");
                FastDriver._1099S.ActiveMiddleName.FASetText("A");
                FastDriver._1099S.ActiveLastName.FASetText("1234567890 ABCDEFGHIJ 1234567890 1234567890 12345");
                FastDriver._1099S.ActiveAddress.FASetText("1234567890 ABCDEFGHIJ 1234567890 123456");
                FastDriver._1099S.ActiveCity.FASetText("1234567890 ABCDEFGHIJ 123456");
                FastDriver._1099S.ActiveZip.FASetText("92604");
                FASTHelpers.KeyboardSendKeys("{TAB}");
                #endregion

                #region Validate values less than boundaries in the fields after save.
                Reports.TestStep = "Validate values less than boundaries in the fields after save.";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("1234567890 ABCDEFGHIJ 1234567890 12345", FastDriver._1099S.PropertyDescription.FAGetValue().Clean(), "Verifying that PropertyDescription is: 1234567890 ABCDEFGHIJ 1234567890 12345");
                Support.AreEqual("?", FastDriver._1099S.GrossProceedPercentage.FAGetValue().Clean(), "Verifying that GrossProceedPercentage is: ?");
                Support.AreEqual("?", FastDriver._1099S.BuyerPartofRETAXPercentage.FAGetValue().Clean(), "Verifying that BuyerPartofRETAXPercentage is: ?");
                Support.AreEqual("I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity", FastDriver._1099S.PayeeIndicator.FAGetAllTextFromSelect(), "Verifying that Payee have: I=Individual|I=Husband/Wife|C=Trust/Estate|C=Business Entity");
                Support.AreEqual("S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide", FastDriver._1099S.SSNTINType.FAGetAllTextFromSelect(), "Verifying that Payee have: S=Social Security Number|T=Tax ID Number|F=Foreign Seller|N=Did Not Provide");
                Support.AreEqual("1234567890 ABCDEFGHIJ 123456", FastDriver._1099S.ActiveFirstName.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 123456");
                Support.AreEqual("A", FastDriver._1099S.ActiveMiddleName.FAGetValue().Clean(), "Verifying that Property Description is: A");
                Support.AreEqual("1234567890 ABCDEFGHIJ 1234567890 1234567890 12345", FastDriver._1099S.ActiveLastName.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 1234567890 1234567890 12345");
                Support.AreEqual("1234567890 ABCDEFGHIJ 1234567890 123456", FastDriver._1099S.ActiveAddress.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 1234567890 123456");
                Support.AreEqual("1234567890 ABCDEFGHIJ 123456", FastDriver._1099S.ActiveCity.FAGetValue().Clean(), "Verifying that Property Description is: 1234567890 ABCDEFGHIJ 123456");
                Support.AreEqual("92604", FastDriver._1099S.ActiveZip.FAGetValue().Clean(), "Verifying that Property Description is: 92604");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0053, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0054
        [TestMethod]
        public void FMUC0058_REG0054()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "FD_2: Validate Field Validations", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Select Proration Tax1 and click on Edit button
                this.ProrationTax1AndEditPerField();
                #endregion

                #region Navigate to 1099-S screen
                this.NavigateTo1099S();
                #endregion

                #region Enter the values less than boundaries in the fields
                Reports.TestStep = "Enter the values less than boundaries in the fields.";
                FastDriver._1099S.GrossProceedPercentage.FASetText("999.9998");
                FastDriver._1099S.BuyerPartofRETAXPercentage.FASetText("999.9998");
                FastDriver._1099S.PropertyDescription.FASetText("1234567890 ABCDEFGHIJ 1234567890 12345");
                FastDriver._1099S.ActiveFirstName.FASetText("1234567890 ABCDEFGHIJ 123456");
                FastDriver._1099S.ActiveMiddleName.FASetText("A");
                FastDriver._1099S.ActiveLastName.FASetText("1234567890 ABCDEFGHIJ 1234567890 1234567890 12345");
                FastDriver._1099S.ActiveAddress.FASetText("1234567890 ABCDEFGHIJ 1234567890 123456");
                FastDriver._1099S.ActiveCity.FASetText("1234567890 ABCDEFGHIJ 123456");
                FastDriver._1099S.ActiveZip.FASetText("92604");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Reset Button
                Reports.TestStep = "Click on Reset Button";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Select Prorpation Tax1 and click on Edit button
                this.SelectProrationTax1AndClickEdit();
                #endregion

                #region Enter buyer charge $9999999.98
                Reports.TestStep = "Enter buyer charge $9999999.98";
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.BuyerCharge.FASetText("9999999.98");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Click on Ok button
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Enter the values less than boundaries in the fields Gross proceeed and Buyer pRat of RE tax.
                Reports.TestStep = "Enter the values less than boundaries in the fields Gross Proceeds and Buyer Part of RE tax.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("9999999999.98");
                FastDriver._1099S.BuyerPartofRETAXDollor.FASetText("9999999.98");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok button
                this.ClickOkButton(WaitFor1099S: false);
                this.ClickOkButton();
                #endregion

                #region Verify the values less than boundaries in the fields Gross Proceeds and Buyer Part of RE tax
                Reports.TestStep = "Verify the values less than boundaries in the fields Gross Proceeds and Buyer Part of RE tax.";
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("9,999,999,999.90", FastDriver._1099S.GrossProceedDollor.FAGetValue().Clean(), "Verifying that GrossProceedPercentage is: 9,999,999,999.98");
                Support.AreEqual("9,999,999.98", FastDriver._1099S.BuyerPartofRETAXDollor.FAGetValue().Clean(), "Verifying that BuyerPartofRETAXDollor is: 9,999,999.98");
                #endregion

                #region Select Proration Tax1 and click on Edit button
                Reports.TestStep = "Select Proration Tax1 and click on Edit button.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                this.ClickOkButton(WaitFor1099S: false);
                this.ClickOkButton(WaitFor1099S: false);
                this.ClickOkButton(WaitFor1099S: false);
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                #endregion

                #region Enter buyer charge $99999999.99.
                Reports.TestStep = "Enter buyer charge $99999999.99.";
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.BuyerCharge.FASetText("99999999.99");
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC058_REG0054, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0056_PH
        [TestMethod]
        public void FMUC0058_REG0056_PH()
        {
            try
            {
                Reports.TestDescription = "BR_ES6945: Display Buyer's Part of RE Tax in Red - Single Record";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0056_PH, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion
        #region FMUC0058_REG0057_PH
        [TestMethod]
        public void FMUC0058_REG0057_PH()
        {
            try
            {
                Reports.TestDescription = "BR_ES6965: Display Buyer's Part of RE Tax in Red - Multiple Records";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0057_PH, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion
        #region FMUC0058_REG0058_PH
        [TestMethod]
        public void FMUC0058_REG0058_PH()
        {
            try
            {
                Reports.TestDescription = "BR_ES6938: Display Sale Price in Red - Single Record";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0058_PH, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion
        #region FMUC0058_REG0059_PH
        [TestMethod]
        public void FMUC0058_REG0059_PH()
        {
            try
            {
                Reports.TestDescription = "BR_ES6951: Display Sale Price in Red - Multiple Records";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0059_PH, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion
        #region FMUC0058_REG0060_PH
        [TestMethod]
        public void FMUC0058_REG0060_PH()
        {
            try
            {
                Reports.TestDescription = "BR_ES6984: Maintain 1099-S Form Templates From Previous Years";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0060_PH, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion
        #region FMUC0058_REG0061_PH
        [TestMethod]
        public void FMUC0058_REG0061_PH()
        {
            try
            {
                Reports.TestDescription = "BR_ES6982: Print 1099-S Form According to IRS Guidelines"; 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0061_PH, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion
        #region FMUC0058_REG0062_PH
        [TestMethod]
        public void FMUC0058_REG0062_PH()
        {
            try
            {
                Reports.TestDescription = "BR_ES6981: Mark Void Checkbox on 1099-S Form";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0062_PH, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion
        #region FMUC0058_REG0063_PH
        [TestMethod]
        public void FMUC0058_REG0063_PH()
        {
            try
            {
                Reports.TestDescription = "BR_ES6959  : Condition to Print CORRECTED 1099-S Form"; 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0063_PH, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion
        #region FMUC0058_REG0064_PH
        [TestMethod]
        public void FMUC0058_REG0064_PH()
        {
            try
            {
                Reports.TestDescription = "BR_ES6510: User Security to Show or Hide 1099-S Link in Navigation";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0064_PH, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion
        #region FMUC0058_REG0065_PH
        [TestMethod]
        public void FMUC0058_REG0065_PH()
        {
            try
            {
                Reports.TestDescription = "BR_ES6979: Prevent 1099-S Form Delivery";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0065_PH, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion
        #region FMUC0058_REG0066_PH
        [TestMethod]
        public void FMUC0058_REG0066_PH()
        {
            try
            {
                Reports.TestDescription = "BR_ES6983: Allow All Delivery Methods Except E-mail";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0066_PH, couldn't be completed because: " + ex.Message); ;
            }
        }
        #endregion
        #region FMUC0058_REG0067_PH
        [TestMethod]
        public void FMUC0058_REG0067_PH()
        {
            try
            {
                Reports.TestDescription = "Button_Icon_ToolTip_VoidButton: VoidButton needs to be validated manually"; 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0067_PH, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion
        #region FMUC0058_REG0068_PH
        [TestMethod]
        public void FMUC0058_REG0068_PH()
        {
            try
            {
                Reports.TestDescription = "Button_Icon_ToolTip_DeliverButtonFramework: DeliverButton - framework needs to be validated manually"; 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0068_PH, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion
        #region FMUC0058_REG0069_PH
        [TestMethod]
        public void FMUC0058_REG0069_PH()
        {
            try
            {
                Reports.TestDescription = "FD_Text: Manually validate Date Created, Last Corrected, Date Voided, Last Delivered, Last Exported, Current Sequence No. and  Original Sequence No";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0069_PH, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0070
        [TestMethod]
        public void FMUC0058_REG0070()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6521_1_ES6974_3_TFSDefect: Validate for single 1099s and Property service check box is unchecked and then checked", loginType: "", emptyCache: true, UseDefaultCreateFileMethod: false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Verify the data populated for first record - Individual seller
                Reports.TestStep = "Verify the data populated for first record - Individual seller.";
                this.NavigateTo1099S();
                Support.AreEqual("260,000.00", FastDriver._1099S.GrossProceedDollor.FAGetValue().Clean(), "Verifying that Gross Proceeed Dollor is: 260,000.00");
                #endregion

                #region Verify for Property or services received as part of consideration check box unchecked
                Reports.TestStep = "Verify for Property or services received as part of consideration check box unchecked.";
                Support.AreEqual("False", FastDriver._1099S.PropertyConsideration.IsSelected().ToString().Clean(), "Verifying that PropertyConsideration is: False");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Decrease gross proceeds dollar amount for first record
                Reports.TestStep = "Decrease gross proceeds dollar amount for first record.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("700.00");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate a message and click on Cancel
                Reports.TestStep = "Validate a message and click on Cancel";
                Support.AreEqual("Sale Price is not fully distributed.", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean(), "Verifying that the message is: Sale Price is not fully distributed.");
                #endregion

                #region Click on Reset Button
                Reports.TestStep = "Click on Reset Button";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Click on Ok button
                Reports.TestStep = "Click on Ok button";
                Support.AreEqual("Resets information in all records to last saved version. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean(), "Verifying that the message is: Resets information in all records to last saved version. Continue?");
                #endregion

                #region Check Property or services received check box and save the record
                Reports.TestStep = "check Property or services received check box and save the record.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.PropertyConsideration.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify the data populated for first record - Individual seller
                Reports.TestStep = "Verify the data populated for first record - Individual seller.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("260,000.00", FastDriver._1099S.GrossProceedDollor.FAGetValue().Clean(), "Verifying that GrossProceedDollor is: 260,000.00.");
                #endregion

                #region Decrease gross proceeds dollar amount for first record
                Reports.TestStep = "Decrease gross proceeds dollar amount for first record.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("700.00");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate a message and click on Cancel
                Reports.TestStep = "Validate a message and click on Cancel";
                Support.AreEqual("Sale Price is not fully distributed.", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean(), "Verifying that the message is: Sale Price is not fully distributed.");
                #endregion

                #region Click on Reset Button
                Reports.TestStep = "Click on Reset Button";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Click on Ok button
                Reports.TestStep = "Click on Ok button";
                Support.AreEqual("Resets information in all records to last saved version. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean(), "Verifying that the message is: Resets information in all records to last saved version. Continue?");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0070, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0071
        [TestMethod]
        public void FMUC0058_REG0071()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6521_1_ES6974_4_TFSDefect: Validate for single 1099s and Property service check box is unchecked and then checked", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Verify the data populated for first record - Individual seller
                Reports.TestStep = "Verify the data populated for first record - Individual seller.";
                this.NavigateTo1099S();
                Support.AreEqual("260,000.00", FastDriver._1099S.GrossProceedDollor.FAGetValue().Clean(), "Verifying that Gross Proceeed Dollor is: 260,000.00");
                #endregion

                #region Verify for Property or services received as part of consideration check box unchecked
                Reports.TestStep = "Verify for Property or services received as part of consideration check box unchecked.";
                Support.AreEqual("False", FastDriver._1099S.PropertyConsideration.IsSelected().ToString().Clean(), "Verifying that PropertyConsideration is: False");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Make gross proceeds as zero dollar amount for first record
                Reports.TestStep = "Make  gross proceeds as zero dollar amount for first record.";
                FastDriver.LeftNavigation.Navigate<_1099S>("Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate a message and click on Cancel
                Reports.TestStep = "Validate a message and click on Cancel";
                Support.AreEqual("Sale Price is not fully distributed.", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean(), "Verifying that the message is: Sale Price is not fully distributed.");
                #endregion

                #region Click on Reset Button
                Reports.TestStep = "Click on Reset Button";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Click on Ok button
                Reports.TestStep = "Click on Ok button";
                Support.AreEqual("Resets information in all records to last saved version. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean(), "Verifying that the message is: Resets information in all records to last saved version. Continue?");
                #endregion

                #region Check Property or services received check box and save the record
                Reports.TestStep = "check Property or services received check box and save the record.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.PropertyConsideration.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify the data populated for first record - Individual seller
                Reports.TestStep = "Verify the data populated for first record - Individual seller.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("260,000.00", FastDriver._1099S.GrossProceedDollor.FAGetValue().Clean(), "Verifying that GrossProceedDollor is: 260,000.00.");
                #endregion

                #region Make gross proceeds as zero dollar amount for first record
                Reports.TestStep = "Make  gross proceeds as zero dollar amount for first record.";
                FastDriver.LeftNavigation.Navigate<_1099S>("Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate a message and click on Cancel
                Reports.TestStep = "Validate a message and click on Cancel";
                Support.AreEqual("Sale Price is not fully distributed.", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean(), "Verifying that the message is: Sale Price is not fully distributed.");
                #endregion

                #region Click on Reset Button
                Reports.TestStep = "Click on Reset Button";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Click on Ok button
                Reports.TestStep = "Click on Ok button";
                Support.AreEqual("Resets information in all records to last saved version. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean(), "Verifying that the message is: Resets information in all records to last saved version. Continue?");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0071, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0072
        [TestMethod]
        public void FMUC0058_REG0072()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6521_2_ES6974_3_TFSDefect: Validate for multiple 1099s and Property service check box is unchecked and then checked", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Verify the data populated for first record - Individual seller
                Reports.TestStep = "Verify the data populated for first record - Individual seller.";
                this.NavigateTo1099S();
                Support.AreEqual("260,000.00", FastDriver._1099S.GrossProceedDollor.FAGetValue().Clean(), "Verifying that Gross Proceeed Dollor is: 260,000.00");
                #endregion

                #region Verify for Property or services received as part of consideration check box unchecked
                Reports.TestStep = "Verify for Property or services received as part of consideration check box unchecked.";
                Support.AreEqual("False", FastDriver._1099S.PropertyConsideration.IsSelected().ToString().Clean(), "Verifying that PropertyConsideration is: False");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Decrease gross proceeds dollar amount for first record
                Reports.TestStep = "Decrease gross proceeds dollar amount for first record.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("700.00");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate a message and click on Cancel
                Reports.TestStep = "Validate a message and click on Cancel";
                Support.AreEqual("Sale Price is not fully distributed.", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean(), "Verifying that the message is: Sale Price is not fully distributed.");
                #endregion

                #region Click on Reset Button
                Reports.TestStep = "Click on Reset Button";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Click on Ok button
                Reports.TestStep = "Click on Ok button";
                Support.AreEqual("Resets information in all records to last saved version. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean(), "Verifying that the message is: Resets information in all records to last saved version. Continue?");
                #endregion

                #region Check Property or services received check box and save the record
                Reports.TestStep = "check Property or services received check box and save the record.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.PropertyConsideration.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify the data populated for first record - Individual seller
                Reports.TestStep = "Verify the data populated for first record - Individual seller.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("260,000.00", FastDriver._1099S.GrossProceedDollor.FAGetValue().Clean(), "Verifying that GrossProceedDollor is: 260,000.00.");
                #endregion

                #region Decrease gross proceeds dollar amount for first record
                Reports.TestStep = "Decrease gross proceeds dollar amount for first record.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("700.00");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate a message and click on Cancel
                Reports.TestStep = "Validate a message and click on Cancel";
                Support.AreEqual("Sale Price is not fully distributed.", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean(), "Verifying that the message is: Sale Price is not fully distributed.");
                #endregion

                #region Click on Reset Button
                Reports.TestStep = "Click on Reset Button";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Click on Ok button
                Reports.TestStep = "Click on Ok button";
                Support.AreEqual("Resets information in all records to last saved version. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean(), "Verifying that the message is: Resets information in all records to last saved version. Continue?");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0072, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #region FMUC0058_REG0073
        [TestMethod]
        public void FMUC0058_REG0073()
        {
            try
            {
                #region Login & Create File
                this.basicSteps(ReportName: "BR_ES6521_2_ES6974_4_TFSDefect: Validate for multiple 1099s and Property service check box is unchecked and then checked", loginType: "", emptyCache: false, UseDefaultCreateFileMethod: false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Verify the data populated for first record - Individual seller
                Reports.TestStep = "Verify the data populated for first record - Individual seller.";
                this.NavigateTo1099S();
                Support.AreEqual("260,000.00", FastDriver._1099S.GrossProceedDollor.FAGetValue().Clean(), "Verifying that Gross Proceeed Dollor is: 260,000.00");
                #endregion

                #region Verify for Property or services received as part of consideration check box unchecked
                Reports.TestStep = "Verify for Property or services received as part of consideration check box unchecked.";
                Support.AreEqual("False", FastDriver._1099S.PropertyConsideration.IsSelected().ToString().Clean(), "Verifying that PropertyConsideration is: False");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Make gross proceeds as zero dollar amount for first record
                Reports.TestStep = "Make  gross proceeds as zero dollar amount for first record.";
                FastDriver.LeftNavigation.Navigate<_1099S>("Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate a message and click on Cancel
                Reports.TestStep = "Validate a message and click on Cancel";
                Support.AreEqual("Sale Price is not fully distributed.", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean(), "Verifying that the message is: Sale Price is not fully distributed.");
                #endregion

                #region Click on Reset Button
                Reports.TestStep = "Click on Reset Button";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Click on Ok button
                Reports.TestStep = "Click on Ok button";
                Support.AreEqual("Resets information in all records to last saved version. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean(), "Verifying that the message is: Resets information in all records to last saved version. Continue?");
                #endregion

                #region Check Property or services received check box and save the record
                Reports.TestStep = "check Property or services received check box and save the record.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.PropertyConsideration.FAClick();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify the data populated for first record - Individual seller
                Reports.TestStep = "Verify the data populated for first record - Individual seller.";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                Support.AreEqual("260,000.00", FastDriver._1099S.GrossProceedDollor.FAGetValue().Clean(), "Verifying that GrossProceedDollor is: 260,000.00.");
                #endregion

                #region Make gross proceeds as zero dollar amount for first record
                Reports.TestStep = "Make  gross proceeds as zero dollar amount for first record.";
                FastDriver.LeftNavigation.Navigate<_1099S>("Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.GrossProceedDollor.FASetText("");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate a message and click on Cancel
                Reports.TestStep = "Validate a message and click on Cancel";
                Support.AreEqual("Sale Price is not fully distributed.", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean(), "Verifying that the message is: Sale Price is not fully distributed.");
                #endregion

                #region Click on Reset Button
                Reports.TestStep = "Click on Reset Button";
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion

                #region Click on Ok button
                Reports.TestStep = "Click on Ok button";
                Support.AreEqual("Resets information in all records to last saved version. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean(), "Verifying that the message is: Resets information in all records to last saved version. Continue?");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0073, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion


        //Team                                    : ServReq
        //Iteration                               : r10
        //UserStory                               : User Story 748571:INC2374897 - Direct [Bug] - Spell Check missing from Email and Fax Modules
        //TestCase                                : 884495
        //Appended By/ Created By                 : Nikhil
        #region FMUC0058_REG0074
        [TestMethod]
        public void FMUC0058_REG0074()
        {
            try
            {
                #region Login & Create File
                this.basicSteps("BR_ES6548_ES6961_ES6962_ES6549_ES6978: Validate the BRs", "", false, false);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
                #endregion

                #region Navigate to the seller screen select the set to property radio button for forward address for first seller
                this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("second", 3);
                #endregion

                #region Navigate to TDS screen and Enter the settlement date as past date to current system date.
                this.NavigateToTDSAndSetSettlementDateAsPastDate();
                #endregion

                #region Modify data for the first record.
                Reports.TestStep = "Modify data for the first record.";
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
                FastDriver._1099S.WaitForScreenToLoad();
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, 1, TableAction.Click);
                this.ModifyDataOfSelectedAdhoc("1234567890", "Seller1FirstName", "K", "Seller1LastName", "45 Bluejay", "Irvine", "CA", "92707");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Check Ready for Extract checkbox and click on save button for the first record.
                Reports.TestStep = "Check Ready for Extract Checkbox an click on save button for the first record";
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, "Seller1FirstName K Seller1LastNa", 1, TableAction.Click);
                FastDriver._1099S.WaitForScreenToLoad();
                if (!FastDriver._1099S.ActiveReadyForExtract.IsSelected())
                {
                    FastDriver._1099S.ActiveReadyForExtract.FAClick();
                }

                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Ok button
                this.ClickOkButton();
                #endregion

                #region Spell Check
                Reports.TestStep = "Spell check-email and fax";
                FastDriver._1099S.SwitchToContentFrame();
                FastDriver._1099S.Method.FASelectItem("Fax");
                FastDriver._1099S.Deliver.FAClick();
                FastDriver.SpellingErrorDlg.SpellCheck_Fax();

                #endregion
            }
            catch (Exception ex)
            {
                FailTest("The test FMUC0058_REG0074, couldn't be completed because: " + ex.Message);
            }
        }
        #endregion

        #endregion

        #region Private Methods

        #region Login

        private void Login(string description, string type = "")
        {
            Reports.TestDescription = description;
            Reports.TestStep = "Login FAST application";

            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            if (type.Equals("ADM"))
            {
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            }
            else
            {
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            }
        }

        #endregion

        #region Creation of File

        private void CreateFileWithWebService(bool UseLocalMethod = false)
        {
            CreateFileRequest fileRequest = new CreateFileRequest();

            fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

            Reports.TestStep = "Create File using web service.";
            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SwitchToTopFrame();
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        }

        private void CreateFileWithGUI(bool qfe = true)
        {
            Reports.TestStep = "Create File using FAST GUI.";
            if (qfe)
            {
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad();

                try
                {
                    FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.CreateStandardFile();

            }
            else
            {
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>(@"Home>Order Entry>Quick Refi Entry").WaitForScreenToLoad();
                try
                {
                    FastDriver.DuplicateFileSearch.SwitchToContentFrame();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickRefiFileEntry.WaitForScrenToLoad();
                FastDriver.QuickRefiFileEntry.CreateStandardFile();
            }
        }

        private void CreatingFileWith260KOfSalesPrice(int SalesPriceValue = 260000)
        {
            CreateFileRequest fileRequest = new CreateFileRequest();

            fileRequest = new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,

                #region File
                File = new File()
                {
                    SalesPriceAmount = SalesPriceValue,
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "RESIDENTAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    BusinessParties = new FileBusinessParty[]
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    },
                    Services = new Service[]
                    {
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID),
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                        ServiceTypeObjectCD = "TO"
                        },
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID),
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[]
                    {
                        new Property()
                        {
                            Name = "PropertyName",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",
                            ProperyTypeCdID = 15, //Single Family Residence
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress()
                                {
                                    AddrLine1 = "Line1",
                                    AddrLine2 = "Line2",
                                    AddrLine3 = "Line3",
                                    AddrLine4 = "Line4",
                                    State = "CA",
                                    City = "Santa Ana",
                                    County = "Orange",
                                    Country = "USA",
                                    Zip = "92604"
                                }
                            }
                        }
                    },
                    Buyers = new BuyerSeller[]
                    {
                        new BuyerSeller()
                        {
                            Type = "Individual",
                            SSN = "123-45-6789",
                            FirstName = "Buyer1Firstname",
                            LastName = "Buyer1Lastname",
                        }
                    },
                    Sellers = new BuyerSeller[]
                    {
                        new BuyerSeller()
                        {
                            Type = "Individual",
                            SSN = "987-65-4321",
                            FirstName = "S1FN",
                            MiddleName = "S1MN",
                            LastName = "S1LN",
                            Suffix = "Sir"
                        },
                        new BuyerSeller()
                        {
                            Type = "Husband and Wife",
                            FirstName = "S2FN",
                            MiddleName = "S2MN",
                            LastName = "S2LN",
                            Suffix = "Dr",
                            SSN = "112-23-3445",
                            SpouseFirstName = "S2SFN",
                            SpouseMiddleName = "S2SMN",
                            SpouseLastName = "S2SLN",
                            SpouseSuffix = "Sir",
                            SpouseSSN = "554-43-3221"
                        }
                    }
                }
                #endregion
            };

            Reports.TestStep = "Create File using web service.";
            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SwitchToTopFrame();
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            
        }

        #endregion

        #region Login & Create File
        private void basicSteps(string ReportName, string loginType = "", bool emptyCache = false, bool UseDefaultCreateFileMethod = true, int SalesPriceValue = 260000)
        {
            #region Login
            this.Login(ReportName, loginType);
            #endregion

            #region BaseState
            if (emptyCache)
            {
                Reports.TestStep = "Deleting Cache";
                Support.DeleteCacheCookies();
            }
            #endregion

            #region Quick File Entry
            if (loginType != "ADM")
            {
                try
                {
                    if (UseDefaultCreateFileMethod)
                    {
                        this.CreateFileWithWebService();
                    }
                    else
                    {
                        this.CreatingFileWith260KOfSalesPrice(SalesPriceValue);
                    }
                }
                catch (Exception e)
                {
                    this.CreateFileWithGUI();
                    Reports.UpdateDebugLog("Web Services failed. File created using GUI.", "Web Services", "", e.Message.ToString(), "", "", Reports.Result(false), "");
                }
            }
            #endregion
        }

        #endregion

        #region Custom Creation of File
        private void CustomFileCreation()
        {
            #region Click on skip button to go to QFE
            Reports.TestStep = "Click on skip button to go to QFE";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
            FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
            #endregion

            #region Create Order with two sellers for 1099-S with Sale Price more than 250000
            Reports.TestStep = "Create Order with two sellers for 1099-S with Sale Price more than 250000";
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("HUDFLINSR1");
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sales w/Mortgage");

            if (!FastDriver.QuickFileEntry.Title.IsSelected())
            {
                FastDriver.QuickFileEntry.Title.FAClick();
            }

            if (!FastDriver.QuickFileEntry.Escrow.IsSelected())
            {
                FastDriver.QuickFileEntry.Escrow.FAClick();
            }
            
            FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("260000");
            Support.SendKeys(FAKeys.Tab);
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("Line1");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("Line2");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("Line3");
            FastDriver.QuickFileEntry.PropertyBookAddrLin4.FASetText("Line4");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
            FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
            FastDriver.QuickFileEntry.PropertyZip.FASetText("92604");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
            FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
            FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
            FastDriver.QuickFileEntry.Seller1FirstName.FASetText("S1FN");
            FastDriver.QuickFileEntry.Seller1MiddleName.FASetText("S1MN");
            FastDriver.QuickFileEntry.Seller1LastName.FASetText("S1LN");
            FastDriver.QuickFileEntry.Seller1Suffix.FASetText("Sir");
            FastDriver.QuickFileEntry.Seller1SSN.FASetText("9876543210");
            FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
            FastDriver.QuickFileEntry.Seller2FirstName.FASetText("S2FN");
            FastDriver.QuickFileEntry.Seller2MiddleName.FASetText("S2MN");
            FastDriver.QuickFileEntry.Seller2LastName.FASetText("S2LN");
            FastDriver.QuickFileEntry.Seller2Suffix.FASetText("Dr");
            FastDriver.QuickFileEntry.Seller2SSN.FASetText("1122334455");
            FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("S2SFN");
            FastDriver.QuickFileEntry.Seller2SpouseMiddleName.FASetText("S2SMN");
            FastDriver.QuickFileEntry.Seller2SpouseLastName.FASetText("S2SLN");
            FastDriver.QuickFileEntry.Seller2SpouseSuffix.FASetText("Sir");
            FastDriver.QuickFileEntry.Seller2SpouseSSN.FASetText("5544332211");
            FastDriver.BottomFrame.Save();
            #endregion

            #region Navigate to the seller screen and add a Trust Estate seller
            Reports.TestStep = "Navigate to the seller screen and add a Trust State Seller";
            FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers");
            FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
            FastDriver.BuyerSellerSummary.New();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Trust/State");
            Playback.Wait(5000);
            FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
            FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("TrustShortName");
            FastDriver.BuyerSellerSetup.TrustSSNtext.FASetText("147852963");
            FastDriver.BuyerSellerSetup.TrustLastNameFor1099SReporting.FASetText("TrustLastName");
            FastDriver.BuyerSellerSetup.TrustSSNtype.FASelectItemBySendingKeys("1099-S");
            FastDriver.BottomFrame.Done();
            #endregion

            #region Navigate to the seller screen select the set to property radio button for forward address for first seller
            this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("first", 2);
            #endregion

            #region Navigate to the seller screen select the set to property radio button for forward address for second seller
            this.NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress("second", 3);
            #endregion

            #region Navigate to TDS screen and Enter the settlement date as past date to current system date
            this.NavigateToTDSAndSetSettlementDateAsPastDate();
            #endregion
        }
        #endregion

        #region Setting Up Activity Date
        private void SetUpActivityDateADM(bool CurrentDate = false)
        {
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            Reports.TestStep = "Login into ADM";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            Reports.TestStep = "Navigate to Office Setup screen, set 1099-S Activity Date";
            FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();

            if (CurrentDate)
            {
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText(DateTime.Now.ToString());
            } 

            else
            {
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText(DateTime.Now.ToString("08/10/2011"));
            }
            FastDriver.BottomFrame.Done();
            FastDriver.OfficeSummary.WaitForScreenToLoad();
            FastDriver.WebDriver.Quit();

        }
        #endregion

        #region NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress
        private void NavigateToSellerAndSetToPropertyRadioButtonForForwardAddress(string seller, int row)
        {
            #region Navigate to the seller screen select the set to property radio button for forward address for first seller.
            Reports.TestStep = "Navigate to the seller screen select the set to property radio button for forward address for " + seller + " seller.";
            FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers");
            FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
            FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(row, 1, TableAction.Click);
            FastDriver.BuyerSellerSummary.Edit();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
            //FastDriver.BuyerSellerSetup.HusbandwifeSSNType.FASelectItemBySendingKeys("1099-S");
            FastDriver.BottomFrame.Done();
            #endregion
        }
        #endregion

        #region NavigateToTDSAndSetSettlementDateAsPastDate
        private void NavigateToTDSAndSetSettlementDateAsPastDate(string TestStep = "Navigate to TDS screen and Enter the settlement date as past date to current system date.", string gap = "-2", bool HandleDialogMessage = true)
        {
            Reports.TestStep = TestStep;

            if (HandleDialogMessage)
            {
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status");
                FastDriver.WebDriver.HandleDialogMessage(false);
                FastDriver.WebDriver.HandleDialogMessage(true);
            }
            
            FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status");
            FastDriver.TermsDatesStatus.WaitForScreenToLoad();
            FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Today.AddDays(Convert.ToInt32(gap)).ToString("M-d-yyyy"));

            if (Int32.Parse(gap) > 0)
            {
                FastDriver.WebDriver.HandleDialogMessage(false);
            }

            Playback.Wait(5000);
            FastDriver.BottomFrame.Done();
        }
        #endregion

        #region SelectProrationTax1AndClickEdit
        private void SelectProrationTax1AndClickEdit()
        {
            Reports.TestStep = "Select Proration Tax1 and click on Edit button.";
            FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax");
            FastDriver.ProrationTax.WaitForScreenToLoad();
            FastDriver.ProrationTax.Tax1.FAClick();
            FastDriver.ProrationTax.Edit.FAClick();
        }
        #endregion

        #region ChangePerFieldToDay
        private void ChangePerFieldToDay()
        {
            Reports.TestStep = "Change the per Field to DAY.";
            FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("DAY");
            Playback.Wait(1000);
        }
        #endregion

        #region ClickOnDone.
        private void ClickOnDone()
        {
            Reports.TestStep = "Click on Done.";
            FastDriver.BottomFrame.Done();
            Playback.Wait(5000);
        }
        #endregion

        #region ClickNewButton
        private void ClickOnNew()
        {
            Reports.TestStep = "Click on New button.";
            FastDriver.ProrationTax.WaitForScreenToLoad();
            FastDriver.ProrationTax.New.FAClick();
        }
        #endregion

        #region ClickOkButton
        private void ClickOkButton(bool ReturnToWindow = false, bool WaitFor1099S = true, bool AcceptMessage = true)
        {
            Reports.TestStep = "Click on Ok button";
            FastDriver.WebDriver.HandleDialogMessage(ReturnToWindow, AcceptMessage);

            if (WaitFor1099S)
            {
                FastDriver._1099S.WaitForScreenToLoad();
            }
        }
        #endregion

        #region ChangePerFieldToMonth
        private void ChangePerFieldToMonth ()
        {
            Reports.TestStep = "Change the per field to MONTH.";
            FastDriver.ProrationDetail.WaitForScreenToLoad();
            FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("MONTH");
            Playback.Wait(1000);
        }
        #endregion

        #region SSN TIN Type Change
        private void PerformSSNTINTypeChange(string StepText, string RowName, string SSNTINType, bool SetSSTINTType = true, string GrossProceedDollorValue = "0.00", bool SetGrossProceedDollor = false, string SSNTIN = "", bool SetSSNTIN = false, string ActiveShortName = "", bool SetActiveShortName = false)
        {
            Reports.TestStep = StepText;
            FastDriver._1099S.WaitForScreenToLoad();
            FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, RowName, 1, TableAction.Click);
            FastDriver._1099S.WaitForScreenToLoad();

            if (SetGrossProceedDollor)
            {
                FASTHelpers.KeyboardSendKeys(GrossProceedDollorValue);
                FASTHelpers.KeyboardSendKeys("{TAB}");
            }

            if (SetSSTINTType)
            {
                FastDriver._1099S.SSNTINType.FASelectItemBySendingKeys(SSNTINType);
                Support.AreEqual(SSNTINType, FastDriver._1099S.SSNTINType.FAGetSelectedItem().ToString().Clean(), "Checking for the expected value: " + SSNTINType);
            }

            if(SetSSNTIN)
            {
                FastDriver._1099S.SSNTIN.FASetText(SSNTIN);
                Support.AreEqual(SSNTIN, FastDriver._1099S.SSNTIN.FAGetValue().ToString().Clean(), "Checking for expected value: " + SSNTIN);
            }

            if(SetActiveShortName)
            {
                FastDriver._1099S.PayeeIndicator.FASelectItemBySendingKeys("C = BusinessEntity");
                FastDriver._1099S.ActiveShortName.FASetText(ActiveShortName);
            }
            
            FastDriver.BottomFrame.Save();
        }
        #endregion

        #region Verify SSN TIN Type Change
        private void SSNTINTypeChangeVerification(string StepText, string RowName, string ExpectedTypeValue, string ExpectedValue, string GrossProceedDollorValue = "", bool GetGrossProceedDollorValue = false, string ActiveShortName = "", bool GetActiveShortName = false)
        {
            Reports.TestStep = StepText;
            FastDriver._1099S.WaitForScreenToLoad();
            FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, RowName, 1, TableAction.Click);
            FastDriver._1099S.WaitForScreenToLoad();
            Support.AreEqual(ExpectedTypeValue, FastDriver._1099S.SSNTINType.FAGetSelectedItem().ToString().Clean(), "Verify that the value of SSTINT Type is: " + ExpectedTypeValue);
            Support.AreEqual(ExpectedValue, FastDriver._1099S.SSNTIN.FAGetValue().Clean(), "Verifying that the value of SSNTIN is: " + ExpectedValue);

            if (GetGrossProceedDollorValue)
            {
                Support.AreEqual(GrossProceedDollorValue, FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, RowName, 5, TableAction.GetText).Message.Clean(), "Verifying that the value of SSNTIN is: " + GrossProceedDollorValue);
            }

            if(GetActiveShortName)
            {
                Support.AreEqual(ActiveShortName, FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, ActiveShortName, 1, TableAction.GetText).Message.Clean(), "Verifying that the value of ActiveShortName is: " + ActiveShortName);
            }
        }
        #endregion

        #region CheckActiveValuesOn1099SSummaryTable
        private void CheckActiveValuesOn1099SSummaryTable(string TestStep, string RowName, string SSNTIN, string ActiveFirstName = "", string ActiveMiddleName = "", string ActiveLastName = "", string ActiveAddress = "", string ActiveCity = "", 
                                                          string ActivecboState = "", string ActiveZip = "", bool CheckGross = false, string GrossValue = "0", bool CheckTaxDollor = false, string TaxValue = "", 
                                                          bool CheckPayeeIndicator = false, string PayeeIndicator = "", bool CheckSSNTINType = false, string SSNTINType = "", bool CheckForeignCountrySeller = false, 
                                                          string ForeignCountrySeller = "",  bool CheckActiveForeignAddress = false, string ActiveForeignAddress = "", bool SetGross = false, bool CheckActiveShortName = false, 
                                                          string ActiveShortName = "")
        {
            Reports.TestStep = TestStep;
            string RowNameUpdated = FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, RowName, 5, TableAction.GetText).Message.Clean();
            FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, RowName, 1, TableAction.Click);
            FastDriver._1099S.WaitForScreenToLoad();

            if (SetGross)
            {
                FASTHelpers.KeyboardSendKeys(GrossValue + "{TAB}");
            }

            if (CheckGross)
            {
                Support.AreEqual(GrossValue, FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, RowNameUpdated, 5, TableAction.GetText).Message.Clean(), "Verifying that GrossProceedDollor is: " + GrossValue);
            }

            if (CheckTaxDollor)
            {
                Support.AreEqual(TaxValue, FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, RowNameUpdated, 7, TableAction.GetText).Message.Clean(), "Verifying that BuyerPartofRETAXDollor is: " + TaxValue);
            }

            if (CheckPayeeIndicator)
            {
                Support.AreEqual(PayeeIndicator, FastDriver._1099S.PayeeIndicator.FAGetSelectedItem().ToString().Clean(), "Verifying that PayeeIndicator is: " + PayeeIndicator);
            }

            if (CheckSSNTINType)
            {
                Support.AreEqual(SSNTINType, FastDriver._1099S.SSNTINType.FAGetSelectedItem().ToString().Clean(), "Verifying that PayeeIndicator is: " + SSNTINType);
            }

            if (CheckForeignCountrySeller)
            {
                Support.AreEqual(ForeignCountrySeller, FastDriver._1099S.ForeignCountrySeller.IsSelected().ToString().Clean(), "Verifying that ForeignCountrySeller is: " + ForeignCountrySeller);
            }

            if (CheckActiveForeignAddress)
            {
                Support.AreEqual(ActiveForeignAddress, FastDriver._1099S.ActiveForeignAddress.IsSelected().ToString().Clean(), "Verifying that ForeignCountrySeller is: " + ActiveForeignAddress);
            }

            Support.AreEqual(SSNTIN, FastDriver._1099S.SSNTIN.FAGetValue().Clean(), "Verifying that SSNTIN is: " + SSNTIN);

            if (!CheckActiveShortName)
            {
                Support.AreEqual(ActiveFirstName, FastDriver._1099S.ActiveFirstName.FAGetValue().Clean(), "Verifying that ActiveFirstName is: " + ActiveFirstName);
                Support.AreEqual(ActiveMiddleName, FastDriver._1099S.ActiveMiddleName.FAGetValue().Clean(), "Verifying that ActiveMiddleName is: " + ActiveMiddleName);
                Support.AreEqual(ActiveLastName, FastDriver._1099S.ActiveLastName.FAGetValue().Clean(), "Verifying that ActiveLastName is: " + ActiveLastName);
            }

            else
            {
                Support.AreEqual(ActiveShortName, FastDriver._1099S.ActiveShortName.FAGetValue().Clean(), "Verifying that ActiveShortName is: " + ActiveShortName);
            }
            

            Support.AreEqual(ActiveAddress, FastDriver._1099S.ActiveAddress.FAGetValue().Clean(), "Verifying that ActiveAddress is: " + ActiveAddress);
            Support.AreEqual(ActiveCity, FastDriver._1099S.ActiveCity.FAGetValue().Clean(), "Verifying that ActiveCity is: " + ActiveCity);
            Support.AreEqual(ActivecboState, FastDriver._1099S.ActivecboState.FAGetSelectedItem().ToString().Clean(), "Verifying that ActivecboState is: " + ActivecboState);
            Support.AreEqual(ActiveZip, FastDriver._1099S.ActiveZip.FAGetValue().Clean(), "Verifying that ActiveZip is: " + ActiveZip);
        }
        #endregion

        #region ModifyDataOfSelectedAdhoc
        private void ModifyDataOfSelectedAdhoc(string SSNTIN, string ActiveFirstName = "", string ActiveMiddleName = "", string ActiveLastName = "", string ActiveAddress = "", string ActiveCity = "", string ActivecboState = "", 
                                               string ActiveZip = "", bool SetGross = false, string GrossValue = "", bool CheckSSNTINTType = false, string SSNTINTType = "", bool CheckActiveShortName = false, string ActiveShortName = "",
                                               bool CheckForeignCountrySeller = false)
        {
            FastDriver._1099S.WaitForScreenToLoad();

            if (CheckForeignCountrySeller)
            {
                Support.AreEqual("False", FastDriver._1099S.ForeignCountrySeller.IsSelected().ToString().Clean(), "Verifying that ForeignCountrySeller is: False");
            }

            if (CheckSSNTINTType)
            {
                Support.AreEqual(SSNTINTType, FastDriver._1099S.SSNTINType.FAGetSelectedItem().Clean(), "Verifying that SSNTINType is: " + SSNTINTType);
            }


            if (SetGross)
            {
                FASTHelpers.KeyboardSendKeys(GrossValue + "{TAB}");
            }

            FastDriver._1099S.SSNTIN.FASetText(SSNTIN);

            if (!CheckActiveShortName)
            {
                FastDriver._1099S.ActiveFirstName.FASetText(ActiveFirstName);
                FastDriver._1099S.ActiveMiddleName.FASetText(ActiveMiddleName);
                FastDriver._1099S.ActiveLastName.FASetText(ActiveLastName);
            }
            else
            {
                FastDriver._1099S.ActiveShortName.FASetText(ActiveShortName);
            }
            
            FastDriver._1099S.ActiveAddress.FASetText(ActiveAddress);
            FastDriver._1099S.ActiveCity.FASetText(ActiveCity);
            FastDriver._1099S.ActivecboState.FASelectItemBySendingKeys(ActivecboState);
            FastDriver._1099S.ActiveZip.FASetText(ActiveZip);
        }
        #endregion

        #region NewTrustEstateSeller
        private void NewTrustEstateSeller()
        {
            Reports.TestStep = "Navigate to the seller screen and add Trust Estate Seller.";
            FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers");
            FastDriver.BuyerSellerSummary.New();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Trust/Estate");
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("TrustShortName");
            FastDriver.BuyerSellerSetup.TrustSSNtext.FASetText("147852963");
            FastDriver.BuyerSellerSetup.TrustLastNameFor1099SReporting.FASetText("TrustLastName");
            FastDriver.BuyerSellerSetup.TrustSSNtype.FASelectItemBySendingKeys("1099-S");
            FastDriver.BottomFrame.Done();
        }
        #endregion

        #region VerifyEmptyFieldOn1099S
        private void VerifyEmptyFieldOn1099S(string TestDescription, string FieldAdded, string FieldRemoved, _1099S._1099SActiveProperty PropertyName, string PropertyValue, _1099S._1099SActiveProperty PropertyToBlankName, _1099S page)
        {
            #region Enter FieldAdded for the first seller record and remove FieldRemoved
            Reports.TestDescription = TestDescription;
            Reports.TestStep = "Enter " + FieldAdded + " for the first seller record and remove " + FieldRemoved + ".";
            FastDriver._1099S.WaitForScreenToLoad();

            FastDriver._1099S.Set1099SActiveProperty(page, PropertyName, PropertyValue);
            FastDriver._1099S.Set1099SActiveProperty(page, PropertyToBlankName, "");

            FastDriver.BottomFrame.Save();
            #endregion

            #region Verify for FieldRemoved is missing and click on Ok Button
            Reports.TestStep = "Verify for " + FieldRemoved + " is missing and click on Ok Button";
            Support.AreEqual(FieldRemoved + " is missing.", FastDriver.WebDriver.HandleDialogMessage(false).Clean(), "Verifying that message says: " + FieldRemoved + " is missing.");
            #endregion
        }
        #endregion

        #region VerifyOnFieldMisingAndClickOnOkButton
        private void VerifyMessageOnAlert(string TestStep, string CompareString, string ReportString, bool HandleDialog = false, bool WaitTime = true)
        {
            Reports.TestStep = "Verify for " + TestStep + " is missing and click on Ok Button";
            Support.AreEqual(CompareString, FastDriver.WebDriver.HandleDialogMessage(HandleDialog).Clean(), "Verify that the message is: " + ReportString);

            if (WaitTime)
            {
                Playback.Wait(1000);
            }  
        }
        #endregion

        #region ProrationTax1AndEditPerField
        private void ProrationTax1AndEditPerField(string PerType = "DAY")
        {
            #region Select Proration Tax1 and click on Edit button
            Reports.TestStep = "Select Proration Tax1 and click on Edit button.";
            FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax");
            FastDriver.ProrationTax.WaitForScreenToLoad();
            FastDriver.ProrationTax.Tax1.FAClick();
            FastDriver.ProrationTax.WaitForScreenToLoad();
            FastDriver.ProrationTax.Edit.FAClick();
            #endregion

            #region Change the per Field to DAY
            Reports.TestStep = "Change the per field to Day.";
            FastDriver.ProrationDetail.WaitForScreenToLoad();
            FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys(PerType);
            #endregion
        }
        #endregion

        #region Navigate to 1099S
        private void NavigateTo1099S(bool ClickOnMessage = false)
        {
            Reports.TestStep = "Navigate to 1099S screen.";
            FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");

            if (ClickOnMessage)
            {
                this.ClickOkButton(WaitFor1099S: false);
                this.ClickOkButton(ReturnToWindow: false, WaitFor1099S: false, AcceptMessage: true);
                FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
            }

            FastDriver._1099S.WaitForScreenToLoad();
        }
        #endregion

        #region NavigateToSellerAndAddTrustEstateSeller
        private void NavigateToSellerAndAddTrustEstateSeller()
        {
            Reports.TestStep = "Navigate to the seller screen and add a Trust Estate seller.";
            FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers");
            FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
            FastDriver.BuyerSellerSummary.New();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Trust/Estate");
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
            FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("TrustShortName");
            FastDriver.BuyerSellerSetup.TrustSSNtext.FASetText("147852963");
            FastDriver.BuyerSellerSetup.TrustLastNameFor1099SReporting.FASetText("TrustLastName");
            FastDriver.BottomFrame.Done();
        }
        #endregion

        #region NavigateToSellerAndAddBusinessEntitySeller
        private void NavigateToSellerAndAddBusinessEntitySeller()
        {
            Reports.TestStep = "Navigate to the seller escreen and add a Business Entity seller.";
            FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
            FastDriver.BuyerSellerSummary.New();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Business Entity");
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("BusinessEntityShortName");
            FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
            FastDriver.BuyerSellerSetup.BusinessEntitySSN.FASetText("582693471");
            FastDriver.BottomFrame.Done();
        }
        #endregion

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}