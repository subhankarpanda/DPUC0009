﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
// using AutoIt;
using System.Linq;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using System.Windows.Input;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;

namespace EscrowTransactions
{
    /// <summary>
    /// Summary description for FMUC0037 Edit Disbursement
    /// </summary>
    [CodedUITest]

    public class FMUC0037 : MasterTestClass
    {
        #region BAT

        #region Test FMUC0037_BAT0001

        /// <summary>
        /// MF1: 1. Edit Disbursment.
        /// </summary>
        [TestMethod]
        public void FMUC0037_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1: 1. Edit Disbursment";

                #region DataSetup
                BusOrgAdhocDlgParameters adhoc = new BusOrgAdhocDlgParameters()
                {
                    Name1 = "REB001",
                    City = "Albany",
                    State = "CA",
                    County = "Alameda",
                };
                // BusOrgAdhocDlgParameters BusOrgAdhoc = new BusOrgAdhocDlgParameters();
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                //string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                //FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Create an AD-HOC instance of REB.
                Reports.TestStep = "Create an AD-HOC instance of REB.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.FAClick();
                #endregion

                #region Enter REB ad-hoc details.
                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.SetAll(adhoc);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Enter Commission charge.
                Reports.TestStep = "Enter Commission charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                #endregion

                #region Navigate to Active Disbursement Summary, Click on Edit button after select reb1 and edit the reference and voucher memo.
                Reports.TestStep = "Navigate to Active Disbursement Summary, Click on Edit button after select reb1 and edit the reference and voucher memo.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Reference.FASetText("Test reference");
                FastDriver.EditDisbursement.VoucherMemo.FASetText("Test voucher memo");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Navigate to Active Disbursement Summary, Click on Edit button after select reb1 Validate the reference and voucher memo.
                Reports.TestStep = "Navigate to Active Disbursement Summary, Click on Edit button after select reb1 Validate the reference and voucher memo.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                string test = FastDriver.EditDisbursement.Reference.FAGetValue().ToString().Trim();
                Support.AreEqual("Test reference", FastDriver.EditDisbursement.Reference.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Test voucher memo", FastDriver.EditDisbursement.VoucherMemo.FAGetText().ToString().Trim(), true);

                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }
        }
        #endregion

        #region Test FMUC0037_BAT0002

        /// <summary>
        /// AF1: AF1: Hold Disbursement Check _ AF2: Release Hold on Disbursment";
        /// </summary>
        [TestMethod]
        public void FMUC0037_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1: Hold Disbursement Check:Sets hold for and reason for holding and navigates from the screen without saving the changes made _ AF2: Release Hold on Disbursement Check / Fee Transfer:Click on Release hold and navigate to other screen without saving.";

                #region DataSetup
                BusOrgAdhocDlgParameters adhoc = new BusOrgAdhocDlgParameters()
                {
                    Name1 = "REB001",
                    City = "Albany",
                    State = "CA",
                    County = "Alameda",
                };
                // BusOrgAdhocDlgParameters BusOrgAdhoc = new BusOrgAdhocDlgParameters();
                var value = string.Empty;
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                //string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                //FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Create an AD-HOC instance of REB.
                Reports.TestStep = "Create an AD-HOC instance of REB.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.FAClick();
                #endregion

                #region Enter REB ad-hoc details.
                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                FastDriver.BusOrgAdhocDlg.SetAll(adhoc);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Enter Commission charge.
                Reports.TestStep = "Enter Commission charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                #endregion

                #region Enter the Hold Information, validate the PENDING status in Active Disbursement Sumamry screen when Hold information is not saved..

                Reports.TestStep = "Click on Edit after clicking on REB001 and enter the Hold Information.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Do not save the hold days information, Click on Home, Click Ok on Dialog.";
                FastDriver.EditDisbursement.HoldInformation.FAClick();
                if (DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Sunday")
                    value = (7 + 3).ToString();
                else
                    value = "7";
                FastDriver.EditDisbursement.HoldFor.FASetText(value);
                FastDriver.EditDisbursement.PurposeOfHold.FASetText("Holding the disbursement");
                FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage().Clean();
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Validate the status as PENDING for REB001 in Active Disbursement Sumamry Screen.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Status", TableAction.GetText).Message.Trim());
                #endregion

                #region Validate that Hold details is not available in the hold information after not saving the data.
                Reports.TestStep = "Click on Edit button after select reb1, Validate that Hold details is not available in the hold information.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.HoldInformation.FAClick();
                Support.AreNotEqual(value, FastDriver.EditDisbursement.HoldFor.FAGetValue().ToString().Trim(), true);
                Support.AreNotEqual("Holding the disbursement", FastDriver.EditDisbursement.PurposeOfHold.GetAttribute("value").ToString().Trim(), true);
                #endregion

                #region Enter the Hold Information, validate the HELD status in Active Disbursement Sumamry screen by saving the Hold information entered.
                Reports.TestStep = "Enter the Hold Information and Save the hold days information";
                FastDriver.EditDisbursement.HoldFor.FASetText(value);
                FastDriver.EditDisbursement.PurposeOfHold.FASetText("Holding the disbursement");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the status as HELD for REB001 in Active Disbursement Sumamry Screen.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Held", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Status", TableAction.GetText).Message.Trim());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate that Hold details is available in the hold information after saving the data.
                Reports.TestStep = "Validate that status is held and Hold days in the hold information is present.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.HoldInformation.FAClick();
                Support.AreEqual(value, FastDriver.EditDisbursement.HoldFor.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("Holding the disbursement", FastDriver.EditDisbursement.PurposeOfHold.FAGetValue().ToString().Trim(), true);
                FastDriver.EditDisbursement.VerifyHELDstatus();
                #endregion

                #region Release Hold, Do not save changes and validate the status as HELD in Active Disbursemnet summary.

                Reports.TestStep = "Click on Edit button after select reb1.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Release Hold and Do not save, Click on Home, Click on Ok Button.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ReleaseHold.FAClick();
                FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage().Clean();
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Click on Edit button after select reb1, Validate the status as Held and Release Hold button is not set.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Held", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Status", TableAction.GetText).Message.Trim());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.EditDisbursement.ReleaseDate.FAGetText().ToString().Trim(), true);
                #endregion

                #region Release Hold, Save the changes and validate Release date as Current date in Edit disbursement.
                Reports.TestStep = "Click on Release Hold and Save the changes made.";
                FastDriver.EditDisbursement.ReleaseHold.FAClick();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate Release Hold is set and release date is current date.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.Date.ToDateString(), FastDriver.EditDisbursement.ReleaseDate.FAGetValue().ToString().Trim(), true);
                FastDriver.EditDisbursement.VerifyPENDINGstatus();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate the REB001 status as PENDING in Active Disbursement Summary,
                Reports.TestStep = "Validate for status pending.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Status", TableAction.GetText).Message.Trim());
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }
        }
        #endregion

        #region Test FMUC0037_BAT0003
        [TestMethod, Obsolete]
        public void FMUC0037_BAT0003()
        {
            Reports.TestDescription = @"AF2: Release Hold on Disbursement Check / Fee Transfer:Click on Release hold and navigate to other screen without saving (Covered in BAT0002).";
            Reports.StatusUpdate("AF2: Release Hold on Disbursement Check / Fee Transfer:Click on Release hold and navigate to other screen without saving (Covered in BAT0002).", true);
        }
        #endregion

        #region Test FMUC0037_BAT0004

        /// <summary>
        /// AF3: Split Disbursement: Navigate to split disbursement screen, AF4: Navigate to split disbursement screen ,change the split amount and validate the same, AF5: Navigate to split disbursement screen, remove the split amount and validate the same
        /// </summary>
        [TestMethod]
        public void FMUC0037_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF3: Split Disbursement: Navigate to split disbursement screen _ AF4: Navigate to split disbursement screen ,change the split amount and validate the same _ AF5: Navigate to split disbursement screen, remove the split amount and validate the same.";

                #region DataSetup
                BusOrgAdhocDlgParameters adhoc = new BusOrgAdhocDlgParameters()
                {
                    Name1 = "REB001",
                    City = "Albany",
                    State = "CA",
                    County = "Alameda",
                };
                // BusOrgAdhocDlgParameters BusOrgAdhoc = new BusOrgAdhocDlgParameters();
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                //string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                //FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Create an AD-HOC instance of REB.
                Reports.TestStep = "Create an AD-HOC instance of REB.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.FAClick();
                #endregion

                #region Enter REB ad-hoc details.
                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                // BusOrgAdhoc = FastDriver.BusOrgAdhocDlg.GetAdhocDetails;
                FastDriver.BusOrgAdhocDlg.SetAll(adhoc);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region Enter Commission charge.
                Reports.TestStep = "Enter Commission charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                #endregion

                #region Validate that amount is not split when Split disburement REB001 is not saved.

                Reports.TestStep = "Navigate to Active Disbursement Summary, Click on split button after selecting reb1.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();

                Reports.TestStep = "Navigate to Split disbursement screen, Enter amount to split and do not save.";
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("6.00" + FAKeys.Tab);
                // Keyboard.SendKeys(FAKeys.TabAway);
                Thread.Sleep(5000);
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FASetText("4.00");
                FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage().Clean();
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Active Disbursement Summary, Click on split button after select reb1.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();

                Reports.TestStep = "Navigate to Split disbursement screen, Validate that amount is not split.";
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.SplitDisbursement.SplitDistributionAmount0.FAGetValue().ToString().Trim(), true);
                #endregion

                #region When Split Disbursement REB001 is saved, validate that Split amount is saved, Master amount shows M, One amount is in Pending status and another in created status.
                Reports.TestStep = "Navigate to Active Disbursement Summary, Click on split button after select reb1.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();

                Reports.TestStep = "Navigate to Split disbursement screen, Split the amount and save."; // Validate that amount is split after saving the split amounts.";
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("6.00" + FAKeys.Tab);
                // Keyboard.SendKeys(FAKeys.TabAway);
                Thread.Sleep(5000);
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FASetText("4.00");
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that amount is split and master amount shows M, One Amount status is Pending and another is created.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("M", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Split", "S.", TableAction.GetText).Message.Trim());
                Support.AreEqual("M", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "10.00", "S.", TableAction.GetText).Message.Trim());
                Support.AreEqual("Split", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Status", TableAction.GetText).Message.Trim());
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "6.00", "Status", TableAction.GetText).Message.Trim());
                Support.AreEqual("Created", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.00", "Status", TableAction.GetText).Message.Trim());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                Support.AreEqual("6.00", FastDriver.SplitDisbursement.SplitDistributionAmount0.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("4.00", FastDriver.SplitDisbursement.SplitDistributionAmount1.FAGetValue().ToString().Trim(), true);
                #endregion

                #region In split disbursement screen ,change the split amount and validate the same.
                Reports.TestStep = "Click on split button after select reb1, Edit the amounts to split and saves changes made.";
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("4.00");
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FASetText("6.00");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Click on split button after select reb1, Validate the amounts changed.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.00", "Status", TableAction.GetText).Message.Trim());
                Support.AreEqual("Created", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "6.00", "Status", TableAction.GetText).Message.Trim());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                Support.AreEqual("4.00", FastDriver.SplitDisbursement.SplitDistributionAmount0.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("6.00", FastDriver.SplitDisbursement.SplitDistributionAmount1.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to split disbursement screen ,Remove the split amount and validate the pending status.
                Reports.TestStep = "Click on split button after select reb1, remove both the split amounts.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.Remove.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.Remove.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the pending status in Active disbursement summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Status", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Click on split button after select reb1, Validate that amount is removed.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.SplitDisbursement.SplitDistributionAmount0.FAGetValue().ToString().Trim(), true);
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }
        }
        #endregion

        #region Test FMUC0037_BAT0005
        [TestMethod, Obsolete]
        public void FMUC0037_BAT0005()
        {
            Reports.TestDescription = @"AF4: Navigate to split disbursement screen ,change the split amount and validate the same (Covered in BAT0004).";
            Reports.StatusUpdate("AF4: Navigate to split disbursement screen ,change the split amount and validate the same (Covered in BAT0004).", true);
        }
        #endregion

        #region Test FMUC0037_BAT0006
        [TestMethod, Obsolete]
        public void FMUC0037_BAT0006()
        {
            Reports.TestDescription = @"AF5: Navigate to split disbursement screen, remove the split amount and validate the same (Covered in BAT0004).";
            Reports.StatusUpdate("AF5: Navigate to split disbursement screen, remove the split amount and validate the same (Covered in BAT0004).", true);
        }
        #endregion

        #region Test FMUC0037_BAT0007

        /// <summary>
        /// AF 8: Approve Wire disbursement less than $20 Million _ AF 8: Approve Wire with another user.
        /// </summary>
        [TestMethod, DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void FMUC0037_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF 8: Approve Wire disbursement < $20 Million _ AF 8: Approve Wire with another user..";


                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Upload and save document
                FastDriver.DocumentRepository.UploadImgDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                #endregion

                #region Convert the charge to WIRE.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region AF 8: Approve Wire with another user.

                Reports.TestStep = "Approve Wire with another user.";
                Reports.StatusUpdate("Approve Wire with another user.", true);

                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);

                Reports.TestStep = "Enter file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Thread.Sleep(5000);
                FastDriver.FileSearch.FindNow.FAClick();
                Thread.Sleep(10000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.ClickOnWireInstructionImageAndApprove("FirstApproval");

                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }
        }
        #endregion

        #region Test FMUC0037_BAT0008
        [TestMethod, Obsolete]
        public void FMUC0037_BAT0008()
        {
            Reports.TestDescription = @"AF 8: Approve Wire with another user (Covered in BAT0007).";
            Reports.StatusUpdate("AF 8: Approve Wire with another user (Covered in BAT0007).", true);
        }
        #endregion

        #region Test FMUC0037_BAT0009

        /// <summary>
        /// AF 9: Approve Wire disbursement equal to or > $20 Million.
        /// </summary>
        [TestMethod, DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void FMUC0037_BAT0009()
        {
            try
            {
                Reports.TestDescription = "AF 9: Approve Wire disbursement equal to or > $20 Million.";

                #region Data Setup
                var HWbuyerCharge = "200,000,001.00";
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add home warranty charge more than 20 million.
                Reports.TestStep = "Add home warranty charge more than 20 million.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW2");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText(HWbuyerCharge);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Upload and save document
                FastDriver.DocumentRepository.UploadImgDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                #endregion

                #region Convert the charge to WIRE.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", HWbuyerCharge, "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region AF 9: Approve Wire with first user.

                Reports.TestStep = "Approve Wire with first user.";
                Reports.StatusUpdate("Approve Wire with first user.", true);

                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);

                Reports.TestStep = "Enter file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Thread.Sleep(5000);
                FastDriver.FileSearch.FindNow.FAClick();
                Thread.Sleep(10000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", HWbuyerCharge, "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.ClickOnWireInstructionImageAndApprove("FirstApproval");
                #endregion

                #region AF 9: Approve Wire with second user.

                Reports.TestStep = "Approve Wire with second user.";
                Reports.StatusUpdate("Approve Wire with second user.", true);

                IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);

                Reports.TestStep = "Enter file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Thread.Sleep(5000);
                FastDriver.FileSearch.FindNow.FAClick();
                Thread.Sleep(10000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", HWbuyerCharge, "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.ClickOnWireInstructionImageAndApprove("SecondApproval");
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }

        }
        #endregion

        #region Test FMUC0037_BAT0010
        [TestMethod, Obsolete]
        public void FMUC0037_BAT0010()
        {
            Reports.TestDescription = @"AF 9: Approve Wire with 1st user (Covered in BAT0009).";
            Reports.StatusUpdate("AF 9: Approve Wire with 1st user (Covered in BAT0009).", true);
        }
        #endregion

        #region Test FMUC0037_BAT0011
        [TestMethod, Obsolete]
        public void FMUC0037_BAT0011()
        {
            Reports.TestDescription = @"AF 9: Approve Wire with 2nd user. (Covered in BAT0009).";
            Reports.StatusUpdate("AF 9: Approve Wire with 2nd user. (Covered in BAT0009).", true);
        }
        #endregion

        #endregion BAT

        #region REG

        #region Test FMUC0037_REG0001

        /// <summary>
        /// FM1767_1769_1770_1768_2395_2487_2488_2489_ES9888;
        /// </summary>
        [TestMethod, DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void FMUC0037_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM1767_1769_1770_1768_2395_2487_2488_2489_ES9888:";

                #region Data Setup
                var value = string.Empty;
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add home warranty charges.
                Reports.TestStep = "Add home warranty charge more than 20 million.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW2");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("10.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("20.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Validate that given Check disbursement to be held, released more than once, and no requirement to keep track of the held "history."

                #region Navigate to Active Disb Summary and select the Pend charge, Validate the Mandatory information for a check(From Account and Payee name ) and click on Edit.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge, Validate the Mandatory information for a check(From Account and Payee name ) and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreNotEqual("", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "30.00", "Payee", TableAction.GetText).Message.Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "30.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreNotEqual("", FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem().ToString().Trim(), true);
                #endregion

                #region Save the Hold Days Info

                FastDriver.EditDisbursement.SaveHoldDays("7");
                #endregion

                #region Verify Held Fee in Active Disbursement Summary.
                Reports.TestStep = "Verify Held Fee in Active Disbursement Summary";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Held", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "30.00", "Status", TableAction.GetText).Message.Trim());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "30.00", "Amount", TableAction.Click);
                #endregion

                #region Release Hold and Save the changes made.
                FastDriver.EditDisbursement.SaveReleaseHold();
                #endregion

                #region Validate that Hold information is not stored in Disbursement History.
                Reports.TestStep = "Validate that Hold information is not stored in Disbursement History.";
                FastDriver.DisbursementHistory.Open();
                Support.AreNotEqual("Held", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "30.00", "Status", TableAction.GetText).Message.Trim());
                #endregion

                #region Navigate to Active Disb Summary and select the Pend charge and click on Edit.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "30.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                #endregion

                #region Save the Hold Days Info
                FastDriver.EditDisbursement.SaveHoldDays("6");
                #endregion

                #region Verify the Held Fee in Active Disbursement Summary.
                Reports.TestStep = "Verify the Held Fee in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Held", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "30.00", "Status", TableAction.GetText).Message.Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Held", "Status", TableAction.Click);
                #endregion

                #endregion

                #region Verify print and print all buttons are disable.
                Reports.TestStep = "Verify print and print all buttons are disable.";
                Support.AreNotEqual("true", FastDriver.ActiveDisbursementSummary.Print.Enabled.ToString().ToLower().Trim(), true);
                Support.AreNotEqual("true", FastDriver.ActiveDisbursementSummary.PrintAll.Enabled.ToString().ToLower().Trim(), true);
                #endregion

                #region Change status from Held to Created or Pending

                #region Click on Release Hold and Save the changes made_2nd time.
                Reports.TestStep = "Click on Release Hold and Save the changes made_2nd time.";
                FastDriver.EditDisbursement.SaveReleaseHold();
                #endregion

                #region Navigate to Active Disb Summary and select the Pend charge and click on Split.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Split.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "30.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionPercentage.FASetText("50.00" + FAKeys.Tab + FAKeys.Tab + FAKeys.Tab);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                FastDriver.SplitDisbursement.SplitDistributionPercentage1.FASetText("50.00" +FAKeys.Tab);
                // Keyboard.SendKeys(FAKeys.TabAway);
                // Thread.Sleep(5000);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Validate that check disbursement will be in Created status when mandatory field (Payee name is missing).
                Reports.TestStep = "Validate that check disbursement will be in Created status when mandatory field (Payee name is missing).";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Payee", TableAction.GetText).Message.Trim(), true);
                #endregion

                #region Convert the created status check to Held.
                Reports.TestStep = "Convert the created status check to Held.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.SaveHoldDays("7");
                #endregion

                #region Verify Held check in Disbursement History and Disbursement Summary
                Reports.TestStep = "Verify Held check in Disbursement History.";
                FastDriver.DisbursementHistory.Open();
                Support.AreEqual("Held", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Payee", "", "Status", TableAction.GetText).Message.Trim(), true);

                Reports.TestStep = "Verify Held check in Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Held", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "", "Status", TableAction.GetText).Message.Trim(), true);
                #endregion

                #region Release the hold check and validate for Created status in Disbursement Summary.
                Reports.TestStep = "Release the hold check and validate for Created status in Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Held", "Status", TableAction.Click);
                FastDriver.EditDisbursement.SaveReleaseHold();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Created", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "", "Status", TableAction.GetText).Message.Trim(), true);
                #endregion

                #region Validate that Hold information is not stored in Disbursement History
                Reports.TestStep = "Validate that Hold information is not stored in Disbursement History.";
                FastDriver.DisbursementHistory.Open();
                Support.AreEqual("Created", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Payee", "", "Status", TableAction.GetText).Message.Trim(), true);
                #endregion

                #region Validate that Status changes from Created to Pending when necessary information is entered.
                Reports.TestStep = "Validate that Status changes from Created to Pending when necessary information is entered.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisbursementPayee1.FASetText("TestPayeeName");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "TestPayeeName", "Status", TableAction.GetText).Message.Trim(), true);
                #endregion

                #endregion

                #region Verifying Hold for FeeTransfer

                #region Enter first fee in Title and escrow.
                EnterFeeInTitleEscrowTab();
                #endregion

                #region Convert the Pending status Fee to Held, verify Held Status in Disbursement summary and history
                Reports.TestStep = "Convert the Pending status Fee to Held_Click on Release Hold and Save the changes made.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                FastDriver.EditDisbursement.SaveHoldDays("7");

                Reports.TestStep = "Verify Held Fee in Disbursement History.";
                FastDriver.DisbursementHistory.Open();
                Support.AreEqual("Held", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "4.98", "Status", TableAction.GetText).Message.Trim(), true);

                Reports.TestStep = "Verify Held Fee in Active Disbursement Summary";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Held", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.GetText).Message.Trim());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);

                #endregion

                #region Release the Hold, Validate that the Fee Transfer status is changed to Pending in Disbursement Summary and Disbursement history.
                FastDriver.EditDisbursement.SaveReleaseHold();

                Reports.TestStep = "Validate that the Fee Transfer status is changed to Pending in Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Validate that Hold information is not stored in Disbursement History.";
                FastDriver.DisbursementHistory.Open();
                Support.AreEqual("Pending", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "4.98", "Status", TableAction.GetText).Message.Trim(), true);
                #endregion

                #endregion

                #region Verifying Hold for Wire.

                #region Add a Lease charge.
                Reports.TestStep = "Add a Lease charge.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.FindGABcode("LEASE");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Edit Disbursement Wire.
                Reports.TestStep = "Edit Disbursement Wire.";
                FastDriver.DocumentRepository.UploadImgDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "lease name 1 lease name 2", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region Convert the Pending status Wire to Held.
                Reports.TestStep = "Click Edit on Pending Status Wire.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Status", TableAction.GetText).Message.Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                FastDriver.EditDisbursement.SaveHoldDays("7");
                #endregion

                #region Verify the Held Wire in Disbursement History.
                Reports.TestStep = "Verify the Held Wire in Disbursement History.";
                FastDriver.DisbursementHistory.Open();
                Support.AreEqual("Held", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Payee", "lease name 1 lease name 2", "Status", TableAction.GetText).Message.Trim(), true);
                #endregion

                #region Verify the Held Wire in Disbursement Summary.
                Reports.TestStep = "Verify the Held Wire in Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Wire", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "lease name 1 lease name 2", "Funds", TableAction.GetText).Message.Trim(), true);
                Support.AreEqual("Held", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "lease name 1 lease name 2", "Status", TableAction.GetText).Message.Trim(), true);
                #endregion

                #region Validate that Print and PrnitAll is in disabled state for Held charges.
                Reports.TestStep = "Validate that Print is in disabled state Held charges.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Held", "Status", TableAction.Click);
                Support.AreNotEqual("true", FastDriver.ActiveDisbursementSummary.Print.Enabled.ToString().Trim().ToLower(), true);
                Support.AreNotEqual("true", FastDriver.ActiveDisbursementSummary.PrintAll.Enabled.ToString().Trim().ToLower(), true);
                #endregion

                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }

        }
        #endregion

        #region Test FMUC0037_REG0002

        /// <summary>
        /// 1773_2014_2015_2492_2490_2491_2527
        /// </summary>
        [TestMethod]
        public void FMUC0037_REG0002()
        {
            try
            {
                Reports.TestDescription = "1773_2014_2015_2492_2490_2491_2527";

                #region Data Setup
                var value = string.Empty;
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add home warranty charges.
                Reports.TestStep = "Add home warranty charge.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW2");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("10.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("20.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Active Disb Summary and select the Pend charge and click on Edit.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "30.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreNotEqual("", FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem().ToString().Trim(), true);
                FastDriver.EditDisbursement.SaveHoldDays("7");
                #endregion

                #region Verify Held Fee in Active Disbursement Summary.
                Reports.TestStep = "Verify Held Fee.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Held", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "30.00", "Status", TableAction.GetText).Message.Trim(), true);
                #endregion

                #region Click on Release Hold and Save the changes made.
                Reports.TestStep = "Click on Release Hold and Save the changes made.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Held", "Status", TableAction.Click);
                FastDriver.EditDisbursement.SaveReleaseHold();
                #endregion

                #region Split the pending charge to 50 percent for two parts and validate the same.
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "30.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionPercentage.FASetText("50.00" + FAKeys.Tab + FAKeys.Tab + FAKeys.Tab);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                FastDriver.SplitDisbursement.SplitDistributionPercentage1.FASetText("50.00" + FAKeys.Tab );
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                Support.AreEqual("15.00", FastDriver.SplitDisbursement.SplitDistributionAmount0.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("15.00", FastDriver.SplitDisbursement.SplitDistributionAmount1.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Validate for Created and Pending status of the splitted amounts.
                Reports.TestStep = "Validate for Created and Pending status of the splitted amounts.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.GetText);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.GetText);
                int RowCount = FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount();
                for (int row = 1; row <= RowCount; row++)
                {
                    string amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(row, 7, TableAction.GetText).Message.Trim();
                    if (amount == "15.00")
                    {
                        string status = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(row, 1, TableAction.GetText).Message.Trim();
                        if (status == "Created")
                        {
                            Reports.StatusUpdate("Split amount status appears as Created.", true);
                        }
                        else if (status == "Pending")
                        {
                            Reports.StatusUpdate("Split amount status appears as Pending.", true);
                        }
                    }
                }
                #endregion

                #region Split the orginal (master) amount with status as Split, by amount and save the split.
                Reports.TestStep = "Split the orginal (master) amount with status as Split, by amount and save the split.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Split", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("12.00");
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FASetText("18.00" + FAKeys.Tab );
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                FastDriver.SplitDisbursement.Remove.FAClick();

                Reports.TestStep = "Verify for split percent according to spitted amount.";
                Support.AreEqual("40.00", FastDriver.SplitDisbursement.SplitDistributionPercentage.FAGetValue(), ToString().Trim(), true);
                Support.AreEqual("60.00", FastDriver.SplitDisbursement.SplitDistributionPercentage1.FAGetValue(), ToString().Trim(), true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Remove the split and validate the pending status of Master amount.
                Reports.TestStep = "Remove the split and validate the pending status of Master amount.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Split", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.Remove.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.Remove.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "30.00", "Status", TableAction.GetText).Message.Trim(), true);
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }

        }
        #endregion

        #region Test FMUC0037_REG0003

        /// <summary>
        /// 14421_14422_14423_14424_14425_ES9886_ES9887_1774
        /// </summary>
        [TestMethod]
        public void FMUC0037_REG0003()
        {
            try
            {
                Reports.TestDescription = "14421_14422_14423_14424_14425_ES9886_ES9887_1774";

                #region Data Setup
                var value = string.Empty;
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add home warranty charges.
                Reports.TestStep = "Add home warranty charge.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW2");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("17.53");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Split the HW charge twice and validate the split amounts and created status.
                Reports.TestStep = "Split the HW charge twice and validate the splits.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "17.53", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionPercentage.FASetText("50.00" + FAKeys.Tab + FAKeys.Tab + FAKeys.Tab);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                FastDriver.SplitDisbursement.SplitDistributionPercentage1.FASetText("50.00" + FAKeys.Tab);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                Support.AreEqual("8.77", FastDriver.SplitDisbursement.SplitDistributionAmount0.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("8.76", FastDriver.SplitDisbursement.SplitDistributionAmount1.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Created", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "8.76", "Status", TableAction.GetText).Message.Trim(), true);
                #endregion

                #region Add a lease charge of $1003.73
                Reports.TestStep = "Add a lease charge of $1003.73.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.FindGABcode("LEASE");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Description1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("1003.73");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Split the Lease disbursement 5 times.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge with amount 1003.73 and click on Split.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "1,003.73", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();

                Reports.TestStep = "Split the disbursement 5 times.";
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.Split5Times();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate that the amount for the last split is lesser by 0.02 and the percentage remains same across all the splits
                Reports.TestStep = "Validate that the amount for the last split is lesser by 0.02.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                VerifyLastSplitAndAllPercentage();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate re-calculation of the amount for last payee when one of the split row is removed.
                Reports.TestStep = "Validate re-calculation of the amount for last payee when one of the split row is removed.";
                ValidateRecalOfSplitamount();
                #endregion

                #region Verify rounding of amount.
                Reports.TestStep = "Verify rounding of amount.";
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                int SDRowCount6 = FastDriver.SplitDisbursement.SplitDisbTable.GetRowCount();
                FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(SDRowCount6, 2, TableAction.SetText, "200.756789");
                FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(SDRowCount6, 1, TableAction.Click);
                string RoundOffAmt = FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(SDRowCount6, 2, TableAction.GetText).Message.ToString().Trim();
                Support.AreEqual("200.75", RoundOffAmt, true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify prevention of spliting a disbursement that is a member of a split
                Reports.TestStep = "Verify prevention of spliting a disbursement that is a member of a split.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "200.75", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                Support.AreEqual("0.00", FastDriver.SplitDisbursement.AmountRemaining.FAGetText().ToString().Trim(), true);
                Support.AreEqual("1,003.73", FastDriver.SplitDisbursement.MasterAmount.FAGetText().ToString().Trim(), true);
                Support.AreEqual("1", "1");
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }

        }
        #endregion

        #region Test FMUC0037_REG0004

        /// <summary>
        /// ES9894_ES9891_ES9894_ES9895_ES13375_FM3342_ES13347_ES13348_ES13349_ES13350_ES13351_ES13352_ES13376_ES13377_ES13378
        /// </summary>
        [TestMethod, DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void FMUC0037_REG0004()
        {
            try
            {
                Reports.TestDescription = "ES9894_ES9891_ES9894_ES9895_ES13375_FM3342_ES13347_ES13348_ES13349_ES13350_ES13351_ES13352_ES13376_ES13377_ES13378";

                #region Data Setup
                var value = string.Empty;
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add home warranty charges.
                Reports.TestStep = "Add home warranty charge.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW2");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("17.53");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Convert to Wire
                FastDriver.DocumentRepository.UploadImgDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "17.53", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region Verify from document repository and click on save.
                Reports.TestStep = "Verify from document repository and click on save.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "17.53", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("From Document Repository", FastDriver.EditDisbursement.SourseOfWireInsLabel.FAGetText().ToString().Trim(), true);
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify pending status of wire, voucher details and Mandatory Information for Pending Wire disbursement.
                Reports.TestStep = "Verify voucher details and click on done.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Status", TableAction.GetText).Message.Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Home Warranty:                                       17.53", FastDriver.EditDisbursement.VoucherChargeDetail.FAGetValue().ToString().Trim(), true);
                Support.AreNotEqual("", FastDriver.EditDisbursement.ReceivingBankABANumber.FAGetValue().ToString().Trim(), true);
                Support.AreNotEqual("", FastDriver.EditDisbursement.ReceivingBankName.FAGetValue().ToString().Trim(), true);
                Support.AreNotEqual("", FastDriver.EditDisbursement.BeneficiaryAccountNumber.FAGetValue().ToString().Trim(), true);
                Support.AreNotEqual("", FastDriver.EditDisbursement.BeneficiaryName.FAGetValue().ToString().Trim(), true);
                #endregion

                #region Verify the status change from pending to created when mandatory info is removed.
                Reports.TestStep = "Verify the status change from pending to created when mandatory info is removed.";
                // FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FAClick();
                FastDriver.EditDisbursement.ReceivingBankABANumber.Clear();
                FastDriver.BottomFrame.Save();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Created", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Status", TableAction.GetText).Message.Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Created", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Status", TableAction.GetText).Message.Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Created", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Status", TableAction.GetText).Message.Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Created", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Status", TableAction.GetText).Message.Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Status", TableAction.GetText).Message.Trim(), true);
                #endregion

                #region Scan a document of misc type and sec-wire out.
                FastDriver.DocumentRepository.UploadImgDoc("Escrow: Misc", "SEC-WireInstOut", "test");
                #endregion

                #region Select the wire, attach second documnet and validate the Voucher details.
                Reports.TestStep = "Select the wire.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.SelectSecondWireInstruction();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "verify voucher details and click on done.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Home Warranty:                                       17.53", FastDriver.EditDisbursement.VoucherChargeDetail.FAGetValue().ToString().Trim(), true);
                #endregion

                #region Disburse the Wire and Validate that Edit button is disabled after Disburse.
                Reports.TestStep = "Select the wire and click on Wire button.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();
                FastDriver.DisburseWires.SwitchToContentFrame();
                FastDriver.DisburseWires.Disburse.FAClick();

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the disbursed and verify that edit button is disabled.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                Support.AreEqual("false", FastDriver.ActiveDisbursementSummary.Wire.Enabled.ToString().ToLower().Trim(), true);

                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }

        }
        #endregion

        #region Test FMUC0037_REG0005

        /// <summary>
        /// FM3343_FM3344_FM3345_FM3362_FM4027_FM4028
        /// </summary>
        [TestMethod]
        public void FMUC0037_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM3343_FM3344_FM3345_FM3362_FM4027_FM4028";

                #region Data Setup
                var value = string.Empty;
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create more than 14 charges for a instance.
                Reports.TestStep = "Create more than 14 charges for a instance.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.FindGABcode("LEASE");
                FastDriver.LeaseDetail.Add16Charges();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Active Disb Summary and select the Pend Lease charge and click on Edit.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend Lease charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "35.52", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Enter the memo details and verify voucher details when  charges exceeds 14.
                Reports.TestStep = "Enter the memo details and verify voucher details when  charges exceeds 14.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.VoucherMemo.FASetText("Entering voucher memo");
                string s = FastDriver.EditDisbursement.VoucherChargeDetail.FAGetValue().ToString().Trim();
                Support.AreEqual("Description1:                                         2.22  Description2:                                         2.22\r\nDescription3:                                         2.22  Description4:                                         2.22\r\nDescription5:                                         2.22  Description6:                                         2.22\r\nDescription7:                                         2.22  Description8:                                         2.22\r\nDescription9:                                         2.22  Description10:                                        2.22\r\nDescription11:                                        2.22  Description12:                                        2.22\r\nDescription13:                                        2.22Total Other Charges                                                6.66", FastDriver.EditDisbursement.VoucherChargeDetail.FAGetValue().ToString().Trim(), true);
                #endregion

                #region Verify allow user update.
                Reports.TestStep = "Verify Allow user update.";
                FastDriver.EditDisbursement.VoucherChargeDetail.FASetText("Description1:2.22Description2:2.22\r\nDescription3:2.22Description4:2.22\r\nDescription5:2.22Description6:2.22\r\nDescription7:2.22Description8:2.22\r\nDescription9:2.22Description10:2.22\r\nDescription11:2.22Description12:2.22\r\nDescription13:2.22TotalOtherCharges6.66");
                FastDriver.BottomFrame.Save();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Description1:2.22Description2:2.22\r\nDescription3:2.22Description4:2.22\r\nDescription5:2.22Description6:2.22\r\nDescription7:2.22Description8:2.22\r\nDescription9:2.22Description10:2.22\r\nDescription11:2.22Description12:2.22\r\nDescription13:2.22TotalOtherCharges6.66", FastDriver.EditDisbursement.VoucherChargeDetail.FAGetValue().ToString().Trim(), true);
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }

        }
        #endregion

        #region Test FMUC0037_REG0006

        /// <summary>
        /// CreatingGABForwireInstruction_ES7610_ES13364_ES13365_ES13366_ES13367_ES13368_ES13369
        /// </summary>
        [TestMethod, DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void FMUC0037_REG0006()
        {
            try
            {
                Reports.TestDescription = "CreatingGABForwireInstruction_ES7610_ES13364_ES13365_ES13366_ES13367_ES13368_ES13369";

                #region Data Setup
                var value = string.Empty;
                #endregion

                #region ADM Login
                ADMLOGIN();
                #endregion

                #region Search a GAB in Address Book and click on Edit button.
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.SearchAddressBook("HUDLEASE03");
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction("ID Code", "HUDLEASE03", "ID Code", TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();
                #endregion

                #region Enter details and check e governance check box.
                Reports.TestStep = "Enter details and check e governance check box.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                if (FastDriver.BusPartyOrgSetUp.ABANumber.FAGetValue().ToString() == "")
                {
                    FastDriver.BusPartyOrgSetUp.ABANumber.FASetText("123456");
                }
                if (FastDriver.BusPartyOrgSetUp.BankName.FAGetValue().ToString() == "")
                {
                    FastDriver.BusPartyOrgSetUp.BankName.FASetText("First American Bank");
                }
                if (FastDriver.BusPartyOrgSetUp.BankAddress.FAGetValue().ToString() == "")
                {
                    FastDriver.BusPartyOrgSetUp.BankAddress.FASetText("3 First American Way");
                }
                if (FastDriver.BusPartyOrgSetUp.AccountNumber.FAGetValue().ToString() == "")
                {
                    FastDriver.BusPartyOrgSetUp.AccountNumber.FASetText("23456789");
                }
                #endregion

                #region Enter details and check e governance check box.
                Reports.TestStep = "Enter details and check e governance check box.";
                FastDriver.BusPartyOrgSetUp.DataGovernanceCertified.FASetCheckbox(true);
                FastDriver.BusPartyOrgSetUp.TicketNumber.FASetText("12345");
                string ABANumberFromADM = FastDriver.BusPartyOrgSetUp.ABANumber.FAGetValue().ToString().Trim();
                string BankNameFromADM = FastDriver.BusPartyOrgSetUp.BankName.FAGetValue().ToString().Trim();
                string BankAddressFromADM = FastDriver.BusPartyOrgSetUp.BankAddress.FAGetValue().ToString().Trim();
                string AccountNumberFromADM = FastDriver.BusPartyOrgSetUp.AccountNumber.FAGetValue().ToString().Trim();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Login to File Side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create Lease Instance
                Reports.TestStep = "Create lease instance";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Description1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("1.11");
                FastDriver.LeaseDetail.SellerCharge.FASetText("1.11");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Active Disb Summary and select the Pend charge and click on Edit, Validate instruction source for GAB.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "2.22", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "validate instruction source for GAB.";
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.SourceofwireIns.FASelectItem("From the Global Address Book - Certified");
                FastDriver.EditDisbursement.VerifyDataGovernanceImg();
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("");
                FastDriver.EditDisbursement.Refresh.FAClick();
                #endregion

                #region Verify for the refresh button after clearing the values.
                Reports.TestStep = "Verify for the refresh button after clearing the values.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(ABANumberFromADM, FastDriver.EditDisbursement.ReceivingBankABANumber.FAGetValue().ToString().Trim(), true);
                Support.AreEqual(BankNameFromADM, FastDriver.EditDisbursement.ReceivingBankName.FAGetValue().ToString().Trim(), true);
                FastDriver.EditDisbursement.VerifyDataGovernanceImg();
                #endregion

                #region Edit the bank details and click on save button.
                Reports.TestStep = "Edit the bank details and click on save button.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("987456");
                Support.AreEqual(BankNameFromADM, FastDriver.EditDisbursement.ReceivingBankName.FAGetValue().ToString().Trim(), true);
                FastDriver.EditDisbursement.VerifyDataGovernanceImg();
                FastDriver.BottomFrame.Save();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.VerifyBrokenImg();

                Reports.TestStep = "Select wire instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.SourceofwireIns.FAClick();
                Keyboard.SendKeys("From the Global Address Book - Certified");
                Keyboard.SendKeys(FAKeys.TabAway);
                Thread.Sleep(5000);
                // FastDriver.EditDisbursement.SourceofwireIns.FASelectItem("From the Global Address Book - Certified");
                string EWMessage = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Wire Details from the Global Address Book were changed.  Click Refresh or choose another Source of Wire Instructions to continue.", EWMessage, true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }

        }
        #endregion

        #region Test FMUC0037_REG0007
        [TestMethod, Obsolete]
        public void FMUC0037_REG0007()
        {
            Reports.TestDescription = @"ES7610_ES13364_ES13365_ES13366_ES13367_ES13368_ES13369 (Covered in REG0006).";
            Reports.StatusUpdate("ES7610_ES13364_ES13365_ES13366_ES13367_ES13368_ES13369 (Covered in REG0006).", true);
        }
        #endregion

        #region Test FMUC0037_REG0008

        /// <summary>
        /// ES13353_ES13354_ES13355_ES13356_ES13435_ES13357_ES13358_ES13359Approval
        /// </summary>
        [TestMethod, DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void FMUC0037_REG0008()
        {
            try
            {
                Reports.TestDescription = "ES13353_ES13354_ES13355_ES13356_ES13435_ES13357_ES13358_ES13359Approval";

                #region Data Setup
                var value = string.Empty;
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add home warranty charges.
                Reports.TestStep = "Add home warranty charge.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW2");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("17.53");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Convert to Wire
                FastDriver.DocumentRepository.UploadImgDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "17.53", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region Verify from document repository and click on save.
                Reports.TestStep = "Verify from document repository and click on save.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("From Document Repository", FastDriver.EditDisbursement.SourseOfWireInsLabel.FAGetText().ToString().Trim(), true);
                FastDriver.BottomFrame.Save();
                #endregion

                #region Login with another user and search the file

                Reports.TestStep = "Searrch for the file with user 1.";
                Reports.StatusUpdate("Search for the file with user 1.", true);

                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);

                
                Reports.TestStep = "Search the file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Thread.Sleep(5000);
                FastDriver.FileSearch.FindNow.FAClick();
                Thread.Sleep(10000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Click on The document Link and Close the Document and verify approved1 check box is enabled.
                Reports.TestStep = "Navigate to Active Disbursement summary and click on the pending charge, click on edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "17.53", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Wire Instruction Image.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ImageName.FAClick();

                Reports.StatusUpdate("Verify Image Load: Look for Screenshot", true);
                FastDriver.EditDisbursement.ImageCloseBtn.FAClick();

                Reports.TestStep = "Validate that Approve1 checkbox is enabled.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                if (FastDriver.EditDisbursement.Approve1.Enabled.ToString() == "True")
                {
                    Reports.StatusUpdate("Approve1 is enabled.", true);
                }
                #endregion

                #region Verify Approval1 Checkbox is disabled and don’t save the page.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "17.53", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verify Approval1 Checkbox is disabled";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                if (FastDriver.EditDisbursement.Approve1.Enabled.ToString() == "False")
                {
                    Reports.StatusUpdate("Approve1 is disabled.", true);
                }
                #endregion

                #region Approve the pending charge.
                FastDriver.EditDisbursement.ClickOnWireInstructionImageAndApprove("FirstApproval");
                #endregion

                #region Verify the Approved status.
                Reports.TestStep = "Verify the Approved status.";
                FastDriver.ActiveDisbursementSummary.Open();
                string WireStatus = FastDriver.ActiveDisbursementSummary.ApprovalStatus.GetAttribute("title").ToString(); // FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("#7", "17.53", "#4", TableAction.GetCell).Element.FindElement(By.Id("dgDisbSmry_1_Img1")).GetAttribute("title").ToString();
                Support.AreEqual("Approved", WireStatus, true);
                #endregion

                #region Split the approved charge and validate the same.
                Reports.TestStep = "Select the approved charge and click on split button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "split for twice and validate the same.";
                FastDriver.SplitDisbursement.SplitDistributionPercentage.FASetText("50.00" + FAKeys.Tab + FAKeys.Tab + FAKeys.Tab);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                FastDriver.SplitDisbursement.SplitDistributionPercentage1.FASetText("50.00" + FAKeys.Tab);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                Support.AreEqual("8.77", FastDriver.SplitDisbursement.SplitDistributionAmount0.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("8.76", FastDriver.SplitDisbursement.SplitDistributionAmount1.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }

        }
        #endregion

        #region Test FMUC0037_REG0009
        [TestMethod, Obsolete]
        public void FMUC0037_REG0009()
        {
            Reports.TestDescription = @"ES13353_ES13435_ES1337_ES13354_ES13355_ES13356_ES13357_ES13358_ES13359Approval (Covered in REG0008).";
            Reports.StatusUpdate("ES13353_ES13435_ES1337_ES13354_ES13355_ES13356_ES13357_ES13358_ES13359Approval (Covered in REG0008).", true);
        }
        #endregion

        #region Test FMUC0037_REG0010

        /// <summary>
        /// ES13360_ES13361_ES13362_ES13363_ES13436_ES13371_ES13437_ES13372_ES13373_ES13438_ES13374_1st Approval_2nd Approval.
        /// </summary>
        [TestMethod, DeploymentItem(@"Common\Support\JpegFile.jpg")]
        public void FMUC0037_REG0010()
        {
            try
            {
                Reports.TestDescription = "ES13360_ES13361_ES13362_ES13363_ES13436_ES13371_ES13437_ES13372_ES13373_ES13438_ES13374_1st Approval_2nd Approval.";

                #region Data Setup
                var HWbuyerCharge = "200,000,001.00";
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add home warranty charge more than 20 million.
                Reports.TestStep = "Add home warranty charge more than 20 million.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW2");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText(HWbuyerCharge);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Upload and save document
                FastDriver.DocumentRepository.UploadImgDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                #endregion

                #region Convert the charge to WIRE.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", HWbuyerCharge, "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region Login with user 1 and search the file

                Reports.TestStep = "Login with user 1 and search the file.";
                Reports.StatusUpdate("Login with user 1 and search the file.", true);

                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);

                Reports.TestStep = "Search the file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Thread.Sleep(5000);
                FastDriver.FileSearch.FindNow.FAClick();
                Thread.Sleep(10000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                #endregion

                #region Click on The document Link and Close the Document and verify approved1 check box is enabled
                Reports.TestStep = "Navigate to Active Disbursement summary and click on edit after selecting the pending charge.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", HWbuyerCharge, "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Wire Instruction Image.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ImageName.FAClick();

                Reports.StatusUpdate("Verify Image Load: Look for Screenshot", true);
                FastDriver.EditDisbursement.ImageCloseBtn.FAClick();

                Reports.TestStep = "Validate that Approve1 checkbox is enabled.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                if (FastDriver.EditDisbursement.Approve1.Enabled.ToString() == "True")
                {
                    Reports.StatusUpdate("Approve1 is enabled.", true);
                }
                #endregion

                #region Verify Approval1 Checkbox is disabled and don’t save the page.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", HWbuyerCharge, "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verify Approval1 Checkbox is disabled";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                if (FastDriver.EditDisbursement.Approve1.Enabled.ToString() == "False")
                {
                    Reports.StatusUpdate("Approve1 is disabled.", true);
                }
                #endregion

                #region
                FastDriver.EditDisbursement.ClickOnWireInstructionImageAndApprove("FirstApproval");
                #endregion

                #region Verify the Approved status.
                Reports.TestStep = "Verify the Approved status.";
                FastDriver.ActiveDisbursementSummary.Open();
                string WireStatus = FastDriver.ActiveDisbursementSummary.ApprovalStatus.GetAttribute("title").ToString(); // FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("#7", HWbuyerCharge, "#4", TableAction.GetCell).Element.FindElement(By.Id("dgDisbSmry_1_Img1")).GetAttribute("title").ToString();
                Support.AreEqual("Pre-Approved", WireStatus, true);
                #endregion

                #region Login with user 2 and search the file

                Reports.TestStep = "Login with user 2 and search the file.";
                Reports.StatusUpdate("Login with user 2 and search the file.", true);

                IISLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);

                Reports.TestStep = "Search the file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Thread.Sleep(5000);
                FastDriver.FileSearch.FindNow.FAClick();
                Thread.Sleep(10000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                #endregion

                #region Click on The document Link and Close the Document and verify approved1 check box is enabled
                Reports.TestStep = "Navigate to Active Disbursement summary and click on edit after selecting the pending charge.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", HWbuyerCharge, "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Wire Instruction Image.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ImageName.FAClick();

                Reports.StatusUpdate("Verify Image Load: Look for Screenshot", true);
                FastDriver.EditDisbursement.ImageCloseBtn.FAClick();

                Reports.TestStep = "Validate that Approve2 checkbox is enabled.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                if (FastDriver.EditDisbursement.Approval2.Enabled.ToString() == "True")
                {
                    Reports.StatusUpdate("Approve2 is enabled.", true);
                }
                #endregion

                #region Verify Approval1 Checkbox is disabled and don’t save the page.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", HWbuyerCharge, "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verify Approval2 Checkbox is disabled";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                if (FastDriver.EditDisbursement.Approval2.Enabled.ToString() == "False")
                {
                    Reports.StatusUpdate("Approve2 is disabled.", true);
                }
                #endregion

                #region
                FastDriver.EditDisbursement.ClickOnWireInstructionImageAndApprove("SecondApproval");
                #endregion

                #region Verify the Approved status.
                Reports.TestStep = "Verify the Approved status.";
                FastDriver.ActiveDisbursementSummary.Open();
                // string WireStatus1 = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("#7", HWbuyerCharge, "#4", TableAction.GetCell).Element.FindElement(By.Id("dgDisbSmry_1_Img1")).GetAttribute("title").ToString();
                string WireStatus1 = FastDriver.ActiveDisbursementSummary.ApprovalStatus.GetAttribute("title").ToString();
                Support.AreEqual("Approved", WireStatus1, true);
                #endregion

                #region Split the approved charge and validate the same.
                Reports.TestStep = "Select the approved charge and click on split button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "split for twice and validate the same.";
                FastDriver.SplitDisbursement.SplitDistributionPercentage.FASetText("50.00" + FAKeys.Tab + FAKeys.Tab + FAKeys.Tab);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                FastDriver.SplitDisbursement.SplitDistributionPercentage1.FASetText("50.00" + FAKeys.Tab);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                Support.AreEqual("100,000,000.50", FastDriver.SplitDisbursement.SplitDistributionAmount0.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("100,000,000.50", FastDriver.SplitDisbursement.SplitDistributionAmount1.FAGetValue().ToString().Trim(), true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }

        }
        #endregion

        #region Test FMUC0037_REG0011
        [TestMethod, Obsolete]
        public void FMUC0037_REG0011()
        {
            Reports.TestDescription = @"ES13360_ES13361_ES13362_ES13363_ES13436_ES13371_ES13437_ES13372_ES13373_ES13438_ES13374_1st Approval (Covered in REG0010).";
            Reports.StatusUpdate("ES13360_ES13361_ES13362_ES13363_ES13436_ES13371_ES13437_ES13372_ES13373_ES13438_ES13374_1st Approval (Covered in REG0010).", true);
        }
        #endregion

        #region Test FMUC0037_REG0012
        [TestMethod, Obsolete]
        public void FMUC0037_REG0012()
        {
            Reports.TestDescription = @"ES13360_ES13361_ES13362_ES13363_ES13436_ES13371_ES13437_ES13372_ES13373_ES13438_ES13374_1st Approval (Covered in REG0012).";
            Reports.StatusUpdate("ES13360_ES13361_ES13362_ES13363_ES13436_ES13371_ES13437_ES13372_ES13373_ES13438_ES13374_1st Approval (Covered in REG0012).", true);
        }
        #endregion

        #region Test FMUC0037_REG0013

        /// <summary>
        /// ES13380
        /// </summary>
        [TestMethod]
        public void FMUC0037_REG0013()
        {
            try
            {
                Reports.TestDescription = "ES13380";

                #region Data Setup
                var value = string.Empty;
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add home warranty charges.
                Reports.TestStep = "Add home warranty charge.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW2");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("17.53");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Convert the charge to WIRE.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "17.53", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify for No Document error message.
                Reports.TestStep = "Verify for No Document error message.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Select Wire Instructions", true, 20);
                FastDriver.SelectWireInstructionsDlg.SwitchToDialogContentFrame();
                Support.AreEqual("No Documents found in Document Repository", FastDriver.SelectWireInstructionsDlg.NoDocumentsWarning.FAGetText().ToString().Trim(), true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }

        }
        #endregion

        #region Test FMUC0037_REG0014

        /// <summary>
        /// EWC1_2
        /// </summary>
        [TestMethod]
        public void FMUC0037_REG0014()
        {
            try
            {
                Reports.TestDescription = "EWC1_2";

                #region Data Setup
                var value = string.Empty;
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add home warranty charges.
                Reports.TestStep = "Add home warranty charge.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW2");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("17.53");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Active Disb Summary and select the Pend charge and click on Split.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Split.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "17.53", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                #endregion

                #region Enter split amounts such as the sum is greater than master amount, validate the message.
                Reports.TestStep = "Enter split amounts such as the sum is greater than master amount.";
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("15.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                Thread.Sleep(5000);
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FASetText("8.76");
                Keyboard.SendKeys(FAKeys.TabAway);
                Thread.Sleep(5000);
                Support.AreEqual("Total of split amount cannot be greater than master amount.", FastDriver.WebDriver.HandleDialogMessage(true, true).ToString().Trim(), true);
                #endregion

                #region Enter split amounts such as the sum is lesser than master amount, validate the message.
                Reports.TestStep = "Enter split amounts such as the sum is greater than master amount.";
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FAClick();
                FastDriver.SplitDisbursement.Remove.FAClick();
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("5.00" + FAKeys.Tab);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Thread.Sleep(5000);
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FASetText("8.76");
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Master check amount is not fully distributed; please check.", FastDriver.WebDriver.HandleDialogMessage(true, true).ToString().Trim(), true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }

        }
        #endregion

        #region Test FMUC0037_REG0015

        /// <summary>
        /// ES14921 : Setup for Threshold amount._ ES14921_ES14922_ES14923_ES14924_ Field_Definition_Approve the wire when Threshold amount is greater than the defined Threshold amount.
        /// </summary>
        [TestMethod, DeploymentItem(@"Common\Support\Hello.pdf")]
        public void FMUC0037_REG0015()
        {
            try
            {
                Reports.TestDescription = "ES14921_Setup for Threshold amount_ ES14921_ES14922_ES14923_ES14924_ Field_Definition_Approve the wire when Threshold amount is greater than the defined Threshold amount.";

                #region Data Setup
                var value = string.Empty;
                ThresholdAmountsParameters amounts = new ThresholdAmountsParameters()
                {
                    Residential = "10",
                    Commercial = "20",
                    NewHomeSubdivision = "30",
                    NewHome = "40",
                    Subdivision = "50",
                    Default = "60",
                    TimeShare = "70",
                    DefaultResidential = "80",
                    DefaultCommercial = "90",
                };
                #endregion

                #region ADM Login
                ADMLOGIN();
                #endregion

                #region To Navigate to Threshold Amount Setup screen, Enter the Threshold amount lower than the amount in File side.
                Reports.TestStep = "To Navigate to Threshold Amount Setup screen.";
                FastDriver.ThresholdAmountSetup.Open();

                Reports.TestStep = "Enter the Threshold amount lower than the amount in File side.";
                FastDriver.ThresholdAmountSetup.SetThresholdAmounts(amounts);
                FastDriver.BottomFrame.Done();
                #endregion

                #region To Navigate to Threshold Amount Setup screen and validate the amounts.
                Reports.TestStep = "To Navigate to Threshold Amount Setup screen.";
                FastDriver.ThresholdAmountSetup.Open();
                Reports.TestStep = "Vaildate the threshold amounts.";
                FastDriver.ThresholdAmountSetup.VerifyThresholdAmounts(amounts);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create a new Utility Instance
                Reports.TestStep = "Create a new Utility Instance.";
                FastDriver.UtilityDetail.Open();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: "Utility Charge", buyerCharge: 50.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Uploda doc in Document Repository.
                UploadPDFDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                #endregion

                #region Convert to Wire.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region AF 8: Approve Wire with another user.

                Reports.TestStep = "Approve Wire with another user.";
                Reports.StatusUpdate("Approve Wire with another user.", true);

                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);

                Reports.TestStep = "Enter file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.SwitchToContentFrame();
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Thread.Sleep(5000);
                FastDriver.FileSearch.FindNow.FAClick();
                Thread.Sleep(10000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.ClickOnWireInstructionImageAndApprove("FirstApproval");
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }

        }
        #endregion

        #region Test FMUC0037_REG0016
        [TestMethod, Obsolete]
        public void FMUC0037_REG0016()
        {
            Reports.TestDescription = @"ES14921_ES14922_ES14923_ES14924 (Covered in REG0015).";
            Reports.StatusUpdate("ES14921_ES14922_ES14923_ES14924 (Covered in REG0015).", true);
        }
        #endregion

        #region Test FMUC0037_REG0017
        [TestMethod, Obsolete]
        public void FMUC0037_REG0017()
        {
            Reports.TestDescription = @"Field_Definition_Approve the wire when Threshold amount is greater than the defined Threshold amount. (Covered in REG0015).";
            Reports.StatusUpdate("Field_Definition_Approve the wire when Threshold amount is greater than the defined Threshold amount. (Covered in REG0015).", true);
        }
        #endregion

        #region Test FMUC0037_REG0018

        /// <summary>
        /// : Change the Threshold amount less than the Threshold amount established for file's Business Segment_ES14921 : When Wire Amount to be approved is less than or equal to the define Threshold amount_Approve the wire when amount is less than the defined Threshold amount.
        /// </summary>ES14921
        [TestMethod, DeploymentItem(@"Common\Support\Hello.pdf")]
        public void FMUC0037_REG0018()
        {
            try
            {
                Reports.TestDescription = "ES14921_Change the Threshold amount less than the Threshold amount established for files Business Segment_When Wire Amount to be approved is less than or equal to the define Threshold amount_Approve the wire when amount is less than the defined Threshold amount.";

                #region Data Setup
                var value = string.Empty;
                ThresholdAmountsParameters amounts = new ThresholdAmountsParameters()
                {
                    Residential = "100",
                    Commercial = "200",
                    NewHomeSubdivision = "300",
                    NewHome = "400",
                    Subdivision = "500",
                    Default = "600",
                    TimeShare = "700",
                    DefaultResidential = "800",
                    DefaultCommercial = "900",
                };
                #endregion

                #region ADM Login
                ADMLOGIN();
                #endregion

                #region To Navigate to Threshold Amount Setup screen, Enter the Threshold amount lower than the amount in File side.
                Reports.TestStep = "To Navigate to Threshold Amount Setup screen.";
                FastDriver.ThresholdAmountSetup.Open();

                Reports.TestStep = "Enter the Threshold amount lower than the amount in File side.";
                FastDriver.ThresholdAmountSetup.SetThresholdAmounts(amounts);
                FastDriver.BottomFrame.Done();
                #endregion

                #region To Navigate to Threshold Amount Setup screen and validate the amounts.
                Reports.TestStep = "To Navigate to Threshold Amount Setup screen.";
                FastDriver.ThresholdAmountSetup.Open();
                Reports.TestStep = "Vaildate the threshold amounts.";
                FastDriver.ThresholdAmountSetup.VerifyThresholdAmounts(amounts);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Create a new Utility Instance
                Reports.TestStep = "Create a new Utility Instance.";
                FastDriver.UtilityDetail.Open();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: "Utility Charge", buyerCharge: 50.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Uploda doc in Document Repository.
                UploadPDFDoc("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
                #endregion

                #region Convert to Wire.
                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region AF 8: Approve Wire with another user.

                Reports.TestStep = "Approve Wire with another user.";
                Reports.StatusUpdate("Approve Wire with another user.", true);

                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);

                Reports.TestStep = "Enter file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.SwitchToContentFrame();
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Thread.Sleep(5000);
                FastDriver.FileSearch.FindNow.FAClick();
                Thread.Sleep(10000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.ClickOnWireInstructionImageAndApprove("FirstApproval");
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }
        }
        #endregion

        #region Test FMUC0037_REG0019
        [TestMethod, Obsolete]
        public void FMUC0037_REG0019()
        {
            Reports.TestDescription = @"ES14921 : When Wire Amount to be approved is less than or equal to the define Threshold amount . (Covered in REG0018).";
            Reports.StatusUpdate("ES14921 : When Wire Amount to be approved is less than or equal to the define Threshold amount . (Covered in REG0018).", true);
        }
        #endregion

        #region Test FMUC0037_REG0020
        [TestMethod, Obsolete]
        public void FMUC0037_REG0020()
        {
            Reports.TestDescription = @"Approve the wire when amount is less than the defined Threshold amount. (Covered in REG0018).";
            Reports.StatusUpdate("Approve the wire when amount is less than the defined Threshold amount. (Covered in REG0018).", true);
        }
        #endregion

        #region Test FMUC0037_REG0021_PH
        [TestMethod, Obsolete]
        public void FMUC0037_REG0021_PH()
        {
            Reports.TestDescription = @"FM4029_ES9734_ES7611_ES9924_ES10008_ES10923_ES10924_Ewc3: These BRs Cant Be Automated Do manually..";
            Reports.StatusUpdate("FM4029_ES9734_ES7611_ES9924_ES10008_ES10923_ES10924_Ewc3: These BRs Cant Be Automated Do manually.", false);
        }
        #endregion

        #region Test FMUC0037_REG0022

        /// <summary>
        /// INC2163370 - [Bug] - Republic - Disbursement Charge Detail does not update once Disburse As is changed to Wire
        /// </summary>ES14921
        [TestMethod]
        public void FMUC0037_REG0022()
        {
            try
            {
                Reports.TestDescription = "INC2163370_Validate the change in Disbursment Charge Detail once DisburseAs is changed to Wire.";

                #region Data Setup
                var value = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add multiple Fees in File Fee Screen
                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "50.00");
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "150.00");

                Reports.TestStep = "Enter second fee in Title and escrow.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Buyer Charge", TableAction.SetText, "100.00");
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Seller Charge", TableAction.SetText, "200.00");
                #endregion

                #region split the fees between the payees in the Split Fees section
                Reports.TestStep = "Navigate to Split Fee Disbursements screen and add a payee.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FABFirstCheckBox.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                int PayeeCount = FastDriver.SplitFeeDisbursements.PayeesSummary.GetRowCount();

                Reports.TestStep = "Valdiate Payeed is added in Split Fee Disbursement Screen.";
                Support.AreEqual("2", PayeeCount.ToString().Trim(), true);

                Reports.TestStep = "Split the fees between the payees in the Split Fees section.";
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: "Buyer1Firstname Buyer1Lastname", splitPer: "50.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Change check disbursement to Wire and fill the mandatory details.
                Reports.TestStep = "Navigate to the Active Disbursement Summary screen and select the disbursement.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("150.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Amount", TableAction.GetText).Message.ToString().Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Funds", TableAction.Click);

                Reports.TestStep = "Edit the disbursement.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Escrow Fee:                                         150.00", FastDriver.EditDisbursement.VoucherChargeDetail.FAGetValue().ToString().Trim(), true);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Go back to Fee Entry and edit the charge for the selected Disbursement and save.
                Reports.TestStep = "Go back to Fee Entry and edit the charge for the selected Disbursement and save.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Escrow Fee", "Buyer Charge", TableAction.Click);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Escrow Fee", "Buyer Charge", TableAction.SendKeys, "200.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Escrow Fee", "Seller Charge", TableAction.Click);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Escrow Fee", "Seller Charge", TableAction.SendKeys, "300.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Validate the changed amount for disbursement.
                Reports.TestStep = "Validate that amount column is updated to latest edited value in Active Disbursement Summary screen.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                Support.AreEqual("250.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Amount", TableAction.GetText).Message.ToString().Trim(), true);

                Reports.TestStep = "Validate that the Charge Detail displays the updated charges.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Escrow Fee:                                         250.00", FastDriver.EditDisbursement.VoucherChargeDetail.FAGetValue().ToString().Trim(), true);
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }
        }
        #endregion

        #region Test FMUC0037_REG0023

        /// <summary>
        /// INC2332384 - [Bug] - Republic - Edited Charge Detail is not saving in Pending Check
        /// </summary>ES14921
        [TestMethod]
        public void FMUC0037_REG0023()
        {
            try
            {
                Reports.TestDescription = "INC2332384_Validate that edited charge details are saved for pending check.";

                #region Data Setup
                var value = string.Empty;
                #endregion

                #region IIS Login
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Add multiple Fees in File Fee Screen
                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "50.00");
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "150.00");

                Reports.TestStep = "Enter second fee in Title and escrow.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Buyer Charge", TableAction.SetText, "100.00");
                FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "Escrow Fee", "Seller Charge", TableAction.SetText, "200.00");
                #endregion

                #region split the fees between the payees in the Split Fees section
                Reports.TestStep = "Navigate to Split Fee Disbursements screen and add a payee.";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FABFirstCheckBox.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Split the fees between the payees in the Split Fees section.";
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 1, payeeName: "Buyer1Firstname Buyer1Lastname", splitPer: "50.00");
                FastDriver.SplitFeeDisbursements.PerformSplitForFee(feeNumber: 2, payeeName: "Buyer1Firstname Buyer1Lastname", splitPer: "50.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Change the charge detail and validate the changes.
                Reports.TestStep = "Navigate to the Active Disbursement Summary screen and select the disbursement.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Funds", TableAction.Click);

                Reports.TestStep = "Navigate to edit disbursement and validate the orginal charge details.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("New Home Rate (Title Only):                         100.00  Escrow Fee:                                         150.00", FastDriver.EditDisbursement.VoucherChargeDetail.FAGetValue().ToString().Trim(), true);

                Reports.TestStep = "Change the charge details and save.";
                FastDriver.EditDisbursement.VoucherChargeDetail.FASetText("New Home Rate (Title Only):                         100.00  Escrow Fee:                                         150.00, Updating the Charge Detail.");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to edit disbursement and validate the updated charge details.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("New Home Rate (Title Only):                         100.00  Escrow Fee:                                         150.00, Updating the Charge Detail.", FastDriver.EditDisbursement.VoucherChargeDetail.FAGetValue().ToString().Trim(), true);
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case failed because " + e.Message);
            }
        }
        #endregion

        #endregion REG

        #region SRT-ServReq

        //Team                           :  SRT-Team2
        //Iteration                      :  r08
        //UserStory                      :  User Story 814188: [ROOT CAUSE] 10.4 Triage - FAST - Edit Disbursement Screen, Note Fields (1-4); typing abnormalities
        // TestCase                      :  829335 and 850033
        //Appended By/ Created By        :  Diego Hilario

        #region FMUC0037_REG0024

        [TestMethod]
        public void FMUC0037_REG0024()
        {
            try
            {
                #region DataSetup
                DepositParameters deposit = new DepositParameters()
                {
                    Amount = 500,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    ReceivedFrom = "Buyer"
                };
                #endregion

                Reports.TestDescription = "TC_829335_To Verify US#814188: Note Fields (1-4) typing abnormalities in Edit Disbursement screen";
                Reports.TestStep = "Login to FAST IIS";
                IISLOGIN();

                Reports.TestStep = "Create a basic file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Deposit in Escrow screen";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Fill Required fields to perform a deposit and click on Save button. Click Cancel on print message dialog";
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.SaveandCancleMessage();

                Reports.TestStep = "Navigate to Active Disbursement screen";
                FastDriver.ActiveDisbursementSummary.Open();

                Reports.TestStep = "Select the created deposit and click on Edit button";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "On Disbursement Details section, select Wire in Disburse As dropdown list";
                FastDriver.EditDisbursement.DisburseAs.FASelectItemBySendingKeys("Wire");

                CheckNoteFields(FastDriver.EditDisbursement.BeneficiaryNote1);
                CheckNoteFields(FastDriver.EditDisbursement.BeneficiaryNote2);
                CheckNoteFields(FastDriver.EditDisbursement.BeneficiaryNote3);
                CheckNoteFields(FastDriver.EditDisbursement.BeneficiaryNote4);

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        #endregion

        #region FMUC0037_REG0025

        [TestMethod]
        public void FMUC0037_REG0025()
        {
            try
            {
                #region DataSetup
                DepositParameters deposit = new DepositParameters()
                {
                    Amount = 500,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    ReceivedFrom = "Buyer"
                };
                #endregion

                Reports.TestDescription = "TC_850033_To Verify US#814188: Note Fields (1-4) typing abnormalities in Edit Disbursement screen";
                Reports.TestStep = "Login to FAST IIS";
                IISLOGIN();

                Reports.TestStep = "Create a basic file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.Buyers[0].Type = "Individual";
                fileRequest.File.Buyers[0].FirstName = "Buyer1FirstName";
                fileRequest.File.Buyers[0].LastName = "Buyer1LastName";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Deposit in Escrow screen";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Fill Required fields to perform a deposit and click on Save button. Click Cancel on print message dialog";
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.SaveandCancleMessage();

                Reports.TestStep = "Navigate to Active Disbursement screen";
                FastDriver.ActiveDisbursementSummary.Open();

                Reports.TestStep = "Select the created deposit and click on Edit button";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "On Disbursement Details section, select Wire in Disburse As dropdown list";
                FastDriver.EditDisbursement.DisburseAs.FASelectItemBySendingKeys("Wire");
                
                CheckNoteFields(FastDriver.EditDisbursement.BeneficiaryNote1, FastDriver.EditDisbursement.Note1Button);
                CheckNoteFields(FastDriver.EditDisbursement.BeneficiaryNote2, FastDriver.EditDisbursement.Note2Button);
                CheckNoteFields(FastDriver.EditDisbursement.BeneficiaryNote3, FastDriver.EditDisbursement.Note3Button);
                CheckNoteFields(FastDriver.EditDisbursement.BeneficiaryNote4, FastDriver.EditDisbursement.Note4Button);

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        #endregion

        //Team                           :  SRT-Team2
        //Iteration                      :  r10
        //UserStory                      :  User Story 833339:[ROOT CAUSE] 10.4 Triage - FAST - Edit Disbursement Screen, Reset Button Defect
        // TestCase                      :  829381
        //Appended By/ Created By        :  Diego Hilario

        [TestMethod, DeploymentItem(@"Common\Support\Hello.pdf")]
        public void FMUC0037_REG0026()
        {
            try
            {
                Reports.TestDescription = "To Verify US#833339- Edit Disbursement screen Reset button behavior";

                Reports.TestStep = "Login to FAST IIS";
                IISLOGIN();

                Reports.TestStep = "Create a basic file";
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository and add a Wire Instruction document by clicking on Upload button and selecting Document Type as 'Escrow: Misc' and Document Name as 'SEC-WireInstOut'";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.Upload.FAClick();
                FastDriver.UploadDocumentDlg.WaitForScreenToLoad();
                FastDriver.UploadDocumentDlg.UploadFile(Reports.DEPLOYDIR + @"\Hello.pdf");
                FastDriver.UploadDocumentDlg.Upload.FAClick();
                FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Misc");
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem("SEC-WireInstOut");
                FastDriver.SaveDocumentDlg.Ok.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.NoTitleWindow, false);

                FastDriver.DocumentRepository.WaitForScreenToLoad();

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.DocumentRepository.Open();
                    return FastDriver.DocumentRepository.DocumentsTable.StringExistOnTable("SEC-WireInstOut");
                }, timeout: 60, idleInterval: 10);

                Reports.TestStep = "Navigate to Deposit in Escrow";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Fill required fields to perform a deposit and click on Save. Click Cancel button on print message dialog ";
                DepositParameters deposit = new DepositParameters()
                {
                    Amount = 500,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    ReceivedFrom = "Buyer"
                };
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.SaveandCancleMessage();

                Reports.TestStep = "Navigate to Active Disbursement screen";
                FastDriver.ActiveDisbursementSummary.Open();

                Reports.TestStep = "Select the created deposit and click on Edit button";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Enter random text on 'Reference' text box";
                FastDriver.EditDisbursement.Reference.FASetText("Testing");
                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Ensure Reset button is enabled";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual(true, FastDriver.BottomFrame.btnReset.IsEnabled(), "Verifying Reset button is enabled");


                Reports.TestStep = "Click on the Reset button";
                FastDriver.BottomFrame.Reset();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Ensure Reset button is disabed";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual(false, FastDriver.BottomFrame.btnReset.IsEnabled(), "Verifying Reset button is disabled");

                Reports.TestStep = "Ensure text enetered in Reference field is cleared";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(string.Empty, FastDriver.EditDisbursement.Reference.FAGetText(), "Verifying Reference textbox is empty");

                Reports.TestStep = "Select Wire in Disburse As dropdown menu";
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Ensure Reset button is enabled";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual(true, FastDriver.BottomFrame.btnReset.IsEnabled(), "Verifying Reset button is enabled");

                Reports.TestStep = "Click on Save button";
                FastDriver.BottomFrame.Save();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Ensure Reset button is disabled";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual(false, FastDriver.BottomFrame.btnReset.IsEnabled(), "Verifying Reset button is disabled");

                Reports.TestStep = "Enter random text on any of the fields under Wire Details section (for ex. Information textbox)";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("Testing");
                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Ensure Reset button is enabled";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual(true, FastDriver.BottomFrame.btnReset.IsEnabled(), "Verifying Reset button is enabled");

                Reports.TestStep = "Click on the Reset button";
                FastDriver.BottomFrame.Reset();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Ensure Reset button is disabed";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual(false, FastDriver.BottomFrame.btnReset.IsEnabled(), "Verifying Reset button is disabled");

                Reports.TestStep = "Ensure random text entered on step __ is cleared";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(string.Empty, FastDriver.EditDisbursement.ReceivingBankAddress.FAGetText(), "Verifying ReceivingBankAddress textbox is empty");

                Reports.TestStep = "Ensure 'Wire' option is selected in Disburse As dropdown menu";
                Support.AreEqual(true, FastDriver.EditDisbursement.DisburseAs.FAGetSelectedItem().Clean().Contains("Wire"), "Verifying Wire option is still selected on Disburse As dropdown menu");

                Reports.TestStep = "Click on '[...]' (Note Details) for any of the notes (for ex. Note 1)";
                FastDriver.EditDisbursement.Note1Button.FAClick();
                FastDriver.BeneficiaryNoteDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Select any of the Note Details options and click on Done (for ex. File no.)";
                FastDriver.BeneficiaryNoteDetailsDlg.DetailsTable.PerformTableAction(2, "File No.", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.BeneficiaryNote1.FAGetText().Contains(fileNumber.ToString());

                Reports.TestStep = "Ensure Reset button is enabled";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual(true, FastDriver.BottomFrame.btnReset.Enabled, "Verifying Reset button is enabled");

                Reports.TestStep = "Click on the Reset button";
                FastDriver.BottomFrame.Reset();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Ensure text entered in the selected Note on step __ is cleared";
                Support.AreEqual(string.Empty, FastDriver.EditDisbursement.BeneficiaryNote1.FAGetText(), "Verifying BeneficiaryNote1 textbox is empty");

                Reports.TestStep = "Click on Add button, select the previously created documen and click on Done";
                FastDriver.EditDisbursement.Add.FAClick();
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.DocumentsTable.PerformTableAction(3, "SEC-WireInstOut", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.EditDisbursement.WireInstructionTable.StringExistOnTable("SEC-WireInstOut"), "Verifying the wire instruction document is added");


                Reports.TestStep = "Ensure Reset button is enabled";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual(true, FastDriver.BottomFrame.btnReset.IsEnabled(), "Verifying Reset button is enabled");

                Reports.TestStep = "Click on the Reset button";
                FastDriver.BottomFrame.Reset();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Ensure the added document is cleared";
                Support.AreEqual(false, FastDriver.EditDisbursement.WireInstructionTable.StringExistOnTable("SEC-WireInstOut"), "Verifying the added document is removed");

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        #endregion

        #region PrivateMethods

        private void ValidateRecalOfSplitamount()
        {
            FastDriver.SplitDisbursement.WaitForScreenToLoad();
            FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(5, 1, TableAction.Click);
            FastDriver.SplitDisbursement.Remove.FAClick();
            FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(4, 1, TableAction.Click);
            FastDriver.SplitDisbursement.WaitForScreenToLoad();
            string AmtRemaining = FastDriver.SplitDisbursement.AmountRemaining.FAGetText().ToString().Trim();
            Support.AreNotEqual("0.00", AmtRemaining, true);

            int SDRowCount3 = FastDriver.SplitDisbursement.SplitDisbTable.GetRowCount();
            FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(SDRowCount3, 2, TableAction.Click);
            Keyboard.SendKeys(FAKeys.TabAway);
            Thread.Sleep(5000);
            int SDRowCount4 = FastDriver.SplitDisbursement.SplitDisbTable.GetRowCount();
            FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(SDRowCount4, 2, TableAction.SetText, AmtRemaining);
            FastDriver.BottomFrame.Save();
            try
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.NoTitleWindow, false);
            }
            catch (TimeoutException)
            {
                Reports.StatusUpdate("Saving... NoTitle window has closed fast.", true);
            }
            FastDriver.SplitDisbursement.WaitForScreenToLoad();
            string LastSplit = FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(SDRowCount4, 2, TableAction.GetText).Message.ToString().Trim();
            string SecondLastSplit = FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(SDRowCount4 - 1, 2, TableAction.GetText).Message.ToString().Trim(); ;
            if ((LastSplit == "200.75") && (SecondLastSplit == "200.73"))
            {
                Reports.StatusUpdate("Adjust Remaining Amount Field is successfull when one of the split row is removed.", true);
            }
            else
            {
                Reports.StatusUpdate("Adjust Remaining Amount Field is not successfull when one of the split row is removed.", false);
            }
            FastDriver.BottomFrame.Save();
        }

        private void VerifyLastSplitAndAllPercentage()
        {
            int SDRowCount2 = FastDriver.SplitDisbursement.SplitDisbTable.GetRowCount();
            for (int iterationCount = 2; iterationCount <= SDRowCount2; iterationCount++)
            {
                if (iterationCount == SDRowCount2)
                {
                    Support.AreEqual("200.73", FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(iterationCount, 2, TableAction.GetText).Message.Trim(), true);
                }
                else
                {
                    Support.AreEqual("200.75", FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(iterationCount, 2, TableAction.GetText).Message.Trim(), true);
                }
            }
            Reports.TestStep = "Validate that the percentage remains same across all the splits";
            for (int iterationCount = 2; iterationCount <= SDRowCount2; iterationCount++)
            {
                Support.AreEqual("20.00", FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(iterationCount, 1, TableAction.GetInputValue).Message.Trim(), true);
            }
        }

        private void IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            if (UserName == null)
            {
                UserName = UserName ?? AutoConfig.UserName;
            }
            if (Password == null)
            {
                Password = Password ?? AutoConfig.UserPassword;
            }
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        public void ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);

        }

        private void UploadPDFDoc(string docType, string docName, string addtlInfo)
        {
            Reports.TestStep = "Navigate to Doc Repository and Click on Upload.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
            FastDriver.DocumentRepository.Upload.FAClick();

            Reports.TestStep = "Browse document and upload it (jpg).";
            if (!((Reports.DEPLOYDIR + "\\Hello.pdf").ToString() == "True"))
            {
                Support.GetEmbeddedImages("AutoSupport", "support.Hello.pdf", Reports.DEPLOYDIR + "\\Hello.pdf");
            }
            string FilePath = Reports.DEPLOYDIR + "\\Hello.pdf";
            FastDriver.UploadDocumentDlg.UploadFile(FilePath);

            Reports.TestStep = "Save Scanned doc,entering Name so that it will appear in Edit Disb Screen.";
            FastDriver.SaveDocumentDlg.SaveDocument(docType, docName, addtlInfo);
            try
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.NoTitleWindow, false);
            }
            catch (TimeoutException)
            {
                Reports.StatusUpdate("Saving... NoTitle window has closed fast.", true);
            }
        }

        private void EnterFeeInTitleEscrowTab()
        {
            Reports.TestStep = "Enter first fee in Title and escrow.";
            FastDriver.FileFees.Open();
            FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
            FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99");
            FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99");
        }

        private void CheckNoteFields(IWebElement noteField, IWebElement elipseButton = null)
        {
            if (elipseButton == null)
            {
                Reports.TestStep = "On Wire Details section, enter 'Edit Disbursement screen notes' in Note textbox";
                noteField.FASetText("Edit Disbursement screen notes");

                Reports.TestStep = "Perform Keyboard Action'{HOME}'";
                Keyboard.SendKeys("{HOME}");

                Reports.TestStep = "Perform Keyboard Action '{RIGHT CURSOR ARROW}'";
                Keyboard.SendKeys("{RIGHT}");

                Reports.TestStep = "Perform Keyboard Action '{BACKSPACE}'";
                Keyboard.SendKeys("\b");
                Support.AreEqual("dit Disbursement screen notes", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'dit Disbursement screen notes'");

                Reports.TestStep = "Enter text 'E'";
                Keyboard.SendKeys("E");
                Support.AreEqual("Edit Disbursement screen notes", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'Edit Disbursement screen notes'");

                Reports.TestStep = "Perform Keyboard Action '{DELETE}' ";
                Keyboard.SendKeys("{DELETE}");
                Support.AreEqual("Eit Disbursement screen notes", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'Eit Disbursement screen notes'");

                Reports.TestStep = "Enter text 'd'";
                Keyboard.SendKeys("d");
                Support.AreEqual("Edit Disbursement screen notes", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'Edit Disbursement screen notes'");

                Reports.TestStep = "Perform Keyboard Action '{SPACE}'";
                Keyboard.SendKeys(" ");
                Support.AreEqual("Ed it Disbursement screen notes", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'Ed it Disbursement screen notes'");

                Reports.TestStep = "Perform Keyboard Action '{LEFT CURSOR ARROW}' ";
                Keyboard.SendKeys("{LEFT}");

                Reports.TestStep = "Enter text 'e'";
                Keyboard.SendKeys("e");
                Support.AreEqual("Ede it Disbursement screen notes", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'Ede it Disbursement screen notes'");

                Reports.TestStep = "Perform Keyboard Action {LEFT CURSOR ARROW}' two times while holding SHIFT key";
                Keyboard.SendKeys("+({LEFT}{LEFT})");

                Reports.TestStep = "Enter text 'D'";
                Keyboard.SendKeys("D");
                Support.AreEqual("ED it Disbursement screen notes", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'ED it Disbursement screen notes'");

                Reports.TestStep = "Perform Keyboard Acton '{END}' and enter text 'R'";
                Keyboard.SendKeys("{END}");
                Keyboard.SendKeys("R");
                Support.AreEqual("ED it Disbursement screen notesR", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'ED it Disbursement screen notesR");
            }

            else
            {
                Reports.TestStep = "On Wire Details section, click on ellipsis button for Note 1 field";
                elipseButton.FAClick();
                FastDriver.BeneficiaryNoteDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Select Buyer checkbox and click on Done";
                FastDriver.BeneficiaryNoteDetailsDlg.DetailsTable.PerformTableAction(2, "Buyer", 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Buyer1FirstName Buyer1LastName", noteField.FAGetValue().Clean().ToString(), "Verifying text is buyer's name");

                Reports.TestStep = "Place cursor at the end of the added text for the corresponding Note field";
                noteField.FAClick();
                Keyboard.SendKeys("{RIGHT}");

                Reports.TestStep = "Perform Keyboard Action'{HOME}'";
                Keyboard.SendKeys("{HOME}");

                Reports.TestStep = "Perform Keyboard Action '{RIGHT CURSOR ARROW}'";
                Keyboard.SendKeys("{RIGHT}");

                Reports.TestStep = "Perform Keyboard Action '{BACKSPACE}'";
                Keyboard.SendKeys("\b");
                Support.AreEqual("uyer1FirstName Buyer1LastName", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'uyer1FirstName Buyer1LastName'");

                Reports.TestStep = "Enter text 'B'";
                Keyboard.SendKeys("B");
                Support.AreEqual("Buyer1FirstName Buyer1LastName", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'Buyer1FirstName Buyer1LastName'");

                Reports.TestStep = "Perform Keyboard Action '{DELETE}' ";
                Keyboard.SendKeys("{DELETE}");
                Support.AreEqual("Byer1FirstName Buyer1LastName", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'Byer1FirstName Buyer1LastName'");

                Reports.TestStep = "Enter text 'u'";
                Keyboard.SendKeys("u");
                Support.AreEqual("Buyer1FirstName Buyer1LastName", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'Buyer1FirstName Buyer1LastName'");

                Reports.TestStep = "Perform Keyboard Action '{SPACE}'";
                Keyboard.SendKeys(" ");
                Support.AreEqual("Bu yer1FirstName Buyer1LastName", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'Bu yer1FirstName Buyer1LastName'");

                Reports.TestStep = "Perform Keyboard Action '{LEFT CURSOR ARROW}' ";
                Keyboard.SendKeys("{LEFT}");

                Reports.TestStep = "Enter text 'e'";
                Keyboard.SendKeys("e");
                Support.AreEqual("Bue yer1FirstName Buyer1LastName", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'Bue yer1FirstName Buyer1LastName'");

                Reports.TestStep = "Perform Keyboard Action {LEFT CURSOR ARROW}' two times while holding SHIFT key";
                Keyboard.SendKeys("+({LEFT}{LEFT})");

                Reports.TestStep = "Enter text 'U'";
                Keyboard.SendKeys("U");
                Support.AreEqual("BU yer1FirstName Buyer1LastName", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'BU yer1FirstName Buyer1LastName'");

                Reports.TestStep = "Perform Keyboard Acton '{END}' and enter text 'R'";
                Keyboard.SendKeys("{END}");
                Keyboard.SendKeys("R");
                Support.AreEqual("BU yer1FirstName Buyer1LastNameR", noteField.FAGetValue().Clean().ToString(), "Verifying text is now 'BU yer1FirstName Buyer1LastNameR");
            }
        }

        #endregion PrivateMethods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}

