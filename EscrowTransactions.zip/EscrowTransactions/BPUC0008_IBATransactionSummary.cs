﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;


namespace EscrowTransactions
{
    [CodedUITest]
    public class BPUC0008 : MasterTestClass
    {
        #region BAT

        [TestMethod]
        public void BPUC0008_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Navigate to IBA transaction summary screen and validate that the screen is loaded";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to IBA bank transaction summary screen.";
                FastDriver.LeftNavigation.Navigate<IBATransactionSummary>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Summary").WaitForScreenToLoad();
                 
                Reports.TestStep = "Validate that  IBA bank transaction summary screen is loaded.";
                Reports.StatusUpdate("Find Now button exist?", FastDriver.IBATransactionSummary.FindNow.IsVisible());

                #endregion GUI interaction

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void BPUC0008_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF1_01: Apply filter criteria and click on find now button";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to IBA bank transaction summary screen.";
                FastDriver.LeftNavigation.Navigate<IBATransactionSummary>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Summary").WaitForScreenToLoad();
                 
                Reports.TestStep = "Validate that  IBA bank transaction summary screen is loaded.";
                Reports.StatusUpdate("Find Now button exist?", FastDriver.IBATransactionSummary.FindNow.IsVisible());

                Reports.TestStep = "Set date as filter criteria and click on find button.";
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(@"7/10/2012" + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                
                #endregion GUI interaction

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void BPUC0008_BAT0003()
        {
            try
            {
                Reports.TestDescription = "MF1_02: Validate that data appears in the table";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to IBA bank transaction summary screen.";
                FastDriver.LeftNavigation.Navigate<IBATransactionSummary>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Summary").WaitForScreenToLoad();
                 
                Reports.TestStep = "Validate that  IBA bank transaction summary screen is loaded.";
                Reports.StatusUpdate("Find Now button exist?", FastDriver.IBATransactionSummary.FindNow.IsVisible());

                Reports.TestStep = "Set date as filter criteria and click on find button.";
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(@"7/10/2012" + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();

                Reports.TestStep = "Validate that transaction details is shown in the summary.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                FastDriver.IBATransactionSummary.CompletedElt.FAClick();

                #endregion GUI interaction

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void BPUC0008_BAT0004()
        {
            try
            {
                Reports.TestDescription = "MF1_03_MF1_04: Sort the table as ascending and descending and Perform Delivery";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to IBA bank transaction summary screen.";
                FastDriver.LeftNavigation.Navigate<IBATransactionSummary>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Summary").WaitForScreenToLoad();

                Reports.TestStep = "Validate that  IBA bank transaction summary screen is loaded.";
                Reports.StatusUpdate("Find Now button exist?", FastDriver.IBATransactionSummary.FindNow.IsVisible());

                Reports.TestStep = "Set date as filter criteria and click on find button.";
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(@"7/10/2012" + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();

                Reports.TestStep = "Validate that transaction details is shown in the summary.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                FastDriver.IBATransactionSummary.CompletedElt.FAClick();

                Reports.TestStep = "Able to Sort the table.";
                FastDriver.IBATransactionSummary.File.FAClick();
                Playback.Wait(250);
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                FastDriver.IBATransactionSummary.Account.FAClick();
                Playback.Wait(250);
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                FastDriver.IBATransactionSummary.Transaction.FAClick();
                Playback.Wait(250);
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                FastDriver.IBATransactionSummary.Status.FAClick();
                Playback.Wait(250);
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                FastDriver.IBATransactionSummary.StatusDate.FAClick();
                Playback.Wait(250);
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                FastDriver.IBATransactionSummary.Amount.FAClick();
                Playback.Wait(250);
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                FastDriver.IBATransactionSummary.IBABank_2.FAClick();
                Playback.Wait(250);
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                Keyboard.SendKeys("^L");
                PerformPrintDelivery();

                #endregion GUI interaction

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void BPUC0008_BAT0005_PH()
        {
            try
            {
                Reports.TestDescription = "MF1_05_Place_Holder: Verify Sorted table as ascending and descending order";
                
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        #endregion

        #region REG

        [TestMethod]
        public void BPUC0008_BP10044_Precondition()
        {
            try
            {
                Reports.TestDescription = "Making the cut off time 14 hours behind";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Enter IBA cutoff time.";
                FastDriver.LeftNavigation.Navigate<IBABankSetup>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>IBA Bank Setup").WaitForScreenToLoad();
                FastDriver.IBABankSetup.SelectBankTable.PerformTableAction(2, "First American Trust, FSB", 1, TableAction.On);
                var value = DateTime.Now.AddHours(Convert.ToInt32("-14")).ToString("hh:mm:ss");
                FastDriver.IBABankSetup.DailyCutOff.FASetText(value + FAKeys.Tab);
                if (DateTime.Now.Hour > 12)
                    FastDriver.IBABankSetup.AMRadio.FASetCheckbox(true);
                else
                    FastDriver.IBABankSetup.PMRadio.FASetCheckbox(true);
                FastDriver.LeftNavigation.Navigate<IBABankSetup>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>IBA Bank Setup").WaitForScreenToLoad();
                
                #endregion GUI interaction

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void BPUC0008_REG0001()
        {
            try
            {
                Reports.TestDescription = "BP10044_001_EWC1: Create IBA Beneficiary transaction";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Order";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "click on new button.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();

                Reports.TestStep = "click on new for blank verification.";
                Support.AreEqual(@"File does not have funds available to open an IBA", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Deposit a casher's check.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("50.00" + FAKeys.Tab);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cashier's Check");
                FastDriver.DepositInEscrow.Representing.FASelectItemBySendingKeys("Initial Deposit");
                FastDriver.DepositInEscrow.Description.FASetText("Initial Deposit" + FAKeys.Tab);
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItemBySendingKeys("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer1" + FAKeys.Tab);
                FastDriver.DepositInEscrow.CheckNumber.FASetText("2234567889" + FAKeys.Tab);
                FastDriver.DepositInEscrow.ABANumber.FASetText("1234567895" + FAKeys.Tab);
                FastDriver.DepositInEscrow.BankName.FASetText("23testbank" + FAKeys.Tab);
                FastDriver.DepositInEscrow.AccountNumber.FASetText("1234567895" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                Playback.Wait(250);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Beneficiary, 10);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad(timeout: 15);
                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText(@"Abc" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText(@"Address Line 1" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText(@"Address Line 2" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText(@"Santa ana" + FAKeys.Tab);;
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem(@"CA");;
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText(@"92727" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText(@"123456789" + FAKeys.Tab);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Transactions, 10);
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab().WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText(@"15" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify that same user cannot approve IBA.";
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Approval").WaitForScreenToLoad();
                Support.AreNotEqual(File.FileNumber, FastDriver.IBATransactionApproval.TransactionTable.Text.Clean());
                
                #endregion GUI interaction

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void BPUC0008_REG0002()
        {
            try
            {
                Reports.TestDescription = "BP10044_002: Login as user 2 and approve IBA transaction";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSecondary,
                    Password = AutoConfig.UserPasswordSecondary
                };
                var value = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                Support.AreEqual(@"File does not have funds available to open an IBA", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("50.00" + FAKeys.Tab);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cashier's Check");
                FastDriver.DepositInEscrow.Representing.FASelectItemBySendingKeys("Initial Deposit");
                FastDriver.DepositInEscrow.Description.FASetText("Initial Deposit" + FAKeys.Tab);
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItemBySendingKeys("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer1" + FAKeys.Tab);
                FastDriver.DepositInEscrow.CheckNumber.FASetText("2234567889" + FAKeys.Tab);
                FastDriver.DepositInEscrow.ABANumber.FASetText("1234567895" + FAKeys.Tab);
                FastDriver.DepositInEscrow.BankName.FASetText("23testbank" + FAKeys.Tab);
                FastDriver.DepositInEscrow.AccountNumber.FASetText("1234567895" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                Playback.Wait(250);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Beneficiary, 10);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad(timeout: 15);
                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText(@"Abc" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText(@"Address Line 1" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText(@"Address Line 2" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText(@"Santa ana" + FAKeys.Tab); ;
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem(@"CA"); ;
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText(@"92727" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText(@"123456789" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Transactions, 10);
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab().WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText(@"15" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Approval").WaitForScreenToLoad();
                Support.AreNotEqual(File.FileNumber, FastDriver.IBATransactionApproval.TransactionTable.Text.Clean());

                Reports.TestStep = "Approve the Transaction.";
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Approval").WaitForScreenToLoad();
                FastDriver.IBATransactionApproval.Select_None.FASetCheckbox(true);
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(7, "15.00", 1, TableAction.On);
                FastDriver.IBATransactionApproval.Approve.FAClick();

                Reports.TestStep = "Click on Ok button.";
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (value.Contains("No dialog present"))
                {
                    FastDriver.IBATransactionPastBankCutoffTimeDlg.WaitForScreenToLoad();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
               
                #endregion GUI interaction

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void BPUC0008_REG0003()
        {
            try
            {
                Reports.TestDescription = "BP10040_BP10041_BP10042_BP10043_EWC2: Verify Approved IBA in transaction summary with user 1";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var credentials2 = new Credentials()
                {
                    UserName = AutoConfig.UserNameSecondary,
                    Password = AutoConfig.UserPasswordSecondary
                };
                var value = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                Support.AreEqual(@"File does not have funds available to open an IBA", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("50.00" + FAKeys.Tab);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cashier's Check");
                FastDriver.DepositInEscrow.Representing.FASelectItemBySendingKeys("Initial Deposit");
                FastDriver.DepositInEscrow.Description.FASetText("Initial Deposit" + FAKeys.Tab);
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItemBySendingKeys("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer1" + FAKeys.Tab);
                FastDriver.DepositInEscrow.CheckNumber.FASetText("2234567889" + FAKeys.Tab);
                FastDriver.DepositInEscrow.ABANumber.FASetText("1234567895" + FAKeys.Tab);
                FastDriver.DepositInEscrow.BankName.FASetText("23testbank" + FAKeys.Tab);
                FastDriver.DepositInEscrow.AccountNumber.FASetText("1234567895" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                Playback.Wait(250);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Beneficiary, 10);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad(timeout: 15);
                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText(@"Abc" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText(@"Address Line 1" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText(@"Address Line 2" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText(@"Santa ana" + FAKeys.Tab); ;
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem(@"CA"); ;
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText(@"92727" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText(@"123456789" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Transactions, 10);
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab().WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText(@"15" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Approval").WaitForScreenToLoad();
                Support.AreNotEqual(File.FileNumber, FastDriver.IBATransactionApproval.TransactionTable.Text.Clean());
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Approval").WaitForScreenToLoad();
                FastDriver.IBATransactionApproval.Select_None.FASetCheckbox(true);
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(7, "15.00", 1, TableAction.On);
                FastDriver.IBATransactionApproval.Approve.FAClick();
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (value.Contains("No dialog present"))
                {
                    FastDriver.IBATransactionPastBankCutoffTimeDlg.WaitForScreenToLoad();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();
                }

                Reports.TestStep = "Navigate to IBA bank transaction summary screen.";
                FastDriver.LeftNavigation.Navigate<IBATransactionSummary>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Summary").WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Enter wrong Beneficiary name.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.Beneficiary.FASetText(@"Buyer1Firstname" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();

                Reports.TestStep = "Verify for wrong beneficiary name message.";
                Support.AreEqual(@"Beneficiary name misspelled or not found.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true, timeout: 80).Clean());
                
                Reports.TestStep = "Enter Beneficiary name.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.Beneficiary.FASetText(@"Abc" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "verify table.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                Support.AreEqual(@"15.00", FastDriver.IBATransactionSummary.Table.PerformTableAction(1, File.FileNumber, 6, TableAction.GetText).Message);

                Reports.TestStep = "Enter amount.";
                FastDriver.LeftNavigation.Navigate<IBATransactionSummary>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Summary").WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FromAmount.FASetText(@"8.00" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.ToAmount.FASetText(@"16.00" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "verify table.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                Support.AreEqual(@"15.00", FastDriver.IBATransactionSummary.Table.PerformTableAction(1, File.FileNumber, 6, TableAction.GetText).Message);

                Reports.TestStep = "Enter wrong Approver and Requestor.";
                FastDriver.LeftNavigation.Navigate<IBATransactionSummary>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Summary").WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.Requestor.FASetText(@"FASTTS\FASTQA06" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.Approver.FASetText(@"FASTTS\FASTQA06" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                
                Reports.TestStep = "Verify the IE message.";
                Support.AreEqual(@"No match found.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true, timeout: 60).Clean());
                
                Reports.TestStep = "Enter Approver and Requestor.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.Requestor.FASetText(@"FASTTS\FASTQA07" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.Approver.FASetText(@"FASTTS\FASTQA06" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "verify table.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                Support.AreEqual(@"15.00", FastDriver.IBATransactionSummary.Table.PerformTableAction(1, File.FileNumber, 6, TableAction.GetText).Message);

                Reports.TestStep = "Enter wrong IBA Bank.";
                FastDriver.LeftNavigation.Navigate<IBATransactionSummary>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Summary").WaitForScreenToLoad();
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.IBABank.FASetText(@"First American Trust" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();

                Reports.TestStep = "enter wrong details for IBA Bank.";
                Support.AreEqual(@"No match found.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true, timeout: 60).Clean());

                Reports.TestStep = "Enter IBA Bank.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.IBABank.FASetText(@"First American Trust, FSB" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "verify table.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                Support.AreEqual(@"First American Trust, FSB", FastDriver.IBATransactionSummary.Table.PerformTableAction(1, File.FileNumber, 7, TableAction.GetText).Message);
                checkForCompletedStatus(File.FileNumber);

                #endregion GUI interaction

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void BPUC0008_REG0004_PH()
        {
            try
            {
                Reports.TestDescription = "UncoveredBRs: BP10044";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }


        //Team                                    : ServReq
        //Iteration                               : r10
        //UserStory                               : User Story 748571:INC2374897 - Direct [Bug] - Spell Check missing from Email and Fax Modules
        //TestCase                                : 884495
        //Appended By/ Created By                 : Nikhil
        [TestMethod]
        public void BPUC0008_REG0005()
        {
            try
            {
                Reports.TestDescription = "BP10040_BP10041_BP10042_BP10043_EWC2: Verify Approved IBA in transaction summary with user 1";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var credentials2 = new Credentials()
                {
                    UserName = AutoConfig.UserNameSecondary,
                    Password = AutoConfig.UserPasswordSecondary
                };
                var value = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                Support.AreEqual(@"File does not have funds available to open an IBA", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("50.00" + FAKeys.Tab);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cashier's Check");
                FastDriver.DepositInEscrow.Representing.FASelectItemBySendingKeys("Initial Deposit");
                FastDriver.DepositInEscrow.Description.FASetText("Initial Deposit" + FAKeys.Tab);
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItemBySendingKeys("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer1" + FAKeys.Tab);
                FastDriver.DepositInEscrow.CheckNumber.FASetText("2234567889" + FAKeys.Tab);
                FastDriver.DepositInEscrow.ABANumber.FASetText("1234567895" + FAKeys.Tab);
                FastDriver.DepositInEscrow.BankName.FASetText("23testbank" + FAKeys.Tab);
                FastDriver.DepositInEscrow.AccountNumber.FASetText("1234567895" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                Playback.Wait(250);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Beneficiary, 10);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad(timeout: 15);
                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText(@"Abc" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText(@"Address Line 1" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText(@"Address Line 2" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText(@"Santa ana" + FAKeys.Tab); ;
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem(@"CA"); ;
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText(@"92727" + FAKeys.Tab);
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText(@"123456789" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Transactions, 10);
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab().WaitForTransactionsTabToLoad();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText(@"15" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Approval").WaitForScreenToLoad();
                Support.AreNotEqual(File.FileNumber, FastDriver.IBATransactionApproval.TransactionTable.Text.Clean());
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Approval").WaitForScreenToLoad();
                FastDriver.IBATransactionApproval.Select_None.FASetCheckbox(true);
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(7, "15.00", 1, TableAction.On);
                FastDriver.IBATransactionApproval.Approve.FAClick();
                value = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (value.Contains("No dialog present"))
                {
                    FastDriver.IBATransactionPastBankCutoffTimeDlg.WaitForScreenToLoad();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();
                }

                Reports.TestStep = "Navigate to IBA bank transaction summary screen.";
                FastDriver.LeftNavigation.Navigate<IBATransactionSummary>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Summary").WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Enter wrong Beneficiary name.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.Beneficiary.FASetText(@"Buyer1Firstname" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();

                Reports.TestStep = "Verify for wrong beneficiary name message.";
                Support.AreEqual(@"Beneficiary name misspelled or not found.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true, timeout: 80).Clean());

                Reports.TestStep = "Enter Beneficiary name.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.Beneficiary.FASetText(@"Abc" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "verify table.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                Support.AreEqual(@"15.00", FastDriver.IBATransactionSummary.Table.PerformTableAction(1, File.FileNumber, 6, TableAction.GetText).Message);

                Reports.TestStep = "Enter amount.";
                FastDriver.LeftNavigation.Navigate<IBATransactionSummary>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Summary").WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FromAmount.FASetText(@"8.00" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.ToAmount.FASetText(@"16.00" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "verify table.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                Support.AreEqual(@"15.00", FastDriver.IBATransactionSummary.Table.PerformTableAction(1, File.FileNumber, 6, TableAction.GetText).Message);

                Reports.TestStep = "Enter wrong Approver and Requestor.";
                FastDriver.LeftNavigation.Navigate<IBATransactionSummary>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Summary").WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.Requestor.FASetText(@"FASTTS\FASTQA06" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.Approver.FASetText(@"FASTTS\FASTQA06" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();

                Reports.TestStep = "Verify the IE message.";
                Support.AreEqual(@"No match found.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true, timeout: 60).Clean());

                Reports.TestStep = "Enter Approver and Requestor.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.Requestor.FASetText(@"FASTTS\FASTQA07" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.Approver.FASetText(@"FASTTS\FASTQA06" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "verify table.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                Support.AreEqual(@"15.00", FastDriver.IBATransactionSummary.Table.PerformTableAction(1, File.FileNumber, 6, TableAction.GetText).Message);

                Reports.TestStep = "Enter wrong IBA Bank.";
                FastDriver.LeftNavigation.Navigate<IBATransactionSummary>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Summary").WaitForScreenToLoad();
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.IBABank.FASetText(@"First American Trust" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();

                Reports.TestStep = "enter wrong details for IBA Bank.";
                Support.AreEqual(@"No match found.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true, timeout: 60).Clean());

                Reports.TestStep = "Enter IBA Bank.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.IBABank.FASetText(@"First American Trust, FSB" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "verify table.";
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                Support.AreEqual(@"First American Trust, FSB", FastDriver.IBATransactionSummary.Table.PerformTableAction(1, File.FileNumber, 7, TableAction.GetText).Message);
                checkForCompletedStatus(File.FileNumber);

                #region Spell Check
                Reports.TestStep = "Spell check-email and fax";
                FastDriver.IBATransactionSummary.DeliveryMethod.FASelectItem("Email");
                FastDriver.IBATransactionSummary.Deliver.FAClick();
                FastDriver.SpellingErrorDlg.SpellCheck_Email();
                #endregion

                #endregion GUI interaction

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        #endregion

        #region HelpMethod

        public static void PerformPrintDelivery()
        {
            Reports.TestStep = "Perform Print.";
            FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
            FastDriver.PrintDlg.WaitForScreenToLoad();
            FastDriver.PrintDlg.Printers.FASelectItem(@"TEXT_FILE_PRINTER");
            FastDriver.PrintDlg.Print.FAClick();
            FastDriver.WebDriver.WaitForDeliveryWindow();

        }

        public void checkForCompletedStatus(string fileNo)
        {
            var value = "";
            int i = 0;
            while (true)
            {
                Playback.Wait(60000);
                FastDriver.LeftNavigation.Navigate<IBATransactionSummary>(@"Home>Business Unit Processing>IBA Interface>IBA Transaction Summary").WaitForScreenToLoad();
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(value + FAKeys.Tab);
                value = DateTime.Now.ToString("MM/dd/yyyy");
                value = value.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(value + FAKeys.Tab);
                FastDriver.IBATransactionSummary.IBABank.FASetText(@"First American Trust, FSB" + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FileNo.FASetText(fileNo + FAKeys.Tab);
                FastDriver.IBATransactionSummary.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.IBATransactionSummary.WaitForScreenToLoad();
                if (FastDriver.IBATransactionSummary.StatusCompleted.Exists())
                {
                    Reports.StatusUpdate("Transaction Completed.", true);
                    break;
                }
                i++;
                if (i > 30)
                {
                    Reports.StatusUpdate("Transaction Not Completed.", false);
                    break;
                }

            }
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}

