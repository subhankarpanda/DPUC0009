﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.Common;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.DataObjects.IIS;

namespace EscrowTransactions
{
    [CodedUITest]
    [DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class BPUC0001 : MasterTestClass
    {

        #region REG

        #region BPUC0001_REG0001
        [TestMethod]
        public void BPUC0001_REG0001()
        {
            try
            {
                Reports.TestDescription = "Main Course: Deposit List screen – Create New Deposit List; Alternate Course 1:  Create/Edit Deposit List – Select ALL receipts to include on a deposit list; Alternate Course 2: Create/Edit Deposit List – Select receipts to include on a deposit list; Search Deposit List – Main Flow – Search and Edit Deposit List; BP7885 Allow Edit of Pending Deposit List";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposite List screen; click New button";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.CompletePendingDepositList();
                FastDriver.DepositList.New.FAClick();

                Reports.TestStep = "Validate Show Excluded checkbox is unchecked by default";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ShowExcluded);
                Support.AreEqual("False", FastDriver.DepositList.ShowExcluded.IsSelected().ToString(), "Show Excluded is unchecked");

                Reports.TestStep = "Enter from date, to date, click Find Now checkbox, select first deposit, click Done";
                FastDriver.DepositList.IssueDateFrom.FASetText(DateTime.Now.AddDays(-1).ToString("M-d-yyyy"));
                FastDriver.DepositList.IssueDateTo.FASetText(DateTime.Now.ToString("M-d-yyyy"));
                FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                FastDriver.DepositList.ReceiptsTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Find Now button, validate new deposit list created with Pending status";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.FindNow);
                FastDriver.DepositList.FindNow.FAClick();
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListTable);
                Support.AreEqual("Pending", FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Select the pending deposit list, click Edit button";
                FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.Click);
                string nextDepositID = (Int32.Parse(FastDriver.DepositList.DepositListTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean()) + 1).ToString();
                FastDriver.DepositList.Edit.FAClick();

                Reports.TestStep = "Click the Complete button";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.Complete);
                FastDriver.DepositList.Complete.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Print the receipt";
                FastDriver.DepositList.PrintDepositReceipt();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate status has changed to complete";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.FindNow);
                FastDriver.DepositList.FindNow.FAClick();
                Support.AreEqual("Complete", FastDriver.DepositList.DepositListTable.PerformTableAction(1, nextDepositID, 2, TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region BPUC0001_REG0002
        [TestMethod]
        public void BPUC0001_REG0002()
        {
            try
            {
                Reports.TestDescription = "Search Deposit List – Main Flow – Search and Deliver Deposit List";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposite List screen; click New button";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();

                Reports.TestStep = "Validate default date field and bank account";
                Support.AreEqual(DateTime.Now.ToString("M-d-yyyy"), FastDriver.DepositList.SearchDate.FAGetValue());
                Support.AreEqual("123456789 Automation Bank", FastDriver.DepositList.BankAccounts.FAGetSelectedItem());

                Reports.TestStep = "Click Find Now button, validate 30 records are retruned regardless status";
                FastDriver.DepositList.FindNow.FAClick();
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListTable);
                Support.AreEqual("30", FastDriver.DepositList.DepositListTable.GetRowCount().ToString());

                Reports.TestStep = "Select a deposite list, perform Print delivery";
                FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Complete", 2, TableAction.Click);
                FastDriver.DepositList.Method.FASelectItem("Print");
                FastDriver.DepositList.Deliver.FAClick();

                Reports.TestStep = "Print the receipt";
                FastDriver.DepositList.PrintDepositReceipt();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region BPUC0001_REG0003
        [TestMethod]
        public void BPUC0001_REG0003()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 2 – Permanently Exclude a Receipt from Eligibility for a Deposit List";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposite List screen; click New button";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.CompletePendingDepositList();
                FastDriver.DepositList.New.FAClick();

                Reports.TestStep = "Click Find Now button; obtain receipt number";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListEdit_FindNow);
                FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                FastDriver.DepositList.ReceiptsTable.PerformTableAction(1, 2, TableAction.Click);
                string ReceiptNumber = FastDriver.DepositList.ReceiptsTable.PerformTableAction(1, 7, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Click Exclude button";
                FastDriver.DepositList.Exclude.FAClick();

                Reports.TestStep = "Enter Exclusion Comment, click Done";
                FastDriver.ExclusionCommentDlg.WaitForScreenToLoad();
                FastDriver.ExclusionCommentDlg.Comments.FASetText("Test BPUC0001_REG0003");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to Exclude Receipts screen, validate Receipt #";
                FastDriver.LeftNavigation.Navigate<ExcludedReceipts>(@"Home>Business Unit Processing>Deposit Slip>Excluded Receipts").WaitForScreenToLoad();
                FastDriver.ExcludedReceipts.FindNow.FAClick();
                FastDriver.ExcludedReceipts.WaitForScreenToLoad(FastDriver.ExcludedReceipts.ExcludedReceiptsTable);
                Support.AreEqual(ReceiptNumber, FastDriver.ExcludedReceipts.ExcludedReceiptsTable.PerformTableAction(2, ReceiptNumber, 2, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Complete the pending receipt (clean up)";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.CompletePendingDepositList();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region BPUC0001_REG0004
        [TestMethod]
        public void BPUC0001_REG0004()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 3 –Permanently Exclude a Receipt – User selects Cancel";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposite List screen; click New button";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.CompletePendingDepositList();
                FastDriver.DepositList.New.FAClick();

                Reports.TestStep = "Click Find Now button; obtain receipt number";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListEdit_FindNow);
                FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                FastDriver.DepositList.ReceiptsTable.PerformTableAction(1, 2, TableAction.Click);
                string ReceiptNumber = FastDriver.DepositList.ReceiptsTable.PerformTableAction(1, 7, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Click Exclude button";
                FastDriver.DepositList.Exclude.FAClick();

                Reports.TestStep = "Enter Exclusion Comment, click Done";
                FastDriver.ExclusionCommentDlg.WaitForScreenToLoad();
                FastDriver.ExclusionCommentDlg.Comments.FASetText("Test BPUC0001_REG0004 - Cancel");
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Validate the receipt is still selectable for exclusion";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                Support.AreEqual("True", FastDriver.DepositList.IsCheckBoxEnabled(FastDriver.DepositList.ReceiptsTable.PerformTableAction(7, ReceiptNumber, 7, TableAction.GetCell).Element).ToString());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region BPUC0001_REG0005
        [TestMethod]
        public void BPUC0001_REG0005()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 4 – Unexclude Permanently Excluded Receipt";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposite List screen; click New button";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.CompletePendingDepositList();
                FastDriver.DepositList.New.FAClick();

                Reports.TestStep = "Check Show Excluded checkbox, click Find Now";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListEdit_FindNow);
                FastDriver.DepositList.ShowExcluded.FASetCheckbox(true);
                FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);

                Reports.TestStep = "Select the first excluded receipt, click Exclude button";
                FastDriver.DepositList.ReceiptsTable.PerformTableAction(1, 2, TableAction.Click);
                string ReceiptNumber = FastDriver.DepositList.ReceiptsTable.PerformTableAction(1, 7, TableAction.GetText).Message.Clean();
                FastDriver.DepositList.Exclude.FAClick();

                Reports.TestStep = "Enter Exclusion Comment, click Done";
                FastDriver.ExclusionCommentDlg.WaitForScreenToLoad();
                FastDriver.ExclusionCommentDlg.Unexclude.FASetCheckbox(true);
                FastDriver.ExclusionCommentDlg.Comments.FASetText("Test BPUC0001_REG0005 - Unexclude");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the receipt is now available for selection";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                Support.AreEqual("True", FastDriver.DepositList.IsCheckBoxEnabled(FastDriver.DepositList.ReceiptsTable.PerformTableAction(7, ReceiptNumber, 7, TableAction.GetCell).Element).ToString());

                Reports.TestStep = "Complete the pending receipt (clean up)";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.CompletePendingDepositList();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region BPUC0001_REG0006
        [TestMethod]
        public void BPUC0001_REG0006()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 5 – Permanently Exclude a Receipt – that is selected in the deposit list.";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposite List screen; click New button";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.CompletePendingDepositList();
                FastDriver.DepositList.New.FAClick();

                Reports.TestStep = "Check Show Excluded checkbox, click Find Now";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListEdit_FindNow);
                FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);

                Reports.TestStep = "Select the first excluded receipt, click Exclude button";
                FastDriver.DepositList.ReceiptsTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DepositList.Exclude.FAClick();

                Reports.TestStep = "Validate warning message";
                Support.AreEqual("The receipt is selected for deposit list. Please deselect from deposit list, before excluding.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean());

                Reports.TestStep = "Complete the pending receipt (clean up)";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.CompletePendingDepositList();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region BPUC0001_REG0007
        [TestMethod]
        public void BPUC0001_REG0007()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 6 –Automatically Exclude a Receipt Aged 30 Days; BP7878 Automatically Exclude Receipts Aged 30 or Greater";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Excluded Receipts sreen, enter 30 days old search criteria";
                FastDriver.LeftNavigation.Navigate<ExcludedReceipts>(@"Home>Business Unit Processing>Deposit Slip>Excluded Receipts").WaitForScreenToLoad();
                FastDriver.ExcludedReceipts.FromDate.FASetText(DateTime.Now.AddDays(-60).ToDateString());
                FastDriver.ExcludedReceipts.FindNow.FAClick();
                FastDriver.ExcludedReceipts.WaitForScreenToLoad(FastDriver.ExcludedReceipts.ExcludedReceiptsTable);
                Support.AreEqual("True", FastDriver.ExcludedReceipts.ExcludedReceiptsTable.PerformTableAction(7, "SystemOnlyUser", 8, TableAction.GetText).Message.Clean().Contains("Receipt aged > 30 days").ToString());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region BPUC0001_REG0008
        [TestMethod]
        public void BPUC0001_REG0008()
        {
            try
            {
                Reports.TestDescription = "User searches for deposit list, but no deposit list exists for the given criteria.";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposite List screen; select an unused bank account";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.BankAccounts.FASelectItemByIndex(10);
                FastDriver.DepositList.FindNow.FAClick();

                Reports.TestStep = "Validate warning message";
                Support.AreEqual("No deposit list found for the selected criteria", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean());
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region BPUC0001_REG0009
        [TestMethod]
        public void BPUC0001_REG0009()
        {
            try
            {
                Reports.TestDescription = "BP7879 Allow print and delivery of deposit list in any status";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposite List screen; click New button";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.CompletePendingDepositList();
                FastDriver.DepositList.New.FAClick();
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ShowExcluded);

                Reports.TestStep = "Enter from date, to date, click Find Now checkbox, select first deposit, click Done";
                FastDriver.DepositList.IssueDateFrom.FASetText(DateTime.Now.AddDays(-1).ToString("M-d-yyyy"));
                FastDriver.DepositList.IssueDateTo.FASetText(DateTime.Now.ToString("M-d-yyyy"));
                FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                FastDriver.DepositList.ReceiptsTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Find Now button, select the Pending deposit list";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.FindNow);
                FastDriver.DepositList.FindNow.FAClick();
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListTable);
                FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.Click);

                Reports.TestStep = "Select Print method, click Deliver";
                FastDriver.DepositList.Method.FASelectItem("Print");
                FastDriver.DepositList.Deliver.FAClick();

                Reports.TestStep = "Print the receipt";
                FastDriver.DepositList.PrintDepositReceipt();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select Preview method, click Deliver";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListTable);
                FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.Click);
                FastDriver.DepositList.Method.FASelectItem("Preview");
                FastDriver.DepositList.Deliver.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 300);
                Support.CloseAllProcessStartingWith("AcroRd"); //close all instances of Adobe Reader

                Reports.TestStep = "Select Email method, click Deliver";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListTable);
                FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.Click);
                FastDriver.DepositList.Method.FASelectItem("Email");
                FastDriver.DepositList.Deliver.FAClick();
                FastDriver.EmailDlg.WaitForDialogToLoad();
                FastDriver.EmailDlg.ToText.FASetText(AutoConfig.DeliverEmailTo, clearFirst: false); // Starting from v10.03.0003 build, it doesn't work if not passing clearFirst: false
                FastDriver.EmailDlg.Subject.FASetText(Environment.MachineName + " -" + AutoConfig.FASTHomeURL);
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 300);

                Reports.TestStep = "Select Fax method, click Deliver";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListTable);
                FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.Click);
                FastDriver.DepositList.Method.FASelectItem("Fax");
                FastDriver.DepositList.Deliver.FAClick();
                FastDriver.FaxDlg.WaitForScreenToLoad();
                FastDriver.FaxDlg.Insert.FAClick();
                FastDriver.FaxDlg.FaxRecipientsTable(1, "", 1, TableAction.SetText, "QA");                                     // Name
                FastDriver.FaxDlg.FaxRecipientsTable(2, "", 2, TableAction.SetText, "1");                                      // Attn
                FastDriver.FaxDlg.FaxRecipientsTable(3, "", 3, TableAction.SetText, AutoConfig.DeliverFaxTo);  // Fax To
                FastDriver.FaxDlg.FAX.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Fax", 300);

                Reports.TestStep = "Complete the pending receipt (clean up)";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.CompletePendingDepositList();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region BPUC0001_REG0010
        [TestMethod]
        public void BPUC0001_REG0010()
        {
            try
            {
                Reports.TestDescription = "BP7996  Shall Not update receipts for Master File";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a master file";
                CreateMasterFile();

                Reports.TestStep = "Navigate to Deposit In Escrow screen; validate warning message";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                Support.AreEqual("In order to record a deposit,the file may not be designated as a Master file.", FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true).Clean());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region BPUC0001_REG0011
        [TestMethod]
        public void BPUC0001_REG0011()
        {
            try
            {
                Reports.TestDescription = "BP7883 Automatically Update Receipt Adjustments on a deposit list in pending Status; BP7884 Allow user option to update receipt adjustments on a deposit list in complete or complete/edit status.; BP13484  Deposit List Transmission Date/Time";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposit In Escrow screen";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                
                Reports.TestStep = "Making a cash deposit.";
                #region deposit data
                var deposit = new DepositParameters()
                {
                    Amount = 101.01,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receipt History, obtain document #";
                FastDriver.DepositReceiptHistory.Open();
                string docNumber = FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6 , "101.01", 4, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Navigate to Deposite List screen; click New button";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.CompletePendingDepositList();
                FastDriver.DepositList.New.FAClick();
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ShowExcluded);

                Reports.TestStep = "Click Advanced Search link, enter receipt number, click Find Now";
                FastDriver.DepositList.AdvancedSearch.FAClick();
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptNumber);
                FastDriver.DepositList.ReceiptNumber.FASetText(docNumber);
                FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                FastDriver.DepositList.ReceiptsTable.PerformTableAction(7, docNumber, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Find Now button, validate new deposit list created with Pending status";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.FindNow);
                FastDriver.DepositList.FindNow.FAClick();
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListTable);
                Support.AreEqual("Pending", FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Select the pending deposit list, click Edit button";
                FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.Click);
                string nextDepositID = (Int32.Parse(FastDriver.DepositList.DepositListTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean()) + 1).ToString();
                FastDriver.DepositList.Edit.FAClick();

                Reports.TestStep = "Add another receipt";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.Complete);
                FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10, true);
                FastDriver.DepositList.ReceiptsTable.PerformTableAction(2, 1, TableAction.On);
                string amount2 = FastDriver.DepositList.ReceiptsTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean();
                FastDriver.DepositList.Complete.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Print the receipt";
                FastDriver.DepositList.PrintDepositReceipt();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate status has changed to complete, validate amount";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.FindNow);
                FastDriver.DepositList.FindNow.FAClick();
                Support.AreEqual("Complete", FastDriver.DepositList.DepositListTable.PerformTableAction(1, nextDepositID, 2, TableAction.GetText).Message.Clean());
                string total = (Convert.ToDouble(amount2) + deposit.Amount).ToString().FormatAsMoney();
                Support.AreEqual(total, FastDriver.DepositList.DepositListTable.PerformTableAction(1, nextDepositID, 3, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Select the deposit list, double click";
                FastDriver.DepositList.DepositListTable.PerformTableAction(1, nextDepositID, 3, TableAction.DoubleClick);

                Reports.TestStep = "Remove the second deposit";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.Complete);
                FastDriver.DepositList.ReceiptsTable.PerformTableAction(3, amount2, 1, TableAction.Off);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Find Now button, validate status has changed to Complete-Edit, amount updated";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.FindNow);
                FastDriver.DepositList.FindNow.FAClick();
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListTable);
                Support.AreEqual("Complete-Edit", FastDriver.DepositList.DepositListTable.PerformTableAction(1, nextDepositID, 2, TableAction.GetText).Message.Clean());
                Support.AreEqual(deposit.Amount.ToString(), FastDriver.DepositList.DepositListTable.PerformTableAction(1, nextDepositID, 3, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate Transmit Date is empty";
                Support.AreEqual(string.Empty, FastDriver.DepositList.DepositListTable.PerformTableAction(1, nextDepositID, 7, TableAction.GetText).Message.Clean());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region BPUC0001_REG0012
        [TestMethod]
        public void BPUC0001_REG0012()
        {
            try
            {
                Reports.TestDescription = "BP7881 Trust Interface Status Determines if Completed Deposit List Is Available for Edit; BP7882 Trust Interface Transmittal Updates Deposit List Status and Prohibits Edit of Deposit List";

                Reports.TestStep = "Login FAST IIS application";
                LoginFastFileSite();

                Reports.TestStep = "Create a basic file";
                CreateBasicFileWithSpecifiedGAB();

                Reports.TestStep = "Navigate to Deposite List screen; select first deposit list with Transmit Date";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.FindNow.FAClick();
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListTable);
                int rowCount = FastDriver.DepositList.DepositListTable.GetRowCount();
                for (int count = 1; count < rowCount; count++)
                {
                    if (FastDriver.DepositList.DepositListTable.PerformTableAction(count, 7, TableAction.GetText).Message.Clean() != "")
                    {
                        FastDriver.DepositList.DepositListTable.PerformTableAction(count, 7, TableAction.Click);
                        break;
                    }
                }

                Reports.TestStep = "Validate Edit button is disabled";
                Support.AreEqual("False", FastDriver.DepositList.Edit.IsEnabled().ToString());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region Private Methods

        private void LoginFastFileSite(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void CreateBasicFileWithSpecifiedGAB(string GABCode = "HUDFLINSR1")
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.EmployeeObjectCD = "";
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(GABCode);
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        private void CreateMasterFile()
        {
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry").WaitForScreenToLoad(FastDriver.QuickFileEntry.Continue);
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
            FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
            FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);
            FastDriver.QuickFileEntry.UseAsMasterFile.FASetCheckbox(true);

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

            FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
            FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
            FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");

            Playback.Wait(1000);
            Keyboard.SendKeys("^{D}");
        }

        #endregion Private Methods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
