﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.Common;
using FASTWCFHelpers.FastFileService;
using System.Threading;


namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0083 : MasterTestClass
    {
        #region BAT

        #region FMUC0083_BAT0001
        [TestMethod]
        public void FMUC0083_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Navigate to View Settlement Statement screen.";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestStep = "Login FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a survey with charges.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Enter payment details for SURVEY.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Survey 1");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("7.99");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Survey 1");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("7.99");
                }
                
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Create a second survey with charges.";
                FastDriver.BottomFrame.New();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Enter payment details for SURVEY.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Survey 2");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("10.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("10.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("10.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("10.99");
                    FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("10.99");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Survey 2");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("10.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("10.99");
                }
                
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to View Settlement Stmt and validate data entered.";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                if (AutoConfig.FormType == "CD")
                {
                    Support.AreEqual("18.98", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Due From Buyer", 5, TableAction.GetText).Message.Clean(), "Due From Buyer");
                    Support.AreEqual("18.98", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Due From Seller", 2, TableAction.GetText).Message.Clean(), "Due From Seller");

                    Support.AreEqual("18.98", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 1, TableAction.GetText).Message.Clean(), "Totals - Seller Debit");
                    Support.AreEqual("18.98", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 2, TableAction.GetText).Message.Clean(), "Totals - Seller Credit");
                    Support.AreEqual("18.98", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 4, TableAction.GetText).Message.Clean(), "Totals - Buyer Debit");
                    Support.AreEqual("18.98", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 5, TableAction.GetText).Message.Clean(), "Totals - Buyer Credit");
                }
                else
                {
                    Support.AreEqual("18.98", FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(3, "Cash (X From) ( To) Buyer", 2, TableAction.GetText).Message.Clean(), "Cash (X From) ( To) Buyer");
                    Support.AreEqual("18.98", FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(3, "Cash ( To) (X From) Seller", 5, TableAction.GetText).Message.Clean(), "Cash ( To) (X From) Seller");
                }
                
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        #endregion

        #endregion

        #region REG
        #region FMUC0083_REG0001
        [TestMethod]
        public void FMUC0083_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM5208: Navigate to View Settlement Statement Page";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestStep = "Login FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a survey with charges.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Enter payment details for SURVEY.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Survey 1");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("7.99");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Survey 1");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("7.99");
                }
                
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to View Settlement Stmt using the shortcut bar S/S";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.ViewSettlementStatement.FAClick();
                FastDriver.ViewSettlementStatement.WaitForScreenToLoad();

                Reports.TestStep = "Validate buyer/seller charges are displayed.";
                if (AutoConfig.FormType == "CD")
                {
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Due From Buyer", 5, TableAction.GetText).Message.Clean(), "Due From Buyer");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Due From Seller", 2, TableAction.GetText).Message.Clean(), "Due From Seller");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 1, TableAction.GetText).Message.Clean(), "Totals - Seller Debit");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 2, TableAction.GetText).Message.Clean(), "Totals - Seller Credit");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 4, TableAction.GetText).Message.Clean(), "Totals - Buyer Debit");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 5, TableAction.GetText).Message.Clean(), "Totals - Buyer Credit");
                }
                else
                {
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(3, "Cash (X From) ( To) Buyer", 2, TableAction.GetText).Message.Clean(), "Cash (X From) ( To) Buyer");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(3, "Cash ( To) (X From) Seller", 5, TableAction.GetText).Message.Clean(), "Cash ( To) (X From) Seller");
                }

                
                Reports.TestStep = "Navidate to File Homepage then navigate to View Settlement Stmt using the Nav Tree";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.TestStep = "Validate buyer/seller charges are displayed.";
                if (AutoConfig.FormType == "CD")
                {
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Due From Buyer", 5, TableAction.GetText).Message.Clean(), "Due From Buyer");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Due From Seller", 2, TableAction.GetText).Message.Clean(), "Due From Seller");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 1, TableAction.GetText).Message.Clean(), "Totals - Seller Debit");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 2, TableAction.GetText).Message.Clean(), "Totals - Seller Credit");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 4, TableAction.GetText).Message.Clean(), "Totals - Buyer Debit");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 5, TableAction.GetText).Message.Clean(), "Totals - Buyer Credit");
                }
                else
                {
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(3, "Cash (X From) ( To) Buyer", 2, TableAction.GetText).Message.Clean(), "Cash (X From) ( To) Buyer");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(3, "Cash ( To) (X From) Seller", 5, TableAction.GetText).Message.Clean(), "Cash ( To) (X From) Seller");
                }
                
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region FMUC0083_REG0002
        [TestMethod]
        public void FMUC0083_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM5207: Navigate to Print Settlement Statement Page";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestStep = "Login FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a survey with charges.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Enter payment details for SURVEY.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                if (AutoConfig.FormType == "CD")
                {
                    FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Survey 1");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("7.99");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Survey 1");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("7.99");
                }
                
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navidate to File Homepage then navigate to View Settlement Stmt using the Nav Tree";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.TestStep = "Validate buyer/seller charges are displayed.";
                if (AutoConfig.FormType == "CD")
                {
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Due From Buyer", 5, TableAction.GetText).Message.Clean(), "Due From Buyer");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Due From Seller", 2, TableAction.GetText).Message.Clean(), "Due From Seller");

                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 1, TableAction.GetText).Message.Clean(), "Totals - Seller Debit");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 2, TableAction.GetText).Message.Clean(), "Totals - Seller Credit");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 4, TableAction.GetText).Message.Clean(), "Totals - Buyer Debit");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(3, "Totals", 5, TableAction.GetText).Message.Clean(), "Totals - Buyer Credit");

                }
                else
                {
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(3, "Cash (X From) ( To) Buyer", 2, TableAction.GetText).Message.Clean(), "Cash (X From) ( To) Buyer");
                    Support.AreEqual("7.99", FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(3, "Cash ( To) (X From) Seller", 5, TableAction.GetText).Message.Clean(), "Cash ( To) (X From) Seller");
                }
                
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region FMUC0083_REG0003
        [TestMethod]
        public void FMUC0083_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM3024: Deposits in Escrow";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestStep = "Login FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Create a deposit in escrow";
                #region data setup
                var deposit1 = new DepositParameters()
                {
                    Amount = 10000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit1);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Make another deposit.";
                #region data setup
                var deposit2 = new DepositParameters()
                {
                    Amount = 20000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Seller",
                    Payor = "Seller"
                };
                #endregion
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit2);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20);

                Reports.TestStep = "Navigate to Deposit/Receipt History to obtain document numbers.";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                string depositreceipt1 = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(6, "10,000.00", 4, TableAction.GetText).Message.Clean();
                string depositreceipt2 = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(6, "20,000.00", 4, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Navidate to View Settlement Stmt screen and validate deposit receipts.";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                if (AutoConfig.FormType == "CD")
                {
                    Support.AreEqual("Deposit: Receipt No. " + depositreceipt1 + " on " + DateTime.Now.ToString("MM/dd/yyyy") + " by Buyer", FastDriver.ViewSettlementStatement.FiancialCharge1.FAGetText(), "Deposit 1");
                    Support.AreEqual("Deposit: Receipt No. " + depositreceipt2 + " on " + DateTime.Now.ToString("MM/dd/yyyy") + " by Seller", FastDriver.ViewSettlementStatement.FiancialCharge2.FAGetText(), "Deposit 2");
                }
                else
                {
                    Support.AreEqual("Receipt No. " + depositreceipt1 + " on " + DateTime.Now.ToString("MM/dd/yyyy") + " by Buyer", FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(2, "10,000.00", 3, TableAction.GetText).Message.Clean(), "Deposit 1");
                    Support.AreEqual("Receipt No. " + depositreceipt2 + " on " + DateTime.Now.ToString("MM/dd/yyyy") + " by Seller", FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(5, "20,000.00", 3, TableAction.GetText).Message.Clean(), "Deposit 2");
                }
                
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region FMUC0083_REG0004
        [TestMethod]
        public void FMUC0083_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM3043 Title/Escrow Charges";

                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestStep = "Login FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Add title and recording fees to files";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 4, TableAction.SetText, "10.00" + FAKeys.Tab); // Buyer charge
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 7, TableAction.SetText, "10.00" + FAKeys.Tab); // Seller charge
                string fee1 = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(1, 4, TableAction.SetText, "20.00" + FAKeys.Tab); // Buyer charge
                FastDriver.FileFees.RecordingTable.PerformTableAction(1, 5, TableAction.SetText, "20.00" + FAKeys.Tab); // Seller charge
                string fee2 = FastDriver.FileFees.RecordingTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Navidate to View Settlement Stmt screen and validate fees are displayed properly.";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                if (AutoConfig.FormType == "CD")
                {
                    Support.AreEqual(fee1 + " to " + AutoConfig.SelectedOfficeName, FastDriver.ViewSettlementStatement.TitleCharge1.FAGetText(), "Title Fee");
                    Support.AreEqual("True", FastDriver.ViewSettlementStatement.RecordingCharge1.FAGetText().Contains(fee2).ToString(), "Recording Fee");
                }
                else
                {
                    Support.AreEqual(true, FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(3, 3, TableAction.GetText).Message.Clean().Contains(fee1), "Title Fee");
                    Support.AreEqual(true, FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(4, 3, TableAction.GetText).Message.Clean().Contains(fee2), "Recording Fee");
                }

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        #region FMUC0083_REG0005
        [TestMethod]
        public void FMUC0083_REG0005()
        {
            try
            {
                Reports.TestDescription = @"US_662403: Control Access for Feature 5 - Continuation";

                #region data setup//change credentials here
                var SU_Credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU
                };
                #endregion

                #region Create New Office
                Reports.TestStep = "Login FAST ADM application with superuser account";
                FASTLogin.Login(AutoConfig.FASTAdmURL, SU_Credentials, true);

                Reports.TestStep = "Create a new office under National Commercial Services Division region";
                FastDriver.OfficeSummary.Open(ProcRegion: "NATLAC");
                FastDriver.OfficeSummary.New.FAClick();
                
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                
                string officeCode = Support.RandomNumber(9999).ToString();
                string officeName = Support.RandomString("AAAAAAAAAA_AAAAAAAAAA");
                string federalTaxID = "11-1111111";

                FastDriver.OfficeSetupOffice.OfficeCode.FASetText(officeCode);
                FastDriver.OfficeSetupOffice.FederalTaxID.FASetText(federalTaxID);
                FastDriver.OfficeSetupOffice.OfficeName.FASetText(officeName);
                FastDriver.OfficeSetupOffice.OfficeCompanyName1.FASetText(officeName);
                FastDriver.OfficeSetupOffice.FeeTransmittalType.FASelectItem("Check");
                FastDriver.OfficeSetupOffice.TimeZone.FASelectItem("Pacific Time");
                FastDriver.OfficeSetupOffice.StatisticalReportingOffice.FASelectItem("Direct");
                FastDriver.OfficeSetupOffice.ProductionSystem.FASelectItem("FAST deployed");
                FastDriver.OfficeSetupOffice.FastStatCode.FASetText("1");

                FastDriver.OfficeSetupOffice.UnderwritersMenu.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad(FastDriver.OfficeSetupUnderwriters.UnderwritersNew);
                FastDriver.OfficeSetupUnderwriters.UnderwritersNew.FAClick();
                Thread.Sleep(5000);
                FastDriver.OfficeSetupUnderwriters.WaitForScreenToLoad(FastDriver.OfficeSetupUnderwriters.UnderwriterName1);
                FastDriver.OfficeSetupUnderwriters.UnderwriterName1.FASelectItem("First American Title Insurance Company");
                FastDriver.OfficeSetupUnderwriters.UseAsDefaultUnderwriter.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Get the new BUID for the office";
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                string officeBUID = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction(2, officeCode, 3, TableAction.GetText).Message.Clean();
                FastDriver.WebDriver.Quit();
                #endregion

                #region Test Case 665586
                Reports.TestStep = "[Test Case 665586] Login FAST IIS application with superuser account";
                FASTLogin.Login(AutoConfig.FASTHomeURL, SU_Credentials, true);

                Reports.TestStep = "Navigate to the newly created office";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeBUID);

                Reports.TestStep = "Create a new file with Business Segment = Commercial and Sale Price = 500,000.00 ";
                CreateFile(busSegment: "Commercial", salePrice: "500,000.00");

                Reports.TestStep = @"Navigate to Term/Dates/Status screen";
                FastDriver.TermsDatesStatus.Open();

                Reports.TestStep = @"Validate Sale Price";
                Support.AreEqual("500,000.00", FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue(), "Total Sale Price");

                if (AutoConfig.FormType == "CD")
                {
                    Reports.TestStep = @"Click Edit SP/OPL button";
                    FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();

                    Reports.TestStep = @"Validate the First Sale Price amount";
                    FastDriver.SalePrice_OwnerPolicyLiabilityDlg.WaitForScreenToLoad();
                    Support.AreEqual("500,000.00", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceAmount.FAGetValue(), "First Sale Price");

                    Reports.TestStep = @"Add Second Sale Price amount of 100,000.00";
                    FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText("100,000.00");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 10, true);
                    FastDriver.WebDriver.HandleDialogMessage(true, true, 10, true);

                    Reports.TestStep = @"Validate the Edit SP/OPL button is in grey color";
                    FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                    Support.AreEqual(true, FastDriver.TermsDatesStatus.Edit_SP_OPL.FAGetAttribute("style").Contains("background-color: rgb(99, 154, 206)"), @"Edit SP/OPL button is in grey color");
                }
                
                Reports.TestStep = @"Navigate to View Settlement Statement screen, validate defaults values";
                FastDriver.ViewSettlementStatement.Open();
                if (AutoConfig.FormType == "CD")
                {
                    Support.AreEqual("600,000.00", FastDriver.ViewSettlementStatement.NewConsiderationTable.PerformTableAction(3, 1, TableAction.GetText).Message, "Buyer Charge");
                    Support.AreEqual("600,000.00", FastDriver.ViewSettlementStatement.NewConsiderationTable.PerformTableAction(3, 5, TableAction.GetText).Message, "Seller Credit");
                }
                else
                {
                    Support.AreEqual("500,000.00", FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(3, "Total Consideration", 1, TableAction.GetText).Message.Clean(), "Buyer Charge");
                    Support.AreEqual("500,000.00", FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(3, "Total Consideration", 5, TableAction.GetText).Message.Clean(), "Seller Credit");
                }

                if (AutoConfig.FormType == "CD")
                {
                    Reports.TestStep = @"Navigate to Settlement Statement screen, validate Initals checkboxes are displayed for all client formats";
                    FastDriver.LeftNavigation.Navigate<PrintEscrowSetlleStmt>("Settlement Statement").WaitForScreenToLoad();
                    Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.CombinedInitialsChkBx.IsDisplayed(), "Combined Initials Checkbox");
                    Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.BuyerInitialsChkBx.IsDisplayed(), "Buyer Initials Checkbox");
                    Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.SellerInititalsChkBx.IsDisplayed(), "Seller Initials Checkbox");
                
                    Reports.TestStep = @"Validate Page Settings";
                    Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.PageSizeLetter.IsSelected(), "Letter page setting");
                }
                #endregion

                #region Test Case 665588
                Reports.TestStep = "[Test Case 665588] Create a new file with Business Segment = Residential and Sale Price = 500,000.00 ";
                CreateFile(busSegment: "Residential", salePrice: "500,000.00");

                Reports.TestStep = @"Navigate to Term/Dates/Status screen";
                FastDriver.TermsDatesStatus.Open();

                Reports.TestStep = @"Validate Sale Price";
                Support.AreEqual("500,000.00", FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue(), "Total Sale Price");

                if (AutoConfig.FormType == "CD")
                {
                    Reports.TestStep = @"Click Edit SP/OPL button";
                    FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                    FastDriver.SalePrice_OwnerPolicyLiabilityDlg.WaitForScreenToLoad();
                    FastDriver.DialogBottomFrame.ClickCancel();
                    FastDriver.TermsDatesStatus.WaitForScreenToLoad();

                    Reports.TestStep = @"Navigate to Settlement Statement screen, validate Initals checkboxes are NOT displayed for all client formats";
                    FastDriver.PrintEscrowSetlleStmt.Open();
                    Support.AreEqual(false, FastDriver.PrintEscrowSetlleStmt.CombinedInitialsChkBx.IsDisplayed(), "Combined Initials Checkbox Is Not Displayed");
                    Support.AreEqual(false, FastDriver.PrintEscrowSetlleStmt.BuyerInitialsChkBx.IsDisplayed(), "Buyer Initials Checkbox Is Not Displayed");
                    Support.AreEqual(false, FastDriver.PrintEscrowSetlleStmt.SellerInititalsChkBx.IsDisplayed(), "Seller Initials Checkbox Is Not Displayed");
                }
                #endregion

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
            finally
            {
                FastDriver.WebDriver.Quit();
            }
        }

        #endregion

        [TestMethod]
        public void FMUC0083_REG0006()
        {
            try
            {
                //UAT 10.6
                //INC2965427_839895
                #region Data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE"; //Sale with Mortagage 
                #endregion

                Reports.TestDescription = "Duplicate fee display on SS (Commercial)";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to File Fee";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "1064_Title_Lender_Policy", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "1064_Title_Lender_Policy", "Det", TableAction.Click);
                FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.FeePaymentDetailsDlg.AdditionalDescription.FASetText("Additional Description for Testing");
                
                if (AutoConfig.FormType == "CD")
                {
                    string loanDescription = FastDriver.FeePaymentDetailsDlg.LoanEstimatedDesc.FAGetValue();
                    FastDriver.DialogBottomFrame.ClickDone();

                    Reports.TestStep = "Navigate to View Settlement Statement";
                    FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                    FastDriver.ViewSettlementStatement.btnExpandAll.FAClick();
                    FastDriver.ViewSettlementStatement.TitleEscrowChrgDescrH.FAGetText();
                    Reports.StatusUpdate("The text contained on Title Escrow charges to is: " + FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable11.FAGetText(), true);
                    Support.AreEqual("False", FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable11.FAGetText().Contains(loanDescription).ToString());
                    Reports.StatusUpdate("The Text of TitleEscrowTable is:  " + FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable11.FAGetText(), true);
                }
                
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        #endregion

        #region HelpMethod

        private void CreateFile(string busSegment, string salePrice)
        {
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
            try
            {
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            }
            catch
            {
                Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
            }

            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("12345");
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
            FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys(busSegment);
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

            if (AutoConfig.FormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
            else if (AutoConfig.FormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

            FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
            FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(salePrice);
            Thread.Sleep(5000);
            FastDriver.BottomFrame.Done();
            FastDriver.FileHomepage.WaitForScreenToLoad();
        }


        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}

