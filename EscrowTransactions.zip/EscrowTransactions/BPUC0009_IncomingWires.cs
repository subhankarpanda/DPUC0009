﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects;
using OpenQA.Selenium;


namespace EscrowTransactions
{
    /// <summary>
    /// Summary description for BPUC0009_IncomingWires
    /// </summary>
    [CodedUITest]
    public class BPUC0009_IncomingWires : MasterTestClass
    {
        public BPUC0009_IncomingWires()
        {
        }

        #region - IW SetUp
        [TestMethod]
        public void BPUC0009_Bank_And_BankAccount_SetUp()
        {
            try
            {
                FASqlHelpers.GenerateDataForIncomingWire();
                Reports.TestDescription = "Setting up Bank and Bank Account for IW Automated Testing";
                Login(AutoConfig.FASTAdmURL, AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Selecting Region to have Region-level access";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Verifying if Bank entry is available.";
                FastDriver.LeftNavigation.Navigate<BankSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Banks").WaitForScreenToLoad();
                if (FastDriver.BankSummary.BankSummaryTable.FAGetText().Contains("First American Trust - FSB"))
                {
                    Reports.StatusUpdate("First American Trust - FSB entry has been set up.", true);
                }
                else
                {
                    Reports.StatusUpdate("First American Trust - FSB entry was not found. Creating Bank entry", true);
                    FastDriver.BankSummary.New.FAClick();
                    FastDriver.BankDetail.WaitForScreenToLoad();
                    FastDriver.BankDetail.FASTBankCode.FASetText("FASTQAR");
                    FastDriver.BankDetail.SMSBankCode.FASetText("002");
                    FastDriver.BankDetail.RoutingNumber.FASetText("122241255");
                    FastDriver.BankDetail.WireInterfaceBank.FASetCheckbox(true);
                    FastDriver.BankDetail.Name1.FASetText("First American Trust - FSB");
                    FastDriver.BankDetail.LocDescription.FASetText("Santa Ana");
                    FastDriver.BankDetail.CheckTemplate.FASelectItem("Custom Envelope - Dual On-Us Symbol (eg JP Morgan)");
                    FastDriver.BankDetail.New.FAClick();
                    FastDriver.BankDetail.AddressType.FASelectItem("Business");
                    FastDriver.BankDetail.AddressLine1.FASetText("421 N. Main St");
                    FastDriver.BankDetail.City.FASetText("Santa Ana");
                    FastDriver.BankDetail.State.FASelectItem("CA");
                    FastDriver.BankDetail.County.FASetText("Orange");
                    FastDriver.BankDetail.Zip.FASetText("91701");
                    FastDriver.BankDetail.Apply.FAClick();
                    FastDriver.BankDetail.BusPhoneNumber.FASetText("(714)647-2715");
                    FastDriver.BankDetail.BusPhoneComments.FASetText("Jerry Braakman - FAST-Bistro Testing");
                    FastDriver.BankDetail.EmailNumber.FASetText("dryvwjz@firstam.com");
                    FastDriver.BankDetail.EmailComments.FASetText("Cecilia Young - FAST-Bistro Testing");
                    FastDriver.BottomFrame.Done();
                    FastDriver.BankSummary.WaitForScreenToLoad();
                }
               
                FastDriver.LeftNavigation.Navigate<OfficeSummary>("STEST>Offices").WaitForScreenToLoad();
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "QA Automation Office - DO NOT TOUCH", "#4", TableAction.DoubleClick);
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
                FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
                if (FastDriver.OfficeSetupBankAccounts.BanksTable.FAGetText().Contains("9993109200000"))
                {
                    Reports.StatusUpdate("Bank account found. Proceeding with next test step.", true);
                }
                else
                {
                    Reports.StatusUpdate("Bank account was not found. Creating entry.", true);
                    FastDriver.OfficeSetupBankAccounts.BankAccountSummaryNew.FAClick();
                    FastDriver.OfficeSetupBankAccounts.BankAccountDetail_BankName.FASelectItem("First American Trust - FSB - Santa Ana");
                    FastDriver.OfficeSetupBankAccounts.BankAccountDetailAccountNo1.FASetText("9993109200000");
                    FastDriver.OfficeSetupBankAccounts.BankAccountDetailAccountNo2.FASetText("9993109200000");
                    FastDriver.OfficeSetupBankAccounts.BankAccountDetail_AccountDescription.FASetText("IW Automation Account");
                    FastDriver.OfficeSetupBankAccounts.DepositAcct.FASetCheckbox(true);
                    FastDriver.OfficeSetupBankAccounts.DisburseAcct.FASetCheckbox(true);
                    FastDriver.OfficeSetupBankAccounts.WirelinkInterfaceAccount.FASetCheckbox(true);
                    FastDriver.OfficeSetupBankAccounts.SignatureText1.Click();
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Accessing Bank Summary for Exchange Region to verify if Bank is set up";
                FastDriver.LeftNavigation.Navigate<BankSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>eSTEST>Banks[1]").WaitForScreenToLoad();
                if (FastDriver.BankSummary.BankSummaryTable.FAGetText().Contains("First American Trust - FSB"))
                {
                    Reports.StatusUpdate("First American Trust - FSB entry has been set up.", true);
                }
                else
                {
                    Reports.StatusUpdate("First American Trust - FSB entry was not found. Creating Bank entry", true);
                    FastDriver.BankSummary.New.FAClick();
                    FastDriver.BankDetail.WaitForScreenToLoad();
                    FastDriver.BankDetail.FASTBankCode.FASetText("FASTQAR");
                    FastDriver.BankDetail.SMSBankCode.FASetText("002");
                    FastDriver.BankDetail.RoutingNumber.FASetText("122241255");
                    FastDriver.BankDetail.WireInterfaceBank.FASetCheckbox(true);
                    FastDriver.BankDetail.Name1.FASetText("First American Trust - FSB");
                    FastDriver.BankDetail.LocDescription.FASetText("Santa Ana");
                    FastDriver.BankDetail.CheckTemplate.FASelectItem("Custom Envelope - Dual On-Us Symbol (eg JP Morgan)");
                    FastDriver.BankDetail.New.FAClick();
                    FastDriver.BankDetail.AddressType.FASelectItem("Business");
                    FastDriver.BankDetail.AddressLine1.FASetText("421 N. Main St");
                    FastDriver.BankDetail.City.FASetText("Santa Ana");
                    FastDriver.BankDetail.State.FASelectItem("CA");
                    FastDriver.BankDetail.County.FASetText("Orange");
                    FastDriver.BankDetail.Zip.FASetText("91701");
                    FastDriver.BankDetail.Apply.FAClick();
                    FastDriver.BankDetail.BusPhoneNumber.FASetText("(714)647-2715");
                    FastDriver.BankDetail.BusPhoneComments.FASetText("Jerry Braakman - FAST-Bistro Testing");
                    FastDriver.BankDetail.EmailNumber.FASetText("dryvwjz@firstam.com");
                    FastDriver.BankDetail.EmailComments.FASetText("Cecilia Young - FAST-Bistro Testing");
                    FastDriver.BottomFrame.Done();
                    FastDriver.BankSummary.WaitForScreenToLoad();
                }

                Reports.TestStep = "Verifying if account number was added to Exchange Delay office";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>("eSTEST>Offices[1]").WaitForScreenToLoad();
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "zz-Exchange Delay FAST Admin Office", "#4", TableAction.DoubleClick);
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
                FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
                if (FastDriver.OfficeSetupBankAccounts.BanksTable.FAGetText().Contains("9993109200000"))
                {
                    Reports.StatusUpdate("Bank account found. Proceeding with next test step.", true);
                }
                else
                {
                    Reports.StatusUpdate("Bank account was not found. Creating entry.", true);
                    FastDriver.OfficeSetupBankAccounts.BankAccountSummaryNew.FAClick();
                    FastDriver.OfficeSetupBankAccounts.BankAccountDetail_BankName.FASelectItem("First American Trust - FSB - Santa Ana");
                    FastDriver.OfficeSetupBankAccounts.BankAccountDetailAccountNo1.FASetText("9993109200000");
                    FastDriver.OfficeSetupBankAccounts.BankAccountDetailAccountNo2.FASetText("9993109200000");
                    FastDriver.OfficeSetupBankAccounts.BankAccountDetail_AccountDescription.FASetText("IW Automation Account");
                    FastDriver.OfficeSetupBankAccounts.DepositAcct.FASetCheckbox(true);
                    FastDriver.OfficeSetupBankAccounts.DisburseAcct.FASetCheckbox(true);
                    FastDriver.OfficeSetupBankAccounts.WirelinkInterfaceAccount.FASetCheckbox(true);
                    FastDriver.OfficeSetupBankAccounts.SignatureText1.Click();
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying if account number was added to Exchange Reverse office";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>("eSTEST>Offices[1]").WaitForScreenToLoad();
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "zz-Exchange Reverse FAST Admin Office", "#4", TableAction.DoubleClick);
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
                FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
                if (FastDriver.OfficeSetupBankAccounts.BanksTable.FAGetText().Contains("9993109200000"))
                {
                    Reports.StatusUpdate("Bank account found. Proceeding with next test step.", true);
                }
                else
                {
                    Reports.StatusUpdate("Bank account was not found. Creating entry.", true);
                    FastDriver.OfficeSetupBankAccounts.BankAccountSummaryNew.FAClick();
                    FastDriver.OfficeSetupBankAccounts.BankAccountDetail_BankName.FASelectItem("First American Trust - FSB - Santa Ana");
                    FastDriver.OfficeSetupBankAccounts.BankAccountDetailAccountNo1.FASetText("9993109200000");
                    FastDriver.OfficeSetupBankAccounts.BankAccountDetailAccountNo2.FASetText("9993109200000");
                    FastDriver.OfficeSetupBankAccounts.BankAccountDetail_AccountDescription.FASetText("IW Automation Account");
                    FastDriver.OfficeSetupBankAccounts.DepositAcct.FASetCheckbox(true);
                    FastDriver.OfficeSetupBankAccounts.DisburseAcct.FASetCheckbox(true);
                    FastDriver.OfficeSetupBankAccounts.WirelinkInterfaceAccount.FASetCheckbox(true);
                    FastDriver.OfficeSetupBankAccounts.SignatureText1.Click();
                }
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }
        #endregion

        #region - Normal IW Test Cases

        #region Screen Checks

        [TestMethod]
        public void BPUC0009_IncomingWiresScreen()
        {
            try
            {
                Reports.TestDescription = "Incoming Wires Screen";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.IncomingWires.Select_BankAcct.FAGetAllTextFromSelect(", ").Contains("All Accounts"), "Verifying Bank Acct. menu options");
                Support.AreEqual(true, FastDriver.IncomingWires.Select_BankAcct.FAGetAllTextFromSelect(", ").Contains("9993109200000"), "Verifying Bank Acct. menu options");

                Reports.TestStep = "Testing Delivery method dropdown menu";
                Support.AreEqual(true, FastDriver.IncomingWires.Select_Method.FAGetAllTextFromSelect(", ").Contains("Print, Preview, Email, Fax"), "Verifying Delivery Method menu options");

                Reports.TestStep = "Verifying default value in DateFrom and DateTo fields";

                Support.AreEqual(DateTime.Now.ToDateString(trim: true), FastDriver.IncomingWires.IssueDateFrom.FAGetValue(), "Verifying DateFrom data.");
                Support.AreEqual(DateTime.Now.ToDateString(trim: true), FastDriver.IncomingWires.IssueDateTo.FAGetValue(), "Verifying DateTo data.");

                Support.AreEqual(true, FastDriver.IncomingWires.Select_Status.FAGetAllTextFromSelect(", ").Contains("All, Completed, Excluded, Manual Receipt, Pending, Pending Approval, Returned, Transferred"), "Verifying Status menu options");

                Reports.TestStep = "Testing Item Type dropdown menu";
                Support.AreEqual(true, FastDriver.IncomingWires.Select_ItemType.FAGetAllTextFromSelect(", ").Contains("All, ACH, IW"), "Verifying Item Type menu options");

                Reports.TestStep = "Verifying Search Results column headers";
                Support.AreEqual(true, FastDriver.IncomingWires.SearchResultsHeader.PerformTableAction(1, 1, TableAction.GetText).Message.Clean().Equals("Type"), "Verifying table headers");
                Support.AreEqual(true, FastDriver.IncomingWires.SearchResultsHeader.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().Equals("Status"), "Verifying table headers");
                Support.AreEqual(true, FastDriver.IncomingWires.SearchResultsHeader.PerformTableAction(1, 3, TableAction.GetText).Message.Clean().Equals("Receive Date"), "Verifying table headers");
                Support.AreEqual(true, FastDriver.IncomingWires.SearchResultsHeader.PerformTableAction(1, 4, TableAction.GetText).Message.Clean().Equals("Amount"), "Verifying table headers");
                Support.AreEqual(true, FastDriver.IncomingWires.SearchResultsHeader.PerformTableAction(1, 5, TableAction.GetText).Message.Clean().Equals("Sending Bank"), "Verifying table headers");
                Support.AreEqual(true, FastDriver.IncomingWires.SearchResultsHeader.PerformTableAction(1, 6, TableAction.GetText).Message.Clean().Equals("Originator"), "Verifying table headers");
                Support.AreEqual(true, FastDriver.IncomingWires.SearchResultsHeader.PerformTableAction(1, 7, TableAction.GetText).Message.Clean().Equals("OBI"), "Verifying table headers");
                Support.AreEqual(true, FastDriver.IncomingWires.SearchResultsHeader.PerformTableAction(1, 8, TableAction.GetText).Message.Clean().Equals("File #"), "Verifying table headers");

                Reports.TestStep = "Verifying Action Button exist";
                Support.AreEqual(true, FastDriver.IncomingWires.ViewDetails.IsDisplayed(), "Action Button is displayed.");
                Support.AreEqual(true, FastDriver.IncomingWires.ExcludeRecover.IsDisplayed(), "Action Button is displayed.");
                Support.AreEqual(true, FastDriver.IncomingWires.ReceiptToFile.IsDisplayed(), "Action Button is displayed.");
                Support.AreEqual(true, FastDriver.IncomingWires.Transfer.IsDisplayed(), "Action Button is displayed.");
                Support.AreEqual(true, FastDriver.IncomingWires.ReturnWire.IsDisplayed(), "Action Button is displayed.");

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_IncomingWiresSearchScreen()
        {
            try
            {
                Reports.TestDescription = "Incoming Wires Search Screen";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();

                Reports.TestStep = "Checking Status Dropdown Values";
                Support.AreEqual(true, FastDriver.IncomingWires.Select_Status.FAGetAllTextFromSelect(", ").Contains("All, Completed, Excluded, Manual Receipt, Pending, Pending Approval, Returned, Transferred"), "Verifying Status menu options");

                Reports.TestStep = "Checking IW Type Dropdown Values";
                Support.AreEqual(true, FastDriver.IncomingWires.Select_ItemType.FAGetAllTextFromSelect(", ").Contains("All, ACH, IW"), "Verifying Item Type menu options");

                Reports.TestStep = "Choose an Item type and validates wires are filtered by that item type";
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(1, "IW", 2, TableAction.Click);
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("ACH");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(1, "ACH", 2, TableAction.Click);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
            
        }

        [TestMethod]
        public void BPUC0009_IncomingWiresViewDetailsScreen()
        {
            try
            {
                ToggleDisplayPDFinBrowser(true);
                Reports.TestDescription = "Incoming Wires View Details Screen (IW)";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();

                Reports.TestStep = "Choose an Item type and validates wires are filtered by that item type";
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(1, "IW", 1, TableAction.Click);

                Reports.TestStep = "Enter View Details Screen and validate Delivery Methods";
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(1, "IW", 1, TableAction.Click);
                Support.AreEqual(true, FastDriver.IncomingWires.ViewDetails.IsEnabled(), "Verifying that View Details button is enabled.");
                FastDriver.IncomingWires.ViewDetails.FAClick();
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.IncomingWireViewDetails.Method.IsEnabled(), "Verifying button is enabled.");
                Support.AreEqual(true, FastDriver.IncomingWireViewDetails.Method.FAGetAllTextFromSelect(", ").Contains("Print, Preview, Email"), "Verifying options in Method dropdown.");

                Reports.TestStep = "Validate that the Print Dialog exists";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Print");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Preview Method screen";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Preview");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Preview, 200);
                FastDriver.WebDriver.ClosePreviewWindow();
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Email Method screen";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Email");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.EmailDlg.WaitForScreenToLoad();
                FastDriver.EmailDlg.SendEmail();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Email, 200);
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                ToggleDisplayPDFinBrowser(false);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_IncomingWiresACHDetails()
        {
            try
            {
                ToggleDisplayPDFinBrowser(true);
                Reports.TestDescription = "Incoming Wires View Details Screen (ACH)";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();

                Reports.TestStep = "Choose an Item type and validates wires are filtered by that item type";
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("ACH");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "ACH", "#1", TableAction.Click);
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("ACH");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();

                Reports.TestStep = "Enter View Details Screen and validate Delivery Methods";
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "ACH", "#1", TableAction.Click);
                Support.AreEqual(true, FastDriver.IncomingWires.ViewDetails.IsEnabled(), "Verifying that View Details button is enabled.");
                FastDriver.IncomingWires.ViewDetails.FAClick();
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.IncomingWireViewDetails.Method.IsEnabled(), "Verifying button is enabled.");
                Support.AreEqual(true, FastDriver.IncomingWireViewDetails.Method.FAGetAllTextFromSelect(", ").Contains("Print, Preview, Email"), "Verifying options in Method dropdown.");

                Reports.TestStep = "Validate that the Print Dialog exists";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Print");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Preview Method screen";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Preview");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 210);
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Email Method screen";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Email");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.EmailDlg.WaitForScreenToLoad();
                FastDriver.EmailDlg.ToText.FASetText(AutoConfig.DeliverEmailTo, clearFirst: false); // Starting from v10.03.0003 build, it doesn't work if not passing clearFirst: false
                FastDriver.EmailDlg.Subject.FASetText(Environment.MachineName + " - IncomingWires Testing");
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                ToggleDisplayPDFinBrowser(true);

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_TransferWireScreen()
        {
            try
            {
                Reports.TestDescription = "Transfer Wire Screen";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, "Pending", 2, TableAction.Click);
                
                FastDriver.IncomingWires.Transfer.FAClick();
                FastDriver.TransferWire.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.TransferWire.RecipientOfficeBUID.IsDisplayed(), "Verifying if Recipient Office BUID field is displayed.");
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_ReturnWireScreen()
        {
            try
            {
                Reports.TestDescription = "Return Wire Screen";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
                
                FastDriver.IncomingWires.ReturnWire.FAClick();
                FastDriver.ReturnWire.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.ReturnWire.ReasonOfReturn.IsDisplayed(), "Verifying if field is displayed.");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_ReceiptToFileScreen()
        {
            try
            {
                Reports.TestDescription = "Receipt to File Screen";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                #region - Data SetUp
                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                string wireAmt = FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.Click);

                var deposit = new DepositParameters()
                {

                    Amount = double.Parse(wireAmt),
                    TypeofFunds = "Direct Deposit",
                    ReceivedFrom = "Buyer",
                    Representing = "Earnest Money Deposit",
                    Description = "Testing Incoming Wires",
                };
                #endregion

                #region - Create file, add manual deposit
                Reports.TestStep = "Creating file in IIS";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                string Representing = FastDriver.DepositInEscrow.Representing.FAGetAllTextFromSelect(", ");
                string ReceivedFrom = FastDriver.DepositInEscrow.ReceivedFrom.FAGetAllTextFromSelect(", ");
                #endregion

                Reports.TestStep = "Checking Receipt to File screen";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.Click);
                Support.AreEqual(true, FastDriver.IncomingWires.ReceiptToFile.IsEnabled(), "Verifying if Receipt To File button is enabled. If step fails, please check transaction status.");
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();

                Reports.TestStep = "Verifying Search Results column headers";
                Support.AreEqual(true, FastDriver.ReceiptToFile.ReceiptTableHeader.PerformTableAction(1, 1, TableAction.GetText).Message.Clean().Equals("BUID"), "Verifying header elements");
                Support.AreEqual(true, FastDriver.ReceiptToFile.ReceiptTableHeader.PerformTableAction(1, 2, TableAction.GetText).Message.Clean().Equals("File Number"), "Verifying header elements");
                Support.AreEqual(true, FastDriver.ReceiptToFile.ReceiptTableHeader.PerformTableAction(1, 3, TableAction.GetText).Message.Clean().Equals("MR"), "Verifying header elements");
                Support.AreEqual(true, FastDriver.ReceiptToFile.ReceiptTableHeader.PerformTableAction(1, 4, TableAction.GetText).Message.Clean().Equals("Receipt #"), "Verifying header elements");
                Support.AreEqual(true, FastDriver.ReceiptToFile.ReceiptTableHeader.PerformTableAction(1, 5, TableAction.GetText).Message.Clean().Equals("Amount"), "Verifying header elements");
                Support.AreEqual(true, FastDriver.ReceiptToFile.ReceiptTableHeader.PerformTableAction(1, 6, TableAction.GetText).Message.Clean().Equals("Received From"), "Verifying header elements");
                Support.AreEqual(true, FastDriver.ReceiptToFile.ReceiptTableHeader.PerformTableAction(1, 7, TableAction.GetText).Message.Clean().Equals("Payor"), "Verifying header elements");
                Support.AreEqual(true, FastDriver.ReceiptToFile.ReceiptTableHeader.PerformTableAction(1, 8, TableAction.GetText).Message.Clean().Equals("For Credit Of"), "Verifying header elements");
                Support.AreEqual(true, FastDriver.ReceiptToFile.ReceiptTableHeader.PerformTableAction(1, 9, TableAction.GetText).Message.Clean().Equals("Representing"), "Verifying header elements");
                Support.AreEqual(true, FastDriver.ReceiptToFile.ReceiptTableHeader.PerformTableAction(1, 10, TableAction.GetText).Message.Clean().Equals("Comments"), "Verifying header elements");

                Reports.TestStep = "Validate Wire Amount and editable fields";
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 1, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 1, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 7, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 7, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 8, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 8, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 10, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 10, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual(ReceivedFrom, FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "select").FAGetAllTextFromSelect(", "));
                //Support.AreEqual(Representing, FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.GetText).Message.Clean());
                FastDriver.BottomFrame.Reset();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                FastDriver.WebDriver.HandleDialogMessage();
              

                Reports.TestStep = "Navigate back to Incoming Wires and set item type as ACH ";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("ACH");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(1, 4, TableAction.Click);
                string Date = FastDriver.IncomingWires.SearchResults.PerformTableAction(1, 3, TableAction.GetText).Message.Clean();
                string Amount = FastDriver.IncomingWires.SearchResults.PerformTableAction(1, 4, TableAction.GetText).Message.Clean();
                string Originator = FastDriver.IncomingWires.SearchResults.PerformTableAction(1, 6, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.ReceiptToFile.FAClick();

                Reports.TestStep = "Validate detail fields are as expected for ACH";
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                Support.AreEqual("ACH", FastDriver.ReceiptToFile.Type.Text.Clean());
                Support.AreEqual(Amount.FormatAsMoney(true), FastDriver.ReceiptToFile.Amount.Text.Clean());
                Support.AreEqual(Date, FastDriver.ReceiptToFile.IssueDate.Text.Clean());
                Support.AreEqual(Originator, FastDriver.ReceiptToFile.Originator.Text.Clean());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Deposit_Adjustment_Screen_Warning_Popup()
        {
            try
            {
                #region Data SetUp
                var deposit = new DepositParameters()
                {

                    Amount = 10,
                    TypeofFunds = "Direct Deposit",
                    ReceivedFrom = "Buyer",
                    Representing = "Earnest Money Deposit",
                    Description = "Testing Incoming Wires",
                };
                #endregion

                Reports.TestDescription = "Deposit Adjustment Screen";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Create a File";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Manual.FAClick();
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(Support.RandomString("NNNNNNNN"));
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Manual Check/Receipt Reason");
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Testing IW");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();

                Reports.TestStep = "Verifying Deposit/Receipt History Screen";
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.DepositAdjustment.AdjustmentReason.FAGetAllTextFromSelect(", ").Contains("Cancel"), "Verifying dropdown items under Adjustment Reason dropdown.");
                Support.AreEqual(true, FastDriver.DepositAdjustment.AdjustmentReason.FAGetAllTextFromSelect(", ").Contains("Correct Amount"), "Verifying dropdown items under Adjustment Reason dropdown.");
                Support.AreEqual(true, FastDriver.DepositAdjustment.AdjustmentReason.FAGetAllTextFromSelect(", ").Contains("Correct Document No"), "Verifying dropdown items under Adjustment Reason dropdown.");
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                Support.AreEqual(true, FastDriver.DepositAdjustment.CorrectAmount.IsEnabled(), "Verifying if Correct Amount field is enabled.");
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Document No");
                Support.AreEqual(true, FastDriver.DepositAdjustment.CorrectDocumentNo.IsEnabled(), "Verifying if Correct Amount No. field is enabled.");
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Bank Acct");
                Support.AreEqual(true, FastDriver.DepositAdjustment.CorrectBankAccount.IsEnabled(), "Verifying if Correct Amount No. field is enabled.");
                FastDriver.DepositAdjustment.CorrectComment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Reset();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Transfer/Return/Exclude
        [TestMethod]
        public void BPUC0009_ReturnWiretoBank()
        {
            try
            {
                Reports.TestDescription = "User Returns a Wire";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
                Support.AreEqual(true, FastDriver.IncomingWires.ReturnWire.IsEnabled(), "Verifying if checkbox is enabled. If step failed, please check transaction status.");
                FastDriver.IncomingWires.ReturnWire.FAClick();
                FastDriver.ReturnWire.WaitForScreenToLoad();
                FastDriver.ReturnWire.ReasonOfReturn.FASetText("Returning cash for test purposes." + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Logging in to FAST IIS as Return Wire approver";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);

                Reports.TestStep = "Selecting Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("1487");

                Reports.TestStep = "Locating wire to approve";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(2, "Unapproved", 2, TableAction.Click);
                Support.AreEqual(true, FastDriver.WireDisbursementApproval.ViewDetails.IsEnabled(), "Verifying if checkbox is enabled. Check automated test.");
                FastDriver.WireDisbursementApproval.ViewDetails.FAClick();

                Reports.TestStep = "Approving wire & Saving";
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.IssueWireDisbursement.Approved.IsEnabled(), "Verifying if checkbox is enabled. If step failed, please check access level for user");
                FastDriver.IssueWireDisbursement.Approved.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Transmitting wire.";
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(2, "Approved", 1, TableAction.On);
                FastDriver.WireDisbursementApproval.Transmit.FAClick();

                Reports.TestStep = "Returning to the Incoming Wires screen to confirm that the wire was Transferred";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.IssueDateFrom.FASetText("01-01-2013");
                FastDriver.IncomingWires.Select_Status.FASelectItem("Returned");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, "Returned", 2, TableAction.Click);

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_TransferToAnotherOffice()
        {
            try
            {
                Reports.TestDescription = "User Transfers a Wire to Another Office";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Access Incoming Wires and select an IW transaction and Click on Transfer";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, "Pending", 2, TableAction.Click);
                Support.AreEqual(true, FastDriver.IncomingWires.Transfer.IsEnabled(), "Verifying if checkbox is enabled. If step failed, please check transaction status.");
                FastDriver.IncomingWires.Transfer.FAClick();

                Reports.TestStep = "Enter desired office BUID";
                FastDriver.TransferWire.WaitForScreenToLoad();
                FastDriver.TransferWire.RecipientOfficeBUID.FASetText("191" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Logging in to FAST IIS as Return Wire approver";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);

                Reports.TestStep = "Selecting Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("1487");

                Reports.TestStep = "Locating wire to approve";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(2, "Unapproved", 2, TableAction.Click);
                Support.AreEqual(true, FastDriver.WireDisbursementApproval.ViewDetails.IsEnabled(), "Verifying if checkbox is enabled. Check automated test.");
                FastDriver.WireDisbursementApproval.ViewDetails.FAClick();

                Reports.TestStep = "Approving wire & Saving";
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                Support.value = FastDriver.IssueWireDisbursement.Approved.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. If step failed, please check access level for user");
                FastDriver.IssueWireDisbursement.Approved.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Transmitting wire.";
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(2, "Approved", 1, TableAction.On);
                FastDriver.WireDisbursementApproval.Transmit.FAClick();

                Reports.TestStep = "Returning to the Incoming Wires screen to confirm that the wire was Transferred";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.IssueDateFrom.FASetText("01-01-2013");
                FastDriver.IncomingWires.Select_Status.FASelectItem("Transferred");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, "Transferred", 2, TableAction.Click);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_UserExcludesWire()
        {
            try
            {
                Reports.TestDescription = "User Excludes a Wire";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();

                Reports.TestStep = "Excluding the wire";
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, "Pending", 2, TableAction.Click);
                Support.value = FastDriver.IncomingWires.ExcludeRecover.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. If step failed, please check transaction status.");
                FastDriver.IncomingWires.ExcludeRecover.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.IncomingWires.WaitForScreenToLoad();

                Reports.TestStep = "Recover a wire";
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, "Excluded", 2, TableAction.Click);
                FastDriver.IncomingWires.ExcludeRecover.FAClick();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, "Pending", 2, TableAction.Click);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Wire Posting
        [TestMethod]
        public void BPUC0009_User_Posts_Manual_Receipt()
        {
            try
            {
                Reports.TestDescription = "User posts manual receipts.";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                #region - Data SetUp
                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                string wireAmt = FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(wireAmt);
                decimal deposits = totalamt / 3;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit3 = totalamt - (deposit1 + deposit1);

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Additional Closing Costs",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating File #1 + Creating Deposit #1
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Creating File #2 + Creating Deposit #2
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FileID = CreateFile();
                string fileNumber2 = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber2);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Creating File #3 + Creating Deposit #3
                Reports.TestStep = "Creating a File #3 & creating a deposit";
                FileID = CreateFile();
                string fileNumber3 = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber3);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit3.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo3 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Access Incoming Wires and select the IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                Support.AreEqual(true, FastDriver.IncomingWires.ReceiptToFile.IsEnabled(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 5, TableAction.Click);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 2, TableAction.SetText, fileNumber3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 4, TableAction.SetText, ReceiptNo3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                #endregion
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_User_cancel_a_receipt_in_a_split_wire()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                #region - Data SetUp
                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                string wireAmt = FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(wireAmt);
                decimal deposits = totalamt / 2;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit2 = totalamt - deposit1;

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Additional Closing Costs",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Creating file #2 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FileID = CreateFile();
                string fileNumber2 = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber2);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit2.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_User_Cancels_Both_Receipt_In_A_Split_Wire()
        {
            try
            {
                Reports.TestDescription = "User cancels both receipts in a split wire";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                #region - Data SetUp
                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                string wireAmt = FastDriver.IncomingWires.SearchResults.PerformTableAction(5, 4, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(5, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(wireAmt);
                decimal deposits = totalamt / 2;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit2 = totalamt - deposit1;

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Additional Closing Costs",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Creating file #2 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FileID = CreateFile();
                string fileNumber2 = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber2);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit2.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(5, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling 2nd Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Cancelling 1st Receipt
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                #endregion
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_User_Cancels_Both_Receipt_In_A_Wire_And_Use_Same_Receipt()
        {
            try
            {
                Reports.TestDescription = "User cancels both receipts in a wire and uses same receipt";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                #region - Data SetUp
                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                string wireAmt = FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(wireAmt);
                decimal deposits = totalamt / 2;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit2 = totalamt - deposit1;

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Additional Closing Costs",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Creating file #2 and adding manual deposit
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FileID = CreateFile();
                string fileNumber2 = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber2);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit2.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling 2nd Receipt
                Reports.TestStep = "Cancelling 2nd Receipt";
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Cancelling 1st Receipt
                Reports.TestStep = "Cancelling 1st Receipt";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Creating file #3 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FileID = CreateFile();
                string fileNumber3 = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber3);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(totalamt.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo3 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Posting 3rd receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Reposting 1st Receipt
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Receipt_Adjustments()
        {
            try
            {
                Reports.TestDescription = "Receipt Adjustment";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                #region - Data SetUp
                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                string wireAmt = FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(wireAmt);

                var deposit = new DepositParameters
                {
                    Amount = (double)totalamt,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Additional Closing Costs",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Verifying that Wire reverted to Pending Status
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.Click);
                #endregion
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Using_Adjusted_Receipt_For_Same_IW()
        {
            try
            {
                Reports.TestDescription = "Using Adjusted Receipt for Same IW";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                #region - Data SetUp
                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                string wireAmt = FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(wireAmt);

                var deposit = new DepositParameters
                {
                    Amount = (double)totalamt,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Additional Closing Costs",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Access Incoming Wires and select the IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region RePosting Same Receipt to a Wire
                Reports.TestStep = "Access Incoming Wires and select the IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Using_Adjusted_Receipt_For_Diff_IW()
        {
            try
            {
                Reports.TestDescription = "Using Adjusted Receipt for Different IW";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                #region - Data SetUp
                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                string wireAmt = FastDriver.IncomingWires.SearchResults.PerformTableAction(9, 4, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(9, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(wireAmt);

                var deposit = new DepositParameters
                {
                    Amount = (double)totalamt,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Additional Closing Costs",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Access Incoming Wires and select the IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(9, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                Reports.TestStep = "Cancelling Receipt";
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region RePosting Same Receipt to a Different Wire
                Reports.TestStep = "Access Incoming Wires and select the IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Posting_Wire_To_Single_File()
        {
            try
            {
                Reports.TestDescription = "Using Adjusted Receipt for Different IW";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                #region - Data SetUp
                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                string wireAmt = FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(wireAmt);

                var deposit = new DepositParameters
                {
                    Amount = (double)totalamt,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Additional Closing Costs",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Posting Wire
                Reports.TestStep = "Access Incoming Wires and select the IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.SelectItem, "Buyer");
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.SelectItem, "Additional Closing Costs");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Posting_Wire_To_Multiple_Files()
        {
            try
            {
                Reports.TestDescription = "Posting Wire to a Multiple Files";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                #region - Data SetUp
                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                string wireAmt = FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(wireAmt);
                decimal deposits = totalamt / 3;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit3 = totalamt - (deposit1 + deposit1);
                #endregion

                #region Creating file
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Creating file
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FileID = CreateFile();
                string fileNumber2 = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber2);
                #endregion

                #region Creating file
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FileID = CreateFile();
                string fileNumber3 = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber3);
                #endregion

                #region Posting Wire
                Reports.TestStep = "Access Incoming Wires and select the IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.Click);
                Support.AreEqual(true, FastDriver.IncomingWires.ReceiptToFile.IsEnabled(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.SetText, deposit1.ToString());
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.SelectItem, "Buyer");
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.SelectItem, "Additional Closing Costs");
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 5, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 5, TableAction.SetText, deposit1.ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 6, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 6, TableAction.SelectItem, "Seller");
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 9, TableAction.SelectItem, "Additional Closing Costs");
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 2, TableAction.SetText, fileNumber3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 5, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 5, TableAction.SetText, deposit3.ToString());
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 6, TableAction.SelectItem, "Buyer");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 9, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 9, TableAction.SelectItem, "Additional Closing Costs");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Checking Wire is listed as Complete
                Reports.TestStep = "Returning to the Incoming Wires screen to confirm that the wire was Transferred";
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.IssueDateFrom.FASetText("01-01-2013");
                FastDriver.IncomingWires.Select_Status.FASelectItem("Completed");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.IncomingWires.SearchResults.PerformTableAction(4, wireAmt, 2, TableAction.GetText).Message.Clean().Equals("Completed"), "Verifying that wire appears as completed.");
                #endregion
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_RePosts_Receipt_Posted_to_Another_file()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                #region - Data SetUp
                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                string wireAmt = FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(wireAmt);

                var deposit = new DepositParameters
                {
                    Amount = (double)totalamt,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Additional Closing Costs",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Access Incoming Wires and select the IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                Support.AreEqual(true, FastDriver.IncomingWires.ReceiptToFile.IsEnabled(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FileID = CreateFile();
                string fileNumber2 = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber2);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Reposting 1st Receipt
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_User_Changes_Amount_Of_IW_Receipted_to_Multiple_Files()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Log in to FAST IIS";
                Login(AutoConfig.FASTHomeURL, AutoConfig.UserName, AutoConfig.UserPassword);

                #region - Data SetUp
                Reports.TestStep = "Access Incoming Wires and select an IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                string wireAmt = FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(wireAmt);
                decimal deposits = totalamt / 2;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit2 = totalamt - deposit1;

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Additional Closing Costs",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Creating file #2 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FileID = CreateFile();
                string fileNumber2 = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber2);

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit2.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Access Incoming Wires and select the IW transaction.";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Changing Amount for all receipts included in the wire
                Reports.TestStep = "Changing Amount for all receipts included in the wire";
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                FastDriver.DepositAdjustment.Comment.FASetText("Changing the Amount of the Receipt");
                decimal newdeposit = deposit1 - (decimal)0.01;
                deposit2 = deposit2 + (decimal)0.01;
                FastDriver.DepositAdjustment.CorrectAmount.FASetText(newdeposit.ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.ReceiptAdjustmentDlg.WaitForScreenToLoad();
                FastDriver.ReceiptAdjustmentDlg.RASearchResults.PerformTableAction(2, 4, TableAction.SetText, deposit2.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region - Exchange/Expresso Delay IW Test Cases

        #region Screen Checks for Exchange/Expresso Delay

        [TestMethod]
        public void BPUC0009_IncomingWiresScreen_Delay()
        {
            try
            {
                Reports.TestDescription = "Incoming Wires Screen";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                Support.value = FastDriver.IncomingWires.Select_BankAcct.Text;
                Support.AreEqual("True", Support.value.Contains("All Accounts").ToString());
                Support.AreEqual("True", Support.value.Contains("9993109200000").ToString());

                Reports.TestStep = "Testing Delivery method dropdown menu";
                Support.value = FastDriver.IncomingWires.Select_Method.Text;
                Support.AreEqual("True", Support.value.Contains("Print").ToString());
                Support.AreEqual("True", Support.value.Contains("Preview").ToString());
                Support.AreEqual("True", Support.value.Contains("Email").ToString());
                Support.AreEqual("True", Support.value.Contains("Fax").ToString());

                Reports.TestStep = "Verifying default value in DateFrom and DateTo fields";

                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.IncomingWires.IssueDateFrom.FAGetValue());
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.IncomingWires.IssueDateTo.FAGetValue());

                Support.value = FastDriver.IncomingWires.Select_Status.Text;
                Support.AreEqual("True", Support.value.Contains("All").ToString());
                Support.AreEqual("True", Support.value.Contains("Completed").ToString());
                Support.AreEqual("True", Support.value.Contains("Excluded").ToString());
                Support.AreEqual("True", Support.value.Contains("Manual Receipt").ToString());
                Support.AreEqual("True", Support.value.Contains("Pending").ToString());
                Support.AreEqual("True", Support.value.Contains("Pending Approval").ToString());
                Support.AreEqual("True", Support.value.Contains("Returned").ToString());
                Support.AreEqual("True", Support.value.Contains("Transferred").ToString());

                Reports.TestStep = "Testing Item Type dropdown menu";
                Support.value = FastDriver.IncomingWires.Select_ItemType.Text;
                Support.AreEqual("True", Support.value.Contains("All").ToString());
                Support.AreEqual("True", Support.value.Contains("ACH").ToString());
                Support.AreEqual("True", Support.value.Contains("IW").ToString());

                Reports.TestStep = "Verifying Search Results column headers";
                Support.AreEqual("Type", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[0].Text);
                Support.AreEqual("Status", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[1].Text);
                Support.AreEqual("Receive Date", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[2].Text);
                Support.AreEqual("Amount", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[3].Text);
                Support.AreEqual("Sending Bank", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[4].Text);
                Support.AreEqual("Originator", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[5].Text);
                Support.AreEqual("OBI", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[6].Text);
                Support.AreEqual("File #", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[7].Text);

                Reports.TestStep = "Verifying Action Button exist";
                Support.AreEqual("True", FastDriver.IncomingWires.ViewDetails.Exists().ToString());
                Support.AreEqual("True", FastDriver.IncomingWires.ExcludeRecover.Exists().ToString());
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Exists().ToString());
                Support.AreEqual("True", FastDriver.IncomingWires.Transfer.Exists().ToString());
                Support.AreEqual("True", FastDriver.IncomingWires.ReturnWire.Exists().ToString());

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_IncomingWiresSearchScreen_Delay()
        {
            try
            {
                Reports.TestDescription = "Incoming Wires Search Screen";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();

                Reports.TestStep = "Checking Status Dropdown Values";
                Support.value = FastDriver.IncomingWires.Select_Status.Text;
                Support.AreEqual("True", Support.value.Contains("All").ToString());
                Support.AreEqual("True", Support.value.Contains("Completed").ToString());
                Support.AreEqual("True", Support.value.Contains("Excluded").ToString());
                Support.AreEqual("True", Support.value.Contains("Manual Receipt").ToString());
                Support.AreEqual("True", Support.value.Contains("Pending").ToString());
                Support.AreEqual("True", Support.value.Contains("Pending Approval").ToString());
                Support.AreEqual("True", Support.value.Contains("Returned").ToString());
                Support.AreEqual("True", Support.value.Contains("Transferred").ToString());

                Reports.TestStep = "Checking IW Type Dropdown Values";
                Support.value = FastDriver.IncomingWires.Select_ItemType.Text;
                Support.AreEqual("True", Support.value.Contains("All").ToString());
                Support.AreEqual("True", Support.value.Contains("ACH").ToString());
                Support.AreEqual("True", Support.value.Contains("IW").ToString());

                Reports.TestStep = "Choose an Item type and validates wires are filtered by that item type";
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "IW", "#1", TableAction.Click);
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("ACH");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "ACH", "#1", TableAction.Click);
            }
            catch (Exception)
            {

                throw;
            }

        }

        [TestMethod]
        public void BPUC0009_IncomingWiresViewDetailsScreen_Delay()
        {
            try
            {
                Reports.TestDescription = "Incoming Wires View Details Screen (IW)";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();

                Reports.TestStep = "Choose an Item type and validates wires are filtered by that item type";
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "IW", "#1", TableAction.Click);

                Reports.TestStep = "Enter View Details Screen and validate Delivery Methods";
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "IW", "#1", TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ViewDetails.Enabled.ToString());
                Support.value = FastDriver.IncomingWires.ViewDetails.Enabled.ToString();
                if (Support.value == "False")
                {
                    Reports.StatusUpdate("View Details button is disabled", false);
                }

                FastDriver.IncomingWires.ViewDetails.FAClick();
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.IncomingWireViewDetails.Method.Enabled.ToString());
                Support.value = FastDriver.IncomingWireViewDetails.Method.Text;
                Support.AreEqual("True", Support.value.Contains("Print").ToString());
                Support.AreEqual("True", Support.value.Contains("Preview").ToString());
                Support.AreEqual("True", Support.value.Contains("Email").ToString());

                Reports.TestStep = "Validate that the Print Dialog exists";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Print");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Preview Method screen";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Preview");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);
                FastDriver.WebDriver.ClosePreviewWindow();
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Email Method screen";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Email");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 20);
                FastDriver.EmailDlg.ToText.FASetText(AutoConfig.DeliverEmailTo, clearFirst: false); // Starting from v10.03.0003 build, it doesn't work if not passing clearFirst: false
                FastDriver.EmailDlg.Subject.FASetText(Environment.MachineName + " - IncomingWires Testing");
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_IncomingWiresACHDetails_Delay()
        {
            try
            {
                Reports.TestDescription = "Incoming Wires View Details Screen (ACH)";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();

                Reports.TestStep = "Choose an Item type and validates wires are filtered by that item type";
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("ACH");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "ACH", "#1", TableAction.Click);
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("ACH");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();

                Reports.TestStep = "Enter View Details Screen and validate Delivery Methods";
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "ACH", "#1", TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ViewDetails.Enabled.ToString());
                Support.value = FastDriver.IncomingWires.ViewDetails.Enabled.ToString();
                if (Support.value == "False")
                {
                    Reports.StatusUpdate("View Details button is disabled", false);
                }

                FastDriver.IncomingWires.ViewDetails.FAClick();
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.IncomingWireViewDetails.Method.Enabled.ToString());
                Support.value = FastDriver.IncomingWireViewDetails.Method.Text;
                Support.AreEqual("True", Support.value.Contains("Print").ToString());
                Support.AreEqual("True", Support.value.Contains("Preview").ToString());
                Support.AreEqual("True", Support.value.Contains("Email").ToString());

                Reports.TestStep = "Validate that the Print Dialog exists";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Print");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Preview Method screen";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Preview");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);
                FastDriver.WebDriver.ClosePreviewWindow();
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Email Method screen";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Email");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 20);
                FastDriver.EmailDlg.ToText.FASetText(AutoConfig.DeliverEmailTo, clearFirst: false); // Starting from v10.03.0003 build, it doesn't work if not passing clearFirst: false
                FastDriver.EmailDlg.Subject.FASetText(Environment.MachineName + " - IncomingWires Testing");
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_TransferWireScreen_Delay()
        {
            try
            {
                Reports.TestDescription = "Transfer Wire Screen";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
                Support.value = FastDriver.IncomingWires.Transfer.Enabled.ToString();
                if (Support.value == "False")
                {
                    Reports.StatusUpdate("Transfer button is disabled", false);
                }
                FastDriver.IncomingWires.Transfer.FAClick();
                FastDriver.TransferWire.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.TransferWire.RecipientOfficeBUID.Exists().ToString());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_ReturnWireScreen_Delay()
        {
            try
            {
                Reports.TestDescription = "Return Wire Screen";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
                Support.value = FastDriver.IncomingWires.ReturnWire.Enabled.ToString();
                if (Support.value == "False")
                {
                    Reports.StatusUpdate("Return button is disabled", false);
                }
                FastDriver.IncomingWires.ReturnWire.FAClick();
                FastDriver.ReturnWire.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ReturnWire.ReasonOfReturn.Exists().ToString());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_ReceiptToFileScreen_Delay()
        {
            try
            {
                Reports.TestDescription = "Receipt to File Screen";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.Click);

                var deposit = new DepositParameters()
                {

                    Amount = double.Parse(Support.data),
                    TypeofFunds = "Direct Deposit",
                    ReceivedFrom = "Buyer",
                    Representing = "Earnest Money Deposit",
                    Description = "Testing Incoming Wires",
                };
                #endregion

                #region - Create file, add manual deposit
                Reports.TestStep = "Creating file in IIS";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo = FastDriver.DepositInEscrow.ReceiptNo.Text.Clean();
                string Representing = FastDriver.DepositInEscrow.Representing.Text.Clean();
                string ReceivedFrom = FastDriver.DepositInEscrow.ReceivedFrom.Text.Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                Reports.TestStep = "Checking Receipt to File screen";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying if Receipt To File button is enabled. If step fails, please check transaction status.");
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();

                Reports.TestStep = "Verifying Search Results column headers";
                Support.AreEqual("BUID", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[0].Text);
                Support.AreEqual("File Number", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[1].Text);
                Support.AreEqual("MR", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[2].Text);
                Support.AreEqual("Receipt #", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[3].Text);
                Support.AreEqual("Amount", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[4].Text);
                Support.AreEqual("Received From", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[5].Text);
                Support.AreEqual("Payor", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[6].Text);
                Support.AreEqual("For Credit Of", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[7].Text);
                Support.AreEqual("Representing", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[8].Text);
                Support.AreEqual("Comments", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[9].Text);

                Reports.TestStep = "Validate Wire Amount and editable fields";
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 1, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 1, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.GetCell).Element.Enabled.ToString());
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 7, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 7, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 8, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 8, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 10, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 10, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual(ReceivedFrom, FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.GetText).Message.Clean());
                Support.AreEqual(Representing, FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "dgRF_0_ddlRepresenting").Text.Clean());
                FastDriver.BottomFrame.Reset();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                FastDriver.WebDriver.HandleDialogMessage();


                Reports.TestStep = "Navigate back to Incoming Wires and set item type as ACH ";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("ACH");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(1, 4, TableAction.Click);
                string Date = FastDriver.IncomingWires.SearchResults.PerformTableAction(1, 3, TableAction.GetText).Message.Clean();
                string Amount = FastDriver.IncomingWires.SearchResults.PerformTableAction(1, 4, TableAction.GetText).Message.Clean();
                string Originator = FastDriver.IncomingWires.SearchResults.PerformTableAction(1, 6, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.ReceiptToFile.FAClick();

                Reports.TestStep = "Validate detail fields are as expected for ACH";
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                Support.AreEqual("ACH", FastDriver.ReceiptToFile.Type.Text.Clean());
                Support.AreEqual(Amount.FormatAsMoney(true), FastDriver.ReceiptToFile.Amount.Text.Clean());
                Support.AreEqual(Date, FastDriver.ReceiptToFile.IssueDate.Text.Clean());
                Support.AreEqual(Originator, FastDriver.ReceiptToFile.Originator.Text.Clean());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Deposit_Adjustment_Screen_Warning_Popup_Delay()
        {
            try
            {
                #region Data SetUp
                var deposit = new DepositParameters()
                {

                    Amount = 10,
                    TypeofFunds = "Direct Deposit",
                    ReceivedFrom = "Buyer",
                    Representing = "Earnest Money Deposit",
                    Description = "Testing Incoming Wires",
                };
                #endregion

                Reports.TestDescription = "Deposit Adjustment Screen";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                Reports.TestStep = "Create a File";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Manual.FAClick();
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(Support.RandomString("NNNNNNNN"));
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Manual Check/Receipt Reason");
                FastDriver.ManualCheckReceiptReason.WaitCreation(FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason, 10);
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Testing IW");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();

                Reports.TestStep = "Verifying Deposit/Receipt History Screen";
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();

                Support.value = FastDriver.DepositAdjustment.AdjustmentReason.Text;
                Support.AreEqual("True", Support.value.Contains("Cancel").ToString());
                Support.AreEqual("True", Support.value.Contains("Correct Amount").ToString());
                Support.AreEqual("True", Support.value.Contains("Correct Document No").ToString());
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                Support.AreEqual("True", FastDriver.DepositAdjustment.CorrectAmount.Enabled.ToString());
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Document No");
                Support.AreEqual("True", FastDriver.DepositAdjustment.CorrectDocumentNo.Enabled.ToString());
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Bank Acct");
                Support.AreEqual("True", FastDriver.DepositAdjustment.CorrectBankAccount.Enabled.ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Reset();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        #endregion

        #region Transfer/Return/Exclude
        [TestMethod]
        public void BPUC0009_ReturnWiretoBank_Delay()
        {
            try
            {
                Reports.TestDescription = "User Returns a Wire";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
                Support.value = FastDriver.IncomingWires.ReturnWire.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. If step failed, please check transaction status.");
                FastDriver.IncomingWires.ReturnWire.FAClick();
                FastDriver.ReturnWire.WaitForScreenToLoad();
                FastDriver.ReturnWire.ReasonOfReturn.FASetText("Returning cash for test purposes.");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Logging in to FAST IIS as Return Wire approver";
                Login("Home", "User_Name2", "User_Password2");

                Reports.TestStep = "Selecting Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                Reports.TestStep = "Locating wire to approve";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Status", "Unapproved", "Status", TableAction.Click);
                Support.value = FastDriver.WireDisbursementApproval.ViewDetails.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. Check automated test.");

                FastDriver.WireDisbursementApproval.ViewDetails.FAClick();

                Reports.TestStep = "Approving wire & Saving";
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                Support.value = FastDriver.IssueWireDisbursement.Approved.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. If step failed, please check access level for user");
                FastDriver.IssueWireDisbursement.Approved.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Status", "Approved", "Sel", TableAction.On);
                FastDriver.WireDisbursementApproval.Transmit.FAClick();

                Reports.TestStep = "Returning to the Incoming Wires screen to confirm that the wire was Transferred";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.IssueDateFrom.FASetText("01-01-2013");
                FastDriver.IncomingWires.Select_Status.FASelectItem("Returned");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Returned", "Status", TableAction.Click);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_TransferToAnotherOffice_Delay()
        {
            try
            {
                Reports.TestDescription = "User Transfers a Wire to Another Office";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
                Support.value = FastDriver.IncomingWires.Transfer.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. If step failed, please check transaction status.");
                FastDriver.IncomingWires.Transfer.FAClick();
                FastDriver.TransferWire.WaitForScreenToLoad();
                FastDriver.TransferWire.RecipientOfficeBUID.FASetText("191");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Logging in to FAST IIS as Return Wire approver";
                Login("Home", "User_Name2", "User_Password2");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                Reports.TestStep = "Locating wire to approve";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Status", "Unapproved", "Status", TableAction.Click);
                Support.value = FastDriver.WireDisbursementApproval.ViewDetails.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. Check automated test.");

                FastDriver.WireDisbursementApproval.ViewDetails.FAClick();

                Reports.TestStep = "Approving wire & Saving";
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                Support.value = FastDriver.IssueWireDisbursement.Approved.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. If step failed, please check access level for user");
                FastDriver.IssueWireDisbursement.Approved.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Status", "Approved", "Sel", TableAction.On);
                FastDriver.WireDisbursementApproval.Transmit.FAClick();

                Reports.TestStep = "Returning to the Incoming Wires screen to confirm that the wire was Transferred";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.IssueDateFrom.FASetText("01-01-2013");
                FastDriver.IncomingWires.Select_Status.FASelectItem("Transferred");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Transferred", "Status", TableAction.Click);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_UserExcludesWire_Delay()
        {
            try
            {
                Reports.TestDescription = "User Excludes a Wire";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();

                Reports.TestStep = "Excluding the wire";
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
                Support.value = FastDriver.IncomingWires.ExcludeRecover.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. If step failed, please check transaction status.");
                FastDriver.IncomingWires.ExcludeRecover.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.IncomingWires.WaitForScreenToLoad();

                Reports.TestStep = "Recover a wire";
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Excluded", "#2", TableAction.Click);
                FastDriver.IncomingWires.ExcludeRecover.FAClick();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }
        #endregion

        #region IW Wire Posting
        [TestMethod]
        public void BPUC0009_User_Posts_Manual_Receipt_Delay()
        {
            try
            {
                Reports.TestDescription = "User posts manual receipts.";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);
                decimal deposits = totalamt / 3;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit3 = totalamt - (deposit1 + deposit1);

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Miscelleaneous Funds",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating File #1 + Creating Deposit #1
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Creating File #2 + Creating Deposit #2
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Creating File #3 + Creating Deposit #3
                Reports.TestStep = "Creating a File #3 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit3.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo3 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber3 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 5, TableAction.Click);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 2, TableAction.SetText, fileNumber3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 4, TableAction.SetText, ReceiptNo3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                #endregion
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_User_cancel_a_receipt_in_a_split_wire_Delay()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);
                decimal deposits = totalamt / 2;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit2 = totalamt - deposit1;

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Miscelleaneous Funds",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Creating file #2 and adding manual deposit
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit2.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_User_Cancels_Both_Receipt_In_A_Split_Wire_Delay()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(5, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(5, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);
                decimal deposits = totalamt / 2;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit2 = totalamt - deposit1;

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Miscelleaneous Funds",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Creating file #2 and adding manual deposit
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit2.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(5, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Cancelling 1st Receipt
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_User_Cancels_Both_Receipt_In_A_Wire_And_Use_Same_Receipt_Delay()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);
                decimal deposits = totalamt / 2;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit2 = totalamt - deposit1;

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Miscelleaneous Funds",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Creating file #2 and adding manual deposit
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit2.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Cancelling 1st Receipt
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Creating file #3 and adding manual deposit
                Reports.TestStep = "Creating a File #3 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(totalamt.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo3 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber3 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting 3rd receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Reposting 1st Receipt
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Receipt_Adjustments_Delay()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);

                var deposit = new DepositParameters
                {
                    Amount = (double)totalamt,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Miscelleaneous Funds",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Verify IW reverted to Pending Status
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.Click);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Using_Adjusted_Receipt_For_Same_IW_Delay()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);

                var deposit = new DepositParameters
                {
                    Amount = (double)totalamt,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Miscelleaneous Funds",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region RePosting Same Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Using_Adjusted_Receipt_For_Diff_IW_Delay()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(9, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(9, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);

                var deposit = new DepositParameters
                {
                    Amount = (double)totalamt,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Miscelleaneous Funds",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(9, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region RePosting Same Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Posting_Wire_To_Single_File_Delay()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                #region Creating file #1
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");
                #endregion

                #region Posting Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad(); 
                FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.SelectItem, "Buyer");
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.SelectItem, "Miscelleaneous Funds");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Posting_Wire_To_Multiple_Files_Delay()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);
                decimal deposits = totalamt / 3;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit3 = totalamt - (deposit1 + deposit1);

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Miscelleaneous Funds",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");
                #endregion

                #region Creating file #2
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");
                #endregion

                #region Creating file #3
                Reports.TestStep = "Creating a File #3 & creating a deposit";
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");
                #endregion

                #region Posting wires
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber3 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.SetText, deposit1.ToString());
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.SelectItem, "Buyer");
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.SelectItem, "Miscelleaneous Funds");
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 5, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 5, TableAction.SetText, deposit1.ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 6, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 6, TableAction.SelectItem, "Buyer");
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 9, TableAction.SelectItem, "Miscelleaneous Funds");
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 2, TableAction.SetText, fileNumber3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 5, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 5, TableAction.SetText, deposit3.ToString());
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 6, TableAction.SelectItem, "Buyer");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 9, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 9, TableAction.SelectItem, "Miscelleaneous Funds");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_RePosts_Receipt_Posted_to_Another_file_Delay()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);

                var deposit = new DepositParameters
                {
                    Amount = (double)totalamt,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Miscelleaneous Funds",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Creating File #2 + Creating Deposit #2
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Reposting 1st Receipt
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_User_Changes_Amount_Of_IW_Receipted_to_Multiple_Files_Delay()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12611");

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);
                decimal deposits = totalamt / 2;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit2 = totalamt - deposit1;

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Miscelleaneous Funds",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Buyer",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Creating File #2 + Creating Deposit #2
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Delayed", "zz-Exchange Delay FAST Admin Office PR: eSTEST off: 9999(12611)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit2.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Changing Amount for all receipts included in the wire
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                FastDriver.DepositAdjustment.Comment.FASetText("Changing the Amount of the Receipt");
                decimal newdeposit = deposit1 - (decimal)0.01;
                deposit2 = deposit2 + (decimal)0.01;
                FastDriver.DepositAdjustment.CorrectAmount.FASetText(newdeposit.ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.ReceiptAdjustmentDlg.WaitForScreenToLoad();
                FastDriver.ReceiptAdjustmentDlg.RASearchResults.PerformTableAction(2, 4, TableAction.SetText, deposit2.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region - Exchange/Expresso Reverse IW Test Cases

        #region Screen Checks for Exchange/Expresso Reverse

        [TestMethod]
        public void BPUC0009_IncomingWiresScreen_Reverse()
        {
            try
            {
                Reports.TestDescription = "Incoming Wires Screen";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                Support.value = FastDriver.IncomingWires.Select_BankAcct.Text;
                Support.AreEqual("True", Support.value.Contains("All Accounts").ToString());
                Support.AreEqual("True", Support.value.Contains("9993109200000").ToString());

                Reports.TestStep = "Testing Delivery method dropdown menu";
                Support.value = FastDriver.IncomingWires.Select_Method.Text;
                Support.AreEqual("True", Support.value.Contains("Print").ToString());
                Support.AreEqual("True", Support.value.Contains("Preview").ToString());
                Support.AreEqual("True", Support.value.Contains("Email").ToString());
                Support.AreEqual("True", Support.value.Contains("Fax").ToString());

                Reports.TestStep = "Verifying default value in DateFrom and DateTo fields";

                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.IncomingWires.IssueDateFrom.FAGetValue());
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.IncomingWires.IssueDateTo.FAGetValue());

                Support.value = FastDriver.IncomingWires.Select_Status.Text;
                Support.AreEqual("True", Support.value.Contains("All").ToString());
                Support.AreEqual("True", Support.value.Contains("Completed").ToString());
                Support.AreEqual("True", Support.value.Contains("Excluded").ToString());
                Support.AreEqual("True", Support.value.Contains("Manual Receipt").ToString());
                Support.AreEqual("True", Support.value.Contains("Pending").ToString());
                Support.AreEqual("True", Support.value.Contains("Pending Approval").ToString());
                Support.AreEqual("True", Support.value.Contains("Returned").ToString());
                Support.AreEqual("True", Support.value.Contains("Transferred").ToString());

                Reports.TestStep = "Testing Item Type dropdown menu";
                Support.value = FastDriver.IncomingWires.Select_ItemType.Text;
                Support.AreEqual("True", Support.value.Contains("All").ToString());
                Support.AreEqual("True", Support.value.Contains("ACH").ToString());
                Support.AreEqual("True", Support.value.Contains("IW").ToString());

                Reports.TestStep = "Verifying Search Results column headers";
                Support.AreEqual("Type", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[0].Text);
                Support.AreEqual("Status", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[1].Text);
                Support.AreEqual("Receive Date", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[2].Text);
                Support.AreEqual("Amount", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[3].Text);
                Support.AreEqual("Sending Bank", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[4].Text);
                Support.AreEqual("Originator", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[5].Text);
                Support.AreEqual("OBI", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[6].Text);
                Support.AreEqual("File #", FastDriver.IncomingWires.SearchResultsHeader.FindElements(By.TagName("TD"))[7].Text);

                Reports.TestStep = "Verifying Action Button exist";
                Support.AreEqual("True", FastDriver.IncomingWires.ViewDetails.Exists().ToString());
                Support.AreEqual("True", FastDriver.IncomingWires.ExcludeRecover.Exists().ToString());
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Exists().ToString());
                Support.AreEqual("True", FastDriver.IncomingWires.Transfer.Exists().ToString());
                Support.AreEqual("True", FastDriver.IncomingWires.ReturnWire.Exists().ToString());

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_IncomingWiresSearchScreen_Reverse()
        {
            try
            {
                Reports.TestDescription = "Incoming Wires Search Screen";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();

                Reports.TestStep = "Checking Status Dropdown Values";
                Support.value = FastDriver.IncomingWires.Select_Status.Text;
                Support.AreEqual("True", Support.value.Contains("All").ToString());
                Support.AreEqual("True", Support.value.Contains("Completed").ToString());
                Support.AreEqual("True", Support.value.Contains("Excluded").ToString());
                Support.AreEqual("True", Support.value.Contains("Manual Receipt").ToString());
                Support.AreEqual("True", Support.value.Contains("Pending").ToString());
                Support.AreEqual("True", Support.value.Contains("Pending Approval").ToString());
                Support.AreEqual("True", Support.value.Contains("Returned").ToString());
                Support.AreEqual("True", Support.value.Contains("Transferred").ToString());

                Reports.TestStep = "Checking IW Type Dropdown Values";
                Support.value = FastDriver.IncomingWires.Select_ItemType.Text;
                Support.AreEqual("True", Support.value.Contains("All").ToString());
                Support.AreEqual("True", Support.value.Contains("ACH").ToString());
                Support.AreEqual("True", Support.value.Contains("IW").ToString());

                Reports.TestStep = "Choose an Item type and validates wires are filtered by that item type";
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "IW", "#1", TableAction.Click);
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("ACH");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "ACH", "#1", TableAction.Click);
            }
            catch (Exception)
            {

                throw;
            }

        }

        [TestMethod]
        public void BPUC0009_IncomingWiresViewDetailsScreen_Reverse()
        {
            try
            {
                Reports.TestDescription = "Incoming Wires View Details Screen (IW)";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();

                Reports.TestStep = "Choose an Item type and validates wires are filtered by that item type";
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "IW", "#1", TableAction.Click);

                Reports.TestStep = "Enter View Details Screen and validate Delivery Methods";
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "IW", "#1", TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ViewDetails.Enabled.ToString());
                Support.value = FastDriver.IncomingWires.ViewDetails.Enabled.ToString();
                if (Support.value == "False")
                {
                    Reports.StatusUpdate("View Details button is disabled", false);
                }

                FastDriver.IncomingWires.ViewDetails.FAClick();
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.IncomingWireViewDetails.Method.Enabled.ToString());
                Support.value = FastDriver.IncomingWireViewDetails.Method.Text;
                Support.AreEqual("True", Support.value.Contains("Print").ToString());
                Support.AreEqual("True", Support.value.Contains("Preview").ToString());
                Support.AreEqual("True", Support.value.Contains("Email").ToString());

                Reports.TestStep = "Validate that the Print Dialog exists";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Print");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Preview Method screen";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Preview");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);
                FastDriver.WebDriver.ClosePreviewWindow();
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Email Method screen";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Email");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 20);
                FastDriver.EmailDlg.ToText.FASetText(AutoConfig.DeliverEmailTo, clearFirst: false); // Starting from v10.03.0003 build, it doesn't work if not passing clearFirst: false
                FastDriver.EmailDlg.Subject.FASetText(Environment.MachineName + " - IncomingWires Testing");
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_IncomingWiresACHDetails_Reverse()
        {
            try
            {
                Reports.TestDescription = "Incoming Wires View Details Screen (ACH)";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();

                Reports.TestStep = "Choose an Item type and validates wires are filtered by that item type";
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("ACH");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "ACH", "#1", TableAction.Click);
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("ACH");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();

                Reports.TestStep = "Enter View Details Screen and validate Delivery Methods";
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Type", "ACH", "#1", TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ViewDetails.Enabled.ToString());
                Support.value = FastDriver.IncomingWires.ViewDetails.Enabled.ToString();
                if (Support.value == "False")
                {
                    Reports.StatusUpdate("View Details button is disabled", false);
                }

                FastDriver.IncomingWires.ViewDetails.FAClick();
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.IncomingWireViewDetails.Method.Enabled.ToString());
                Support.value = FastDriver.IncomingWireViewDetails.Method.Text;
                Support.AreEqual("True", Support.value.Contains("Print").ToString());
                Support.AreEqual("True", Support.value.Contains("Preview").ToString());
                Support.AreEqual("True", Support.value.Contains("Email").ToString());

                Reports.TestStep = "Validate that the Print Dialog exists";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Print");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Preview Method screen";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Preview");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);
                FastDriver.WebDriver.ClosePreviewWindow();
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Email Method screen";
                FastDriver.IncomingWireViewDetails.Method.FASelectItem("Email");
                FastDriver.IncomingWireViewDetails.Deliver.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 20);
                FastDriver.EmailDlg.ToText.FASetText(AutoConfig.DeliverEmailTo, clearFirst: false); // Starting from v10.03.0003 build, it doesn't work if not passing clearFirst: false
                FastDriver.EmailDlg.Subject.FASetText(Environment.MachineName + " - IncomingWires Testing");
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.IncomingWireViewDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_TransferWireScreen_Reverse()
        {
            try
            {
                Reports.TestDescription = "Transfer Wire Screen";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
                Support.value = FastDriver.IncomingWires.Transfer.Enabled.ToString();
                if (Support.value == "False")
                {
                    Reports.StatusUpdate("Transfer button is disabled", false);
                }
                FastDriver.IncomingWires.Transfer.FAClick();
                FastDriver.TransferWire.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.TransferWire.RecipientOfficeBUID.Exists().ToString());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_ReturnWireScreen_Reverse()
        {
            try
            {
                Reports.TestDescription = "Return Wire Screen";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
                Support.value = FastDriver.IncomingWires.ReturnWire.Enabled.ToString();
                if (Support.value == "False")
                {
                    Reports.StatusUpdate("Return button is disabled", false);
                }
                FastDriver.IncomingWires.ReturnWire.FAClick();
                FastDriver.ReturnWire.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ReturnWire.ReasonOfReturn.Exists().ToString());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_ReceiptToFileScreen_Reverse()
        {
            try
            {
                Reports.TestDescription = "Receipt to File Screen";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.Click);

                var deposit = new DepositParameters()
                {

                    Amount = double.Parse(Support.data),
                    TypeofFunds = "Direct Deposit",
                    ReceivedFrom = "Seller",
                    Representing = "Deposit",
                    Description = "Testing Incoming Wires",
                };
                #endregion

                #region - Create file, add manual deposit
                Reports.TestStep = "Creating file in IIS";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo = FastDriver.DepositInEscrow.ReceiptNo.Text.Clean();
                string Representing = FastDriver.DepositInEscrow.Representing.Text.Clean();
                string ReceivedFrom = FastDriver.DepositInEscrow.ReceivedFrom.Text.Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                Reports.TestStep = "Checking Receipt to File screen";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying if Receipt To File button is enabled. If step fails, please check transaction status.");
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();

                Reports.TestStep = "Verifying Search Results column headers";
                Support.AreEqual("BUID", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[0].Text);
                Support.AreEqual("File Number", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[1].Text);
                Support.AreEqual("MR", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[2].Text);
                Support.AreEqual("Receipt #", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[3].Text);
                Support.AreEqual("Amount", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[4].Text);
                Support.AreEqual("Received From", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[5].Text);
                Support.AreEqual("Payor", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[6].Text);
                Support.AreEqual("For Credit Of", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[7].Text);
                Support.AreEqual("Representing", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[8].Text);
                Support.AreEqual("Comments", FastDriver.ReceiptToFile.ReceiptTableHeader.FindElements(By.TagName("TD"))[9].Text);

                Reports.TestStep = "Validate Wire Amount and editable fields";
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 1, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 1, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.GetCell).Element.Enabled.ToString());
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 7, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 7, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 8, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 8, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 10, TableAction.GetCell).Element.Exists().ToString());
                Support.AreEqual("True", FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 10, TableAction.GetCell).Element.Enabled.ToString());
                Support.AreEqual(ReceivedFrom, FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.GetText).Message.Clean());
                Support.AreEqual(Representing, FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.GetCell).Element.FindElement(By.Id("dgRF_0_ddlRepresenting")).Text.Clean());
                FastDriver.BottomFrame.Reset();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                FastDriver.WebDriver.HandleDialogMessage();


                Reports.TestStep = "Navigate back to Incoming Wires and set item type as ACH ";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("ACH");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(1, 4, TableAction.Click);
                string Date = FastDriver.IncomingWires.SearchResults.PerformTableAction(1, 3, TableAction.GetText).Message.Clean();
                string Amount = FastDriver.IncomingWires.SearchResults.PerformTableAction(1, 4, TableAction.GetText).Message.Clean();
                string Originator = FastDriver.IncomingWires.SearchResults.PerformTableAction(1, 6, TableAction.GetText).Message.Clean();
                FastDriver.IncomingWires.ReceiptToFile.FAClick();

                Reports.TestStep = "Validate detail fields are as expected for ACH";
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                Support.AreEqual("ACH", FastDriver.ReceiptToFile.Type.Text.Clean());
                Support.AreEqual(Amount.FormatAsMoney(true), FastDriver.ReceiptToFile.Amount.Text.Clean());
                Support.AreEqual(Date, FastDriver.ReceiptToFile.IssueDate.Text.Clean());
                Support.AreEqual(Originator, FastDriver.ReceiptToFile.Originator.Text.Clean());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Deposit_Adjustment_Screen_Warning_Popup_Reverse()
        {
            try
            {
                #region Data SetUp
                var deposit = new DepositParameters()
                {

                    Amount = 10,
                    TypeofFunds = "Direct Deposit",
                    ReceivedFrom = "Seller",
                    Representing = "Deposit",
                    Description = "Testing Incoming Wires",
                };
                #endregion

                Reports.TestDescription = "Deposit Adjustment Screen";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");

                Reports.TestStep = "Create a File";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Manual.FAClick();
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(Support.RandomString("NNNNNNNN"));
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Manual Check/Receipt Reason");
                FastDriver.ManualCheckReceiptReason.WaitCreation(FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason, 10);
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Testing IW");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();

                Reports.TestStep = "Verifying Deposit/Receipt History Screen";
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();

                Support.value = FastDriver.DepositAdjustment.AdjustmentReason.Text;
                Support.AreEqual("True", Support.value.Contains("Cancel").ToString());
                Support.AreEqual("True", Support.value.Contains("Correct Amount").ToString());
                Support.AreEqual("True", Support.value.Contains("Correct Document No").ToString());
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                Support.AreEqual("True", FastDriver.DepositAdjustment.CorrectAmount.Enabled.ToString());
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Document No");
                Support.AreEqual("True", FastDriver.DepositAdjustment.CorrectDocumentNo.Enabled.ToString());
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Bank Acct");
                Support.AreEqual("True", FastDriver.DepositAdjustment.CorrectBankAccount.Enabled.ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Reset();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        #endregion

        #region Transfer/Return/Exclude
        [TestMethod]
        public void BPUC0009_ReturnWiretoBank_Reverse()
        {
            try
            {
                Reports.TestDescription = "User Returns a Wire";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
                Support.value = FastDriver.IncomingWires.ReturnWire.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. If step failed, please check transaction status.");
                FastDriver.IncomingWires.ReturnWire.FAClick();
                FastDriver.ReturnWire.WaitForScreenToLoad();
                FastDriver.ReturnWire.ReasonOfReturn.FASetText("Returning cash for test purposes.");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Logging in to FAST IIS as Return Wire approver";
                Login("Home", "User_Name2", "User_Password2");

                Reports.TestStep = "Selecting Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                Reports.TestStep = "Locating wire to approve";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Status", "Unapproved", "Status", TableAction.Click);
                Support.value = FastDriver.WireDisbursementApproval.ViewDetails.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. Check automated test.");

                FastDriver.WireDisbursementApproval.ViewDetails.FAClick();

                Reports.TestStep = "Approving wire & Saving";
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                Support.value = FastDriver.IssueWireDisbursement.Approved.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. If step failed, please check access level for user");
                FastDriver.IssueWireDisbursement.Approved.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Status", "Approved", "Sel", TableAction.On);
                FastDriver.WireDisbursementApproval.Transmit.FAClick();

                Reports.TestStep = "Returning to the Incoming Wires screen to confirm that the wire was Transferred";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.IssueDateFrom.FASetText("01-01-2013");
                FastDriver.IncomingWires.Select_Status.FASelectItem("Returned");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Returned", "Status", TableAction.Click);
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_TransferToAnotherOffice_Reverse()
        {
            try
            {
                Reports.TestDescription = "User Transfers a Wire to Another Office";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
                Support.value = FastDriver.IncomingWires.Transfer.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. If step failed, please check transaction status.");
                FastDriver.IncomingWires.Transfer.FAClick();
                FastDriver.TransferWire.WaitForScreenToLoad();
                FastDriver.TransferWire.RecipientOfficeBUID.FASetText("191");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Logging in to FAST IIS as Return Wire approver";
                Login("Home", "User_Name2", "User_Password2");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                Reports.TestStep = "Locating wire to approve";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>("Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Status", "Unapproved", "Status", TableAction.Click);
                Support.value = FastDriver.WireDisbursementApproval.ViewDetails.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. Check automated test.");

                FastDriver.WireDisbursementApproval.ViewDetails.FAClick();

                Reports.TestStep = "Approving wire & Saving";
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                Support.value = FastDriver.IssueWireDisbursement.Approved.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. If step failed, please check access level for user");
                FastDriver.IssueWireDisbursement.Approved.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("Status", "Approved", "Sel", TableAction.On);
                FastDriver.WireDisbursementApproval.Transmit.FAClick();

                Reports.TestStep = "Returning to the Incoming Wires screen to confirm that the wire was Transferred";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.IssueDateFrom.FASetText("01-01-2013");
                FastDriver.IncomingWires.Select_Status.FASelectItem("Transferred");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Transferred", "Status", TableAction.Click);
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_UserExcludesWire_Reverse()
        {
            try
            {
                Reports.TestDescription = "User Excludes a Wire";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();

                Reports.TestStep = "Excluding the wire";
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
                Support.value = FastDriver.IncomingWires.ExcludeRecover.Enabled.ToString();
                Support.AreEqual("True", Support.value, "Verifying if checkbox is enabled. If step failed, please check transaction status.");
                FastDriver.IncomingWires.ExcludeRecover.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.IncomingWires.WaitForScreenToLoad();

                Reports.TestStep = "Recover a wire";
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Excluded", "#2", TableAction.Click);
                FastDriver.IncomingWires.ExcludeRecover.FAClick();
                FastDriver.IncomingWires.SearchResults.PerformTableAction("Status", "Pending", "#2", TableAction.Click);
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }
        #endregion

        #region IW Wire Posting
        [TestMethod]
        public void BPUC0009_User_Posts_Manual_Receipt_Reverse()
        {
            try
            {
                Reports.TestDescription = "User posts manual receipts.";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);
                decimal deposits = totalamt / 3;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit3 = totalamt - (deposit1 + deposit1);

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Deposit",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Seller",
                };
                #endregion

                #region Creating File #1 + Creating Deposit #1
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Creating File #2 + Creating Deposit #2
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Creating File #3 + Creating Deposit #3
                Reports.TestStep = "Creating a File #3 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit3.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo3 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber3 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 5, TableAction.Click);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 2, TableAction.SetText, fileNumber3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 4, TableAction.SetText, ReceiptNo3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                #endregion
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_User_cancel_a_receipt_in_a_split_wire_Reverse()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);
                decimal deposits = totalamt / 2;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit2 = totalamt - deposit1;

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Deposit",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Seller",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Creating file #2 and adding manual deposit
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit2.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_User_Cancels_Both_Receipt_In_A_Split_Wire_Reverse()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(5, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(5, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);
                decimal deposits = totalamt / 2;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit2 = totalamt - deposit1;

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Deposit",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Seller",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Creating file #2 and adding manual deposit
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit2.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(5, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Cancelling 1st Receipt
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_User_Cancels_Both_Receipt_In_A_Wire_And_Use_Same_Receipt_Reverse()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);
                decimal deposits = totalamt / 2;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit2 = totalamt - deposit1;

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Deposit",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Seller",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Creating file #2 and adding manual deposit
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit2.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Cancelling 1st Receipt
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Creating file #3 and adding manual deposit
                Reports.TestStep = "Creating a File #3 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(totalamt.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo3 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber3 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting 3rd receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Reposting 1st Receipt
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Receipt_Adjustments_Reverse()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);

                var deposit = new DepositParameters
                {
                    Amount = (double)totalamt,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Deposit",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Seller",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Verify IW reverted to Pending Status
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(7, 4, TableAction.Click);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Using_Adjusted_Receipt_For_Same_IW_Reverse()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);

                var deposit = new DepositParameters
                {
                    Amount = (double)totalamt,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Deposit",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Seller",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region RePosting Same Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Using_Adjusted_Receipt_For_Diff_IW_Reverse()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(9, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(9, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);

                var deposit = new DepositParameters
                {
                    Amount = (double)totalamt,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Deposit",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Seller",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(9, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region RePosting Same Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(8, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Posting_Wire_To_Single_File_Reverse()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                #region Creating file #1
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");
                #endregion

                #region Posting Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(6, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.SelectItem, "Buyer");
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.SelectItem, "Miscelleaneous Funds");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_Posting_Wire_To_Multiple_Files_Reverse()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);
                decimal deposits = totalamt / 3;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit3 = totalamt - (deposit1 + deposit1);

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Deposit",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Seller",
                };
                #endregion

                #region Creating file #1
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");
                #endregion

                #region Creating file #2
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");
                #endregion

                #region Creating file #3
                Reports.TestStep = "Creating a File #3 & creating a deposit";
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");
                #endregion

                #region Posting wires
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber3 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(4, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.SetText, deposit1.ToString());
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 6, TableAction.SelectItem, "Buyer");
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 9, TableAction.SelectItem, "Miscelleaneous Funds");
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 5, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 5, TableAction.SetText, deposit1.ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 6, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 6, TableAction.SelectItem, "Buyer");
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 9, TableAction.SelectItem, "Miscelleaneous Funds");
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 2, TableAction.SetText, fileNumber3);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 5, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 5, TableAction.SetText, deposit3.ToString());
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 6, TableAction.SelectItem, "Buyer");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 9, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(3, 9, TableAction.SelectItem, "Miscelleaneous Funds");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_RePosts_Receipt_Posted_to_Another_file_Reverse()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);

                var deposit = new DepositParameters
                {
                    Amount = (double)totalamt,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Deposit",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Seller",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Cancelling Receipt
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancelling Receipt. IW Testing");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

                #region Creating File #2 + Creating Deposit #2
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting Receipt to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(2, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Reposting 1st Receipt
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void BPUC0009_User_Changes_Amount_Of_IW_Receipted_to_Multiple_Files_Reverse()
        {
            try
            {
                Reports.TestDescription = "User cancels a receipt in a split wire";
                Reports.TestStep = "Logging in to IIS";
                Login("Home", "User_Name", "User_Password");

                Reports.TestStep = "Logging in to Exchange Automation Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12610");;

                #region - Data SetUp
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                Support.DataSave("WireAmt", FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.GetText).Message.Clean());
                Support.DataLoad("WireAmt");
                FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.Click);
                decimal totalamt = decimal.Parse(Support.data);
                decimal deposits = totalamt / 2;
                decimal deposit1 = decimal.Round(deposits, 2);
                decimal deposit2 = totalamt - deposit1;

                var deposit = new DepositParameters
                {
                    Amount = (double)deposit1,
                    TypeofFunds = "Direct Deposit",
                    Representing = "Deposit",
                    Description = "Testing Incoming Wires",
                    ReceivedFrom = "Seller",
                };
                #endregion

                #region Creating file #1 and adding manual deposit
                Reports.TestStep = "Creating a File #1 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Creating File #2 + Creating Deposit #2
                Reports.TestStep = "Creating a File #2 & creating a deposit";
                FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>("Home>Order Entry>1031 Exchange>Exchange File Entry").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.ExchangeFileEntry.WaitForScreenToLoad();
                ExchangeFile("Reverse / Construction", "zz-Exchange Reverse FAST Admin Office PR: eSTEST off: 9998(12610)");

                Reports.TestStep = "Creating a deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.DepositInEscrow.Amount.FASetText(deposit2.ToString());
                FastDriver.DepositInEscrow.Comment.FASetText("BPUC0009 - IncomingWires Sanity/Regression Test");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue().Clean();
                FastDriver.TopFrame.SwitchToTopFrame();
                string fileNumber2 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Posting All Receipts to a Wire
                Reports.TestStep = "Accessing Incoming Wires";
                FastDriver.LeftNavigation.Navigate<IncomingWires>("Home>Business Unit Processing>Wire Interface>Incoming Wires").WaitForScreenToLoad();
                FastDriver.IncomingWires.Select_BankAcct.FASelectItem("9993109200000 First American Trust - FSB");
                FastDriver.IncomingWires.Select_ItemType.FASelectItem("IW");
                FastDriver.IncomingWires.FindNow.FAClick();
                FastDriver.IncomingWires.WaitForScreenToLoad();
                FastDriver.IncomingWires.SearchResults.PerformTableAction(3, 4, TableAction.Click);
                Support.AreEqual("True", FastDriver.IncomingWires.ReceiptToFile.Enabled.ToString(), "Verifying button availability. If step fails, please check transaction.");

                Reports.TestStep = "Posting Deposits to Wire";
                FastDriver.IncomingWires.ReceiptToFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 2, TableAction.SetText, fileNumber);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 4, TableAction.SetText, ReceiptNo1);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.ReceiptToFile.AddFile.FAClick();
                FastDriver.ReceiptToFile.WaitForScreenToLoad();
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 2, TableAction.SetText, fileNumber2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.Click);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(2, 4, TableAction.SetText, ReceiptNo2);
                FastDriver.ReceiptToFile.ReceiptTable.PerformTableAction(1, 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Changing Amount for all receipts included in the wire
                FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                FastDriver.DepositAdjustment.Comment.FASetText("Changing the Amount of the Receipt");
                decimal newdeposit = deposit1 - (decimal)0.01;
                deposit2 = deposit2 + (decimal)0.01;
                FastDriver.DepositAdjustment.CorrectAmount.FASetText(newdeposit.ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.ReceiptAdjustmentDlg.WaitForScreenToLoad();
                FastDriver.ReceiptAdjustmentDlg.RASearchResults.PerformTableAction(2, 4, TableAction.SetText, deposit2.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region Recursive methods
        private void Login(string Key, string UserID, string UserPwd)
        {

            var credentials = new Credentials()
            {
                UserName = UserID,
                Password = UserPwd
            };

            FASTLogin.Login(Key, credentials, true);
        }

        public static int CreateFile()
        {
            var customFile = RequestFactory.GetCreateFileDefaultRequest();

            try
            {
                int? FileID = FileService.CreateFile(customFile).FileID;
                return (int)FileID;
            }
            catch (Exception)
            {

                throw new Exception("Unable to retrieve FileID.");
            }

        }

        private void ExchangeFile(string TransactionType, string Office)
        {
            
            FastDriver.ExchangeFileEntry.TransactionType.FASelectItem(TransactionType);
            FastDriver.ExchangeFileEntry.ExchangeOffice.FASelectItem(Office);
            FastDriver.ExchangeFileEntry.TaxPayerAddNew.FAClick();
            FastDriver.ExchangeFileEntry.TaxPayerType.FASelectItem("Individual");
            FastDriver.ExchangeFileEntry.TaxpyrIndividualName.FASetText("John");
            FastDriver.ExchangeFileEntry.TaxpyrIndividualLast.FASetText("Doe");
            FastDriver.ExchangeFileEntry.TaxpyrIndividualSSNTIN.FASetText("123456789");
            FastDriver.ExchangeFileEntry.TaxPayerAddressLine1.FASetText("1 Main St.");
            FastDriver.ExchangeFileEntry.TaxPayerCity.FASetText("Santa Ana");
            FastDriver.ExchangeFileEntry.TaxPayerState.FASelectItem("CA");
            FastDriver.ExchangeFileEntry.TaxPayerZIP.FASetText("92707");
            FastDriver.ExchangeFileEntry.TaxPayerCounty.FASetText("Orange");
            FastDriver.ExchangeFileEntry.TaxPayerBusPh.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.TaxPayerHomePh.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.TaxPayerCellFax.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.TaxPayerPager.FASetText("9999999999");
            FastDriver.ExchangeFileEntry.TaxPayerEmail.FASetText("test@test.net");
            FastDriver.ExchangeFileEntry.PartiesTab.FAClick();
            FastDriver.ExchangeFileEntry.WaitForTabToLoad();
            FastDriver.ExchangeFileEntry.EnterPartiesTabGABCode("DIRECTEDBY", "CTESTDKEXU", "CTESTYMJCA", "EXCHCPA", "ATNYTITCMP");

            if (FastDriver.ExchangeFileEntry.TransactionType.FAGetSelectedItem().Equals("Delayed"))
            {
                FastDriver.ExchangeFileEntry.RelinquishedTab.FAClick();
                FastDriver.ExchangeFileEntry.WaitForTabToLoad();
                FastDriver.ExchangeFileEntry.RelPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.RelPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.RelPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.RelPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.RelPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.RelPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.EnterRelinquishedTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                FastDriver.ExchangeFileEntry.RelBuyersAddNew.FAClick();
                FastDriver.ExchangeFileEntry.RelBuyersType.FASelectItem("Individual");
                FastDriver.ExchangeFileEntry.RelBuyersIndividualFirstName.FASetText("Jane");
                FastDriver.ExchangeFileEntry.RelBuyersIndividualLastName.FASetText("Doe");
                FastDriver.ExchangeFileEntry.RelBuyersIndividualSSNTIN.FASetText("123456789");
                FastDriver.ExchangeFileEntry.RelAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.RelBuyersCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.RelBuyersState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.RelBuyersZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.RelBuyersCounty.FASetText("Orange");
                FastDriver.ExchangeFileEntry.RelBuyersBusPhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.RelBuyersHomePhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.RelBuyersCellPhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.RelBuyersPager.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.RelBuyersEmail.FASetText("test@test.net");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
            }

            else 
            {
                FastDriver.ExchangeFileEntry.EATAcquisitionTab.FAClick();
                FastDriver.ExchangeFileEntry.WaitForTabToLoad();
                FastDriver.ExchangeFileEntry.EATAcqPropertyType.FASelectItem("Single Family Residence");
                FastDriver.ExchangeFileEntry.EATAcqPropertyAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.EATAcqPropertyCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.EATAcqPropertyState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.EATAcqPropertyZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.EATAcqPropertyCounty.FASelectItem("Orange");
                FastDriver.ExchangeFileEntry.EnterEATAcquisitionTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                FastDriver.ExchangeFileEntry.EATAcqSellersAddNew.FAClick();
                FastDriver.ExchangeFileEntry.EATAcqSellersType.FASelectItem("Individual");
                FastDriver.ExchangeFileEntry.EATAcqSellersIndividualFirstName.FASetText("Jane");
                FastDriver.ExchangeFileEntry.EATAcqSellersIndividualLastName.FASetText("Doe");
                FastDriver.ExchangeFileEntry.EATAcqSellersIndividualSSNTIN.FASetText("123456789");
                FastDriver.ExchangeFileEntry.EATAcqAddressLine1.FASetText("1 Main St.");
                FastDriver.ExchangeFileEntry.EATAcqSellersCity.FASetText("Santa Ana");
                FastDriver.ExchangeFileEntry.EATAcqSellersState.FASelectItem("CA");
                FastDriver.ExchangeFileEntry.EATAcqSellersZIP.FASetText("92707");
                FastDriver.ExchangeFileEntry.EATAcqSellersCounty.FASetText("Orange");
                FastDriver.ExchangeFileEntry.EATAcqSellersBusPhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.EATAcqSellersHomePhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.EATAcqSellersCellPhone.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.EATAcqSellersPager.FASetText("9999999999");
                FastDriver.ExchangeFileEntry.EATAcqSellersEmail.FASetText("test@test.net");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
            }

            
            
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
