﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.Common;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.PageObjects.IIS;

namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0026 : MasterTestClass
    {

        #region BAT

        [TestMethod]
        [Description("MF_01: File Balance Summary")]
        public void FMUC0026_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF_01: File Balance Summary";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile();
                #endregion

                #region Set an instance for Survey Details with charge amount entered
                Reports.TestStep = "Set an instance for Survey Details with charge amount entered.";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("200");
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Set an instance for Lease Details with charge amount entered
                Reports.TestStep = "Set an instance for Lease Details with charge amount entered.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("0.8");
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion
                
                #region Enter Fees
                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();
                
                #endregion

                #region Valitate Active Disbursement and Issue Check
                Reports.TestStep = "Validate that active disbursement screen is loaded.";
                FastDriver.ActiveDisbursementSummary.Open();

                Reports.TestStep = "To Issue the check us the Print button in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();


                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();

                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                
                #endregion

                #region Select a pending check and click on Edit
                Reports.TestStep = "Select a pending check and click on Edit.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Lenders Advantage A Division Of First Am", 8, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItemBySendingKeys("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");

                FastDriver.BottomFrame.Save();

                #endregion

                #region Deposit a Cash
                Reports.TestStep = "Deposit a cash.";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton:false);
         
                #endregion

                #region Validate that File balance summary screen is loaded.
                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();
                
                Reports.TestStep = "Validate that File balance summary screen is loaded.";
                Support.AreEqual("4,987.01-", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());
                
                Reports.TestStep = "Verify the Current Available Funds Amount color.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.GetAttribute("style").ToLower().Contains("red").ToString(),"Verify the Current Available Funds Amount color: red ");
                Support.AreEqual("10.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                Support.AreEqual("4,997.01", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                FastDriver.EscrowFileBalanceSummary.Deliver();
                
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                #endregion

                #region Deposit a Cash
                Reports.TestStep = "Deposit a cash.";

                FastDriver.DepositInEscrow.Open();
                DepositData.Amount = 8000;
                DepositData.Comments = "Comments Before Save";
                FastDriver.DepositInEscrow.Deposit(DepositData);
                
                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region Validate that File balance summary screen is loaded.

                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Validate that File balance summary screen is loaded.";
                Support.AreEqual("3,012.99", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText());

                Reports.TestStep = "Verify the Current Available Funds Amount color.";
                Support.AreEqual("8,010.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText());
                Support.AreEqual("4,997.01", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText());
                Support.AreEqual("SHORT", FastDriver.EscrowFileBalanceSummary.Inbalance.FAGetText().Trim());

                FastDriver.EscrowFileBalanceSummary.Deliver();
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                Reports.TestStep = "Verifying for the Print Delivery Event of File Balance Summary screen";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventCategory.FASelectItemBySendingKeys("Doc Delivery");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(1,"[Print]",1,TableAction.Click);
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(4, "Print Service", 4, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Documents: Escrow File Balance Sheet").ToString(), "Verify Comments contain Documents: Escrow File Balance Sheet");
                Support.AreEqual(true.ToString(), FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Delivery Method: Print").ToString(), "Verify Comments contain Delivery Method: Print" );

            
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

             
        #endregion

        #region REGRESSION

        [TestMethod]
        [Description("REG_0001: (FM899_FM934_FM3197_FM3193_FM3687_FM3688_FM3689_FM3191_FM3184_FM3189_FM3414_FM3185_FM3413_FM2761_FM2783_FM2751_FM2758_FM2770_FM2771_FM2777_FM2774_FM2775_FM2782_FM2762_FM1056_FM1057_FM2766_FM1055_FM1058_F && REG_0002: (FM2784_FM2785_FM3416_FM3486_FM900_FM904_FM905_FM907_FM2742_FM2741_FM3303_ FM3304_FM3302_FM1051_FM3305_FM3306_FM3307_FM1063_FM902_FM901_FM903_FM3417_FM3419_FM3420_FM3421_FM3422_FM3194_FM912_FM3423_FM913_F")]
        public void FMUC0026_REG0001()
        {
            try
            {
                Reports.TestDescription = "REG_0001: (FM899_FM934_FM3197_FM3193_FM3687_FM3688_FM3689_FM3191_FM3184_FM3189_FM3414_FM3185_FM3413_FM2761_FM2783_FM2751_FM2758_FM2770_FM2771_FM2777_FM2774_FM2775_FM2782_FM2762_FM1056_FM1057_FM2766_FM1055_FM1058_F && REG_0002: (FM2784_FM2785_FM3416_FM3486_FM900_FM904_FM905_FM907_FM2742_FM2741_FM3303_ FM3304_FM3302_FM1051_FM3305_FM3306_FM3307_FM1063_FM902_FM901_FM903_FM3417_FM3419_FM3420_FM3421_FM3422_FM3194_FM912_FM3423_FM913_F";

                #region REG_0001: (FM899_FM934_FM3197_FM3193_FM3687_FM3688_FM3689_FM3191_FM3184_FM3189_FM3414_FM3185_FM3413_FM2761_FM2783_FM2751_FM2758_FM2770_FM2771_FM2777_FM2774_FM2775_FM2782_FM2762_FM1056_FM1057_FM2766_FM1055_FM1058_F

                Reports.TestStep = "REG_0001: (FM899_FM934_FM3197_FM3193_FM3687_FM3688_FM3689_FM3191_FM3184_FM3189_FM3414_FM3185_FM3413_FM2761_FM2783_FM2751_FM2758_FM2770_FM2771_FM2777_FM2774_FM2775_FM2782_FM2762_FM1056_FM1057_FM2766_FM1055_FM1058_F";
                Reports.StatusUpdate("REG_0001: (FM899_FM934_FM3197_FM3193_FM3687_FM3688_FM3689_FM3191_FM3184_FM3189_FM3414_FM3185_FM3413_FM2761_FM2783_FM2751_FM2758_FM2770_FM2771_FM2777_FM2774_FM2775_FM2782_FM2762_FM1056_FM1057_FM2766_FM1055_FM1058_F", true);

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10000.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Regression Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";
                DepositData.Comments = "Regression is in progress";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile();
                #endregion

                #region Remove New Loan Amount
                Reports.TestStep = "Remove New Loan Amount.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("0" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FindGABCode("247");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Set an instance for Survey Details with charge amount entered
                Reports.TestStep = "Set an instance for Survey Details with charge amount entered.";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("200");
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Print All Checks
                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();

                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                #endregion

                #region Validate the data and seller issued check flag
                Reports.TestStep = "Validate the data and seller issued check flag.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.IsDisplayed().ToString());
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.SellerCheckIssuedFlag.IsDisplayed().ToString());
                FastDriver.BottomFrame.Done();

                #endregion

                #region Deposit a Cash on behalf of Buyer.
                Reports.TestStep = "Deposit a Cash on behalf of Buyer.";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion
                
                #region Print All Checks
                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();

                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                #endregion

                #region Deposit a Cash on behalf of Buyer
                Reports.TestStep = "Deposit a Cash on behalf of Buyer.";

                FastDriver.DepositInEscrow.Open();
                DepositData.Amount = 7000;
                FastDriver.DepositInEscrow.Deposit(DepositData);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow:false);
                
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region Deposit a Cash on behalf of Buyer
                Reports.TestStep = "Deposit a Cash on behalf of Buyer.";

                FastDriver.DepositInEscrow.Open();
                DepositData.Amount = 3500;
                FastDriver.DepositInEscrow.Deposit(DepositData);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the Message in Deposit in Escrow Page for excess deposit.";
                Support.AreEqual("Important! The credit to party contains total cash or similar deposits in excess of $10,000. Form 8300 is required to be completed and filed with the IRS within 15 days.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false));
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton:false);
                #endregion
                
                #region Verify for the Message on FBS screen after deposit extra amount after 10,000.00
                Reports.TestStep = "Verify for the Message on FBS screen after deposit extra amount after 10,000.00";
                FastDriver.EscrowFileBalanceSummary.Open();

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.Thisfilecontaionsexcessof1000000.IsDisplayed().ToString());
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.Thisfilecom8300isrequired.IsDisplayed().ToString());
                FastDriver.BottomFrame.Done();
               
                #endregion

                #region Print All Checks
                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();

                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                #endregion

                #region Edit Charge in Survey Detail Screen
                Reports.TestStep = "Edit Charge in Survey Detail Screen.";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10" + FAKeys.Tab);
                
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion

                #region Validate the Warn Message in File Balance summary
                Reports.TestStep = "Validate the Warn Message in File Balance summary.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Support.AreEqual("*", FastDriver.EscrowFileBalanceSummary.DisbSumTotNetIssuedFlag.FAGetText());
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("* Issued Check Amounts exceed Actual Charge Amounts").ToString(),"File Balance Summary Table Contains: *Issued Check Amounts exceed Actual Charge Amounts");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Net Issued Disbursements: - $ 20,500.00 *").ToString(), "Balance Summary Table Contains: Net Issued Disbursements:- $20,500.00*");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("File Balance: $ 190.00-").ToString(), "Balance Summary Table Contains: File Balance:$190.00-");
                
                Reports.TestStep = "Verify the File Balance Display Amount color.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalance.GetAttribute("style").ToLower().Contains("red").ToString(), "Verify the File Balance Display Amount color: red ");
                
                Reports.TestStep = "Validate the Warn Message in File Balance summary.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.BuyerCheckIssuedFlag.IsDisplayed().ToString());
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.SellerCheckIssuedFlag.IsDisplayed().ToString());

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected File Balance: $ 190.00-").ToString(), "Balance Summary Table Contains: Projected File Balance:$190.00-");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Buyer $ 0.00 $ $ 15,490.00 þ").ToString(), "Balance Summary Table Contains: Buyer$0.00$$15,490.00þ");

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.IsDisplayed().ToString(), "LoanProceedsSummaryTable Exists");

                Support.AreEqual("Lenders Advantage", FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.PerformTableAction(2, 1, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify Seller's Funds Due in File Balance summary.";
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.FBSProjectedTable.PerformTableAction(1, "Seller's Funds Due:", 3, TableAction.GetText).Message.Trim(), "Projected Table: Seller's Funds Due:$0.00");
                Support.AreEqual("5,000.00", FastDriver.EscrowFileBalanceSummary.SellerNetCheck.FAGetText().Trim());

                #endregion

                #endregion

                #region  REG_0002: (FM2784_FM2785_FM3416_FM3486_FM900_FM904_FM905_FM907_FM2742_FM2741_FM3303_ FM3304_FM3302_FM1051_FM3305_FM3306_FM3307_FM1063_FM902_FM901_FM903_FM3417_FM3419_FM3420_FM3421_FM3422_FM3194_FM912_FM3423_FM913_F

                Reports.TestStep = "REG_0002: (FM2784_FM2785_FM3416_FM3486_FM900_FM904_FM905_FM907_FM2742_FM2741_FM3303_ FM3304_FM3302_FM1051_FM3305_FM3306_FM3307_FM1063_FM902_FM901_FM903_FM3417_FM3419_FM3420_FM3421_FM3422_FM3194_FM912_FM3423_FM913_F";
                Reports.StatusUpdate("REG_0002: (FM2784_FM2785_FM3416_FM3486_FM900_FM904_FM905_FM907_FM2742_FM2741_FM3303_ FM3304_FM3302_FM1051_FM3305_FM3306_FM3307_FM1063_FM902_FM901_FM903_FM3417_FM3419_FM3420_FM3421_FM3422_FM3194_FM912_FM3423_FM913_F", true);
                
                #region Create a New Loan Details
                Reports.TestStep = "Create a New Loan Details.";

                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("5000");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100HM01");

                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");

                if (!FastDriver.NewLoan.LoanChargesInterestCalculationPerDiem.IsSelected())
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationPerDiem.FAClick();
                }

                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("0.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("09/12/2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("12/31/2012");
                FastDriver.NewLoan.LoanChargesOriginationChargebuyercharge.FASetText("100" + FAKeys.Tab);

                if (_GetCurrentFileFormType() == FormType.HUD) { 
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("0.75");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.0" + FAKeys.Tab);
                }

                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_Months1.FASetText("4");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_MonthlyCharge.FASetText("15");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_Months2.FASetText("5");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_MonthlyCharge2.FASetText("10");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("25");
              
                if (_GetCurrentFileFormType() == FormType.HUD){
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("150");
                }
                
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                FastDriver.NewLoan.MortgageGABcode.FASetText("255");
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FASetText("75");

                Reports.TestStep = "New us Shortcut Keys.";
                FastDriver.BottomFrame.New();
                
                Reports.TestStep = "Enter details for a instance in new loan screen.";
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100");
                FastDriver.NewLoan.FindGABCode("266");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Deposit a Cash on behalf of Seller
                Reports.TestStep = "Deposit a Cash on behalf of Seller.";

                FastDriver.DepositInEscrow.Open();
                DepositData.Amount = 1250;
                DepositData.ReceivedFrom = "Seller";
                DepositData.Description = "Regression Escrow Deposit";
                DepositData.Representing = "Additional Deposit";

                FastDriver.DepositInEscrow.Deposit(DepositData);

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the Message in Deposit in Escrow Page for excess deposit.";
                Support.AreEqual("Deposit Receipt is ready for printing. Continue?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));

                #endregion 
                
                #region Deposit a Cash by Other.
                Reports.TestStep = "Deposit a Cash by Other.";

                FastDriver.DepositInEscrow.Open();
                DepositData.Amount = 500;
                DepositData.ReceivedFrom = "Other";
                DepositData.Description = "Regression Escrow Deposit";
                DepositData.Representing = "Additional Deposit";
                DepositData.Payor = "First American";
                FastDriver.DepositInEscrow.Deposit(DepositData);

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the Message in Deposit in Escrow Page for excess deposit.";
                Support.AreEqual("Deposit Receipt is ready for printing. Continue?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));

                #endregion

                #region Deposit Amount
                Reports.TestStep = "Deposit Amount.";
                FastDriver.DepositOutsideEscrow.Open();

                DepositOutsideEscrowParameters DepositOutsideData = new DepositOutsideEscrowParameters();
                DepositOutsideData.TotalDeposit = 200;
                DepositOutsideData.EarnerstMoneyHeldBy_0 = "Outside Title Company";
                DepositOutsideData.EarnerstMoneyName_0 = "Bank of America";
                DepositOutsideData.EarnerstMoneyAmount_0 = 100.00;
                DepositOutsideData.ExcessDeposit = 50;
                DepositOutsideData.DisbursedasProceeds = 50;

                if (_GetCurrentFileFormType() == FormType.HUD){

                    DepositOutsideData.Curefor0Tolerance_Amount = 25;
                    DepositOutsideData.Curefor10Tolerance_Amount = "#";
                }

                FastDriver.DepositOutsideEscrow.Deposit(DepositOutsideData);
                FastDriver.BottomFrame.Save();
                
                #endregion

                #region Enter Charges
                Reports.TestStep = "Enter Charges.";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.GABcode.FASetText("726");
                FastDriver.OTCDetail.Find.Click();
                FastDriver.OTCDetail.WaitForScreenToLoad();
                FastDriver.OTCDetail.ChargesRetained.FASetText("40");
                FastDriver.OTCDetail.Type.FASelectItem("Outside Title Company");
                FastDriver.OTCDetail.OTCTitleServicesBuyerCharge.FASetText("10");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Validate the data in Escrow File Balance Summary
                Reports.TestStep = "Validate the data in Escrow File Balance Summary.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Support.AreEqual("SHORT", FastDriver.EscrowFileBalanceSummary.Inbalance.FAGetText(),"Inbalance Text");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.Inbalance.GetAttribute("style").ToLower().Contains("red").ToString(), "Verify the Inbalance color: red ");

                Support.AreEqual("1,750.00", FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText(), "CurrentAvailableFunds");
                Reports.TestStep = "Verify the Current Available Funds Amount color.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.GetAttribute("style").ToLower().Contains("green").ToString(), "Verify the CurrentAvailableFunds color: green ");

                Support.AreEqual("22,250.00", FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText(), "NetDeposit");
                Support.AreEqual("20,500.00", FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText(), "NetIssuedDisb");
                Support.AreEqual("27,065.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText(), "NetTotalDisbursements");
                Support.AreEqual("27,065.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText(), "Payoffloannettotaldisb");
                Support.AreEqual("4,815.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText(), "FileBalance");
                
                Reports.TestStep = "Verify the File Balance Amount color.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalance.GetAttribute("style").ToLower().Contains("red").ToString(), "Verify the FileBalance color: red ");

                Support.AreEqual("20,565.00", FastDriver.EscrowFileBalanceSummary.BuyerNetCheck.FAGetText(), "BuyerNetCheck");
                Reports.TestStep = "Verify the Buyer Net Check Amount color.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.BuyerNetCheck.GetAttribute("style").ToLower().Contains("green").ToString(), "Verify the BuyerNetCheck color: green ");

                Support.AreEqual("6,225.00", FastDriver.EscrowFileBalanceSummary.SellerNetCheck.FAGetText(), "SellerNetCheck");
                Reports.TestStep = "Verify the Seller Net Check Amount color.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.SellerNetCheck.GetAttribute("style").ToLower().Contains("green").ToString(), "Verify the SellerNetCheck color: green ");

                Support.AreEqual("5,000.00", FastDriver.EscrowFileBalanceSummary.LoanAmount.FAGetText(), "LoanAmount");

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.BuyerCheckIssuedFlag.IsDisplayed().ToString());
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.SellerCheckIssuedFlag.IsDisplayed().ToString());
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DisbSumTotNetIssuedFlag.IsDisplayed().ToString());
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DisbSumTotNetIssuedFlag.FAGetText().Contains("*").ToString(), "DisbSumTotNetIssuedFlag text contains *");

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Net Total Deposits: $ 22,250.00").ToString(), "Balance Summary Table Contains: Net Total Deposits:$22,250.00");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Net Issued Disbursements: - $ 20,500.00 *").ToString(), "Balance Summary Table Contains: Net Issued Disbursements:- $20,500.00*");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Issued: $ 20,500.00 $ 1,250.00 $ 500.00 $ 22,250.00").ToString(), "DepositOrDisbursementSummaryTable Contains: Issued:$20,500.00$1,250.00$500.00$22,250.00");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Net Adjustments: $ 0.00 $ 0.00 $ 0.00 $ 0.00").ToString(), "DepositOrDisbursementSummaryTable Contains: Net Adjustments:$0.00$0.00$0.00$0.00");

                Reports.TestStep = "Validate the data in Escrow File Balance Summary.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Net Total Deposits: $ 22,250.00").ToString(), "Balance Summary Table Contains: Net Total Deposits:$22,250.00");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Net Total Disbursements: - $ 27,065.00").ToString(), "Balance Summary Table Contains: Net Total Disbursements:- $27,065.00");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("File Balance: $ 4,815.00-").ToString(), "Balance Summary Table Contains: File Balance:$4,815.00-");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Net Deposits: $ 20,500.00 $ 1,250.00 $ 500.00 $ 22,250.00").ToString(), "DepositOrDisbursementSummaryTable Contains: Net Deposits:$20,500.00$1,250.00$500.00$22,250.00");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Deposits Outside Escrow:   $ 200.00").ToString(), "DepositOrDisbursementSummaryTable Contains: Deposits Outside Escrow: $200.00");


                Reports.TestStep = "Validate the data in Escrow File Balance Summary.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected Loan Funding: $ 4,985.00").ToString(), "Balance Summary Table Contains: Projected Loan Funding: $ 4,985.00");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Funds Deposited with OTC: $ 40.00-").ToString(), "Balance Summary Table Contains: Funds Deposited with OTC: $ 40.00-");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected File Balance: $ 130.00").ToString(), "Balance Summary Table Contains: Projected File Balance: $ 130.00");

                Support.AreEqual("5,000.00", FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-115.00", FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.PerformTableAction(2, 3, TableAction.GetText).Message.Trim());

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("(4) Issued Checks: $ 20,500.00").ToString(), "DepositOrDisbursementSummaryTable Contains: (4) Issued Checks: $ 20,500.00");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("(4) Total Issued: $ 20,500.00").ToString(), "DepositOrDisbursementSummaryTable Contains: (4) Total Issued: $ 20,500.00");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Disbursements Pending & Held: $ 6,565.00").ToString(), "DepositOrDisbursementSummaryTable Contains: Disbursements Pending & Held: $ 6,565.00");

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Buyer's Funds Due: $ 0.00").ToString(), "Balance Summary Table Contains: Buyer's Funds Due: $ 0.00");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Seller's Funds Due: $ 0.00").ToString(), "Balance Summary Table Contains: Seller's Funds Due: $ 0.00");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Difference Amount: $ 190.00").ToString(), "Balance Summary Table Contains: Difference Amount: $ 190.00");

                Support.AreEqual("4,885.00", FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.PerformTableAction(2, 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("Leoris & Cohen, P.C.", FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.PerformTableAction(3, 1, TableAction.GetText).Message.Trim());

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Net Issued: $ 20,500.00 *").ToString(), "DepositOrDisbursementSummaryTable Contains: Net Issued: $ 20,500.00 *");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("* Issued Check Amounts exceed Actual Charge Amounts $ 190.00").ToString(), "DepositOrDisbursementSummaryTable Contains: * Issued Check Amounts exceed Actual Charge Amounts $ 190.00");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Net Total Disbursements: $ 27,065.00").ToString(), "DepositOrDisbursementSummaryTable Contains: Net Total Disbursements: $ 27,065.00");

                Reports.TestStep = "Validate the data in Escrow File Balance Summary.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Funds Held After Close   Funds Due   Net Check").ToString(), "Balance Summary Table Contains: Funds Held After Close   Funds Due   Net Check");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Buyer $ 0.00 $ $ 20,565.00 þ").ToString(), "Balance Summary Table Contains: Buyer $ 0.00 $ $ 20,565.00 þ");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Seller $ 0.00 $   $ 6,225.00 þ").ToString(), "Balance Summary Table Contains: Seller $ 0.00 $   $ 6,225.00 þ");

                Support.AreEqual("100.00", FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.Trim());

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Total Actual Issued Charges $ 20,690.00").ToString(), "DepositOrDisbursementSummaryTable Contains: Total Actual Issued Charges $ 20,690.00");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("(3) Pending Issue: $ 6,565.00").ToString(), "DepositOrDisbursementSummaryTable Contains: (3) Pending Issue: $ 6,565.00");
               
                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("REG_0003: (ES6086_ES6085_ES6084_ES6083_FM2773_FM3691_FM3191_FM2772_FM1061_FM1105_FM1106_0001_FD) 1.Sub Escrow: Show File Balance Totals for Outside Escrow Company 2.Sub Escrow: Show Net Check Total as Pending Disbursement to OEC 3.Sub")]
        public void FMUC0026_REG0003()
        {
            try
            {
                Reports.TestDescription = "REG_0003: (ES6086_ES6085_ES6084_ES6083_FM2773_FM3691_FM3191_FM2772_FM1061_FM1105_FM1106_0001_FD) 1.Sub Escrow: Show File Balance Totals for Outside Escrow Company 2.Sub Escrow: Show Net Check Total as Pending Disbursement to OEC 3.Sub";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateSubEscrowFile();
                #endregion

                #region validate IN BALANCE situation in File Balance Summary
                Reports.TestStep = "Validate IN BALANCE situation in File Balance Summary.";
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual("IN BALANCE", FastDriver.EscrowFileBalanceSummary.Inbalance.FAGetText().Trim());

                #endregion 

                #region Deposit a cash on behalf of Buyer
                Reports.TestStep = "Deposit a cash on behalf of Buyer.";
                DepositParameters deposit = new DepositParameters();
                deposit.Amount = 200.00;
                deposit.TypeofFunds = "Cash";
                deposit.Representing = "Additional Deposit";
                deposit.Description = "Regression Escrow Deposit";
                deposit.ReceivedFrom = "Seller";
                deposit.Payor = "First American";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Amount.FASetText(deposit.Amount.ToString());
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(deposit.TypeofFunds);
                FastDriver.DepositInEscrow.Representing.FASelectItem(deposit.Representing);
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(deposit.ReceivedFrom);
                FastDriver.DepositInEscrow.DepositedTo.FASelectItem(deposit.DepositedTo);
                FastDriver.DepositInEscrow.Payor.FASetText(deposit.Payor);
                FastDriver.DepositInEscrow.Description.FASetText(deposit.Description);
                FastDriver.DepositInEscrow.CredittoSeller.FASetCheckbox(deposit.CreditToSeller);
                FastDriver.DepositInEscrow.CredittoBuyer.FASetCheckbox(deposit.CreditToBuyer);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region OutsideEscrowCompanyDetail Enter GAB && Enter Sales Price in TDS screen for a file
                Reports.TestStep = "Enter GAB and click on find button.";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("726");

                Reports.TestStep = "Enter Sales Price in TDS screen for a file.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("100" + FAKeys.Tab);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion
                
                #region Validate the data in Escrow File Balance Summary
                Reports.TestStep = "Validate the data in file summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();
                
                Support.AreEqual(false.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Buyer").ToString(), "Balance Summary Table Does Not Contain: Buyer");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Outside Escrow Company").ToString(), "Balance Summary Table Contains: Outside Escrow Company");

                Reports.TestStep = "Validate the data in file summary screen.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Outside Escrow Company $ 0.00 $ $ 200.00").ToString(), "Balance Summary Table Contains: Outside Escrow Company$0.00$$200.00");
                Support.AreEqual(false.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("100.00").ToString(), "Balance Summary Table Does Not Contain: 100.00");
                Support.AreEqual(false.ToString(), FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.FAGetText().Contains("100.00").ToString(), "LoanProceedsSummaryTable Does Not Contain: 100.00");
                Support.AreEqual(false.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("100.00").ToString(), "DepositOrDisbursementSummaryTable Does Not Contain: 100.00");
                Support.AreEqual(false.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Buyer").ToString(), "DepositOrDisbursementSummaryTable Does Not Contain: Buyer");
                Support.AreEqual(false.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Seller").ToString(), "DepositOrDisbursementSummaryTable Does Not Contain: Seller");

                #endregion

                #region Validate Payee
                Reports.TestStep = "Validate Payee.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Bank Of America", 1, TableAction.Click);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.SwitchToContentFrame();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Validate the data in Escrow File Balance Summary
                Reports.TestStep = "Validate the data in file summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Support.AreEqual("EXCESS", FastDriver.EscrowFileBalanceSummary.Inbalance.FAGetText().Trim());

                Reports.TestStep = "Verify the File Balance Display Message color.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.Inbalance.GetAttribute("style").ToLower().Contains("green").ToString(), "Verify the Inbalance color: green ");

                Reports.TestStep = "Verify the File Balance Display Amount color.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalance.GetAttribute("style").ToLower().Contains("green").ToString(), "Verify the FileBalance color: green ");

                Reports.TestStep = "Validate the data in file summary screen.";
                Support.AreEqual(false.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Outside Escrow Company").ToString(), "Balance Summary Table Does not Contain: Outside Escrow Company");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Seller").ToString(), "Balance Summary Table  Contains: Seller");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Buyer").ToString(), "Balance Summary Table  Contains: Buyer");

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Buyer").ToString(), "DepositOrDisbursementSummaryTable Contains: Buyer");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Seller").ToString(), "DepositOrDisbursementSummaryTable Contains: Seller");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Outside Escrow").ToString(), "DepositOrDisbursementSummaryTable Contains: Outside Escrow");

                #endregion

                #region Change the Transaction type to Refinance
                Reports.TestStep = "Change the Transaction type to Refinance.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("Refinance" + FAKeys.Tab);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

                #region Validate the data in Escrow File Balance Summary
                Reports.TestStep = "Validate the data in file summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad();

                Support.AreEqual("EXCESS", FastDriver.EscrowFileBalanceSummary.Inbalance.FAGetText().Trim());
                Support.AreEqual(false.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Buyer").ToString(), "Balance Summary Table Does not Contain: Buyer");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Borrower").ToString(), "Balance Summary Table  Contains: Borrower");

                Support.AreEqual(false.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Buyer").ToString(), "DepositOrDisbursementSummaryTable Does not Contain: Buyer");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("Borrower").ToString(), "DepositOrDisbursementSummaryTable Contains: Borrower");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("REG_0004: Field Defination for Trial Note button and delivery.")]
        public void FMUC0026_REG0004()
        {
            try
            {
                Reports.TestDescription = "REG_0004: Field Defination for Trial Note button and delivery.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateSubEscrowFile();
                #endregion

                #region Click on Trial Balance note
                Reports.TestStep = "Click on Trial Balance note.";
                FastDriver.EscrowFileBalanceSummary.Open();
                FastDriver.EscrowFileBalanceSummary.TrialBalanceNote.FAClick();

                Reports.TestStep = "Enter a note from File Balance Summary screen.";
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText("Note From File Balance Summary");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region Validate the Trial Balance note entered from File Balance Summary screen
                Reports.TestStep = "Validate the Trial Balance note entered from File Balance Summary screen.";
                FastDriver.FileNotes.Open();
                Support.AreEqual(true.ToString(), FastDriver.FileNotes.Table.FAGetText().Contains("Note From File Balance Summary").ToString(), "Table Contains: ote From File Balance Summary");
                #endregion

                #region Navigate to File balance summary screen and Perform preview delivery
                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();
                
                Reports.TestStep = "Perform Preview Deliveries.";
                FastDriver.EscrowFileBalanceSummary.cboMethod.FASelectItem("Preview");
                FastDriver.EscrowFileBalanceSummary.Deliver();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");
                FastDriver.WebDriver.ClosePreviewWindow();
                #endregion

               

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("FMXXXX : Listing Broker’s Funds Due")]
        public void FMUC0026_REG0005()
        {
            try
            {
                Reports.TestDescription = "FMXXXX : Listing Broker’s Funds Due";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile(AddNewLoanAmount:false);
                #endregion

                #region Credit Buyer's (Selling) Broker
                Reports.TestStep = "Credit Buyer's (Selling) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();

                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("600.00");
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("700.00");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Verify the Listing Broker's Fund Due for a non-zero negative amount
                Reports.TestStep = "Verify the Listing Broker's Fund Due for a non-zero negative amount.";

                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Listing Broker's Funds Due: $ 100.00").ToString(), "Verify FalieBalanceSymmaryTable Contains: Listing Broker's Funds Due:$100.00");
                #endregion

                #region Edit the Commision Amount

                Reports.TestStep = "Edit the Commision Amount.";

                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000.00");
                FastDriver.BottomFrame.Done();

                #endregion 


                #region Verify the Listing Broker's Fund Due for a zero or positive number
                Reports.TestStep = "Verify the Listing Broker's Fund Due for a zero or positive number.";

                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Selling Broker's Funds Due: $ 0.00").ToString(), "Verify FalieBalanceSymmaryTable Contains: Selling Broker's Funds Due: $ 0.00");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("FMXXXX : Selling Broker’s Funds Due")]
        public void FMUC0026_REG0006()
        {
            try
            {
                Reports.TestDescription = "FMXXXX : Selling Broker’s Funds Due";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile(AddNewLoanAmount: false);
                #endregion

                #region Create an instance of Sellers Listing broker.
                Reports.TestStep = "Create an instance of Sellers Listing broker.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();

                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add Credit Listing Broker in Selling Broker screen .";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(5, 1, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();

                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("200.00" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText("300.00");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Verify the Selling Broker's Fund Due for a non-zero negative amount.
                Reports.TestStep = "Verify the Selling Broker's Fund Due for a non-zero negative amount.";

                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Selling Broker's Funds Due: $ 100.00").ToString(), "Verify FalieBalanceSymmaryTable Contains: Selling Broker's Funds Due:$100.00");
                #endregion

                #region Edit the Commision Amount

                Reports.TestStep = "Edit the Commision Amount Buyer's (Selling) Broker.";

                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(2, "Other Broker 1 for HUD Test Name 1", 2, TableAction.Click);

                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000.00");
                FastDriver.BottomFrame.Done();

                #endregion


                #region Verify the Selling Broker's Fund Due for a zero or positive number
                Reports.TestStep = "Verify the Selling Broker's Fund Due for a zero or positive number.";

                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Selling Broker's Funds Due: $ 0.00").ToString(), "Verify FalieBalanceSymmaryTable Contains: Selling Broker's Funds Due: $ 0.00");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        [Description("FMXXXX : Other RE Broker’s Funds Due")]
        public void FMUC0026_REG0007()
        {
            try
            {
                Reports.TestDescription = "FMXXXX : Other RE Broker’s Funds Due";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile(AddNewLoanAmount: false);
                #endregion

                #region Enter Buyer credit and Seller credit for Other Broker 1st instance.
                Reports.TestStep = "Enter Buyer credit and Seller credit for Other Broker 1st instance.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();

                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("100.00");
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("150.00");

                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText("150.00");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Verify the Other Broker's Fund Due for a non-zero negative amount.
                Reports.TestStep = "Verify the Other Broker's Fund Due for a non-zero negative amount.";

                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Other RE Broker's Funds Due: $ 200.00").ToString(), "Verify FalieBalanceSymmaryTable Contains: Listing Broker's Funds Due:$100.00");
                #endregion

                #region Edit the Commision Amount

                Reports.TestStep = "Edit the Commision Amount.";

                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(2, "Other Broker 1 for HUD Test Name 1", 2, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();


                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000.00");
                FastDriver.BottomFrame.Done();

                #endregion


                #region Verify the Other Broker's Fund Due for a zero or positive number
                Reports.TestStep = "Verify the Other Broker's Fund Due for a zero or positive number.";

                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Selling Broker's Funds Due: $ 0.00").ToString(), "Verify FalieBalanceSymmaryTable Contains: Selling Broker's Funds Due: $ 0.00");
                #endregion

                #region Enter Buyer credit and Seller credit for Other Broker 2nd instance.
                Reports.TestStep = "Enter Buyer credit and Seller credit for Other Broker 2nd instance.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();

                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("50.00");
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("1000.00");

                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText("1000.00");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Verify the Other Broker's Fund Due for an aggregate amount of Other Broker
                Reports.TestStep = "Verify the Other Broker's Fund Due for an aggregate amount of Other Broker.";

                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Other RE Broker's Funds Due: $ 1,250.00").ToString(), "Verify FalieBalanceSymmaryTable Contains: Listing Broker's Funds Due:$100.00");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("FM2782 : Projected File Balance")]
        public void FMUC0026_REG0008()
        {
            try
            {
                Reports.TestDescription = "FM2782 : Projected File Balance";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile(AddNewLoanAmount: false);
                #endregion

                #region Credit Buyer's (Selling) Broker
                Reports.TestStep = "Credit Buyer's (Selling) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();

                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("600.00");
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("700.00");

                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Credit to Buyer Seller" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("75.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();

                #endregion
                
                #region Enter Buyer credit and Seller credit for Other Broker 1st instance.
                Reports.TestStep = "Enter Buyer credit and Seller credit for Other Broker 1st instance.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();

                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("100.00");
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("150.00");

                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText("150.00");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Add Credit Listing Broker in Selling Broker screen
                Reports.TestStep = "Add Credit Listing Broker in Selling Broker screen .";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("50.00");
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText("500.00");

                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Credit to Buyer Seller" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("500.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();

                #endregion


                #region Create new OTC instance with fund deposit
                Reports.TestStep = "Create new OTC instance with fund deposit.";

                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.GABcode.FASetText("814");
                FastDriver.OTCDetail.Find.FAClick(); 
                FastDriver.OTCDetail.ChargesRetained.FASetText("250.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to Deposit outside escrow and set values for seller's broker

                Reports.TestStep = "Navigate to Deposit outside escrow and set values for seller's broker.";
                
                DepositOutsideEscrowParameters DepositData = new DepositOutsideEscrowParameters();
                DepositData.TotalDeposit = 500.00;
                DepositData.EarnerstMoneyHeldBy_0 = "Seller's Broker";
                DepositData.EarnerstMoneyName_0 = "Seller's Broker";
                DepositData.EarnerstMoneyAmount_0 = 500.00;

                FastDriver.DepositOutsideEscrow.Open();
                FastDriver.DepositOutsideEscrow.Deposit(DepositData);

                FastDriver.BottomFrame.Save();

                #endregion


                #region Verify the Projected File Balance amount.
                Reports.TestStep = "Verify the Projected File Balance amount.";

                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Projected File Balance").ToString(), "Verify FalieBalanceSymmaryTable Contains: Projected File Balance");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Error Warning Conditions : Covered EWC3 and FM3189")]
        public void FMUC0026_REG0009()
        {
            try
            {
                Reports.TestDescription = "Error Warning Conditions : Covered EWC3 and FM3189";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Sanity Deposit In Escrow";
                DepositData.ReceivedFrom = "Buyer";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile();
                #endregion
                              
                #region Set an instance for Lease Details with charge amount entered
                Reports.TestStep = "Set an instance for Lease Details with charge amount entered.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("5.00");
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion
                               
                #region Deposit a Cash
                Reports.TestStep = "Deposit a cash.";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region Validate that active disbursement
                Reports.TestStep = "Validate that active disbursement screen is loaded.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();


                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();

                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                #endregion 

                #region Change the Lease Charges Amount after disbursement
                Reports.TestStep = "Change the Lease Charges Amount after disbursement.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.BuyerCharge.FASetText("3.00" + FAKeys.Tab);
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?", FastDriver.WebDriver.HandleDialogMessage());

                #endregion

                #region Navigate to File balance summary screen and verify the presence of EWC3 messages.
                Reports.TestStep = "Navigate to File balance summary screen and verify the presence of EWC3 messages.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.IssuedAmountsexceedactulachargemessage.IsDisplayed().ToString(), "IssuedAmountsexceedactulachargemessage is displayed");
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DifferenceAmountLabel.IsDisplayed().ToString(), "DifferenceAmountLabel is displayed");
                Support.AreEqual("2.00", FastDriver.EscrowFileBalanceSummary.DifferenceAmountValue.FAGetText().Trim(), "DifferenceAmountValue value");
                Support.AreEqual("SHORT", FastDriver.EscrowFileBalanceSummary.Inbalance.FAGetText().Trim());
                Reports.TestStep = "Verify the File Balance Display Amount color.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.Inbalance.FAGetAttribute("style").Contains("red").ToString(), "Inbalance text color: red");

             
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Business Rules Covered: FM4920, FM4951, FM2764, FM2765, FM1057, FM2767, FM3486, FM2768, FM2769, FM2785, FM2746, FM3192, ES7559 and ES11644.")]
        public void FMUC0026_REG0010()
        {
            try
            {
                Reports.TestDescription = "Business Rules Covered: FM4920, FM4951, FM2764, FM2765, FM1057, FM2767, FM3486, FM2768, FM2769, FM2785, FM2746, FM3192, ES7559 and ES11644.";


                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile();
                #endregion

                #region Remove New Loan Amount.
                Reports.TestStep = "Remove New Loan Amount.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("0" + FAKeys.Tab);
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Done.";
                FastDriver.NewLoan.FindGABCode("726");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create an OTC instance
                Reports.TestStep = "Create an OTC instance.";

                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.GABcode.FASetText("HUDOUTESC1");
                FastDriver.OTCDetail.Find.FAClick();
                FastDriver.OTCDetail.WaitForScreenToLoad();
                FastDriver.OTCDetail.ChargesRetained.FASetText("250.00" + FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.OTCDetail.WaitForScreenToLoad();

                #endregion

                #region Create second Instance of Outside Title Company
                Reports.TestStep = "Create second Instance of Outside Title Company.";
                FastDriver.OTCDetail.Open();

                Reports.TestStep = "Click on New button.";
                FastDriver.BottomFrame.New();
                FastDriver.OTCDetail.WaitForScreenToLoad();
                FastDriver.OTCDetail.GABcode.FASetText("759");
                FastDriver.OTCDetail.Find.FAClick();
                FastDriver.OTCDetail.WaitForScreenToLoad(); FastDriver.OTCDetail.ChargesRetained.FASetText("100.00" + FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to File balance summary screen and verify the 1st OTC charges are retained
                Reports.TestStep = "Navigate to File balance summary screen and verify the 1st OTC charges are retained.";
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual("SHORT", FastDriver.EscrowFileBalanceSummary.Inbalance.FAGetText().Trim());
                Support.AreEqual("250.00-", FastDriver.EscrowFileBalanceSummary.FBSProjectedTable.PerformTableAction(1, "Funds Deposited with OTC:", 3, TableAction.GetText).Message.Trim(),"Verify Funds Deposited with OTC");
                
                
                Support.AreEqual(false.ToString(), FastDriver.EscrowFileBalanceSummary.Recieved.IsSelected().ToString(), "Recieved Checked?");

                Reports.TestStep = "Verify the File Balance Display Amount color.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetAttribute("style").Contains("red").ToString(), "FileBalance text color: red");
                
                #endregion

                #region Select the Funds Received checkbox.
                Reports.TestStep = "Select the Funds Received checkbox.";
                FastDriver.NewLoan.Open();

                FastDriver.NewLoan.LoanDetailsFundsReceived.FAClick();
                string LenderName = FastDriver.NewLoan.BusinessPartyNameField.FAGetText();

                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.LoanChargesOriginationChargebuyercharge.FASetText("100" + FAKeys.Tab);

                if(_GetCurrentFileFormType() == FormType.HUD){
                    FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingDescription2.FASetText("Extra Charge" + FAKeys.Tab);
                }
               
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to File balance summary screen and verify the 1st OTC charges are retained
                Reports.TestStep = "Navigate to File balance summary screen and verify New Loan funding are not retained if Loan Funding Received.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Verify Funds Deposited with OTC.";
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.FBSProjectedTable.PerformTableAction(1, "Funds Deposited with OTC:", 3, TableAction.GetText).Message.Trim(), "Verify Funds Deposited with OTC");

                Reports.TestStep = "Verify Our Origination charge is not included in Project Loan Funding.";
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.FBSProjectedTable.PerformTableAction(1, "Projected Loan Funding:", 3, TableAction.GetText).Message.Trim(), "Verify Projected Loan Funding");

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.Recieved.IsSelected().ToString(), "Recieved Checked?");
                #endregion

                #region Add Hold Funds for Buyer and Seller
                Reports.TestStep = "Add Hold Funds for Buyer and Seller.";
                FastDriver.HoldFunds.Open();

                FastDriver.HoldFunds.SellerCharge.FASetText("4.00" + FAKeys.Tab);
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to Hold Fund Screen and Add Hold Funds
                Reports.TestStep = "Navigate to Hold Fund Screen.";
                FastDriver.HoldFunds.Open();
                Reports.TestStep = "Click on New.";

                FastDriver.BottomFrame.New();
                FastDriver.HoldFunds.WaitForScreenToLoad();

                if (!FastDriver.HoldFunds.RadbtnBuyer.IsSelected()) { 
                    FastDriver.HoldFunds.RadbtnBuyer.FAClick();
                }

                FastDriver.HoldFunds.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to File balance summary screen and verify the Buyer/Seller Funds Held
                Reports.TestStep = "Navigate to File balance summary screen and verify the Buyer/Seller Funds Held.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Verify Buyer's Funds Due in File Balance summary.";
                Support.AreEqual("5,120.00", FastDriver.EscrowFileBalanceSummary.FBSProjectedTable.PerformTableAction(1, "Buyer's Funds Due:", 3, TableAction.GetText).Message.Trim(), "Verify Buyer's Funds Due");

                Reports.TestStep = "Verify the Buyer Funds Due color.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetAttribute("style").Contains("red").ToString(), "BuyerFundsDue text color: red");

                Reports.TestStep = "Verify the Buyer/Seller Funds Held After Close.";
                Support.AreEqual("4.00", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1, "Seller", 3, TableAction.GetText).Message.Trim(), "Verify FundsHeldSeller Amount ");
                Support.AreEqual("20.00", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1, "Buyer", 3, TableAction.GetText).Message.Trim(), "Verify FundsHeldBuyer Amount ");

                Reports.TestStep = "Verify Buyer's Funds Held in File Balance summary.";
                Support.AreEqual("20.00", FastDriver.EscrowFileBalanceSummary.FilaBalanceSummaryActualPostedTable.PerformTableAction(1, "Buyer Funds Held:", 3, TableAction.GetText).Message.Trim(), "Verify Buyer's Funds Due");

                Reports.TestStep = "Verify Seller's Funds Held in File Balance summary.";
                Support.AreEqual("4.00", FastDriver.EscrowFileBalanceSummary.FilaBalanceSummaryActualPostedTable.PerformTableAction(1, "Seller Funds Held:", 3, TableAction.GetText).Message.Trim(), "Verify Buyer's Funds Due");

                Reports.TestStep = "Verify Projected File Balance Amount in File Balance summary.";
                Support.AreEqual("100.00", FastDriver.EscrowFileBalanceSummary.FBSProjectedTable.PerformTableAction(1, "Projected File Balance:", 3, TableAction.GetText).Message.Trim(), "Verify Buyer's Funds Due");

                Reports.TestStep = "Verify the Projected File Balance Amount color.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.ProjectedFileBalanceAmount.FAGetAttribute("style").Contains("green").ToString(), "ProjectedFileBalanceAmount text color: green");

                #endregion

                #region Create a Second and Third New Loan instance

                Reports.TestStep = "Create a Second New Loan instance.";
                FastDriver.NewLoan.Open();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();

                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                string LenderName2 = FastDriver.NewLoan.BusinessPartyNameField.FAGetText();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create Third New Loan instance.";
                FastDriver.NewLoanSummary.Open();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();

                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("Lender");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();

                string LenderName3 = FastDriver.NewLoan.BusinessPartyNameField.FAGetText();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to File balance summary screen and verify the Order of New Loan sequence
                Reports.TestStep = "Navigate to File balance summary screen and verify the Order of New Loan sequence.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.FAGetText().ToLower().Contains(LenderName.ToLower()).ToString(), "Verify LoanProceedsSummaryTable Contains: " + LenderName);
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.FAGetText().ToLower().Contains(LenderName2.ToLower()).ToString(), "Verify LoanProceedsSummaryTable Contains: " + LenderName2);
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.FAGetText().ToLower().Contains(LenderName3.ToLower()).ToString(), "Verify LoanProceedsSummaryTable Contains: " + LenderName3);

                Reports.TestStep = "Verify the Net Charges Amount in Loan Proceeds Summary table.";
                FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.PerformTableAction(3, "-100.00", 3, TableAction.Click);
                #endregion

                #region Enter Fees
                Reports.TestStep = "Navigate to File Fees Screen.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "5.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to File Fees Screen. and Edit PDD
                Reports.TestStep = "Navigate to File Fees Screen and Edit PDD.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 3, TableAction.Click);

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                if (_GetCurrentFileFormType() == FormType.CD)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("3.00");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("2.00");
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Lender");
                }
                else {
                    FastDriver.PaymentDetailsDlg.BuyerPaidByBuyer.FASetText("3.00");
                    FastDriver.PaymentDetailsDlg.BuyerPaidByLender.FASetText("2.00");
                }
              

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to File balance summary screen and Verify the Net Fees in Loan Proceeds Summary table.
                Reports.TestStep = "Navigate to File Balance Summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();

          
                Reports.TestStep = "Verify the Net Fees in Loan Proceeds Summary table.";
                FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.PerformTableAction(4, "2.00", 4, TableAction.Click);
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Business Rules Covered: FM2776, FM1051, FM1058, FM3305, FM3306, FM3307, FM2741, FM3303, FM3304 and FM3302.")]
        public void FMUC0026_REG0011()
        {
            try
            {
                Reports.TestDescription = "Business Rules Covered: FM2776, FM1051, FM1058, FM3305, FM3306, FM3307, FM2741, FM3303, FM3304 and FM3302.";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Deposit In Escrow for Buyer";
                DepositData.ReceivedFrom = "Buyer";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile();
                #endregion

                #region Deposit a Cash for Buyer
                Reports.TestStep = "Deposit a cash for Buyer.";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region Deposit a Cash for Seller
                Reports.TestStep = "Deposit a cash for Seller.";
                DepositData.Amount = 20.00;
                DepositData.ReceivedFrom = "Seller";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region Deposit a Cash for Other
                Reports.TestStep = "Deposit a cash for Other.";
                DepositData.Amount = 30.00;
                DepositData.ReceivedFrom = "Other";
                DepositData.Payor = "Other Payee Name 1";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion
                
                #region Navigate to File balance summary screen and verify the Net Deposits of Buyer, Seller and Other.
                Reports.TestStep = "Navigate to File balance summary screen and verify the Net Deposits of Buyer, Seller and Other.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Verify the Buyer Deposit Amount.";
                Support.AreEqual("10.00", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Net Deposits:", 4, TableAction.GetText).Message.Trim(), "Verify Buyer Net Deposits");
                Support.AreEqual("20.00", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Net Deposits:", 6, TableAction.GetText).Message.Trim(), "Verify Seller Net Deposits");
                Support.AreEqual("30.00", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Net Deposits:", 8, TableAction.GetText).Message.Trim(), "Verify Other Net Deposits");
                Support.AreEqual("60.00", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Net Deposits:", 10, TableAction.GetText).Message.Trim(), "Verify Total Net Deposits");
                
                #endregion

                #region Buyer DepositAdjust 
                Reports.TestStep = "Navigate to Deposit History and Adjust Buyer.";

                FastDriver.DepositReceiptHistory.Open();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6,"10.00",7,TableAction.Click);
                FastDriver.DepositReceiptHistory.Adjust.FAClick();

                Reports.TestStep = "Correct Amount.";
                FastDriver.DepositAdjustment.SwitchToContentFrame();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                FastDriver.DepositAdjustment.WaitCreation(FastDriver.DepositAdjustment.CorrectAmount);
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("5.00");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.BottomFrame.Done();

                #endregion 

                #region Seller DepositAdjust
                Reports.TestStep = "Navigate to Deposit History and Adjust Seller.";

                FastDriver.DepositReceiptHistory.Open();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, "20.00", 7, TableAction.Click);
                FastDriver.DepositReceiptHistory.Adjust.FAClick();

                Reports.TestStep = "Correct Amount.";
                FastDriver.DepositAdjustment.SwitchToContentFrame();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                FastDriver.DepositAdjustment.WaitCreation(FastDriver.DepositAdjustment.CorrectAmount);
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("10.00");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.BottomFrame.Done();

                #endregion 

                #region Other DepositAdjust
                Reports.TestStep = "Navigate to Deposit History and Adjust Other.";

                FastDriver.DepositReceiptHistory.Open();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, "30.00", 7, TableAction.Click);
                FastDriver.DepositReceiptHistory.Adjust.FAClick();

                Reports.TestStep = "Correct Amount.";
                FastDriver.DepositAdjustment.SwitchToContentFrame();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                FastDriver.DepositAdjustment.WaitCreation(FastDriver.DepositAdjustment.CorrectAmount);
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("15.00");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.BottomFrame.Done();

                #endregion 
                    
                #region Navigate to File balance summary screen and Net Adjustments.
                Reports.TestStep = "Navigate to File Balance Summary screen and Net Adjustments.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Verify the Buyer Net Adjustments.";
                Support.AreEqual("5.00-", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Net Adjustments:", 4, TableAction.GetText).Message.Trim(), "Verify Buyer Net Adjustments");
                Support.AreEqual("10.00-", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Net Adjustments:", 6, TableAction.GetText).Message.Trim(), "Verify Seller Net Adjustments");
                Support.AreEqual("15.00-", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Net Adjustments:", 8, TableAction.GetText).Message.Trim(), "Verify Other Net Adjustments");
                Support.AreEqual("30.00-", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Net Adjustments:", 10, TableAction.GetText).Message.Trim(), "Verify Total Net Adjustments");

                #endregion

                #region Deposit a Cash for Buyer
                Reports.TestStep = "Deposit a cash for Buyer.";

                DepositData.Amount = 5000.00;
                DepositData.Payor = "";
                DepositData.ReceivedFrom = "Buyer";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region Set an instance for Lease Details with charge amount entered
                Reports.TestStep = "Set an instance for Lease Details with charge amount entered.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.GABcode.FASetText("Lease");
                FastDriver.LeaseDetail.Find.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();

                FastDriver.LeaseDetail.SellerCharge.FASetText("6000.00");
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to File balance summary screen and Verify the Seller's Funds Due.
                Reports.TestStep = "Navigate to File Balance Summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Verify the Seller's Funds Due Amount.";
                Support.AreEqual("990.00", FastDriver.EscrowFileBalanceSummary.SellerFundsDue.FAGetText().Trim(), "Seller's Funds Due value");
                
                Reports.TestStep = "Verify the Seller's Funds Due Amount color.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.SellerFundsDue.GetAttribute("style").ToLower().Contains("red").ToString(), "Verify the SellerFundsDue color: red ");

                Reports.TestStep = "Verify Seller's Funds Due in File Balance summary.";
                Support.AreEqual("990.00", FastDriver.EscrowFileBalanceSummary.FBSProjectedTable.PerformTableAction(1, "Seller's Funds Due:", 3, TableAction.GetText).Message.Trim(), "Verify File Balance Summary (Projected) Table - Seller's Funds Due value");

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        [Description("Business Rules Covered: FM912, , FM3420, FM3421, FM3423, FM3422, FM1463, FM2743, FM2744, FM914, ES9901.")]
        public void FMUC0026_REG0012()
        {
            try
            {
                Reports.TestDescription = "Business Rules Covered: FM912, , FM3420, FM3421, FM3423, FM3422, FM1463, FM2743, FM2744, FM914, ES9901.";
                              
                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile();
                #endregion

                #region Remove New Loan Amount
                Reports.TestStep = "Remove New Loan Amount.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("0" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FindGABCode("247");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Set an instance for Lease Details with charge amount
                Reports.TestStep = "Set an instance of the Lease Details with charge amount.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.GABcode.FASetText("Lease");
                FastDriver.LeaseDetail.Find.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();

                FastDriver.LeaseDetail.BuyerCharge.FASetText("5.00");
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Enter Fees
                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();

                #endregion
                
                #region Set an instance for Survey Details with charge amount entered
                Reports.TestStep = "Set an instance for Survey Details with charge amount entered.";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.FindGABCode("Survey");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("20.00");
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to File balance summary screen and Net Adjustments and Verify the Count of Pending Disbursement.
                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Verify the Count of Pending Disbursement.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.FAGetText().Contains("(4) Pending Issue").ToString(), "Verify DisbursementSummaryTotals contains: (4) Pending Issue");

                #endregion

                #region Navigate to Active Disbursement Sumamry, Select a Pending check and change it to Wire
                Reports.TestStep = "Navigate to Active Disbursement Sumamry screen.";
                FastDriver.ActiveDisbursementSummary.Open();

                Reports.TestStep = "Select a Pending check and change it to Wire.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItemBySendingKeys("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the conversion of Check to Wire.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Wire", 1, TableAction.Click);


                #endregion

                #region Navigate to File balance summary screen, Verify the Count of Pending Disbursement
                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Verify the Count of Pending Disbursement.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.FAGetText().Contains("(1) Created Disbursement: $ 4,997.01").ToString(), "Verify DisbursementSummaryTotals contains:(1) Created Disbursement: $ 4,997.01");

                #endregion

                #region Navigate to Active Disbursement Sumamry, Select a Pending check 
                Reports.TestStep = "Navigate to Active Disbursement Sumamry screen and Select a Pending Check.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Enter the Hold Information details.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                FastDriver.EditDisbursement.HoldInformation.FAClick();
                                             
                string HoldFor = "7";
                if (DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Sunday") { 
                    HoldFor = "9";
                }
                FastDriver.EditDisbursement.HoldFor.FASetText(HoldFor);
                FastDriver.EditDisbursement.PurposeOfHold.FASetText("Holding the disbursement");
                FastDriver.BottomFrame.Save();

            #endregion

                #region Navigate to Active Disbursement Sumamry screen and Verify Held
                Reports.TestStep = "Navigate to Active Disbursement Sumamry screen and Verify Held.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Held", 1, TableAction.Click);
                                
                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Verify the Count of Pending Disbursement.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.FAGetText().Contains("(1) Held Checks: $ 20.00").ToString(), "Verify DisbursementSummaryTotals contains: (1) Held Checks: $ 20.00");

                
                #endregion

                #region Navigate to Document Repository screen and Click on Scan button
                Reports.TestStep = "Navigate to Document Repository screen and Click on Scan button.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();

                FastDriver.DocumentRepository.Scan_FiltrTempTab.FAClick();

                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();

                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Save the TIF Doc.";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);
                #endregion

                #region Navigate to Active Disbursement Summary screen and Convert to wire attach Instruction
                Reports.TestStep = "Navigate to Active Disbursement Summary screen.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Wire", 1, TableAction.Click);

                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.Add.FAClick();
                FastDriver.SelectWireInstructionsDlg.SelectWireInstruction();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion  

                #region Navigate to Active Disbursement Summary screen and DisburseAll
                Reports.TestStep = "Navigate to Active Disbursement Summary screen.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.IssueDisbursements.Disburse.FAClick();
                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Playback.Wait(5000);
         //       FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                #endregion
                
                #region Navigate to File balance summary screen
                Reports.TestStep = "Navigate to File balance summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.FAGetText().Contains("(1) Issued Checks: $ 5.00").ToString(), "Verify DisbursementSummaryTotals contains:(1) Created Disbursement: $ 4,997.01");
                
                Reports.TestStep = "Verify the Issued Wires and Count.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.FAGetText().Contains("(1) Issued Wires: $ 4,997.01").ToString(), "Verify DisbursementSummaryTotals contains:(1) Created Disbursement: $ 4,997.01");

                Reports.TestStep = "Verify the Total Issued and Count.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.FAGetText().Contains("(2) Total Issued: $ 5,002.01").ToString(), "Verify DisbursementSummaryTotals contains:(1) Created Disbursement: $ 4,997.01");

                Reports.TestStep = "Verify the Net Issued.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.FAGetText().Contains("Net Issued: $ 5,002.01").ToString(), "Verify DisbursementSummaryTotals contains:(1) Created Disbursement: $ 4,997.01");

                #endregion

                #region Navigate to Active Disbursement Summary screen and Disburse a Fee.
                Reports.TestStep = "Navigate to Active Disbursement Summary screen and Disburse a Fee.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3,"Fee Transfer",1,TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(5000);

                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region Navigate to File balance summary screen,Verify the Issued Fee Transfer
                Reports.TestStep = "Navigate to File Balance Summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Verify the Issued Fee Transfer.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.FAGetText().Contains("(1) Issued Fee Transfer: $ 4.98").ToString(), "Verify DisbursementSummaryTotals contains:(1) Issued Fee Transfer: $ 4.98");

                #endregion

                #region Navigate to Active Disbursement Summary screen and Select the Held Record.
                Reports.TestStep = "Navigate to Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Held", 1, TableAction.Click);

                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Release Hold and Save the changes made.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ReleaseHold.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                #endregion
                
                #region Navigate to Active Disbursement Summary screen and Print All
                Reports.TestStep = "Navigate to Active Disbursement Summary screen and Click on Print All.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();


                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Playback.Wait(5000);

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
               
                #endregion

                #region Navigate to Disbursement History and Process a One-Sided Adjustment on a Disbursement
                Reports.TestStep = "Navigate to Disbursement History";
                FastDriver.DisbursementHistory.Open();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(7,"5.00",3,TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Disbursement.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Cancel");
                Support.AreEqual(true.ToString(), FastDriver.DisbursementAdjustment.Description.FAGetValue().Contains(DateTime.Now.ToDateString()).ToString(),"Description contains Current Date");
                FastDriver.DisbursementAdjustment.Comment.FASetText("Comments for cancel");
                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print);
                #endregion

                #region Navigate to File balance summary screen,Verify the Issued Fee Transfer
                Reports.TestStep = "Navigate to File Balance Summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Verify the Issued Fee Transfer.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.FAGetText().Contains("Net Adjustments: $ 5.00-").ToString(), "Verify DisbursementSummaryTotals contains:Net Adjustments: $ 5.00-");

                Reports.TestStep = "Verify the Net Issued.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.FAGetText().Contains("Net Issued: $ 5,021.99").ToString(), "Verify DisbursementSummaryTotals contains:Net Issued: $ 5,001.99");

                #endregion

                #region Navigate to Active Disbursement Summary screen,  Get the Doc # for SellerName SellerLastName
                Reports.TestStep = " Navigate to Active Disbursement Summary screen,  Get the Doc # for SellerName SellerLastName.";
                FastDriver.ActiveDisbursementSummary.Open();
                string DocNumber = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "SellerName SellerLastName", 5, TableAction.GetText).Message.Trim();

                Reports.TestStep = "Verify the tool tip details is present on mouse hovering of Issued Check Mark icon.";
                FastDriver.EscrowFileBalanceSummary.Open();

               string SellerCheckIssuedFlagTitle = FastDriver.EscrowFileBalanceSummary.SellerCheckIssuedFlag.GetAttribute("title");
               Support.AreEqual(true.ToString(), SellerCheckIssuedFlagTitle.Contains(DocNumber).ToString(), "Veryfi  Issued Check has the correct Doc Number");
               Support.AreEqual(true.ToString(), SellerCheckIssuedFlagTitle.Contains("4,997.01").ToString(), "Veryfi  Issued Check has the correct Issued Amount");

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Business Rules Covered: ES13107, ES13109.")]
        public void FMUC0026_REG0013()
        {
            try
            {
                Reports.TestDescription = "Business Rules Covered: ES13107, ES13109.";
                Reports.TestStep = "ES13109: MANUALLY VERIFY the presence of Trial Balance Note in Trust32 Extract.";
                               
                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                _CreateFile();
                #endregion

                #region Navigate to File balance summary screen and Validate the field definition of Trial balance note
                Reports.TestStep = "Navigate to File Balance Summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();

                FastDriver.EscrowFileBalanceSummary.TrialBalanceNote.FAClick();
                Reports.TestStep = "Enter More than sixty one character.";
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();

                FastDriver.TrialBalanceNoteDlg.Notes.FASetText(@"test comment length should not exceed 61&^*(^*)&(;\/ testing _,/\");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the field definition of Trial balance note.";
                string ErrorMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: false);

                Support.AreEqual(true.ToString(), ErrorMessage.Contains("Error: Internal Comment length of 65 exceeds maximum of 61.").ToString(), "Dialog Message Contains: Error: Internal Comment length of 65 exceeds maximum of 61");
                Support.AreEqual(true.ToString(), ErrorMessage.Contains("Reduce the size of the internal comment to 61 or less to save.").ToString(), "Dialog Message Contains: Reduce the size of the internal comment to 61 or less to save.");

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton:false,switchBackToFastWindow:false);

                Reports.TestStep = "Enter with Special character.";
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText(@"test comment length 61&^*(^*)&(;\/ testing _,/\");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the error message for trial balance note.";
                Support.AreEqual("Please enter a valid Trial Balance Note.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false));

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: false);

                Reports.TestStep = "Enter a note from File Balance Summary screen.";
                FastDriver.TrialBalanceNoteDlg.WaitForScreenToLoad();
                FastDriver.TrialBalanceNoteDlg.Notes.FASetText(@"Note From File Balance Summary screen-,\/");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName); 
            
                #endregion

                #region Navigate to Trust Accounting Interface screen
                Reports.TestStep = "Navigate to Trust Accounting Interface screen.";
                FastDriver.TrustAccounting.Open();
                FastDriver.TrustAccounting.BuildExtract.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.TrustAccounting.WaitForScreenToLoad();

                FastDriver.TrustAccounting.Display.FAClick();
                FastDriver.TrustAccounting.WaitForScreenToLoad();
                FastDriver.TrustAccounting.Display.FAClick();

                Reports.TestStep = "Select Pending Extract record.";

                FastDriver.TrustAccounting.WaitForPedingExtract();

                FastDriver.TrustAccounting.ExtractFilesTable.PerformTableAction(3,"Pending",3,TableAction.Click);

                FastDriver.TrustAccounting.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TrustAccounting.Deliver.FAClick();
                FastDriver.TrustAccounting.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");
                FastDriver.WebDriver.ClosePreviewWindow();


                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Business Rules Covered: ES9929, ES9930.")]
        public void FMUC0026_REG0014()
        {
            try
            {
                Reports.TestDescription = "Business Rules Covered: ES9929, ES9930.";
                Reports.TestStep = "ES9929 and ES9930: VERIFY MANUALLY the Paid Check Status using Simulator.";

                DepositParameters DepositData = new DepositParameters();
                DepositData.Amount = 10.00;
                DepositData.TypeofFunds = "Cash";
                DepositData.Representing = "Additional Closing Costs";
                DepositData.Description = "Deposit In Escrow for Buyer";
                DepositData.ReceivedFrom = "Buyer";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                OrderDetailsResponse FileData = _CreateFile();
                #endregion

                #region Deposit a Cash
                Reports.TestStep = "Deposit a cash.";

                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(DepositData);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                #endregion

                #region Set an instance for Lease Details with charge amount entered
                Reports.TestStep = "Set an instance for Lease Details with charge amount entered.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.FindGABcode("Lease");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("6000.00");
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to Active Disbursement Summary screen
                Reports.TestStep = "Navigate to Active Disbursement Summary screen.";
                FastDriver.ActiveDisbursementSummary.Open();

                Reports.TestStep = "Print the checks.";
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();

                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                #endregion

                #region Navigate to Trust Accounting Interface screen
                Reports.TestStep = "Navigate to Trust Accounting Interface screen.";
                FastDriver.TrustAccounting.Open();
                FastDriver.TrustAccounting.BuildExtract.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.TrustAccounting.WaitForScreenToLoad();

                FastDriver.TrustAccounting.Display.FAClick();
                FastDriver.TrustAccounting.WaitForScreenToLoad();
                FastDriver.TrustAccounting.Display.FAClick();

                Reports.TestStep = "Select Pending Extract record.";
                Playback.Wait(10000);
                FastDriver.TrustAccounting.WaitForScreenToLoad();
                FastDriver.TrustAccounting.ExtractFilesTable.PerformTableAction(3, "Pending", 3, TableAction.Click);

                Reports.TestStep = "Click on Transmit Now button.";
                FastDriver.TrustAccounting.TransmitNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Business Rules Covered: ES6083, ES6085.")]
        public void FMUC0026_REG0015()
        {
            try
            {
                Reports.TestDescription = "Business Rules Covered: ES6083, ES6085.";
             
                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create an Escrow and Sub-Escrow Order.";
                OrderDetailsResponse FileData = _CreateSubEscrowFile();
                #endregion

                #region Navigate to Trust Outside Escrow Company and set BuyerCharge
                Reports.TestStep = "Navigate to Trust Outside Escrow Company.";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC1");
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("OEC" + FAKeys.Tab);
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to File Balance Summary screen and Verifying the presence of Outside Escrow Company
                Reports.TestStep = "Navigate to File Balance Summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Verifying the presence of Outside Escrow Company for a Sub-Escrow file.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Outside Escrow Company $ 0.00 $ 20.00 $").ToString(), "Verify File Balance Summary Table contains: Outside Escrow Company $ 0.00 $ 20.00 $");

                #endregion 

                #region Navigate to File Homepage screen and Remove Sub Escrow Service Type
                Reports.TestStep = "Navigate to File Homepage screen and Remove Sub Escrow Service Type.";

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.SwitchToContentFrame();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to File Balance Summary screen and Verifying the conversion of Outside Escrow Company to file's Buyer and Seller.
                Reports.TestStep = "Navigate to File Balance Summary screen.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Verifying the conversion of Outside Escrow Company to file's Buyer and Seller.";
                Support.AreEqual(true.ToString(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryTable.FAGetText().Contains("Buyer $ 0.00 $ 20.00 $").ToString(), "Verify File Balance Summary Table Contains: Buyer $ 0.00 $ 20.00 $");
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        
        #region PRIVATE METHODS

        private OrderDetailsResponse _CreateFile(bool AddNewLoanAmount = true, bool AddSalesPriceAmount = true)
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = _GetCurrentFileFormType();
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            if (AddSalesPriceAmount)
                customizableFileRequest.File.SalesPriceAmount = 5000;
            if (AddNewLoanAmount)
                customizableFileRequest.File.FirstNewLoanAmount = 5000;
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        } 
                };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            return File;
        }

        private OrderDetailsResponse _CreateSubEscrowFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = _GetCurrentFileFormType();
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
           

            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        } 
                };

            customizableFileRequest.File.Services = new Service[] 
                    { 
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "SEO"
                        }
                    };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            return File;

        }

        private void _IISLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Login to IIS";
            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private FormType _GetCurrentFileFormType() {
            return AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
        }
           
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}