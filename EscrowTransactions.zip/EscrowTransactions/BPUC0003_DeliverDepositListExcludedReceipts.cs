﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.Common;
using System.Windows.Forms;

namespace EscrowTransactions
{
    [CodedUITest]
    [DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class BPUC0003 : MasterTestClass
    {
        [TestMethod]
        public void BPUC0003_REG0001()
        {
            try
            {
                Reports.TestDescription = "001: Exclude deposit list";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();


                Reports.TestStep = "Executing Pre-requisite for REG0001";
                REG0001_PreRequisite();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile();


                Reports.TestStep = "Deposit a cashier's check. For that, Navigate to Depost In Escrow page.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();


                FastDriver.DepositInEscrow.Amount.FASetText(@"1,000.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(@"Cashier's Check");
                FastDriver.DepositInEscrow.Representing.FASelectItem(@"Initial Deposit");
                FastDriver.DepositInEscrow.Description.FASetText(@"Initial Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(@"Buyer");
//                FastDriver.DepositInEscrow.Comment.FASetText("Comments Before Save");
                FastDriver.DepositInEscrow.CheckNumber.FASetText(@"1234567889");
                FastDriver.DepositInEscrow.ABANumber.FASetText(@"1234567895");
                FastDriver.DepositInEscrow.BankName.FASetText(@"23testbank");
                FastDriver.DepositInEscrow.AccountNumber.FASetText(@"1234567895");

                FastDriver.BottomFrame.Save();
                
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 10);

                Reports.TestStep = "Saving the Deposit Receipt Number";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                var depositReceiptNumber = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();


                Reports.TestStep = "Create a deposit list with select the dates and click on Exclude button.";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();

                //FastDriver.DepositList.WaitForScreenToLoad();

                FastDriver.DepositList.New.FAClick();
                var DateFrom = DateTime.Now.ToString("M-dd-yyyy");
                FastDriver.DepositList.IssueDateFrom.FASetText(@DateFrom);
                var DateTo = DateTime.Now.ToString("M-dd-yyyy");
                FastDriver.DepositList.IssueDateTo.FASetText(@DateTo);
                FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
                Playback.Wait(20000);

                FastDriver.DepositList.ReceiptsTable.PerformTableAction(7, depositReceiptNumber, 3, TableAction.Click);
                var cellValue = FastDriver.DepositList.ReceiptsTable.PerformTableAction(7, depositReceiptNumber,3, TableAction.GetText).Message.ToString();
                Reports.StatusUpdate("Is the deposit amount equal to 1000.00 ?", cellValue == "1,000.00");
                

                FastDriver.DepositList.Exclude.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Exclude a receipt entering the comments.";
                FastDriver.ExclusionCommentDlg.WaitForScreenToLoad();
                FastDriver.ExclusionCommentDlg.Comments.FASetText(@"Reason1 for exclusion");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);


                FastDriver.BottomFrame.Done();
                Playback.Wait(6000);

                Reports.TestStep = "Verify the receipt which is excluded.";
                FastDriver.LeftNavigation.Navigate<ExcludedReceipts>(@"Home>Business Unit Processing>Deposit Slip>Excluded Receipts").WaitForScreenToLoad();

                DateTo = DateTime.Now.ToDateString();
                FastDriver.ExcludedReceipts.ToDate.FASetText(DateTo);

                FastDriver.ExcludedReceipts.FindNow.FAClick();
                FastDriver.ExcludedReceipts.WaitForScreenToLoad();

                //FastDriver.ExcludedReceipts.ExcludedReceiptDate.FAClick();

                FastDriver.ExcludedReceipts.ExcludedReceiptsTable.PerformTableAction(2, depositReceiptNumber, 5, TableAction.Click);
                cellValue = FastDriver.ExcludedReceipts.ExcludedReceiptsTable.PerformTableAction(2, depositReceiptNumber, 5, TableAction.GetText).Message.ToString();
                Reports.StatusUpdate("Is the excluded deposit amount equal to 1000.00 ?", cellValue == "1,000.00");

                Reports.TestStep = "Preview and deliver.";
                PerformDelivery("Preview");
                
                /*FastDriver.ExcludedReceipts.Method.FASelectItem("Preview");
                FastDriver.ExcludedReceipts.Deliver.FAClick();
                if (FASTLibrary.FASTLibrary.WaitforDeliveryWindow("Preview").ToString() == "False")
                    General.AreEqual("", FASTLibrary.FASTLibrary.GeneralMessage);*/
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }   
        }

        [TestMethod]
        public void BPUC0003_REG0001_Precondition_ExpectedFailure()
        {
            Reports.TestDescription = "This is a required pre-condition for REG0001, which is called explicitly from within REG0001 itself.";
            Reports.StatusUpdate("This is not an independent Test Method ! This preconidtion is called from REG0001 !", true);
        }

        #region BPUC0003_REG0002_PH

        [TestMethod]
        public void BPUC0003_REG0002_PH()
        {
            try
            {
                Reports.TestDescription = "UncoveredBRs: 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22";

                Reports.TestStep = "Dummy test to use it as a Place holder for non-automated scenarios.";
                Assert.Inconclusive("This flow has NOT been automated. Please perform this MANUALLY !");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion BPUC0003_REG0002_PH

        //Team                                    : ServReq
        //Iteration                               : r10
        //UserStory                               : User Story 748571:INC2374897 - Direct [Bug] - Spell Check missing from Email and Fax Modules
        //TestCase                                : 884495
        //Appended By/ Created By                 : Nikhil
        [TestMethod]
        public void BPUC0003_REG0003()
        {
            try
            {
                Reports.TestDescription = "001: Exclude deposit list";

                Reports.TestStep = "Login to FAST IIS.";
                this.LoginToIIS();


                Reports.TestStep = "Executing Pre-requisite for REG0001";
                REG0001_PreRequisite();

                Reports.TestStep = "Create a file with default values.";
                var fileNumber = CreateFile();


                Reports.TestStep = "Deposit a cashier's check. For that, Navigate to Depost In Escrow page.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();


                FastDriver.DepositInEscrow.Amount.FASetText(@"1,000.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(@"Cashier's Check");
                FastDriver.DepositInEscrow.Representing.FASelectItem(@"Initial Deposit");
                FastDriver.DepositInEscrow.Description.FASetText(@"Initial Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(@"Buyer");
                //                FastDriver.DepositInEscrow.Comment.FASetText("Comments Before Save");
                FastDriver.DepositInEscrow.CheckNumber.FASetText(@"1234567889");
                FastDriver.DepositInEscrow.ABANumber.FASetText(@"1234567895");
                FastDriver.DepositInEscrow.BankName.FASetText(@"23testbank");
                FastDriver.DepositInEscrow.AccountNumber.FASetText(@"1234567895");

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 10);

                Reports.TestStep = "Saving the Deposit Receipt Number";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                var depositReceiptNumber = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();


                Reports.TestStep = "Create a deposit list with select the dates and click on Exclude button.";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();

                //FastDriver.DepositList.WaitForScreenToLoad();

                FastDriver.DepositList.New.FAClick();
                var DateFrom = DateTime.Now.ToString("M-dd-yyyy");
                FastDriver.DepositList.IssueDateFrom.FASetText(@DateFrom);
                var DateTo = DateTime.Now.ToString("M-dd-yyyy");
                FastDriver.DepositList.IssueDateTo.FASetText(@DateTo);
                FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
                Playback.Wait(20000);

                FastDriver.DepositList.ReceiptsTable.PerformTableAction(7, depositReceiptNumber, 3, TableAction.Click);
                var cellValue = FastDriver.DepositList.ReceiptsTable.PerformTableAction(7, depositReceiptNumber, 3, TableAction.GetText).Message.ToString();
                Reports.StatusUpdate("Is the deposit amount equal to 1000.00 ?", cellValue == "1,000.00");


                FastDriver.DepositList.Exclude.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Exclude a receipt entering the comments.";
                FastDriver.ExclusionCommentDlg.WaitForScreenToLoad();
                FastDriver.ExclusionCommentDlg.Comments.FASetText(@"Reason1 for exclusion");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);


                FastDriver.BottomFrame.Done();
                Playback.Wait(6000);

                Reports.TestStep = "Verify the receipt which is excluded.";
                FastDriver.LeftNavigation.Navigate<ExcludedReceipts>(@"Home>Business Unit Processing>Deposit Slip>Excluded Receipts").WaitForScreenToLoad();

                DateTo = DateTime.Now.ToDateString();
                FastDriver.ExcludedReceipts.ToDate.FASetText(DateTo);

                FastDriver.ExcludedReceipts.FindNow.FAClick();
                FastDriver.ExcludedReceipts.WaitForScreenToLoad();

                //FastDriver.ExcludedReceipts.ExcludedReceiptDate.FAClick();

                FastDriver.ExcludedReceipts.ExcludedReceiptsTable.PerformTableAction(2, depositReceiptNumber, 5, TableAction.Click);
                cellValue = FastDriver.ExcludedReceipts.ExcludedReceiptsTable.PerformTableAction(2, depositReceiptNumber, 5, TableAction.GetText).Message.ToString();
                Reports.StatusUpdate("Is the excluded deposit amount equal to 1000.00 ?", cellValue == "1,000.00");


                #region Spell Check
                Reports.TestStep = "Spell check-email and fax";
                FastDriver.DepositList.Method.FASelectItem("Email");
                FastDriver.FileFees.Deliver.FAClick();
                FastDriver.SpellingErrorDlg.SpellCheck_Email();
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        #region Private Methods

        private void LoginToIIS()
        {
            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            #endregion

            try
            {
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            }
            catch (Exception)
            {
                throw new Exception("Login is unsuccessful ! Aborting the test !");
            }
        }


        #region Pre-requisites
        private bool REG0001_PreRequisite()
        {
            try
            {
                Reports.TestStep = "Navigate to Deposit List";
                FastDriver.LeftNavigation.Navigate<DepositList>(@"Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();

                Reports.TestStep = "Check if Pending Deposit List exists";
                if (!FastDriver.DepositList.New.IsEnabled())
                {
                    Reports.TestStep = "Pending Deposit List Exists. Clear all Pending deposit lists.";
                    Support.AreEqual("true", FastDriver.DepositList.FindNow.IsEnabled().ToString().ToLower());
                    FastDriver.DepositList.FindNow.FAClick();


                    Reports.TestStep = "Select the Pending Deposit List";
                    FastDriver.DepositList.WaitForScreenToLoad();
                    FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.Click);


                    Reports.TestStep = "Click Edit button";
                    FastDriver.DepositList.Edit.FAClick();


                    Reports.TestStep = "Click Find Now in Edit Deposit List Screen";
                    FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                    FastDriver.DepositList.DepositListEdit_FindNow.FAClick();

                    Reports.TestStep = "Check Select All Check Box";
                    FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                    if ((FastDriver.DepositList.SelectAll.FAGetAttribute("checked") ?? "false") == "false")
                    {
                        FastDriver.DepositList.SelectAll.FAClick();
                        FastDriver.WebDriver.HandleDialogMessage();
                        FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                    }
                    
                    FastDriver.DepositList.Complete.FAClick();
                    Reports.TestStep = "Print Dialog is displayed. Click Cancel button.";
                    FastDriver.PrintDlg.WaitForScreenToLoad();
                    FastDriver.PrintDlg.ClickCancel();

                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.DepositList.WaitForScreenToLoad();
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        #endregion



        #region File Creation

        private string CreateFile(bool OnDemandRequest = false, string GABCode = "", bool IsAutoNumber = true)
        {
            string fileNumber = "";
            try
            {
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = BuildCreateFileRequest();
                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            }
            catch
            {
                return "";
            }
            return fileNumber;
        }


        private CreateFileRequest BuildCreateFileRequest()
        {
            var x = new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,
                
                #region File
                File = new File()
                {
                    SalesPriceAmount = 5000,
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "COMMERCIAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    
                    
                    BusinessParties = new FileBusinessParty[] 
                    { 
                        
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE" 
                        },
                    },
                    
                   
                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[]
                    { 
                        new Property() 
                        {
                            Name = "J305",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",
                            ProperyTypeCdID = 15, //Single Family Residence
                            
                            Taxes = new Taxes[]
                            {
                                new Taxes()
                                {
                                     APN = "Prop1APN1",
                                },
                                new Taxes()
                                {
                                     APN = "9845012345",
                                }
                            },
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA" 
                                    
                                } 
                            } 
                        } 
                    },
                    Buyers = new BuyerSeller[] 
                    { 
                        new BuyerSeller() 
                        { 
                            Type = "Individual",
                            SSN = "123-45-6789",
                            FirstName = "Buyer1Firstname",
                            LastName = "Buyer1Lastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband And Wife",
                            FirstName = "Buyer2Firstname",
                            LastName = "Buyer2Lastname",
                            SpouseFirstName = "Buyer2SpouseName",
                            SpouseLastName = "Buyer2Lastname"
                        }
                    },
                    Sellers = new BuyerSeller[] 
                    {
                        new BuyerSeller() 
                        {
                            Type = "Individual",
                            SSN = "987-65-4321",
                            FirstName = "Seller1FirstName",
                            LastName = "Seller1SpouLastname",
                        },                        
                        new BuyerSeller() 
                        { 
                            Type = "Husband And Wife",
                            FirstName = "Seller2Firstname",
                            LastName = "Seller2Lastname",
                            SpouseFirstName = "Seller2SpouseName",
                            SpouseLastName = "Seller2SpouLastname"
                        }
                    },

                    
                  /*  NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                    {
                        LoanNumber = "WCF_DefaultLoanNumber",
                        NewLoanAmount = 5000.00m,
                        LiabilityAmount = 5000.00m,
                        BenMortgageeTextID = 0,
                        FileBusinessParty = new FileBusinessParty
                        {
                            Name = "Nhat Nguyen",
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        },
                        LoanTypeCdID = 0,
                        FundDate = DateTime.Today
                    },*/

                    FileNotes = new FileNote[] 
                    { 
                        new FileNote()
                        {
                            TypeCdID = 695, //EPIC
                            Note = @"Notes Data including - * # Specialcharacter :) !"
                        }
                    }
                }
                #endregion
            };
            

            return x;
        }

        #endregion


        #region Delivery Functions

        private bool isAlertPresent()
        {
            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                if (Message.Contains("No printer") || Message.Contains("error while populating printers"))
                {
                    Reports.StatusUpdate("Printer is not configured", false);
                }
                else if (string.IsNullOrEmpty(Message))
                {
                    return false;
                }

                return true;
            }
            catch (OpenQA.Selenium.NoAlertPresentException)
            {
                return false;
            }
        }

        private bool HandleDeliveryFailure(string deliveryMethod, int timeoutSeconds)
        {
            try
            {
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, timeoutSeconds);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return true;
            }
            catch (OpenQA.Selenium.WebDriverTimeoutException)
            {
                Reports.StatusUpdate(string.Format("'{0}' failed after {1} seconds.", deliveryMethod, timeoutSeconds), false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return false;
            }
        }

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Random ran=new Random();
                int ranNumber= ran.Next(250);
                Playback.Wait(5000);
                PDFFilePath = PDFFilePath.Replace(".PDF", ranNumber + ".PDF");

                Keyboard.SendKeys("^{S}", System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", System.Windows.Input.ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true);

                Keyboard.SendKeys("{F4}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This close the dialog

                Keyboard.SendKeys("{N}", System.Windows.Input.ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Keyboard.SendKeys("{F4}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        private void PerformDelivery(string deliveryMethod)
        {
            Reports.TestStep = "Perfom the " + deliveryMethod + " delivery method.";
            FastDriver.ExcludedReceipts.Method.FASelectItem(deliveryMethod);
            FastDriver.ExcludedReceipts.Deliver.FAClick();

            switch (deliveryMethod)
            {
                case "Email":
                    {
                        FastDriver.EmailDlg.WaitForDialogToLoad();
                        FastDriver.EmailDlg.SendEmail();
                        FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, 200);
                        break;
                    }
                case "Print":
                    {
                        if (!isAlertPresent())
                        {
                           // FastDriver.WebDriver.WaitForWindowAndSwitch(windowName: "Print", timeoutSeconds: 20);
                            FastDriver.PrintDlg.WaitForScreenToLoad();
                            FastDriver.PrintDlg.SelectPrinter();
                            FastDriver.PrintDlg.ClickPrint();
                            HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 200 ? 200 : int.Parse(AutoConfig.WaitTime) * 3);
                        }
                        else
                        {
                            Reports.StatusUpdate("Printer is not configured correctly", false);
                        }
                        break;
                    }
                case "Fax":
                    {
                        FastDriver.FaxDlg.WaitForScreenToLoad();
                        FastDriver.FaxDlg.SendFax();
                        FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, 200);
                        break;
                    }
                case "Preview":
                    {
                        //FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, 200);
                        if (HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 250 ? 250 : int.Parse(AutoConfig.WaitTime) * 3))
                        {
                            Reports.TestStep = "Save PDF file";
                            string tempPdfFile = @"C:\Temp\temp.PDF";
                            SavePDFFile(tempPdfFile);
                        }
                        break;
                    }
            }
            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
            FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.FindNow);
        }

        #endregion

        #endregion


        /*[ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }*/
    }
}
