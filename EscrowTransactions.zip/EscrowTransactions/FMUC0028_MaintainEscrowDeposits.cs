﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.Common;
using FASTWCFHelpers.FastFileService;

namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0028 : MasterTestClass
    {
        public FMUC0028()
        {

        }

        #region BAT
        [TestMethod]
        public void FMUC0028_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF: Record a Deposit in Escrow by Cash";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Perform a Cash Deposit
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Perform a cash deposit.";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 10.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Saurabh Jain",
                    CreditToSeller = false,
                    Comments = "Comments Before Save",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                #endregion

                #region Validate the Deposit Details in Deposit Summary page
                Reports.TestStep = "Navigate to Deposit Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();

                Reports.TestStep = "Select the performed deposit from the list.";
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(7, depositDetail.Payor, 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.Click();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();

                Reports.TestStep = "Validate the results are matching with the actual one.";
                Support.AreEqual(string.Format("{0:0.00}", depositDetail.Amount), FastDriver.DepositInEscrow.Amount.FAGetValue());
                Support.AreEqual(depositDetail.TypeofFunds.ToString(), FastDriver.DepositInEscrow.TypeofFunds.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Representing.ToString(), FastDriver.DepositInEscrow.Representing.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Description.ToString(), FastDriver.DepositInEscrow.Description.FAGetValue());
                Support.AreEqual(depositDetail.ReceivedFrom.ToString(), FastDriver.DepositInEscrow.ReceivedFrom.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Payor.ToString(), FastDriver.DepositInEscrow.Payor.FAGetValue());
                Support.AreEqual(depositDetail.Comments.ToString(), FastDriver.DepositInEscrow.Comment.FAGetValue());
                Support.AreEqual(depositDetail.CreditToSeller.ToString(), FastDriver.DepositInEscrow.CredittoSeller.Selected.ToString(), true);
                #endregion

                #region Move to the ADM side and create the accounts for upcoming scripts.
                #region Login to ADM side
                this.ADMLOGIN();
                #endregion

                #region Move to the regional level and select the 1486 office.
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                #endregion

                #region Move to the office setup of STEST and select the office bank accounts tab.
                Reports.TestStep = "Navigate to Office Setup screen";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();

                Reports.TestStep = "Open the bank accounts setup for the office.";
                FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
                FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
                #endregion

                #region Verify that account 1230/4533/3109200000/3120370000 accounts are available, if not create it.
                Reports.TestStep = "Creating a list for the account number and verifying whether they are available.";
                string[] accountArray = new string[4] { "1230", "4533", "3109200000", "3120370000" };
                string accntTableContnt = FastDriver.OfficeSetupBankAccounts.BanksTable.FAGetText();
                for (int counter = 0; counter < accountArray.Length; counter++)
                {
                    if (!accntTableContnt.Contains(accountArray[counter]))
                    {
                        Reports.TestStep = accountArray[counter] + " is not available hence click on new button to create.";
                        FastDriver.OfficeSetupBankAccounts.BankAccountSummaryNew.FAClick();

                        Reports.TestStep = "Entering the bank account details.";
                        FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad(FastDriver.OfficeSetupBankAccounts.BankAccountDetail_BankName);
                        FastDriver.OfficeSetupBankAccounts.BankAccountDetail_BankName.FASelectItem("Automation Bank - Automation Testing");
                        FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad(FastDriver.OfficeSetupBankAccounts.BankAccountDetailAccountNo1);
                        FastDriver.OfficeSetupBankAccounts.BankAccountDetailAccountNo1.FASetText(accountArray[counter]);
                        FastDriver.OfficeSetupBankAccounts.BankAccountDetail_AccountDescription.FASetText("Automation Account " + counter);
                        FastDriver.OfficeSetupBankAccounts.DepositAcct.FASetCheckbox(true);
                        FastDriver.OfficeSetupBankAccounts.DisburseAcct.FASetCheckbox(true);
                        FastDriver.BottomFrame.Done();

                        Reports.TestStep = "Navigate to Office Setup screen";
                        FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();

                        Reports.TestStep = "Open the bank accounts setup for the office.";
                        FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
                        FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
                    }
                    else
                    {
                        Reports.StatusUpdate(accountArray[counter] + " is available at banks table", true);
                    }
                }

                #region Make the Wirelink Interface account checkbox enabled.
                Reports.TestStep = "Make the Wirelink Interface account checkbox enabled.";
                FastDriver.LeftNavigation.Navigate<BankSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Banks").WaitForScreenToLoad();
                FastDriver.BankSummary.BankSummaryTable.PerformTableAction(1, "Automation Bank", 1, TableAction.Click);
                FastDriver.BankSummary.Edit.FAClick();
                FastDriver.BankDetail.WireInterfaceBank.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                #endregion

                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_BAT0001 failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1: Manual Receipt Number";
                string manualReason = "This Manual cash deposit for testing.";
                string recieptNo = this.getRecieptNo;
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File.
                CreateBasicFile();
                #endregion

                #region Perform a Cash Deposit with Manual reciept number.
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Perform a cash deposit.";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 8000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Testing Payor",
                    CreditToSeller = true,
                    Comments = "It is a Manual Cash deposit.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                #endregion

                #region Add Manual Check number.
                Reports.TestStep = "Click on the Manual Button and provide the manual check number";
                FastDriver.DepositInEscrow.Manual.FAClick();
                FastDriver.DepositInEscrow.ReceiptNo.SendKeys(OpenQA.Selenium.Keys.Backspace);
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(recieptNo);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Add Comment for the Manual cash deposit.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText(manualReason);
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                //FastDriver.PrintDlg.WaitForScreenToLoad();
                //FastDriver.PrintDlg.Cancel.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                #endregion

                #region Move to Deposit Summary page and select the perform deposit from the list.
                Reports.TestStep = "Navigate to Deposit Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();

                Reports.TestStep = "Select the performed deposit from the list.";
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(7, depositDetail.Payor, 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.Click();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Validate the Deposit details.
                Reports.TestStep = "Validate the results are matching with the actual one.";
                Support.AreEqual(string.Format("{0:0,0.00}", depositDetail.Amount), FastDriver.DepositInEscrow.Amount.FAGetValue());
                Support.AreEqual(depositDetail.TypeofFunds.ToString(), FastDriver.DepositInEscrow.TypeofFunds.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Representing.ToString(), FastDriver.DepositInEscrow.Representing.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Description.ToString(), FastDriver.DepositInEscrow.Description.FAGetValue());
                Support.AreEqual(depositDetail.ReceivedFrom.ToString(), FastDriver.DepositInEscrow.ReceivedFrom.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Payor.ToString(), FastDriver.DepositInEscrow.Payor.FAGetValue());
                Support.AreEqual(depositDetail.Comments.ToString(), FastDriver.DepositInEscrow.Comment.FAGetValue());
                Support.AreEqual(recieptNo, FastDriver.DepositInEscrow.ReceiptNo.FAGetValue());
                Support.AreEqual(manualReason, FastDriver.DepositInEscrow.ManualReceiptReason.FAGetText());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_BAT0002 failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF2: Record a Deposit in Escrow by Cashiers Check, Personal Check or Money Order.";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Perform a Deposit with Cashier's check.
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Perform a Cashier's check deposit.";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 111.00,
                    TypeofFunds = "Cashier's Check",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Testing Payor",
                    CreditToSeller = false,
                    Comments = "It is a Manual Cash deposit.",
                    CheckNumber = "12345678",
                    ABANumber = "1234567895",
                    AccountNumber = "123456743",
                    BankName = "23testbank"
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 20);
                #endregion

                #region Move to Deposit Summary page and select the perform deposit from the list.
                Reports.TestStep = "Navigate to Deposit Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();

                Reports.TestStep = "Select the performed deposit from the list.";
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(7, depositDetail.Payor, 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.Click();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Validate the Deposit details.
                Reports.TestStep = "Validate the results are matching with the actual one.";
                Support.AreEqual(string.Format("{0:0.00}", depositDetail.Amount), FastDriver.DepositInEscrow.Amount.FAGetValue());
                Support.AreEqual(depositDetail.TypeofFunds.ToString(), FastDriver.DepositInEscrow.TypeofFunds.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Representing.ToString(), FastDriver.DepositInEscrow.Representing.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Description.ToString(), FastDriver.DepositInEscrow.Description.FAGetValue());
                Support.AreEqual(depositDetail.ReceivedFrom.ToString(), FastDriver.DepositInEscrow.ReceivedFrom.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Payor.ToString(), FastDriver.DepositInEscrow.Payor.FAGetValue());
                Support.AreEqual(depositDetail.Comments.ToString(), FastDriver.DepositInEscrow.Comment.FAGetValue());
                Support.AreEqual(depositDetail.CreditToSeller.ToString(), FastDriver.DepositInEscrow.CredittoSeller.Selected.ToString(), true);
                Support.AreEqual(depositDetail.ABANumber, FastDriver.DepositInEscrow.ABANumber.FAGetValue());
                Support.AreEqual(depositDetail.AccountNumber, FastDriver.DepositInEscrow.AccountNumber.FAGetValue());
                Support.AreEqual(depositDetail.BankName, FastDriver.DepositInEscrow.BankName.FAGetValue());
                Support.AreEqual(depositDetail.CheckNumber, FastDriver.DepositInEscrow.CheckNumber.FAGetValue());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_BAT0003 failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF3: Record a Deposit in Escrow by Wire.";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Perform a Deposit with Wire.
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Perform a Cashier's check deposit.";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 111.00,
                    TypeofFunds = "Wire",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Testing Payor",
                    CreditToSeller = false,
                    Comments = "It is a Wire deposit.",

                    WireBankName = "Automation Bank Wire",
                    ConfirmationNumber = "123456789",
                    BankContact = "Test Contact",
                    FedRoutingNumber = "456789",
                    ConfirmationTime = "01:01:01"
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 20);
                #endregion

                #region Move to Deposit Summary page and select the perform deposit from the list.
                Reports.TestStep = "Navigate to Deposit Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();

                Reports.TestStep = "Select the performed deposit from the list.";
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(7, depositDetail.Payor, 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.Click();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Validate the Deposit details.
                Reports.TestStep = "Validate the results are matching with the actual one.";
                Support.AreEqual(string.Format("{0:0.00}", depositDetail.Amount), FastDriver.DepositInEscrow.Amount.FAGetValue());
                Support.AreEqual(depositDetail.TypeofFunds.ToString(), FastDriver.DepositInEscrow.TypeofFunds.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Representing.ToString(), FastDriver.DepositInEscrow.Representing.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Description.ToString(), FastDriver.DepositInEscrow.Description.FAGetValue());
                Support.AreEqual(depositDetail.ReceivedFrom.ToString(), FastDriver.DepositInEscrow.ReceivedFrom.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Payor.ToString(), FastDriver.DepositInEscrow.Payor.FAGetValue());
                Support.AreEqual(depositDetail.Comments.ToString(), FastDriver.DepositInEscrow.Comment.FAGetValue());
                Support.AreEqual(depositDetail.CreditToSeller.ToString(), FastDriver.DepositInEscrow.CredittoSeller.Selected.ToString(), true);
                Support.AreEqual(depositDetail.WireBankName, FastDriver.DepositInEscrow.WireBankName.FAGetValue());
                Support.AreEqual(depositDetail.ConfirmationNumber, FastDriver.DepositInEscrow.ConfirmationNum.FAGetValue());
                Support.AreEqual(depositDetail.BankContact, FastDriver.DepositInEscrow.BankContact.FAGetValue());
                Support.AreEqual(depositDetail.FedRoutingNumber, FastDriver.DepositInEscrow.FederalRoutingNumber.FAGetValue());
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DepositInEscrow.ConfirmationDate.FAGetValue());
                Support.AreEqual(depositDetail.ConfirmationTime, FastDriver.DepositInEscrow.ConfirmationTime.FAGetValue());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_BAT0004 failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF4: Record a Deposit in Escrow by Credit Card";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Perform a Deposit with Credit Card option.
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Perform a Cashier's check deposit.";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 113.00,
                    TypeofFunds = "Credit Card",
                    Representing = "Earnest Money Deposit",
                    Description = "Earnest Money Deposit with Credit card",
                    ReceivedFrom = "Buyer",
                    Payor = "Testing Payor",
                    CreditToSeller = false,
                    Comments = "It is a Credit card deposit.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 20);
                #endregion

                #region Move to Deposit Summary page and select the perform deposit from the list.
                Reports.TestStep = "Navigate to Deposit Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();

                Reports.TestStep = "Select the performed deposit from the list.";
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(7, depositDetail.Payor, 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.Click();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Validate the Deposit details.
                Reports.TestStep = "Validate the results are matching with the actual one.";
                Support.AreEqual(string.Format("{0:0.00}", depositDetail.Amount), FastDriver.DepositInEscrow.Amount.FAGetValue());
                Support.AreEqual(depositDetail.TypeofFunds.ToString(), FastDriver.DepositInEscrow.TypeofFunds.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Representing.ToString(), FastDriver.DepositInEscrow.Representing.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Description.ToString(), FastDriver.DepositInEscrow.Description.FAGetValue());
                Support.AreEqual(depositDetail.ReceivedFrom.ToString(), FastDriver.DepositInEscrow.ReceivedFrom.FAGetSelectedItem());
                Support.AreEqual(depositDetail.Payor.ToString(), FastDriver.DepositInEscrow.Payor.FAGetValue());
                Support.AreEqual(depositDetail.Comments.ToString(), FastDriver.DepositInEscrow.Comment.FAGetValue());
                Support.AreEqual(depositDetail.CreditToSeller.ToString(), FastDriver.DepositInEscrow.CredittoSeller.Selected.ToString(), true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_BAT0005 failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_BAT0006_PH()
        {
            try
            {
                Reports.TestDescription = "AF5_FM1424_ES9928_ES12806_ES12808_ES12809_ES12810PlaceHolder: Record a Deposit in Escrow by IBA Transaction";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_BAT0006 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_BAT0007()
        {
            try
            {
                Reports.TestDescription = "MF1: Approve IBA Transactions.8.2 Updates.";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Perform a Cash Deposit
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Perform a cash deposit.";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 213.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Seller",
                    Payor = "Testing Payor1",
                    CreditToSeller = false,
                    Comments = "Comments Before Save",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Fetch the recieved from and Deposited account details.
                Reports.TestStep = "Get the values for the deposited to account detail and payor detail.";
                string depositedToAccnt = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                #endregion

                #region Enter the details for 2nd cash deposit.
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Enter the Details for the 2nd Deposit.";
                DepositParameters depositDetail2 = new DepositParameters()
                {
                    Amount = 242.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Seller",
                    Payor = "Testing Payor2",
                    CreditToSeller = false,
                    Comments = "Comments Before Save",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail2);
                #endregion

                #region Validate the value for Recieving date, Payor and Deposited to Account details.
                Reports.TestStep = "Validate the value of the  Deposited to Account, It should be same as in 1st deposit.";
                Support.AreEqual(depositedToAccnt, FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem());
                #endregion

                #region Change the Depositedto Account to some other account.
                Reports.TestStep = "Change the deposited to account number to another account.";
                FastDriver.DepositInEscrow.DepositedTo.FASelectItem("1230");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate the message on changing the account number.
                string messageContent = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string depositedToAccnt2 = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                Support.AreEqual("There are existing deposits in account " + depositedToAccnt + ". Are you sure about proceeding with deposits to a different account?", messageContent);
                #endregion

                #region Move to Deposit History, select the first Deposit and Validate the details.
                Reports.TestStep = "Navigate to Deposit Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();

                Reports.TestStep = "Select the first deposit from the list.";
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, string.Format("{0:0.00}", depositDetail.Amount), 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.Click();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();

                Reports.TestStep = "Validate the results are matching with the actual one for first deposit.";
                Support.AreEqual(depositedToAccnt, FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem());
                #endregion

                #region Move to Deposit History, select the Second deposit and Validate the details.
                Reports.TestStep = "Navigate to Deposit Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();

                Reports.TestStep = "Select the Second deposit from the list.";
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, string.Format("{0:0.00}", depositDetail2.Amount), 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.Click();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();

                Reports.TestStep = "Validate the results are matching with the actual one for first deposit.";
                Support.AreEqual(depositedToAccnt2, FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_BAT0007 failed because " + ex.Message);
            }
        }
        #endregion

        #region REG
        [TestMethod]
        public void FMUC0028_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM909_ FM911: FMUC0028 Deposits in Escrow_ Prompt to print receipt_FM1423 Print by office preference.";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Move to OTC page and enter the OTC details.
                Reports.TestStep = "Navigate to the OTC details page.";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>("Home>Order Entry>Outside Title Company").WaitForScreenToLoad();

                Reports.TestStep = "Enter the OTC details.";
                FastDriver.OutsideTitleCompanyDetail.FindGAB(gab: "814");
                string otcName = FastDriver.OutsideTitleCompanyDetail.GetOutsideTitleCompanyFullName;
                FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable.PerformTableAction(2, 3, TableAction.SetText, "212.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Deposit in Escrow page and perform a cash deposit with recieved from OTC.
                Reports.TestStep = "Navigate to Deposit in Escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Perform a cash deposit with recieved from OTC.";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 213.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Outside Title Company",
                    CreditToSeller = false,
                    Comments = "This Deposit is from the Outside title company.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                #endregion

                #region Verify the name of payor is same as for the GAB entered in the OTC page.
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Support.AreEqual(otcName, FastDriver.DepositInEscrow.Payor.FAGetValue());
                #endregion

                #region Navigate back to Deposit in Escrow and perform another cash deposit.
                Reports.TestStep = "Navigate back to Deposit in Escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Perform an another cash deposit.";
                DepositParameters depositDetail2 = new DepositParameters()
                {
                    Amount = 312.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "testing payor",
                    CreditToSeller = false,
                    Comments = "This Deposit is the normal deposit.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail2);
                FastDriver.BottomFrame.Save();
                Reports.TestStep = "Print the deposit reciept.";
                FastDriver.WebDriver.HandleDialogMessage(timeout: 10);
                #endregion

                #region Print the deposit reciept
                FastDriver.PrintDlg.WaitForScreenToLoad();
                string printerName = FastDriver.PrintDlg.Printers.FAGetSelectedItem();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                #endregion

                #region Navigate to the Printerconfiguration and verify for the default printer.
                Reports.TestStep = "Navigate to Printer Configuration page and verify for the default printer.";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>("Home>Printer Configuration").WaitForScreenToLoad();
                Support.AreEqual(printerName, FastDriver.PrinterConfiguration.CheckPrinterAssignmentsTable.PerformTableAction(1, 4, TableAction.GetSelectedItem).Message);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG00001 failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM910_FM1888_FM1365_FM1421:FM1422_FM1938: Event for manual receipt_Constructed number_Assign Issue Date_Excessive cash deposits_Warning on cash deposits_Event for cash deposits .";
                string recieptNo = this.getRecieptNo;
                string manualReason = "Adding comments for manual check.";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Perform a Cash Deposit with Manual reciept number.
                Reports.TestStep = "Navigate to Deposit in Escrow page.";
                FastDriver.DepositInEscrow.Open();
                Reports.TestStep = "Perform a cash deposit with Manual reciept number.";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 123.00,
                    TypeofFunds = "Cash",
                    Representing = "Earnest Money Deposit",
                    Description = "Earnest Money Deposit",
                    ReceivedFrom = "Seller",
                    Payor = "Testing Payor1",
                    CreditToSeller = false,
                    Comments = "It is a Manual Cash deposit.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                #endregion

                #region Add Manual Check number.
                Reports.TestStep = "Click on the Manual Button and provide the manual check number";
                FastDriver.DepositInEscrow.Manual.Click();
                FastDriver.DepositInEscrow.ReceiptNo.SendKeys(OpenQA.Selenium.Keys.Backspace);
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(recieptNo);
                FastDriver.DepositInEscrow.IssueDte.FASetText("08-20-2015");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Add Comment for the Manual cash deposit.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText(manualReason);
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 5);
                #endregion

                #region Perform an another deposit with system generated reciept.
                Reports.TestStep = "Navigate to Deposit in Escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Perform a cash deposit with automatic reciept number.";
                DepositParameters depositDetail2 = new DepositParameters()
                {
                    Amount = 7000.00,
                    TypeofFunds = "Cash",
                    Representing = "Earnest Money Deposit",
                    Description = "Earnest Money Deposit",
                    ReceivedFrom = "Seller",
                    Payor = "Testing Payor2",
                    CreditToSeller = false,
                    Comments = "This Deposit is second deposit with automatic reciept number.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail2);
                string issueDate = FastDriver.DepositInEscrow.IssueDte.FAGetValue();
                Support.AreEqual(issueDate, DateTime.Now.ToDateString());
                FastDriver.DepositInEscrow.IssueDte.FASetText("08-20-2015");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                #endregion

                #region Perform an another deposit so that it crosses the excess deposit limit.
                Reports.TestStep = "Navigate to Deposit in Escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Perform a cash deposit with automatic reciept number.";
                DepositParameters depositDetail3 = new DepositParameters()
                {
                    Amount = 5000.00,
                    TypeofFunds = "Money Order",
                    Representing = "Initial Deposit",
                    Description = "Intial Deposit",
                    ReceivedFrom = "Seller",
                    Payor = "Testing Payor3",
                    CreditToSeller = false,
                    Comments = "This Deposit is second deposit with automatic reciept number.",

                    CheckNumber = "12345678",
                    ABANumber = "1234567895",
                    AccountNumber = "123456743",
                    BankName = "23testbank"
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail3);
                FastDriver.BottomFrame.Save();
                #endregion

                #region Validate the warning message on excess deposit.
                Reports.TestStep = "Verifying the warning message on  performing the deposit with excess amount.";
                string messageContent = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 20);
                Support.AreEqual("Important! The credit to party contains total cash or similar deposits in excess of $10,000. Form 8300 is required to be completed and filed with the IRS within 15 days.", messageContent);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 20);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                recieptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                string recieptIssueDate = DateTime.Parse(FastDriver.DepositInEscrow.IssueDte.FAGetValue()).ToString("M/d/yyyy");
                #endregion

                #region Navigate to Event/Tracking Log and verify the event log.
                Reports.TestStep = "Navigate to the Event/Tracking Log";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("Accounting/Privacy");
                messageContent = FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Excess Cash Deposits]", 5, TableAction.GetText).Message;

                Reports.TestStep = "Validate the receipt number for excess amount in Event log";
                Support.AreEqual("True", messageContent.Contains(recieptNo).ToString(), true);

                Reports.TestStep = "Validate the receipt issue date for excess amount in Event log";
                Support.AreEqual("True", messageContent.Contains(recieptIssueDate).ToString(), true);

                Reports.TestStep = "Validate the excess amount in Event log";
                string excessAmount = "Amount: " + string.Format("{0:0,0.00}", (depositDetail3.Amount).ToString());
                Support.AreEqual("True", messageContent.Contains(excessAmount).ToString(), true);

                Reports.TestStep = "Validate the Update Trust Accounting status for excess amount in Event log";
                Support.AreEqual("True", messageContent.Contains("Update Trust Accounting=Yes").ToString(), true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0002 failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM1066_FM1068: Deposit cannot be changed_Limited update to deposit.";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Perform the 1st deposit.
                Reports.TestStep = "Navigate to Deposit in Escrow page.";
                FastDriver.DepositInEscrow.Open();
                Reports.TestStep = "Perform the 1st deposit";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 10.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    CreditToSeller = false,
                    Comments = "Comments Before Save",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string recieptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                #endregion

                #region Move to the Deposit history and validate details field are disabled.
                Reports.TestStep = "Navigate to Deposit Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();

                Reports.TestStep = "Select the performed deposit from the list.";
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(4, recieptNo, 4, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.Click();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.VerifyFieldsDisabledAfterDeposit();
                #endregion

                #region Perform the 2nd deposit.
                Reports.TestStep = "Navigate to Deposit in Escrow page to perform 2nd deposit.";
                FastDriver.DepositInEscrow.Open();
                Reports.TestStep = "Perform the 2nd deposit";
                DepositParameters depositDetail2 = new DepositParameters()
                {
                    Amount = 22.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    CreditToSeller = false,
                    Comments = "Comments Before Save",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail2);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                recieptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                #endregion

                #region Move to the Deposit history and validate details field are disabled and change the credit to seller.
                Reports.TestStep = "Navigate to Deposit Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();

                Reports.TestStep = "Select the performed deposit from the list.";
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(4, recieptNo, 4, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.Click();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.VerifyFieldsDisabledAfterDeposit();
                Reports.TestStep = "Change the credit to seller.";
                FastDriver.DepositInEscrow.CredittoSeller.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.DepositInEscrow.CredittoSeller.Selected.ToString(), true);
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoBuyer.Selected.ToString(), true);
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoOther.Selected.ToString(), true);
                #endregion

                #region Perform the 3rd deposit.
                Reports.TestStep = "Navigate to Deposit in Escrow page to perform the 3rd deposit.";
                FastDriver.DepositInEscrow.Open();
                Reports.TestStep = "Perform the 3rd deposit";
                DepositParameters depositDetail3 = new DepositParameters()
                {
                    Amount = 33.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    CreditToSeller = false,
                    Comments = "Comments Before Save",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail3);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                recieptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                #endregion

                #region Move to the Deposit history and validate details field are disabled and change the credit to other.
                Reports.TestStep = "Navigate to Deposit Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();

                Reports.TestStep = "Select the performed deposit from the list.";
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(4, recieptNo, 4, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.Click();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Reports.TestStep = "Change the credit to seller.";
                FastDriver.DepositInEscrow.CredittoOther.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoSeller.Selected.ToString(), true);
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoBuyer.Selected.ToString(), true);
                Support.AreEqual("True", FastDriver.DepositInEscrow.CredittoOther.Selected.ToString(), true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0003 failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM1370: Deposit totals available.";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Perform the 1st deposit with credit to seller and Verify value is updated.
                Reports.TestStep = "Navigate to Deposit in Escrow page to perform 1st deposit.";
                FastDriver.DepositInEscrow.Open();
                Reports.TestStep = "Perform the 1st deposit";
                DepositParameters depositDetail1 = new DepositParameters()
                {
                    Amount = 1234.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    CreditToSeller = true,
                    Comments = "This deposit is credited to seller",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail1);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.VerifyUpdatedDeposits(0.00, 1234.00, 0.00);
                #endregion

                #region Perform the 2nd deposit with credit to buyer and Verify value is updated.
                Reports.TestStep = "Navigate to Deposit in Escrow page to perform 2nd deposit.";
                FastDriver.DepositInEscrow.Open();
                Reports.TestStep = "Perform the 1st deposit";
                DepositParameters depositDetail2 = new DepositParameters()
                {
                    Amount = 12.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "",
                    CreditToBuyer = true,
                    Comments = "This deposit is credited to buyer",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail2);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.VerifyUpdatedDeposits(12.00, 1234.00, 0.00);
                #endregion

                #region Perform the 3rd deposit with credit to buyer and Verify value is updated.
                Reports.TestStep = "Navigate to Deposit in Escrow page to perform 2nd deposit.";
                FastDriver.DepositInEscrow.Open();
                Reports.TestStep = "Perform the 3rd deposit";
                DepositParameters depositDetail3 = new DepositParameters()
                {
                    Amount = 33.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "",
                    CreditToOther = true,
                    Comments = "This deposit is credited to other",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail3);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.VerifyUpdatedDeposits(12.00, 1234.00, 33.00);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0004 failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_REG0006()
        {
            try
            {
                Reports.TestDescription = "FM1444_FM1445: Deposit is never negative _Negative amounts not allowed.";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Navigate to the escrow deposit and try to perform a deposit with negative value.
                Reports.TestStep = "Navigate to Deposit in Escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Perform the deposit with the negative value.";
                FastDriver.DepositInEscrow.Amount.FASetText("-10.00");
                FastDriver.DepositInEscrow.Description.FASetText("Description added");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Verify the error message on performing the deposit with negative amount.
                string messageContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Please correct invalid data entered.", messageContent);
                #endregion

                #region Perform deposit with correct data.
                Reports.TestStep = "Perform deposit with correct data";
                DepositParameters depositDetail1 = new DepositParameters()
                {
                    Amount = 1234.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    CreditToSeller = true,
                    Comments = "This deposit is credited to seller",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail1);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string recieptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                #endregion

                #region Navigate to the Deposit history and select the latest deposit.
                Reports.TestStep = "Navigate to Deposit Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();

                Reports.TestStep = "Select the performed deposit from the list and click on the adjust button.";
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(4, recieptNo, 4, TableAction.Click);
                FastDriver.DepositReceiptHistory.Adjust.FAClick();
                #endregion

                #region Adjust the deposit with negative amount and verify the error message.
                Reports.TestStep = "Adjust the deposit with negative amount.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("-10.00");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the error message occured.";
                messageContent = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Please correct invalid data entered.", messageContent);
                FastDriver.DepositAdjustment.SwitchToContentFrame();
                #endregion

                #region Adjust the deposit with correct positive value of amount and save.
                Reports.TestStep = "Adjust the deposit with positive value of correct amount.";
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("15.00");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0006 failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_REG0007()
        {
            try
            {
                Reports.TestDescription = "ES9132_Flow 1: Issue a Deposit Receipt for Partial Withdrawal";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Perform a cash deposit.
                Reports.TestStep = "Navigate to Deposit in Escrow page to perform 1st deposit.";
                FastDriver.DepositInEscrow.Open();
                Reports.TestStep = "Perform a cash deposit";
                DepositParameters depositDetail1 = new DepositParameters()
                {
                    Amount = 1234.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer's Broker",
                    Payor = "Test Payor",
                    CreditToSeller = true,
                    Comments = "This deposit is credited to seller",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail1);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Add a beneficiary and transaction amount in IBA for the partial withdrawn.
                Reports.TestStep = "Move to the IBA page and click on the New button.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                IBABeneficiary Beneficiary = new IBABeneficiary()
                {
                    BeneficiaryName = "Beneficiary Name1",
                    AddressLine1 = "Beneficiary Name1 Address Line 1",
                    AddressLine2 = "Beneficiary Name1 Address Line 2",
                    City = "Beneficiary Name1 Santa ana",
                    State = "CA",
                    ZipCode = "92727",
                    selectSSN = true,
                    SSNTINnumber = "123456789",
                };
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.AddOtherBeneficiary(Beneficiary);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                #endregion

                #region Select the IBA account details.
                string IBABankName = FastDriver.InterestBearingAccounts.RecordSummaryTable.PerformTableAction(1, 4, TableAction.GetText).Message;
                if (string.IsNullOrWhiteSpace(IBABankName))
                {
                    FastDriver.InterestBearingAccounts.IBABank.FAClick();
                    FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                    FastDriver.SelectIBABankDlg.SelectAutomatedBank("First American Trust, FSB");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                }
                #endregion

                #region Enter transaction amount and Save.
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, 4, TableAction.SetText, "100.00");
                Support.SendKeys("{TAB}");
                FastDriver.BottomFrame.Save();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                string transactionID = FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, 2, TableAction.GetText).Message;
                Support.DataSave("transactionID", transactionID);
                #endregion

                Reports.TestStep = "ES9132_Flow 2:Login TO FAST Application using FASTQA06 user and approve IBA requests.";

                # region DataSetup (Add activity rights to the FASTQA06 user)
                Reports.TestStep = "Add activity rights for the FASTQA06 user to approve IBA transactions.";
                ADMLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);
                Reports.TestStep = "Move to the QA automation-DO NOT TOUCH region.";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to Employee security - Enter userid and search";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.ADM.EmployeeSecurity>("Home>System Maintenance>Security Maintenance>Employee Security").WaitForScreenToLoad();
                FastDriver.EmployeeSecurity.SearchAndSelectEmployee(AutoConfig.UserNameSecondary);

                Reports.TestStep = "Select the Office under the mentioned region.";
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
                FastDriver.BusinessUnitRoleAssignment.SelectOfficeUnderBusinessUnits(officeBUID: AutoConfig.SelectedRegionBUID, officeName: AutoConfig.SelectedOfficeName);

                FastDriver.BusinessUnitRoleAssignment.AddRemoveRolesButton.FAClick();
                FastDriver.RoleSelectionDialog.WaitForScreenToLoad();
                FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction("Role Name", "IT - all", "Select", TableAction.On);
                FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction("Role Name", "Office Administrator", "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Save();


                if (FastDriver.TrackChangeHistoryDialog.IsPresent())
                {
                    FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText("123");
                    FastDriver.TrackChangeHistoryDialog.UserNotes.FASetText("Adding Roles");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
                }
                FastDriver.BottomFrame.Done();
                #endregion

                # region IIS Login with FASTQA06 user.
                Reports.TestStep = "Login into the IIS Side with user FASTQA06.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                #region Approve the IBA Transaction
                Reports.TestStep = "Navigate to the IBA transaction approval.";
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>("Home>Business Unit Processing>IBA Interface>IBA Transaction Approval").WaitForScreenToLoad();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                Support.DataLoad("transactionID");
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(3, Support.data.Trim(), 1, TableAction.Click);
                FastDriver.IBATransactionApproval.Approve.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                # region IIS Login with FASTQA07 user
                IISLOGIN();
                #endregion

                #region Get the previous file opened.
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Navigate to IBA screen and checking for the status. Add button is enabled once transaction is completed.;
                Reports.TestStep = "Navigate to IBA screen and checking for the status. Add button is enabled once transaction is completed.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();

                Reports.TestStep = "Select the created IBA transaction.";
                FastDriver.InterestBearingAccounts.RecordSummaryTable.PerformTableAction(5, "100.00", 5, TableAction.Click);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                Playback.Wait(3000);
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                for (int i = 1; i < 10; i++)
                {
                    if (!FastDriver.InterestBearingAccounts.Add.Enabled)
                    {
                        FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                        FastDriver.InterestBearingAccounts.RecordSummaryTable.PerformTableAction(5, "100.00", 5, TableAction.Click);
                        FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                        FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                        Playback.Wait(5000);
                        FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Add, 20);
                    }
                    else
                    {
                        break;
                    }
                }
                FastDriver.InterestBearingAccounts.Add.FAClick();
                #endregion

                #region Add Partial Withdrawal.
                Reports.TestStep = "Add Partial Withdrawal.";
                FastDriver.AddIBATransactionDlg.WaitForScreenToLoad();
                FastDriver.AddIBATransactionDlg.PartialWithdrawal.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, "Partial Withdrawal", 4, TableAction.SetText, "50.00");
                Support.SendKeys("{TAB}");
                FastDriver.BottomFrame.Save();
                transactionID = FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, "Partial Withdrawl", 2, TableAction.GetText).Message.Trim();
                #endregion

                Reports.TestStep = "ES9132_Flow 2:Login TO FAST Application using FASTQA06 user and approve IBA requests";

                # region IIS Login with FASTQA06 user.
                Reports.TestStep = "Login into the IIS Side with user FASTQA06.";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);
                #endregion

                #region Approve the IBA Transaction.
                Reports.TestStep = "Navigate to the IBA transaction approval.";
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>("Home>Business Unit Processing>IBA Interface>IBA Transaction Approval").WaitForScreenToLoad();

                Reports.TestStep = "Approve the Transaction.";
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                Support.DataLoad("transactionID");
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(3, transactionID, 1, TableAction.On);
                FastDriver.IBATransactionApproval.Approve.FAClick();

                if (FastDriver.IBATransactionPastBankCutoffTimeDlg.IsDisplayed())
                {
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.IBATransactionApproval.WaitForScreenToLoad();
                #endregion

                Reports.TestDescription = "ES9132_Flow 4: Validate the issue deposit for partial withdrawn";

                # region IIS Login with FASTQA07 user
                IISLOGIN();
                #endregion

                #region Get the previous file opened.
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Navigage to the Deposit Summary page.
                Reports.TestStep = "Navigate to Deposit Summary and open the details for partial withdrawl.";
                FastDriver.DepositReceiptHistory.Open();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(8, "IBA Partial Withdrawal", 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.FAClick();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Get the reciept number from the detail.
                Reports.TestStep = "Get the Reciept number from the detail.";
                string getRecieptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                #endregion

                #region NAvigate to Interest bearing account and validate the receipt number from Deposit/Receipt summary.
                Reports.TestStep = "NAvigate to Interest bearing account and validate the receipt number from Deposit/Receipt summary";
                FastDriver.InterestBearingAccounts.Open();
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                string docID = FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, "Partial Withdrawal", 3, TableAction.GetText).Message;
                Support.AreEqual(docID, getRecieptNo);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0007 failed because " + ex.Message);
            }
        }

        [TestMethod, Obsolete]
        public void FMUC0028_REG0008()
        {
            try
            {
                Reports.TestDescription = "ES9132_Flow 3: Add partial withdrawn and approce it from 2nd user.";
                Reports.StatusUpdate("This test method is clubbed with method REG07", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0008 failed because " + ex.Message);
            }
        }

        [TestMethod, Obsolete]
        public void FMUC0028_REG0009()
        {
            try
            {
                Reports.TestDescription = "ES9132_Flow 3: Add partial withdrawn and approve it from 2nd user.";
                Reports.StatusUpdate("This test method is clubbed with method REG07", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0009 failed because: " + ex.Message);
            }
        }

        [TestMethod, Obsolete]
        public void FMUC0028_REG0010()
        {
            try
            {
                Reports.TestDescription = "ES9132_Flow 4: Validate the issue deposit for partial withdrawn";
                Reports.StatusUpdate("This test method is clubbed with method REG07", true);
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0010 failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_REG0012_FMXXXX_1()
        {
            try
            {
                Reports.TestDescription = "FMXXXX_ES15152: Other Radio Button_Default ‘For Credit To’ Setting to ‘Other’ when ‘Received From’ is ‘Other’, ‘Seller’s Broker’, or ‘Buyer’s Broker’.";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Create  Buyers (Selling) Broker instance.
                Reports.TestStep = "Navigate to REB link and Add the Buyers(selling) broker instance .";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("BUYERBROKER", "HUDFLINSR1");
                string buyerBrokerFullName = FastDriver.RealEstateBrokerAgent.GetBrokerFullName;
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create  Sellers (Listing) Broker instance.
                Reports.TestStep = "Navigate to REB link and Add the Sellers(Listing) broker instance.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "243");
                string sellerBrokerFullName = FastDriver.RealEstateBrokerAgent.GetBrokerFullName;
                FastDriver.BottomFrame.Done();
                #endregion

                #region Perform a deposit and select recieved from the Buyer's Broker.
                Reports.TestStep = "Navigate to Deposit in Escrow page to perform deposit.";
                FastDriver.DepositInEscrow.Open();
                Reports.TestStep = "Perform a cash deposit with recieved from Buyers Broker";
                DepositParameters depositDetail1 = new DepositParameters()
                {
                    Amount = 12.21,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer's Broker",
                    CreditToSeller = false,
                    Comments = "This deposit is recieved from the Buyers Broker.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail1);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Validate Default ‘For Credit To’ Setting to ‘Other’ when ‘Received From’ is ‘Buyer’s Broker’.
                Reports.TestStep = "Validate Default ‘For Credit To’ Setting to ‘Other’ when ‘Received From’ is ‘Buyer’s Broker’";
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoBuyer.Enabled.ToString(), true);
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoSeller.Enabled.ToString(), true);
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoOther.Enabled.ToString(), true);
                Support.AreEqual("True", FastDriver.DepositInEscrow.CredittoOther.Selected.ToString(), true);
                #endregion

                #region Verify the amount deposited to Buyer's Broker.
                Reports.TestStep = "Navigate to REB Summary page & Open the Buyers(selling) broker instance..";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("BUYERBROKER");
                Support.AreEqual(depositDetail1.Amount.ToString(), FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionNetCheckAmt.FAGetText());
                #endregion

                #region Verify system will not reflect the deposit to Buyer Broker amount on settlement.
                Reports.TestStep = "Navigate to the View Settlement statement page.";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.");
                FastDriver.ViewSettlementStatement.SwitchToContentFrame();

                Reports.TestStep = "Verify system will not reflect the deposit to Buyer Broker amount on settlement.";
                string tableContent = FastDriver.ViewSettlementStatement.SummaryTable.FAGetText();
                bool result = tableContent.Contains(depositDetail1.Amount.ToString());
                Reports.StatusUpdate("Verification result for 'system will not reflect the deposit to Buyer Broker amount on settlement': " + (!result).ToString(), !result, expectedValue: "False", actualValue: result.ToString());

                #endregion

                #region Perform a deposit and select recieved from the Seller's Broker.
                Reports.TestStep = "Navigate to Deposit in Escrow page to perform deposit.";
                FastDriver.DepositInEscrow.Open();
                Reports.TestStep = "Perform a cash deposit with recieved from Sellers Broker";
                DepositParameters depositDetail2 = new DepositParameters()
                {
                    Amount = 13.31,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Seller's Broker",
                    CreditToSeller = false,
                    Comments = "This deposit is recieved from the Sellers Broker.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail2);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Validate Default ‘For Credit To’ Setting to ‘Other’ when ‘Received From’ is ‘Buyer’s Broker’.
                Reports.TestStep = "Validate Default ‘For Credit To’ Setting to ‘Other’ when ‘Received From’ is ‘Buyer’s Broker’";
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoBuyer.Enabled.ToString(), true);
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoSeller.Enabled.ToString(), true);
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoOther.Enabled.ToString(), true);
                Support.AreEqual("True", FastDriver.DepositInEscrow.CredittoOther.Selected.ToString(), true);
                #endregion

                #region Verify the amount deposited to Seller's Broker.
                Reports.TestStep = "Navigate to REB Summary page & Open the Sellers(listing) broker instance and verify the deposited to seller's broker amount.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Support.AreEqual(depositDetail2.Amount.ToString(), FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionNetCheckAmt.FAGetText());
                #endregion

                #region Verify system will not reflect the deposit to Seller Broker amount on settlement.
                Reports.TestStep = "Navigate to the View Settlement statement page.";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.");
                FastDriver.ViewSettlementStatement.SwitchToContentFrame();

                Reports.TestStep = "Verify system will not reflect the deposit to Seller Broker amount on settlement.";
                string tableContent2 = FastDriver.ViewSettlementStatement.GetViewSettlementTable().FAGetText();
                result = tableContent.Contains(depositDetail2.Amount.ToString());
                Reports.StatusUpdate("Verification result for 'system will not reflect the deposit to Seller Broker amount on settlement': " + (!result).ToString(), !result, expectedValue: "False", actualValue: result.ToString());
                #endregion

                #region Verify that  amount deposited to other from Seller and Buyer Broker.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Verify that  amount deposited to other from Seller and Buyer Broker.";
                string payee = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, depositDetail1.Amount.ToString(), 8, TableAction.GetText).Message.Trim();
                Support.AreEqual(buyerBrokerFullName.Contains(payee).ToString(), "True", true);

                payee = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, depositDetail2.Amount.ToString(), 8, TableAction.GetText).Message.Trim();
                Support.AreEqual(sellerBrokerFullName.Contains(payee).ToString(), "True", true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0012_FMXXXX_1() failed because: " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_REG0013_FMXXXX_2()
        {
            try
            {
                Reports.TestDescription = "FMXXXX : Other,Seller,Buyer Radio Button and verify Disbursement.";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                Reports.TestStep = "Create a new file.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = this.GetDefaultFileCreated();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").SwitchToContentFrame();
                Support.AreEqual("true", FastDriver.FileHomepage.WaitCreation(FastDriver.FileHomepage.ChangeOO, continueOnFailure: true).ToString(), true);
                #endregion

                #region Create a new Buyer.
                Reports.TestStep = "Navigate to the Buyers link.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.BuyerSellerSetup>("Home>Order Entry>Buyers").WaitForScreenToLoad();

                Reports.TestStep = "Create a new buyer of type Individual.";
                FastDriver.BuyerSellerSetup.ChangeInstanceType(0, "Individual");
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("TestBuyerfrsecti0nD1");
                FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText("TestBuyerMiddlesecD1");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("TestBuyerfrLastsecD1");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create a new Seller.
                Reports.TestStep = "Navigate to the Sellers link.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.BuyerSellerSetup>("Home>Order Entry>Sellers").WaitForScreenToLoad();

                Reports.TestStep = "Create a new seller of type Individual.";
                FastDriver.BuyerSellerSetup.ChangeInstanceType(0, "Individual");
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("TestSelerfrsecti0nD1");
                FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText("TestSelerMiddlesecD1");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("TestSelerfrLastsecD1");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create  Buyers (Selling) Broker instance.
                Reports.TestStep = "Navigate to REB link and Add the Buyers(selling) broker instance .";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("BUYERBROKER", "HUDFLINSR1");
                string buyerBrokerFullName = FastDriver.RealEstateBrokerAgent.GetBrokerFullName;
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create  Sellers (Listing) Broker instance.
                Reports.TestStep = "Navigate to REB link and Add the Sellers(Listing) broker instance.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "243");
                string sellerBrokerFullName = FastDriver.RealEstateBrokerAgent.GetBrokerFullName;
                FastDriver.BottomFrame.Done();
                #endregion

                #region Perform a deposit and select recieved from the Buyer's Broker.
                Reports.TestStep = "Navigate to Deposit in Escrow page to perform deposit.";
                FastDriver.DepositInEscrow.Open();
                Reports.TestStep = "Perform a cash deposit with recieved from Buyers Broker";
                DepositParameters depositDetail1 = new DepositParameters()
                {
                    Amount = 12.21,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer's Broker",
                    CreditToSeller = false,
                    Comments = "This deposit is recieved from the Buyers Broker.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail1);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Validate Default ‘For Credit To’ Setting to ‘Other’ when ‘Received From’ is ‘Buyer’s Broker’.
                Reports.TestStep = "Validate Default ‘For Credit To’ Setting to ‘Other’ when ‘Received From’ is ‘Buyer’s Broker’";
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoBuyer.Enabled.ToString(), true);
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoSeller.Enabled.ToString(), true);
                Support.AreEqual("False", FastDriver.DepositInEscrow.CredittoOther.Enabled.ToString(), true);
                Support.AreEqual("True", FastDriver.DepositInEscrow.CredittoOther.Selected.ToString(), true);
                #endregion

                #region Verify that  amount deposited to other from Buyer Broker.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Verify the amount deposited to other.";
                string payee = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, depositDetail1.Amount.ToString(), 8, TableAction.GetText).Message;
                Support.AreEqual(buyerBrokerFullName.Contains(payee).ToString(), "True");
                #endregion

                #region Perform a deposit and select deposited to as Buyer.
                Reports.TestStep = "Navigate to Deposit in Escrow page to perform deposit.";
                FastDriver.DepositInEscrow.Open();
                Reports.TestStep = "Perform a cash deposit with recieved from Buyers Broker";
                DepositParameters depositDetail2 = new DepositParameters()
                {
                    Amount = 13.31,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer's Broker",
                    CreditToBuyer = true,
                    Comments = "This deposit is recieved from the Buyers Broker and deposited to the buyer.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail2);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                #endregion

                #region Verify that  amount deposited to Buyer from Buyer Broker.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Verify the amount deposited to Buyer.";
                payee = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, depositDetail2.Amount.ToString(), 8, TableAction.GetText).Message;
                Support.AreEqual("TestBuyerfrsecti0nD1 TestBuyerMiddlesecD", payee.Trim());
                #endregion

                #region Perform a deposit and select deposited to as Seller.
                Reports.TestStep = "Navigate to Deposit in Escrow page to perform deposit.";
                FastDriver.DepositInEscrow.Open();
                Reports.TestStep = "Perform a cash deposit with recieved from Buyers Broker";
                DepositParameters depositDetail3 = new DepositParameters()
                {
                    Amount = 14.41,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer's Broker",
                    CreditToSeller = true,
                    Comments = "This deposit is recieved from the Buyers Broker and deposited to the Seller.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail3);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Verify that  amount deposited to Seller from Buyer Broker.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Verify the amount deposited to Seller.";
                payee = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, depositDetail3.Amount.ToString(), 8, TableAction.GetText).Message;
                Support.AreEqual("TestSelerfrsecti0nD1 TestSelerMiddlesecD", payee.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0013_FMXXXX_2 failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0028_REG0014()
        {
            try
            {
                Reports.TestDescription = "FM1899  Record exceptions as events: Recording a manual receipt excessive cash deposit ";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Perform a Cash Deposit with Manual reciept number.
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Perform a cash deposit.";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 8000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Testing Payor",
                    CreditToSeller = true,
                    Comments = "It is a Manual Cash deposit.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                #endregion

                #region Add Manual Check number.
                Reports.TestStep = "Click on the Manual Button and provide the manual check number";
                FastDriver.DepositInEscrow.Manual.FAClick();
                string recieptNo = this.getRecieptNo;
                FastDriver.DepositInEscrow.ReceiptNo.SendKeys(OpenQA.Selenium.Keys.Backspace);
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(recieptNo);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Add Comment for the Manual cash deposit.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("This is the first deposit with the manual reciept number.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 20);
                #endregion

                #region Perform second Cash Deposit with Manual reciept number.
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Perform a cash deposit.";
                DepositParameters depositDetail1 = new DepositParameters()
                {
                    Amount = 7000.77,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Testing Payor",
                    CreditToSeller = true,
                    Comments = "It is second Manual Cash deposit.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail1);
                #endregion

                #region Add Manual Check number and verify the warning message for the excess deposit.
                Reports.TestStep = "Click on the Manual Button and provide the manual check number";
                FastDriver.DepositInEscrow.Manual.FAClick();
                recieptNo = this.getRecieptNo;
                FastDriver.DepositInEscrow.ReceiptNo.SendKeys(OpenQA.Selenium.Keys.Backspace);
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(recieptNo);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Add Comment for the Manual cash deposit.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("This is the second deposit with manual reciept number.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Verifying the warning message on  performing the deposit wit excess amount.";
                string messageContent = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10);
                Support.AreEqual("Important! The credit to party contains total cash or similar deposits in excess of $10,000. Form 8300 is required to be completed and filed with the IRS within 15 days.", messageContent);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 20);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string recieptIssueDate = DateTime.Parse(FastDriver.DepositInEscrow.IssueDte.FAGetValue()).ToString("M/d/yyyy");

                #endregion

                #region Navigate to Event/Tracking Log and verify the event log.
                Reports.TestStep = "Navigate to the Event/Tracking Log";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.SelectEventCategory("Accounting/Privacy");
                messageContent = FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Excess Cash Deposits]", 5, TableAction.GetText).Message;

                Reports.TestStep = "Validate the receipt number for excess amount in Event log";
                Support.AreEqual("True", messageContent.Contains(recieptNo).ToString(), true);

                Reports.TestStep = "Validate the receipt issue date for excess amount in Event log";
                Support.AreEqual("True", messageContent.Contains(recieptIssueDate).ToString(), true);

                Reports.TestStep = "Validate the excess amount in Event log";
                string excessAmount = "Amount: " + string.Format("{0:0,0.00}", (depositDetail1.Amount).ToString());
                Support.AreEqual("True", messageContent.Contains(excessAmount).ToString(), true);

                Reports.TestStep = "Validate the Update Trust Accounting status for excess amount in Event log";
                Support.AreEqual("True", messageContent.Contains("Update Trust Accounting=Yes").ToString(), true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0014 failed because " + ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0028_REG0015()
        {
            try
            {
                Reports.TestDescription = "ES14669_ES14670_ES14671: Default Account for Deposit_First Account is a Deposit only account_Deposits to different accounts.";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Move to the Deposit in escrow page and get the value for default deposit account.
                Reports.TestStep = "Navigate to the Deposit in escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Get the value for the default deposit to account.";
                string defaultDepstAccnt = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                #endregion

                #region Perform a deposit for account other than the default deposit to account.
                Reports.TestStep = "Deposit a cash in account other than default account and store the account number.";
                DepositParameters depositDetail1 = new DepositParameters()
                {
                    Amount = 123.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Test Payor",
                    CreditToSeller = false,
                    Comments = "This cash is deposited to the account other than the default deposit account.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail1);
                FastDriver.DepositInEscrow.DepositedTo.FASelectItem("4533");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);

                Reports.TestStep = "Get the latest deposit to account value.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string defaultDepstAccnt1 = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                #endregion

                #region Perform a deposit for the account other than the default  and first deposit to account and validate the warning message.
                Reports.TestStep = "Navigate to the Deposit in escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Deposit a cash in account other than default account and store the account number.";
                DepositParameters depositDetail2 = new DepositParameters()
                {
                    Amount = 321.01,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Test Payor2",
                    CreditToSeller = false,
                    Comments = "This cash is deposited to the account other than the default deposit account for second time.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail2);
                FastDriver.DepositInEscrow.DepositedTo.FASelectItem("1230");

                Reports.TestStep = "Get the latest deposit to account value.";
                string defaultDepstAccnt2 = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                FastDriver.BottomFrame.Save();
                string messageContent = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10);
                Support.AreEqual("There are existing deposits in account " + defaultDepstAccnt1 + ". Are you sure about proceeding with deposits to a different account?", messageContent, true);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Validate that the 1st deposit account is only defaulted for further deposits.
                Reports.TestStep = "Navigate to the Deposit in escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Get the latest deposit to account value which is coming as default.";
                string latestDepstAccnt = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, defaultDepstAccnt1);
                Support.AreNotEqual(latestDepstAccnt, defaultDepstAccnt2);
                #endregion

                #region Move to the fee entry page and add the first fee with charges.
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, "1.99", "2.99");
                #endregion

                #region Navigate to Active Disbursement Summary and select fee amount/fee transfer row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the fee transfer fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Fee transfer.
                Reports.TestStep = "Validate the From account in Edit disbursement for Fee transfer.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, defaultDepstAccnt);
                #endregion

                #region Move to the Homewarrenty  page and add charges.
                Reports.TestStep = "Navigate to the home warrenty page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                Reports.TestStep = "Enter the gab id and charges for the homewarrenty.";
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                string hwName = FastDriver.HomeWarrantyDetail.getHWfullName;
                FastDriver.HomeWarrantyDetail.AddCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Active Disbursement Summary and select Check amount row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the Check fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, hwName, 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Check.
                Reports.TestStep = "Validate the From account in Edit disbursement for Check";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, defaultDepstAccnt);
                #endregion

                #region Move to the Lease page and add charges.
                Reports.TestStep = "Navigate to the Lease charges page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                Reports.TestStep = "Enter the gab id and charges for the Lease.";
                FastDriver.LeaseDetail.FindGABcode("LEASE");
                string leaseName = FastDriver.LeaseDetail.GetLeaseFullName;
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, "Changed Desc", buyerCharge: 10.00, sellerCharge: 11.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Active Disbursement Summary and select the row related to currently added lease charge.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the row of relavent lease charge and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, leaseName, 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Get the From account in Edit disbursement page.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                #endregion

                #region Move to the Document repository page and click on the scan button.
                Reports.TestStep = "Navigate to document repository page and click on the scan button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan_FiltrTempTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Open button and load the image document.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)

                Reports.TestStep = "Save the TIF Doc.";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository and click edit on the created status.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                #endregion

                #region Move to the Active Disbursement page and click edit on the wire fund type.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the wire fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, leaseName, 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Add wire instruction.
                Reports.TestStep = "Click on the add button to add the wire instruction";
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region Navigate to Active Disbursement Summary and select Pending wire row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the Pending wire fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Wire", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Check.
                Reports.TestStep = "Validate the From account in Edit disbursement for Wire";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, defaultDepstAccnt);
                #endregion

                //***************************************************************
                // ADM Verification.

                #region close the browser and login to the ADM side.
                ADMLOGIN();
                #endregion

                #region Move to the regional level and select the 1486 office.
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedOfficeBUID);
                #endregion

                #region Move to the Office setup screen and verify for the default primary deposit account.
                Reports.TestStep = "Navigate to Office Setup screen";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();

                Reports.TestStep = "Open the bank accounts setup for the office.";
                FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
                FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
                string value = FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction(8, "Yes", 4, TableAction.GetText).Message;
                if (value == defaultDepstAccnt)
                {
                    Reports.StatusUpdate("Deposit account number is defaulted with the primary deposit account of the file owning office.", true);
                }

                else
                {
                    Reports.StatusUpdate("Deposit account number is not defaulted with the primary deposit account of the file owning office.", false);
                }
                #endregion


            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0015 failed because " + ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0028_REG0016()
        {
            try
            {
                Reports.TestDescription = "ES14672_A: Deposit Account Deactivated after deposit (For Checks and Fee Transfers)";
                #region Data setup (Verify that account 1230 is in active state, if not make it active)
                Reports.TestStep = "Verify that account 1230 is in active state, if not make it active.";
                InactivateBankAccount(subToCal: false, accountNumber: "1230");
                #endregion

                # region IIS Login
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Move to the Deposit in escrow page and get the value for default deposit account.
                Reports.TestStep = "Navigate to the Deposit in escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Get the value for the default deposit to account.";
                string defaultDepstAccnt = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                #endregion

                #region Deposit cash in account 1230.
                Reports.TestStep = "Deposit cash in account 1230.";
                DepositParameters depositDetail1 = new DepositParameters()
                {
                    Amount = 123.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    CreditToSeller = false,
                    Comments = "This cash is deposited to the account other than the default deposit account.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail1);
                FastDriver.DepositInEscrow.DepositedTo.FASelectItem("1230");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);

                Reports.TestStep = "Get the latest deposit to account value.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string DepstAccnt1 = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                #endregion

                #region Add fee to the file and note down the default From Account in Edit Disbursement screen.
                Reports.TestStep = "Add fee to the file and note down the default From Account in Edit Disbursement screen.";
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, "1.99", "2.99");
                #endregion

                #region Navigate to Active Disbursement Summary and select fee amount/fee transfer row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the fee transfer fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Fee transfer.
                Reports.TestStep = "Validate the From account in Edit disbursement for Fee transfer.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                string latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, DepstAccnt1);
                #endregion

                #region Move to the Homewarrenty  page and add charges.
                Reports.TestStep = "Navigate to the home warrenty page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                Reports.TestStep = "Enter the gab id and charges for the homewarrenty.";
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                string hwName = FastDriver.HomeWarrantyDetail.getHWfullName;
                FastDriver.HomeWarrantyDetail.AddCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Active Disbursement Summary and select Check amount row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the Check fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, hwName, 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Check.
                Reports.TestStep = "Validate the From account in Edit disbursement for Check";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, DepstAccnt1);
                #endregion

                #region Data Setup(Make the active state of account 1230 to inactive state)
                Reports.TestStep = "Make the active state of account 1230 to inactive state.";
                MasterTestClass.PerformRequiredRegistrySettings();
                InactivateBankAccount(subToCal: true, accountNumber: "1230");
                #endregion

                Reports.TestStep = "Login into file side and validate that Primary Disbursement Account is defaulted for fee and check.";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Get the previous file opened.
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Navigate to Active Disbursement Summary and select fee amount/fee transfer row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the fee transfer fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Fee transfer.
                Reports.TestStep = "Validate the From account in Edit disbursement for Fee transfer.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, defaultDepstAccnt);
                #endregion

                #region Navigate to Active Disbursement Summary and select Check amount row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the Check fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, hwName, 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Check.
                Reports.TestStep = "Validate the From account in Edit disbursement for Check";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, defaultDepstAccnt);
                #endregion

                Reports.TestStep = "Make the acount 1230 to active.";
                MasterTestClass.PerformRequiredRegistrySettings();
                InactivateBankAccount(subToCal: false, accountNumber: "1230");
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0016 failed because " + ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0028_REG0017()
        {
            try
            {
                Reports.TestDescription = "ES14672_B: Deposit Account Deactivated after deposit (For Wire)";
                InactivateBankAccount(subToCal: false, accountNumber: "3109200000");
                # region IIS Login
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Move to the Deposit in escrow page and get the value for default deposit account.
                Reports.TestStep = "Navigate to the Deposit in escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Get the value for the default deposit to account.";
                string defaultDepstAccnt = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                #endregion

                #region Move to the Homewarrenty  page and add charges.
                Reports.TestStep = "Navigate to the home warrenty page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                Reports.TestStep = "Enter the gab id and charges for the homewarrenty.";
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                string homeWarrentyName = FastDriver.HomeWarrantyDetail.getHWfullName;
                FastDriver.HomeWarrantyDetail.AddCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Active Disbursement Summary and select the row related to currently added HomeWarrenty charge.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the row of relavent Home warrenty charge and click on the edit button.";
                string status = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, homeWarrentyName, 1, TableAction.GetText).Message;
                Support.AreEqual("Pending", status, true);
                #endregion

                #region Move to the Document repository page and click on the scan button.
                this.UploadScanDocument();
                #endregion

                #region Move to the Active Disbursement page and click edit on the wire fund type.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the wire fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, homeWarrentyName, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Add wire instruction and convert it to Wire.
                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region Navigate to Active Disbursement Summary and select Pending wire row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the Pending wire fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Wire", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Edit From account in Edit disbursement for Wire.
                Reports.TestStep = "Edit the From account in Edit disbursement for Wire";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.FromAccount.FASelectItem("3109200000");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region datasetup
                MasterTestClass.PerformRequiredRegistrySettings();
                InactivateBankAccount(subToCal: true, accountNumber: "3109200000");
                #endregion

                Reports.TestStep = "Login into file side and validate that Primary Disbursement Account is defaulted for wire.";
                # region IIS Login
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                #endregion

                #region Get the previous file opened.
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Navigate to Active Disbursement Summary and select Pending Wire row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the fee transfer fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Wire", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Wire.
                Reports.TestStep = "Validate the From account in Edit disbursement for wire";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                string latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, defaultDepstAccnt);
                #endregion

                #region datasetup
                Reports.TestStep = "Make the acount 3109200000 to active.";
                MasterTestClass.PerformRequiredRegistrySettings();
                InactivateBankAccount(subToCal: false, accountNumber: "3109200000");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0017 failed because " + ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0028_REG0018()
        {
            try
            {
                Reports.TestDescription = "ES14673_A: Account Type changed after deposit (For Checks and Fee Transfers)";
                #region Data Setup
                Reports.TestStep = "Verify that account 1230 is both Deposit and disburement account, if not make it both.";
                ChangeAccountType(subToCal: false, accountNumber: "1230");
                #endregion

                # region IIS Login
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Move to the Deposit in escrow page and get the value for default deposit account.
                Reports.TestStep = "Navigate to the Deposit in escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Get the value for the default deposit to account.";
                string defaultDepstAccnt = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                #endregion

                #region Deposit cash in account 1230.
                Reports.TestStep = "Deposit cash in account 1230.";
                DepositParameters depositDetail1 = new DepositParameters()
                {
                    Amount = 126.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    CreditToSeller = false,
                    Comments = "This cash is deposited to the account other than the default deposit account.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail1);
                FastDriver.DepositInEscrow.DepositedTo.FASelectItem("1230");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);

                Reports.TestStep = "Get the latest deposit to account value.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string DepstAccnt1 = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                #endregion

                #region Add fee to the file and note down the default From Account in Edit Disbursement screen.
                Reports.TestStep = "Add fee to the file and note down the default From Account in Edit Disbursement screen.";
                Reports.TestStep = "Navigate to Fee Entry page and add the first Title/Escrow fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                Reports.TestStep = "Add the Charges for the added fees.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.EnterAmount("New Home Rate (Title Only)", true, "1.99", "2.99");
                #endregion

                #region Navigate to Active Disbursement Summary and select fee amount/fee transfer row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the fee transfer fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Fee transfer.
                Reports.TestStep = "Validate the From account in Edit disbursement for Fee transfer.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                string latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, DepstAccnt1);
                #endregion

                #region Move to the Homewarrenty  page and add charges.
                Reports.TestStep = "Navigate to the home warrenty page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                Reports.TestStep = "Enter the gab id and charges for the homewarrenty.";
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                string hwName = FastDriver.HomeWarrantyDetail.getHWfullName;
                FastDriver.HomeWarrantyDetail.AddCharge(chargesTable: FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, chargeDescription: "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.02);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Active Disbursement Summary and select Check amount row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the Check fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, hwName, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Check.
                Reports.TestStep = "Validate the From account in Edit disbursement for Check";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, DepstAccnt1);
                #endregion

                #region Data Setup
                Reports.TestStep = "Verify that account 1230 should not be Deposit and disburement account, if not remove it.";
                MasterTestClass.PerformRequiredRegistrySettings();
                ChangeAccountType(subToCal: true, accountNumber: "1230");
                #endregion

                Reports.TestStep = "Login into file side and validate that Primary Disbursement Account is defaulted for fee and check.";
                # region IIS Login
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                #endregion

                #region Get the previous file opened.
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Navigate to Active Disbursement Summary and select fee amount/fee transfer row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the fee transfer fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Fee transfer.
                Reports.TestStep = "Validate the From account in Edit disbursement for Fee transfer.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, defaultDepstAccnt);
                #endregion

                #region Navigate to Active Disbursement Summary and select Check amount row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the Check fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, hwName, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Check.
                Reports.TestStep = "Validate the From account in Edit disbursement for Check";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, defaultDepstAccnt);
                #endregion

                #region Data Setup
                Reports.TestStep = "Verify that account 1230 is both Deposit and disburement account, if not make it both.";
                MasterTestClass.PerformRequiredRegistrySettings();
                ChangeAccountType(subToCal: false, accountNumber: "1230");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0018 failed because: " + ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0028_REG0019()
        {
            try
            {
                Reports.TestDescription = "ES14673_B: Account Type changed after deposit (For Wire)";
                #region Data setup
                Reports.TestStep = "Verify that account 3109200000 is both Deposit and disburement account, if not make it both.";
                ChangeAccountType(subToCal: false, accountNumber: "3109200000");
                #endregion

                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Move to the Deposit in escrow page and get the value for default deposit account.
                Reports.TestStep = "Navigate to the Deposit in escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Get the value for the default deposit to account.";
                string defaultDepstAccnt = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                #endregion

                #region Move to the Homewarrenty  page and add charges.
                Reports.TestStep = "Navigate to the home warrenty page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                Reports.TestStep = "Enter the gab id and charges for the homewarrenty.";
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                string hwName = FastDriver.HomeWarrantyDetail.getHWfullName;
                FastDriver.HomeWarrantyDetail.AddCharge(chargesTable: FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, chargeDescription: "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Move to the Document repository page and click on the scan button.
                this.UploadScanDocument();
                #endregion

                #region Move to the Active Disbursement page and click edit on the wire fund type.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the wire fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, hwName, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Convert to Wire
                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region Navigate to Active Disbursement Summary and select Pending wire row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the Pending wire fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Wire", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Edit From account in Edit disbursement for Wire.
                Reports.TestStep = "Edit the From account in Edit disbursement for Wire";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.FromAccount.FASelectItem("3109200000");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Data Setup
                Reports.TestStep = "Verify that account 3109200000 should not be Deposit and disburement account, if not remove it.";
                ChangeAccountType(subToCal: true, accountNumber: "3109200000");
                #endregion

                Reports.TestStep = "Login into file side and validate that Primary Disbursement Account is defaulted for wire.";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Get the previous file opened.
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Navigate to Active Disbursement Summary and select Pending Wire row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the fee transfer fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, hwName, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Wire.
                Reports.TestStep = "Validate the From account in Edit disbursement for Check";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                string latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, defaultDepstAccnt);
                #endregion

                #region Data setup
                Reports.TestStep = "Verify that account 3109200000 is both Deposit and disburement account, if not make it both.";
                ChangeAccountType(subToCal: false, accountNumber: "3109200000", setWireIntrfcAccnt: true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0019 failed because: " + ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0028_REG0020()
        {
            try
            {
                Reports.TestDescription = "Error/Warning Conditions_3_6: There are no depositing bank accounts defined for the office. Evaluated upon opening the page._User selects Deposit in Escrow in a Title Only file (file does not have Escrow or Sub Escrow service).";
                #region ADM Settings.
                #region login to the ADM side.
                ADMLOGIN();
                #endregion

                #region Move to the regional level and select the 1486 office.
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
                #endregion

                #region Move to the office setup of STEST and select the office 7879 and check the project file check box.
                Reports.TestStep = "Navigate to Office Setup screen";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7879").WaitForScreenToLoad();

                Reports.TestStep = "Check the project file check box and click on done button.";
                FastDriver.OfficeSetupOffice.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Click on the ChangeOO button and change the titleOwn office.
                Reports.TestStep = "Click on the ChangeOO button to change the titleOwn office";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change the title and escrow Owning office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad(FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice);
                Playback.Wait(10000);
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickYes();
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Perform a Cash deposit for this changed office and verify the error message.
                Reports.TestStep = "Navigate to the Deposit in escrow page.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                Reports.TestStep = "Verify the error message.";
                string messageContent = FastDriver.WebDriver.HandleDialogMessage(timeout: 20).Replace("\n", string.Empty);
                Support.AreEqual("File Owning Office does not have a Deposit Account. Please create a Deposit Account for this office in Office Setup.", messageContent);
                #endregion

                #region Verify save and done button.
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual("False", FastDriver.BottomFrame.btnDone.Enabled.ToString(), true);
                Support.AreEqual("False", FastDriver.BottomFrame.btnSave.Enabled.ToString(), true);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").SwitchToContentFrame();

                #endregion

                #region Create a file with Title only.
                Reports.TestStep = "Create file with title Only.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = this.GetTitleOnlyFileCreated();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").SwitchToContentFrame();
                Support.AreEqual("true", FastDriver.FileHomepage.WaitCreation(FastDriver.FileHomepage.ChangeOO, continueOnFailure: true).ToString(), true);
                #endregion

                #region Perform a Cash deposit for this new file and verify the error message.
                Reports.TestStep = "Navigate to the Deposit in escrow page.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");

                Reports.TestStep = "Verify the error message.";
                messageContent = FastDriver.WebDriver.HandleDialogMessage(timeout: 20).Replace("\n", string.Empty);
                Support.AreEqual("File must have 'Escrow' or 'Sub Escrow' Service Type in order to record a deposit.", messageContent);
                #endregion

                #region Verify save and done button.
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual("False", FastDriver.BottomFrame.btnDone.Enabled.ToString(), true);
                Support.AreEqual("False", FastDriver.BottomFrame.btnSave.Enabled.ToString(), true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0020 failed because: " + ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0028_REG0021()
        {
            try
            {
                Reports.TestDescription = "Field Validations in Deposit in Escrow screen";
                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                #endregion

                #region Move to the Deposit in escrow screen and validate the fields.
                Reports.TestStep = "Navigate to the Deposit in escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Validate the fields in Deposit in Ecsorw screen.";
                bool result = FastDriver.DepositInEscrow.VerifyFieldsOnPageLoad();

                result = result && FastDriver.DepositInEscrow.History.Enabled.Equals(true);
                Reports.StatusUpdate(controlDescription: "Validation for History field: " + result.ToString(), status: result, expectedValue: "True", actualValue: result.ToString());

                result = result && FastDriver.DepositInEscrow.Method.Enabled.Equals(false);
                Reports.StatusUpdate(controlDescription: "Validation for Method field: " + result.ToString(), status: result, expectedValue: "False", actualValue: (!result).ToString());

                result = result && FastDriver.DepositInEscrow.Deliver.Enabled.Equals(false);
                Reports.StatusUpdate(controlDescription: "Validation for Deliver field: " + result.ToString(), status: result, expectedValue: "False", actualValue: (!result).ToString());

                result = result && FastDriver.DepositInEscrow.Manual.Enabled.Equals(true);
                Reports.StatusUpdate(controlDescription: "Validation for Manual field: " + result.ToString(), status: result, expectedValue: "True", actualValue: result.ToString());

                string depositValue = FastDriver.DepositInEscrow.BuyerDeposits.FAGetText().Trim();
                result = result && depositValue.Equals("0.00");
                Reports.StatusUpdate(controlDescription: "Validation for default value of Buyers Deposit: " + result.ToString(), status: result, expectedValue: "0.00", actualValue: depositValue);

                depositValue = FastDriver.DepositInEscrow.SellerDeposits.FAGetText().Trim();
                result = result && depositValue.Equals("0.00");
                Reports.StatusUpdate(controlDescription: "Validation for default value of sellers Deposit: " + result.ToString(), status: result, expectedValue: "0.00", actualValue: depositValue);

                depositValue = FastDriver.DepositInEscrow.OtherDeposits.FAGetText().Trim();
                result = result && depositValue.Equals("0.00");
                Reports.StatusUpdate(controlDescription: "Validation for default value of Others Deposit: " + result.ToString(), status: result, expectedValue: "0.00", actualValue: depositValue);

                Reports.StatusUpdate("Validation result for all fields is :" + result.ToString(), result, expectedValue: "True", actualValue: result.ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0021 failed because: " + ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0028_REG0022()
        {
            try
            {
                Reports.TestDescription = "ES14672_C: Deposit Account Deactivated after deposit (For Wire)_Validating the BR SM14667: 1st Deposit Account, if the 1st deposit account is a Wirelink Interface Account";

                #region Data setup (Verify that account 3109200000 is in active state, if not make it active)
                Reports.TestStep = "Verify that account 3109200000 is in active state, if not make it active.";
                InactivateBankAccount(subToCal: false, accountNumber: "3109200000");
                #endregion

                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Move to the Deposit in escrow page and get the value for default deposit account.
                Reports.TestStep = "Navigate to the Deposit in escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Get the value for the default deposit to account.";
                string defaultDepstAccnt = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                #endregion

                #region Deposit cash in account 3120370000.
                Reports.TestStep = "Deposit cash in account 3120370000.";
                DepositParameters depositDetail1 = new DepositParameters()
                {
                    Amount = 213.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    CreditToSeller = false,
                    Comments = "This cash is deposited to the account other than the default deposit account.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail1);
                FastDriver.DepositInEscrow.DepositedTo.FASelectItem("3120370000");
                string EscrowAccount = "3120370000";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);

                Reports.TestStep = "Get the latest deposit to account value.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Move to the Lease page and add charges.
                Reports.TestStep = "Navigate to the Lease charges page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                Reports.TestStep = "Enter the gab id and charges for the Lease.";
                FastDriver.LeaseDetail.FindGABcode("LEASE");
                string leaseName = FastDriver.LeaseDetail.GetLeaseFullName;
                FastDriver.LeaseDetail.AddCharge(chargesTable: FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: "Changed Desc", buyerCharge: 10.00, sellerCharge: 11.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Active Disbursement Summary and select the row related to currently added lease charge.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the row of relavent lease charge and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, leaseName, 8, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement.
                Reports.TestStep = "Validate the From account in Edit disbursement for Wire";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                string DfAccount = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(DfAccount, EscrowAccount);
                #endregion

                #region Move to the Document repository page and click on the scan button.
                this.UploadScanDocument();
                #endregion

                #region Move to the Active Disbursement page and click edit on the wire fund type.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the wire fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, leaseName, 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Convert to Wire
                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region Navigate to Active Disbursement Summary and select Pending wire row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the Pending wire fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Wire", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Change the From account to other than default account.
                Reports.TestStep = "Change the From account to other than default account";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.FromAccount.FASelectItem("3109200000");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(timeout: 10);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Data Setup
                Reports.TestStep = "Deactivate the account 3109200000";
                MasterTestClass.PerformRequiredRegistrySettings();
                InactivateBankAccount(subToCal: true, accountNumber: "3109200000");
                #endregion

                # region IIS Login
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                #endregion

                #region Get the previous file opened.
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Navigate to Active Disbursement Summary and select Pending Wire row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the fee transfer fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Wire", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Wire.
                Reports.TestStep = "Validate the From account in Edit disbursement for wire";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                string latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, DfAccount);
                #endregion

                #region Data Setup
                MasterTestClass.PerformRequiredRegistrySettings();
                InactivateBankAccount(subToCal: false, accountNumber: "3109200000");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0022 failed because: " + ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0028_REG0023()
        {
            try
            {
                Reports.TestDescription = "ES14673_C: Account Type changed after deposit (For Wire)_Validating the BR SM14667: 1st Deposit Account, if the 1st deposit account is a Wirelink Interface Account.";
                #region Data Setup
                Reports.TestStep = "Verify that account 3109200000 is both Deposit and disburement account, if not make it both.";
                ChangeAccountType(subToCal: false, accountNumber: "3109200000", setWireIntrfcAccnt: true);
                #endregion

                # region IIS Login
                IISLOGIN();
                #endregion

                #region Create A Basic File
                CreateBasicFile();
                string fileNumber = FastDriver.TopFrame.GetFileNumber();
                #endregion

                #region Move to the Deposit in escrow page and get the value for default deposit account.
                Reports.TestStep = "Navigate to the Deposit in escrow page.";
                FastDriver.DepositInEscrow.Open();

                Reports.TestStep = "Get the value for the default deposit to account.";
                string defaultDepstAccnt = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                #endregion

                #region Deposit cash in account 3120370000.
                Reports.TestStep = "Deposit cash in account 3120370000.";
                DepositParameters depositDetail1 = new DepositParameters()
                {
                    Amount = 213.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Test Payor",
                    CreditToSeller = false,
                    Comments = "This cash is deposited to the account other than the default deposit account.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail1);
                FastDriver.DepositInEscrow.DepositedTo.FASelectItem("3120370000");
                string EscrowAccount = "3120370000";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);

                Reports.TestStep = "Get the latest deposit to account value.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string DepstAccnt1 = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                #endregion

                #region Move to the Lease page and add charges.
                Reports.TestStep = "Navigate to the Lease charges page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                Reports.TestStep = "Enter the gab id and charges for the Lease.";
                FastDriver.LeaseDetail.FindGABcode("LEASE");
                string leaseName = FastDriver.LeaseDetail.GetLeaseFullName;
                FastDriver.LeaseDetail.AddCharge(chargesTable: FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: "Changed Desc23", sellerCharge: 10.00, buyerCharge: 11.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Active Disbursement Summary and select the row related to currently added lease charge.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the row of relavent lease charge and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, leaseName, 8, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement.
                Reports.TestStep = "Validate the From account in Edit disbursement for Wire";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                string DfAccount = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(DfAccount, EscrowAccount);
                #endregion

                #region Move to the Document repository page and click on the scan button.
                this.UploadScanDocument();
                #endregion

                #region Move to the Active Disbursement page and click edit on the wire fund type.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the wire fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, leaseName, 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Convert to Wire
                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region Navigate to Active Disbursement Summary and select Pending wire row.
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the Pending wire fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Wire", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Change the From account to other than default account.
                Reports.TestStep = "Change the From account to other than default account";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.FromAccount.FASelectItem("3109200000");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Data Setup
                Reports.TestStep = "Verify that account 3109200000 should not be Deposit and disburement account, if not remove it.";
                ChangeAccountType(subToCal: true, accountNumber: "3109200000");
                #endregion

                # region IIS Login
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN();
                #endregion

                #region Get the previous file opened.
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Check the from account after deactivating the previuosly selected from account
                Reports.TestStep = "Navigate to the Active Disbursement summary page.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select the fee transfer fund type and click on the edit button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Wire", 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion

                #region Validate the From account in Edit disbursement for Wire.
                Reports.TestStep = "Validate the From account in Edit disbursement for wire";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                string latestDepstAccnt = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                Support.AreEqual(latestDepstAccnt, DfAccount);
                #endregion

                #region Data Setup
                ChangeAccountType(subToCal: false, accountNumber: "3109200000", setWireIntrfcAccnt: true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest("Test case FMUC0028_REG0023 failed because: " + ex.Message);
            }
        }

        #endregion

        #region PrivateMethods

        /// <summary>
        /// This method logins to File side.
        /// </summary>
        /// <param name="UserName"> username string for login</param>
        /// <param name="Password">password for the corresponding username for login.</param>
        private void IISLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Login into the IIS Side.";
            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        /// <summary>
        /// This method creates a basic file with all details.
        /// </summary>
        private void CreateBasicFile()
        {
            Reports.TestStep = "Create a new file.";
            CreateFileRequest fileRequest = new CreateFileRequest();
            fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            fileRequest.File.TransactionTypeObjectCD = "SALE";
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").SwitchToContentFrame();
            Support.AreEqual("true", FastDriver.FileHomepage.WaitCreation(FastDriver.FileHomepage.ChangeOO, continueOnFailure: true).ToString(), true);
        }

        /// <summary>
        /// This method generates a random reciept number.
        /// </summary>
        private string getRecieptNo
        {
            get
            {
                Random ran = new Random();
                int recieptNo = ran.Next(11111, 99999);
                return recieptNo.ToString();
            }
        }

        /// <summary>
        /// This method logins to ADM side.
        /// </summary>
        /// <param name="UserName"> username string for login</param>
        /// <param name="Password">password for the corresponding username for login.</param>
        private void ADMLOGIN(string UserName = null, string Password = null)
        {
            MasterTestClass.PerformRequiredRegistrySettings();
            var website = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Reports.TestStep = "Login into the ADM Side with user id: " + UserName + ".";
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        /// <summary>
        /// This method activates/deactivates the account number.
        /// </summary>
        /// <param name="subToCal">if subTocal==true --->make the account inactive and if subTocal==false---> make the account active</param>
        /// <param name="accountNumber">accountNumber string which we have to deactivate/activate</param>
        private void InactivateBankAccount(bool subToCal, string accountNumber)
        {
            #region close the browser and login to the ADM side.
            ADMLOGIN();
            #endregion

            #region Move to the regional level and select the 1486 office.
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
            #endregion

            #region Move to the office setup of STEST and select the office bank accounts tab.
            Reports.TestStep = "Navigate to Office Setup screen";
            FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();

            Reports.TestStep = "Open the bank accounts setup for the office.";
            FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
            FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();

            Reports.TestStep = "Select the bank account which we want to change the status.";
            FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction(4, accountNumber, 4, TableAction.Click);
            FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad(FastDriver.OfficeSetupBankAccounts.BankStatus);

            string status = FastDriver.OfficeSetupBankAccounts.BankStatus.FAGetText();
            if (subToCal == true)
            {
                Reports.TestStep = "View and Change Bank Account Status to Inactive.";
                if (status.Equals("Active"))
                {
                    Reports.TestStep = "Change the Status to Deactivate.";
                    FastDriver.OfficeSetupBankAccounts.ViewChangeStatus.FAClick();
                    FastDriver.StatusEdit.WaitForScreenToLoad();
                    FastDriver.StatusEdit.Deactivate.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Verify Bank Status changed to InActive.";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
                    FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();

                    Reports.TestStep = "Select the bank account  for which changed the status.";
                    FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction(4, accountNumber, 4, TableAction.Click);
                    FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
                    status = FastDriver.OfficeSetupBankAccounts.BankStatus.FAGetText();
                    Support.AreEqual("InActive", status);
                    FastDriver.BottomFrame.Done();
                }
                else
                {
                    Reports.StatusUpdate("Account status is already Inactive.", true);
                }
            }
            else
            {
                Reports.TestStep = "View and Change Bank Account Status to Active.";
                if (status.Equals("InActive"))
                {
                    Reports.TestStep = "Change the Status to activate.";
                    FastDriver.OfficeSetupBankAccounts.ViewChangeStatus.FAClick();
                    FastDriver.StatusEdit.WaitForScreenToLoad();
                    FastDriver.StatusEdit.Activate.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Verify Bank Status changed to InActive.";
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                    FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
                    FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();

                    Reports.TestStep = "Select the bank account  for which changed the status.";
                    FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction(4, accountNumber, 4, TableAction.Click);
                    FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
                    status = FastDriver.OfficeSetupBankAccounts.BankStatus.FAGetText();
                    Support.AreEqual("Active", status);
                    FastDriver.BottomFrame.Done();
                }
                else
                {
                    Reports.StatusUpdate("Account status is already active.", true);
                }
            }
            #endregion
        }

        /// <summary>
        /// This method changes the account of type (deposit and disburse to only deposit and viceversa)
        /// </summary>
        /// <param name="subToCal">if subToCal ==true makes the account type to deposit only</param>
        /// if subToCal==false make the account type to deposit and disburse type
        /// <param name="accountNumber">account Number string</param>
        /// <param name="setWireIntrfcAccnt">by default it is false. If it is true makes the account type wirelinkinterface account along with deposit and disbuse type.</param>
        private void ChangeAccountType(bool subToCal, string accountNumber, bool setWireIntrfcAccnt = false)
        {
            #region close the browser and login to the ADM side.
            ADMLOGIN();
            #endregion

            #region Move to the regional level and select the 1486 office.
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);
            #endregion

            #region Move to the office setup of STEST and select the office bank accounts tab.
            Reports.TestStep = "Navigate to Office Setup screen";
            FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();

            Reports.TestStep = "Open the bank accounts setup for the office.";
            FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
            FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();

            Reports.TestStep = "Select the bank account which we want to change the status.";
            FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction(4, accountNumber, 4, TableAction.Click);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
            if (subToCal == true)
            {
                Reports.TestStep = "View and Change Bank Account Type to Deposit Only type Account.";
                FastDriver.OfficeSetupBankAccounts.DisburseAcct.FASetCheckbox(false);
                FastDriver.OfficeSetupBankAccounts.PrimaryDisburse.FASetCheckbox(false);
                FastDriver.OfficeSetupBankAccounts.WirelinkInterfaceAccount.FASetCheckbox(false);
                FastDriver.OfficeSetupBankAccounts.PrimaryDeposit.FASetCheckbox(false);
                FastDriver.OfficeSetupBankAccounts.DepositAcct.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
            }
            else
            {
                Reports.TestStep = "View and Change Bank Account Type to Deposit and Disbursement  type Account.";
                FastDriver.OfficeSetupBankAccounts.DisburseAcct.FASetCheckbox(true);
                FastDriver.OfficeSetupBankAccounts.PrimaryDisburse.FASetCheckbox(false);
                if (setWireIntrfcAccnt == true)
                {
                    FastDriver.OfficeSetupBankAccounts.WirelinkInterfaceAccount.FASetCheckbox(true);
                }
                else
                {
                    FastDriver.OfficeSetupBankAccounts.WirelinkInterfaceAccount.FASetCheckbox(false);
                }
                FastDriver.OfficeSetupBankAccounts.PrimaryDeposit.FASetCheckbox(false);
                FastDriver.OfficeSetupBankAccounts.DepositAcct.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
            }
            #endregion
        }

        /// <summary>
        /// This method creats the file with the basic details only i.e BUID, transaction type,business segment and state.
        /// </summary>
        /// <returns></returns>
        private CreateFileRequest GetDefaultFileCreated()
        {
            #region CreateFileRequest
            return new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,
                File = new File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "RESIDENTAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.None
                            }
                        } 
                    },
                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    } 
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[] 
                    { 
                        new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA" 
                                } 
                            } 
                        } 
                    },
                }
            };
            #endregion
        }

        /// <summary>
        /// This method creates the file with title services only.
        /// </summary>
        /// <returns></returns>
        private CreateFileRequest GetTitleOnlyFileCreated()
        {
            #region CreateFileRequest
            return new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,
                File = new File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "RESIDENTAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.None
                            }
                        } 
                    },
                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID), 
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    } 
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        }
                    },
                    Properties = new Property[] 
                    { 
                        new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA" 
                                } 
                            } 
                        } 
                    },
                }
            };
            #endregion
        }

        /// <summary>
        /// This method uploads the scanned document.
        /// </summary>
        private void UploadScanDocument()
        {
            Reports.TestStep = "Navigate to document repository page and click on the scan button.";
            FastDriver.DocumentRepository.Open();
            FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
            FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();
            FastDriver.DocumentRepository.Scan_FiltrTempTab.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

            Reports.TestStep = "Click on Open button and load the image document.";
            FastDriver.ImagingWorkBench.WaitForWindowToLoad();
            FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
            FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
            FastDriver.BottomFrame.Done();
            Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)
            Reports.TestStep = "Save the TIF Doc.";
            FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
            FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

            Reports.TestStep = "Navigate to document Repository and click edit on the created status.";
            FastDriver.DocumentRepository.Open();
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}


