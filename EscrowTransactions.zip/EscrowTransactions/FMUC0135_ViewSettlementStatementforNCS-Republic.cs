﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using System.Linq;
using System.Collections.Generic;

namespace EscrowTransactions
{
    [CodedUITest]
    public partial class FMUC0135 : MasterTestClass
    {
        //add test methods here by using the 'testms' snippet
        #region r11.2015-i09 Nov
        //FMUC0083_BAT0002 test method can be used for this iteration as well
        #endregion
        #region r12.2015
        [TestMethod]
        public void FMUC0135_REG0001()
        {
            try
            {
                Reports.TestDescription = "Project 2824, a brand new view settlement statement screen layout/format for commercial business segment US# 380709, 585440, 586297, 547930 and 532237";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region File Setup
                #region File Creation
                Reports.TestStep = "Control access and creating a CD radiobutton escrow order";

                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("531");
                FastDriver.HomePage.WaitForHomeScreen();

                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.txtBusinessSourceGABID.FASetText("2476648");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
                }

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("123456789.97");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("994555873");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Trust/Estate");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Business Entity");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Survey Instances
                Reports.TestStep = "1st survey instance";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad().SwitchToContentFrame();

                FastDriver.SurveyDetail.FindGABCode("2470308");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey 1st instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("5433.03");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1023.98");
                FastDriver.BottomFrame.New();

                Reports.TestStep = "2nd survey instance";
                FastDriver.BottomFrame.SwitchToContentFrame();
                FastDriver.SurveyDetail.Find.FAClick();
                FastDriver.SurveyDetail.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad().FileaddressBookResultsRadio.FAClick();
                FastDriver.DialogBottomFrame.ClickDone().SwitchToContentFrame();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey 2nd instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("5.06");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("7.05");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Adding Fees
                Reports.TestStep = "Add Fees";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Closing-Accommodation Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Closing-Accommodation Fee", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Closing-Accommodation Fee", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                //FastDriver.FileFees.AddFees.FAClick();

                //FastDriver.FileFees.FindNow.FAClick();
                //Playback.Wait(5000);
                //RandomFeeSelect();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Adding Deposits
                Reports.TestStep = "Add Deposits";

                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("50000000.13");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Credit Card");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Closing Costs");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Seller");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 15);
                //KeyboardSendKeys(FAKeys.Escape);

                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("0.07");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Other");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Miscellaneous Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Other");
                FastDriver.DepositInEscrow.Payor.FASetText("Sangakkara");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 15);

                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("123456789");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 15);

                #endregion

                #region Adding Taxes
                Reports.TestStep = "Test data, Prorations";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.New.FAClick();
                Playback.Wait(2000);
                FastDriver.ProrationTax.Amount.FASetText("1000");
                FastDriver.ProrationTax.Desc.FASetText("Proration tax and special char ABCabc123!@#");
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(2000);
                FastDriver.ProrationTax.bc.FASetText("50");
                FastDriver.ProrationTax.sc.FASetText("50");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Test data, Funds held";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For First Hold Fund Instance.");
                FastDriver.HoldFunds.SellerCharge.FASetText("100");
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(2000);
                FastDriver.ProrationTax.New.FAClick();
                Playback.Wait(2000);
                FastDriver.HoldFunds.FindGABCode("2479674");
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.96");
                FastDriver.BottomFrame.New();
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Test Buyer Fund");
                FastDriver.HoldFunds.RadbtnBuyer.FASetCheckbox(true);
                FastDriver.HoldFunds.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.FindGABCode("2479674");
                FastDriver.HoldFunds.HoldFundBuyerCharge1.FASetText("11.11");
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                Reports.TestStep = "Now validating the newly built view settlement screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                /*if (FastDriver.ViewSettlementStatement.NewDepositsInEscrowTable.Exists())
                {
                    if (FastDriver.ViewSettlementStatement.NewDepositsInEscrowTable.FeeExistOnTable("Total Buyer Deposits in Escrow").ToString() == "True")
                        Reports.StatusUpdate("Error with buyer subtotals line item", false);
                    if (FastDriver.ViewSettlementStatement.NewDepositsInEscrowTable.FeeExistOnTable("Total Seller Deposits in Escrow").ToString() == "True")
                        Reports.StatusUpdate("Error with seller subtotals line item", false);
                    if (FastDriver.ViewSettlementStatement.NewDepositsInEscrowTable.FeeExistOnTable("Total Buyer Title/Escrow Charge").ToString() == "True")
                        Reports.StatusUpdate("Error with buyer subtotals line item", false);
                    if (FastDriver.ViewSettlementStatement.NewDepositsInEscrowTable.FeeExistOnTable("Total Seller Title/Escrow Charge").ToString() == "True")
                        Reports.StatusUpdate("Error with seller subtotals line item", false);
                }
                else
                    Reports.StatusUpdate("Table is not displayed", false);

                if (FastDriver.ViewSettlementStatement.FundsHeldTable.Exists())
                {
                    if (FastDriver.ViewSettlementStatement.FundsHeldTable.FeeExistOnTable("Total Buyer Funds Held").ToString() == "True")
                        Reports.StatusUpdate("Error with buyer subtotals line item", false);
                    if (FastDriver.ViewSettlementStatement.FundsHeldTable.FeeExistOnTable("Total Seller Funds Held").ToString() == "True")
                        Reports.StatusUpdate("Error with seller subtotals line item", false);
                }
                else
                    Reports.StatusUpdate("Table is not displayed", false);

                #region CheckBoxes count
                var allChckBoxes = FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.FAFindElements(ByLocator.ClassName, "ss_Subtotal").ToListString();
                if (allChckBoxes.Count.ToString() == "9")
                {
                    Reports.StatusUpdate("Number of subtotal checkboxes is 9 as expected", true);
                }
                else
                {
                    Reports.StatusUpdate("Subtotal checkboxes count error", true);
                }
                #endregion*/

                #region Active Headers check
                int chckActiveHeaders = FastDriver.WebDriver.FindElements(By.XPath("//div[@class='SectionHeader']")).Count();
                if (chckActiveHeaders == 9)
                {
                    Reports.StatusUpdate("Number of active headers is 9 as expected by configuration", true);
                }
                else
                {
                    Reports.StatusUpdate("Active headers count error", false);
                }
                #endregion

                #region Inactive Headers Check
                int chckInactiveHeaders = FastDriver.WebDriver.FindElements(By.XPath("//div[@class='SectionHeader_disabled']")).Count();
                if (chckInactiveHeaders == 6)
                {
                    Reports.StatusUpdate("Number of inactive headers is 6 as expected by configuration", true);
                }
                else
                {
                    Reports.StatusUpdate("Inactive headers count error", false);
                }
                #endregion

                #region Expand/Collapse buttons check
                if (!(FastDriver.ViewSettlementStatement.btnCollapseAll.Exists()))
                { Reports.StatusUpdate("Collapse all button is not displayed", false); }
                if (!(FastDriver.ViewSettlementStatement.btnExpandAll.Exists()))
                { Reports.StatusUpdate("Expand all button not appearing", false); }
                if (!(FastDriver.ViewSettlementStatement.btnExpandAll.GetAttribute("Title").ToString() == "Click to expand all section"))
                { Reports.StatusUpdate("ExpandAll tooltip error", false); }
                if (!(FastDriver.ViewSettlementStatement.btnCollapseAll.GetAttribute("Title").ToString() == "Click to collapse all section"))
                { Reports.StatusUpdate("CollapseAll tooltip error", false); }
                FastDriver.ViewSettlementStatement.btnCollapseAll.FAClick();

                int chckExpndCollBtns = FastDriver.WebDriver.FindElements(By.XPath("//img[contains(@Id,'Arrow-')]")).Count();
                //int chckExpndCollBtns = FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.FAFindElements(ByLocator.XPath, "//img[contains(@Id,'Arrow-')]").ToListString();

                if (chckExpndCollBtns == 15)
                {
                    Reports.StatusUpdate("Number expand/collapse buttons is 15 as expected by configuration", true);
                }
                else
                {
                    Reports.StatusUpdate("expand/collapse buttons count error", false);
                }
                #endregion

                /*#region Subtotal funtionality check

                FastDriver.ViewSettlementStatement.MarkSelectAllCheckBox();

                if (FastDriver.ViewSettlementStatement.FundsHeld_SubtotalsCheckbox.GetAttribute("checked") == "False" || FastDriver.ViewSettlementStatement.TitleEscrow_SubtotalCheckbox.GetAttribute("checked") == "False" || FastDriver.ViewSettlementStatement.NewLoan_SubtotalsCheckbox.GetAttribute("checked") == "False" || FastDriver.ViewSettlementStatement.DepositsInEscrow_SubtotalCheckbox.GetAttribute("checked") == "False")
                    Reports.StatusUpdate("Enabled subtotals check boxes error", false);

                if (FastDriver.ViewSettlementStatement.PayoffLoan_SubtotalsCheckbox.GetAttribute("checked") == "True" || FastDriver.ViewSettlementStatement.AssumptionLoan_SubtotalsCheckbox.GetAttribute("checked") == "True" || FastDriver.ViewSettlementStatement.Commissions_SubtotalCheckbox.GetAttribute("checked") == "True" || FastDriver.ViewSettlementStatement.Attorney_SubtotalsCheckbox.GetAttribute("checked") == "True")
                    Reports.StatusUpdate("Disabled subtotals check boxes error", false);
                FastDriver.ViewSettlementStatement.btnExpandAll.FAClick();

                if (FastDriver.ViewSettlementStatement.DepositsInEscrow.FAGetText().Clean().Contains("Total Buyer Deposits in Escrow $123,456,789.00").ToString() != "True")
                    Reports.StatusUpdate("Error with Deposits in Escrow buyer subtotals line item", false);
                if (FastDriver.ViewSettlementStatement.DepositsInEscrow.FAGetText().Clean().Contains("Total Seller Deposits in Escrow $50,000,000.13").ToString() != "True")
                    Reports.StatusUpdate("Error with Deposits in Escrow seller subtotals line item", false);
                if (FastDriver.ViewSettlementStatement.TitleEscrowChargesTBL.FAGetText().Clean().Contains("Total Buyer Title/Escrow Charge $2,101.03").ToString() != "True")
                    Reports.StatusUpdate("Error with Title/Escrow charges buyer subtotals line item", false);
                if (FastDriver.ViewSettlementStatement.TitleEscrowChargesTBL.FAGetText().Clean().Contains("Total Seller Title/Escrow Charge $3,909.12").ToString() != "True")
                    Reports.StatusUpdate("Error with Title/Escrow charges seller subtotals line item", false);
                if (FastDriver.ViewSettlementStatement.NewFundsHeldTable.FAGetText().Clean().Contains("Total Buyer Funds Held $6,559.93").ToString() != "True")
                    Reports.StatusUpdate("Error with Funds Held buyer subtotals line item", false);
                if (FastDriver.ViewSettlementStatement.NewFundsHeldTable.FAGetText().Clean().Contains("Total Seller Funds Held $1,234,567.39").ToString() != "True")
                    Reports.StatusUpdate("Error with Funds Held seller subtotals line item", false);
                #endregion*/
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        // FMUC0135_REG0009/10/11 are brought in from TDS UC .cs file
        [TestMethod]
        public void FMUC0135_REG0009()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "-User Story 380706: Terms/Dates/Status New features validation: Edit SP/OPL button, Additional Sale Price Fields, Total Sale Price label";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);


                //Reports.TestStep = "Navigate to a region and office with the Feature 5 permission.";

                //FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedOfficeBUID);

                Reports.TestStep = "Create File with Commercial business type.";

                #region Through UI
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("800");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Done();

                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                #region Through WS
                /*           
                FastDriver.TopFrame.SearchFileByFileNumber(RequestFactory.NCSCreateCommercialFilewAmounts().File.FileNumber);
                  */
                #endregion

                Reports.TestStep = "Navigate to the Terms/Dates/Status screen";

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad().SwitchToContentFrame();

                Reports.TestStep = "Verify the Edit SP/OPL button is displayed in the Terms/Dates/Status screen";

                Support.AreEqual("true", FastDriver.TermsDatesStatus.Edit_SP_OPL.Exists().ToString(), true);

                Reports.TestStep = "Verify the SP/OPL pop up dialog is opened after clicking the Edit SP/OPL button.";

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                Support.AreEqual("True", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SP_OPL_Dlg_Frame.Exists().ToString(), true);

                Reports.TestStep = "Verify that no message is displayed when Sale Price Description is entered without Sale Price Amount.";
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("Test Change 1");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText(" ");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                string a = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("No dialog present", a);
                //Support.AreEqual("False", FastDriver.IEMessageDlg.IEAlertMessage.Exists().ToString());

                Reports.TestStep = "Verify that message is displayed when Sale Price Amount is entered without Sale Price Description.";

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText(" ");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText("100000");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual("Description can not be blank", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());

                Reports.TestStep = "Verify that Total Sale Price is displayed updated in File Homepage after updated in Terms/Dates/Status.";

                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("Test Change 1");
                Keyboard.SendKeys("{TAB}");
                string Dlg_TotalSP1 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.TotalSalePrice.FAGetValue();
                string ScndSPriceText1 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().ToString();
                string ScndSAmount1 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FAGetValue();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 30));

                Support.AreEqual("Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.HandleDialogMessage(timeout: 30).ToString().Clean(), true);


                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.TermsDatesStatus.SwitchToContentFrame();

                string TDS_SalePrice = FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue().ToString();

                FastDriver.TermsDatesStatus.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Support.AreEqual(TDS_SalePrice, FastDriver.FileHomepage.TermsDatesPrice.FAGetValue().ToString(), true);

                Reports.TestStep = "Verify that Total Sale Price is displayed updated in File Summary after updated in Terms/Dates/Status.";

                FastDriver.LeftNavigation.Navigate<FileSummary>("Home>Order Entry>File Summary").WaitForScreenToLoad();

                Support.AreEqual(TDS_SalePrice, FastDriver.FileSummary.SalesPrice.FAGetText().FormatAsMoney(), true);


                Reports.TestStep = "verify Starter/Ref. for Total Sale Price; User Story 629699 coverage.";

                #region Through UI
                FastDriver.FileSummary.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");

                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Done();

                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                FastDriver.TopFrame.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<StarterReference>("Home>Order Entry>Starter/Ref.").WaitForScreenToLoad().SwitchToContentFrame();

                FastDriver.StarterReference.StarterFileNumber.FASetText(fileNum);

                FastDriver.StarterReference.AllFileItems.FAClick();
                FastDriver.StarterReference.CopyNow.FAClick();
                Playback.Wait(9000);

                //Navitage to Terms/Date/Status screen and compare.
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 15);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                Support.AreEqual(Dlg_TotalSP1, FastDriver.SalePrice_OwnerPolicyLiabilityDlg.TotalSalePrice.FAGetValue().ToString().Clean());
                Support.AreEqual(ScndSPriceText1, FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().ToString().Clean());
                Support.AreEqual(ScndSAmount1, FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FAGetValue().ToString().Clean());

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickCancel();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0135_REG0010()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Editable labels for different considerations/Sale Price on the TDS screen";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //Reports.TestStep = "Navigate to a region and office with the Feature 5 permission.";

                //FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedOfficeBUID);

                Reports.TestStep = "Create File with Commercial business type.";

                #region Through UI
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("800");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Done();

                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                Reports.TestStep = "Navigate to the Terms/Dates/Status screen";

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();

                Reports.TestStep = "Verify the SP/OPL pop up dialog is opened after clicking the Edit SP/OPL button and verify default values for the five Sale Price fields.";

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 15);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                Support.AreEqual("True", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SP_OPL_Dlg_Frame.Exists().ToString(), true);

                #region default values checks
                //Labels
                Support.AreEqual("First Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue());
                Support.AreEqual("Second Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue());
                Support.AreEqual("Third Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue());
                Support.AreEqual("Fourth Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue());
                Support.AreEqual("Fifth Sale Price", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue());

                //Amounts                
                Support.AreEqual("0.00", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FAGetValue());
                Support.AreEqual("0.00", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FAGetValue());
                Support.AreEqual("0.00", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceAmount.FAGetValue());
                Support.AreEqual("0.00", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceAmount.FAGetValue());

                //Total
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.TotalSalePrice.Enabled.ToString());
                #endregion

                Reports.TestStep = "Verify that input max lenght is 50 characters in the description fields- Alphabets";
                #region Alphabets checks
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue().Length.ToString());
                #endregion

                //
                Reports.TestStep = "Verify that input max lenght is 50 characters in the description fields- Numeric";
                #region Numeric checks
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("012345678901234567890123456789012345678901234567890");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("012345678901234567890123456789012345678901234567890");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("012345678901234567890123456789012345678901234567890");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("012345678901234567890123456789012345678901234567890");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("012345678901234567890123456789012345678901234567890");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue().Length.ToString());
                #endregion

                //
                Reports.TestStep = "Verify that input max lenght is 50 characters in the description fields- Alphanumerics";
                #region Alphanumerics checks
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("aA0bB1cC2dD3eE4fF5gG6hH7iI8jJ9kKlLmMnNoOpPqQrRsStTuUvV");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("aA0bB1cC2dD3eE4fF5gG6hH7iI8jJ9kKlLmMnNoOpPqQrRsStTuUvV");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("aA0bB1cC2dD3eE4fF5gG6hH7iI8jJ9kKlLmMnNoOpPqQrRsStTuUvV");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("aA0bB1cC2dD3eE4fF5gG6hH7iI8jJ9kKlLmMnNoOpPqQrRsStTuUvV");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("aA0bB1cC2dD3eE4fF5gG6hH7iI8jJ9kKlLmMnNoOpPqQrRsStTuUvV");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue().Length.ToString());
                #endregion

                //
                Reports.TestStep = "Verify that input max lenght is 50 characters in the description fields- Special characters";
                #region Special characters checks

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("<>*%$#:;'/+-=().,_&<>*%$#:;'\"/+-=().,_&<>*%$#:;'\\<>()<>()<>/+\"");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("<>*%$#:;'/+-=().,_&<>*%$#:;'\"/+-=().,_&<>*%$#:;'\\<>()<>()<>/+\"");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("<>*%$#:;'/+-=().,_&<>*%$#:;'\"/+-=().,_&<>*%$#:;'\\<>()<>()<>/+\"");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("<>*%$#:;'/+-=().,_&<>*%$#:;'\"/+-=().,_&<>*%$#:;'\\<>()<>()<>/+\"");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("<>*%$#:;'/+-=().,_&<>*%$#:;'\"/+-=().,_&<>*%$#:;'\\<>()<>()<>/+\"");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue().Length.ToString());
                #endregion

                //
                Reports.TestStep = "Verify that input max lenght is 50 characters in the description fields - Alphanumeric with Special characters";
                #region Alphanumeric with Special characters check

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("A0<b1>C2*d3%E4$f5#G6:h7;iI8'jJ9/kK+lL-mM&nN_oO.pP,qQ=rR(sS)");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("A0<b1>C2*d3%E4$f5#G6:h7;iI8'jJ9/kK+lL-mM&nN_oO.pP,qQ=rR(sS)");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("A0<b1>C2*d3%E4$f5#G6:h7;iI8'jJ9/kK+lL-mM&nN_oO.pP,qQ=rR(sS)");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("A0<b1>C2*d3%E4$f5#G6:h7;iI8'jJ9/kK+lL-mM&nN_oO.pP,qQ=rR(sS)");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FAGetValue().Length.ToString());
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("A0<b1>C2*d3%E4$f5#G6:h7;iI8'jJ9/kK+lL-mM&nN_oO.pP,qQ=rR(sS)");
                Support.AreEqual("50", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FAGetValue().Length.ToString());
                #endregion

                //
                Reports.TestStep = "Verify message pop up for invalid Special Characters input in the description fields";
                #region invalid Special Characters checks

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("!");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("First Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("@");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("Second Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("^");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("Third Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("`");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("Fourth Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("{");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("Fifth Sale Price");


                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("}");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("First Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("[");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("Second Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("]");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("Third Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("|");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("Fourth Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("~");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("Fifth Sale Price");

                #endregion

                Reports.TestStep = "Verify that input of mixed characters in the description fields gives invalid message pop up - Alphanumeric with invalid Special characters";
                #region Alphanumeric and Special characters with invalid characters checks

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("A0<!");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("First Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("@b1>");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("Second Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("C2*^");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("Third Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("E4${");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("Fourth Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("}d3%");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("Fifth Sale Price");


                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("f5#[");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.FASetText("First Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("G:]");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText("Second Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("~h7;");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.FASetText("Third Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("|iI8'");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.FASetText("Fourth Sale Price");

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("K+lL`");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 10).ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", timeoutSeconds: 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.FASetText("Fifth Sale Price");

                #endregion


                Reports.TestStep = "Verify that total amount equals the sum of all Sale Price Amounts.";
                #region Sum All Amounts

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText("100000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FASetText("200000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceAmount.FASetText("300000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceAmount.FASetText("400000");
                Keyboard.SendKeys("{TAB}");

                string amt1 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceAmount.FAGetValue();
                string amt2 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FAGetValue();
                string amt3 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FAGetValue();
                string amt4 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceAmount.FAGetValue();
                string amt5 = FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceAmount.FAGetValue();

                decimal amtsum = decimal.Parse(amt1) + decimal.Parse(amt2) + decimal.Parse(amt3) + decimal.Parse(amt4) + decimal.Parse(amt5);
                string totalamt = amtsum.ToString("#,#.00");

                Support.AreEqual(totalamt, FastDriver.SalePrice_OwnerPolicyLiabilityDlg.TotalSalePrice.FAGetValue());
                #endregion
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 30));

                Support.AreEqual("Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.HandleDialogMessage(timeout: 30).ToString().Clean(), true);


                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);


                Reports.TestStep = "Verify if system displays Sale Price/Owner's Policy Liabilities webpage dialog for HUD file";
                #region HUD file
                Reports.TestStep = "Change File Format to HUD";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();

                FastDriver.FileFees.HUD.FAClick();
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Navigate to the Terms/Dates/Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();


                Reports.TestStep = "Verify that the elipse button is displayed instead of the Edit SP/OPL button in the Terms/Dates/Status screen for file type HUD ";
                Support.AreEqual("...", FastDriver.TermsDatesStatus.Edit_SP_OPL.FAGetText());

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Verify that the Sale price fields are not displayed for HUD file.";
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.Exists().ToString());

                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                Reports.TestStep = "Verify if system displays Sale Price/Owner's Policy Liabilities webpage dialog for Refinance file";
                #region Refinance file

                Reports.TestStep = "Change File Format to CD and Transaction type to refinance";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();

                FastDriver.FileFees.CD.FAClick();
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys("R");
                Playback.Wait(2000);
                //Keyboard.SendKeys("{TAB}");               
                Support.AreEqual("The sale price and all seller charges and credits will be removed, Continue?", FastDriver.WebDriver.HandleDialogMessage(timeout: 15).ToString().Clean());


                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to the Terms/Dates/Status screen";

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();

                Reports.TestStep = "Verify that the elipse button is displayed instead of the Edit SP/OPL button in the Terms/Dates/Status screen for file type HUD ";
                Support.AreEqual("...", FastDriver.TermsDatesStatus.Edit_SP_OPL.FAGetText());

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Verify that the Sale price fields are not displayed for Refinance file.";
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceDesc.Exists().ToString());
                Support.AreEqual("False", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceDesc.Exists().ToString());
                FastDriver.DialogBottomFrame.ClickCancel();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0135_REG0011()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "User Story 814221: REQ0991048- Total Sale Price becomes enabled upon removing the break down in the webpage.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File with Commercial business type and add values to Sales Price and  First New Loan fields.";

                #region Through UI
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("800");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Done();

                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                Reports.TestStep = "Navigate to the Terms/Dates/Status screen";

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad().SwitchToContentFrame();

                Reports.TestStep = "Click the Edit SP/OPL button to open the SP/OPL  dialog box.";

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Add  2nd, 3rd,4th and 5th Sale price breakdowns.";
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText("100000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FASetText("200000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceAmount.FASetText("300000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceAmount.FASetText("400000");


                Reports.TestStep = "Close the dialog and verify the Total Sale Price textbox is disabled.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 30));

                Support.AreEqual("Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.HandleDialogMessage(timeout: 30).ToString().Clean(), true);

                FastDriver.DialogBottomFrame.SwitchToContentFrame();
                Support.AreEqual(false, FastDriver.TermsDatesStatus.SalesPriceAmount.IsEnabled(), "Confirm Total Sales Price textbox is desabled.");


                Reports.TestStep = "Open the SP/OPL dialog box again and clear the 1st Sale price; then close and confirm Total Sale Price textbox is still disabled.";

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FirstSalePriceAmount.FASetText("0");
                Keyboard.SendKeys("{TAB}");

                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 30));

                Support.AreEqual("Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.HandleDialogMessage(timeout: 30).ToString().Clean(), true);
                FastDriver.DialogBottomFrame.SwitchToContentFrame();
                Support.AreEqual(false, FastDriver.TermsDatesStatus.SalesPriceAmount.IsEnabled(), "Confirm Total Sales Price textbox is desabled.");

                Reports.TestStep = "Open the SP/OPL dialog box again and clear the rest of the Sale prices; then close and confirm Total Sale Price textbox is enabled.";

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText("0");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FASetText("0");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceAmount.FASetText("0");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceAmount.FASetText("0");
                Keyboard.SendKeys("{TAB}");

                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 30));

                FastDriver.DialogBottomFrame.SwitchToContentFrame();
                Support.AreEqual(true, FastDriver.TermsDatesStatus.SalesPriceAmount.IsEnabled(), "Confirm Total Sales Price textbox is enabled.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion
        #region r00.2016
        [TestMethod]
        public void FMCU0135_BAT0001_NCS()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "User Story 5599410: Provide Control Access to regions for 2824 Feature 5.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File with Commercial business type and Escrow and Sub-Escrow service types.";

                #region Through UI
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("800");

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Done();

                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                Reports.TestStep = "Navigate to View Settlement Statement screen";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.TestStep = "Confirm the screen is displayed with the new elements of Feature 5";

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.btnExpandAll.Exists(), "Validating presence of Feature 5 elements in screen.");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.GoToButton.Exists(), "Validating presence of Feature 5 elements in screen.");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.NewConsiderationSection.Exists(), "Validating presence of Feature 5 elements in screen.");

                Reports.TestStep = "Change the Business segment to other than Commercial";

                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Residential");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Return to View Settlement Statement screen";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.TestStep = "Confirm the screen does not display the new elements of Feature 5";

                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.btnExpandAll.Exists(), "Validating Feature 5 elements are not displayed in screen.");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.GoToButton.Exists(), "Validating Feature 5 elements are not displayed in screen.");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.NewConsiderationSection.Exists(), "Validating Feature 5 elements are not displayed in screen.");

                //your test case code here
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region r01.2016
        //FMUC0083_BAT0001_NCS moved to 0136 use case document because of some references and namespaces issues
        #endregion
        #region r02.2016
        #endregion
        #region r03.2016
        [TestMethod]
        public void US_692339_NCS()
        {
            try
            {
                Reports.TestDescription = "Remove the subtotal checkbox for the \"Disbursements Paid\" section.";
                #region Log into IIS of testing enviroment
                Reports.TestStep = "Log into IIS of testing enviroment";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,                // AutoConfig.UserName,
                    Password = AutoConfig.UserPassword            //AutoConfig.UserPassword
                };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                //FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion
                #region Configure Printer
                SetDefaultCheckPrinter();
                #endregion
                #region Create File
                try
                {
                    #region Create CD File using FileService
                    CreateCDFile();
                    #endregion
                }
                catch (Exception)
                {
                    #region Create File Using GUI
                    CreateFileUsingGUI();
                    #endregion
                }
                #endregion
                //FastDriver.TopFrame.SearchFileByFileNumber("66444");
                //TC707354
                #region To verify instance group header is displayed in bold for commission section
                #region Navigate to Real Estate Buyer and Seller Broker screen and add GAB with Commission amounts
                Reports.TestStep = "Navigate to Real Estate Buyer and Seller Broker screen and add GAB with Commission amounts";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                //FastDriver.RealEstateBrokerAgent.FindGAB("50812");
                FastDriver.RealEstateBrokerAgent.FindGAB("508");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("7.00");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("3.00" + Keys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("5.00" + Keys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion
                Reports.TestStep = "To verify instance group header is displayed in bold for commission section";
                //FastDriver.ViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.");
                FastDriver.ViewSettlementStatement.WaitForScreenToLoad(FastDriver.ViewSettlementStatement.Commission);
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.IsDisbursementSectionDisabled(), "System should display the Disbursement section in grey and collapsed.");
                //Support.AreEqual("false", FastDriver.ViewSettlementStatement.AreSubtotalsLabelAndCheckboxDisplayed().ToString().ToLower(), "System should not display the Subtotal Label and checkbox.");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.Commission.FAGetText().Contains("3.00"), "Verifying amounts are displayed on for Buyer on Commission table");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.Commission.FAGetText().Contains("5.00"), "Verifying amounts are displayed on for Seller on Commission table");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.NewCommissionsTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAGetFontStyleProperties().IsBold, "Verify The REB broker instance header is displayed in bold followed by charges of the instance Broker : <Sellers (Listing) Broker>");//Weight of 700 indicates text is bold
                #endregion
                #region Navigate to Real Estate Buyer and Seller Broker screen and add GAB with Commission amounts x1
                Reports.TestStep = "Navigate to Real Estate Buyer and Seller Broker screen and add GAB with Commission amounts x1";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                //FastDriver.RealEstateBrokerAgent.FindGAB("41029");
                FastDriver.RealEstateBrokerAgent.FindGAB("410");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("9.00");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("6.00" + Keys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("8.00" + Keys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion
                #region To verify instance group header is displayed in bold for commission section x1
                Reports.TestStep = "To verify instance group header is displayed in bold for commission section x1";
                FastDriver.ViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.IsDisbursementSectionDisabled(), "System should display the Disbursement section in grey and collapsed.");
                //Support.AreEqual("false", FastDriver.ViewSettlementStatement.AreSubtotalsLabelAndCheckboxDisplayed().ToString().ToLower(), "System should not display the Subtotal Label and checkbox.");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.Commission.FAGetText().Contains("6.00"), "Verifying amounts are displayed on for Buyer on Commission table");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.Commission.FAGetText().Contains("8.00"), "Verifying amounts are displayed on for Seller on Commission table");
                Support.AreEqual(true, FastDriver.WebDriver.FindElement(By.CssSelector("#table-6 tr:last-child table")).PerformTableAction(1, 3, TableAction.GetCell).Element.FAGetFontStyleProperties().IsBold, "Verify The REB broker instance header is displayed in bold followed by charges of the instance Broker : <Sellers (Listing) Broker>");//Weight of 700 indicates text is bold
                #endregion
                #region Navigate to Real Estate Buyer and Seller Broker screen and add GAB with Commission amounts x2
                Reports.TestStep = "Navigate to Real Estate Buyer and Seller Broker screen and add GAB with Commission amounts x2";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                //FastDriver.RealEstateBrokerAgent.FindGAB("605");
                FastDriver.RealEstateBrokerAgent.FindGAB("508");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1.00");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("2.00" + Keys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("3.00" + Keys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion
                #region To verify instance group header is displayed in bold for commission section x2
                Reports.TestStep = "To verify instance group header is displayed in bold for commission section x2";
                FastDriver.ViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.IsDisbursementSectionDisabled(), "System should display the Disbursement section in grey and collapsed.");
                //Support.AreEqual("false", FastDriver.ViewSettlementStatement.AreSubtotalsLabelAndCheckboxDisplayed().ToString().ToLower(), "System should not display the Subtotal Label and checkbox.");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.Commission.FAGetText().Contains("2.00"), "Verifying amounts are displayed on for Buyer on Commission table");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.Commission.FAGetText().Contains("3.00"), "Verifying amounts are displayed on for Seller on Commission table");
                Support.AreEqual(true, FastDriver.WebDriver.FindElement(By.CssSelector("#table-6 tr:last-child table")).PerformTableAction(1, 3, TableAction.GetCell).Element.FAGetFontStyleProperties().IsBold, "Verify The REB broker instance header is displayed in bold followed by charges of the instance Broker : <Sellers (Listing) Broker>");//Weight of 700 indicates text is bold
                #endregion
                //TC707355
                #region To verify  instance group header is displayed in bold for Attorney section
                #region Navigate to Attorney Buyer screen and add charges
                FastDriver.AttorneyDetail.Open(isBuyer: true);
                //FastDriver.AttorneyDetail.FindGABcode("605");
                FastDriver.AttorneyDetail.FindGABcode("508");
                FastDriver.AttorneyDetail.BuyerCharge.FASetText("2.00");
                FastDriver.AttorneyDetail.SellerCharge.FASetText("3.00");
                FastDriver.BottomFrame.Done();
                #endregion
                Reports.TestStep = "To verify  instance group header is displayed in bold for Attorney section";
                FastDriver.ViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.IsDisbursementSectionDisabled(), "System should display the Disbursement section in grey and collapsed.");
                //Support.AreEqual("false", FastDriver.ViewSettlementStatement.AreSubtotalsLabelAndCheckboxDisplayed().ToString().ToLower(), "System should not display the Subtotal Label and checkbox.");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.Attorney.FAGetText().Contains("2.00"), "Verifying amounts are displayed on for Buyer on Attorney table");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.Attorney.FAGetText().Contains("3.00"), "Verifying amounts are displayed on for Seller on Attorney table");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.NewAttorneyTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAGetFontStyleProperties().IsBold, "Verify The Attorney buyer instance header is displayed in bold followed by charges of the instance Attorney: <Buyer's Instance 1 - GAB Name>");//Weight of 700 indicates text is bold
                #region Navigate to Attorney Seller screen and add charges
                Reports.TestStep = "Navigate to Attorney Seller screen and add charges";
                FastDriver.AttorneyDetail.Open(isBuyer: false);
                FastDriver.AttorneyDetail.FindGABcode("511");
                FastDriver.AttorneyDetail.BuyerCharge.FASetText("4.00");
                FastDriver.AttorneyDetail.SellerCharge.FASetText("5.00");
                FastDriver.BottomFrame.Done();
                #endregion
                Reports.TestStep = "To verify  instance group header is displayed in bold for Attorney section x1";
                FastDriver.ViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.Attorney.FAGetText().Contains("4.00"), "Verifying amounts are displayed on for Buyer on Attorney table");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.Attorney.FAGetText().Contains("5.00"), "Verifying amounts are displayed on for Seller on Attorney table");
                Support.AreEqual(true, FastDriver.WebDriver.FindElement(By.CssSelector("#table-7 tr:last-child table")).PerformTableAction(1, 3, TableAction.GetCell).Element.FAGetFontStyleProperties().IsBold, "Verify The Attorney buyer instance header is displayed in bold followed by charges of the instance Attorney: <Seller's Instance 1 - GAB Name>");//Weight of 700 indicates text is bold
                #endregion
                //TC707360 
                #region To verify  instance group header is displayed in bold for New Loan (s) section
                #region Navigate to New Loan and add charges.
                Reports.TestStep = "Navigate to New Loan and add charges.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("440");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(timeout: 3); // to handle Changing Business Party error
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction("Description", "Application Fee", "Buyer Charge", TableAction.SetText, "2.00");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction("Description", "Application Fee", "Seller Charge", TableAction.SetText, "3.00");
                FastDriver.BottomFrame.Done();
                #endregion
                #region To verify  instance group header is displayed in bold for New Loan(s) section
                Reports.TestStep = "To verify  instance group header is displayed in bold for New Loan(s) section";
                FastDriver.ViewSettlementStatement.Open();
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.NewNewLoanTable.FAGetText().Contains("2.00"), "Verifying amounts are displayed on for Buyer on New Loan table");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.NewNewLoanTable.FAGetText().Contains("3.00"), "Verifying amounts are displayed on for Seller on New Loan  table");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.NewNewLoanTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAGetFontStyleProperties().IsBold, "Verify The New Loan buyer instance header is displayed in bold followed by charges of the instance Lender: <New Loan Instance 1 - GAB Name>");//Weight of 700 indicates text is bold
                #endregion
                #region Navigate to New Loan and add charges x1
                Reports.TestStep = "Navigate to New Loan and add charges x1";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGABCode("312");
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "4.00");
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "5.00");
                FastDriver.BottomFrame.Done();
                #endregion
                #region To verify  instance group header is displayed in bold for New Loan(s) section x1
                Reports.TestStep = "To verify  instance group header is displayed in bold for New Loan(s) section x1";
                FastDriver.ViewSettlementStatement.Open();
                Support.AreEqual(true, FastDriver.WebDriver.FindElement(By.CssSelector("#table-8 tr:last-child table")).FAGetText().Contains("4.00"), "Verifying amounts are displayed on for Buyer on New Loan table");
                Support.AreEqual(true, FastDriver.WebDriver.FindElement(By.CssSelector("#table-8 tr:last-child table")).FAGetText().Contains("5.00"), "Verifying amounts are displayed on for Seller on New Loan  table");
                Support.AreEqual(true, FastDriver.WebDriver.FindElement(By.CssSelector("#table-8 tr:last-child table")).PerformTableAction(1, 3, TableAction.GetCell).Element.FAGetFontStyleProperties().IsBold, "Verify The New Loan buyer instance header is displayed in bold followed by charges of the instance Mrtg. Broker: <Mortgage broker Instance 1 - GAB Name>");//Weight of 700 indicates text is bold
                #endregion
                #endregion
                //TC707361
                #region To verify  instance group header is displayed in bold for Payoff Loan(s) section
                #region Navigate to Payoff Loan screen and add charges
                Reports.TestStep = "Navigate to Payoff Loan screen and add charges";
                FastDriver.PayoffLoanDetails.Open();
                FastDriver.PayoffLoanDetails.FindGABCode("313");
                FastDriver.PayoffLoanDetails.WaitCreation(FastDriver.PayoffLoanDetails.LenderGABName);
                string PayoffLenderName = FastDriver.PayoffLoanDetails.LenderGABName.FAGetText();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitCreation(FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge);
                FastDriver.PayoffLoanCharges.LoanChargesTable.PerformTableAction("Description", "Principal Balance", "Buyer Charge", TableAction.SetText, "2.00");
                FastDriver.PayoffLoanCharges.LoanChargesTable.PerformTableAction("Description", "Principal Balance", "Seller Charge", TableAction.SetText, "3.00");
                FastDriver.BottomFrame.Done();
                #endregion
                Reports.TestStep = "To verify  instance group header is displayed in bold for Payoff Loan(s) section";
                FastDriver.ViewSettlementStatement.Open();
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.NewPayoffLoanTable.FAGetText().Contains("2.00"), "Verifying amounts are displayed on for Buyer on Payoff Loan table");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.NewPayoffLoanTable.FAGetText().Contains("3.00"), "Verifying amounts are displayed on for Seller on Payoff Loan  table");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.NewPayoffLoanTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAGetFontStyleProperties().IsBold, "Verify The Payoff Loan buyer instance header is displayed in bold followed by charges of the instance Lender:  Payoff Loan Instance 1 - GAB Name>");//Weight of 700 indicates text is bold
                Support.AreEqual(true.ToString().ToLower(), FastDriver.ViewSettlementStatement.NewPayoffLoanTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAGetText().Contains(PayoffLenderName).ToString().ToLower(), "Verify The Payoff Loan buyer instance header contains " + PayoffLenderName);
                #endregion
                //TC707362
                #region To verify  instance group header is displayed in bold for Assumption Loan(s) section
                #region Navigate to Assumption Loan screen and add charges
                Reports.TestStep = "Navigate to Assumption Loan screen and add charges";
                FastDriver.AssumptionLoanDetails.Open();
                FastDriver.AssumptionLoanDetails.FindGABCode("315");
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.GABcodeName);
                string AssumptionLenderName = FastDriver.AssumptionLoanDetails.GABcodeName.FAGetText();
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UnpaidPrincipalLoanChargesTable.PerformTableAction("Description", "Unpaid Principal Balance", "Seller Charge", TableAction.SetText, "3.00");
                FastDriver.BottomFrame.Done();
                #endregion
                Reports.TestStep = "To verify  instance group header is displayed in bold for Assumption Loan(s) section";
                FastDriver.ViewSettlementStatement.Open();
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.AssumptionLoanTable.FAGetText().Contains("3.00"), "Verifying amounts are displayed on for Seller on Assumption Loan  table");
                Support.AreEqual(true, FastDriver.ViewSettlementStatement.AssumptionLoanTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAGetFontStyleProperties().IsBold, "Verify The Assumption Loan buyer instance header is displayed in bold followed by charges of the instance Lender:  Assumption Loan Instance 1 - GAB Name>");//Weight of 700 indicates text is bold
                Support.AreEqual(true.ToString().ToLower(), FastDriver.ViewSettlementStatement.AssumptionLoanTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAGetText().Contains(AssumptionLenderName).ToString().ToLower(), "Verify The Assumption Loan buyer instance header contains " + AssumptionLenderName);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test case US_692339_NCS failed because " + ex.Message);
            }
        }
        #endregion
        #region r04.2016
        //FMUC0135_REG0027 Covers US 684190
        [TestMethod]
        public void FMUC0135_REG0027()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verification of the New 'Disbursements Paid' section in the View Settlement Statement UI.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File.";               
                CreateFile_WS();

                #region Lease setup
                Reports.TestStep = "Navigate to the Lease screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("420");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("300");
                FastDriver.LeaseDetail.SellerCharge.FASetText("300");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Homeowner Association setup
                Reports.TestStep = "Navigate to Homeowner Association and add values to buyer and seller.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge1.FASetText("500");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge2.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge3.FASetText("5000");

                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FASetText("500");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge1.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge2.FASetText("500");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge3.FASetText("1000");

                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Warranty setup
                Reports.TestStep = "Navigate to Home Warranty and add values to buyer and seller.";

                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                FastDriver.HomeWarrantyDetail.FindGABCode("246");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("1000");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Inspection Repair setup
                Reports.TestStep = "Navigate to Inspection Repair Pest screen and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.FindGAB("800");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("500");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Inspection Repair Septic and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").WaitForScreenToLoad();
                FastDriver.InspectionRepairSeptic.FindGAB("247");
                FastDriver.InspectionRepairSeptic.BuyerCharge.FASetText("500");
                FastDriver.InspectionRepairSeptic.SellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Inspection Repair Other and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.FindGAB("246");
                FastDriver.InspectionRepairOther.BuyerCharge.FASetText("500");
                FastDriver.InspectionRepairOther.SellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance setup
                Reports.TestStep = "Navigate to the Insurance screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FindGAB("420");
                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("1000");
                FastDriver.InsuranceFire.FireSellerCharge.FASetText("500");
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad().Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.FindGAB("boa");
                FastDriver.Insuranceflood.FloodBuyercharge.FASetText("500");
                FastDriver.Insuranceflood.FloodSellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad().Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.FindGAB("420");
                FastDriver.InsuranceWind.WindBuyerCharge.FASetText("500");
                FastDriver.InsuranceWind.WindSellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad().EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.FindGAB("246");
                FastDriver.InsuranceEarth.EarthBuyerCharge.FASetText("1000");
                FastDriver.InsuranceEarth.EarthSellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Navigate to the View Settlement Stmt screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                
                Reports.TestStep = "Verify that the section with values are displayed and the ones without values are not displayed";

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_HomeOwnrAssoc_Label.Exists(), "'Homeowner Association sub-header is displayed");

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_HomeWarranty_Label.Exists(), "'Home Warranty sub-header is displayed");

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_InspctnRep_Label.Exists(), "'Inspection/Repair sub-header is displayed");

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_Insurance_Label.Exists(), "'Insurance sub-header is displayed");

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_Lease_Label.Exists(), "'Lease sub-header is displayed");

                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.Disburs_MiscDisbursement_Label.Exists(), "'Miscellaneous Disbursement sub-header is not displayed");

                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.Disburs_PropertyTaxChk_Label.Exists(), "'Property Tax Check sub-header is not displayed");

                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.Disburs_Survey_Label.Exists(), "'Survey sub-header is not displayed");

                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.Disburs_Utility_Label.Exists(), "'Utility sub-header is not displayed");

                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.Disburs_REBCharges_Label.Exists(), "'Real Estate Broker Charges sub-header is not displayed");

                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.Disburs_OutsideEscrow_Label.Exists(), "'Outside Escrow sub-header is not displayed");

                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

                #region Miscellaneous Disbursement setup
                Reports.TestStep = "Navigate to the Miscellaneous Disbursement screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("boa");
                FastDriver.MiscDisbursementDetail.Description.FASetText("Added value" + Keys.Tab);
                FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText("10000");
                FastDriver.MiscDisbursementDetail.SellerCharge.FASetText("15000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Tax Check setup
                Reports.TestStep = "Navigate to the Property Tax Check screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("420");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("300");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_3.FASetText("200");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_5.FASetText("100");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_2.FASetText("250");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_4.FASetText("250");
                FastDriver.BottomFrame.New();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("100");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("100");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_2.FASetText("700.01");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_2.FASetText("600.36");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey setup
                Reports.TestStep = "Navigate to the Survey screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("800");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("300000");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("200000");
                FastDriver.BottomFrame.New();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("500000");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.13");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Utility setup
                Reports.TestStep = "Navigate to the Utility screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("boa");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("1000");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText("1300");
                FastDriver.BottomFrame.Done();
                #endregion

                #region REB values setup
                Reports.TestStep = "Add REB commission charge for both buyer and seller.";
                #region step actions
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.FindGAB("800");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("20000");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual("Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 35));
                string BuyerREBrokerName = FastDriver.RealEstateBrokerAgent.BrokerName1.FAGetText().ToString().Clean();

                FastDriver.BottomFrame.Done();

                FastDriver.BottomFrame.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.FindGAB("246");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("10000");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual("Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 35));
                string SellerREBrokerName = FastDriver.RealEstateBrokerAgent.BrokerName1.FAGetText().ToString().Clean();
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                #region Outside Escrow Company setup
                Reports.TestStep = "Navigate to the Outside Escrow Company screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("246");
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("Outside Charges" + Keys.Tab);
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FASetText("1000");
                FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FASetText("1300");
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Navigate to the View Settlement Stmt screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                
                FastDriver.NCSViewSettlementStatement.DisbursementPaidSection.ScrollIntoView();

                Reports.TestStep = "Verify all the subsections are displayed.";
               Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_HomeOwnrAssoc_Label.Exists(), "'Homeowner Association sub-header is displayed");

               Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_HomeWarranty_Label.Exists(), "'Home Warranty sub-header is displayed"); 

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_InspctnRep_Label.Exists(), "'Inspection/Repair sub-header is displayed"); 

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_Insurance_Label.Exists(), "'Insurance sub-header is displayed"); 

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_Lease_Label.Displayed, "'Lease sub-header is displayed"); 

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_MiscDisbursement_Label.Exists(), "'Miscellaneous Disbursement sub-header is displayed"); 

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_PropertyTaxChk_Label.Exists(), "'Property Tax Check sub-header is displayed"); 

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_Survey_Label.Exists(), "'Survey sub-header is displayed"); 

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_Utility_Label.Exists(), "'Utility sub-header is displayed");

                //Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_REBCharges_Label.Exists(), "'Real Estate Broker Charges sub-header is displayed");

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Disburs_OutsideEscrow_Label.Exists(), "'Outside Escrow sub-header is displayed");               
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion
        #region r05.2016
        /// <summary>
        /// FMUC0135_REG0028 Covers US 602638
        /// FMUC0135_REG0029 - This Test method covers the US 609014 from r05
        /// </summary>
        [TestMethod]
        public void FMUC0135_REG0028()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Test Case Description";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                
                Reports.TestStep = "Create File.";
                CreateFile_WS();

                Reports.TestStep = "Adding REB commission charge for both buyer and seller.";
                #region step actions
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.FindGAB("3");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("20000");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual("Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 35));
                string BuyerREBrokerName = FastDriver.RealEstateBrokerAgent.BrokerName1.FAGetText().ToString().Clean();

                FastDriver.BottomFrame.Done();

                FastDriver.BottomFrame.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.FindGAB("274");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("10000");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual("Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 35));
                string SellerREBrokerName = FastDriver.RealEstateBrokerAgent.BrokerName1.FAGetText().ToString().Clean();
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Adding Attorneys charges for buyer and seller";
                #region Step actions
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.FindGABcode("249");
                string buyerAttorney = GetAttorneyName();
                FastDriver.AttorneyDetail.BuyerCharge.FASetText("2000");
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.FindGABcode("245");
                string sellerAttorney = FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName.FAGetText().ToString().Clean();
                FastDriver.AttorneyDetail.SellerCharge.FASetText("3000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Homeowner Association setup
                Reports.TestStep = "Navigate to Homeowner Association and add values to buyer and seller.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge1.FASetText("500");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge2.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge3.FASetText("5000");

                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FASetText("500");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge1.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge2.FASetText("500");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge3.FASetText("1000");

                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Warranty setup
                Reports.TestStep = "Navigate to Home Warranty and add values to buyer and seller.";

                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                FastDriver.HomeWarrantyDetail.FindGABCode("246");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("1000");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();
                #endregion 
             
                Reports.TestStep = "Navigate to the View Settlement Stmt screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.TestStep = "Verifying drag and drop of section in View Settlement Statement screen.";
                string ConsiderationPos1 = FastDriver.NCSViewSettlementStatement.ConsiderationTableDragDrop.FAGetLocation().Y.ToString();

                FastDriver.NCSViewSettlementStatement.ConsiderationTableDragDrop.FADragAndDrop(FastDriver.NCSViewSettlementStatement.DisbursementsTableDragDrop);

                Support.AreNotEqual(ConsiderationPos1, FastDriver.NCSViewSettlementStatement.ConsiderationTableDragDrop.FAGetLocation().Y.ToString(), "Consideration section successfully dropped.");

                Reports.TestStep = "Verifying drag and drop of Cash to/from Buyer/Seller and Totals sections is restricted in View Settlement Statement screen.";

                var CashFromToPos1 = FastDriver.NCSViewSettlementStatement.CashFromToTableDragDrop.FAGetLocation().Y;     
                
                FastDriver.NCSViewSettlementStatement.CashFromToTableDragDrop.FADragAndDrop(FastDriver.NCSViewSettlementStatement.TotalsTableDragDrop);
 
                var CashFromToPos2 = FastDriver.NCSViewSettlementStatement.CashFromToTableDragDrop.FAGetLocation().Y;

                if (CashFromToPos1 != CashFromToPos2)
                {
                    Support.AreEqual(CashFromToPos2.ToString(), FastDriver.NCSViewSettlementStatement.CashFromToTableDragDrop.FAGetLocation().Y.ToString(), "Cash From/To Buyer/Seller section is not allowed to be moved.");
                }
                else
                {
                    Support.AreEqual(CashFromToPos1.ToString(), FastDriver.NCSViewSettlementStatement.CashFromToTableDragDrop.FAGetLocation().Y.ToString(), "Cash From/To Buyer/Seller section is not allowed to be moved.");
                }               

                string TotalsPos1 = FastDriver.NCSViewSettlementStatement.TotalsTableDragDrop.FAGetLocation().Y.ToString();

                FastDriver.NCSViewSettlementStatement.TotalsTableDragDrop.FADragAndDrop(FastDriver.NCSViewSettlementStatement.CashFromToTableDragDrop);

                Support.AreEqual(TotalsPos1, FastDriver.NCSViewSettlementStatement.TotalsTableDragDrop.FAGetLocation().Y.ToString(), "Totals section is not allowed to be moved.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0135_REG0029()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Test Case Description";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                
                Reports.TestStep = "Create File.";
                CreateFile_WS();

                Reports.TestStep = "Adding REB commission charge for buyer seller and other.";
                #region step actions
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.FindGAB("3");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("20000");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual("Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 35));
                string BuyerREBrokerName = FastDriver.RealEstateBrokerAgent.BrokerName1.FAGetText().ToString().Clean();
                FastDriver.BottomFrame.Done();

                FastDriver.BottomFrame.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.FindGAB("274");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("10000");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual("Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 35));
                string SellerREBrokerName = FastDriver.RealEstateBrokerAgent.BrokerName1.FAGetText().ToString().Clean();
                FastDriver.BottomFrame.Done();

                FastDriver.BottomFrame.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("508");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("10000");
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual("Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 35));
                string OtherREBrokerName = FastDriver.RealEstateBrokerAgent.BrokerName1.FAGetText().ToString().Clean();
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Navigate to the View Settlement Stmt screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.TestStep = "Verify the charge instances can be moved inside the Comission section only";
                                
                var CommissionIns1Pos = FastDriver.NCSViewSettlementStatement.NewCommissionsTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']//b[contains(text(),'" + BuyerREBrokerName + "')]").FAGetLocation().Y.ToString();

                FastDriver.NCSViewSettlementStatement.NewCommissionsTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']//b[contains(text(),'" + BuyerREBrokerName + "')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.NewCommissionsTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']//b[contains(text(),'" + OtherREBrokerName + "')]"));

                Support.AreNotEqual(CommissionIns1Pos, FastDriver.NCSViewSettlementStatement.NewCommissionsTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']//b[contains(text(),'" + BuyerREBrokerName + "')]").FAGetLocation().Y.ToString(), "Verifying Buyer instance is moved.");
                
                var CommissionIns2Pos = FastDriver.NCSViewSettlementStatement.NewCommissionsTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']//b[contains(text(),'" + OtherREBrokerName + "')]").FAGetLocation().Y.ToString();

                FastDriver.NCSViewSettlementStatement.NewCommissionsTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']//b[contains(text(),'" + OtherREBrokerName + "')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.NewCommissionsTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']//b[contains(text(),'" + SellerREBrokerName + "')]"));

                Support.AreNotEqual(CommissionIns2Pos, FastDriver.NCSViewSettlementStatement.NewCommissionsTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']//b[contains(text(),'" + OtherREBrokerName + "')]").FAGetLocation().Y.ToString(), "Verifying Buyer instance is moved.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region r06.2016
        [TestMethod, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
        /// <summary>
        /// FMUC0135_REG0018 - This Test method covers the US 723626 from r06
        /// FMUC0135_REG0031 - This Test method covers the US 609000 from r06
        /// </summary>
        /// <param name="admLogin"></param>
        public void FMUC0135_REG0018()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion
                Reports.TestDescription = "#US 723626 for Re-sequence charges within the instances in Commission Section - UI.";
                Reports.TestStep = "Logging into automation region/office using automation credentials";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #region Setting up an escrow order and required test data for all the USs that are going to cover
                Reports.TestStep = "Create File with Commercial business segment";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("800");
                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }
                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.BottomFrame.Done();
                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion
                #region Create REB Instances
                Reports.TestStep = "Navigate to Real Estate Broker/Agent screen and create an instance of Seller's Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                Playback.Wait(3000);
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("1000000" + Keys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("2000000" + Keys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("POC Seller Credit" + Keys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("3000000" + Keys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText("4000000" + Keys.Tab);

                Reports.TestStep = "Navigate to Real Estate Broker/Agent screen and create an instance of Buyer's Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                //FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                //FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("2000000" + Keys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("2700000" + Keys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("POC Buyer Credit" + Keys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("3400000" + Keys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText("1000000" + Keys.Tab);
                #endregion
                #region To verify the re-sequencing of Charges within  instances in commission section and save View SS via Done button
                Reports.TestStep = "To verify the re-sequencing of Charges within  instances in commission section and save View SS via Done button";//TC771814
                Reports.TestStep = "Navigate to View Settlement Stmt. screen.";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.GoToButtonHover();
                FastDriver.NCSViewSettlementStatement.GoToComissions.FAClick();
                string instanceYLocation1 = FastDriver.NCSViewSettlementStatement.Firstinstance.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'POC Buyer Credit ')]").FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Firstinstance.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'POC Buyer Credit ')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.Firstinstance.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Real Estate Commission ')]"));
                Support.AreNotEqual(instanceYLocation1, FastDriver.NCSViewSettlementStatement.Firstinstance.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'POC Buyer Credit ')]").FAGetLocation().Y.ToString(), "Verify charge is resequenced or not");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                #endregion
                #region To verify the re-sequencing of charges within instances restricted from moving ouside of that instance in Commision section
                Reports.TestStep = "To verify the re-sequencing of charges within instances restricted from moving ouside of that instance in Commision section.";//TC772334
                Reports.TestStep = "Navigate to View Settlement Stmt. screen.";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.GoToButtonHover();
                FastDriver.NCSViewSettlementStatement.GoToComissions.FAClick();
                string instanceYLocation2 = FastDriver.NCSViewSettlementStatement.Secondinstance.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'POC Seller Credit ')]").FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Secondinstance.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'POC Seller Credit ')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.Firstinstance.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Real Estate Commission ')]"));
                Support.AreNotEqual(instanceYLocation2, FastDriver.NCSViewSettlementStatement.Secondinstance.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'POC Seller Credit ')]").FAGetLocation().Y.ToString(), "Verify charge is resequenced or not");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.WaitCreation(FastDriver.BottomFrame.btnDone);
                FastDriver.BottomFrame.SwitchToContentFrame();
                Playback.Wait(10000);
                #endregion
                #region Add new charges after re-sequencing the charges within instances in commision section
                Reports.TestStep = "Add new charges after re-sequencing the charges within instances in commision section.";//TC772356
                Reports.TestStep = "Navigate to Real Estate Broker/Agent screen and create an instance of Seller's Broker and Add new charge to the Seller Instance.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBrokerXpath.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText("2nd POC" + Keys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("3700000" + Keys.Tab);
                Reports.TestStep = "Navigate to View Settlement Stmt. screen.";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.GoToButtonHover();
                FastDriver.NCSViewSettlementStatement.GoToComissions.FAClick();
                Support.AreEqual("2nd POC POC $37,000,000.00", FastDriver.NCSViewSettlementStatement.Secondinstance.PerformTableAction(4, 4, TableAction.GetText).Message);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test case US_723626_NCS failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0135_REG0026()
        {
            try
            {
                Reports.TestDescription = "US_609015:To verify the re-sequencing of charges within instances under Attorney(Buyer/Seller) section and verify in the delivered Settlement Statement.";

                #region LOGIN
                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion
                Reports.TestStep = "Login into the IIS Side.";
                Reports.TestStep = "Login FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create File.";
                CreateFile_WS();
                #endregion

                #region Navigate Buyer's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorney(BuyerCharge: "50.00", SellerCharge: "50.00", GabCode: "247");
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "First Instance Second cahrge A987", 453.00, null, null, null, 92.00);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "First Instance Third cahrge B876", null, null, 7654.00, null, 65.00);
                FastDriver.BottomFrame.Done();

                #endregion

                #region Create an Second Attorney Instance by Clicking on New-Buyer's Attorney.
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorney(BuyerCharge: "100.00", SellerCharge: "100.00", GabCode: "HUDBUYATT2");
                FastDriver.AttorneyDetail.ChargeDescription.FASetText("Modified Charge in Source");
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "2nd Instance Second cahrge T654", 433, null, 655.00, null, 87.00);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "2nd Instance Third cahrge 8u76", 6543.00, null, 7654.00, null, 76.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Create Instance in Attorney Seller Screen.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorney(BuyerCharge: "1121.00", SellerCharge: "1678.00", GabCode: "BOA");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Updated Charge Desc in Pdd");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "3rd Instance Second charge F652", 234.00, null, 876.00, null, 88.00);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "3rd Instance Third charge G543", 78.00, null, 87.00, null, 99.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to NCSViewSettlementStatement and resquence the Instance on Attorney section
                Reports.TestStep = "Navigate to NCSViewSettlementStatement and resquence the Instance on Attorney section";
                FastDriver.NCSViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.Attorney_1st_Instance.Highlight();
                Support.AreEqual("Attorney: Lenders Advantage A Division Of First American Title Ins.", FastDriver.NCSViewSettlementStatement.Attorney_1st_Instance.FAGetText().Trim(), "Validation before swapping");
                string LInst1 = FastDriver.NCSViewSettlementStatement.Attorney_1st_Instance.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Attorney_3rd_Instance.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Attorney_1st_Instance);
                string Linst3 = FastDriver.NCSViewSettlementStatement.Attorney_3rd_Instance.FAGetLocation().Y.ToString();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreNotEqual(LInst1, FastDriver.NCSViewSettlementStatement.Attorney_1st_Instance.FAGetLocation().Y.ToString(), "Validation After navigating to Some other page");
                FastDriver.NCSViewSettlementStatement.Attorney_3rd_Instance.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Commission);
                Playback.Wait(1000);
                Support.AreEqual(Linst3, FastDriver.NCSViewSettlementStatement.Attorney_3rd_Instance.FAGetLocation().Y.ToString(), "Validation After moving Out from Instance");

                #endregion

                #region Navigate to NCSViewSettlementStatement and verify the re-sequencing of charges within instances under Attorney(Buyer/Seller) section
                Reports.TestStep = "Navigate to NCSViewSettlementStatement and verify the re-sequencing of charges within instances under Attorney(Buyer/Seller) section";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.Attorney_2nd_INS_1st_cahrge.Highlight();
                Support.AreEqual("Modified Charge in Source", FastDriver.NCSViewSettlementStatement.Attorney_2nd_INS_1st_cahrge.FAGetText().Trim(), "Validation before swapping");
                string BBB = FastDriver.NCSViewSettlementStatement.Attorney_2nd_INS_1st_cahrge.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Attorney_2nd_INS_3rd_cahrge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Attorney_2nd_INS_1st_cahrge);
                Support.AreNotEqual(BBB, FastDriver.NCSViewSettlementStatement.Attorney_2nd_INS_1st_cahrge.FAGetLocation().Y.ToString(), "Validation After swapping");
                FastDriver.BottomFrame.Reset();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreEqual(BBB, FastDriver.NCSViewSettlementStatement.Attorney_2nd_INS_1st_cahrge.FAGetLocation().Y.ToString(), "Validation After Reset Button");
                string CCC = FastDriver.NCSViewSettlementStatement.Attorney_2nd_INS_3rd_cahrge.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Attorney_2nd_INS_3rd_cahrge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Attorney_2nd_INS_1st_cahrge);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreNotEqual(CCC, FastDriver.NCSViewSettlementStatement.Attorney_2nd_INS_3rd_cahrge.FAGetLocation().Y.ToString(), "Validation After swapping");
                #endregion

                #region Create an Fourth Attorney Instance by Clicking on New-Seller's Attorney.
                Reports.TestStep = "Create an Fourth Attorney Instance by Clicking on New-Buyer's Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                CreateAttorney(BuyerCharge: "1311.00", SellerCharge: "1588.00", GabCode: "211");
                FastDriver.AttorneyDetail.ChargeDescription.FASetText("Added New charge for New Instance");
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "4th Instance Second charge H345", 234.00, null, 876.00, null, 88.00);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "4th Instance Third charge K876", 328777865.00, null, 324543265.29, null, 99.00);
                FastDriver.BottomFrame.Done();

                #endregion

                #region Validating Already resqenced Items
                Reports.TestStep = "Navigate to NCSViewSettlementStatement and verify the re-sequencing of charges/instances after inserting charge/Instances under Attorney(Buyer/Seller) Screen";
                FastDriver.NCSViewSettlementStatement.Open().WaitForScreenToLoad();//System should display the NCS View Settlement Statement screen with defaults
                Playback.Wait(3000);
                Support.AreEqual("Attorney: New Century Mortgage", FastDriver.NCSViewSettlementStatement.Attorney_4th_Instance.FAGetText().Trim(), "Validation After Adding Instance");
                Support.AreEqual("Added New charge for New Instance", FastDriver.NCSViewSettlementStatement.Attorney_4th_INS_1st_cahrge.FAGetText().Trim(), "Validation After Adding Charge1");
                Support.AreEqual("4th Instance Second charge H345", FastDriver.NCSViewSettlementStatement.Attorney_4th_INS_2nd_cahrge.FAGetText().Trim(), "Validation After Adding Charge2");
                Support.AreEqual("4th Instance Third charge K876", FastDriver.NCSViewSettlementStatement.Attorney_4th_INS_3rd_cahrge.FAGetText().Trim(), "Validation After Adding Charge3");
                Support.AreNotEqual(LInst1, FastDriver.NCSViewSettlementStatement.Attorney_1st_Instance.FAGetLocation().Y.ToString(), "Validation After Adding in Instances");
                Support.AreEqual(Linst3, FastDriver.NCSViewSettlementStatement.Attorney_3rd_Instance.FAGetLocation().Y.ToString(), "Validation After moving Out from Instance");
                Support.AreNotEqual(BBB, FastDriver.NCSViewSettlementStatement.Attorney_2nd_INS_1st_cahrge.FAGetLocation().Y.ToString(), "Validation after Insteting charges in Attorney screen");
                Support.AreNotEqual(CCC, FastDriver.NCSViewSettlementStatement.Attorney_2nd_INS_3rd_cahrge.FAGetLocation().Y.ToString(), "Validation after Insteting charges in Attorney screen");
                #endregion


            }
            catch (Exception ex)
            {
                FailTest("Test case US_609015_NCS_779145 failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0135_REG0031()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Test Case Description";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File.";
                CreateFile_WS();

                Reports.TestStep = "Navigate to the Terms/Dates/Status screen";

                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad().SwitchToContentFrame();

                Reports.TestStep = "Click the Edit SP/OPL button to open the SP/OPL  dialog box.";

                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Add  2nd, 3rd,4th and 5th Sale price breakdowns.";
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText("100000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FASetText("200000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FourthSalePriceAmount.FASetText("300000");
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.FifthSalePriceAmount.FASetText("400000");
                
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 30));

                Support.AreEqual("Sale Price has changed. Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.HandleDialogMessage(timeout: 30).ToString().Clean(), true);

                FastDriver.DialogBottomFrame.SwitchToContentFrame();


                Reports.TestStep = "Navigate to the View Settlement Stmt screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.TestStep = "Verifying the restriction of moving the charges of the Consideration section.";
                var Consideration1Pos = FastDriver.NCSViewSettlementStatement.Consideration1stSaleP.FAGetLocation().Y.ToString();

                FastDriver.NCSViewSettlementStatement.Consideration1stSaleP.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Consideration4thSaleP);

                Support.AreEqual(Consideration1Pos, FastDriver.NCSViewSettlementStatement.Consideration1stSaleP.FAGetLocation().Y.ToString(), "Restriction of moving the Consideration charges confirmed");

                var Consideration2Pos = FastDriver.NCSViewSettlementStatement.Consideration2ndSaleP.FAGetLocation().Y.ToString();

                FastDriver.NCSViewSettlementStatement.Consideration2ndSaleP.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Consideration5thSaleP);

                Support.AreEqual(Consideration2Pos, FastDriver.NCSViewSettlementStatement.Consideration2ndSaleP.FAGetLocation().Y.ToString(), "Restriction of moving the Consideration charges confirmed");


                //your test case code here
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region r07.2016
        /// <summary>
        /// FMUC0135_REG0006 - This test method covers few resequencing user stories 608120, 609004, 609006, 608996 and 609020
        /// FMUC0135_REG0007 - This test method covers few resequencing user stories 756824 and 757381
        /// FMUC0135_REG0015 - This test method covers few resequencing user stories 756821 and 702669
        /// FMUC0135_REG0016 - This test method covers few resequencing user story 609023
        /// FMUC0135_REG0039 - This test method covers user story 756823    
        /// FMUC0135_REG0040  - This test method covers user story 757384
        /// FMUC0135_REG0041  - This test method covers user story 609019 and 794316
        /// </summary>
        [TestMethod]
        public void FMUC0135_REG0006()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion
                Reports.TestDescription = "US# 608120, 609004, 609006, 608996 and 609020 Resequence functionality for Deposits in escrow, Earnest Money, Adjustments, Proration and Funds Held sections";
                Reports.TestStep = "Logging into automation region/office using automation credentials";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #region Setting up an escrow order and required test data for all the USs that are going to cover
                Reports.TestStep = "Create File with Commercial business segment";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("800");
                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }
                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.BottomFrame.Done();
                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                Reports.TestStep = "Perform multiple cash deposits";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 1000,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Comments = "Comments Before Save",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 15);
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                DepositParameters depositDetail1 = new DepositParameters()
                {
                    Amount = 1000,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Seller",
                    Comments = "Comments Before Save",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail1);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 15);
                Reports.TestStep = "Test data, REB for Earnest Money";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.FindGAB("246");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                DepositOutsideEscrowParameters doe = new DepositOutsideEscrowParameters()
                {
                    TotalDeposit = 400,
                    EarnerstMoneyHeldBy_0 = "Seller's Broker",
                    EarnerstMoneyAmount_0 = 100,
                    EarnerstMoneyHeldBy_1 = "Buyer's Broker",
                    EarnerstMoneyAmount_1 = 300,
                };
                FastDriver.DepositOutsideEscrow.Deposit(doe);
                FastDriver.BottomFrame.Save();
                Reports.TestStep = "Test data, Adjustments";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.AssignTenantSecurityLeaseRent_BuyerCharge.FASetText("100.03");
                FastDriver.AdjustmentOffset.BuyerCredit1.FASetText("50.93");
                FastDriver.AdjustmentOffset.SellerCharge1.FASetText("200.98");
                FastDriver.AdjustmentOffset.SellerCredit1.FASetText("5.66");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.description3.FASetText("Alphanumeric and special char ABCabc123!@#");
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(2000);
                FastDriver.AdjustmentMisc.BuyerCharge3.FASetText("1000");
                FastDriver.AdjustmentMisc.BuyerCredit3.FASetText("200");
                FastDriver.AdjustmentMisc.SellerCharge3.FASetText("2000.02");
                FastDriver.AdjustmentMisc.SellerCredit3.FASetText("0.01");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Test data, Prorations";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.New.FAClick();
                Playback.Wait(2000);
                FastDriver.ProrationTax.Amount.FASetText("1000");
                FastDriver.ProrationTax.Desc.FASetText("Proration tax and special char ABCabc123!@#");
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(2000);
                FastDriver.ProrationTax.bc.FASetText("50");
                FastDriver.ProrationTax.sc.FASetText("50");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<ProrationRent>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad();
                FastDriver.ProrationTax.New.FAClick();
                Playback.Wait(2000);
                FastDriver.ProrationTax.Amount.FASetText("1000");
                FastDriver.ProrationTax.Desc.FASetText("Proration rent and special char ABCabc123!@#");
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(2000);
                FastDriver.ProrationTax.bc.FASetText("50");
                FastDriver.ProrationTax.sc.FASetText("50");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Test data, Funds held";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For First Hold Fund Instance.");
                FastDriver.HoldFunds.SellerCharge.FASetText("100");
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(2000);
                FastDriver.ProrationTax.New.FAClick();
                Playback.Wait(2000);
                FastDriver.HoldFunds.FindGABCode();
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.96");
                FastDriver.BottomFrame.New();
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Test Buyer Fund");
                FastDriver.HoldFunds.RadbtnBuyer.FASetCheckbox(true);
                FastDriver.HoldFunds.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.FindGABCode("248");
                FastDriver.HoldFunds.HoldFundBuyerCharge1.FASetText("11.11");
                FastDriver.BottomFrame.Done();
                #endregion
                Reports.TestStep = "Performing resequencing on VSS";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.ViewSettlementStatement.MarkSelectAllCheckBox();
                string a = FastDriver.NCSViewSettlementStatement.AdjustmentsTable.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Alphanumeric and special char ABCabc123!@#')]").FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.AdjustmentsTable.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Alphanumeric and special char ABCabc123!@#')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.AdjustmentsTable.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Assign Tenant Lease/Rent')]"));
                Support.AreNotEqual(a, FastDriver.NCSViewSettlementStatement.AdjustmentsTable.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Alphanumeric and special char ABCabc123!@#')]").FAGetLocation().Y.ToString());
                string b = FastDriver.NCSViewSettlementStatement.ProrationsTable.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Proration rent and special char ABCabc123!@# @$1,000.00/mo')]").FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.ProrationsTable.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Proration rent and special char ABCabc123!@# @$1,000.00/mo')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.ProrationsTable.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Proration tax and special char ABCabc123!@# @$1,000.00/yr')]"));
                Support.AreNotEqual(b, FastDriver.NCSViewSettlementStatement.ProrationsTable.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Proration rent and special char ABCabc123!@# @$1,000.00/mo')]").FAGetLocation().Y.ToString());
                FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.FASendKeys(""); // Bring element into view
                FastDriver.NCSViewSettlementStatement.DragAndDropRowOnTableUsingRowIndex(FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable, fromRowIndex: 5, toRowIndex: 4, offsetY: 15);
                FastDriver.NCSViewSettlementStatement.EMTable.FASendKeys(""); // Bring element into view
                FastDriver.NCSViewSettlementStatement.DragAndDropRowOnTableUsingRowIndex(FastDriver.NCSViewSettlementStatement.EMTable, fromRowIndex: 7, toRowIndex: 4, offsetY: 15);
                FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.FASendKeys(""); // Bring element into view
                FastDriver.NCSViewSettlementStatement.DragAndDropRowOnTableUsingRowIndex(FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID, fromRowIndex: 7, toRowIndex: 4, offsetY: 15);
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.WaitCreation(FastDriver.BottomFrame.btnDone);
                FastDriver.BottomFrame.SwitchToContentFrame();
                Playback.Wait(10000);
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(4, 4, TableAction.GetText).Message.Equals("Ad Hoc Entry to Midwest Financial Group B: 11.11").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.EMTable.PerformTableAction(4, 4, TableAction.GetText).Message.Equals("Earnest Money Held By: Chase Manhattan Mortgage Corporation").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.ProrationsTable.PerformTableAction(3, 4, TableAction.GetText).Message.Equals("Proration rent and special char ABCabc123!@# @$1,000.00/mo").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.AdjustmentsTable.PerformTableAction(3, 4, TableAction.GetText).Message.Equals("Alphanumeric and special char ABCabc123!@#").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(4, 4, TableAction.GetText).Message.Contains("on " + DateTime.Today.ToString("MM/dd/yyyy") + " by SellerNa1 SellerLa1").ToString());
                Reports.TestStep = "Resequencing all rows in DIE section, any new deposits coming in should always sit at bottom";
                FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.FASendKeys(""); // Bring element into view
                FastDriver.NCSViewSettlementStatement.DragAndDropRowOnTableUsingRowIndex(FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable, fromRowIndex: 5, toRowIndex: 4, offsetY: 15);
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.WaitCreation(FastDriver.BottomFrame.btnDone);
                FastDriver.BottomFrame.SwitchToContentFrame();
                Playback.Wait(10000);
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                DepositParameters depositDetail2 = new DepositParameters()
                {
                    Amount = 1000000000.76,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Seller",
                    Comments = "Comments Before Save",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail2);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 15);
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(6, 4, TableAction.GetText).Message.Contains("S: (1,000,000,000.76)").ToString());
            }
            catch (Exception ex)
            { FailTest(ex.Message); }
        }
        [TestMethod]
        public void FMUC0135_REG0007()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion
                Reports.TestDescription = "US# 756824 and 757381 Re-sequence charges in Outside Escrow Charges subsection of Disbursement section - UI/Delivery Re-sequence charges in Property Tax Check subsection of Disbursement section - UI/Delivery";
                Reports.TestStep = "Logging into automation region/office using automation credentials";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #region Setting up an escrow order and required test data for all the USs that are going to cover
                Reports.TestStep = "Create refinance File with Commercial business segment";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("800");
                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }
                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Refinance");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.BottomFrame.Done();
                FastDriver.QuickFileEntry.SwitchToTopFrame();
                Reports.TestStep = "Test data, Property Tax Check";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("246");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_2.FASetText("100.65");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_2.FASetText("200");
                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("0.01");
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_3.FASetText("1000");
                FastDriver.PropertyTaxCheck.buyerCredit2.FASetText("2000.34");
                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge1.FASetText("76.97");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Test data, Outside Escrow Company";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad().FileaddressBookResultsRadio.FAClick();
                FastDriver.DialogBottomFrame.ClickDone().SwitchToContentFrame();
                //FastDriver.OutsideEscrowCompanyDetail.FindGAB("boa");
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("1st instance 1st charge Ab09!@#" + FAKeys.Tab);
                Playback.Wait(3000);
                Keyboard.SendKeys("{TAB}{TAB}{TAB}");
                Playback.Wait(3000);
                Keyboard.SendKeys("{TAB}{TAB}{TAB}");
                Playback.Wait(3000);
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription2.FASetText("1st instance 2nd charge Ab09!@#" + FAKeys.Tab);
                Playback.Wait(3000);
                Keyboard.SendKeys("{TAB}{TAB}{TAB}");
                Playback.Wait(3000);
                Keyboard.SendKeys("{TAB}{TAB}{TAB}");
                Playback.Wait(3000);
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FASetText("23.45" + FAKeys.Tab);
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge2.FASetText("119.19" + FAKeys.Tab);
                //Keyboard.SendKeys("{TAB}23.45{TAB}{TAB}");
                //Keyboard.SendKeys("{TAB}119.19{TAB}{TAB}");
                FastDriver.BottomFrame.New();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("420");
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("2nd instance 1st charge Ab09!@#" + FAKeys.Tab);
                Playback.Wait(3000);
                Keyboard.SendKeys("{TAB}{TAB}{TAB}");
                Playback.Wait(3000);
                Keyboard.SendKeys("{TAB}{TAB}{TAB}");
                Playback.Wait(3000);
                //Keyboard.SendKeys("{TAB}1000000.65{TAB}{TAB}");
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription2.FASetText("2nd instance 2nd charge Ab09!@#" + FAKeys.Tab);
                Playback.Wait(3000);
                Keyboard.SendKeys("{TAB}{TAB}{TAB}");
                Playback.Wait(3000);
                Keyboard.SendKeys("{TAB}{TAB}{TAB}");
                Playback.Wait(3000);
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FASetText("1000000.65" + FAKeys.Tab);
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge2.FASetText("0.09" + FAKeys.Tab);
                //Keyboard.SendKeys("{TAB}0.09{TAB}{TAB}");
                FastDriver.BottomFrame.Done();
                #endregion
                Reports.TestStep = "Performing resequencing on VSS";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.ViewSettlementStatement.MarkSelectAllCheckBox();
                string a = FastDriver.NCSViewSettlementStatement.PropertySubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'County Tax ')]").FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.PropertySubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'County Tax ')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.PropertySubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'Tax Installment: Interest Due ')]"));
                Support.AreNotEqual(a, FastDriver.NCSViewSettlementStatement.PropertySubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'County Tax ')]").FAGetLocation().Y.ToString());
                string b = FastDriver.NCSViewSettlementStatement.OutsideSubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'2nd instance 2nd charge Ab09!@# ')]").FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.OutsideSubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'2nd instance 2nd charge Ab09!@# ')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.OutsideSubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'1st instance 1st charge Ab09!@# ')]"));
                Support.AreNotEqual(b, FastDriver.NCSViewSettlementStatement.OutsideSubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'2nd instance 2nd charge Ab09!@# ')]").FAGetLocation().Y.ToString());
                Playback.Wait(3000);
                Reports.TestStep = "Testing reset button functionality";
                FastDriver.BottomFrame.Reset();
                //Playback.Wait(9000);
                FastDriver.ViewSettlementStatement.WaitForScreenToLoad();
                //string a = FastDriver.ViewSettlementStatement.SelectAll_SubtotalsCheckbox.IsSelected().ToString();
                Support.AreEqual("False", FastDriver.ViewSettlementStatement.SelectAll_SubtotalsCheckbox.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.PropertySubsection1.PerformTableAction(2, 4, TableAction.GetText).Message.Equals("Tax Installment: Interest Due to Chase Manhattan Mortgage Corporation").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.OutsideSubsection1.PerformTableAction(2, 4, TableAction.GetText).Message.Equals("1st instance 1st charge Ab09!@# to BuyerNa1 BuyerLa1").ToString());
                FastDriver.ViewSettlementStatement.MarkSelectAllCheckBox();
                string c = FastDriver.NCSViewSettlementStatement.PropertySubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'County Tax ')]").FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.PropertySubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'County Tax ')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.PropertySubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'Tax Installment: Interest Due ')]"));
                Support.AreNotEqual(c, FastDriver.NCSViewSettlementStatement.PropertySubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'County Tax ')]").FAGetLocation().Y.ToString());
                string d = FastDriver.NCSViewSettlementStatement.OutsideSubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'2nd instance 2nd charge Ab09!@# ')]").FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.OutsideSubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'2nd instance 2nd charge Ab09!@# ')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.OutsideSubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'1st instance 1st charge Ab09!@# ')]"));
                Support.AreNotEqual(d, FastDriver.NCSViewSettlementStatement.OutsideSubsection1.FAFindElement(ByLocator.XPath, "//span[@class='subTotalDescrStyle']/span[contains(text(),'2nd instance 2nd charge Ab09!@# ')]").FAGetLocation().Y.ToString());
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.WaitCreation(FastDriver.BottomFrame.btnDone);
                FastDriver.BottomFrame.SwitchToContentFrame();
                Reports.TestStep = "Validating whether resequencing really happened or not on VSS";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.PropertySubsection1.PerformTableAction(2, 4, TableAction.GetText).Message.Equals("Total Property Tax Check").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.OutsideSubsection1.PerformTableAction(2, 4, TableAction.GetText).Message.Equals("Total Outside Escrow").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.PropertySubsection1.PerformTableAction(3, 4, TableAction.GetText).Message.Equals("County Tax to Lenders Advantage A Division Of First American Title Ins. B: 76.97").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.OutsideSubsection1.PerformTableAction(3, 4, TableAction.GetText).Message.Equals("2nd instance 2nd charge Ab09!@# to The Northern Trust Company B: 0.09").ToString());
                /*FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.FASendKeys(""); // Bring element into view
                FastDriver.NCSViewSettlementStatement.DragAndDropRowOnTableUsingRowIndex(FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable, fromRowIndex: 5, toRowIndex: 4, offsetY: 15);
                FastDriver.NCSViewSettlementStatement.EMTable.FASendKeys(""); // Bring element into view
                FastDriver.NCSViewSettlementStatement.DragAndDropRowOnTableUsingRowIndex(FastDriver.NCSViewSettlementStatement.EMTable, fromRowIndex: 7, toRowIndex: 4, offsetY: 15);
                FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.FASendKeys(""); // Bring element into view
                FastDriver.NCSViewSettlementStatement.DragAndDropRowOnTableUsingRowIndex(FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID, fromRowIndex: 7, toRowIndex: 4, offsetY: 15);
                Playback.Wait(6000);
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(4, 3, TableAction.GetText).Message.Equals("Ad Hoc Entry to Midwest Financial Group B: 11.11").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.EMTable.PerformTableAction(4, 3, TableAction.GetText).Message.Equals("Earnest Money Held By: Chase Manhattan Mortgage Corporation").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.ProrationsTable.PerformTableAction(3, 3, TableAction.GetText).Message.Equals("Proration rent and special char ABCabc123!@# @$1,000.00/mo").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.AdjustmentsTable.PerformTableAction(3, 3, TableAction.GetText).Message.Equals("Alphanumeric and special char ABCabc123!@#").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(4, 3, TableAction.GetText).Message.Contains("on " + DateTime.Today.ToString("MM/dd/yyyy") + " by SellerNa1 SellerLa1").ToString());
                FastDriver.ViewSettlementStatement.MarkSelectAllCheckBox();
                Support.AreEqual("False", FastDriver.ViewSettlementStatement.Ptcveri.FAGetText().Equals("Tax Installment: Interest Due to Chase Manhattan Mortgage Corporation").ToString());
                Support.AreEqual("False", FastDriver.ViewSettlementStatement.Oeveri.FAGetText().Equals("1st instance 1st charge Ab09!@# to Bank of America").ToString());
                FastDriver.ViewSettlementStatement.Ptcfrom.FADragAndDropWithOffset(FastDriver.ViewSettlementStatement.Ptcto, offsetY: 20);
                FastDriver.ViewSettlementStatement.Oefrom.FADragAndDropWithOffset(FastDriver.ViewSettlementStatement.Oeto, offsetY: 20);
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.WaitCreation(FastDriver.BottomFrame.btnDone);
                FastDriver.BottomFrame.SwitchToContentFrame();
                Reports.TestStep = "Validating whether resequencing really happened or not on VSS";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ViewSettlementStatement.Ptcveri.FAGetText().Equals("Tax Installment: Interest Due to Chase Manhattan Mortgage Corporation").ToString());
                Support.AreEqual("True", FastDriver.ViewSettlementStatement.Oeveri.FAGetText().Equals("1st instance 1st charge Ab09!@# to Bank of America").ToString());*/
                Playback.Wait(6000);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Reports.TestStep = "Testing change in business segment functionality";
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Subdivision");
                FastDriver.BottomFrame.Done();
                Playback.Wait(6000);
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.");
                Playback.Wait(6000);
                //string a = FastDriver.WebDriver.FindElement(By.Id("btnPrintDeliver")).ToString();
                //Support.AreEqual("False", a, "Verify that the displayed SS is not related to 2824 project");
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.SelectAll_SubtotalsCheckbox.IsDisplayed().ToString(), "Verify that the displayed SS is not related to 2824 project");
                //Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.PrintDeliver.IsDisplayed().ToString(), "Verify that the displayed SS is not related to 2824 project");
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.btnExpandAll.IsDisplayed().ToString(), "Verify that the displayed SS is not related to 2824 project");
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.btnCollapseAll.IsDisplayed().ToString(), "Verify that the displayed SS is not related to 2824 project");
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Done();
                Playback.Wait(6000);
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.");
                Playback.Wait(6000);
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.SelectAll_SubtotalsCheckbox.IsDisplayed().ToString(), "Verify that the 2824 project SS is displayed");
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.PrintDeliver.IsDisplayed().ToString(), "Verify that the 2824 project SS is displayed");
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.btnExpandAll.IsDisplayed().ToString(), "Verify that the 2824 project SS is displayed");
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.btnCollapseAll.IsDisplayed().ToString(), "Verify that the 2824 project SS is displayed");
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.PropertySubsection1.PerformTableAction(2, 4, TableAction.GetText).Message.Equals("Total Property Tax Check").ToString());
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.PropertySubsection1.PerformTableAction(2, 4, TableAction.GetCell).Element.FAGetFontStyleProperties().IsBold, "Verify the Total Property Tax Check sub header row is displayed in bold followed by charges");//Weight of 700 indicates text is bold
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.OutsideSubsection1.PerformTableAction(2, 4, TableAction.GetText).Message.Equals("Total Outside Escrow").ToString());
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.OutsideSubsection1.PerformTableAction(2, 4, TableAction.GetCell).Element.FAGetFontStyleProperties().IsBold, "Verify the Total Outside Escrow sub header row is displayed in bold followed by charges");//Weight of 700 indicates text is bold
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.PropertySubsection1.PerformTableAction(3, 4, TableAction.GetText).Message.Equals("County Tax to Lenders Advantage A Division Of First American Title Ins. B: 76.97").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.OutsideSubsection1.PerformTableAction(3, 4, TableAction.GetText).Message.Equals("2nd instance 2nd charge Ab09!@# to The Northern Trust Company B: 0.09").ToString());
            }
            catch (Exception ex)
            { FailTest(ex.Message); }
        }
        [TestMethod]
        public void FMUC0135_REG0017()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion
                Reports.TestDescription = "#US 756821, 702669 Re-sequence charges in Inspection/Repair and Homeowner Association subsections of Disbursement section - UI/Delivery";
                Reports.TestStep = "Logging into automation region/office using automation credentials";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #region Setting up an escrow order and required test data for all the USs that are going to cover
                Reports.TestStep = "Create refinance File with Commercial business segment";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("800");
                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }
                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Refinance");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.BottomFrame.Done();
                FastDriver.QuickFileEntry.SwitchToTopFrame();

                //Test Data for UserStory 702669
                Reports.TestStep = "Test data, Homeowner Association.";
                Reports.TestStep = "Navigate to Homeowner Association and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("420");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FASetText("1400");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge1.FASetText("9500");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge2.FASetText("2000");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge3.FASetText("5000");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Home Warranty and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("246");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();

                // Test data for User Story 756821
                Reports.TestStep = "Test data, Inspection/Repair.";
                Reports.TestStep = "Navigate to Inspection Repair Pest screen and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.FindGAB("800");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("500" + Keys.Tab + Keys.Tab);
                FastDriver.InspectionRepairPest.buyerCharge1.FASetText("1000");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to Inspection Repair Septic and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").WaitForScreenToLoad();
                FastDriver.InspectionRepairSeptic.FindGAB("420");
                FastDriver.InspectionRepairSeptic.BuyerCharge.FASetText("500" + Keys.Tab + Keys.Tab);
                FastDriver.InspectionRepairSeptic.buyerCharge1.FASetText("1000");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to Inspection Repair Other and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.FindGAB("800");
                FastDriver.InspectionRepairOther.BuyerCharge.FASetText("500" + Keys.Tab + Keys.Tab);
                FastDriver.InspectionRepairOther.buyerCharge1.FASetText("1000");
                FastDriver.BottomFrame.Done();

                #endregion
                Reports.TestStep = "Performing resequencing on VSS";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.GoToButtonHover();
                FastDriver.NCSViewSettlementStatement.GoToDisbursementPaid.FAClick();
                string homeownerYLocation = FastDriver.NCSViewSettlementStatement.HomeownerSubsection.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Certification Letter ')]").FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.HomeownerSubsection.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Certification Letter ')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.HomeownerSubsection.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Association Dues ')]"));
                Support.AreNotEqual(homeownerYLocation, FastDriver.NCSViewSettlementStatement.HomeownerSubsection.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Certification Letter ')]").FAGetLocation().Y.ToString());
                string inspectionYLocation = FastDriver.NCSViewSettlementStatement.InspectionSubsection.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Septic Inspection ')]").FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.InspectionSubsection.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Septic Inspection ')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.InspectionSubsection.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Other Inspection ')]"));
                Support.AreNotEqual(inspectionYLocation, FastDriver.NCSViewSettlementStatement.InspectionSubsection.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Septic Inspection ')]").FAGetLocation().Y.ToString());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            { FailTest(ex.Message); }
        }
        [TestMethod]
        public void FMUC0135_REG0016()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "#US 609023 for Re-sequence subsections in 'Disbursement Paid' section - UI/Delivery";
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Through UI
                Reports.TestStep = "Create File with Commercial business type.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.BottomFrame.Done();

                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                #region Homeowner Association setup
                Reports.TestStep = "Navigate to Homeowner Association and add values to buyer and seller.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge1.FASetText("500");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge2.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge3.FASetText("5000");

                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FASetText("500");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge1.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge2.FASetText("500");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge3.FASetText("1000");

                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Warranty setup
                Reports.TestStep = "Navigate to Home Warranty and add values to buyer and seller.";

                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                FastDriver.HomeWarrantyDetail.FindGABCode("246");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("1000");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Inspection Repair setup
                Reports.TestStep = "Navigate to Inspection Repair Pest screen and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.FindGAB("800");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("500");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Inspection Repair Septic and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").WaitForScreenToLoad();
                FastDriver.InspectionRepairSeptic.FindGAB("247");
                FastDriver.InspectionRepairSeptic.BuyerCharge.FASetText("500");
                FastDriver.InspectionRepairSeptic.SellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Inspection Repair Other and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.FindGAB("246");
                FastDriver.InspectionRepairOther.BuyerCharge.FASetText("500");
                FastDriver.InspectionRepairOther.SellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region REB values setup
                Reports.TestStep = "Add REB commission charge for both buyer and seller.";
                #region step actions
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.FindGAB("800");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FASetText("20000");
                Keyboard.SendKeys("{TAB}");
                //Support.AreEqual("Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 35));
                string BuyerREBrokerName = FastDriver.RealEstateBrokerAgent.BrokerName1.FAGetText().ToString().Clean();

                FastDriver.BottomFrame.Done();

                FastDriver.BottomFrame.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.FindGAB("246");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FASetText("10000");
                Keyboard.SendKeys("{TAB}");
                //Support.AreEqual("Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 35));
                string SellerREBrokerName = FastDriver.RealEstateBrokerAgent.BrokerName1.FAGetText().ToString().Clean();
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                #region Insurance setup
                Reports.TestStep = "Navigate to the Insurance screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FindGAB("420");
                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("1000");
                FastDriver.InsuranceFire.FireSellerCharge.FASetText("500");
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad().Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.FindGAB("boa");
                FastDriver.Insuranceflood.FloodBuyercharge.FASetText("500");
                FastDriver.Insuranceflood.FloodSellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad().Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.FindGAB("420");
                FastDriver.InsuranceWind.WindBuyerCharge.FASetText("500");
                FastDriver.InsuranceWind.WindSellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad().EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.FindGAB("246");
                FastDriver.InsuranceEarth.EarthBuyerCharge.FASetText("1000");
                FastDriver.InsuranceEarth.EarthSellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Lease setup
                Reports.TestStep = "Navigate to the Lease screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("420");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("300");
                FastDriver.LeaseDetail.SellerCharge.FASetText("300");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Miscellaneous Disbursement setup
                Reports.TestStep = "Navigate to the Miscellaneous Disbursement screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("boa");
                FastDriver.MiscDisbursementDetail.Description.FASetText("Added value" + Keys.Tab);
                FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText("10000");
                FastDriver.MiscDisbursementDetail.SellerCharge.FASetText("15000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey setup
                Reports.TestStep = "Navigate to the Survey screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("800");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("300000");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("200000");
                FastDriver.BottomFrame.New();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("500000");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.13");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Utility setup
                Reports.TestStep = "Navigate to the Utility screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("boa");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("1000");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText("1300");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Outside Escrow Company setup
                Reports.TestStep = "Navigate to the Outside Escrow Company screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("246");
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("Outside Charges" + Keys.Tab);
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FASetText("1000");
                FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FASetText("1300");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Tax Check setup
                Reports.TestStep = "Navigate to the Property Tax Check screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("420");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("300");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_3.FASetText("200");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_5.FASetText("100");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_2.FASetText("250");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_4.FASetText("250");
                FastDriver.BottomFrame.New();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("100");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("100");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_2.FASetText("700.01");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_2.FASetText("600.36");
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestDescription = "Re-sequencing the subsections of Disbursement Paid section in View Settlement statement.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Reports.TestStep = "Navigate to View Settlement Statement.";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Reports.TestStep = "Perform re-sequencing of subsections in Disbursement paid section.";
                string a = FastDriver.NCSViewSettlementStatement.From_InspectionRepair.FAGetLocation().Y.ToString();
                string b = FastDriver.NCSViewSettlementStatement.From_Utility.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.From_InspectionRepair.FADragAndDropWithOffset(FastDriver.NCSViewSettlementStatement.To_MiscellaneousDisbursement, offsetY: 20);
                FastDriver.NCSViewSettlementStatement.From_Utility.FADragAndDropWithOffset(FastDriver.NCSViewSettlementStatement.To_OutsideEscrow, offsetY: 20);
                Support.AreNotEqual(a, FastDriver.NCSViewSettlementStatement.From_InspectionRepair.FAGetLocation().Y.ToString(), "Verify the reqequenced subsection");
                Support.AreNotEqual(b, FastDriver.NCSViewSettlementStatement.From_Utility.FAGetLocation().Y.ToString(), "Verify the reqequenced subsection");
                //FastDriver.ViewSettlementStatement.Inspection_Repair.FADragAndDrop(FastDriver.ViewSettlementStatement.HomeownerAssociation);
                //FastDriver.ViewSettlementStatement.OutsideEscrow.FADragAndDrop(FastDriver.ViewSettlementStatement.Utility);
                //FastDriver.ViewSettlementStatement.MiscellaneousDisbursement.FADragAndDrop(FastDriver.ViewSettlementStatement.HomeWarranty);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                throw;
            }
        }
        [TestMethod]
        public void FMUC0135_REG0032()
        {
            try
            {
                Reports.TestDescription = "US#757383:Verify Re-sequencing Charges in Survey section under 'Disbursement Paid' section UI/Delivery.";

                #region LOGIN
                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion
                Reports.TestStep = "Login into the IIS Side.";
                Reports.TestStep = "Login FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion
                #region Create A Basic file order.
                Reports.TestStep = "Create File.";
                CreateFile_WS();
                #endregion

                #region Navigate Survey and Create Instance.
                Reports.TestStep = "Navigate to the Survey screen and add values for buyer and seller charges.";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.FindGABCode("HUDSURVEY1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("11.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("12.00");
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, "1st Instance Second cahrge G876", 544.00, null, 453.00, null, 92.00);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, "1st Instance Third cahrge H654", 765432187.00, null, 123456789.22, null, 65.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to ViewSettlementStatement and resquence the orders
                Reports.TestStep = "Navigate to ViewSettlementStatement and resquence the orders";
                FastDriver.ViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_1stCharge.Highlight();
                string Disc1 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_2ndCharge.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_3rdCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_2ndCharge);
                string Disc3 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_1stCharge.FAGetLocation().Y.ToString();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreNotEqual(Disc1, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_2ndCharge.FAGetLocation().Y.ToString(), "Validation After navigating to Some other page");
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_1stCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Commission);
                Playback.Wait(1000);
                Support.AreEqual(Disc3, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_1stCharge.FAGetLocation().Y.ToString(), "Validation After moving Out from Instance");
                #endregion

                #region Navigate Survey and Create Second Instance.
                Reports.TestStep = "Create Second instance in Survey Screen.";
                FastDriver.SurveyDetail.Open();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("HUDSURVEY2");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Modified Description in Survey screen");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("231546789.33");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("432123654.22");
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, "2nd Instance Second cahrge Y654", 433, null, 655.00, null, 87.00);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, "2nd Instance Third cahrge U432", 6543.00, null, 7654.00, null, 76.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to ViewSettlementStatement Screen and Validate resequenced Charges
                Reports.TestStep = "Navigate to ViewSettlementStatement and Validate the orders";
                FastDriver.ViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults

                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_5thCharge.Highlight();
                Support.AreNotEqual(Disc1, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_2ndCharge.FAGetLocation().Y.ToString(), "Validation After Inserting New Instance");
                Support.AreEqual(Disc3, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_1stCharge.FAGetLocation().Y.ToString(), "Validation After Inserting New Instance");
                string Disc2 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_5thCharge.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_5thCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_2ndCharge);
                Support.AreNotEqual(Disc2, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_5thCharge.FAGetLocation().Y.ToString(), "Validation Before Clicking on Reset Button");
                FastDriver.BottomFrame.Reset();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(3000);
                Support.AreEqual(Disc2, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_FirstInstance_5thCharge.FAGetLocation().Y.ToString(), "Validation After Clicking on Reset Button");
                #endregion


            }
            catch (Exception ex)
            {
                FailTest("Test case US_757383_NCS_805159 failed because " + ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0135_REG0033()
        {
            try
            {
                Reports.TestDescription = "US#757382:Verify Re-sequencing Charges in Lease section under 'Disbursement Paid' section UI/Delivery.";

                #region LOGIN
                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion
                Reports.TestStep = "Login into the IIS Side.";
                Reports.TestStep = "Login FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create File.";
                CreateFile_WS();
                #endregion

                #region Navigate Lease and Create Instance.
                Reports.TestStep = "Navigate to the Lease screen and add values for buyer and seller charges.";
                FastDriver.LeaseDetail.Open();
                Playback.Wait(3000);
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE01");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("132456721.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("432156788.54");
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, "1st Instance Second charge Z333", 544.00, null, 453.00, null, 92.00);
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, "1st Instance Third charge E222", 8765.00, null, 7654.00, null, 65.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to ViewSettlementStatement and resquence the orders
                Reports.TestStep = "Navigate to ViewSettlementStatement and resquence the orders";
                FastDriver.ViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_2ndCharge.Highlight();
                string Leas1 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_2ndCharge.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_3rdCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_2ndCharge);
                string Leas3 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_1stCharge.FAGetLocation().Y.ToString();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreNotEqual(Leas1, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_2ndCharge.FAGetLocation().Y.ToString(), "Validation After navigating to Some other page");
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_1stCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Commission);
                Playback.Wait(1000);
                Support.AreEqual(Leas3, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_1stCharge.FAGetLocation().Y.ToString(), "Validation After moving Out from Instance");
                #endregion

                #region Navigate Lease and Create Second Instance.
                Reports.TestStep = "Create Second instance in Lease Screen.";
                FastDriver.LeaseDetail.Open();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE02");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("876");
                FastDriver.LeaseDetail.SellerCharge.FASetText("654");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Updated Charge Description in Source Screen");
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, "2nd Instance Second charge G222", 43, null, 65.00, null, 87.00);
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, "2nd Instance Third cahrge F111", 6543.00, null, 7654.00, null, 76.00);
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to ViewSettlementStatement Screen and Validate resequenced Charges
                Reports.TestStep = "Navigate to ViewSettlementStatement and Validate the orders";
                FastDriver.ViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_5thCharge.Highlight();
                Support.AreNotEqual(Leas1, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_2ndCharge.FAGetLocation().Y.ToString(), "Validation After Inserting New Instance");
                Support.AreEqual(Leas3, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_1stCharge.FAGetLocation().Y.ToString(), "Validation After Inserting New Instance");
                string Disc2 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_5thCharge.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_5thCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_2ndCharge);
                Support.AreNotEqual(Disc2, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_5thCharge.FAGetLocation().Y.ToString(), "Validation Before Clicking on Reset Button");
                FastDriver.BottomFrame.Reset();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(3000);
                Support.AreEqual(Disc2, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Lease_5thCharge.FAGetLocation().Y.ToString(), "Validation After Clicking on Reset Button");
                #endregion


            }
            catch (Exception ex)
            {
                FailTest("Test case US_757382_NCS_805057 failed because " + ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0135_REG0034()
        {
            try
            {
                Reports.TestDescription = "US#756827:Verify Re-sequencing Charges in Utility section under 'Disbursement Paid' section UI.";

                #region LOGIN
                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion
                Reports.TestStep = "Login into the IIS Side.";
                Reports.TestStep = "Login FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create File.";
                CreateFile_WS();
                #endregion

                #region Navigate Utility and Create Instance.
                Reports.TestStep = "Navigate to the Utility screen and add values for buyer and seller charges.";
                FastDriver.UtilityDetail.Open();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("1000");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText("1300");
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, "1st Instance Second charge H543", 544.00, null, 453.00, null, 92.00);
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, "1st Instance Third charge J765", 8765.00, null, 7654.00, null, 65.00);
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to ViewSettlementStatement and resquence the orders
                Reports.TestStep = "Navigate to ViewSettlementStatement and resquence the orders";
                FastDriver.ViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_1stCharge.Highlight();
                string Utility1 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_2ndCharge.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_3rdCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_2ndCharge);
                string Utility3 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_1stCharge.FAGetLocation().Y.ToString();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreNotEqual(Utility1, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_2ndCharge.FAGetLocation().Y.ToString(), "Validation After navigating to Some other page");
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_1stCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Commission);
                Playback.Wait(1000);
                Support.AreEqual(Utility3, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_1stCharge.FAGetLocation().Y.ToString(), "Validation After moving Out from Instance");
                #endregion

                #region Navigate Utility and Create Second Instance.
                Reports.TestStep = "Create New instance in Utility Screen.";
                FastDriver.UtilityDetail.Open();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP2");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("876");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText("654");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText("Updated Charge in Utility source screen");
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, "2nd Instance Second charge M543", 433, null, 655.00, null, 87.00);
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, "2nd Instance Third charge K765", 6543.00, null, 7654.00, null, null);
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to ViewSettlementStatement Screen and Validate resequenced Charges
                Reports.TestStep = "Navigate to ViewSettlementStatement and Validate the orders";
                FastDriver.ViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_5thCharge.Highlight();
                Support.AreNotEqual(Utility1, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_2ndCharge.FAGetLocation().Y.ToString(), "Validation After Inserting New Instance");
                Support.AreEqual(Utility3, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_1stCharge.FAGetLocation().Y.ToString(), "Validation After Inserting New Instance");
                string Utility2 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_5thCharge.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_5thCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_2ndCharge);
                Support.AreNotEqual(Utility2, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_5thCharge.FAGetLocation().Y.ToString(), "Validation Before Clicking on Reset Button");
                FastDriver.BottomFrame.Reset();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(3000);
                Support.AreEqual(Utility2, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Utility_5thCharge.FAGetLocation().Y.ToString(), "Validation After Clicking on Reset Button");
                #endregion


            }
            catch (Exception ex)
            {
                FailTest("Test case US_756826_NCS_799486 failed because " + ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0135_REG0035()
        {
            try
            {
                Reports.TestDescription = "US#756826:Verify Re-sequencing Charges in Home Warranty section under 'Disbursement Paid' section UI/Delivery..";

                #region LOGIN
                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion
                Reports.TestStep = "Login into the IIS Side.";
                Reports.TestStep = "Login FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create File.";
                CreateFile_WS();
                #endregion

                #region Navigate Home Warranty and Create Instance.
                Reports.TestStep = "Create Home Warranty Detail Screen.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HUDHMWRNT1");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.Done();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                #endregion

                #region Navigate Home Warranty and Create Second Instance.
                Reports.TestStep = "Create Second instance in Home Warranty Screen.";
                FastDriver.HomeWarrantyDetail.Open();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Updated Charge for Homewarranty first charge");
                FastDriver.HomeWarrantyDetail.EarlyCoverageChargeDescription.FASetText("Modified charge for Home Warranty - Early Cov");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to ViewSettlementStatement and resquence the orders
                Reports.TestStep = "Navigate to ViewSettlementStatement and resquence the orders";
                FastDriver.ViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_1stCharge.Highlight();
                string HW1 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_2ndCharge.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_3rdCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_2ndCharge);
                string HW3 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_1stCharge.FAGetLocation().Y.ToString();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreNotEqual(HW1, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_2ndCharge.FAGetLocation().Y.ToString(), "Validation After navigating to Some other page");
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_1stCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Commission);
                Playback.Wait(1000);
                Support.AreEqual(HW3, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_1stCharge.FAGetLocation().Y.ToString(), "Validation After moving Out from Instance");

                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_4thCharge.Highlight();
                Support.AreNotEqual(HW1, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_2ndCharge.FAGetLocation().Y.ToString(), "Validation After Inserting New Instance");
                Support.AreEqual(HW3, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_1stCharge.FAGetLocation().Y.ToString(), "Validation After Inserting New Instance");
                int HW2 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_4thCharge.FAGetLocation().Y;
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_4thCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_1stCharge);
                Support.AreNotEqual(HW2.ToString(), FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_4thCharge.FAGetLocation().Y.ToString(), "Validation Before Clicking on Reset Button");
                FastDriver.BottomFrame.Reset();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(3000);
                HW2 += 1;
                Support.AreEqual(HW2.ToString(), FastDriver.NCSViewSettlementStatement.Disbursement_Paid_HW_4thCharge.FAGetLocation().Y.ToString(), "Validation After Clicking on Reset Button");
                #endregion


            }
            catch (Exception ex)
            {
                FailTest("Test case US_756826_NCS_799486 failed because " + ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0135_REG0039()
        {
            try
            {
                #region datasetup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region Loginto IIs and create file with business segment as commercial
                Reports.TestStep = "Loginto IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Create file with business segment as commercial";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.Click();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Accommodation");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("Firstamway");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to REB screen and create REB instances with REB charges
                Reports.TestStep = "Navigate to REB screen and create REB instances with REB charges";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(8000);
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FASetText("100.00");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FASetText("20.00");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(8000);
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("255");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FASetText("200.00");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FASetText("30.00");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Playback.Wait(8000);
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDLEASE01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FASetText("Other REB Broker charges");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FASetText("300.00");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FASetText("40.00");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to View Settlement statement and perform re-sequencing and verify the re-sequenced charges
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("General Excise Tax", FastDriver.NCSViewSettlementStatement.REB_Charge1.FAGetText().Trim(), "Validation before swapping");
                FastDriver.NCSViewSettlementStatement.REB_Charge1.Highlight();
                string AAA = FastDriver.NCSViewSettlementStatement.REB_Charge1.FAGetLocation().Y.ToString();
                Support.AreEqual("Other REB Broker charges", FastDriver.NCSViewSettlementStatement.REB_Charge3.FAGetText().Trim(), "Validation before swapping");

                string BBB = FastDriver.NCSViewSettlementStatement.REB_Charge3.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.REB_Charge3.FADragAndDrop(FastDriver.NCSViewSettlementStatement.REB_Charge1);
                FastDriver.BottomFrame.Done();
                Playback.Wait(10000);
                FastDriver.ViewSettlementStatement.WaitForScreenToLoad();
                Support.AreNotEqual(AAA, FastDriver.NCSViewSettlementStatement.REB_Charge1.FAGetLocation().Y.ToString(), "Validation After swapping");

                Support.AreNotEqual(BBB, FastDriver.NCSViewSettlementStatement.REB_Charge3.FAGetLocation().Y.ToString(), "Validation After swapping");


                #endregion




            }
            catch (Exception ex)
            {
                FailTest(ex.Message);

            }
        }
        [TestMethod]
        public void FMUC0135_REG0040()
        {
            try
            {
                #region datasetup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region Loginto IIs and create file with business segment as commercial
                Reports.TestStep = "Loginto IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Create file with business segment as commercial";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.Click();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Accommodation");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("Firstamway");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to Insurance screen and create Insurance instances
                Reports.TestStep = "Navigate to Insurance screen and create Insurance instances";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance");
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad().SwitchToContentFrame();

                FastDriver.InsuranceFire.FireGABcode.FASetText("255");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("300");
                FastDriver.InsuranceFire.FireSellerCharge.FASetText("400");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance");
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.Insuranceflood.FindGAB(GABCode: "HUDFLINSR1");
                FastDriver.Insuranceflood.FloodBuyercharge.FASetText("400");
                FastDriver.Insuranceflood.FloodSellerCharge.FASetText("600");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance");
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.InsuranceEarth.FindGAB(GABCode: "HUDLEASE01");
                FastDriver.InsuranceEarth.EarthBuyerCharge.FASetText("800");
                FastDriver.InsuranceEarth.EarthSellerCharge.FASetText("900");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to View Settlement statement and perform re-sequencing and verify the re-sequenced charges
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                FastDriver.ViewSettlementStatement.WaitForScreenToLoad();

                string temp1 = FastDriver.NCSViewSettlementStatement.DisbursementsTable.FindElements(By.TagName("table"))[0].FindElements(By.TagName("tr"))[3].Text.ToString();
                FastDriver.NCSViewSettlementStatement.DisbursementsTable.FindElements(By.TagName("table"))[0].FindElements(By.TagName("tr"))[3].FADragAndDrop(FastDriver.NCSViewSettlementStatement.DisbursementsTable.FindElements(By.TagName("table"))[0].FindElements(By.TagName("tr"))[0]);
                FastDriver.BottomFrame.Done();
                Playback.Wait(10000);
                FastDriver.ViewSettlementStatement.WaitForScreenToLoad();
                string temp2 = FastDriver.NCSViewSettlementStatement.DisbursementsTable.FindElements(By.TagName("table"))[0].FindElements(By.TagName("tr"))[3].Text.ToString();
                Support.AreNotEqual(temp1, temp2, "Validation after swapping");



                #endregion




            }
            catch (Exception ex)
            {
                FailTest(ex.Message);

            }
        }

        [TestMethod]
        public void FMUC0135_REG0041()
        {
            try
            {
                #region datasetup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region Loginto IIs and create file with business segment as commercial
                Reports.TestStep = "Loginto IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Create file with business segment as commercial";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.Click();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Accommodation");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("Firstamway");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();







                #endregion
                #region Navigate to Fee Entry and save the fees to the file
                Reports.TestStep = "Navigate to Fee Entry and save the fees to the file";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");

                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Administration Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFeeTable.PerformTableAction("#2", "Administration Fee", "#1", TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CA Withhold Assistance Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFeeTable.PerformTableAction("#2", "CA Withhold Assistance Fee", "#1", TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Check Fee - Additional");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFeeTable.PerformTableAction("#2", "Check Fee - Additional", "#1", TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Closing Service Coordination");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFeeTable.PerformTableAction("#2", "Closing Service Coordination", "#1", TableAction.On);

                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Administration Fee", "Buyer Charge", TableAction.SetText, "10");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Administration Fee", "Seller Charge", TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "CA Withhold Assistance Fee", "Buyer Charge", TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "CA Withhold Assistance Fee", "Seller Charge", TableAction.SetText, "40");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Check Fee - Additional", "Buyer Charge", TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Closing Service Coordination", "Seller Charge", TableAction.SetText, "60");


                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to View Settlement Statement and verify the re-sequencing of charges under Tite\Escrow Charges section.
                Reports.TestStep = " Navigate to View Settlement Statement and verify the re-sequencing of charges under Tite/Escrow Charges section";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("Check Fee - Additional", FastDriver.NCSViewSettlementStatement.Fees_Charge3.FAGetText().Trim(), "Validation before swapping");
                Support.AreEqual("Administration Fee", FastDriver.NCSViewSettlementStatement.Fees_Charge1.FAGetText().Trim(), "Validation before swapping");
                string temp1 = FastDriver.NCSViewSettlementStatement.Fees_Charge1.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Fees_Charge3.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Fees_Charge1);
                FastDriver.BottomFrame.Done();
                Playback.Wait(10000);
                FastDriver.ViewSettlementStatement.WaitForScreenToLoad();


                Support.AreNotEqual("temp1", FastDriver.NCSViewSettlementStatement.Fees_Charge1.FAGetLocation().Y.ToString(), "Validation after swapping");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);

            }
        }

        #region FMCU0135_REG0050 - FMUC0083_BAT0002_NCS
        [DataSource("System.Data.Odbc", "Dsn=Excel Files;Driver={Microsoft Excel Driver (*.xlsx)};dbq=|DataDirectory|\\NCS_Data.xlsx;defaultdir=.;driverid=790;maxbuffersize=2048;pagetimeout=5;readonly=true", "Sheet1$", DataAccessMethod.Sequential), DeploymentItem("NCS_Data.xlsx"), TestMethod]
        public void FMUC0135_REG0050()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = " Project NCS 2824 coverage of US# 622216, 608080, 608806 and 608843";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                /*Need to erase this from all scripts.
                Reports.TestStep = "Navigate to a region and office with the Feature 5 permission.";                
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("1552");
                FastDriver.HomePage.WaitForHomeScreen();
                */                
                Reports.TestStep = "Create File with Commercial business type.";
                CreateFile_WS();

                Reports.TestStep = "Add isntances of New Loan Lender with third party payee and mortgage.";
                #region Instance 1
                Reports.StatusUpdate("1st Lender Instance", true);
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode(TestContext.DataRow["NewLoanGabID1"].ToString());
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.FAClick();
                FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FASetText("20");

                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction("Description", "Application Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction("Description", "Application Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction("Description", "Processing Fee", "Buyer Charge", TableAction.SetText, "200.00");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction("Description", "Processing Fee", "Seller Charge", TableAction.SetText, "300.00");

                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode(TestContext.DataRow["3PartyPayeeGabID2"].ToString());
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(true);
                FastDriver.NewLoanDisbursements.NthChargeSelect(3).FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                FastDriver.BottomFrame.SwitchToContentFrame();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGABCode(TestContext.DataRow["MrtBrokerGabID1"].ToString());
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "2000.00");
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "1500.00");
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction("Description", "Credit Report", "Buyer Charge", TableAction.SetText, "1500.00");
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction("Description", "Credit Report", "Seller Charge", TableAction.SetText, "2000.00");
                FastDriver.BottomFrame.New();
                #endregion
                #region Instance 2
                Reports.StatusUpdate("2nd Lender Instance", true);
                
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode(TestContext.DataRow["NewLoanGabID2"].ToString());
                FastDriver.BottomFrame.Done();                
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.FAFindElement(ByLocator.Id, "grdLoanSumry_1").FADoubleClick();
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.NewLoanSummary.SwitchToContentFrame();

                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.FAClick();
                FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FASetText("20");
                
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Lender's Inspection Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Lender's Inspection Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Document Preparation Fee", "Buyer Charge", TableAction.SetText, "200.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Document Preparation Fee", "Seller Charge", TableAction.SetText, "300.00");
               

                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode(TestContext.DataRow["3PartyPayeeGabID3"].ToString());
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

               
                FastDriver.BottomFrame.SwitchToContentFrame();               
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGABCode(TestContext.DataRow["MrtBrokerGabID3"].ToString());
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "2000.00");
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "1500.00");
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction("Description", "Credit Report", "Buyer Charge", TableAction.SetText, "1500.00");
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction("Description", "Credit Report", "Seller Charge", TableAction.SetText, "2000.00");
                FastDriver.BottomFrame.Done();
                #endregion
                

                Reports.TestStep = "Add isntances of Payoff Loan Lender.";
                #region Instance 1
                Reports.StatusUpdate("Payoff Loan 1st instance.", true);
                FastDriver.PayoffLoanDetails.Open();
                FastDriver.PayoffLoanDetails.FindGABCode(TestContext.DataRow["PayoffLoanGabID1"].ToString());
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItem("Fixed Rate");                
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.InterestCalculationPercentRate.FAClick();
                FastDriver.PayoffLoanCharges.InterestCalculationPercentRate.FASetCheckbox(true);
                FastDriver.PayoffLoanCharges.InterestCalculationProrPercentRateval.FASetText("20");

                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Reconveyance Fee", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Reconveyance Fee", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Late Charge", "Buyer Charge", TableAction.SetText, "100.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Late Charge", "Seller Charge", TableAction.SetText, "400.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Recording Fee", "Buyer Charge", TableAction.SetText, "200.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Recording Fee", "Seller Charge", TableAction.SetText, "300.00");
                FastDriver.PayoffLoanCharges.PayChargesBtn.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(false);
                FastDriver.NewLoanDisbursements.NthChargeSelect(3).FASetCheckbox(false);
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode(TestContext.DataRow["3PartyPayeeGabID6"].ToString());
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(true);
                FastDriver.NewLoanDisbursements.NthChargeSelect(3).FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                #endregion
                #region Instance 2
                Reports.StatusUpdate("Payoff Loan 2nd instance.", true);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(TestContext.DataRow["PayoffLoanGabID3"].ToString());
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.InterestCalculationPercentRate.FAClick();
                FastDriver.PayoffLoanCharges.InterestCalculationPercentRate.FASetCheckbox(true);
                FastDriver.PayoffLoanCharges.InterestCalculationProrPercentRateval.FASetText("20");

                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Buyer Charge", TableAction.SetText, "500.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Seller Charge", TableAction.SetText, "300.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Late Charge", "Buyer Charge", TableAction.SetText, "100.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Late Charge", "Seller Charge", TableAction.SetText, "400.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Reconveyance Fee", "Buyer Charge", TableAction.SetText, "1000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Reconveyance Fee", "Seller Charge", TableAction.SetText, "500.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Recording Fee", "Buyer Charge", TableAction.SetText, "2000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Recording Fee", "Seller Charge", TableAction.SetText, "3000.00");

                FastDriver.PayoffLoanCharges.PayChargesBtn.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(false);
                FastDriver.NewLoanDisbursements.NthChargeSelect(3).FASetCheckbox(false); 
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode(TestContext.DataRow["3PartyPayeeGabID5"].ToString());
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(true);
                FastDriver.NewLoanDisbursements.NthChargeSelect(3).FASetCheckbox(true);
                FastDriver.BottomFrame.Done();               
                #endregion
                

                Reports.TestStep = "Add isntances of Assumption Loan Lender.";
                #region Instance 1
                Reports.StatusUpdate("Assumption Loan 1st instance.", true);
                FastDriver.AssumptionLoanDetails.Open();
                FastDriver.AssumptionLoanDetails.FindGABCode(TestContext.DataRow["AssumptionLoanGabID2"].ToString());
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.InterestProrationInterestType.FASelectItem("Fixed Rate");
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.InterestProrationPercentRate.FAClick();
                FastDriver.AssumptionLoanCharges.InterestProrationPercentRatevalue.FASetText("20");

                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Document Fee", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Document Fee", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Late Charge", "Buyer Charge", TableAction.SetText, "100.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Late Charge", "Seller Charge", TableAction.SetText, "400.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Assumption Transfer Fee", "Buyer Charge", TableAction.SetText, "200.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Assumption Transfer Fee", "Seller Charge", TableAction.SetText, "300.00");

                FastDriver.AssumptionLoanCharges.PayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(false);
                FastDriver.NewLoanDisbursements.NthChargeSelect(3).FASetCheckbox(false); 
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode(TestContext.DataRow["3PartyPayeeGabID2"].ToString());
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(true);
                FastDriver.NewLoanDisbursements.NthChargeSelect(3).FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                #endregion
                #region Instance 2
                Reports.StatusUpdate("Assumption Loan 2nd instance.", true);
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode(TestContext.DataRow["AssumptionLoanGabID1"].ToString());
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.InterestProrationInterestType.FASelectItem("Fixed Rate");
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.InterestProrationPercentRate.FAClick();
                FastDriver.AssumptionLoanCharges.InterestProrationPercentRatevalue.FASetText("20");

                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Application Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Application Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Late Charge", "Buyer Charge", TableAction.SetText, "100.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Late Charge", "Seller Charge", TableAction.SetText, "400.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Processing Fee", "Buyer Charge", TableAction.SetText, "200.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Processing Fee", "Seller Charge", TableAction.SetText, "300.00");

                FastDriver.AssumptionLoanCharges.PayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(false);
                FastDriver.NewLoanDisbursements.NthChargeSelect(3).FASetCheckbox(false); 
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode(TestContext.DataRow["3PartyPayeeGabID3"].ToString());
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(true);
                FastDriver.NewLoanDisbursements.NthChargeSelect(3).FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                #endregion
                

                Reports.TestStep = "Navigate to the View Settlement Stmt screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.StatusUpdate("US 622216 coverage", true);
                Reports.TestStep = "Verify if column header is displayed for the Cash section of the View Settlement Statement when charges are displayed. US# 622216";
                Support.AreEqual(false, FastDriver.ViewSettlementStatement.CashSectionTable.FAGetText().Contains("Buyer Charge"), "Verifying colum header row is not displayed in Cash Section");
                Support.AreEqual(false, FastDriver.ViewSettlementStatement.CashSectionTable.FAGetText().Contains("Buyer Credit"), "Verifying colum header row is not displayed in Cash Section");
                Support.AreEqual(false, FastDriver.ViewSettlementStatement.CashSectionTable.FAGetText().Contains("Charge Description"), "Verifying colum header row is not displayed in Cash Section");
                Support.AreEqual(false, FastDriver.ViewSettlementStatement.CashSectionTable.FAGetText().Contains("Seller Charge"), "Verifying colum header row is not displayed in Cash Section");
                Support.AreEqual(false, FastDriver.ViewSettlementStatement.CashSectionTable.FAGetText().Contains("Seller Credit"), "Verifying colum header row is not displayed in Cash Section");

                Reports.StatusUpdate(FastDriver.ViewSettlementStatement.NewNewLoanTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']/b[contains(text(),'Mrtg. Broker: " + TestContext.DataRow["MrtBrokerGabName1"].ToString() + "')]").FAGetLocation().Y.ToString(), true);

                Reports.StatusUpdate(FastDriver.ViewSettlementStatement.NewPayoffLoanTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']/b[contains(text(),'Lender: " + TestContext.DataRow["PayoffLoanGabName1"].ToString() + "')]").FAGetLocation().Y.ToString(), true);

                Reports.StatusUpdate("US 608080 1st coverage", true);
                Reports.TestStep = "Verify if resequencing of Lender instances is possible in New Loan section. US# 608080.";

                //Saving original position.
                string MortBrokerInstance = FastDriver.ViewSettlementStatement.NewNewLoanTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']/b[contains(text(),'Mrtg. Broker: " + TestContext.DataRow["MrtBrokerGabName1"].ToString() + "')]").FAGetLocation().Y.ToString();

                // Perform drag and drop action.
                FastDriver.ViewSettlementStatement.NewNewLoanTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']/b[contains(text(),'Mrtg. Broker: " + TestContext.DataRow["MrtBrokerGabName1"].ToString() + "')]").FADragAndDrop(FastDriver.ViewSettlementStatement.NewNewLoanTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']/b[contains(text(),'Lender: " + TestContext.DataRow["NewLoanGabName1"].ToString() + "')]"));

                //Comparing current position with original position.
                Support.AreNotEqual(MortBrokerInstance,FastDriver.ViewSettlementStatement.NewNewLoanTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']/b[contains(text(),'Mrtg. Broker: " + TestContext.DataRow["MrtBrokerGabName1"].ToString() + "')]").FAGetLocation().Y.ToString(), "Validating the drag and drop of worked.");

                Reports.StatusUpdate("US 608080 2nd coverage", true);
                Reports.TestStep = "Verify if resequencing of charges whithing one lender instance is possible in New Loan section. US# 608080.";
                FastDriver.ViewSettlementStatement.NewNewLoanTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr'][contains(text(),'Processing Fee to " + TestContext.DataRow["3PartyPayeeGabName2"].ToString() + "')]").FADragAndDrop(FastDriver.ViewSettlementStatement.NewNewLoanTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr'][contains(text(),'Verification Fee to " + TestContext.DataRow["NewLoanGabName1"].ToString() + "')]"));

                Reports.StatusUpdate("US 608806 coverage", true);
                Reports.TestStep = "Verify if resequencing of Lender instances is possible in Payoff Loan section. US# 608806.";
                FastDriver.ViewSettlementStatement.NewPayoffLoanTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']/b[contains(text(),'Lender: " + TestContext.DataRow["PayoffLoanGabName1"].ToString() + "')]").FADragAndDrop(FastDriver.ViewSettlementStatement.NewNewLoanTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']/b[contains(text(),'Lender: " + TestContext.DataRow["PayoffLoanGabName2"].ToString() + "')]"));

                Reports.StatusUpdate("US 608843 coverage", true);
                Reports.TestStep = "Verify if resequencing of Lender instances is possible in Assumption Loan section. US# 608843.";
                FastDriver.ViewSettlementStatement.NewNewLoanTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']/b[contains(text(),'Lender: " + TestContext.DataRow["AssumptionLoanGabName1"].ToString() + "')]").FADragAndDrop(FastDriver.ViewSettlementStatement.NewNewLoanTable.FAFindElement(ByLocator.XPath, "//div[@class='maxWidth400 ChargeDescr']/b[contains(text(),'Lender: " + TestContext.DataRow["AssumptionLoanGabName3"].ToString() + "')]"));


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion


        #endregion
        #region r08.2016
        [TestMethod]
        public void FMUC0135_REG0002()
        {
            try
            {
                Reports.TestDescription = "US779318 :For Deposits in Escrow section, display Subtotals for buyer/seller net credit amount in Settlement Statement- UI.";
                string recieptNo = this.getRecieptNo;
                string manualReason = "Adding comments for manual check.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Create A Basic file order.
                Reports.TestStep = "Create File.";
                CreateFile_WS();
                #endregion

                #region Perform a Cash Deposit with Manual reciept number.
                Reports.TestStep = "Navigate to Deposit in Escrow page.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                Reports.TestStep = "Perform a cash deposit with Manual reciept number.";
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 89899989623.86,
                    TypeofFunds = "Cash",
                    Representing = "Earnest Money Deposit",
                    Description = "Earnest Money Deposit",
                    ReceivedFrom = "Seller",
                    Payor = "Testing Payor1",
                    CreditToSeller = false,
                    Comments = "It is a Manual Cash deposit.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                #endregion

                #region Add Manual Check number.
                Reports.TestStep = "Click on the Manual Button and provide the manual check number";
                FastDriver.DepositInEscrow.Manual.Click();
                FastDriver.DepositInEscrow.ReceiptNo.SendKeys(OpenQA.Selenium.Keys.Backspace);
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(recieptNo);
                FastDriver.DepositInEscrow.IssueDte.FASetText("08-20-2015");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Add Comment for the Manual cash deposit.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText(manualReason);
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 5);
                //FastDriver.PrintDlg.WaitForScreenToLoad();
                //FastDriver.PrintDlg.Cancel.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                #endregion

                #region Perform an another deposit with system generated reciept.
                Reports.TestStep = "Navigate to Deposit in Escrow page.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Perform a cash deposit with automatic reciept number.";
                DepositParameters depositDetail2 = new DepositParameters()
                {
                    Amount = 7000.00,
                    TypeofFunds = "Cash",
                    Representing = "Earnest Money Deposit",
                    Description = "Earnest Money Deposit",
                    ReceivedFrom = "Buyer",
                    Payor = "Testing Payor2",
                    CreditToSeller = false,
                    Comments = "This Deposit is second deposit with automatic reciept number.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail2);
                string issueDate = FastDriver.DepositInEscrow.IssueDte.FAGetValue();
                Support.AreEqual(issueDate, DateTime.Now.ToDateString());
                FastDriver.DepositInEscrow.IssueDte.FASetText("08-20-2015");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                String recieptNo1 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                #endregion

                #region Perform an another deposit so that it crosses the excess deposit limit.
                Reports.TestStep = "Navigate to Deposit in Escrow page.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Perform a cash deposit with automatic reciept number.";
                DepositParameters depositDetail3 = new DepositParameters()
                {
                    Amount = 5000.00,
                    TypeofFunds = "Money Order",
                    Representing = "Initial Deposit",
                    Description = "Intial Deposit",
                    ReceivedFrom = "Seller",
                    Payor = "Testing Payor3",
                    CreditToSeller = false,
                    Comments = "This Deposit is second deposit with automatic reciept number.",

                    CheckNumber = "12345678",
                    ABANumber = "1234567895",
                    AccountNumber = "123456743",
                    BankName = "23testbank"
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail3);
                // Support.AreEqual(issueDate, DateTime.Now.ToDateString());
                //  FastDriver.DepositInEscrow.IssueDte.FASetText("08-20-2015");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 15);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                String recieptNo2 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                String issueDate1 = FastDriver.DepositInEscrow.IssueDte.FAGetValue();
                String Issuedate2 = issueDate1.Replace("-", "/");
                #endregion

                #region Perform an another deposit with system generated reciept.
                Reports.TestStep = "Navigate to Deposit in Escrow page.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Perform a cash deposit with automatic reciept number.";
                DepositParameters depositDetail4 = new DepositParameters()
                {
                    Amount = 56438765432.54,
                    TypeofFunds = "Cash",
                    Representing = "Earnest Money Deposit",
                    Description = "Earnest Money Deposit",
                    ReceivedFrom = "Buyer",
                    Payor = "Testing Payor2",
                    CreditToSeller = false,
                    Comments = "This Deposit is second deposit with automatic reciept number.",
                };
                FastDriver.DepositInEscrow.Deposit(depositDetail4);

                Support.AreEqual(issueDate, DateTime.Now.ToDateString());
                FastDriver.DepositInEscrow.IssueDte.FASetText("08-20-2015");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                String recieptNo3 = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                #endregion

                #region Navigate to ViewSettlementStatement and Verify Subtotal functionality
                Reports.TestStep = "Navigate to ViewSettlementStatement and and Verify Subtotal functionality";
                FastDriver.NCSViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.DepositsInEscrow_SubtotalCheckbox.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                string Tabledata = FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.FAGetText();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreEqual("TRUE", Tabledata.Contains("Total Deposits in Escrow").ToString().ToUpper());
                Support.AreEqual("Total Deposits in Escrow", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(3, 4, TableAction.GetText).Message.Trim(), "Verify The Buyer Credit Value>");
                Support.AreEqual("56,438,772,432.54", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(3, 3, TableAction.GetText).Message.Trim(), "Verify The Buyer Credit Value>");
                Support.AreEqual("89,899,994,623.86", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(3, 6, TableAction.GetText).Message.Trim(), "Verify The Seller Credit Value>");
                verifytheData(FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable, "Receipt No. " + recieptNo + " on 08/20/2015 by Testing Payor1", null, null, null, "89,899,989,623.86");
                verifytheData(FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable, "Receipt No. " + recieptNo1 + " on 08/20/2015 by Testing Payor2", null, null, "7,000.00", null);
                verifytheData(FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable, "Receipt No. " + recieptNo3 + " on 08/20/2015 by Testing Payor2", null, null, "56,438,765,432.54", null);
                verifytheData(FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable, "Receipt No. " + recieptNo2 + " on " + Issuedate2 + " by Testing Payor3", null, null, null, "5,000.00");
                Reports.TestStep = "Verify UnSubtotal functionality after unchecking the Subtotal checkbox";
                FastDriver.NCSViewSettlementStatement.DepositsInEscrow_SubtotalCheckbox.FASetCheckbox(false);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreEqual("89,899,989,623.86", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(3, 6, TableAction.GetText).Message.Trim(), "Validating the Seller Credit Value in Seller Credit Column");
                Support.AreEqual("7,000.00", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(4, 3, TableAction.GetText).Message.Trim(), "Validating the Buyer  Credit Value in Buyer Credit Column");
                Support.AreEqual("56,438,765,432.54", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(5, 3, TableAction.GetText).Message.Trim(), "Validating the Buyer  Credit Value in Buyer Credit Column");
                Support.AreEqual("5,000.00", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(6, 6, TableAction.GetText).Message.Trim(), "Validating the Seller Credit Value in Seller Credit Column");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion

                #region Move to the Deposit history and validate details field are disabled and change the credit to seller.
                Reports.TestStep = "Navigate to Deposit Summary and credit to Buyer.";
                FastDriver.DepositReceiptHistory.Open();
                Reports.TestStep = "Select the performed deposit from the list.";
                FastDriver.DepositReceiptHistory.WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(4, recieptNo, 3, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.Click();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.VerifyFieldsDisabledAfterDeposit();
                Reports.TestStep = "Change the credit to seller.";
                FastDriver.DepositInEscrow.CredittoBuyer.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Move to the Deposit history and validate details field are disabled and change the credit to Buyer.
                Reports.TestStep = "Navigate to Deposit Summary and change the credit to Buyer .";
                FastDriver.DepositReceiptHistory.Open();
                Reports.TestStep = "Select the performed deposit from the list.";
                FastDriver.DepositReceiptHistory.WaitForScreenToLoad();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(4, recieptNo3, 3, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.Click();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.VerifyFieldsDisabledAfterDeposit();
                Reports.TestStep = "Change the credit to seller.";
                FastDriver.DepositInEscrow.CredittoSeller.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                #endregion

                #region Navigate to ViewSettlementStatement and Verify Subtotal functionality
                Reports.TestStep = "Navigate to ViewSettlementStatement and and Verify Subtotal functionality";
                FastDriver.NCSViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.DepositsInEscrow_SubtotalCheckbox.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                string Tabledata1 = FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.FAGetText();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreEqual("TRUE", Tabledata1.Contains("Total Deposits in Escrow").ToString().ToUpper());
                Support.AreEqual("Total Deposits in Escrow", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(3, 4, TableAction.GetText).Message.Trim(), "Validating the Total Sub Header in Deposit in Escrow section>");
                Support.AreEqual("56,438,770,432.54", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(3, 6, TableAction.GetText).Message.Trim(), "Verify The Seller Credit Value>");
                Support.AreEqual("89,899,996,623.86", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(3, 3, TableAction.GetText).Message.Trim(), "Verify The Buyer Credit Value>");
                verifytheData(FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable, "Receipt No. " + recieptNo + " on 08/20/2015 by Testing Payor1", null, null, null, "89,899,989,623.86");
                verifytheData(FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable, "Receipt No. " + recieptNo1 + " on 08/20/2015 by Testing Payor2", null, null, "7,000.00", null);
                verifytheData(FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable, "Receipt No. " + recieptNo3 + " on 08/20/2015 by Testing Payor2", null, null, null, "56,438,765,432.54");
                verifytheData(FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable, "Receipt No. " + recieptNo2 + " on " + Issuedate2 + " by Testing Payor3", null, null, null, "5,000.00");
                Reports.TestStep = "Verify UnSubtotal functionality after unchecking the Subtotal checkbox";
                FastDriver.NCSViewSettlementStatement.DepositsInEscrow_SubtotalCheckbox.FASetCheckbox(false);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreEqual("89,899,989,623.86", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(3, 3, TableAction.GetText).Message.Trim(), "Validating the Buyer Credit Value in Buyer Credit Column");
                Support.AreEqual("7,000.00", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(4, 3, TableAction.GetText).Message.Trim(), "Validating the Buyer  Credit Value in Buyer Credit Column");
                Support.AreEqual("56,438,765,432.54", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(5, 6, TableAction.GetText).Message.Trim(), "Validating the Seller  Credit Value in Seller Credit Column");
                Support.AreEqual("5,000.00", FastDriver.NCSViewSettlementStatement.NewDepositsInEscrowTable.PerformTableAction(6, 6, TableAction.GetText).Message.Trim(), "Validating the Seller Credit Value in Seller Credit Column");

                #endregion



            }
            catch (Exception ex)
            {
                FailTest("Test case US_779318_NCS_823619 failed because " + ex.Message);
            }
        }
        /// <summary>
        /// FMUC0135_REG0004 - This Test method covers the US 759774 from r08
        /// FMUC0135_REG0003 - This Test method covers the US 780195 from r08
        /// FMUC0135_REG0005 - This Test method covers the US 777271 from r08
        /// FMUC0135_REG0012 covers US 779317 from r08
        /// FMUC0135_REG0014 covers US 785581 from r08
        /// </summary>
        /// <param name="admLogin"></param>
        [TestMethod]
        public void FMUC0135_REG0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "#US 759774 for Remove the subtotal checkbox from Miscellaneous Disbursements section.";
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Through UI
                Reports.TestStep = "Create File with Commercial business type.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.BottomFrame.Done();

                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                #region Setting up TestData
                Reports.TestStep = "Miscellaneous Disbursement test data setup.";
                Reports.TestStep = "Navigate to the Miscellaneous Disbursement screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("boa");
                FastDriver.MiscDisbursementDetail.Description.FASetText("Charge1 of Miscellaneous Disbursement" + Keys.Tab);
                FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText("10000");
                FastDriver.MiscDisbursementDetail.SellerCharge.FASetText("15000" + Keys.Tab + Keys.Tab);
                FastDriver.MiscDisbursementDetail.Description1.FASetText("Charge2 of Miscellaneous Disbursement" + Keys.Tab);
                FastDriver.MiscDisbursementDetail.BuyerCharge1.FASetText("13000");
                FastDriver.MiscDisbursementDetail.SellerCharge1.FASetText("24000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verifying Removal of Subtotal Checkbox of Miscellaneous Disbursement in Disbursement Paid section without Subtotal Checkbox checked
                Reports.TestStep = "Navigate to Viewsettlement Statement";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Reports.TestStep = "Verify the Removal of Subtotal Checkbox of Miscellaneous Disbursement in Disbursement Paid Section.";
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.Disburs_MiscDisbursements_SubtotalCheckbx.IsVisible().ToString());
                FastDriver.BottomFrame.Done();
                #endregion
                #region Verifying Removal of Subtotal Checkbox of Miscellaneous Disbursement in Disbursement Paid section with Select All Subtotal Checkbox checked
                Reports.TestStep = "Navigate to Viewsettlement Statement and Select Select All checkbox";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.SelectAll_SubtotalsCheckbox.FAClick();
                Reports.TestStep = "Verify no Subtotal amount is displayed for Miscellaneous Disbursement subsection in Disbursement Paid section with Select All checkbox checked.";
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.DisbursementsTable.FAFindElement(ByLocator.XPath, "//table[@id='table-12']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/div").Equals("230,000.00").ToString(), "check");
                #endregion
            }
            catch (Exception)
            {
                throw;
            }
        }
        [TestMethod]
        public void FMUC0135_REG0003()
        {
            try
            {
                Reports.TestDescription = "US# 780195 For Funds Held section, display Subtotals for buyer/seller net charge/credit amount in Settlement Statement- UI";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log into FAST application automation region/office with automation credentials";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Set up a basic file and sufficient funds held data i.e. multiple instances";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.txtBusinessSourceGABID.FASetText("800");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                { FastDriver.QuickFileEntry.Title.FASetCheckbox(true); }
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                { FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true); }
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("123456789.97");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("994555873");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Trust/Estate");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Business Entity");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For First Hold Funds Instance.");
                FastDriver.HoldFunds.SellerCharge.FASetText("100");
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(2000);
                FastDriver.ProrationTax.New.FAClick();
                Playback.Wait(2000);
                FastDriver.HoldFunds.FindGABCode("420");
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("Sanath");
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("" + FAKeys.Tab);
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.96" + FAKeys.Tab);
                Keyboard.SendKeys("{TAB}");
                FastDriver.BottomFrame.New();
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For Second Hold Funds Instance.");
                FastDriver.HoldFunds.RadbtnBuyer.FASetCheckbox(true);
                FastDriver.HoldFunds.BuyerCharge.FASetText("200000000.87" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.FindGABCode();
                FastDriver.HoldFunds.HoldFundBuyerCharge1.FASetText("100000000.11");
                FastDriver.BottomFrame.New();
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For Third Hold Funds Instance !@#$%^&*()_+1234567890 ABCD.");
                FastDriver.HoldFunds.RadbtnBuyer.FASetCheckbox(true);
                FastDriver.HoldFunds.BuyerCharge.FASetText("300000000.87" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.FindGABCode("246");
                FastDriver.HoldFunds.HoldFundBuyerCharge1.FASetText("100000000" + FAKeys.Tab);
                Playback.Wait(5000);
                FastDriver.HoldFunds.New.FAClick();
                Playback.Wait(5000);
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad().FileaddressBookResultsRadio1.FAClick();
                FastDriver.DialogBottomFrame.ClickDone().SwitchToContentFrame();
                FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("!@#$%P1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5");
                FastDriver.HoldFunds.HoldFundBuyerCharge1.FASetText("100000000" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Validating the subtotals design on the view settlement statement screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                //FastDriver.ViewSettlementStatement.GoToButtonHover();
                //FastDriver.ViewSettlementStatement.GoToFundsHeld.FAClick();
                //Playback.Wait(2000);
                string a = FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'!@#$%P1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5 ')]").FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'!@#$%P1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5 ')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Sanath ')]"));
                Support.AreNotEqual(a, FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'!@#$%P1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5 ')]").FAGetLocation().Y.ToString());
                /*string a = FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.FAFindElement(ByLocator.XPath, "//span[@class='']/span[contains(text(),'Reason For Third Hold Funds Instance !@#$%^&*()_+1234567890 ABCD.')]").FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.FAFindElement(ByLocator.XPath, "//span[@class='']/span[contains(text(),'Reason For Third Hold Funds Instance !@#$%^&*()_+1234567890 ABCD.')]").FADragAndDrop(FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.FAFindElement(ByLocator.XPath, "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'!@#$%P1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5 ')]"));
                Support.AreNotEqual(a, FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.FAFindElement(ByLocator.XPath, "//span[@class='']/span[contains(text(),'Reason For Third Hold Funds Instance !@#$%^&*()_+1234567890 ABCD.')]").FAGetLocation().Y.ToString());*/
                Support.AreEqual("Funds Held Reason For First Hold Funds Instance.", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(3, 4, TableAction.GetText).Message);
                Support.AreEqual("89.04", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(3, 5, TableAction.GetText).Message);
                FastDriver.NCSViewSettlementStatement.MarkSelectAllCheckBox();
                Playback.Wait(2000);
                Support.AreEqual("Total Funds Held", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(3, 4, TableAction.GetText).Message);
                Support.AreEqual("500,000,001.74", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(3, 2, TableAction.GetText).Message);
                Support.AreEqual("", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(3, 3, TableAction.GetText).Message);
                Support.AreEqual("100.00", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(3, 5, TableAction.GetText).Message);
                Support.AreEqual("", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(3, 6, TableAction.GetText).Message);
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(9, 4, TableAction.GetText).Message.Equals("Ad Hoc Entry to Bank of America B: 100,000,000.11").ToString());
                Playback.Wait(6000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                Reports.TestStep = "Altering an amount and validating the changes on VSS";
                FastDriver.LeftNavigation.Navigate<HoldFundsSummary>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFundsSummary.SummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.HoldFundsSummary.Edit.FAClick();
                FastDriver.HoldFunds.SellerCharge.FASetText("2222.22" + FAKeys.Tab);
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("2,222.22", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(3, 5, TableAction.GetText).Message);
                /*for (int i = 4; i <= FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.GetRowCount(); i++)
                {
                    Support.AreEqual("", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(i, 1, TableAction.GetText).Message);
                    Support.AreEqual("", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(i, 5, TableAction.GetText).Message);
                }*/
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(8, 4, TableAction.GetText).Message.Equals("Sanath to The Northern Trust Company S: 10.96").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(7, 4, TableAction.GetText).Message.Equals("!@#$%P1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5 to Buyer1fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcde B: 100,000,000.00").ToString());
                FastDriver.NCSViewSettlementStatement.FundsHeld_SubtotalsCheckbox.FASetCheckbox(false);
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(7, 4, TableAction.GetText).Message.Equals("Sanath to The Northern Trust Company").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(6, 4, TableAction.GetText).Message.Equals("!@#$%P1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5 to Buyer1fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcde").ToString());
                Support.AreEqual("Funds Held Reason For First Hold Funds Instance.", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(3, 4, TableAction.GetText).Message);
                FastDriver.NCSViewSettlementStatement.MarkSelectAllCheckBox();
                Playback.Wait(2000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<HoldFundsSummary>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFundsSummary.SummaryTable.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.HoldFundsSummary.Edit.FAClick();
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.HoldFunds.HoldFundBuyerCharge1.FASetText("0.93" + FAKeys.Tab);
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(7, 4, TableAction.GetText).Message.Equals("!@#$%P1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5 to Buyer1fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcde B: 0.93").ToString());
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Refinance");
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true, timeout: 10);
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Playback.Wait(3000);
                Support.AreEqual("", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.PerformTableAction(3, 5, TableAction.GetText).Message.Trim());
                //Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.GetAttribute("InnerText").Contains("S: ").ToString());
                //Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.FAGetAttribute("InnerText").Contains("S: ").ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.FundsHeldTableUseID.StringExistOnTable("S: ").ToString());
            }
            catch (Exception ex)
            { FailTest(ex.Message); }
        }
        [TestMethod]
        public void FMUC0135_REG0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "#US 777271 for New Subtotal Design for Disbursements Paid section- UI.";
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Through UI
                Reports.TestStep = "Create File with Commercial business type.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.BottomFrame.Done();

                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                #region Setting Test data for Disbursement Oaid section
                #region Homeowner Association setup
                Reports.TestStep = "Navigate to Homeowner Association and add values to buyer and seller.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FASetText("1200");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge1.FASetText("12500000000");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge2.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge3.FASetText("5000");

                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FASetText("500");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge1.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge2.FASetText("500");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge3.FASetText("1000");
                Reports.TestStep = "Adding POC amounts for Homeowner Association Subsection in Disbursement section.";
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                FastDriver.HomeownerAssociation.SwitchToDialogContentFrame();
                FastDriver.HomeownerAssociation.AssociationCharge1PBbyBuyer.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationBuyerCharge1PBbyOther.FASetText("200");
                FastDriver.HomeownerAssociation.AssociationBuyerCharge1PBotherDropdown.FASelectItem("POC-L");
                FastDriver.HomeownerAssociation.SwitchToDialogBottomFrame();
                FastDriver.HomeownerAssociation.PPDDone.FAClick();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Warranty setup
                Reports.TestStep = "Navigate to Home Warranty and add values to buyer and seller.";

                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                FastDriver.HomeWarrantyDetail.FindGABCode("246");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("10000000000");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("1000");
                FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FASetText("2400");
                FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FASetText("3000");
                Reports.TestStep = "Adding POC amounts for Homeowner Association Subsection in Disbursement section.";
                FastDriver.HomeWarrantyDetail.PaymentDetailsEarlyCoverage.FAClick();
                FastDriver.HomeWarrantyDetail.SwitchToDialogContentFrame();
                FastDriver.HomeWarrantyDetail.ECBPbySellerAtClosing.FASetText("1500");
                FastDriver.HomeWarrantyDetail.ECOtherSeller.FASetText("1500");
                FastDriver.HomeWarrantyDetail.DropdownECOtherSeller.FASelectItem("POC");
                FastDriver.HomeWarrantyDetail.SwitchToDialogBottomFrame();
                FastDriver.HomeWarrantyDetail.PPDDone.FAClick();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Inspection Repair setup
                Reports.TestStep = "Navigate to Inspection Repair Pest screen and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.FindGAB("800");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("50000000000");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Inspection Repair Septic and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").WaitForScreenToLoad();
                FastDriver.InspectionRepairSeptic.FindGAB("247");
                FastDriver.InspectionRepairSeptic.BuyerCharge.FASetText("5000");
                FastDriver.InspectionRepairSeptic.SellerCharge.FASetText("1000");
                FastDriver.InspectionRepairSeptic.PaymentDetails.FAClick();
                FastDriver.InspectionRepairSeptic.SwitchToDialogContentFrame();
                FastDriver.InspectionRepairSeptic.SepticPBbyBuyerAtClosing.FASetText("2000");
                FastDriver.InspectionRepairSeptic.SepticBPbyOthers.FASetText("3000");
                FastDriver.InspectionRepairSeptic.DropdownSepticOtherBuyer.FASelectItem("POC");
                FastDriver.InspectionRepairSeptic.SwitchToDialogBottomFrame();
                FastDriver.InspectionRepairSeptic.SepticPPDdone.FAClick();
                FastDriver.InspectionRepairSeptic.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Inspection Repair Other and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.FindGAB("246");
                FastDriver.InspectionRepairOther.BuyerCharge.FASetText("500");
                FastDriver.InspectionRepairOther.SellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region REB values setup
                Reports.TestStep = "Add REB commission charge for both buyer and seller.";
                #region step actions
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.FindGAB("800");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FASetText("20000000000");
                Keyboard.SendKeys("{TAB}");
                //Support.AreEqual("Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 35));
                string BuyerREBrokerName = FastDriver.RealEstateBrokerAgent.BrokerName1.FAGetText().ToString().Clean();

                FastDriver.BottomFrame.Done();

                FastDriver.BottomFrame.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.FindGAB("246");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FASetText("10000");
                Keyboard.SendKeys("{TAB}");
                //Support.AreEqual("Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 35));
                string SellerREBrokerName = FastDriver.RealEstateBrokerAgent.BrokerName1.FAGetText().ToString().Clean();
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                #region Insurance setup
                Reports.TestStep = "Navigate to the Insurance screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FindGAB("420");
                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("10000000000");
                FastDriver.InsuranceFire.FireSellerCharge.FASetText("500");
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad().Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.FindGAB("boa");
                FastDriver.Insuranceflood.FloodBuyercharge.FASetText("500");
                FastDriver.Insuranceflood.FloodSellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad().Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.FindGAB("420");
                FastDriver.InsuranceWind.WindBuyerCharge.FASetText("4500");
                FastDriver.InsuranceWind.WindSellerCharge.FASetText("1000");
                FastDriver.InsuranceWind.WindPaymentDetails.FAClick();
                FastDriver.InsuranceWind.SwitchToDialogContentFrame();
                FastDriver.InsuranceWind.WindPBbyBuyerAtClosing.FASetText("2500");
                FastDriver.InsuranceWind.WindBPbyOthers.FASetText("2000");
                FastDriver.InsuranceWind.DropdownWind.FASelectItem("POC-L");
                FastDriver.InsuranceWind.SwitchToDialogBottomFrame();
                FastDriver.InsuranceWind.PPDDone.FAClick();
                FastDriver.InsuranceWind.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad().EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.FindGAB("246");
                FastDriver.InsuranceEarth.EarthBuyerCharge.FASetText("1000");
                FastDriver.InsuranceEarth.EarthSellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Lease setup
                Reports.TestStep = "Navigate to the Lease screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("420");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("32500000000");
                FastDriver.LeaseDetail.SellerCharge.FASetText("3600");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                FastDriver.LeaseDetail.SwitchToDialogContentFrame();
                FastDriver.LeaseDetail.LeaseBPbySellerAtClosing.FASetText("3200");
                FastDriver.LeaseDetail.LeaseOthersSeller.FASetText("400");
                FastDriver.LeaseDetail.DropdownLease.FASelectItem("POC-L");
                FastDriver.LeaseDetail.SwitchToDialogBottomFrame();
                FastDriver.LeaseDetail.PDDdone.FAClick();
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey setup
                Reports.TestStep = "Navigate to the Survey screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("800");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("3000");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("200000");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.SurveyDetail.SwitchToDialogContentFrame();
                FastDriver.SurveyDetail.SurveyPBbyBuyerAtClosing.FASetText("2000");
                FastDriver.SurveyDetail.SurveyBPOthers.FASetText("1000");
                FastDriver.SurveyDetail.DropdoenSurvey.FASelectItem("POC");
                FastDriver.SurveyDetail.SwitchToDialogBottomFrame();
                FastDriver.SurveyDetail.PDDdone.FAClick();
                FastDriver.SurveyDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("30000000000");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.13");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Utility setup
                Reports.TestStep = "Navigate to the Utility screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("boa");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("10000000000");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText("1300");
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                FastDriver.UtilityDetail.SwitchToDialogContentFrame();
                FastDriver.UtilityDetail.UtilityBPbySellerAtClosing.FASetText("1000");
                FastDriver.UtilityDetail.UtilityOthersSeller.FASetText("300");
                FastDriver.UtilityDetail.DropdownUtitlity.FASelectItem("POC-L");
                FastDriver.UtilityDetail.SwitchToDialogBottomFrame();
                FastDriver.UtilityDetail.PDDdone.FAClick();
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.ProrationSellerCredit.FASetText("2000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Outside Escrow Company setup
                Reports.TestStep = "Navigate to the Outside Escrow Company screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("246");
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("Outside Charges" + Keys.Tab);
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FASendKeys("2000");
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FASetText("13000000000");
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToDialogContentFrame();
                FastDriver.OutsideEscrowCompanyDetail.OEPBbyBuyerAtClosing.FASetText("1000");
                FastDriver.OutsideEscrowCompanyDetail.OEBPbyOthers.FASetText("1000");
                FastDriver.OutsideEscrowCompanyDetail.DropdownOE.FASelectItem("POC");
                FastDriver.OutsideEscrowCompanyDetail.SwitchToDialogBottomFrame();
                FastDriver.OutsideEscrowCompanyDetail.PDDdone.FAClick();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Tax Check setup
                Reports.TestStep = "Navigate to the Property Tax Check screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("420");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("3000");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_3.FASetText("200");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_5.FASetText("100");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_2.FASetText("250");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_4.FASetText("250");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToDialogContentFrame();
                FastDriver.PropertyTaxCheck.PTPBbyBuyerAtClosing.FASetText("2000");
                FastDriver.PropertyTaxCheck.PTBPbyOthers.FASetText("1000");
                FastDriver.PropertyTaxCheck.DropdownPT.FASelectItem("POC-L");
                FastDriver.PropertyTaxCheck.SwitchToDialogBottomFrame();
                FastDriver.PropertyTaxCheck.PDDdone.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("10000000000");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("100");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_2.FASetText("700.01");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_2.FASetText("600.36");
                FastDriver.BottomFrame.Done();
                #endregion
                #endregion

                #region Verifying the Subtotal of subsections of Disbursement Paid section by Selecting the individual subtotal checkbox
                Reports.TestStep = "Navigate to Viewsettlement Statement and verify and Select the Subtotal checkboxes for each subsections.";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.GoToButtonHover();
                FastDriver.NCSViewSettlementStatement.GoToDisbursementPaid.FAClick();
                FastDriver.NCSViewSettlementStatement.Disburs_HomeOwnrAssoc_SubtotalCheckbx.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.Disburs_HomeWarranty_SubtotalCheckbx.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.Disburs_InspctnRep_SubtotalCheckbx.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.Disburs_Insurance_SubtotalCheckbx.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.Disburs_Lease_SubtotalCheckbx.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.Disburs_OutsideEscrow_SubtotalCheckbx.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.Disburs_PropertyTaxChk_SubtotalCheckbx.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.Disburs_REBCharges_SubtotalCheckbx.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.Disburs_Survey_SubtotalCheckbx.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.Disburs_Utility_SubtotalCheckbx.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.Disburs_REBCharges_SubtotalCheckbx.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.Disburs_OutsideEscrow_SubtotalCheckbx.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Reports.TestStep = "Verify the Subtotal functionality for subsections in Disbursement Paid section.";
                //Homeowner Association
                Support.AreEqual("Total Homeowner Association", FastDriver.NCSViewSettlementStatement.HomeownerSubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Homeowner Association");
                Support.AreEqual("12,500,007,000.00", FastDriver.NCSViewSettlementStatement.HomeownerSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("3,000.00", FastDriver.NCSViewSettlementStatement.HomeownerSubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.HomeownerSubsection, "Transfer Fee " + "to Lenders Advantage " + "(POC-L 200.00) " + "B: 1,000.00\r\nS: 500.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.HomeownerSubsection, "Association Dues " + "to Lenders Advantage " + "B: 12,500,000,000.00\r\nS: 1,000.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.HomeownerSubsection, "Document Fee " + "to Lenders Advantage " + "B: 1,000.00\r\nS: 500.00", null, null, null, null);
                //Home Warrenty
                Support.AreEqual("Total Home Warranty", FastDriver.NCSViewSettlementStatement.HomewarrentySubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Home warrenty subsection");
                Support.AreEqual("10,000,002,400.00", FastDriver.NCSViewSettlementStatement.HomewarrentySubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("2,500.00", FastDriver.NCSViewSettlementStatement.HomewarrentySubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.HomewarrentySubsection, "Home Warranty " + "to Chase Manhattan Mortgage Corporation " + "B: 10,000,000,000.00\r\nS: 1,000.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.HomewarrentySubsection, "Home Warranty - Early Coverage " + "to Chase Manhattan Mortgage Corporation" + " (POC 1,500.00) " + "B: 2,400.00\r\nS: 1,500.00", null, null, null, null);
                //Inspection/Repair
                Support.AreEqual("Total Inspection", FastDriver.NCSViewSettlementStatement.InspectionSubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Inspection/Repair subsection");
                Support.AreEqual("50,000,002,500.00", FastDriver.NCSViewSettlementStatement.InspectionSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("3,000.00", FastDriver.NCSViewSettlementStatement.InspectionSubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.InspectionSubsection, "Pest Inspection " + "to First American Title Company " + "B: 50,000,000,000.00\r\nS: 1,000.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.InspectionSubsection, "Septic Inspection " + "to Lenders Advantage A Division Of First American Title Ins." + " (POC 3,000.00) " + "B: 2,000.00\r\nS: 1,000.00", null, null, null, null);
                //Insurance
                Support.AreEqual("Total Insurance", FastDriver.NCSViewSettlementStatement.InsuranceSubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Insurance");
                Support.AreEqual("10,000,004,000.00", FastDriver.NCSViewSettlementStatement.InsuranceSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "VErify the Buyer subtotal amount");
                Support.AreEqual("3,500.00", FastDriver.NCSViewSettlementStatement.InsuranceSubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.InsuranceSubsection, "Homeowner's Insurance Premium " + "to The Northern Trust Company " + "B: 10,000,000,000.00\r\nS: 500.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.InsuranceSubsection, "Wind Insurance Premium " + "to The Northern Trust Company" + " (POC-L 2,000.00) " + "B: 2,500.00\r\nS: 1,000.00", null, null, null, null);
                //Lease
                Support.AreEqual("Total Lease", FastDriver.NCSViewSettlementStatement.LeaseSubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the Subtotal header for Lease subsection");
                Support.AreEqual("32,500,000,000.00", FastDriver.NCSViewSettlementStatement.LeaseSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer amount");
                Support.AreEqual("3,200.00", FastDriver.NCSViewSettlementStatement.LeaseSubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verfiy the Seller amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.LeaseSubsection, "Rent/Lease Payment Due " + "to The Northern Trust Company" + " (POC-L 400.00) " + "B: 32,500,000,000.00\r\nS: 3,200.00", null, null, null, null);
                //Propert Tax Check
                Support.AreEqual("Total Property Tax Check", FastDriver.NCSViewSettlementStatement.PropertySubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Property Tax check subsection");
                Support.AreEqual("10,000,001,699.64", FastDriver.NCSViewSettlementStatement.PropertySubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("100.01", FastDriver.NCSViewSettlementStatement.PropertySubsection.PerformTableAction(2, 6, TableAction.GetText).Message, "verify the Seller subtotal amount is displayed in Seller Credit column as Seller credit is greater than Seller Charge");
                verifytheData(FastDriver.NCSViewSettlementStatement.PropertySubsection, "Property Taxes " + "to The Northern Trust Company" + " (POC-L 1,000.00) " + "B: 2,000.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.PropertySubsection, "Tax Installment: Interest Due " + "to Lenders Advantage A Division Of First American Title Ins. " + "B: (600.36)\r\nS: (700.01)", null, null, null, null);//Buyer credit and Seller credit should be inside Brackets
                //Survey
                Support.AreEqual("Total Survey", FastDriver.NCSViewSettlementStatement.SurverySubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "VErify the subtotal header for Survey Subsection");
                Support.AreEqual("30,000,002,000.00", FastDriver.NCSViewSettlementStatement.SurverySubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("200,001.13", FastDriver.NCSViewSettlementStatement.SurverySubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller Subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.SurverySubsection, "Survey " + "to First American Title Company " + "(POC 1,000.00) " + "B: 2,000.00\r\nS: 200,000.00", null, null, null, null);
                //Utility
                Support.AreEqual("Total Utility", FastDriver.NCSViewSettlementStatement.UtilitySubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Utility subsection");
                Support.AreEqual("10,000,000,000.00", FastDriver.NCSViewSettlementStatement.UtilitySubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("1,000.00", FastDriver.NCSViewSettlementStatement.UtilitySubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verfiy the Seller subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.UtilitySubsection, "Utilities " + "to Bank of America" + " (POC-L 300.00) " + "B: 10,000,000,000.00\r\nS: 1,000.00", null, null, null, null);
                //REB
                Support.AreEqual("Total Real Estate Broker", FastDriver.NCSViewSettlementStatement.REBSubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for REB subsection");
                Support.AreEqual("20,000,000,000.00", FastDriver.NCSViewSettlementStatement.REBSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("10,000.00", FastDriver.NCSViewSettlementStatement.REBSubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller sutotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.REBSubsection, "General Excise Tax " + "to First American Title Company " + "B: 20,000,000,000.00", null, null, null, null);
                //Outside Escrow
                Support.AreEqual("Total Outside Escrow", FastDriver.NCSViewSettlementStatement.OutsideSubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Outside Escrow subsection");
                Support.AreEqual("1,000.00", FastDriver.NCSViewSettlementStatement.OutsideSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("13,000,000,000.00", FastDriver.NCSViewSettlementStatement.OutsideSubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.OutsideSubsection, "Outside Charges " + "to Chase Manhattan Mortgage Corporation" + " (POC 1,000.00) " + "B: 1,000.00\r\nS: 13,000,000,000.00", null, null, null, null);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verifying the Subtotal of subsections of Disbursement Paid section by Selecting the Select All checkbox
                Reports.TestStep = "Navigate to Viewsettkement Statement and verify and Select the Select All Subtotal checkbox.";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.SelectAll_SubtotalsCheckbox.FAClick();
                Reports.TestStep = "Verify the Subtotal functionality for subsections in Disbursement Paid section.";
                //Homeowner Association
                Support.AreEqual("Total Homeowner Association", FastDriver.NCSViewSettlementStatement.HomeownerSubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Homeowner Association");
                Support.AreEqual("12,500,007,000.00", FastDriver.NCSViewSettlementStatement.HomeownerSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("3,000.00", FastDriver.NCSViewSettlementStatement.HomeownerSubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.HomeownerSubsection, "Transfer Fee " + "to Lenders Advantage " + "(POC-L 200.00) " + "B: 1,000.00\r\nS: 500.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.HomeownerSubsection, "Association Dues " + "to Lenders Advantage " + "B: 12,500,000,000.00\r\nS: 1,000.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.HomeownerSubsection, "Document Fee " + "to Lenders Advantage " + "B: 1,000.00\r\nS: 500.00", null, null, null, null);
                //Home Warrenty
                Support.AreEqual("Total Home Warranty", FastDriver.NCSViewSettlementStatement.HomewarrentySubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Home warrenty subsection");
                Support.AreEqual("10,000,002,400.00", FastDriver.NCSViewSettlementStatement.HomewarrentySubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("2,500.00", FastDriver.NCSViewSettlementStatement.HomewarrentySubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.HomewarrentySubsection, "Home Warranty " + "to Chase Manhattan Mortgage Corporation " + "B: 10,000,000,000.00\r\nS: 1,000.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.HomewarrentySubsection, "Home Warranty - Early Coverage " + "to Chase Manhattan Mortgage Corporation" + " (POC 1,500.00) " + "B: 2,400.00\r\nS: 1,500.00", null, null, null, null);
                //Inspection/Repair
                Support.AreEqual("Total Inspection", FastDriver.NCSViewSettlementStatement.InspectionSubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Inspection/Repair subsection");
                Support.AreEqual("50,000,002,500.00", FastDriver.NCSViewSettlementStatement.InspectionSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("3,000.00", FastDriver.NCSViewSettlementStatement.InspectionSubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.InspectionSubsection, "Pest Inspection " + "to First American Title Company " + "B: 50,000,000,000.00\r\nS: 1,000.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.InspectionSubsection, "Septic Inspection " + "to Lenders Advantage A Division Of First American Title Ins." + " (POC 3,000.00) " + "B: 2,000.00\r\nS: 1,000.00", null, null, null, null);
                //Insurance
                Support.AreEqual("Total Insurance", FastDriver.NCSViewSettlementStatement.InsuranceSubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Insurance");
                Support.AreEqual("10,000,004,000.00", FastDriver.NCSViewSettlementStatement.InsuranceSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "VErify the Buyer subtotal amount");
                Support.AreEqual("3,500.00", FastDriver.NCSViewSettlementStatement.InsuranceSubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.InsuranceSubsection, "Homeowner's Insurance Premium " + "to The Northern Trust Company " + "B: 10,000,000,000.00\r\nS: 500.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.InsuranceSubsection, "Wind Insurance Premium " + "to The Northern Trust Company" + " (POC-L 2,000.00) " + "B: 2,500.00\r\nS: 1,000.00", null, null, null, null);
                //Lease
                Support.AreEqual("Total Lease", FastDriver.NCSViewSettlementStatement.LeaseSubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the Subtotal header for Lease subsection");
                Support.AreEqual("32,500,000,000.00", FastDriver.NCSViewSettlementStatement.LeaseSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer amount");
                Support.AreEqual("3,200.00", FastDriver.NCSViewSettlementStatement.LeaseSubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verfiy the Seller amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.LeaseSubsection, "Rent/Lease Payment Due " + "to The Northern Trust Company" + " (POC-L 400.00) " + "B: 32,500,000,000.00\r\nS: 3,200.00", null, null, null, null);
                //Propert Tax Check
                Support.AreEqual("Total Property Tax Check", FastDriver.NCSViewSettlementStatement.PropertySubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Property Tax check subsection");
                Support.AreEqual("10,000,001,699.64", FastDriver.NCSViewSettlementStatement.PropertySubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("100.01", FastDriver.NCSViewSettlementStatement.PropertySubsection.PerformTableAction(2, 6, TableAction.GetText).Message, "verify the Seller subtotal amount is displayed in Seller Credit column as Seller credit is greater than Seller Charge");
                verifytheData(FastDriver.NCSViewSettlementStatement.PropertySubsection, "Property Taxes " + "to The Northern Trust Company" + " (POC-L 1,000.00) " + "B: 2,000.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.PropertySubsection, "Tax Installment: Interest Due " + "to Lenders Advantage A Division Of First American Title Ins. " + "B: (600.36)\r\nS: (700.01)", null, null, null, null);//Buyer credit and Seller credit should be inside Brackets
                //Survey
                Support.AreEqual("Total Survey", FastDriver.NCSViewSettlementStatement.SurverySubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "VErify the subtotal header for Survey Subsection");
                Support.AreEqual("30,000,002,000.00", FastDriver.NCSViewSettlementStatement.SurverySubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("200,001.13", FastDriver.NCSViewSettlementStatement.SurverySubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller Subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.SurverySubsection, "Survey " + "to First American Title Company " + "(POC 1,000.00) " + "B: 2,000.00\r\nS: 200,000.00", null, null, null, null);
                //Utility
                Support.AreEqual("Total Utility", FastDriver.NCSViewSettlementStatement.UtilitySubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Utility subsection");
                Support.AreEqual("10,000,000,000.00", FastDriver.NCSViewSettlementStatement.UtilitySubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("1,000.00", FastDriver.NCSViewSettlementStatement.UtilitySubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verfiy the Seller subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.UtilitySubsection, "Utilities " + "to Bank of America" + " (POC-L 300.00) " + "B: 10,000,000,000.00\r\nS: 1,000.00", null, null, null, null);
                //REB
                Support.AreEqual("Total Real Estate Broker", FastDriver.NCSViewSettlementStatement.REBSubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for REB subsection");
                Support.AreEqual("20,000,000,000.00", FastDriver.NCSViewSettlementStatement.REBSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("10,000.00", FastDriver.NCSViewSettlementStatement.REBSubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller sutotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.REBSubsection, "General Excise Tax " + "to First American Title Company " + "B: 20,000,000,000.00", null, null, null, null);
                //Outside Escrow
                Support.AreEqual("Total Outside Escrow", FastDriver.NCSViewSettlementStatement.OutsideSubsection.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify the subtotal header for Outside Escrow subsection");
                Support.AreEqual("1,000.00", FastDriver.NCSViewSettlementStatement.OutsideSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                Support.AreEqual("13,000,000,000.00", FastDriver.NCSViewSettlementStatement.OutsideSubsection.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify the Seller subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.OutsideSubsection, "Outside Charges " + "to Chase Manhattan Mortgage Corporation" + " (POC 1,000.00) " + "B: 1,000.00\r\nS: 13,000,000,000.00", null, null, null, null);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Subtotal after Adding/Editing the charges
                Reports.TestStep = "Navigate to Homeowner Association and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge4.FASetText("3000");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to Home Warranty and Edit values to seller.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("2000");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to Inspection Repair Pest screen and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.buyerCharge1.FASetText("5000");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Verify the Subtotal after adding the Charges.";
                Reports.TestStep = "Navigate to Viewsettkement Statement and verify and Select the Select All Subtotal checkbox after adding charges.";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                //Homeowner Association
                Support.AreEqual("12,500,010,000.00", FastDriver.NCSViewSettlementStatement.HomeownerSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.HomeownerSubsection, "HOA Capital Contribution " + "to Lenders Advantage " + "B: 3,000.00", null, null, null, null);
                //Homewarrenty
                Support.AreEqual("4,400.00", FastDriver.NCSViewSettlementStatement.HomewarrentySubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.HomewarrentySubsection, "Home Warranty " + "to Chase Manhattan Mortgage Corporation " + "B: 2,000.00\r\nS: 1,000.00", null, null, null, null);
                //Inspection/Repair
                Support.AreEqual("50,000,007,500.00", FastDriver.NCSViewSettlementStatement.InspectionSubsection.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify the Buyer subtotal amount");
                verifytheData(FastDriver.NCSViewSettlementStatement.InspectionSubsection, "Pest Repair " + "to First American Title Company " + "B: 5,000.00", null, null, null, null);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Subtotal after Deleting the charges
                Reports.TestStep = "Navigate to the Lease screen and Delete values for buyer charges.";
                Playback.Wait(4000);
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease");
                Playback.Wait(4000);
                FastDriver.LeaseDetail.BuyerCharge.FASetText("0.00");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to the Utility screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("0.00");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Verify the Subtotal after adding the Charges.";
                Reports.TestStep = "Navigate to Viewsettkement Statement and verify and Select the Select All Subtotal checkbox after deleting the charges.";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                //Lease
                verifytheData(FastDriver.NCSViewSettlementStatement.LeaseSubsection, "Rent/Lease Payment Due " + "to The Northern Trust Company" + " (POC-L 400.00) " + "S: 3,200.00", null, null, null, null);
                //Utility
                verifytheData(FastDriver.NCSViewSettlementStatement.UtilitySubsection, "Utilities " + "to Bank of America" + " (POC-L 300.00) " + "S: 1,000.00", null, null, null, null);
                #endregion

                #region Verify Subtotal for Refinance file
                Reports.TestStep = "Navigate to Filehomepage and Change the Transaction Type to Refinanace.";
                FastDriver.FileHomepage.Open();
                //FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                //FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Refinance");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to Viewsettkement Statement and verify the Subtotal and verify whether the Seller information is displayed.";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                //Homeowner Association
                verifytheData(FastDriver.NCSViewSettlementStatement.HomeownerSubsection, "Transfer Fee " + "to Lenders Advantage " + "(POC-L 200.00) " + "B: 1,000.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.HomeownerSubsection, "Association Dues " + "to Lenders Advantage " + "B: 12,500,000,000.00", null, null, null, null);
                //Home Warrenty
                verifytheData(FastDriver.NCSViewSettlementStatement.HomewarrentySubsection, "Home Warranty " + "to Chase Manhattan Mortgage Corporation " + "B: 2,000.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.HomewarrentySubsection, "Home Warranty - Early Coverage " + "to Chase Manhattan Mortgage Corporation " + "B: 2,400.00", null, null, null, null);
                //Inspection/Repair
                verifytheData(FastDriver.NCSViewSettlementStatement.InspectionSubsection, "Pest Inspection " + "to First American Title Company " + "B: 50,000,000,000.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.InspectionSubsection, "Septic Inspection " + "to Lenders Advantage A Division Of First American Title Ins." + " (POC 3,000.00) " + "B: 2,000.00", null, null, null, null);
                //Insurance
                verifytheData(FastDriver.NCSViewSettlementStatement.InsuranceSubsection, "Homeowner's Insurance Premium " + "to The Northern Trust Company " + "B: 10,000,000,000.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.InsuranceSubsection, "Wind Insurance Premium " + "to The Northern Trust Company" + " (POC-L 2,000.00) " + "B: 2,500.00", null, null, null, null);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify the Resequencing of Charges and Subsections with Subtotal
                Reports.TestStep = "Navigate to Viewsettlement Statement and Perform resequencing.";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                //Charge resequencing
                //FastDriver.NCSViewSettlementStatement.From_HomeownerAssociation.FADragAndDropWithOffset(FastDriver.NCSViewSettlementStatement.To_CertificateLetter, offsetY: 20);
                //FastDriver.NCSViewSettlementStatement.From_PestCharge.FADragAndDropWithOffset(FastDriver.NCSViewSettlementStatement.To_SepticCharge, offsetY: 20);
                //Subsection Resequencing
                FastDriver.NCSViewSettlementStatement.From_HomeownerAssociation.FADragAndDrop(FastDriver.NCSViewSettlementStatement.To_Insurance);
                FastDriver.NCSViewSettlementStatement.From_InspectionRepair.FADragAndDrop(FastDriver.NCSViewSettlementStatement.To_OutsideEscrow);
                Reports.TestStep = "Verify the Charges and Subsections resequenced Positions.";
                //Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.HomewarrentySubsection.PerformTableAction(5, 3, TableAction.GetText).Message.Equals("Association Dues to Lenders Advantage B: 12,500,000,000.00").ToString());
                //Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.HomewarrentySubsection.PerformTableAction(5, 3, TableAction.GetText).Message.Equals("Pest Repair to First American Title Company B: 5,000.00").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.HomewarrentySubsection.PerformTableAction(1, 4, TableAction.GetText).Message.Contains("Homeowner Association").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.SurverySubsection.PerformTableAction(1, 4, TableAction.GetText).Message.Contains("Inspection/Repair").ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0135_REG0012()
        {
            try
            {

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region LOGINTO ADM SERVER
                Reports.TestStep = "login to the ADM Side.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                #endregion

                #region Select Region
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                #endregion

                #region Navigate to Fee Summary and Create a Fee.
                Reports.TestStep = "Alternate Course 1:  Add a new fee";
                FastDriver.LeftNavigation.Navigate<FeeList2>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitScreenToLoad();
                FastDriver.FeeList2.WaitScreenToLoad();

                string Fee_Des = Support.RandomString("ANANA");
                string Fee_Code = Support.RandomString("ANANA");

                Reports.TestStep = "Create A Fee with in Fee Setup.";
                FastDriver.FeeSetup.CreateFeeWithDefaultValues(Fee_Des, Fee_Code, "Escrow Fee");

                Reports.TestStep = "Main Course - Verify Fee is created succesfully in Fee Setup with Fee Code " + Fee_Des + " and Fee Description " + Fee_Des;
                FastDriver.FeeList2.CheckFeeCodeExistsOnFeeTable(Fee_Code, "Escrow Fee", Fee_Des);

                Reports.TestStep = "Select the Fee with Fee Code " + Fee_Des + " and Fee Description " + Fee_Des + " and Change the description";
                FastDriver.FeeList2.FeeTable.PerformTableAction(3, Fee_Code, 3, TableAction.Click);

                FastDriver.FeeList2.Edit.FAClick();


                FastDriver.FeeSetup.WaitForScreenToLoad();

                FastDriver.FeeSetup.ThirdPartyPayee.FAClick();
                FastDriver.BottomFrame.Done();



                #endregion



                #region Loginto IIs and create file with business segment as commercial
                Reports.TestStep = "Loginto IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create file with business segment as commercial";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.Click();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Accommodation");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("Firstamway");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();


                #endregion



                #region Navigate to Newloan screen add lender and Mortgage Broker and save
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("255");
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.MortgageFindGABCode("HUDLEASE01");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Fee Entry and save the fees to the file
                Reports.TestStep = "Navigate to Fee Entry and save the fees to the file";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");

                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Document Preparation - Deed");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFeeTable.PerformTableAction("#2", "Document Preparation - Deed", "#1", TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CA Withhold Assistance Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFeeTable.PerformTableAction("#2", "CA Withhold Assistance Fee", "#1", TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Check Fee - Additional");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFeeTable.PerformTableAction("#2", "Check Fee - Additional", "#1", TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Closing Service Coordination");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFeeTable.PerformTableAction("#2", "Closing Service Coordination", "#1", TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Document Preparation");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFeeTable.PerformTableAction("#2", "Document Preparation", "#1", TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SearchFees("Escrow Fee", "Escrow Fee");
                FastDriver.FileFees.SelectFirstFromFeeResultsTable();
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SearchFees("Escrow Fee", Fee_Des);
                FastDriver.FileFees.SelectFirstFromFeeResultsTable();
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SearchFees("Recording Fee - Deed", "Record Deed");
                FastDriver.FileFees.SelectFirstFromFeeResultsTable();
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.PayRecordingTax);
                FastDriver.FileFees.RecordingTable.PerformTableAction("Description", "Record Deed", "Sel", TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction("Description", "Record Deed", "Buyer Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.FileFees.RecordingTable.PerformTableAction("Description", "Record Deed", "Seller Charge", TableAction.SetText, "3.99" + FAKeys.Tab);
                FastDriver.FileFees.PayRecordingTax.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.WaitForScreenToLoad();
                FastDriver.RecordFeeTransferTaxDisb.New.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.WaitCreation(FastDriver.RecordFeeTransferTaxDisb.GABcode);
                FastDriver.RecordFeeTransferTaxDisb.GABcode.FASetText("HUDLEASE01");
                FastDriver.RecordFeeTransferTaxDisb.Find.FAClick();
                Reports.TestStep = "Select all fees";
                FastDriver.RecordFeeTransferTaxDisb.WaitForScreenToLoad(FastDriver.RecordFeeTransferTaxDisb.All);
                FastDriver.RecordFeeTransferTaxDisb.All.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandEscrow.FAClick();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Document Preparation - Deed", "Buyer Charge", TableAction.SetText, "923.22");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Document Preparation - Deed", "Seller Charge", TableAction.SetText, "121.44");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "CA Withhold Assistance Fee", "Buyer Charge", TableAction.SetText, "30.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "CA Withhold Assistance Fee", "Seller Charge", TableAction.SetText, "40");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Check Fee - Additional", "Buyer Charge", TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Closing Service Coordination", "Seller Charge", TableAction.SetText, "60");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Document Preparation", "Buyer Charge", TableAction.SetText, "80.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Document Preparation", "Seller Charge", TableAction.SetText, "140");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Escrow Fee", "Buyer Charge", TableAction.SetText, "90.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "Escrow Fee", "Seller Charge", TableAction.SetText, "240.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", Fee_Des, "Buyer Charge", TableAction.SetText, "80.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", Fee_Des, "Seller Charge", TableAction.SetText, "140");
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("Document Preparation", 24.2, 31.23, 56.78, "Mortgage Broker", 674.2, 34.56, 24.55, "Lender", false, false, false, false);
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, Fee_Des, 3, TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                FastDriver.PaymentDetails.GfeThirdPartyNameDefault.FASetText("Third Party");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileFees.WaitForScreenToLoad();
                #endregion

                #region Navigate to View Settlement statement screen and verify for the subtotal functionality
                Reports.TestStep = "Navigate to View Settlement statement screen and verify for the subtotal functionality";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                #region Verify the charges under Title/Escrow Charges section without subtotal
                Reports.TestStep = "Verify the charges under Title/Escrow Charges section without subtotal";
            
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.TitleEscrow_SubtotalCheckbox.Exists(), "Verify Subtotal checkbox exists under Title Escrow Charges section");

                Support.AreEqual("923.22", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 2, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                Support.AreEqual("121.44", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("32.85", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(4, 2, TableAction.GetText).Message, "Verify Buyer charge without subtotal");
                Support.AreEqual("43.80", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(4, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("50.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(5, 2, TableAction.GetText).Message, "Verify Buyer charge without subtotal");
                Support.AreEqual("60.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(6, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("24.20", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(7, 2, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("674.20", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(7, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("90.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(8, 2, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("240.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(8, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("87.60", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(9, 2, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("153.30", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(9, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("2.99", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(10, 2, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("3.99", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(10, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");

                Support.AreEqual("Document Preparation - Deed to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("CA Withhold Assistance Fee to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(4, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Check Fee - Additional to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(5, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Closing Service Coordination to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(6, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Document Preparation to QA Automation Office - DO NOT TOUCH POC-L $24.55,POC-MB $56.78,POC-B $31.23,POC-S $34.56", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(7, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Escrow Fee to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(8, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                string actualwouts = Fee_Des + " to Third Party";
                Support.AreEqual(actualwouts, FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(9, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Record Deed to Lease 1 for HUD Testing Name 1 Lease 1 f", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(10, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                #endregion

                #region Verify the subtotal header row and total charges under Title/Escrow Charges section with subtotal
                FastDriver.NCSViewSettlementStatement.TitleEscrow_SubtotalCheckbox.FAClick();
                Reports.TestStep = "Verify subtotal checkbox selection is saved via Auto save and verify the charges";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Reports.TestStep = "Verify the subtotal header row and total charges under Title/Escrow Charges section with subtotal";
                Support.AreEqual("Total to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 4, TableAction.GetText).Message, "Verify Subtotal header row");
                Support.AreEqual("1,210.86", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 2, TableAction.GetText).Message, "Verify Subtotal Buyer charge");
                Support.AreEqual("1,296.73", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 5, TableAction.GetText).Message, "Verify  Subtotal Seller charge");
                Support.AreEqual("Document Preparation - Deed B: 923.22\r\nS: 121.44", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(4, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("CA Withhold Assistance Fee B: 32.85\r\nS: 43.80", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(5, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("Check Fee - Additional B: 50.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(6, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("Closing Service Coordination S: 60.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(7, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("Document Preparation (POC-L 24.55,POC-MB 56.78,POC-B 31.23,POC-S 34.56) B: 24.20\r\nS: 674.20", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(8, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Escrow Fee B: 90.00\r\nS: 240.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(9, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                string actualws = Fee_Des + " to Third Party B: 87.60\r\nS: 153.30";
                Support.AreEqual(actualws, FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(10, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("Record Deed to Lease 1 for HUD Testing Name 1 Lease 1 f B: 2.99\r\nS: 3.99", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(11, 4, TableAction.GetText).Message, "Verify fee description with subtotal");

                #endregion


                Reports.TestStep = "Deselect the subtotal checkbox and save and then again select the subtotal checkbox";
                FastDriver.NCSViewSettlementStatement.TitleEscrow_SubtotalCheckbox.FASetCheckbox(false);
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.TitleEscrow_SubtotalCheckbox.FASetCheckbox(true);

                #region Verify Subtotal checkbox is unchecked on click of Reset button in View SS screen
                Reports.TestStep = "Verify Subtotal checkbox is unchecked on click of Reset button in View SS screen";
                FastDriver.BottomFrame.Reset();
                FastDriver.ViewSettlementStatement.SwitchToContentFrame();

                Support.AreEqual("923.22", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 2, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                Support.AreEqual("121.44", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("32.85", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(4, 2, TableAction.GetText).Message, "Verify Buyer charge without subtotal");
                Support.AreEqual("43.80", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(4, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("50.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(5, 2, TableAction.GetText).Message, "Verify Buyer charge without subtotal");
                Support.AreEqual("60.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(6, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("24.20", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(7, 2, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("674.20", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(7, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("90.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(8, 2, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("240.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(8, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("87.60", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(9, 2, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("153.30", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(9, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("2.99", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(10, 2, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("3.99", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(10, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");

                Support.AreEqual("Document Preparation - Deed to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("CA Withhold Assistance Fee to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(4, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Check Fee - Additional to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(5, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Closing Service Coordination to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(6, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Document Preparation to QA Automation Office - DO NOT TOUCH POC-L $24.55,POC-MB $56.78,POC-B $31.23,POC-S $34.56", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(7, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Escrow Fee to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(8, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual(actualwouts, FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(9, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Record Deed to Lease 1 for HUD Testing Name 1 Lease 1 f", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(10, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                #endregion
                #region Select the Select All checkbox,click on Done and verify subtotal checkbox under Title/Escrow Charges section is checked
                Reports.TestStep = "Select the Select All checkbox and verify subtotal checkbox under Title/Escrow Charges section is checked";
                FastDriver.NCSViewSettlementStatement.MarkSelectAllCheckBox();

                Reports.TestStep = " Verify Subtotal checkbox selection is saved on click of Done button";

                FastDriver.BottomFrame.Done();
                FastDriver.ViewSettlementStatement.SwitchToContentFrame();
                FastDriver.ViewSettlementStatement.WaitForScreenToLoad();

                Support.AreEqual("true", FastDriver.NCSViewSettlementStatement.TitleEscrow_SubtotalCheckbox.GetAttribute("checked"));
                Support.AreEqual("Total to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 4, TableAction.GetText).Message, "Verify Subtotal header row");
                Support.AreEqual("1,210.86", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 2, TableAction.GetText).Message, "Verify Subtotal Buyer charge");
                Support.AreEqual("1,296.73", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 5, TableAction.GetText).Message, "Verify  Subtotal Seller charge");
                Support.AreEqual("Document Preparation - Deed B: 923.22\r\nS: 121.44", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(4, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("CA Withhold Assistance Fee B: 32.85\r\nS: 43.80", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(5, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("Check Fee - Additional B: 50.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(6, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("Closing Service Coordination S: 60.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(7, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("Document Preparation (POC-L 24.55,POC-MB 56.78,POC-B 31.23,POC-S 34.56) B: 24.20\r\nS: 674.20", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(8, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("Escrow Fee B: 90.00\r\nS: 240.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(9, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual(actualws, FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(10, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("Record Deed to Lease 1 for HUD Testing Name 1 Lease 1 f B: 2.99\r\nS: 3.99", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(11, 4, TableAction.GetText).Message, "Verify fee description with subtotal");

                #endregion
                #region Deselect the subtotal checkbox under Title/Escrow charges section and verify the charges without subtotal
                Reports.TestStep = "Deselect the subtotal checkbox under Title/Escrow charges section and verify the charges without subtotal";
                FastDriver.NCSViewSettlementStatement.TitleEscrow_SubtotalCheckbox.FASetCheckbox(false);
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                #region Verify the charges under Title/Escrow Charges section without subtotal
                Reports.TestStep = "Verify the charges under Title/Escrow Charges section without subtotal";
                Support.AreEqual("923.22", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 2, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                Support.AreEqual("121.44", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("32.85", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(4, 2, TableAction.GetText).Message, "Verify Buyer charge without subtotal");
                Support.AreEqual("43.80", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(4, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("50.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(5, 2, TableAction.GetText).Message, "Verify Buyer charge without subtotal");
                Support.AreEqual("60.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(6, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("24.20", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(7, 2, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("674.20", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(7, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("90.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(8, 2, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("240.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(8, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("87.60", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(9, 2, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("153.30", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(9, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("2.99", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(10, 2, TableAction.GetText).Message, "Verify Seller charge without subtotal");
                Support.AreEqual("3.99", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(10, 5, TableAction.GetText).Message, "Verify Seller charge without subtotal");

                Support.AreEqual("Document Preparation - Deed to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("CA Withhold Assistance Fee to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(4, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Check Fee - Additional to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(5, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Closing Service Coordination to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(6, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Document Preparation to QA Automation Office - DO NOT TOUCH POC-L $24.55,POC-MB $56.78,POC-B $31.23,POC-S $34.56", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(7, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Escrow Fee to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(8, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual(actualwouts, FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(9, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                Support.AreEqual("Record Deed to Lease 1 for HUD Testing Name 1 Lease 1 f", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(10, 4, TableAction.GetText).Message, "Verify fee description without subtotal");
                FastDriver.NCSViewSettlementStatement.TitleEscrow_SubtotalCheckbox.FASetCheckbox(true);
                #endregion


                #endregion


                #endregion



                #region Verify the subtoal functionality in view SS for Refinance files
                Reports.TestStep = " Navigate to FHP and change the transaction type to Refinance and verify the subtoal functionality in view SS for Refinance files";
                #region Navigate to FHP and change the transaction type to Refinance

                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Refinance");
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to View SS and verify the display in View SS for refinance file with subtotal checkbox selected
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.NCSViewSettlementStatement.TitleEscrow_SubtotalCheckbox.GetAttribute("checked"));
                Support.AreEqual("Total to QA Automation Office - DO NOT TOUCH", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 4, TableAction.GetText).Message, "Verify Subtotal header row");
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreEqual("1,210.86", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(3, 2, TableAction.GetText).Message, "Verify Subtotal Buyer charge");


                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.fees_sellertot.FAGetText().Equals("").ToString(), "Verify  Subtotal Seller charge is blank");

                Support.AreEqual("Document Preparation - Deed B: 923.22", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(4, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("CA Withhold Assistance Fee B: 32.85", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(5, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("Check Fee - Additional B: 50.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(6, 4, TableAction.GetText).Message, "Verify fee description with subtotal");

                Support.AreEqual("Document Preparation (POC-MB 56.78,POC-B 31.23) B: 24.20", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(7, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("Escrow Fee B: 90.00", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(8, 4, TableAction.GetText).Message, "Verify fee description with subtotal");

                string actualrws = Fee_Des + " to Third Party B: 87.60";

                Support.AreEqual(actualrws, FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(9, 4, TableAction.GetText).Message, "Verify fee description with subtotal");
                Support.AreEqual("Record Deed to Lease 1 for HUD Testing Name 1 Lease 1 f B: 2.99", FastDriver.NCSViewSettlementStatement.feestable.PerformTableAction(10, 4, TableAction.GetText).Message, "Verify fee description with subtotal");



                #endregion
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);

            }

        }
        [TestMethod]
        public void FMUC0135_REG0014()
        {
            Reports.TestDescription = "US# 779319- To verify the subtotal functionality under Commission section";
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion
                #region Loginto IIs and create file with business segment as commercial
                Reports.TestStep = "Loginto IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create file with business segment as commercial";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.Click();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Accommodation");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("Firstamway");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();


                #endregion

                #region Navigate to REB screen and create REB instances with REB charges
                Reports.TestStep = "Navigate to REB screen and create REB instances with REB charges";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(8000);
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDFLINSR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("200.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("300.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Description1" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("20.00" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText("30.00" + FAKeys.Tab);

                Keyboard.SendKeys("{TAB}");

                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription2.FASetText("Description2" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit2.FASetText("10.00" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit1.FASetText("40.00" + FAKeys.Tab);
                Keyboard.SendKeys("{TAB}");
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText("POC Description1" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("60.00" + FAKeys.Tab);
                Keyboard.SendKeys("{TAB}");

                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(8000);
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDLEASE01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("400.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("100.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Description3" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("600.00" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText("150.00" + FAKeys.Tab);
                Keyboard.SendKeys("{TAB}");
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText("POC Description3" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("26.66" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Playback.Wait(8000);
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("255");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();

                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("12,345,678,912.22" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Description4" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("12,456,789,230.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Playback.Wait(8000);
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDLEASE02");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("56.55" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("3.55" + FAKeys.Tab);





                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText("POC Description4" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("20.50" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to View Settlement statement screen and verify for the subtotal functionality
                Reports.TestStep = "Navigate to View Settlement statement screen and verify for the subtotal functionality";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                #region Verify the charges under Commision section without subtotal
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.Exists(), "Verify Subtotal checkbox exists under Title Escrow Charges section");
                Support.AreEqual("Broker: Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(1, 4, TableAction.GetText).Message, "Verify Commision description without subtotal");
                Support.AreEqual("Real Estate Commission to Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify Commision description without subtotal");
                Support.AreEqual("Description3 to Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(3, 4, TableAction.GetText).Message, "Verify Commision description without subtotal");
                Support.AreEqual("POC Description3 to Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2 POC $26.66", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(4, 4, TableAction.GetText).Message, "Verify Commision description  without subtotal");

                Support.AreEqual("400.00", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify Commision description without subtotal");
                Support.AreEqual("100.00", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify Commision description  without subtotal");
                Support.AreEqual("600.00", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(3, 3, TableAction.GetText).Message, "Verify Commision description without subtotal");
                Support.AreEqual("150.00", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(3, 6, TableAction.GetText).Message, "Verify Commision description  without subtotal");

                Support.AreEqual("Broker: Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(1, 4, TableAction.GetText).Message, "Verify commision description without subtotal");
                Support.AreEqual("Real Estate Commission to Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify commision description  without subtotal");
                Support.AreEqual("Description1 to Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(3, 4, TableAction.GetText).Message, "Verify commision description without subtotal");
                Support.AreEqual("Description2 to Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(4, 4, TableAction.GetText).Message, "Verify commision description without subtotal");
                Support.AreEqual("POC Description1 to Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2 POC $60.00", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(5, 4, TableAction.GetText).Message, "Verify commision description without subtotal");

                Support.AreEqual("200.00", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                Support.AreEqual("300.00", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                Support.AreEqual("20.00", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(3, 3, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                Support.AreEqual("30.00", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(3, 6, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                Support.AreEqual("10.00", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(4, 3, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                Support.AreEqual("40.00", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(4, 6, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");

                Support.AreEqual("Broker: Thomas Freeman", FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable.PerformTableAction(1, 4, TableAction.GetText).Message, "Verify commision description without subtotal");
                Support.AreEqual("Real Estate Commission to Thomas Freeman", FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify commision description  without subtotal");
                Support.AreEqual("Description4 to Thomas Freeman", FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable.PerformTableAction(3, 4, TableAction.GetText).Message, "Verify commision description without subtotal");

                Support.AreEqual("12,345,678,912.22", FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                Support.AreEqual("12,456,789,230.00", FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable.PerformTableAction(3, 3, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");

                Support.AreEqual("Broker: Lease 2 for HUD Testing Name 1 Lease 2 for HUD Testing Name 2", FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable.PerformTableAction(1, 4, TableAction.GetText).Message, "Verify commision description without subtotal");
                Support.AreEqual("Real Estate Commission to Lease 2 for HUD Testing Name 1 Lease 2 for HUD Testing Name 2", FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable.PerformTableAction(2, 4, TableAction.GetText).Message, "Verify commision description  without subtotal");
                Support.AreEqual("POC Description4 to Lease 2 for HUD Testing Name 1 Lease 2 for HUD Testing Name 2 POC $20.50", FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable.PerformTableAction(3, 4, TableAction.GetText).Message, "Verify commision description without subtotal");

                Support.AreEqual("56.55", FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                Support.AreEqual("3.55", FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                #endregion
                #region Select subtotal checkbox and save via Done button and verify the charges under Commision section with subtotal
                Reports.TestStep = "Select the subtotal checkbox under commision section and save via Done";
                FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                Playback.Wait(15000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Reports.TestStep = "Verification of the display of charges under Commision section with subtotal checkbox selected";
                Support.AreEqual("true", FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.GetAttribute("checked"));
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "Total to Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", null, null, "200.00", "50.00");
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "Real Estate Commission B: 400.00\r\nS: 100.00", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "Description3 B: (600.00)\r\nS: (150.00)", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "POC Description3 (POC 26.66)", null, null, null, null);

                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Total to Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", "170.00", "230.00", null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Real Estate Commission B: 200.00\r\nS: 300.00", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Description1 B: (20.00)\r\nS: (30.00)", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Description2 B: (10.00)\r\nS: (40.00)", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "POC Description1 (POC 60.00)", null, null, null, null);

                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable, "Total to Thomas Freeman", null, "12,345,678,912.22", "12,456,789,230.00", null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable, "Real Estate Commission S: 12,345,678,912.22", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable, "Description4 B: (12,456,789,230.00)", null, null, null, null);

                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable, "Total to Lease 2 for HUD Testing Name 1 Lease 2 for HUD Testing Name 2", "56.55", "3.55", null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable, "Real Estate Commission B: 56.55\r\nS: 3.55", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable, "POC Description4 (POC 20.50)", null, null, null, null);
                #endregion



                #region Deselect the subtotal checkbox and save and then again select the subtotal checkbox
                Reports.TestStep = "Deselect the subtotal checkbox and save and then again select the subtotal checkbox";
                FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                Playback.Wait(15000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Reports.TestStep = "Select the subtotal checkbox and click on Reset ";
                FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.FASetCheckbox(true);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "Total to Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", null, null, "200.00", "50.00");
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Total to Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", "170.00", "230.00", null, null);
                #endregion
                #region Verify the Reset functionality of subtotal checkbox
                FastDriver.BottomFrame.Reset();
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();


                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.IsSelected().ToString());
                Support.AreEqual("Broker: Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(1, 4, TableAction.GetText).Message, "Verify Commision description without subtotal");
                Support.AreEqual("400.00", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify Commision description without subtotal");
                Support.AreEqual("100.00", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify Commision description  without subtotal");
                Support.AreEqual("Broker: Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(1, 4, TableAction.GetText).Message, "Verify commision description without subtotal");

                Support.AreEqual("200.00", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                Support.AreEqual("300.00", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                #endregion
                #region Select the Select All checkbox and save via Autosave and verify subtotal functionality
                Reports.TestStep = "Select the Select All checkbox and save via Autosave and verify subtotal functionality";
                FastDriver.NCSViewSettlementStatement.SelectAll_SubtotalsCheckbox.FASetCheckbox(true);
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.GetAttribute("checked"));
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "Total to Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", null, null, "200.00", "50.00");
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "Real Estate Commission B: 400.00\r\nS: 100.00", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "Description3 B: (600.00)\r\nS: (150.00)", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "POC Description3 (POC 26.66)", null, null, null, null);

                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Total to Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", "170.00", "230.00", null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Real Estate Commission B: 200.00\r\nS: 300.00", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Description1 B: (20.00)\r\nS: (30.00)", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Description2 B: (10.00)\r\nS: (40.00)", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "POC Description1 (POC 60.00)", null, null, null, null);

                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable, "Total to Thomas Freeman", null, "12,345,678,912.22", "12,456,789,230.00", null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable, "Real Estate Commission S: 12,345,678,912.22", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable, "Description4 B: (12,456,789,230.00)", null, null, null, null);

                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable, "Total to Lease 2 for HUD Testing Name 1 Lease 2 for HUD Testing Name 2", "56.55", "3.55", null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable, "Real Estate Commission B: 56.55\r\nS: 3.55", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable, "POC Description4 (POC 20.50)", null, null, null, null);
                #endregion

                #region Deselect the subtotal checkbox under Commision section and verify the charges without subtotal
                Reports.TestStep = " Deselect the subtotal checkbox under Commision section and verify the charges without subtotal";


                FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.FASetCheckbox(false);

                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.IsSelected().ToString());
                Support.AreEqual("Broker: Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(1, 4, TableAction.GetText).Message, "Verify Commision description without subtotal");
                Support.AreEqual("400.00", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify Commision description without subtotal");
                Support.AreEqual("100.00", FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify Commision description  without subtotal");
                Support.AreEqual("Broker: Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(1, 4, TableAction.GetText).Message, "Verify commision description without subtotal");

                Support.AreEqual("200.00", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(2, 2, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                Support.AreEqual("300.00", FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable.PerformTableAction(2, 5, TableAction.GetText).Message, "Verify Buyer charge  without subtotal");
                #endregion
                #endregion

                #region Edit REB charges by adding the charge or removing the charge
                Reports.TestStep = "Navigate to REB and edit REB charges by adding the charge or removing the charge";


                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(5, 2, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(8000);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("0.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();

                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(8000);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("30.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                #endregion
                #region Navigate to View SS and verify the modified values in View SS
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                FastDriver.NCSViewSettlementStatement.SwitchToContentFrame();
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Total to Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", "160.00", "230.00", null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Description1 B: (30.00)\r\nS: (30.00)", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "Total to Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", "400", null, null, "50.00");

                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "Description3 S: (150.00)", null, null, null, null);

                #endregion
                #region Revert the changes in REB

                Reports.TestStep = "Navigate to REB and revert the changes in REB";

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("20.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(5, 2, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("600.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify the subtoal functionality in view SS for Refinance files


                #region Navigate to FHP and change the transaction type to Refinance
                Reports.TestStep = " Navigate to FHP and change the transaction type to Refinance and verify the subtoal functionality in view SS for Refinance files";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Refinance");
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to View SS and verify the display in View SS for refinance file with subtotal checkbox selected
                Reports.TestStep = "Navigate to View SS and verify the display in View SS for refinance file with subtotal checkbox selected";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.GetAttribute("checked"));
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "Total to Lease 1 for HUD Testing Name 1 Lease 1 for HUD Testing Name 2", null, null, "100.00", null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "Real Estate Commission B: 500.00", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "Description3 B: (600.00)", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_1stinstancetable, "POC Description3 (POC 26.66)", null, null, null, null);

                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Total to Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", "470.00", null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Real Estate Commission B: 500.00", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Description1 B: (20.00)", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "Description2 B: (10.00)", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_2ndinstancetable, "POC Description1 (POC 60.00)", null, null, null, null);

                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable, "Total to Thomas Freeman", null, null, "111,110,317.78", null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable, "Real Estate Commission B: 12,345,678,912.22", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_3rdinstancetable, "Description4 B: (12,456,789,230.00)", null, null, null, null);

                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable, "Total to Lease 2 for HUD Testing Name 1 Lease 2 for HUD Testing Name 2", "60.10", null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable, "Real Estate Commission B: 60.10", null, null, null, null);
                verifytheData1(FastDriver.NCSViewSettlementStatement.Commision_4thinstancetable, "POC Description4 (POC 20.50)", null, null, null, null);

                #endregion
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);


            }
        }
        [TestMethod]
        public void FMUC0135_REG0022()
        {
            try
            {
                Reports.TestDescription = "To test US# 779319&813834- Verify New Loan section, display Subtotals for buyer/seller net charge/credit amount in Settlement Statement- UI";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Through UI
                Reports.TestStep = "Create File with Commercial business type.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                FastDriver.BottomFrame.Done();

                FastDriver.QuickFileEntry.SwitchToTopFrame();
                string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                #region UI

                Reports.TestStep = "Navigate to New Loan";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Pull GAB code";
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("22233344455.66");

                Reports.TestStep = "Click on Loan Charges tab";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Enter data in Interest Calculation section";
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("NCS Updated Payee Name in PDD");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
              
                Reports.TestStep = "In the Origination Charges section, enter amounts in a few charge fields";
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", buyerCharge: 100);
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Origination Fee", buyerCredit: 200);
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Underwriting Fee", sellerCharge: 300);
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Processing Fee", sellerCredit: 400);
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Verification Fee", buyerCharge: 500, buyerCredit: 600, sellerCharge: 700, sellerCredit: 800);

                Reports.TestStep = "In one of the New Loan charge fields, enter an amount";
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", buyerCharge: 12345678901.23);

                Reports.TestStep = "Open Payment Details for Appraisal, uncheck the Use Default Checkbox and enter Third Party Payee in the Payee Name field";
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("NCS SS Third Party Payee");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("12345678901.23");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to New Loan - Loan Charges screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Add another charge in the New Loan charges section with a default payee";
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Credit Report", buyerCharge: 12345678901.23);
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("248");
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(9, 1, TableAction.Click);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a GAB to Mortgage Broker";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGABCode("MBOLEND1");

                Reports.TestStep = "Define Mortgage Broker Charges";
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 12345678901.23, buyerCredit: 12345678901.23, sellerCharge: 12345678901.23, sellerCredit: 12345678901.23);

                Reports.TestStep = "Defining POC-MB for Mortgage Broker Charge";
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit Report", buyerCharge: 12345678901.23);
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("12345678901.23");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);


                Reports.TestStep = "Navigate to View Settlement Statement";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.NewNewLoanTable.Highlight();
                Reports.TestStep = "Verify the Without subtotals for the New Loan section are not displayed upon screen loading";
                NewLoan(1, 1);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Lender: Lenders Advantage A Division Of First American Title Ins.", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 2);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("22,233,344,455.66", BuyerCredit);
                Support.AreEqual("Loan Amount", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 3);
                Support.AreEqual("487.50", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Prepaid Interest 08/06/12 to 06/27/13 @$1.500000/day to NCS Updated Payee Name in PDD", Description, "Updated Payee Name displayed with Charge Descrption");
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 4);
                Support.AreEqual("100.00", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Application Fee", Description, "Payee Name not displayed with Charge Descrption");
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 5);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("200.00", BuyerCredit);
                Support.AreEqual("Origination Fee", Description, "Payee Name not displayed with Charge Descrption");
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 6);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Underwriting Fee", Description, "Payee Name not displayed with Charge Descrption");
                Support.AreEqual("300.00", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 7);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Processing Fee", Description, "Payee Name not displayed with Charge Descrption");
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("400.00", SellerCredit);

                NewLoan(1, 8);
                Support.AreEqual("500.00", BuyerCharge);
                Support.AreEqual("600.00", BuyerCredit);
                Support.AreEqual("Verification Fee", Description, "Payee Name not displayed with Charge Descrption");
                Support.AreEqual("700.00", SellerCharge);
                Support.AreEqual("800.00", SellerCredit);

                NewLoan(1, 9);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Appraisal Fee to NCS SS Third Party Payee POC-L $12,345,678,901.23", Description, "Payee Name displayed with Charge Descrption");
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 10);
                Support.AreEqual("12,345,678,901.23", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Credit Report to Midwest Financial Group", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(2, 1);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Mrtg. Broker: Lender Entity - Name 1 Lender Entity - Name 2", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(2, 2);
                Support.AreEqual("12,345,678,901.23", BuyerCharge);
                Support.AreEqual("12,345,678,901.23", BuyerCredit);
                Support.AreEqual("Appraisal Fee", Description, "Payee Name not displayed with Charge Descrption");
                Support.AreEqual("12,345,678,901.23", SellerCharge);
                Support.AreEqual("12,345,678,901.23", SellerCredit);

                NewLoan(2, 3);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Credit Report POC-MB $12,345,678,901.23", Description, "Payee Name not displayed with Charge Descrption");
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);


                Reports.TestStep = "Mark the Subtotal checkbox in the New Loan section to trigger the display of the subtotals for the section and verify the subtotals are displayed as expected.";
                FastDriver.NCSViewSettlementStatement.SelectAll_SubtotalsCheckbox.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NCSViewSettlementStatement.Open();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.NewNewLoanTable.Highlight();
                NewLoan(1, 1);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Lender: Lenders Advantage A Division Of First American Title Ins.", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 2);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("22,233,344,455.66", BuyerCredit);
                Support.AreEqual("Loan Amount", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 3);
                Support.AreEqual("487.50", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Prepaid Interest 08/06/12 to 06/27/13 @$1.500000/day to NCS Updated Payee Name in PDD", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 4);
                Support.AreEqual("12,345,678,701.23", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Total to Lenders Advantage A Division Of First American Title Ins.", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("200.00", SellerCredit);

                NewLoan(1, 5);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Application Fee B: 100.00", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 6);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Origination Fee B: (200.00)", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 7);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Underwriting Fee S: 300.00", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 8);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Processing Fee S: (400.00)", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 9);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Verification Fee B: (100.00)\r\nS: (100.00)", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 10);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Appraisal Fee to NCS SS Third Party Payee (POC-L 12,345,678,901.23)", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(1, 11);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Credit Report to Midwest Financial Group B: 12,345,678,901.23", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(2, 1);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Mrtg. Broker: Lender Entity - Name 1 Lender Entity - Name 2", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(2, 2);
                Support.AreEqual("0.00", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Total to Lender Entity - Name 1 Lender Entity - Name 2", Description);
                Support.AreEqual("0.00", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(2, 3);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Appraisal Fee B: 0.00\r\nS: 0.00", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);

                NewLoan(2, 4);
                Support.AreEqual("", BuyerCharge);
                Support.AreEqual("", BuyerCredit);
                Support.AreEqual("Credit Report (POC-MB 12,345,678,901.23)", Description);
                Support.AreEqual("", SellerCharge);
                Support.AreEqual("", SellerCredit);


                #endregion

                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #region US-779320
        [DataSource("System.Data.Odbc", "Dsn=Excel Files;Driver={Microsoft Excel Driver (*.xlsx)};dbq=|DataDirectory|\\NCS_Data.xlsx;defaultdir=.;driverid=790;maxbuffersize=2048;pagetimeout=5;readonly=true", "Sheet1$", DataAccessMethod.Sequential), DeploymentItem("NCS_Data.xlsx"), TestMethod]
        public void FMUC0135_REG0008()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "US#779320&813834:Verify the Subtotals for Buyer/Seller net mixed (charge/credit) amount is displayed in the Payoff Loan(s) section - UI Test Case 823393";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                
                Reports.TestStep = "Create File with Commercial business type.";
                CreateFile_WS();
                
                Reports.TestStep = "Navigate to Payoff Loan screen and add 2 instances of Payoff Lender with values for buyer and seller charges and credits.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();

                #region Instance 1
                FastDriver.PayoffLoanDetails.FindGABCode(TestContext.DataRow["PayoffLoanGabID1"].ToString());
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.FASetText("20000");

                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Reconveyance Fee", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Reconveyance Fee", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Prepayment Penalty", "Buyer Credit", TableAction.SetText, "200.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Prepayment Penalty", "Seller Credit", TableAction.SetText, "300.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Recording Fee", "Buyer Credit", TableAction.SetText, "700.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Recording Fee", "Seller Credit", TableAction.SetText, "600.00");

                FastDriver.PayoffLoanCharges.PayChargesBtn.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(false);
                FastDriver.NewLoanDisbursements.NthChargeSelect(3).FASetCheckbox(false);
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode(TestContext.DataRow["3PartyPayeeGabID6"].ToString());
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(true);
                FastDriver.NewLoanDisbursements.NthChargeSelect(3).FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.New();

                FastDriver.BottomFrame.New();
                #endregion
                #region Instance 2
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(TestContext.DataRow["PayoffLoanGabID3"].ToString());
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.FASetText("10000");


                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Reconveyance Fee", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Reconveyance Fee", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Recording Fee", "Buyer Charge", TableAction.SetText, "200.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Recording Fee", "Seller Charge", TableAction.SetText, "300.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Prepayment Penalty", "Buyer Credit", TableAction.SetText, "2100.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Prepayment Penalty", "Seller Credit", TableAction.SetText, "900.00");
               

                Reports.TestStep = "Open the Payment Details Dialog box: Unmark the Use default checkbox of the Payee Name on CD/Settlement Statement and add a new Payee name and Select one type of POC for Buyer/Borrower and another for Seller and add values to each ";

                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details -- Webpage Dialog", true, 20);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.USEDEFAULT.FASetCheckbox(false);

                if (FastDriver.PaymentDetailsDlg.PayeeName.Enabled == true)
                {
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("NCS Fast testing.");
                }
                else
                {
                    FailTest("Payee textbox was not enabled.");
                }

                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("1000");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("2000");

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Navigate to the View Settlement Stmt screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                
                Reports.TestStep = "Verify the subtotals for the Payoff Loan section are not displayed upon screen loading.";
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable.FAGetText().Contains("Total to"), "Subtotals are not displayed.");
                #region Verify UnSubtotal functionality
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.NCSViewSettlementStatement.PayoffLoan_SubtotalsCheckbox.FASetCheckbox(false);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable.Highlight();
                Reports.TestStep = "Verify the Without Subtotal functionality for First Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 1, 1);
                Support.AreEqual("Lender: PAYOFF LENDER NAME 1 PAYOFF LENDER NAME 2", Description, "Validating the First Instance Header under Description Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 1, 2);
                Support.AreEqual("Interest on Payoff Loan", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("20,000.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 1, 3);
                Support.AreEqual("Statement/Forwarding Fee", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("5,000.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("3,000.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 1, 4);
                Support.AreEqual("Recording Fee", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("700.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("600.00", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 1, 5);
                Support.AreEqual("Reconveyance Fee to Olympic Coast Investment", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("10,000.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("5,000.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 1, 6);
                Support.AreEqual("Prepayment Penalty to Olympic Coast Investment", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("200.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("300.00", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");



                Reports.TestStep = "Verify the Without Subtotal functionality for Payoff Loan Second Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 2, 1);
                Support.AreEqual("Lender: Sacramento Valley Financial", Description, "Validating the Second Instance Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 2, 2);
                Support.AreEqual("Interest on Payoff Loan", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("10,000.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 2, 3);
                Support.AreEqual("Statement/Forwarding Fee to NCS Fast testing. POC $1,000.00,POC-L $2,000.00", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("5,000.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("3,000.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 2, 4);
                Support.AreEqual("Reconveyance Fee", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("10,000.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("5,000.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 2, 5);
                Support.AreEqual("Prepayment Penalty", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("2,100.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("900.00", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 2, 6);
                Support.AreEqual("Recording Fee", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("200.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("300.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion

                #region Verify Subtotal functionality
                Reports.TestStep = "Mark the Subtotal checkbox in the Payoff Loan section to trigger the display of the subtotals for the section and verify the subtotals are displayed as expected.";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.NCSViewSettlementStatement.PayoffLoan_SubtotalsCheckbox.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable.Highlight();
                Reports.TestStep = "Verify the Subtotal functionality for First Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 1, 1);
                Support.AreEqual("Total to PAYOFF LENDER NAME 1 PAYOFF LENDER NAME 2", Description, "Validating the First Instance Header under Description Column");
                Support.AreEqual("34,100.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("7,100.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 1, 2);
                Support.AreEqual("Interest on Payoff Loan B: 20,000.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amouns displayed Without B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 1, 3);
                Support.AreEqual("Statement/Forwarding Fee B: 5,000.00\r\nS: 3,000.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 1, 4);
                Support.AreEqual("Recording Fee B: (700.00)\r\nS: (600.00)", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 1, 5);
                Support.AreEqual("Reconveyance Fee to Olympic Coast Investment B: 10,000.00\r\nS: 5,000.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 1, 6);
                Support.AreEqual("Prepayment Penalty to Olympic Coast Investment B: (200.00)\r\nS: (300.00)", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Verify the Subtotal functionality for Second Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 2, 1);
                Support.AreEqual("Total to Sacramento Valley Financial", Description, "Validating the Second Instance Header under Description Column");
                Support.AreEqual("23,100.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("7,400.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 2, 2);
                Support.AreEqual("Interest on Payoff Loan B: 10,000.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amouns displayed Without B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 2, 3);
                Support.AreEqual("Statement/Forwarding Fee to NCS Fast testing. (POC 1,000.00,POC-L 2,000.00) B: 5,000.00\r\nS: 3,000.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 2, 4);
                Support.AreEqual("Reconveyance Fee B: 10,000.00\r\nS: 5,000.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 2, 5);
                Support.AreEqual("Prepayment Penalty B: (2,100.00)\r\nS: (900.00)", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewPayoffLoanTable, 2, 6);
                Support.AreEqual("Recording Fee B: 200.00\r\nS: 300.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                #endregion

          
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region US-779321
        [DataSource("System.Data.Odbc", "Dsn=Excel Files;Driver={Microsoft Excel Driver (*.xlsx)};dbq=|DataDirectory|\\NCS_Data.xlsx;defaultdir=.;driverid=790;maxbuffersize=2048;pagetimeout=5;readonly=true", "Sheet1$", DataAccessMethod.Sequential), DeploymentItem("NCS_Data.xlsx"), TestMethod]
        public void FMUC0135_REG0013()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "US#779321&813834:Verify the Subtotals for Buyer/Seller net mixed (charge/credit) amount is displayed in the Assumption Loan(s) section";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
               
                Reports.TestStep = "Create File with Commercial business type.";
                CreateFile_WS();
                
                Reports.TestStep = "Navigate to Assumption Loan screen and add 2 instances of Assumption Lender with values for buyer and seller charges and credits.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                #region Instance 1
                FastDriver.AssumptionLoanDetails.FindGABCode(TestContext.DataRow["AssumptionLoanGabID1"].ToString());
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.FASetText("20000");
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details -- Webpage Dialog", true, 20);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.USEDEFAULT.FASetCheckbox(false);
                if (FastDriver.PaymentDetailsDlg.PayeeName.Enabled == true)
                {
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Updated Payee Name for testing.");
                }
                else
                {
                    FailTest("Payee textbox was not enabled.");
                }
                
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("432");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("2000");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(2000);
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Document Fee", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Document Fee", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Balance of Impounds/Reserves Acct.", "Buyer Credit", TableAction.SetText, "200.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Balance of Impounds/Reserves Acct.", "Seller Credit", TableAction.SetText, "300.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Assumption Transfer Fee", "Buyer Credit", TableAction.SetText, "700.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Assumption Transfer Fee", "Seller Credit", TableAction.SetText, "600.00");

                FastDriver.AssumptionLoanCharges.PayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(false);
                FastDriver.NewLoanDisbursements.NthChargeSelect(3).FASetCheckbox(false);
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode(TestContext.DataRow["3PartyPayeeGabID4"].ToString());
                FastDriver.NewLoanDisbursements.NthChargeSelect(2).FASetCheckbox(true);
                FastDriver.NewLoanDisbursements.NthChargeSelect(3).FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.New();

                FastDriver.BottomFrame.New();
                #endregion
                #region Instance 2
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode(TestContext.DataRow["AssumptionLoanGabID3"].ToString());
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.FASetText("10000");
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FASetText("78698");


                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Document Fee", "Buyer Credit", TableAction.SetText, "10000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Document Fee", "Seller Credit", TableAction.SetText, "5000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Late Charge", "Buyer Charge", TableAction.SetText, "200.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Late Charge", "Seller Charge", TableAction.SetText, "300.00");
                #endregion

                Reports.TestStep = "Open the Payment Details Dialog box: Unmark the Use default checkbox of the Payee Name on CD/Settlement Statement and add a new Payee name and Select one type of POC for Buyer/Borrower and another for Seller and add values to each ";

                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details -- Webpage Dialog", true, 20);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.USEDEFAULT.FASetCheckbox(false);

                if (FastDriver.PaymentDetailsDlg.PayeeName.Enabled == true)
                {
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("NCS Fast testing.");
                }
                else
                {
                    FailTest("Payee textbox was not enabled.");
                }

                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("1000");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("2000");

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to the View Settlement Stmt screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();


                #region Verify UnSubtotal functionality
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(2000);
                FastDriver.NCSViewSettlementStatement.Attorney_SubtotalsCheckbox.FASetCheckbox(false);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.AssumptionLoanTable.Highlight();
                Reports.TestStep = "Verify the Without Subtotal functionality for First Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 1);
                Support.AreEqual("Lender: Draper And Kramer Mortgage Corporation", Description, "Validating the Lender Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 2);
                Support.AreEqual("Unpaid Principal Balance to Updated Payee Name for testing. POC-L $2,000.00", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("2,432.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("432.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 3);
                Support.AreEqual("Assumption Loan Interest Proration", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("20,000.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 4);
                Support.AreEqual("Balance of Impounds/Reserves Acct.", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("200.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("300.00", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 5);
                Support.AreEqual("Assumption Transfer Fee", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("700.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("600.00", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 6);
                Support.AreEqual("Statement/Forwarding Fee to Severino Financial Company", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("5,000.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("3,000.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 7);
                Support.AreEqual("Document Fee to Severino Financial Company", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("10,000.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("5,000.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Verify the Without Subtotal functionality for Payoff Loan Second Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 2, 1);
                Support.AreEqual("Lender: First American Lenders Advantage", Description, "Validating the Second Instance Lender Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 2, 2);
                Support.AreEqual("Unpaid Principal Balance", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("78,698.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("78,698.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 2, 3);
                Support.AreEqual("Assumption Loan Interest Proration", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("10,000.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 2, 4);
               Support.AreEqual("Statement/Forwarding Fee to NCS Fast testing. POC $1,000.00,POC-L $2,000.00", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("5,000.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("3,000.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 2, 5);
                Support.AreEqual("Document Fee", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("10,000.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("5,000.00", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 2, 6);
                Support.AreEqual("Late Charge", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("200.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("300.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
               

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion

                #region Verify Subtotal functionality
                Reports.TestStep = "Mark the Subtotal checkbox in the Payoff Loan section to trigger the display of the subtotals for the section and verify the subtotals are displayed as expected.";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.AssumptionLoan_SubtotalsCheckbox.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.AssumptionLoanTable.Highlight();
                Reports.TestStep = "Verify the Subtotal functionality for First Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 1);
                Support.AreEqual("Lender: Draper And Kramer Mortgage Corporation", Description, "Validating the Lender Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 2);
                Support.AreEqual("Unpaid Principal Balance to Updated Payee Name for testing. (POC-L 2,000.00)", Description, "Validating Charge description without PayeeName and Buter/Seller Amouns displayed Without B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("2,432.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("432.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 3);
                Support.AreEqual("Assumption Loan Interest Proration", Description, "Validating Charge description without PayeeName and Buter/Seller Amouns displayed Without B:&S:");
                Support.AreEqual("20,000.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 4);
                Support.AreEqual("Total to Draper And Kramer Mortgage Corporation", Description, "Validating the First Instance Header under Description Column");
                Support.AreEqual("14,100.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("7,100.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 5);
                Support.AreEqual("Balance of Impounds/Reserves Acct. B: (200.00)\r\nS: (300.00)", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 6);
                Support.AreEqual("Assumption Transfer Fee B: (700.00)\r\nS: (600.00)", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 7);
                Support.AreEqual("Statement/Forwarding Fee to Severino Financial Company B: 5,000.00\r\nS: 3,000.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 1, 8);
                Support.AreEqual("Document Fee to Severino Financial Company B: 10,000.00\r\nS: 5,000.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Verify the Subtotal functionality for Second Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 2, 1);
                Support.AreEqual("Lender: First American Lenders Advantage", Description, "Validating the Lender Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 2, 2);
                Support.AreEqual("Unpaid Principal Balance", Description, "Validating Charge description without PayeeName and Buter/Seller Amouns displayed Without B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("78,698.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("78,698.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 2, 3);
                Support.AreEqual("Assumption Loan Interest Proration", Description, "Validating Charge description without PayeeName and Buter/Seller Amouns displayed Without B:&S:");
                Support.AreEqual("10,000.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 2, 4);
                Support.AreEqual("Total to First American Lenders Advantage", Description, "Validating the Second Instance Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("4,800.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("1,700.00", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 2, 5);
                Support.AreEqual("Statement/Forwarding Fee to NCS Fast testing. (POC 1,000.00,POC-L 2,000.00) B: 5,000.00\r\nS: 3,000.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 2, 6);
                Support.AreEqual("Document Fee B: (10,000.00)\r\nS: (5,000.00)", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.AssumptionLoanTable, 2, 7);
                Support.AreEqual("Late Charge B: 200.00\r\nS: 300.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                #endregion

                

            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
        #region US-781837
        [TestMethod]
        public void FMUC0135_REG0015()
        {
            try
            {
                Reports.TestDescription = "US#781837&813834:To verify the Subtotal functionality for Attorney section in View SS Screen.";


                #region LOGIN
                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion
                Reports.TestStep = "Login into the IIS Side.";
                Reports.TestStep = "Login FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create File.";
                CreateFile_WS();
                #endregion

                #region Navigate Buyer's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney First Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "50.00", SellerCharge: "50.00", GabCode: "HUDBUYATT1");
                string FirstinstName = FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName.FAGetText();
                string FirstinstName1 = FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName1.FAGetText();
                string FirstinstLendername = FirstinstName + " " + FirstinstName1;
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "1st Instance Second charge", 544.00, null, 453.00, null, 92.00);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "1st Instance Third charge", 8765.00, null, 7654.00, null, 65.00);
                FastDriver.BottomFrame.Done();

                #endregion

                #region Create an Second Attorney Instance by Clicking on New-Buyer's Attorney.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Second Instance.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorney(BuyerCharge: "100.00", SellerCharge: "100.00", GabCode: "HUDBUYATT2");
                string SecondinstName = FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName.FAGetText();
                string SecondinstName1 = FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName1.FAGetText();
                string SecondinstLendername = SecondinstName + " " + SecondinstName1;
                FastDriver.AttorneyDetail.ChargeDescription.FASetText("Attorney Fee 2nd Instance");
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "2nd Instance Second charge", 433, null, 655.00, null, 87.00);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "2nd Instance Third charge", 6543.00, null, 7654.00, null, 76.00);
                FastDriver.BottomFrame.Done();


                #endregion

                #region Verify UnSubtotal functionality
                Reports.TestStep = "Navigate to View Settlement statement screen  and Verify the without subtotals Functionality for the Attorney section are not displayed upon screen loading.";
                FastDriver.NCSViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(5000);
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.NewAttorneyTable.FAGetText().Contains("Total to"), "Subtotals are not displayed.");
                Reports.TestStep = "Verify the Without Subtotal functionality for First Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 1);
                Support.AreEqual("Attorney: Buyer's Attorney 1 for HUD Test Name 1 Buyer's Attorney 1 for HUD Test Name 2", Description, "Validating the First Instance Header under Description Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 2);
                Support.AreEqual("Attorney Fee", Description,"Validating Charge description without PayeeName");
                Support.AreEqual("50.00", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("50.00", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 3);
                Support.AreEqual("1st Instance Second charge", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("544.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("453.00", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 4);
                Support.AreEqual("1st Instance Third charge", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("8,765.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("7,654.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Verify the Without Subtotal functionality for Second Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 1);
                Support.AreEqual("Attorney: " + SecondinstLendername + "",Description,"Validating the Second Instance Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 2);
                Support.AreEqual("Attorney Fee 2nd Instance", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("100.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("100.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 3);
                Support.AreEqual("2nd Instance Second charge", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("433.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("655.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 4);
                Support.AreEqual("2nd Instance Third charge", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("6,543.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("7,654.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
               

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion

                #region Navigate to ViewSettlementStatement and Verify Subtotal functionality
                Reports.TestStep = "Navigate to ViewSettlementStatement and Verify Subtotal functionality for First Instance";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(1000);
                FastDriver.NCSViewSettlementStatement.Attorney_SubtotalsCheckbox.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.NewAttorneyTable.Highlight();
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 1);
                Support.AreEqual("Total to Buyer's Attorney 1 for HUD Test Name 1 Buyer's Attorney 1 for HUD Test Name 2", Description, "Validating the First Instance Header under Description Column");
                Support.AreEqual("9,359.00", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("8,157.00", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 2);
                Support.AreEqual("Attorney Fee B: 50.00\r\nS: 50.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 3);
                Support.AreEqual("1st Instance Second charge B: 544.00\r\nS: 453.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 4);
                Support.AreEqual("1st Instance Third charge B: 8,765.00\r\nS: 7,654.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Verify the Subtotal functionality for Second Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 1);
                Support.AreEqual("Total to Buyer's Attorney 2 for HUD Test Name 1 Buyer's Attorney 2 for HUD Test Name 2", Description, "Validating the Second Instance Header under Description Column");
                Support.AreEqual("7,076.00", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("8,409.00", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 2);
                Support.AreEqual("Attorney Fee 2nd Instance B: 100.00\r\nS: 100.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 3);
                Support.AreEqual("2nd Instance Second charge B: 433.00\r\nS: 655.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 4);
                Support.AreEqual("2nd Instance Third charge B: 6,543.00\r\nS: 7,654.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
              
                
                FastDriver.BottomFrame.Done();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                #endregion

                #region Select Instanc and Edit the Buyer/Seller Charge.
                Reports.TestStep = "Navigate to Attorney Summary-Buyer screen and Select Instance";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneySummary.WaitForScreenToLoad();
                Playback.Wait(5000);
                Reports.TestStep = "Select Instanc and Edit the Buyer/Seller Charge.";
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Buyer's Attorney 2 for HUD Test Name 1", 2, TableAction.Click);
                FastDriver.AttorneySummary.Edit.FAClick();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.AttorneyDetail.GABcode.FASetText("BOA");
                FastDriver.AttorneyDetail.Find.Click();
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee 2nd Instance", "456783214.99");
                SetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee 2nd Instance", "675342345.22");
                FastDriver.AttorneyDetail.PaymentDetails.Click();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details -- Webpage Dialog", true, 20);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.USEDEFAULT.FASetCheckbox(false);

                if (FastDriver.PaymentDetailsDlg.PayeeName.Enabled == true)
                {
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("NCS Fast testing.");
                }
                else
                {
                    FailTest("Payee textbox was not enabled.");
                }


                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Select Instance, Click on Edit and Enter the Poc and Poc-L amounts.";
                FastDriver.AttorneySummary.WaitForScreenToLoad();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Buyer's Attorney 1 for HUD Test Name 1", 2, TableAction.Click);
                FastDriver.AttorneySummary.Edit.FAClick();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                FastDriver.AttorneyDetail.PaymentDetails.Click();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details -- Webpage Dialog", true, 20);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.USEDEFAULT.FASetCheckbox(false);

                if (FastDriver.PaymentDetailsDlg.PayeeName.Enabled == true)
                {
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Updated Payee Name in PDD.");
                }
                else
                {
                    FailTest("Payee textbox was not enabled.");
                }

                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("1000");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("2000");

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();





                #endregion

                #region Navigate to ViewSettlementStatement and Verify Subtotal functionality
                Reports.TestStep = "Navigate to ViewSettlementStatement and Verify Subtotal functionality for First Instance";
                FastDriver.NCSViewSettlementStatement.Open();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.NCSViewSettlementStatement.Attorney_SubtotalsCheckbox.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.NewAttorneyTable.Highlight();
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 1);
                Support.AreEqual("Total to Buyer's Attorney 1 for HUD Test Name 1 Buyer's Attorney 1 for HUD Test Name 2", Description, "Validating the First Instance Header under Description Column");
                Support.AreEqual("9,359.00", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("8,157.00", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 2);
                Support.AreEqual("Attorney Fee to Updated Payee Name in PDD. (POC 1,000.00,POC-L 2,000.00) B: 50.00\r\nS: 50.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 3);
                Support.AreEqual("1st Instance Second charge B: 544.00\r\nS: 453.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Buyer Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 4);
                Support.AreEqual("1st Instance Third charge B: 8,765.00\r\nS: 7,654.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Verify the Subtotal functionality for Second Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 1);
                Support.AreEqual("Total to Bank of America", Description, "Validating the Second Instance Header under Description Column");
                Support.AreEqual("456,790,190.99", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("675,350,654.22", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 2);
                Support.AreEqual("Attorney Fee 2nd Instance to NCS Fast testing. B: 456,783,214.99\r\nS: 675,342,345.22", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 3);
                Support.AreEqual("2nd Instance Second charge B: 433.00\r\nS: 655.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 4);
                Support.AreEqual("2nd Instance Third charge B: 6,543.00\r\nS: 7,654.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
               
                FastDriver.BottomFrame.Done();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                #endregion

                #region Verify UnSubtotal functionality
                Reports.TestStep = "Navigate to View Settlement statement screen and Verify the without subtotals Functionality for the Attorney section are not displayed upon screen loading.";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.NCSViewSettlementStatement.Attorney_SubtotalsCheckbox.FASetCheckbox(false);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.NewAttorneyTable.Highlight();
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.NewAttorneyTable.FAGetText().Contains("Total to"), "Subtotals are not displayed.");
                Reports.TestStep = "Verify the Without Subtotal functionality for First Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 1);
                Support.AreEqual("Attorney: Buyer's Attorney 1 for HUD Test Name 1 Buyer's Attorney 1 for HUD Test Name 2", Description, "Validating the First Instance Header under Description Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 2);
                Support.AreEqual("Attorney Fee to Updated Payee Name in PDD. POC $1,000.00,POC-L $2,000.00", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("50.00", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("50.00", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 3);
                Support.AreEqual("1st Instance Second charge", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("544.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("453.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 4);
                Support.AreEqual("1st Instance Third charge", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("8,765.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("7,654.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Verify the Without Subtotal functionality for Second Instance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 1);
                Support.AreEqual("Attorney: Bank of America", Description, "Validating the Second Instance Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 2);
                Support.AreEqual("Attorney Fee 2nd Instance to NCS Fast testing.", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("456,783,214.99", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("675,342,345.22", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 3);
                Support.AreEqual("2nd Instance Second charge", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("433.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("655.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 4);
                Support.AreEqual("2nd Instance Third charge", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("6,543.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("7,654.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");


                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion
                
                #region Verify Subtotal for Refinance file
                Reports.TestStep = "Navigate to Filehomepage and Change the Transaction Type to Refinanace.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Refinance");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 20);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                Reports.TestStep = "Navigate to Viewsettlement Statement and verify the Subtotal and verify whether the Seller information is displayed.";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.");
                Playback.Wait(4000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.Attorney_SubtotalsCheckbox.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.NewAttorneyTable.Highlight();
                Reports.TestStep = "Navigate to ViewSettlementStatement and Verify the Subtotal Functionality For First Instance For Refinance File";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 1);
                Support.AreEqual("Total to Buyer's Attorney 1 for HUD Test Name 1 Buyer's Attorney 1 for HUD Test Name 2", Description, "Validating the First Instance Header under Description Column");
                Support.AreEqual("9,359.00", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Buyer Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 2);
                Support.AreEqual("Attorney Fee to Updated Payee Name in PDD. (POC 1,000.00) B: 50.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 3);
                Support.AreEqual("1st Instance Second charge B: 544.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Buyer Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 4);
                Support.AreEqual("1st Instance Third charge B: 8,765.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Verify the Subtotal Functionality for Second Instance For Refinance File";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 1);
                Support.AreEqual("Total to Bank of America", Description, "Validating the Second Instance Header under Description Column");
                Support.AreEqual("456,790,190.99", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 2);
                Support.AreEqual("Attorney Fee 2nd Instance to NCS Fast testing. B: 456,783,214.99", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 3);
                Support.AreEqual("2nd Instance Second charge B: 433.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 4);
                Support.AreEqual("2nd Instance Third charge B: 6,543.00", Description, "Validating Charge description without PayeeName and Buter/Seller Amount displayed With B:&S:");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();

                #endregion

                #region Verify UnSubtotal functionality Refinance File
                Reports.TestStep = "Navigate to View Settlement statement screen and Verify the without subtotals Functionality for the Attorney section are not displayed upon screen loading.";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.NCSViewSettlementStatement.Attorney_SubtotalsCheckbox.FASetCheckbox(false);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.NewAttorneyTable.Highlight();
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.NewAttorneyTable.FAGetText().Contains("Total to"), "Subtotals are not displayed.");
                Reports.TestStep = "Verify Without Subtotal functionality for First Instance for Refinance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 1);
                Support.AreEqual("Attorney: Buyer's Attorney 1 for HUD Test Name 1 Buyer's Attorney 1 for HUD Test Name 2", Description, "Validating the First Instance Header under Description Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 2);
                Support.AreEqual("Attorney Fee to Updated Payee Name in PDD. POC $1,000.00", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("50.00", BuyerCharge, "Validating Buyer Charge Value in Buyer Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in Seller Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 3);
                Support.AreEqual("1st Instance Second charge", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("544.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 1, 4);
                Support.AreEqual("1st Instance Third charge", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("8,765.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Verify the Without Subtotal functionality for Second Instance For Refinance";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 1);
                Support.AreEqual("Attorney: Bank of America", Description, "Validating the Second Instance Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 2);
                Support.AreEqual("Attorney Fee 2nd Instance to NCS Fast testing.", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("456,783,214.99", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 3);
                Support.AreEqual("2nd Instance Second charge", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("433.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewAttorneyTable, 2, 4);
                Support.AreEqual("2nd Instance Third charge", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("6,543.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");


                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("Test case US_781837_NCS_827636 failed because " + ex.Message);
            }
        }
        #endregion
        #endregion
        #region r09.2016
        /// <summary>
        /// FMUC0135_REG0019 - This Test method covers the US 685730 from r09
        /// FMUC0135_REG0020 - This Test method covers the US 675503 and 694339 from r09
        /// FMUC0135_REG0021 - This Test method covers the US 668239 and 687881 from r09
        /// FMUC0135_REG0024 - This Test method covers the US 672338 from r09
        /// FMUC0135_REG0025 - This Test method covers the US 686386 from r09
        /// FMUC0135_REG0030 - This Test method covers the US 608744 from r09
        /// FMUC0135_REG0036 - This Test method covers the US 761805 from r09
        /// FMUC0135_REG0038 - This Test method covers the US 690182 from r09
        /// </summary>
        [TestMethod]
        public void FMUC0135_REG0019()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "#US 685730 for Display the header section in the View Settlement Statement.";
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Through UI
                Reports.TestStep = "Create File with Commercial business type.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.EscrowOwningOfficeOfficer.FASelectItem("Y, Yeshwanth");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("Property 1");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Agricultural Land");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationTRact.FASetText("Tract1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First property: Address1 line 1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("First property: Address1 line 2");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("First property: Address1 line 3");
                FastDriver.QuickFileEntry.PropertyBookAddrLin4.FASetText("First property: Address1 line 4");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("City1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("NV");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("89003");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Nye");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFN1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLN1");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFN1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLN1");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("420");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                FastDriver.FileHomepage.Open();
                string fileNum = FastDriver.FileHomepage.FileNumPrefix.FAGetValue() + FastDriver.FileHomepage.FileNum.FAGetValue() + FastDriver.FileHomepage.FileNumSufix.FAGetValue();
                FastDriver.TopFrame.SwitchToContentFrame();
                string[] EscrowOfficerName = FastDriver.FileHomepage.EscrowOwningOfficeOfficer.FAGetSelectedItem().Split(',');
                #endregion

                #region Setting test data for Property, Buyer, Seller, Lender
                Reports.TestStep = "Navigate to Properties/Tax Info and add Property details";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("First property: Address2 line 1");//Property 1 Address 2 
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("First property: Address2 line 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("First property: Address2 line 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("First property: Address2 line 4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("City2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("AZ");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("85925");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Apache");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("First property: Address3 line 1");//Property 1 Address 3
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("First property: Address3 line 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("First property: Address3 line 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("First property: Address3 line 4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("City3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("FL");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("32003");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Clay");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Playback.Wait(10000);
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                //Property 2
                FastDriver.PropertiesSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("Property 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FASelectItem("Condominium");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Second property: Address1 line 1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("Second property: Address1 line 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("Second property: Address1 line 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("Second property: Address1 line 4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("City2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("KS");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("66901");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Cloud");
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText("Lot2");
                FastDriver.PropertyTaxInfoLegalDesciption.Tract.FASetText("Tract2");
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("Unit2");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Playback.Wait(10000);
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                //Property 3
                FastDriver.PropertiesSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("Property 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FASelectItem("Industrial");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Third property: Address1 line 1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("Third property: Address1 line 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("Third property: Address1 line 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("Third property: Address1 line 4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("City3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("HI");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("96708");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Maui");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Reports.TestStep = "Navigate to Buyers screen and add Buyer details";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.New();
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Husband/Wife");
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("Buyer2Spouse1FN");
                FastDriver.BuyerSellerSetup.HusbandLastName.FASetText("Buyer2Spouse1FN");
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Buyer2Spouse2FN");
                FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FASetText("Buyer2Spouse2LN");
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FAClick();
                FastDriver.BuyerSellerSetup.btnNew.FAClick();
                Playback.Wait(5000);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("BuyerFN3");
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FAClick();
                FastDriver.BuyerSellerSetup.btnNew.FAClick();
                Playback.Wait(5000);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                Playback.Wait(5000);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("BuyerFN4");
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FAClick();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to Sellers screen and add Seller details";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Husband/Wife");
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("Seller2Spouse1FN");
                FastDriver.BuyerSellerSetup.HusbandLastName.FASetText("Seller2Spouse1LN");
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Seller2Spouse2FN");
                FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FASetText("Seller2Spouse2LN");
                FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
                FastDriver.BuyerSellerSetup.btnNew.FAClick();
                Playback.Wait(5000);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("SellerFN3");
                FastDriver.BuyerSellerSetup.TrustLastNameFor1099SReporting.FASetText("SellerTrustLN");
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FAClick();
                FastDriver.BuyerSellerSetup.btnNew.FAClick();
                Playback.Wait(5000);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                Playback.Wait(5000);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("SellerFN4");
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FAClick();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to New Loan screen and add Lender details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("800");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("2,20,000.00");
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("2,70,000.00");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to Assumption Loan screen and add Lender details";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("boa");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("473");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Playback.Wait(5000);
                //FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                //FastDriver.AddressBookSearchDlg.FileaddressBookRadio_1.FAClick();
                //Playback.Wait(5000);
                //FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio1.FAClick();
                //FastDriver.AddressBookSearchDlg.SwitchToDialogBottomFrame();
                //FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                #endregion

                #region Verify the Header section in the View settlement statement
                Reports.TestStep = "Navigate to viewsettlement statement and verify the header section";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Reports.TestStep = "Verify the First section of Header section in ViewSettlement Statement";
                Support.AreEqual("File No: " + fileNum, FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[1]").FAGetText());//Validation of File No: field 
                Support.AreEqual("Escrow Officer:" + EscrowOfficerName[1] + " " + EscrowOfficerName[0] + "/FQ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[2]").FAGetText());
                Reports.TestStep = "Verify the Property section of Header section in ViewSettlement Statement";               
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderpropertylabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.propertyPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("First property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[1]/div[1]").FAGetText());
                Support.AreEqual("First property: Address2 line 1, First property: Address2 line 2, First property: Address2 line 3, First property: Address2 line 4, City2, AZ 85925\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[1]/div[2]").FAGetText());
                Support.AreEqual("First property: Address3 line 1, First property: Address3 line 2, First property: Address3 line 3, First property: Address3 line 4, City3, FL 32003\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[2]/div[1]").FAGetText());
                Support.AreEqual("Second property: Address1 line 1, Second property: Address1 line 2, Second property: Address1 line 3, Second property: Address1 line 4, City2, KS 66901\r\nLot: Lot2 Unit: Unit2 Tract: Tract2", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[2]/div[2]").FAGetText());
                Support.AreEqual("Third property: Address1 line 1, Third property: Address1 line 2, Third property: Address1 line 3, Third property: Address1 line 4, City3, HI 96708", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[3]/div").FAGetText());
                Reports.TestStep = "Verify the Buyer section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderbuyerlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.buyerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("BuyerFN1  BuyerLN1", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[7]/div/div[1]").FAGetText());
                Support.AreEqual("Buyer2Spouse1FN  Buyer2Spouse1FN/Buyer2Spouse2FN  Buyer2Spouse2LN\r\nFirst property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[7]/div[1]/div[2]").FAGetText());
                Support.AreEqual("BuyerFN3\r\nFirst property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[7]/div[2]/div[1]").FAGetText());
                Support.AreEqual("BuyerFN4\r\nFirst property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[7]/div[2]/div[2]").FAGetText());
                Reports.TestStep = "Verify the Seller section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheadersellerlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.sellerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("SellerFN1  SellerLN1\r\nFirst property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[10]/div/div[1]").FAGetText());
                Support.AreEqual("Seller2Spouse1FN  Seller2Spouse1LN/Seller2Spouse2FN  Seller2Spouse2LN\r\nFirst property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[10]/div[1]/div[2]").FAGetText());
                Support.AreEqual("SellerFN3\r\nFirst property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[10]/div[2]/div[1]").FAGetText());
                Support.AreEqual("SellerFN4\r\nFirst property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[10]/div[2]/div[2]").FAGetText());
                Reports.TestStep = "Verify the Lender section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderLenderlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.LenderPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("The Northern Trust Company\r\n4811 Emerson, Palatine, IL 60067     ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[1]/div[1]").FAGetText());
                Support.AreEqual("First American Title Company\r\n12600 Hesperia Road #C, Victorville, CA 92392     ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[1]/div[2]").FAGetText());
                Support.AreEqual("Lenders Advantage A Division Of First American Title Ins.\r\n15441 94Th Avenue, Orland Park, IL 60462     ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[2]/div").FAGetText());
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                #endregion

                #region Deleting the Property, Buyer, Seller and Lender Details
                Reports.TestStep = "Navigate to Properties/Tax Info and delete the address of the first Property details";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to Buyer screen and delete all the buyer details";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(5, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Reports.TestStep = "Navigate to Srller screen and delete all the seller details";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(5, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Reports.TestStep = "Navigate to New Loan screen and delete Lender details";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                #endregion

                #region Verify the Header section in the View settlement statement after deleting Buyer, Seller and New Lender information
                Reports.TestStep = "Navigate to viewsettlement statement and verify the header section";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Reports.TestStep = "Verify the First section of Header section in ViewSettlement Statement";
                Support.AreEqual("File No: " + fileNum, FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[1]").FAGetText());//Validation of File No: field 
                Support.AreEqual("Escrow Officer:" + EscrowOfficerName[1] + " " + EscrowOfficerName[0] + "/FQ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[2]").FAGetText());
                Reports.TestStep = "Verify the Property section of Header section in ViewSettlement Statement";               
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderpropertylabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.propertyPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("First property: Address2 line 1, First property: Address2 line 2, First property: Address2 line 3, First property: Address2 line 4, City2, AZ 85925\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[1]/div[1]").FAGetText());
                Support.AreEqual("First property: Address3 line 1, First property: Address3 line 2, First property: Address3 line 3, First property: Address3 line 4, City3, FL 32003\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[1]/div[2]").FAGetText());
                Support.AreEqual("Second property: Address1 line 1, Second property: Address1 line 2, Second property: Address1 line 3, Second property: Address1 line 4, City2, KS 66901\r\nLot: Lot2 Unit: Unit2 Tract: Tract2", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[2]/div[1]").FAGetText());
                Support.AreEqual("Third property: Address1 line 1, Third property: Address1 line 2, Third property: Address1 line 3, Third property: Address1 line 4, City3, HI 96708", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[2]/div[2]").FAGetText());
                Reports.TestStep = "Verify the Buyer section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderbuyerlabel.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.buyerPlusIcon.IsDisplayed().ToString());
                Reports.TestStep = "Verify the Seller section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheadersellerlabel.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.sellerPlusIcon.IsDisplayed().ToString());
                Reports.TestStep = "Verify the Lender section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderLenderlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.LenderPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("Bank of America", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[1]/div[1]").FAGetText());
                Support.AreEqual("World Savings Bank\r\n1144 Lake Street, Oak Park, IL 60301     ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[1]/div[2]").FAGetText());
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                #endregion
            }
            catch (Exception ex)
            { FailTest(ex.Message); }
        }
        [TestMethod]
        public void FMUC0135_REG0020()
        {
            try
            {
                Reports.TestDescription = "US# 675503 and 694339 Display + icon for Property and allow user to select and display multiple Properties in the Settlement Statement Header. Allow user to select multiple Properties in the Property Details dialog to get displayed in the Settlement Statement Header.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log into FAST application automation region/office with automation credentials";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Set up a basic file and the file must contain multiple property details and each property should have multiple address details";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.txtBusinessSourceGABID.FASetText("800");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                { FastDriver.QuickFileEntry.Title.FASetCheckbox(true); }
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                { FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true); }
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Equity Loan");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("2000000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1000000000.87");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Trust/Estate");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Business Entity");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("Property1name");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Retail");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Property1lot");
                FastDriver.QuickFileEntry.PropertyInformationTRact.FASetText("Property1tract");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Property1unit");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("property1addre1line1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("property1addre1line2");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("property1addre1line3");
                FastDriver.QuickFileEntry.PropertyBookAddrLin4.FASetText("property1addre1line4");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("property1addre1city");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("33610");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("hillsborough");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("FL");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("property1addre2line1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("property1addre2line2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("property1addre2line3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("property1addre2line4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("property1addre2city");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("orange");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("92701");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("CA");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("property1addre3line1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("property1addre3line2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("property1addre3line3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("property1addre3line4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("property1addre3city");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("nye");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("89003");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("NV");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Playback.Wait(8000);
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("property2name");
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FASelectItem("Golf Course");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("property2addre1line1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("property2addre1line2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("property2addre1line3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("property2addre1line4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("property2addre1city");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("apache");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("85925");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("AZ");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Playback.Wait(8000);
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("property3name");
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FASelectItem("Industrial");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("property3addre1line1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("property3addre1line2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("property3addre1line3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("property3addre1line4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("property3addre1city");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("knox");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("43005");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("OH");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("property3addre2line1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("property3addre2line2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("property3addre2line3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("property3addre2line4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("property3addre2city");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("cobb");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("30007");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("GA");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("property3addre3line1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("property3addre3line2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("property3addre3line3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("property3addre3line4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("property3addre3city");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("linn");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("66010");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("KS");
                FastDriver.PropertyTaxInfoLegalDesciption.LegalDescriptionTab.FAClick();
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText("property3lot");
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("property3unit");
                FastDriver.PropertyTaxInfoLegalDesciption.Tract.FASetText("property3tract");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Playback.Wait(5000);
                Reports.TestStep = "Validating the custom header section and property details webpage dialog box on view settlement statement screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.buyerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.borrowerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.customheaderbuyerlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderborrowerlabel.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.sellerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.customheadersellerlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.propertyPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderpropertylabel.IsDisplayed().ToString());
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Accommodation");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.buyerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.borrowerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderbuyerlabel.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.customheaderborrowerlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.sellerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheadersellerlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.propertyPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderpropertylabel.IsDisplayed().ToString());
                FastDriver.NCSViewSettlementStatement.propertyPlusIcon.FAClick();
                Playback.Wait(3000);
                Support.AreEqual("Ctrl+Q", FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.GetAttribute("title").ToString());
                Support.AreEqual("Ctrl+D", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.GetAttribute("title").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.IsEnabled().ToString());
                Support.AreEqual("Property Details", FastDriver.NCSViewSettlementStatement.webpagedialogboxtitle.FAGetText());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                int a = FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElements(ByLocator.TagName, "input").GetAllVisible().Count();
                //int b = FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElements(ByLocator.TagName, "textarea").Count();
                //int a = FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElements(ByLocator.Id, "ckhName").GetAllVisible().Count();
                int b = FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").Count();
                Support.AreEqual("8", a.ToString());
                Support.AreEqual("7", b.ToString());
                var g = FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElements(ByLocator.TagName, "input").GetAllVisible();
                for (int i = 0; i <= a - 1; i++)
                {
                    if (g[i].IsSelected().ToString() == "True")
                    //if (FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElements(ByLocator.TagName, "input").ToList()[i].IsSelected().ToString() == "True")
                    { }
                    else
                    { Reports.StatusUpdate("Error with checkboxes on the property details webpage dialog box", false); }
                }
                string[] c = new string[7];
                c[0] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610\r\nLot: Property1lot Unit: Property1unit Tract: Property1tract";
                c[1] = "property1addre2line1, property1addre2line2, property1addre2line3, property1addre2line4, property1addre2city, CA 92701\r\nLot: Property1lot Unit: Property1unit Tract: Property1tract";
                c[2] = "property1addre3line1, property1addre3line2, property1addre3line3, property1addre3line4, property1addre3city, NV 89003\r\nLot: Property1lot Unit: Property1unit Tract: Property1tract";
                c[3] = "property2addre1line1, property2addre1line2, property2addre1line3, property2addre1line4, property2addre1city, AZ 85925";
                c[4] = "property3addre1line1, property3addre1line2, property3addre1line3, property3addre1line4, property3addre1city, OH 43005\r\nLot: property3lot Unit: property3unit Tract: property3tract";
                c[5] = "property3addre2line1, property3addre2line2, property3addre2line3, property3addre2line4, property3addre2city, GA 30007\r\nLot: property3lot Unit: property3unit Tract: property3tract";
                c[6] = "property3addre3line1, property3addre3line2, property3addre3line3, property3addre3line4, property3addre3city, KS 66010\r\nLot: property3lot Unit: property3unit Tract: property3tract";
                for (int i = 0; i <= b - 1; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList()[i].FAGetText() == c[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes property address contents on the property details webpage dialog box", false); }
                }
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
                Playback.Wait(3000);
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.Exists().ToString());
                FastDriver.NCSViewSettlementStatement.propertyPlusIcon.FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.Id, "ckhSelectAllAddress").FAClick();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                Keyboard.SendKeys("^d");
                Playback.Wait(3000);
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.Exists().ToString());
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.ClickSummaryTable(2, "property2name", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Remove.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Playback.Wait(3000);
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.ClickSummaryTable(2, "Property1name", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoLegalDesciption.LegalDescriptionTab.FAClick();
                Playback.Wait(3000);
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText("aA1!@#$");
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("bB2$%^");
                FastDriver.PropertyTaxInfoLegalDesciption.Tract.FASetText("cC3&*()");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.ClickSummaryTable(2, "property3name", 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoLegalDesciption.LegalDescriptionTab.FAClick();
                Playback.Wait(3000);
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.propertyPlusIcon.FAClick();
                Playback.Wait(3000);
                int d = FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElements(ByLocator.TagName, "input").GetAllVisible().Count();
                int e = FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").Count();
                Support.AreEqual("7", d.ToString());
                Support.AreEqual("6", e.ToString());
                
                for (int i = 0; i <= d - 1; i++)
                {
                    if (g[i].IsSelected().ToString() == "False")
                    //if (FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElements(ByLocator.TagName, "input").ToList()[i].IsSelected().ToString() == "False")
                    { }
                    else
                    { Reports.StatusUpdate("Error with checkboxes on the property details webpage dialog box", false); }
                }
                string[] f = new string[6];
                f[0] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610\r\nLot: aA1!@#$ Unit: bB2$%^ Tract: cC3&*()";
                f[1] = "property1addre2line1, property1addre2line2, property1addre2line3, property1addre2line4, property1addre2city, CA 92701\r\nLot: aA1!@#$ Unit: bB2$%^ Tract: cC3&*()";
                f[2] = "property1addre3line1, property1addre3line2, property1addre3line3, property1addre3line4, property1addre3city, NV 89003\r\nLot: aA1!@#$ Unit: bB2$%^ Tract: cC3&*()";
                f[3] = "property3addre1line1, property3addre1line2, property3addre1line3, property3addre1line4, property3addre1city, OH 43005\r\nLot: property3lot Tract: property3tract";
                f[4] = "property3addre2line1, property3addre2line2, property3addre2line3, property3addre2line4, property3addre2city, GA 30007\r\nLot: property3lot Tract: property3tract";
                f[5] = "property3addre3line1, property3addre3line2, property3addre3line3, property3addre3line4, property3addre3city, KS 66010\r\nLot: property3lot Tract: property3tract";
                for (int i = 0; i <= e - 1; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList()[i].FAGetText() == f[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes property address contents on the property details webpage dialog box", false); }
                }
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0135_REG0021()
        {
            try
            {
                Reports.TestDescription = "US# 668239 and 687881 Display + icon for Buyer and Seller and display all the buyer details in the buyer details dialog. Allow user to select/unselect Seller Names and Addresses in Seller Details dialog to get displayed in the Settlement Statement Header.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log into FAST application automation region/office with automation credentials";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Set up a basic file and the file must contain multiple buyer/seller details";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.txtBusinessSourceGABID.FASetText("800");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                { FastDriver.QuickFileEntry.Title.FASetCheckbox(true); }
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                { FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true); }
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("FL");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.buyerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.sellerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheadersellerlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderpropertylabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderbuyerlabel.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.customheaderborrowerlabel.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.borrowerPlusIcon.IsDisplayed().ToString());
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Construction Finance");
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.propertyPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.customheadersellerlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderborrowerlabel.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.customheaderbuyerlabel.IsDisplayed().ToString());
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.txtBusinessSourceGABID.FASetText("800");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                { FastDriver.QuickFileEntry.Title.FASetCheckbox(true); }
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                { FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true); }
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Trust/Estate");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Business Entity");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2fni 2abcdefgh");
                FastDriver.QuickFileEntry.Seller2MiddleName.FASetText("Seller2mni 2abcdefgh");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2lni 2abcdefgh");
                FastDriver.QuickFileEntry.Seller2Suffix.FASetText("Selle");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("Property1name");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Retail");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("property1addre1line1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("property1addre1line2");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("property1addre1line3");
                FastDriver.QuickFileEntry.PropertyBookAddrLin4.FASetText("property1addre1line4");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("property1addre1city");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("33610");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("hillsborough");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("FL");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Seller3ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab" + FAKeys.Tab);
                FastDriver.BuyerSellerSetup.TrustLastNameFor1099SReporting.FASetText("david warner maxwell" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "Trust/Estate", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Bangalore Mysore");
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "Individual", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("OK");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                Reports.TestStep = "Validating custom header section on VSS online screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Playback.Wait(5000);
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.buyerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.sellerPlusIcon.IsDisplayed().ToString());
                FastDriver.NCSViewSettlementStatement.sellerPlusIcon.FAClick();
                Playback.Wait(5000);
                int a = FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.TagName, "input").Count();
                int b = FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.TagName, "textarea").Count();
                Support.AreEqual("8", a.ToString());
                Support.AreEqual("6", b.ToString());
                for (int i = 0; i <= a - 1; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.TagName, "input").ToList()[i].IsSelected().ToString() == "True")
                    { }
                    else
                    { Reports.StatusUpdate("Error with checkboxes on the seller details webpage dialog box", false); }
                }
                Support.AreEqual("Ctrl+Q", FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.GetAttribute("title").ToString());
                Support.AreEqual("Ctrl+D", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.GetAttribute("title").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                string[] c = new string[3];
                c[0] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610";
                c[1] = "OK";
                c[2] = "property1addre1line2, property1addre1line4, Bangalore Mysore, FL 33610";
                //var e = FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList();
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList()[i].FAGetText() == c[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes current address contents on the seller details webpage dialog box", false); }
                }
                string[] d = new string[3];
                d[0] = "Seller1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab";
                d[1] = "Seller2fni 2abcdefgh Seller2mni 2abcdefgh Seller2lni 2abcdefgh Selle";
                d[2] = "Seller3ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtName").ToList()[i].FAGetText() == d[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes name contents on the seller details webpage dialog box", false); }
                }
                Support.AreEqual("Seller Details", FastDriver.NCSViewSettlementStatement.webpagedialogboxtitle.FAGetText());
                Keyboard.SendKeys("^q");
                Playback.Wait(3000);
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.Exists().ToString());
                FastDriver.NCSViewSettlementStatement.sellerPlusIcon.FAClick();
                Playback.Wait(5000);
                FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElement(ByLocator.Id, "ckhSelectAllName").FAClick();
                //FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElement(ByLocator.Id, "ckhSelectAllAddress").FAClick();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                Keyboard.SendKeys("^d");
                Playback.Wait(3000);
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.Exists().ToString());
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "Individual", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.ClickClear();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "BusinessEntity", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.CurrentCountry.FASelectItem("CANADA");
                Playback.Wait(3000);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.SS.FAClick();
                Playback.Wait(5000);
                FastDriver.TopFrame.SwitchToContentFrame();
                FastDriver.NCSViewSettlementStatement.sellerPlusIcon.FAClick();
                Playback.Wait(5000);
                int e = FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.TagName, "input").Count();
                int f = FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.TagName, "textarea").Count();
                Support.AreEqual("6", e.ToString());
                Support.AreEqual("4", f.ToString());
                string[] g = new string[2];
                //g[0] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4,  ";
                g[0] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4";
                //g[1] = ", property1addre1line2, property1addre1line4, Bangalore Mysore, FL 33610";
                g[1] = "property1addre1line2, property1addre1line4, Bangalore Mysore, FL 33610";
                for (int i = 0; i <= 1; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList()[i].FAGetText() == g[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes current address contents on the seller details webpage dialog box", false); }
                }
                string[] h = new string[2];
                h[0] = "Seller1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab";
                h[1] = "Seller3ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab";
                for (int i = 0; i <= 1; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtName").ToList()[i].FAGetText() == h[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes name contents on the seller details webpage dialog box", false); }
                }
                for (int i = 0; i <= e - 1; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.TagName, "input").ToList()[i].IsSelected().ToString() == "False")
                    { }
                    else
                    { Reports.StatusUpdate("Error with checkboxes on the seller details webpage dialog box", false); }
                }
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                Keyboard.SendKeys("^d");
                Playback.Wait(3000);
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.Exists().ToString());
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0135_REG0023()
        {
            try
            {
                Reports.TestDescription = "US#761831&762820:To Verify the Miscellaneous Disbursements subtotals-Provide right click functionality for Adding/Remove payees to groups";

                #region LOGIN
                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion
                Reports.TestStep = "Login into the IIS Side.";
                Reports.TestStep = "Login FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create File.";
                CreateFile_WS();
                #endregion

                #region Creating Instances
                Reports.TestStep = "Create a Instances on Misc Disbursement Details screen.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                Playback.Wait(3000);
                FillMiscDisbursementDetail(Description: "1stInstFirstcharge", BuyerCharge: "7865", SellerCharge: "9876");
                FastDriver.MiscDisbursementDetail.LoanEstimate.SendKeys(FAKeys.Tab);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "1stInstSecondcharge", 432154326.11, null, 654334562.55, null, 76.00);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "1stInstThirdcharge", 453, null, 876, null, null);
                FastDriver.MiscDisbursementDetail.Description1.JSClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.Click();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details -- Webpage Dialog", true, 20);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("1000");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("2000");

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                Playback.Wait(3000);

                Reports.TestStep = "Create a second Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                Playback.Wait(3000);
                FillMiscDisbursementDetail(Description: "2ndInstFirstCharge", BuyerCharge: "345212345.43", SellerCharge: "563212348.99");
                FastDriver.MiscDisbursementDetail.LoanEstimate.SendKeys(FAKeys.Tab);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "2ndInstSecondCharge", null, null, null, null, 76.00);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "2ndInstThirdCharge", 231, null, 432, null, null);
                FastDriver.MiscDisbursementDetail.Description1.JSClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.Click();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details -- Webpage Dialog", true, 20);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2551");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("2551");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("2551");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");

                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2921");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("2921");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("2921");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Summary screen and Click on NEW.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.New.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();

                Reports.TestStep = "Create a Third Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB3");
                Playback.Wait(3000);
                FillMiscDisbursementDetail(Description: "3rdInstFirstCharge", BuyerCharge: "7676", SellerCharge: "6753");
                FastDriver.MiscDisbursementDetail.LoanEstimate.SendKeys(FAKeys.Tab);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "3rdInstSecondCharge", 345532134.33, null, 546887832.11, null, 86.00);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "3rdInstThirdCharge", 21, null, 43, null, null);
                FastDriver.MiscDisbursementDetail.Description.JSClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.Click();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details -- Webpage Dialog", true, 20);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("114321456.11");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("256");

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                #endregion

                #region Creating Groups in Miscellaneous Disbursement Section
                Reports.TestStep = "Navigate to View Settlestatement and Select Multiple templates (1 or more) by using \"Ctrl\" command";
                FastDriver.NCSViewSettlementStatement.Open();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable.Highlight();

                #region Creating First Group
                var documents = new List<string> { "1stInstFirstcharge " };
                FastDriver.NCSViewSettlementStatement.SelectDocuments(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents);
                RightclickonCharge(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents);
                Reports.TestStep = "Select \"Create group\" option";
                FastDriver.NCSViewSettlementStatement.CreateGroup.Highlight();
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.RemovefromGroupDisabled.IsEnabled(), "Verifying RemoveFromGroup button  Disiabled in Miscellaneous Disbursement section");
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.AddtoGroupDisabled.IsEnabled(), "Verifying AddtoGroup button  Disiabled in Miscellaneous Disbursement section");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.CreateGroup.IsEnabled(), "Verifying CreateGroup button  enabled in Miscellaneous Disbursement section");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.CreateGroup.IsDisplayed(), "Verifying CreateGroup Button Displayed in Miscellaneous Disbursement section");
                FastDriver.NCSViewSettlementStatement.CreateGroup.FASelectContextMenuItem();
                #endregion

                #region Validation Group1 after creating Group
                Reports.TestStep = "Validation Group1 after creating Group";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.MDFirstGroup.Highlight();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.MDFirstGroup.IsDisplayed(), "Validating Group1 atfer clicking on CreateGroup button in Miscellaneous Disbursement section");
                string FirstGroupHeader = FastDriver.NCSViewSettlementStatement.MDFirstGroup.PerformTableAction(1, 4, TableAction.GetText).Message.Trim();
                Support.AreEqual("78,650.00", FastDriver.NCSViewSettlementStatement.MDFirstGroup.PerformTableAction(1, 2, TableAction.GetText).Message.Trim(), "Verify The Buyer Charge Value>");
                Support.AreEqual("98,760.00", FastDriver.NCSViewSettlementStatement.MDFirstGroup.PerformTableAction(1, 5, TableAction.GetText).Message.Trim(), "Verify The Seller Charge Value>");
                verifytheData(FastDriver.NCSViewSettlementStatement.MDFirstGroup, "1stInstFirstcharge B: 78,650.00\r\nS: 98,760.00", null, null, null, null);
                #endregion

                #region Remove Single charge from Group
                Reports.TestStep = "Remove Single charge from Group";
                FastDriver.NCSViewSettlementStatement.SelectDocuments(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents);
                RightclickonCharge(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents);
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.RemovefromGroup.IsEnabled(), "Verifying RemoveFromGroup button  Enabled in Miscellaneous Disbursement section");
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.AddtoGroupDisabled.IsEnabled(), "Verifying AddtoGroup button  Disiabled in Miscellaneous Disbursement section");
                FastDriver.NCSViewSettlementStatement.RemovefromGroup.FASelectContextMenuItem();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 20);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.MDFirstGroup.IsDisplayed(), "Verifying Group1 not displayed in Miscellaneous Disbursement section");
                FastDriver.NCSViewSettlementStatement.SelectDocuments(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents);
                RightclickonCharge(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents);
                Reports.TestStep = "Select \"Create group\" option";
                FastDriver.NCSViewSettlementStatement.CreateGroup.Highlight();
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.RemovefromGroupDisabled.IsEnabled(), "Verifying RemoveFromGroup button  Disiabled in Miscellaneous Disbursement section");
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.AddtoGroupDisabled.IsEnabled(), "Verifying AddtoGroup button  Disiabled in Miscellaneous Disbursement section");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.CreateGroup.IsEnabled(), "Verifying CreateGroup button  enabled in Miscellaneous Disbursement section");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.CreateGroup.IsDisplayed(), "Verifying CreateGroup Button Displayed in Miscellaneous Disbursement section");
                FastDriver.NCSViewSettlementStatement.CreateGroup.FASelectContextMenuItem();
                #endregion

                #region Adding Charge to Existing Group(Group1)
                Reports.TestStep = "Adding Charge to Existing Group(Group1)";
                var documents1 = new List<string> { "1stInstSecondcharge " };
                FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable.Highlight();
                FastDriver.NCSViewSettlementStatement.SelectDocuments(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents1);
                RightclickonCharge(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents1);
                FastDriver.NCSViewSettlementStatement.AddtoGroup.Highlight();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.AddtoGroup.IsEnabled(), "Verifying AddtoGroup button  enabled in Miscellaneous Disbursement section");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.AddtoGroup.IsDisplayed(), "Verifying AddtoGroup Button Displayed in Miscellaneous Disbursement section");
                FastDriver.NCSViewSettlementStatement.AddtoGroup.FASelectContextMenuItem();
                FastDriver.NCSViewSettlementStatement.AddtoGroup.FAMouseOver();
                FastDriver.NCSViewSettlementStatement.AddtoGroupSubList1.Highlight();
                FastDriver.NCSViewSettlementStatement.AddtoGroupSubList1.JSClick();
                #endregion

                #region Validating Charge in group after Adding to Group1
                Reports.TestStep = "Validating Charge in group after Adding to Group1";
                FastDriver.NCSViewSettlementStatement.MDFirstGroup.Highlight();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.MDFirstGroup.IsDisplayed(), "validating Group1 atfer click on CreateGroup button in Miscellaneous Disbursement section");
                Support.AreEqual("432,232,976.11", FastDriver.NCSViewSettlementStatement.MDFirstGroup.PerformTableAction(1, 2, TableAction.GetText).Message.Trim(), "Verify The Buyer Charge Value>");
                Support.AreEqual("654,433,322.55", FastDriver.NCSViewSettlementStatement.MDFirstGroup.PerformTableAction(1, 5, TableAction.GetText).Message.Trim(), "Verify The Seller Charge Value>");
                verifytheData(FastDriver.NCSViewSettlementStatement.MDFirstGroup, "1stInstFirstcharge B: 78,650.00\r\nS: 98,760.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.MDFirstGroup, "1stInstSecondcharge (POC 1,000.00,POC-L 2,000.00) B: 432,154,326.11\r\nS: 654,334,562.55", null, null, null, null);
                #endregion

                #region Creating Second Group
                Reports.TestStep = "Creating Second Group on Miscellaneous Disbursement section";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                var documents2 = new List<string> { "2ndInstSecondCharge ", "1stInstThirdcharge ", "3rdInstFirstCharge " };
                FastDriver.NCSViewSettlementStatement.SelectDocuments(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents2);
                var documents3 = new List<string> { "3rdInstFirstCharge " };
                RightclickonCharge(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents3);
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.RemovefromGroupDisabled.IsEnabled(), "Verifying RemovefromGroup Button Disiabled in Miscellaneous Disbursement section");
                FastDriver.NCSViewSettlementStatement.CreateGroup.Highlight();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.AddtoGroup.IsEnabled(), "Verifying AddtoGroup button  enabled in Miscellaneous Disbursement section");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.CreateGroup.IsEnabled(), "Verifying CreateGroup button  enabled in Miscellaneous Disbursement section");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.CreateGroup.IsDisplayed(), "Verifying CreateGroup Button Displayed in Miscellaneous Disbursement section");
                FastDriver.NCSViewSettlementStatement.CreateGroup.FASelectContextMenuItem();
                #endregion

                #region Validation Group2 after creating Group
                Reports.TestStep = "Validation Group2 after creating Group";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.MDSecondGroup.Highlight();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.MDSecondGroup.IsDisplayed(), "Validating Group2 atfer clicking on CreateGroup button in Miscellaneous Disbursement section");
                string SecondGroupHeader = FastDriver.NCSViewSettlementStatement.MDSecondGroup.PerformTableAction(1, 4, TableAction.GetText).Message.Trim();
                Support.AreEqual("79,764.00", FastDriver.NCSViewSettlementStatement.MDSecondGroup.PerformTableAction(1, 2, TableAction.GetText).Message.Trim(), "Verify The Buyer Charge Value>");
                Support.AreEqual("71,327.00", FastDriver.NCSViewSettlementStatement.MDSecondGroup.PerformTableAction(1, 5, TableAction.GetText).Message.Trim(), "Verify The Seller Charge Value>");
                verifytheData(FastDriver.NCSViewSettlementStatement.MDSecondGroup, "1stInstThirdcharge B: 453.00\r\nS: 876.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.MDSecondGroup, "2ndInstSecondCharge (POC-B 2,551.00,POC-L 2,551.00,POC-S 2,921.00,POC 2,921.00) B: 2,551.00\r\nS: 2,921.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.MDSecondGroup, "3rdInstFirstCharge (POC-L 114,321,712.11) B: 76,760.00\r\nS: 67,530.00", null, null, null, null);


                #endregion

                #region  Removing from one group and adding to Next Group
                Reports.TestStep = "Removing from one group and adding to Next Group";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.SelectDocuments(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents3);
                RightclickonCharge(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents3);
                FastDriver.NCSViewSettlementStatement.RemovefromGroup.Highlight();
                FastDriver.NCSViewSettlementStatement.RemovefromGroup.FASelectContextMenuItem();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 20);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.SelectDocuments(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents3);
                RightclickonCharge(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents3);
                FastDriver.NCSViewSettlementStatement.AddtoGroup.FASelectContextMenuItem();
                FastDriver.NCSViewSettlementStatement.AddtoGroup.FAMouseOver();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.AddtoGroupSubList1.IsEnabled(), "Verifying AddtoGroupSubList1 button  enabled in Miscellaneous Disbursement section");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.AddtoGroupSubList1.IsDisplayed(), "Verifying AddtoGroupSubList1 Button Displayed in Miscellaneous Disbursement section");
                FastDriver.NCSViewSettlementStatement.AddtoGroupSubList1.JSClick();
                #endregion

                #region Validation Group1 after Adding Group
                Reports.TestStep = "Validation Group1 after Adding charge";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.MDFirstGroup.Highlight();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.MDFirstGroup.IsDisplayed(), "Validating Group2 atfer clicking on CreateGroup button in Miscellaneous Disbursement section");
                Support.AreEqual("432,309,736.11", FastDriver.NCSViewSettlementStatement.MDFirstGroup.PerformTableAction(1, 2, TableAction.GetText).Message.Trim(), "Verify The Buyer Charge Value>");
                Support.AreEqual("654,500,852.55", FastDriver.NCSViewSettlementStatement.MDFirstGroup.PerformTableAction(1, 5, TableAction.GetText).Message.Trim(), "Verify The Seller Charge Value>");
                verifytheData(FastDriver.NCSViewSettlementStatement.MDFirstGroup, "1stInstFirstcharge B: 78,650.00\r\nS: 98,760.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.MDFirstGroup, "1stInstSecondcharge (POC 1,000.00,POC-L 2,000.00) B: 432,154,326.11\r\nS: 654,334,562.55", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.MDFirstGroup, "3rdInstFirstCharge (POC-L 114,321,712.11) B: 76,760.00\r\nS: 67,530.00", null, null, null, null);
                #endregion

                #region Validation Group2 after Adding Group
                Reports.TestStep = "Validation Group2 after Adding charge";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.MDSecondGroup.Highlight();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.MDSecondGroup.IsDisplayed(), "Validating Group2 atfer clicking on CreateGroup button in Miscellaneous Disbursement section");
                Support.AreEqual("3,004.00", FastDriver.NCSViewSettlementStatement.MDSecondGroup.PerformTableAction(1, 2, TableAction.GetText).Message.Trim(), "Verify The Buyer Charge Value>");
                Support.AreEqual("3,797.00", FastDriver.NCSViewSettlementStatement.MDSecondGroup.PerformTableAction(1, 5, TableAction.GetText).Message.Trim(), "Verify The Seller Charge Value>");
                verifytheData(FastDriver.NCSViewSettlementStatement.MDSecondGroup, "1stInstThirdcharge B: 453.00\r\nS: 876.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.MDSecondGroup, "2ndInstSecondCharge (POC-B 2,551.00,POC-L 2,551.00,POC-S 2,921.00,POC 2,921.00) B: 2,551.00\r\nS: 2,921.00", null, null, null, null);

                #endregion

                #region Selecting Already grouped Charges and validating the AddtoGroup&Remove Group Buttons disiabled
                Reports.TestStep = "Selecting partof grouped Charges and validating the AddtoGroup&Remove Group Buttons disiabled";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                var documents4 = new List<string> { "2ndInstSecondCharge ", "1stInstFirstcharge " };
                FastDriver.NCSViewSettlementStatement.SelectDocuments(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents4);
                RightclickonCharge(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents);
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.CreateGroup.IsEnabled(), "Verifying CreateGroup button Disiabled in Miscellaneous Disbursement section");
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.CreateGroup.IsDisplayed(), "Verifying CreateGroup button Displayed in Miscellaneous Disbursement section");
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.AddtoGroup.IsEnabled(), "Verifying AddtoGroup button  Disiabled in Miscellaneous Disbursement section");
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.AddtoGroup.IsDisplayed(), "Verifying AddtoGroup Button Displayed in Miscellaneous Disbursement section");
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.RemovefromGroupDisabled.IsEnabled(), "Verifying RemovefromGroup  button  Disabled in Miscellaneous Disbursement section");
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.RemovefromGroupDisabled.IsDisplayed(), "Verifying RemovefromGroup  Button Displayed in Miscellaneous Disbursement section");

                #endregion

                FastDriver.BottomFrame.Done();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(5000);
                #endregion

                #region Navigate to Miscellaneous Disbursement Screen
                Reports.TestStep = "Navigate to  Misc Disbursement Details screen and Perform Action like Remove Instance/Edit Charges/Changing Gab ID/Updating Payee Name.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 1 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();
                Playback.Wait(3000);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("Boa");
                Playback.Wait(3000);
                FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText("5439.00");
                FastDriver.MiscDisbursementDetail.SellerCharge.FASetText("4321.00");
                FastDriver.BottomFrame.Done();
                FastDriver.MiscellaneousDisbursementSummary.WaitForScreenToLoad();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 2 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();
                Playback.Wait(3000);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.Description1.JSClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.Click();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details -- Webpage Dialog", true, 20);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.USEDEFAULT.FASetCheckbox(false);
                if (FastDriver.PaymentDetailsDlg.PayeeName.Enabled == true)
                {
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Updated Payee Name for Testing Misc Disd");
                }
                else
                {
                    FailTest("Payee textbox was not enabled.");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();
                FastDriver.MiscellaneousDisbursementSummary.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 3 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Remove.FAClick();
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(3000);
                #endregion

                #region Navigate to View SS and Validate the changes
                Reports.TestStep = "Navigate to View SS and Validate the changes";
                FastDriver.NCSViewSettlementStatement.Open();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable.Highlight();

                #region Validation Group1 after Updating Gab and charge in Misd
                Reports.TestStep = "Validation Group1 after Updating Gab and charge in Misd";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.MDFirstGroup.Highlight();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.MDFirstGroup.IsDisplayed(), "Validating Group2 atfer clicking on CreateGroup button in Miscellaneous Disbursement section");
                Support.AreEqual(FirstGroupHeader, FastDriver.NCSViewSettlementStatement.MDFirstGroup.PerformTableAction(1, 4, TableAction.GetText).Message.Trim(), "Verify the First Group Header after updating Gab>");
                Support.AreEqual("432,159,765.11", FastDriver.NCSViewSettlementStatement.MDFirstGroup.PerformTableAction(1, 2, TableAction.GetText).Message.Trim(), "Verify The Buyer Charge Value>");
                Support.AreEqual("654,338,883.55", FastDriver.NCSViewSettlementStatement.MDFirstGroup.PerformTableAction(1, 5, TableAction.GetText).Message.Trim(), "Verify The Seller Charge Value>");
                verifytheData(FastDriver.NCSViewSettlementStatement.MDFirstGroup, "1stInstFirstcharge B: 5,439.00\r\nS: 4,321.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.MDFirstGroup, "1stInstSecondcharge (POC 1,000.00,POC-L 2,000.00) B: 432,154,326.11\r\nS: 654,334,562.55", null, null, null, null);
                #endregion

                #region Validation Group2 after updating Payee name in PDD
                Reports.TestStep = "Validation Group2 after updating Payee name in PDD";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.MDSecondGroup.IsDisplayed(), "Validating Group2 atfer clicking on CreateGroup button in Miscellaneous Disbursement section");
                Support.AreEqual(SecondGroupHeader, FastDriver.NCSViewSettlementStatement.MDSecondGroup.PerformTableAction(1, 4, TableAction.GetText).Message.Trim(), "Verify the Second Group Header after updating payeename>");
                Support.AreEqual("3,004.00", FastDriver.NCSViewSettlementStatement.MDSecondGroup.PerformTableAction(1, 2, TableAction.GetText).Message.Trim(), "Verify The Buyer Charge Value>");
                Support.AreEqual("3,797.00", FastDriver.NCSViewSettlementStatement.MDSecondGroup.PerformTableAction(1, 5, TableAction.GetText).Message.Trim(), "Verify The Seller Charge Value>");
                verifytheData(FastDriver.NCSViewSettlementStatement.MDSecondGroup, "1stInstThirdcharge B: 453.00\r\nS: 876.00", null, null, null, null);
                verifytheData(FastDriver.NCSViewSettlementStatement.MDSecondGroup, "2ndInstSecondCharge to Updated Payee Name for Testing Misc Disd (POC-B 2,551.00,POC-L 2,551.00,POC-S 2,921.00,POC 2,921.00) B: 2,551.00\r\nS: 2,921.00", null, null, null, null);

                #endregion

                #endregion


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0135_REG0024()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion
                Reports.TestDescription = "Functionality verification of + icon for Lender label in the Settlement Statement Header section of the View settlement statement screen.";
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);


                #region Create CD File using FileService
                CreateFile_WS();
                #endregion

                #region Through UI
                //Reports.TestStep = "Create File with Commercial business type.";
                //FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                //FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                //FastDriver.QuickFileEntry.WaitForScreenToLoad();
                //FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

                //if (!FastDriver.QuickFileEntry.Title.Selected)
                //{
                //    FastDriver.QuickFileEntry.Title.FAClick();
                //}

                //if (!FastDriver.QuickFileEntry.Escrow.Selected)
                //{
                //    FastDriver.QuickFileEntry.Escrow.FAClick();
                //}

                //Playback.Wait(100);
                //FastDriver.QuickFileEntry.FormType_CD.FAClick();
                //FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                //FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                //FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                //FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                //FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                //FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                //FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                //FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                //FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                //FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                //FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                //FastDriver.BottomFrame.Done();

                //FastDriver.QuickFileEntry.SwitchToTopFrame();
                //string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion

                Reports.TestStep = "Navigate to New Loan screen and add 5 instances of Lenders with charges.";
                #region Instance 1
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("123");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction("Description", "Application Fee", "Buyer Charge", TableAction.SetText, "200.00");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction("Description", "Application Fee", "Seller Charge", TableAction.SetText, "300.00");

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Credit Report", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Credit Report", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.BottomFrame.New();

                #endregion
                #region Instance 2
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("376");
                FastDriver.NewLoan.ClickChargesTab();

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.BottomFrame.New();
                #endregion
                #region Instance 3
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABName.FASetText("Bank Of America");
                FastDriver.NewLoan.FindGABCode("1024");
                FastDriver.NewLoan.ClickChargesTab();

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.BottomFrame.New();
                #endregion
                #region Instance 4
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MGTST1");
                FastDriver.NewLoan.ClickChargesTab();

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.BottomFrame.New();
                #endregion
                #region Instance 5
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("1140");
                FastDriver.NewLoan.ClickChargesTab();

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.BottomFrame.New();
                #endregion
                Reports.TestStep = "Navigate to the View Settlement Stmt screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Reports.TestStep = "Verifying that a (+) indicator next to Lender label is displayed.";
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderPlusIcon.Displayed, "(+) indicator next to Lender label is displayed.");

                Reports.TestStep = "Click the (+) icon to open the lender details dialog.";

                FastDriver.NCSViewSettlementStatement.LenderPlusIcon.FAClick();
                Playback.Wait(5000);
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderHeaderDetails.Displayed, "Lender details dialog box is displayed");

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.Displayed, "Lender details dialog box is displayed");

                Reports.TestStep = "In the Lender Details web dialog user verifies that the Name and Address text fields are editable.";
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").Enabled, "Validating Name field text is enabled.");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtAddr").Enabled, "Validating Name field text is enabled.");

                Reports.TestStep = "Verify the Name text field takes an input of 150 characters length.";
                FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").FASetText("abcdefghlmnkopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ< > * % $ # :;'\\ / + - = ( ) . , _ &abcdefghlmnkopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghlmnkopqrstuvwxyz0123456789ABCDE");

                Support.AreEqual("150", FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").FAGetText().Length.ToString(), "Lenght of accepted input string for Name field is as expected.");

                Reports.TestStep = "Verify the Address text field takes an input of 350 characters length.";
                FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtAddr").FASetText("abcdefghlmnkopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ<>*% $ # :;'- = ( ).,_&abcdefghlmnkopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ<>*% $ # :;'- = ( ).,_&abcdefghlmnkopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ<>*% $ # :;'- = ( ).,_&abcdefghlmnkopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ<>*% $ # :;'- = ( ).,_&abcdefghlmnkopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ<>*% $ # :;'- = ( ).,_&");

                Support.AreEqual("350", FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtAddr").FAGetText().Length.ToString(), "Lenght of accepted input string for Address field is as expected.");

                Reports.TestStep = "In the Lender Details web dialog user verifies that in the Display Name in Header column all checkboxes are checked and enabled.";
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhName").Selected, "Validating 1st Name check box is selected.");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(4, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhName").Selected, "Validating 2nd Name checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(5, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhName").Selected, "Validating 3rd Name checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(6, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhName").Selected, "Validating 4th Name checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(7, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhName").Selected, "Validating 5th  Name checkbox is selected..");

                Reports.TestStep = "In the Lender Details web dialog user verifies that in the Display Address in Header column all checkboxes are checked and enabled.";
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 5, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhAddr").Selected, "Validating 1st Addres checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(4, 5, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhAddr").Selected, "Validating 2nd Addres checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(5, 5, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhAddr").Selected, "Validating 3rd Addres checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(6, 5, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhAddr").Selected, "Validating 4th Addres checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(7, 5, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhAddr").Selected, "Validating 5th Addres checkbox is selected..");

                Reports.TestStep = "In the Lender Details web dialog user erases the name of the first lender and clicks on done.";
                FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").Clear();
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").FAGetText().Equals("Name cannot be blank..."), "Verifying Error message when 1st lender name field is blank.");

                Reports.TestStep = "User proceeds to verify the Name field cannot be empty message is triggered by the rest of Lender names displayed being erased in the web dialog.";
                Reports.StatusUpdate("2nd Lender instance", true);
                FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(4, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").Clear();
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(4, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").FAGetText().Equals("Name cannot be blank..."), "Verifying Error message when 2nd lender name field is blank.");

                Reports.StatusUpdate("3rd Lender instance", true);
                FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(5, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").Clear();
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(5, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").FAGetText().Equals("Name cannot be blank..."), "Verifying Error message when 3rd lender name field is blank.");

                Reports.StatusUpdate("4th Lender instance", true);
                FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(6, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").Clear();
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(6, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").FAGetText().Equals("Name cannot be blank..."), "Verifying Error message when 4th lender name field is blank.");

                Reports.StatusUpdate("5th Lender instance", true);
                FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(7, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").Clear();
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(7, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").FAGetText().Equals("Name cannot be blank..."), "Verifying Error message when 5th lender name field is blank.");
                //FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(1, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName");
                //Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(1, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName"), "Text name area 1 s enabled.");

                //FastDriver.NCSViewSettlementStatement.LenderHeaderDetails.PerformTableAction(1, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName");

                //FastDriver.NCSViewSettlementStatement.LenderHeaderDetails.FAFindElement(ByLocator.Id, "customPopUp").PerformTableAction(1, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName");
            }
            catch (Exception ex)
            { FailTest(ex.Message); }
        }
        [TestMethod]
        public void FMUC0135_REG0025()
        {
            try
            {
                Reports.TestDescription = "US# 686386 Allow user to select Buyer Names and Addresses in the Buyer Details dialog to be displayed in the Settlement Statement Header.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log into FAST application automation region/office with automation credentials";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Set up a basic file and the file must contain multiple buyer/seller details";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.txtBusinessSourceGABID.FASetText("800");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                { FastDriver.QuickFileEntry.Title.FASetCheckbox(true); }
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                { FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true); }
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Trust/Estate");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Business Entity");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2fnhi 2abcdefgh");
                FastDriver.QuickFileEntry.Buyer2MiddleName.FASetText("Buyer2mnhi 2abcdefgh");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2lnhi 2abcdefgh");
                FastDriver.QuickFileEntry.Buyer2Suffix.FASetText("Buyer");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("Property1name");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Retail");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("property1addre1line1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("property1addre1line2");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("property1addre1line3");
                FastDriver.QuickFileEntry.PropertyBookAddrLin4.FASetText("property1addre1line4");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("property1addre1city");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("33610");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("hillsborough");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("FL");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Buyer3fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "Trust/Estate", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FAClick();
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "Individual", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("property1addre2line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("property1addre2line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("property1addre2line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("property1addre2line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("property1addre2city");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("66010");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("linn");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("KS");
                Reports.TestStep = "Validating custom header section on VSS online screen";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.SS.FAClick();
                Playback.Wait(5000);
                FastDriver.TopFrame.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.buyerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.sellerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.borrowerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.customheaderborrowerlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderbuyerlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheadersellerlabel.IsDisplayed().ToString());
                FastDriver.NCSViewSettlementStatement.buyerPlusIcon.FAClick();
                Playback.Wait(5000);
                int a = FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.TagName, "input").Count();
                int b = FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.TagName, "textarea").Count();
                Support.AreEqual("8", a.ToString());
                Support.AreEqual("6", b.ToString());
                for (int i = 0; i <= a - 1; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.TagName, "input").ToList()[i].IsSelected().ToString() == "True")
                    { }
                    else
                    { Reports.StatusUpdate("Error with checkboxes on the buyer details webpage dialog box", false); }
                }
                Support.AreEqual("Ctrl+Q", FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.GetAttribute("title").ToString());
                Support.AreEqual("Ctrl+D", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.GetAttribute("title").ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.IsEnabled().ToString());
                Support.AreEqual("Buyer Details", FastDriver.NCSViewSettlementStatement.webpagedialogboxtitle.FAGetText());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                string[] c = new string[3];
                c[0] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610";
                c[1] = "property1addre2line1, property1addre2line2, property1addre2line3, property1addre2line4, property1addre2city, KS 66010";
                c[2] = "";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList()[i].FAGetText() == c[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes current address contents on the buyer details webpage dialog box", false); }
                }
                string[] d = new string[3];
                d[0] = "Buyer1fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab";
                d[1] = "Buyer2fnhi 2abcdefgh Buyer2mnhi 2abcdefgh Buyer2lnhi 2abcdefgh Buyer";
                d[2] = "Buyer3fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtName").ToList()[i].FAGetText() == d[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes name contents on the buyer details webpage dialog box", false); }
                }
                Keyboard.SendKeys("^q");
                Playback.Wait(3000);
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.Exists().ToString());
                FastDriver.NCSViewSettlementStatement.buyerPlusIcon.FAClick();
                Playback.Wait(5000);
                FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElement(ByLocator.Id, "ckhSelectAllName").FAClick();
                //FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElement(ByLocator.Id, "ckhSelectAllAddress").FAClick();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                Keyboard.SendKeys("^d");
                Playback.Wait(3000);
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.Exists().ToString());
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "Individual", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.ClickClear();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "Trust/Estate", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("!@#$%^&*()_+" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "BusinessEntity", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Oo0!@#$%^" + FAKeys.Tab);
                FastDriver.BuyerSellerSetup.CurrentCountry.FASelectItem("CANADA");
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("THIS IS CANADIAN ADDRESS 123!@#");
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("McGrath");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Pollock");
                FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText("Ponting");
                FastDriver.BuyerSellerSetup.IndividualSuffix.FASetText("Imran");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("85929");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("apache");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("AZ");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Melbourne bay");
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.SS.FAClick();
                Playback.Wait(5000);
                FastDriver.TopFrame.SwitchToContentFrame();
                FastDriver.NCSViewSettlementStatement.buyerPlusIcon.FAClick();
                Playback.Wait(5000);
                for (int i = 0; i <= a - 1; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.TagName, "input").ToList()[i].IsSelected().ToString() == "False")
                    { }
                    else
                    { Reports.StatusUpdate("Error with checkboxes on the buyer details webpage dialog box", false); }
                }
                string[] e = new string[3];
                e[0] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610";
                e[1] = "THIS IS CANADIAN ADDRESS 123!@#";
                e[2] = "Melbourne bay, AZ 85929";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList()[i].FAGetText() == e[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes current address contents on the buyer details webpage dialog box", false); }
                }
                string[] f = new string[3];
                f[0] = "!@#$%^&*()_+";
                f[1] = "Oo0!@#$%^";
                f[2] = "McGrath Ponting Pollock Imran";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtName").ToList()[i].FAGetText() == f[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes name contents on the buyer details webpage dialog box", false); }
                }
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Mtg Mod w/Increased Liability");
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.SS.FAClick();
                Playback.Wait(5000);
                FastDriver.TopFrame.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.borrowerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.buyerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderborrowerlabel.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.customheaderbuyerlabel.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.customheadersellerlabel.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.sellerPlusIcon.IsDisplayed().ToString());
                FastDriver.NCSViewSettlementStatement.borrowerPlusIcon.FAClick();
                Support.AreEqual("Borrower Details", FastDriver.NCSViewSettlementStatement.webpagedialogboxtitle.FAGetText());
                for (int i = 0; i <= a - 1; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.TagName, "input").ToList()[i].IsSelected().ToString() == "False")
                    { }
                    else
                    { Reports.StatusUpdate("Error with checkboxes on the borrower details webpage dialog box", false); }
                }
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList()[i].FAGetText() == e[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes current address contents on the borrower details webpage dialog box", false); }
                }
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtName").ToList()[i].FAGetText() == f[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes name contents on the borrower details webpage dialog box", false); }
                }
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0135_REG0030()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "#US 608744 for Settlement Statement Header in View Settlement Statement- Refinance files.";
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Through UI
                Reports.TestStep = "Create File with Commercial business type.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Refinance");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.EscrowOwningOfficeOfficer.FASelectItem("Y, Yeshwanth");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("Property 1");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Agricultural Land");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationTRact.FASetText("Tract1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First property: Address1 line 1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("First property: Address1 line 2");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("First property: Address1 line 3");
                FastDriver.QuickFileEntry.PropertyBookAddrLin4.FASetText("First property: Address1 line 4");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("City1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("NV");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("89003");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Nye");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFN1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLN1");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFN1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLN1");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("420");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                FastDriver.FileHomepage.Open();
                string fileNum = FastDriver.FileHomepage.FileNumPrefix.FAGetValue() + FastDriver.FileHomepage.FileNum.FAGetValue() + FastDriver.FileHomepage.FileNumSufix.FAGetValue();
                FastDriver.TopFrame.SwitchToContentFrame();
                string[] EscrowOfficerName = FastDriver.FileHomepage.EscrowOwningOfficeOfficer.FAGetSelectedItem().Split(',');
                #endregion

                #region Setting test data for Property, Buyer, Seller, Lender
                Reports.TestStep = "Navigate to Properties/Tax Info and add Property details";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("First property: Address2 line 1");//Property 1 Address 2 
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("First property: Address2 line 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("First property: Address2 line 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("First property: Address2 line 4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("City2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("AZ");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("85925");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Apache");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("First property: Address3 line 1");//Property 1 Address 3
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("First property: Address3 line 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("First property: Address3 line 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("First property: Address3 line 4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("City3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("FL");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("32003");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Clay");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Playback.Wait(10000);
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                //Property 2
                FastDriver.PropertiesSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("Property 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FASelectItem("Condominium");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Second property: Address1 line 1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("Second property: Address1 line 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("Second property: Address1 line 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("Second property: Address1 line 4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("City2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("KS");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("66901");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Cloud");
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText("Lot2");
                FastDriver.PropertyTaxInfoLegalDesciption.Tract.FASetText("Tract2");
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("Unit2");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Playback.Wait(10000);
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                //Property 3
                FastDriver.PropertiesSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("Property 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FASelectItem("Industrial");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Third property: Address1 line 1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("Third property: Address1 line 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("Third property: Address1 line 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("Third property: Address1 line 4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("City3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("HI");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("96708");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Maui");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Reports.TestStep = "Navigate to Buyers screen and add Buyer details";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.New();
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Husband/Wife");
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("Buyer2Spouse1FN");
                FastDriver.BuyerSellerSetup.HusbandLastName.FASetText("Buyer2Spouse1FN");
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Buyer2Spouse2FN");
                FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FASetText("Buyer2Spouse2LN");
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FAClick();
                FastDriver.BuyerSellerSetup.btnNew.FAClick();
                Playback.Wait(5000);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("BuyerFN3");
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FAClick();
                FastDriver.BuyerSellerSetup.btnNew.FAClick();
                Playback.Wait(5000);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                Playback.Wait(5000);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("BuyerFN4");
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FAClick();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to New Loan screen and add Lender details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("800");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("2,20,000.00");
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("2,70,000.00");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to Assumption Loan screen and add Lender details";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("boa");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("473");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                //Playback.Wait(5000);
                //FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                //FastDriver.AddressBookSearchDlg.FileaddressBookRadio_1.FAClick();
                //Playback.Wait(5000);
                //FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio1.FAClick();
                //FastDriver.AddressBookSearchDlg.SwitchToDialogBottomFrame();
                //FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                #endregion

                #region Verify the Header section in the View settlement statement
                Reports.TestStep = "Navigate to viewsettlement statement and verify the header section";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Reports.TestStep = "Verify the First section of Header section in ViewSettlement Statement";
                //Should be uncommented during Transistion Phase or in FeatINT
                Support.AreEqual("File No: " + fileNum, FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[1]").FAGetText());//Validation of File No: field 
                Support.AreEqual("Escrow Officer:" + EscrowOfficerName[1] + " " + EscrowOfficerName[0] + "/FQ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[2]").FAGetText());
                Reports.TestStep = "Verify the Property section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderpropertylabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.propertyPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("First property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[1]/div[1]").FAGetText());
                Support.AreEqual("First property: Address2 line 1, First property: Address2 line 2, First property: Address2 line 3, First property: Address2 line 4, City2, AZ 85925\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[1]/div[2]").FAGetText());
                Support.AreEqual("First property: Address3 line 1, First property: Address3 line 2, First property: Address3 line 3, First property: Address3 line 4, City3, FL 32003\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[2]/div[1]").FAGetText());
                Support.AreEqual("Second property: Address1 line 1, Second property: Address1 line 2, Second property: Address1 line 3, Second property: Address1 line 4, City2, KS 66901\r\nLot: Lot2 Unit: Unit2 Tract: Tract2", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[2]/div[2]").FAGetText());
                Support.AreEqual("Third property: Address1 line 1, Third property: Address1 line 2, Third property: Address1 line 3, Third property: Address1 line 4, City3, HI 96708", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[3]/div").FAGetText());
                Reports.TestStep = "Verify the Buyer section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderborrowerlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.borrowerPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("BuyerFN1  BuyerLN1\r\nFirst property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[7]/div/div[1]").FAGetText());
                Support.AreEqual("Buyer2Spouse1FN  Buyer2Spouse1FN/Buyer2Spouse2FN  Buyer2Spouse2LN\r\nFirst property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[7]/div[1]/div[2]").FAGetText());
                Support.AreEqual("BuyerFN3\r\nFirst property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[7]/div[2]/div[1]").FAGetText());
                Support.AreEqual("BuyerFN4\r\nFirst property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[7]/div[2]/div[2]").FAGetText());
                Reports.TestStep = "Verify the Seller Details is not displayed in Header Section in ViewSettlement Statement";
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.customheadersellerlabel.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.sellerPlusIcon.IsDisplayed().ToString());
                Reports.TestStep = "Verify the Lender section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderLenderlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.LenderPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("The Northern Trust Company\r\n4811 Emerson, Palatine, IL 60067     ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[1]/div[1]").FAGetText());
                Support.AreEqual("First American Title Company\r\n12600 Hesperia Road #C, Victorville, CA 92392     ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[1]/div[2]").FAGetText());
                Support.AreEqual("Lenders Advantage A Division Of First American Title Ins.\r\n15441 94Th Avenue, Orland Park, IL 60462     ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[2]/div").FAGetText());
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                #endregion

                #region Deleting the Property, Buyer, Seller and Lender Details
                Reports.TestStep = "Navigate to Properties/Tax Info and delete the address of the first Property details";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                Playback.Wait(3000);
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to Buyer screen and delete all the buyer details";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(5, 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Reports.TestStep = "Navigate to New Loan screen and delete Lender details";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                #endregion

                #region Verify the Header section in the View settlement statement after deleting Buyer, Seller and New Lender information
                Reports.TestStep = "Navigate to viewsettlement statement and verify the header section";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Reports.TestStep = "Verify the First section of Header section in ViewSettlement Statement";
                //Validation of File No: field //Should be uncommented during Transistion Phase or in FeatINT
                Support.AreEqual("File No: " + fileNum, FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[1]").FAGetText());//Validation of File No: field 
                Support.AreEqual("Escrow Officer:" + EscrowOfficerName[1] + " " + EscrowOfficerName[0] + "/FQ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[2]").FAGetText());
                Reports.TestStep = "Verify the Property section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderpropertylabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.propertyPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("First property: Address2 line 1, First property: Address2 line 2, First property: Address2 line 3, First property: Address2 line 4, City2, AZ 85925\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[1]/div[1]").FAGetText());
                Support.AreEqual("First property: Address3 line 1, First property: Address3 line 2, First property: Address3 line 3, First property: Address3 line 4, City3, FL 32003\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[1]/div[2]").FAGetText());
                Support.AreEqual("Second property: Address1 line 1, Second property: Address1 line 2, Second property: Address1 line 3, Second property: Address1 line 4, City2, KS 66901\r\nLot: Lot2 Unit: Unit2 Tract: Tract2", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[2]/div[1]").FAGetText());
                Support.AreEqual("Third property: Address1 line 1, Third property: Address1 line 2, Third property: Address1 line 3, Third property: Address1 line 4, City3, HI 96708", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[2]/div[2]").FAGetText());
                Reports.TestStep = "Verify the Buyer section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderborrowerlabel.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.buyerPlusIcon.IsDisplayed().ToString());
                Reports.TestStep = "Verify the Seller section of Header section in ViewSettlement Statement";
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.customheadersellerlabel.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.sellerPlusIcon.IsDisplayed().ToString());
                Reports.TestStep = "Verify the Lender section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderLenderlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.LenderPlusIcon.IsDisplayed().ToString());
                Support.AreEqual("Bank of America", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[1]/div[1]").FAGetText());
                Support.AreEqual("World Savings Bank\r\n1144 Lake Street, Oak Park, IL 60301     ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[1]/div[2]").FAGetText());
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                #endregion
            }
            catch (Exception ex)
            { FailTest(ex.Message); }
        }
        [TestMethod]
        public void FMUC0135_REG0036()
        {
            try
            {

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion
                #region Loginto IIs and create file with business segment as commercial
                Reports.TestStep = "Loginto IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create file with business segment as commercial";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.Click();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Accommodation");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("Firstamway");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();


                #endregion

                #region Create Miscellaneous Disbursement instances
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("255");
                Playback.Wait(8000);

                FillMiscDisbursementDetail("Miscellaneous description1", "76.88", "34.65");


                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDLEASE01");
                Playback.Wait(8000);
                FillMiscDisbursementDetail("Miscellaneous description2", "237.45", "874.76");

                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(8000);
                FillMiscDisbursementDetail("Miscellaneous description3", "642.6", "13.78");
                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDFLINSR1");
                Playback.Wait(8000);
                FillMiscDisbursementDetail("Miscellaneous description4", "94753.65", "12.89");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to View SS and create group
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.");
                var documents = new List<String> { "Miscellaneous description1 ", "Miscellaneous description2 ", "Miscellaneous description3 " };
                FastDriver.NCSViewSettlementStatement.SelectDocuments(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents);
                Reports.TestStep = "Hold Right Click";
                FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable.PerformTableAction(2, 4, TableAction.GetCell).Element.FARightClick();
                Reports.TestStep = "Select \"Create group\" option";

                FastDriver.NCSViewSettlementStatement.CreateGroup.FASelectContextMenuItem();
                FastDriver.BottomFrame.Done();
             
                #endregion

                #region validation after creating Group
                Reports.TestStep = "validation after creating Group";
                Playback.Wait(6000);
                FastDriver.NCSViewSettlementStatement.SwitchToContentFrame();
                FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable.PerformTableAction(4, "Total to Thomas Freeman", 5, TableAction.Click);
                #endregion
                #region Rename the group payee name
                Reports.TestStep = "Verify for payee name limit to 50 characters";
               
                // FastDriver.NCSViewSettlementStatement.MDFirstGroup.FAFindElement(ByLocator.XPath, "//span[text()='Thomas Freeman']").Highlight();
                //FastDriver.NCSViewSettlementStatement.MDFirstGroup.FAFindElement(ByLocator.XPath, "//span[text()='Thomas Freeman']").FADoubleClick();
                //FastDriver.NCSViewSettlementStatement.MDFirstGroup.FAFindElement(ByLocator.XPath, "//span[text()='Thomas Freeman']").Clear();
                //FastDriver.NCSViewSettlementStatement.MDFirstGroup.FAFindElement(ByLocator.XPath, "//span[text()='']").FASetText("Group1 Payee");
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.Highlight();
                FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.FADoubleClick();
                FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.FASetText("Payeenameforverifyingthe50charactertestingscenariotest");
                FastDriver.BottomFrame.Done();
                Playback.Wait(9000);
                FastDriver.NCSViewSettlementStatement.SwitchToContentFrame();
                FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.Highlight();
                Support.AreEqual("Payeenameforverifyingthe50charactertestingscenari", FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.FAGetText(), "True");
                Reports.TestStep = "Rename the group payee name";
                FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.Highlight();
                FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.FADoubleClick();            
                FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.FASetText("Group1 Payee");
                FastDriver.BottomFrame.Done();
                Playback.Wait(9000);
                FastDriver.NCSViewSettlementStatement.SwitchToContentFrame();
                FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.Highlight();               
                Support.AreEqual("Group1 Payee", FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.FAGetText(), "True");                            
               
                #endregion
                #region validation on blank group payee name and payee name containing special characters
                Reports.TestStep = "validation on blank group payee name and payee name containing special characters";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.FADoubleClick();
                FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.Clear();
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Description cannot be blank", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, timeout: 10).ToString());
                FastDriver.NCSViewSettlementStatement.SwitchToContentFrame();
                Support.AreEqual("Group1 Payee", FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.FAGetText(), "True");
                FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.FADoubleClick();
                FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.FASetText("test ^{}[]special9");
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Description may only contain 0-9 a-z A-Z < > * % $ # : ;  ' \" / + - = ( ) . , _ & characters", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, timeout: 10).ToString());
                FastDriver.NCSViewSettlementStatement.SwitchToContentFrame();
                Support.AreEqual("Group1 Payee", FastDriver.NCSViewSettlementStatement.MiscDisbpayee_edit.FAGetText(), "True");
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0135_REG0038()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion
                Reports.TestDescription = "Functionality verification of select/unselect Lender Names and Addresses in Lender Details dialog to get displayed in the Settlement Statement Header.";
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                //FastDriver.LeftFrame.SwitchToTopFrame();
                //FastDriver.TopFrame.SetNumberAndPressEnter("37490");
                #region Create CD File using FileService
                var customizableFileRequest = new CreateFileRequest()
                {
                    EmployeeObjectCD = "1",
                    Source = "FAST",
                    Target = "FAST",
                    formType = FormType.CD,//NCS only works for CD
                    File = new File()
                    {
                        SalesPriceAmount = 5000,
                        FirstNewLoanAmount = 10000,
                        BusinessSegmentObjectCD = "Commercial",
                        TransactionTypeObjectCD = "SALE",//Sale w/Mortgage
                        ExternalFileNumber = "123456789",
                        AutoNumberIndicator = true,
                        BusinessParties = new FileBusinessParty[]
                                {
                                    new FileBusinessParty()
                                        {
                                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId(gabCode: "HUDFLINSR1", regionBUID: 1486),
                                        //HUDFLINSR1 >> 8836264
                                        //488 >> 8835468
                                        RoleTypeObjectCD = "BUSSOURCE",
                                        AdditionalRole = new AdditionalRoleList()
                                            {
                                            eAddtionalRole = AdditionalRoleType.NewLender
                                            },
                                        },

                                    //new FileBusinessParty()
                                    //    {
                                    //    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("50812"),
                                    //    RoleTypeObjectCD = "DIRECTEDBY"
                                    //    }
                                    },
                        Services = new Service[]
                                    {
                                    new Service()
                                        {
                                        OfficeInfo = new OfficeInfo()
                                            {
                                            //RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),//change?
                                            RegionID = 1486,
                                            //BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID),//change?
                                            BUID = 1487,
                                            ProductionOffices = new ProductionOffice[]
                                                {
                                                new ProductionOffice()
                                                    {
                                                    BUID = 0,
                                                    OfficeCode = 0,
                                                    RegionID = 0,
                                                    SeqNum = 0
                                                    }
                                                }
                                            },
                                        ServiceTypeObjectCD = "TO"
                                        },
                                    new Service()
                                        {
                                        OfficeInfo = new OfficeInfo()
                                            {
                                            //RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),//change?
                                            RegionID = 1486,
                                            //BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID),//change?
                                            BUID = 1487,
                                            ProductionOffices = new ProductionOffice[]
                                                {
                                                new ProductionOffice()
                                                    {
                                                    BUID = 0,
                                                    OfficeCode = 0,
                                                    RegionID = 0,
                                                    SeqNum = 0
                                                    }
                                                }
                                            },
                                        ServiceTypeObjectCD = "EO"
                                        }
                                },
                        Properties = new Property[]
                                    {
                                    new Property()
                                        {
                                        PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                                            {
                                            new FASTWCFHelpers.FastFileService.PhysicalAddress()
                                                {
                                                AddrLine1 = "BTM Mico Layout",
                                                AddrLine2 = "Near Saibaba Temple",
                                                AddrLine3 = "BTM 1st Stage",
                                                AddrLine4 = "KEB Layout",
                                                City = "Bangalore Mysore",
                                                Zip = "89003",
                                                State = "NV",
                                                County = "Nye",
                                                }
                                            }
                                        }
                                    },
                        FileNotes = new FileNote[]
                            {
                                new FileNote()
                                {
                                    Note = "Notes Data including - * # Specialcharacter :) !",
                                    TypeCdID = 695 //EPIC
                                }
                            }
                    }

                };

                var CreateFile = FileService.CreateFile(customizableFileRequest);
                Support.AreEqual("File Saved Successfully.", CreateFile.OperationResponse.StatusDescription);
                var File = FileService.GetOrderDetails((int)CreateFile.FileID);
                //FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                string FileNumber = File.FileNumber;
                FastDriver.LeftNavigation.SwitchToTopFrame();
                FastDriver.TopFrame.FileNumberEditBox.FASetText(File.FileNumber);
                Keyboard.SendKeys("{ENTER}");


                #endregion
                #region Through UI kept for reference.
                //Reports.TestStep = "Create File with Commercial business type.";
                //FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                //FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                //FastDriver.QuickFileEntry.WaitForScreenToLoad();
                //FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

                //if (!FastDriver.QuickFileEntry.Title.Selected)
                //{
                //    FastDriver.QuickFileEntry.Title.FAClick();
                //}

                //if (!FastDriver.QuickFileEntry.Escrow.Selected)
                //{
                //    FastDriver.QuickFileEntry.Escrow.FAClick();
                //}

                //Playback.Wait(100);
                //FastDriver.QuickFileEntry.FormType_CD.FAClick();
                //FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                //FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                //FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                //FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                //FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                //FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                //FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                //FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
                //FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
                //FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
                //FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
                //FastDriver.BottomFrame.Done();

                //FastDriver.QuickFileEntry.SwitchToTopFrame();
                //string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion
                Reports.TestStep = "Navigate to New Loan screen and add 5 instances of Lenders with charges.";
                #region Instance 1
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("123");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction("Description", "Application Fee", "Buyer Charge", TableAction.SetText, "200.00");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction("Description", "Application Fee", "Seller Charge", TableAction.SetText, "300.00");

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Credit Report", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Credit Report", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.BottomFrame.New();

                #endregion
                #region Instance 2
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("376");
                FastDriver.NewLoan.ClickChargesTab();

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.BottomFrame.New();
                #endregion
                #region Instance 3
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABName.FASetText("Bank Of America");
                FastDriver.NewLoan.FindGABCode("1024");
                FastDriver.NewLoan.ClickChargesTab();

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.BottomFrame.New();
                #endregion
                #region Instance 4
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MGTST1");
                FastDriver.NewLoan.ClickChargesTab();

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.BottomFrame.New();
                #endregion
                #region Instance 5
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("1140");
                FastDriver.NewLoan.ClickChargesTab();

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Seller Charge", TableAction.SetText, "5000.00");
                FastDriver.BottomFrame.New();
                #endregion
                Reports.TestStep = "Navigate to the View Settlement Stmt screen";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Reports.TestStep = "Verifying that a (+) indicator next to Lender label is displayed.";
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderPlusIcon.Displayed, "(+) indicator next to Lender label is displayed.");
                Reports.TestStep = "Click the (+) icon to open the lender details dialog.";
                FastDriver.NCSViewSettlementStatement.LenderPlusIcon.FAClick();
                Playback.Wait(5000);
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderHeaderDetails.Displayed, "Lender details dialog box is displayed");

                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.Displayed, "Lender details dialog box is displayed");

                Reports.TestStep = "In the Lender Details web dialog user verifies that the Name and Address text fields are editable.";
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").Enabled, "Validating Name field text is enabled.");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtAddr").Enabled, "Validating Name field text is enabled.");

                Reports.TestStep = "Verify the Name text field takes an input of 150 characters length.";
                FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").FASetText("abcdefghlmnkopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ< > * % $ # :;'\\ / + - = ( ) . , _ &abcdefghlmnkopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghlmnkopqrstuvwxyz0123456789ABCDE");

                Support.AreEqual("150", FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").FAGetText().Length.ToString(), "Lenght of accepted input string for Name field is as expected.");

                Reports.TestStep = "Verify the Address text field takes an input of 350 characters length.";
                FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtAddr").FASetText("abcdefghlmnkopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ< > * % $ # :;'- = ( ) . , _ &abcdefghlmnkopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ< > * % $ # : ; ' \\ / + - = ( ) . , _ &abcdefghlmnkopqrstuvwxyzabcdefghlmnkopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ< > * % $ # :;'- = ( ) . , _ &abcdefghlmnkopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ< > * % $ # : ; ' \\ / + - = ( ) . , _ &abcdefghlmnkopqrstuvwxyz");

                Support.AreEqual("350", FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtAddr").FAGetText().Length.ToString(), "Lenght of accepted input string for Address field is as expected.");

                Reports.TestStep = "In the Lender Details web dialog user verifies that in the Display Name in Header column all checkboxes are checked and enabled.";
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhName").Selected, "Validating 1st Name check box is selected.");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(4, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhName").Selected, "Validating 2nd Name checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(5, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhName").Selected, "Validating 3rd Name checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(6, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhName").Selected, "Validating 4th Name checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(7, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhName").Selected, "Validating 5th  Name checkbox is selected..");

                Reports.TestStep = "In the Lender Details web dialog user verifies that in the Display Address in Header column all checkboxes are checked and enabled.";
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 5, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhAddr").Selected, "Validating 1st Addres checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(4, 5, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhAddr").Selected, "Validating 2nd Addres checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(5, 5, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhAddr").Selected, "Validating 3rd Addres checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(6, 5, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhAddr").Selected, "Validating 4th Addres checkbox is selected..");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(7, 5, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "ckhAddr").Selected, "Validating 5th Addres checkbox is selected..");
                Reports.TestStep = "In the Lender Details web dialog user erases the name of the first lender and clicks on done.";
                FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(3, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName").FASetText(" ");
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);

                //FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(1, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName");
                //Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.LenderDetailsPopUpTbl.PerformTableAction(1, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName"), "Text name area 1 s enabled.");

                //FastDriver.NCSViewSettlementStatement.LenderHeaderDetails.PerformTableAction(1, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName");

                //FastDriver.NCSViewSettlementStatement.LenderHeaderDetails.FAFindElement(ByLocator.Id, "customPopUp").PerformTableAction(1, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "txtName");
            }
            catch (Exception ex)
            { FailTest(ex.Message); }
        }
        #endregion
        #region HelpMethod
        private void NCSLogin(bool admLogin = false)
        {
            if (!admLogin)
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU
                };

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            }
            else
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                    //UserName = AutoConfig.UserName,
                    //Password = AutoConfig.UserPassword
                };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                //FASTLogin.Login(Support.GetRunCategoryOption("WEBSITE", "FASTADM_URL"), credentials, true);
            }

            //
            //

        }

        private void SelectNCSRegion()
        {
            Reports.TestStep = "Navigate to a region and office with the Feature 5 permission.";
            //FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedOfficeBUID);
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("1552");
        }

        public static int CreateCDFile()
        {
            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            //var customizableFileRequest = RequestFactory.NCSCreateCommercialFilewAmounts();
            customizableFileRequest.formType = FormType.CD;
            //customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.SalesPriceAmount = 5000;
            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        //AddrBookEntryID = AdminService.GetGABAddressBookEntryId("50811"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    },

                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = AdminService.GetGABAddressBookEntryId("50812"),
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("508"),
                        RoleTypeObjectCD = "DIRECTEDBY"
                    }
                };
            customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
            var CreateFile = FileService.CreateFile(customizableFileRequest);
            Support.AreEqual("File Saved Successfully.", CreateFile.OperationResponse.StatusDescription);
            var File = FileService.GetOrderDetails((int)CreateFile.FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            return Convert.ToInt32(File.FileNumber);
        }

        public static int CreateCDFileNew()
        {
            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            //var customizableFileRequest = RequestFactory.NCSCreateCommercialFilewAmounts();
            customizableFileRequest.formType = FormType.CD;
            //customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.SalesPriceAmount = 5000;
            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("800"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                    
                };
            customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
            customizableFileRequest.File.SalesPriceAmount = 3000000;
            customizableFileRequest.File.FirstNewLoanAmount = 1500000;
            var CreateFile = FileService.CreateFile(customizableFileRequest);
            Support.AreEqual("File Saved Successfully.", CreateFile.OperationResponse.StatusDescription);
            var File = FileService.GetOrderDetails((int)CreateFile.FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            return Convert.ToInt32(File.FileNumber);
        }

        public static int CreateFile()
        {
            var customFile = RequestFactory.GetDetailedCreateFileDefaultRequest();
            customFile.formType = FormType.CD;
            customFile.File.Properties = new Property[]
                    { 
                        new Property() 
                        {
                            Name = "J305",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",
                            ProperyTypeCdID = 15, //Single Family Residence
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA", 
                                    Zip= "92707"
                                } 
                            } 
                        } 
                    };
            try
            {
                int? FileID = FileService.CreateFile(customFile).FileID;
                return (int)FileID;
            }
            catch (Exception)
            {

                throw new Exception("Unable to retrieve FileID.");
            }
        }

        public void CreateFileUsingGUI()
        {
            #region Create a QFE CD file
            Reports.TestStep = "Create a QFE CD file";
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            //FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("HUDFLINSR1"); //Not found on FINT08, FINT16
            //FastDriver.QuickFileEntry.txtBusinessSourceGABID.FASetText("50811");
            FastDriver.QuickFileEntry.txtBusinessSourceGABID.FASetText("HUDFLINSR1");
            FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            //FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
            //FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("50812");
            FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("508");
            FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();

            if (!FastDriver.QuickFileEntry.Title.Selected)
            {
                FastDriver.QuickFileEntry.Title.FAClick();
            }

            if (!FastDriver.QuickFileEntry.Escrow.Selected)
            {
                FastDriver.QuickFileEntry.Escrow.FAClick();
            }
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");//On NCS Region this is selected by default
            FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
            //if (!FastDriver.QuickFileEntry.ProjectFile.Selected)
            //{
            //    FastDriver.QuickFileEntry.ProjectFile.FAClick();
            //}
            FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5.37");
            FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("9.03");
            //FastDriver.QuickFileEntry.FormType_HUD.FAClick();
            FastDriver.QuickFileEntry.FormType_CD.FAClick();
            FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
            //FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
            //Option not found on FINT08
            FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
            FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
            FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyBookAddrLin4.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");

            FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");

            FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
            FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
            FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
            FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
            FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");

            FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
            FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
            FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
            FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
            FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
            FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");

            //FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("2479674");
            FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
            FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
            FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            //FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("1256628");
            FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("BOA");
            FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
            FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
            FastDriver.QuickFileEntry.Notes.FASetText("Notes Data including - * # Specialcharacter :) !");
            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);
            #endregion
        }

        public void SetDefaultCheckPrinter()
        {
            Reports.TestStep = "Set default check printer";
            FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
            FastDriver.PrinterConfiguration.SetDefaultPrinter();
        }

        public static void RandomFeeSelect()
        {

            for (int i = 0; i < 4; i++)
            {
                FastDriver.WebDriver.FindElement(By.Id(FastDriver.FileFees.randomFeeCheckBoxSelector())).FAClick();

            }
            FastDriver.BottomFrame.Done();

        }

        public static string GetReleaseinDays()
        {
            string ReleaseinDays = "";
            if (DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(Convert.ToInt32("7")).DayOfWeek.ToString() == "Sunday")
                ReleaseinDays = "9";
            else
                ReleaseinDays = "7";

            return ReleaseinDays;
        }

        public string GetAttorneyName()
        {
            string attorneyNameLabel1 = string.Empty;
            string attorneyNameLabel2 = string.Empty;

            if (FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName.Displayed)
                attorneyNameLabel1 = FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName.FAGetText().ToString().Clean();

            if (FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName1.Displayed)
                attorneyNameLabel2 = FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName1.FAGetText().ToString().Clean();

            string fullAttorneyName = attorneyNameLabel1 + " " + attorneyNameLabel2;

            return fullAttorneyName;
        }
        #endregion
        #region     Private Methods

        private string BuyerCharge;
        private string BuyerCredit;
        private string Description;
        private string SellerCharge;
        private string SellerCredit;

        private void NewLoan(int section, int rowindex)
        {
            FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
            int buyercharge_index = 0;
            int buyercredit_index = 0;
            int Des_index = 0;
            int sellercharge_index = 0;
            int sellercredit_index = 0;

            FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
            IWebElement header_value = FastDriver.NCSViewSettlementStatement.NewNewLoanTable.FAFindElements(ByLocator.TagName, "tr").ToList()[1];

            string c1 = header_value.FAGetText();
            int columncount = header_value.FAFindElements(ByLocator.TagName, "td").Count();

            for (int i = 0; i <= columncount - 1; i++)
            {
                string cc = header_value.FAFindElements(ByLocator.TagName, "td").ToList()[i].FAGetText();
                if (header_value.FAFindElements(ByLocator.TagName, "td").ToList()[i].FAGetText() == "Buyer Charge")
                {
                    buyercharge_index = i;
                }
                if (header_value.FAFindElements(ByLocator.TagName, "td").ToList()[i].FAGetText() == "Buyer Credit")
                {
                    buyercredit_index = i;
                }
                if (header_value.FAFindElements(ByLocator.TagName, "td").ToList()[i].FAGetText() == "Description")
                {
                    Des_index = i;
                }
                if (header_value.FAFindElements(ByLocator.TagName, "td").ToList()[i].FAGetText() == "Seller Charge")
                {
                    sellercharge_index = i;
                }
                if (header_value.FAFindElements(ByLocator.TagName, "td").ToList()[i].FAGetText() == "Seller Credit")
                {
                    sellercredit_index = i;
                }
            }
            IWebElement section_table = FastDriver.NCSViewSettlementStatement.NewNewLoanTable.FAFindElements(ByLocator.TagName, "table").ToList()[section - 1].FAFindElements(ByLocator.TagName, "tr").ToList()[rowindex - 1];
            int actualtable = section_table.FAFindElements(ByLocator.TagName, "td").ToList().Count();
            BuyerCharge = section_table.FAFindElements(ByLocator.TagName, "td").ToList()[buyercharge_index].FAGetText();
            BuyerCredit = section_table.FAFindElements(ByLocator.TagName, "td").ToList()[buyercredit_index].FAGetText();
            Description = section_table.FAFindElements(ByLocator.TagName, "td").ToList()[Des_index].FAGetText();
            SellerCharge = section_table.FAFindElements(ByLocator.TagName, "td").ToList()[sellercharge_index].FAGetText();
            SellerCredit = section_table.FAFindElements(ByLocator.TagName, "td").ToList()[sellercredit_index].FAGetText();


        }

        private void VerifydatainSS(IWebElement TableID,int section, int rowindex)
        {
            FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
            int buyercharge_index = 0;
            int buyercredit_index = 0;
            int Des_index = 0;
            int sellercharge_index = 0;
            int sellercredit_index = 0;

            FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
            IWebElement header_value = TableID.FAFindElements(ByLocator.TagName, "tr").ToList()[1];

            string c1 = header_value.FAGetText();
            int columncount = header_value.FAFindElements(ByLocator.TagName, "td").Count();

            for (int i = 0; i <= columncount - 1; i++)
            {
                string cc = header_value.FAFindElements(ByLocator.TagName, "td").ToList()[i].FAGetText();
                if (header_value.FAFindElements(ByLocator.TagName, "td").ToList()[i].FAGetText() == "Buyer Charge")
                {
                    buyercharge_index = i;
                }
                if (header_value.FAFindElements(ByLocator.TagName, "td").ToList()[i].FAGetText() == "Buyer Credit")
                {
                    buyercredit_index = i;
                }
                if (header_value.FAFindElements(ByLocator.TagName, "td").ToList()[i].FAGetText() == "Description")
                {
                    Des_index = i;
                }
                if (header_value.FAFindElements(ByLocator.TagName, "td").ToList()[i].FAGetText() == "Seller Charge")
                {
                    sellercharge_index = i;
                }
                if (header_value.FAFindElements(ByLocator.TagName, "td").ToList()[i].FAGetText() == "Seller Credit")
                {
                    sellercredit_index = i;
                }
            }
            IWebElement section_table = TableID.FAFindElements(ByLocator.TagName, "table").ToList()[section - 1].FAFindElements(ByLocator.TagName, "tr").ToList()[rowindex - 1];
            int actualtable = section_table.FAFindElements(ByLocator.TagName, "td").ToList().Count();
            BuyerCharge = section_table.FAFindElements(ByLocator.TagName, "td").ToList()[buyercharge_index].FAGetText();
            BuyerCredit = section_table.FAFindElements(ByLocator.TagName, "td").ToList()[buyercredit_index].FAGetText();
            Description = section_table.FAFindElements(ByLocator.TagName, "td").ToList()[Des_index].FAGetText();
            SellerCharge = section_table.FAFindElements(ByLocator.TagName, "td").ToList()[sellercharge_index].FAGetText();
            SellerCredit = section_table.FAFindElements(ByLocator.TagName, "td").ToList()[sellercredit_index].FAGetText();


        }


        private void verifytheData(IWebElement tableName, string descContent, string BCharge, string SCharge, string BCredit, string SCredit)
        {

            try
            {

                bool result = false;
                int rowCount = tableName.GetRowCount();
                string cellContent;
                for (int counter = 2; counter <= rowCount; counter++)
                {
                    cellContent = tableName.PerformTableAction(counter, 4, TableAction.GetText).Message;
                   // IWebElement fromElement = tableName.FindElement(By.XPath("./tbody/tr[" + counter + "]"));

                    if (cellContent.Trim().Contains(descContent.Trim()))
                    {

                        Support.AreEqual("True", cellContent.Contains(descContent).ToString(), "ChargeDescription: " + descContent + " in section");;
                        if (!string.IsNullOrEmpty(BCharge))
                        {
                            result = (!result) && cellContent.Contains(BCharge);
                            Support.AreEqual("True", cellContent.Contains(BCharge).ToString(), "Buyer Charge Displayed " + BCharge + " in the Description column");

                        }
                        if (!string.IsNullOrEmpty(SCharge))
                        {
                            result = (!result) && cellContent.Contains(SCharge);
                            Support.AreEqual("True", cellContent.Contains(SCharge).ToString(), "Seller Charge Displayed " + SCharge + " in the Description column");
                        }
                        if (!string.IsNullOrEmpty(BCredit))
                        {
                            result = (!result) && cellContent.Contains(BCredit);
                            Support.AreEqual("True", cellContent.Contains(BCredit).ToString(), "Buyer Credit Displayed " + BCredit + " in the Description column");
                        }
                        if (!string.IsNullOrEmpty(SCredit))
                        {
                            result = (!result) && cellContent.Contains(SCredit);
                            Support.AreEqual("True", cellContent.Contains(SCredit).ToString(), "Seller Credit Displayed " + SCredit + " in the Description column");
                        }
                        result = true;
                        break;
                    }
                    
                }
                if (result == false)
                {
                    Support.AreEqual("False", "ChargeDescription: " + descContent + " not listed in the section");
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        private void verifytheData1(IWebElement tableName, string descContent, string BCharge, string SCharge, string BCredit, string SCredit)
        {

            try
            {

                bool result = false;
                int rowCount = tableName.GetRowCount();
                string cellContent;
                for (int counter = 1; counter <= rowCount; counter++)
                {
                    cellContent = tableName.PerformTableAction(counter, 4, TableAction.GetText).Message;
                    // IWebElement fromElement = tableName.FindElement(By.XPath("./tbody/tr[" + counter + "]"));

                    if (cellContent.Trim().Contains(descContent.Trim()))
                    {

                        Support.AreEqual("True", cellContent.Contains(descContent).ToString(), "ChargeDescription" + descContent + " in section"); ;
                        if (counter == 1)
                        {
                            if (!string.IsNullOrEmpty(BCharge))
                            {
                                result = (!result) && cellContent.Contains(BCharge);
                                Support.AreEqual("False", cellContent.Contains(BCharge).ToString(), "Buyer Charge Displayed " + BCharge + "  not in the Description column");

                            }
                            if (!string.IsNullOrEmpty(SCharge))
                            {
                                result = (!result) && cellContent.Contains(SCharge);
                                Support.AreEqual("False", cellContent.Contains(SCharge).ToString(), "Seller Charge Displayed " + SCharge + " not in the Description column");
                            }
                            if (!string.IsNullOrEmpty(BCredit))
                            {
                                result = (!result) && cellContent.Contains(BCredit);
                                Support.AreEqual("False", cellContent.Contains(BCredit).ToString(), "Buyer Credit Displayed " + BCredit + "not in the Description column");
                            }
                            if (!string.IsNullOrEmpty(SCredit))
                            {
                                result = (!result) && cellContent.Contains(SCredit);
                                Support.AreEqual("False", cellContent.Contains(SCredit).ToString(), "Seller Credit Displayed " + SCredit + "not in the Description column");
                            }
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(BCharge))
                            {
                                result = (!result) && cellContent.Contains(BCharge);
                                Support.AreEqual("True", cellContent.Contains(BCharge).ToString(), "Buyer Charge Displayed " + BCharge + " in the Description column");

                            }
                            if (!string.IsNullOrEmpty(SCharge))
                            {
                                result = (!result) && cellContent.Contains(SCharge);
                                Support.AreEqual("True", cellContent.Contains(SCharge).ToString(), "Seller Charge Displayed " + SCharge + " in the Description column");
                            }
                            if (!string.IsNullOrEmpty(BCredit))
                            {
                                result = (!result) && cellContent.Contains(BCredit);
                                Support.AreEqual("True", cellContent.Contains(BCredit).ToString(), "Buyer Credit Displayed " + BCredit + " in the Description column");
                            }
                            if (!string.IsNullOrEmpty(SCredit))
                            {
                                result = (!result) && cellContent.Contains(SCredit);
                                Support.AreEqual("True", cellContent.Contains(SCredit).ToString(), "Seller Credit Displayed " + SCredit + " in the Description column");
                            }
                        }
                        result = true;
                        break;
                    }

                }
                if (result == false)
                {
                    Support.AreEqual("False", "ChargeDescription" + descContent + " not listed in the section");
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        public static void CreateAttorney(string BuyerCharge, string SellerCharge, string GabCode)
        {
            #region Set Attorney's Data
            FastDriver.AttorneyDetail.GABcode.FASetText(GabCode);
            FastDriver.AttorneyDetail.Find.FAClick();
            FastDriver.AttorneyDetail.Type.FASelectItem("Attorney- Primary");

            SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", BuyerCharge);
            SetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", SellerCharge);

            #endregion
        }

        public static void SetBuyerCharge(IWebElement TableCharges, string DescriptionRow, string BuyerCreditValue, int startOffRow = 1)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 3, TableAction.SetText, BuyerCreditValue, startOffRow);
        }

        public static void  SetSellerCharge(IWebElement TableCharges, string DescriptionRow, string BuyerCreditValue, int startOffRow = 1)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 4, TableAction.SetText, BuyerCreditValue, startOffRow);
        }

        private string getRecieptNo
        {
            get
            {
                Random ran = new Random();
                int recieptNo = ran.Next(11111, 99999);
                return recieptNo.ToString();
            }
        }

        public static void FillMiscDisbursementDetail(string Description = "", string BuyerCharge = "", string SellerCharge = "", string CheckOnlyDescription = "", string CheckOnlyCharge = "")
        {

            if (!Description.Equals(""))
            {
                if (!Description.Equals("EMPTY"))
                {
                    FastDriver.MiscDisbursementDetail.Description.FASetText(Description);
                    FastDriver.MiscDisbursementDetail.Description.SendKeys(FAKeys.Tab);
                }
                else
                {
                    FastDriver.MiscDisbursementDetail.Description.FASetText("");
                    FastDriver.MiscDisbursementDetail.Description.SendKeys(FAKeys.Tab);
                }
            }

            if (!BuyerCharge.Equals(""))
            {
                if (!BuyerCharge.Equals("EMPTY"))
                {
                    FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText(BuyerCharge);
                    FastDriver.MiscDisbursementDetail.BuyerCharge.SendKeys(FAKeys.Tab);
                }
                else
                {
                    FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText("");
                    FastDriver.MiscDisbursementDetail.BuyerCharge.SendKeys(FAKeys.Tab);
                }
            }

            if (!SellerCharge.Equals(""))
            {
                if (!SellerCharge.Equals("EMPTY"))
                {
                    FastDriver.MiscDisbursementDetail.SellerCharge.FASetText(SellerCharge);
                    FastDriver.MiscDisbursementDetail.SellerCharge.SendKeys(FAKeys.Tab);
                }
                else
                {
                    FastDriver.MiscDisbursementDetail.SellerCharge.FASetText("");
                    FastDriver.MiscDisbursementDetail.SellerCharge.SendKeys(FAKeys.Tab);
                }
            }

            if (!CheckOnlyDescription.Equals(""))
            {
                if (!CheckOnlyDescription.Equals("EMPTY"))
                {
                    FastDriver.MiscDisbursementDetail.CheckOnlyDescription.FASetText(CheckOnlyDescription);
                    FastDriver.MiscDisbursementDetail.CheckOnlyDescription.SendKeys(FAKeys.Tab);
                }
                else
                {
                    FastDriver.MiscDisbursementDetail.CheckOnlyDescription.FASetText("");
                    FastDriver.MiscDisbursementDetail.CheckOnlyDescription.SendKeys(FAKeys.Tab);
                }
            }

            if (!CheckOnlyCharge.Equals(""))
            {
                if (!CheckOnlyCharge.Equals("EMPTY"))
                {
                    //FastDriver.MiscDisbursementDetail.CheckOnlyCharge.FASetText("");
                    FastDriver.MiscDisbursementDetail.CheckOnlyCharge.SendKeys(CheckOnlyCharge + FAKeys.Tab);
                    //FastDriver.MiscDisbursementDetail.CheckOnlyCharge.SendKeys(FAKeys.Tab);
                }
                else
                {
                    FastDriver.MiscDisbursementDetail.CheckOnlyCharge.FASetText("");
                    FastDriver.MiscDisbursementDetail.CheckOnlyCharge.SendKeys(FAKeys.Tab);
                }
            }



        }
        
        private void CreateFile_UI()
        {   
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

            if (!FastDriver.QuickFileEntry.Title.Selected)
            {
                FastDriver.QuickFileEntry.Title.FAClick();
            }

            if (!FastDriver.QuickFileEntry.Escrow.Selected)
            {
                FastDriver.QuickFileEntry.Escrow.FAClick();
            }

            Playback.Wait(100);
            FastDriver.QuickFileEntry.FormType_CD.FAClick();
            FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
            FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
            FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
            FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
            FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerNa1");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLa1");
            FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerNa1");
            FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLa1");
            FastDriver.BottomFrame.Done();

            FastDriver.QuickFileEntry.SwitchToTopFrame();
            string fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

           
        }
       
        private void CreateFile_WS()
       {
           var customizableFileRequest = new CreateFileRequest()
                {
                    EmployeeObjectCD = "1",
                    Source = "FAST",
                    Target = "FAST",
                    formType = FormType.CD,//NCS only works for CD
                    File = new File()
                    {
                        SalesPriceAmount = 3000000,
                        FirstNewLoanAmount = 1500000,                        
                        BusinessSegmentObjectCD = "Commercial",
                        TransactionTypeObjectCD = "SALE",//Sale w/Mortgage
                        ExternalFileNumber = "123456789",
                        AutoNumberIndicator = true,
                        BusinessParties = new FileBusinessParty[]
                                {
                                    new FileBusinessParty()
                                        {
                                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId(gabCode: "HUDFLINSR1", regionBUID: 1486),
                                        RoleTypeObjectCD = "BUSSOURCE",
                                        AdditionalRole = new AdditionalRoleList()
                                            {
                                            eAddtionalRole = AdditionalRoleType.NewLender
                                            },
                                        },
                                    },
                        Services = new Service[]
                                    {
                                    new Service()
                                        {
                                        OfficeInfo = new OfficeInfo()
                                            {
                                            RegionID = 1486,
                                            BUID = 1487,
                                            ProductionOffices = new ProductionOffice[]
                                                {
                                                new ProductionOffice()
                                                    {
                                                    BUID = 0,
                                                    OfficeCode = 0,
                                                    RegionID = 0,
                                                    SeqNum = 0
                                                    }
                                                }
                                            },
                                        ServiceTypeObjectCD = "TO"
                                        },
                                    new Service()
                                        {
                                        OfficeInfo = new OfficeInfo()
                                            {
                                            RegionID = 1486,
                                            BUID = 1487,
                                            ProductionOffices = new ProductionOffice[]
                                                {
                                                new ProductionOffice()
                                                    {
                                                    BUID = 0,
                                                    OfficeCode = 0,
                                                    RegionID = 0,
                                                    SeqNum = 0
                                                    }
                                                }
                                            },
                                        ServiceTypeObjectCD = "EO"
                                        }
                                },
                        Properties = new Property[]
                                    {
                                    new Property()
                                        {
                                        PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                                            {
                                            new FASTWCFHelpers.FastFileService.PhysicalAddress()
                                                {
                                                AddrLine1 = "BTM Mico Layout",
                                                AddrLine2 = "Near Saibaba Temple",
                                                AddrLine3 = "BTM 1st Stage",
                                                AddrLine4 = "KEB Layout",
                                                City = "Bangalore Mysore",
                                                Zip = "89003",
                                                State = "NV",
                                                County = "Nye",
                                                }
                                            }
                                        }
                                    },
                        FileNotes = new FileNote[]
                            {
                                new FileNote()
                                {
                                    Note = "Notes Data including - * # Specialcharacter :) !",
                                    TypeCdID = 695 //EPIC
                                }
                            },
                        Buyers = new BuyerSeller[] 
                        { 
                        new BuyerSeller() 
                        { 
                            Type = "Individual",                            
                            SSN = "123-45-6789",
                            FirstName = "Buyer1Firstname",
                            LastName = "Buyer1Lastname",
                        }
                        },
                        Sellers = new BuyerSeller[]
                        {
                        new BuyerSeller() 
                        {
                            Type = "Individual",
                            SSN = "987-65-4321",
                            FirstName = "Seller1FirstName",
                            LastName = "Seller1Lastname",
                        }
                    }


                }
       };
                var CreateFile = FileService.CreateFile(customizableFileRequest);
                Support.AreEqual("File Saved Successfully.", CreateFile.OperationResponse.StatusDescription);
                var File = FileService.GetOrderDetails((int)CreateFile.FileID);
                //FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                string FileNumber = File.FileNumber;
                FastDriver.LeftNavigation.SwitchToTopFrame();
                FastDriver.TopFrame.SetNumberAndPressEnter(File.FileNumber);
                Keyboard.SendKeys("{ENTER}");
       }

        public void RightclickonCharge(IWebElement table, List<string> documents)
        {


            List<IWebElement> docs = new List<IWebElement>();


            foreach (var doc in documents)
            {
                try
                {

                    docs.Add(table.FindElement(By.XPath(".//tr/td/div/span/*[text()='" + doc + "']")));

                }
                catch
                {
                    Reports.StatusUpdate("Unable to find document '" + doc + "' on the table", true);
                }
            }


            if (docs.Count == 0)    //  unable to find any doc on table


                Playback.Wait(500); // need this
            for (int i = 0; i < docs.Count; i++)
            {
                docs[i].FARightClick();                                 // click on row to select
            }

        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
    