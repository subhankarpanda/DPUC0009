﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using System.Runtime.Serialization;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using System.IO;
using System.Collections.Generic;

namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0057 : FASTHelpers
    {


        #region BAT

        [TestMethod]
        public void FMUC0057_BAT0001()
        {

            try
            {
                Reports.TestDescription = "MF_001: Process a One-Sided Adjustment on a Deposit";

                #region DataSetup
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Intreraction
                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");

                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("8000");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer700");

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);


                Reports.TestStep = "Save the deposited to account number.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Support.value = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                Support.DataSave("DepositedTo", "DepositedToAcctNo", Support.value);

                Reports.TestStep = "Save the issue date.";
                Support.value = FastDriver.DepositInEscrow.IssueDte.FAGetValue();
                Support.DataSave("IssueDate", "IssueDate", Support.value);
                Reports.TestStep = "To click on adjustment button in Deposit History.";

                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");

                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                Support.DataLoad("IssueDate", "IssueDate");
                Support.value = FastDriver.DepositAdjustment.Description.FAGetValue();
                string sDescription = "Cancel " + Support.data;
                Support.AreEqual("True", Support.value.Contains(sDescription).ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                Support.value = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual(@"true", Support.value);
                FastDriver.DepositAdjustment.Loggedonuser.Exists();
                Support.value = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual(@"True", Support.value);
                Support.value = FastDriver.DepositAdjustment.Comment.Enabled.ToString();
                Support.AreEqual(@"True", Support.value);


                Support.value = FastDriver.DepositAdjustment.AdjustmentDate.FAGetValue();
                Support.DataSave("AdjDate", "AdjDate", Support.value);
                Support.DataLoad("AdjDate", "AdjDate");
                DateTime PostedOnServerDate = Convert.ToDateTime(Support.data);
                TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Pacific SA Standard Time");
                DateTime newDateTime = TimeZoneInfo.ConvertTime(PostedOnServerDate, timeZoneInfo);
                Support.value = newDateTime.ToDateString();
                Support.DataSave("Date", "Date", Support.value);
                Support.DataLoad("Date", "Date");
                Support.value = FastDriver.DepositAdjustment.PostedOn.FAGetText().ToString();
                if (Support.value == Support.data)
                {
                    Reports.StatusUpdate("Verify for PostedOn date: " + Support.data, Support.value.Contains(Support.data));
                }
                else
                {
                    Support.DataLoad("AdjDate", "AdjDate");
                    Reports.StatusUpdate("Verify for PostedOn date: " + Support.data, Support.value.Contains(Support.data));
                }

                Support.value = FastDriver.DepositAdjustment.PostedBy.FAGetText().ToString();
                Support.value = Support.value.Replace(" ", "");
                Support.AreEqual(@"True", AutoConfig.UserName.ToUpper().Trim().Contains(Support.value.Trim()).ToString());

                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Verifying for deposit adjustment";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");

                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                Playback.Wait(10000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Reports.TestStep = "Verifying for deposit adjustment";
                string deposit = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Deposit Adjustment]", "Comments", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", deposit.Contains("Adjustment Reason: Cancel").ToString());

                Reports.TestStep = "Validate after the deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", amount.Contains("8,000.00-").ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_BAT0002()
        {

            try
            {
                Reports.TestDescription = "AF_003: Reverse a One-Sided Adjustment on a Deposit";

                #region DataSetup
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region precondition
                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");

                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("8000");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer700");

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);


                Reports.TestStep = "Save the deposited to account number.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Support.value = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                Support.DataSave("DepositedTo", "DepositedToAcctNo", Support.value);

                Reports.TestStep = "Save the issue date.";
                Support.value = FastDriver.DepositInEscrow.IssueDte.FAGetValue();
                Support.DataSave("IssueDate", "IssueDate", Support.value);
                Reports.TestStep = "To click on adjustment button in Deposit History.";

                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");

                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region GUI Intreraction

                Reports.TestStep = "To select the adjusted deposit and repost.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");

                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(10000);

                Reports.TestStep = "Reverse a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.Highlight();
                string AdjustmentReason = FastDriver.DepositAdjustment.AdjustmentReason.FAGetSelectedItem();
                Support.AreEqual("REPOST", AdjustmentReason);
                Support.DataLoad("IssueDate", "IssueDate");
                String Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                string sDescription = "REPOST " + Support.data;
                Support.AreEqual("True", Description.Contains(sDescription).ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Repost deposit");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);

                String Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                string Comment = FastDriver.DepositAdjustment.Comment.Enabled.ToString();
                Support.AreEqual("True", Comment);

                string AdjustmentDate = FastDriver.DepositAdjustment.AdjustmentDate.FAGetValue();

                DateTime PostedOnServerDate = Convert.ToDateTime(AdjustmentDate);
                TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Pacific SA Standard Time");
                DateTime newDateTime = TimeZoneInfo.ConvertTime(PostedOnServerDate, timeZoneInfo);
                string newdatestring = newDateTime.ToDateString();

                string PostedOn = FastDriver.DepositAdjustment.PostedOn.FAGetText().ToString();
                if (PostedOn == newdatestring)
                {
                    Reports.StatusUpdate("Verify for PostedOn date: " + PostedOn, PostedOn.Contains(newdatestring));
                }
                else
                {

                    Reports.StatusUpdate("Verify for PostedOn date: " + PostedOn, AdjustmentDate.Contains(newdatestring));
                }

                string PostedBy = FastDriver.DepositAdjustment.PostedBy.FAGetText().ToString();
                PostedBy = PostedBy.Replace(" ", "");
                Support.AreEqual("True", AutoConfig.UserName.ToUpper().Trim().Contains(PostedBy.Trim()).ToString());
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after repost deposit.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string RepostDescription = FastDriver.DepositSummary.RepostDescription.FAGetText();
                Support.AreEqual("True", RepostDescription.Contains("REPOST ").ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_BAT0003()
        {

            try
            {
                Reports.TestDescription = "AF_001: Process a Correcting Adjustment on a Deposit";

                #region DataSetup
                IISLOGIN();
                CreateBasicFile();

                #endregion

                #region GUI Interaction

                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("8000");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer200");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Save the document number.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();

                string ReceiptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();

                Reports.TestStep = "Save the Issue Date";
                string IssueDte = FastDriver.DepositInEscrow.IssueDte.FAGetValue();

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                Playback.Wait(10000);
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(10000);

                Reports.TestStep = "Process a Correcting Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                Playback.Wait(10000);
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                string sDescription = "Correct Amount " + IssueDte;
                Support.AreEqual("True", Description.Contains(sDescription).ToString());

                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);

                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);

                string Comment = FastDriver.DepositAdjustment.Comment.Enabled.ToString();
                Support.AreEqual("True", Comment);

                string AdjustmentDate = FastDriver.DepositAdjustment.AdjustmentDate.FAGetValue();

                DateTime PostedOnServerDate = Convert.ToDateTime(AdjustmentDate);
                TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Pacific SA Standard Time");
                // DateTime newDateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
                DateTime newDateTime = TimeZoneInfo.ConvertTime(PostedOnServerDate, timeZoneInfo);
                string newdatetime = newDateTime.ToDateString();
                string PostedOn = FastDriver.DepositAdjustment.PostedOn.FAGetText();
                if (PostedOn == newdatetime)
                {

                    Reports.StatusUpdate("Verify for PostedOn date: " + PostedOn, newdatetime.Contains(PostedOn));
                }
                else
                {
                    Reports.StatusUpdate("Verify for PostedOn date: " + PostedOn, AdjustmentDate.Contains(PostedOn));
                }

                string PostedBy = FastDriver.DepositAdjustment.PostedBy.FAGetText().ToString();
                PostedBy = PostedBy.Replace(" ", "");
                Support.AreEqual(@"True", AutoConfig.UserName.ToUpper().Trim().Contains(PostedBy.Trim()).ToString());

                FastDriver.DepositAdjustment.CorrectAmount.FASetText("7,000.00");
                string CorrectDescription = FastDriver.DepositAdjustment.CorrectDescription.FAGetValue();
                string sDescription1 = "Correct Amount " + IssueDte;
                Support.AreEqual("True", CorrectDescription.Contains(sDescription1).ToString());
                FastDriver.DepositAdjustment.CorrectComment.FASetText("Amount corrected");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);

                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after correct amt deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();

                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("8,000.00-", "8,000.00-");
                // 
                Reports.TestStep = "Validate after correct amt deposit adjustment.";
                FastDriver.DepositSummary.WaitForScreenToLoad();

                amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "7,000.00", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("7,000.00", "7,000.00");

                Reports.TestStep = "Verifying for deposit adjustment in Event Log";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                Playback.Wait(10000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Reports.TestStep = "Verifying for deposit adjustment";
                string deposit = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Deposit Adjustment]", "Comments", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", deposit.Contains("Adjustment Reason: Correct Amount").ToString());
                Support.AreEqual("True", deposit.Contains("Amount: 8000.00").ToString());
                Support.AreEqual("True", deposit.Contains("Corrected To:7000").ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_BAT0004()
        {

            try
            {
                Reports.TestDescription = "AF_004: Process an Ad-Hoc Deposit Adjustment";

                #region Login
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(2000);
                Playback.Wait(1000);
                #endregion

                #region GUI Interaction
                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("12000");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer302");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Save the issued date.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                String IssueDte = FastDriver.DepositInEscrow.IssueDte.FAGetValue();

                Reports.TestStep = "To click on adhoc adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.AdHocAdjustment.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Process an Ad-Hoc Deposit Adjustment.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string randomstring = "#" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositAdjustment.DocumentNo.FASetText(randomstring);
                string DocumentNo = FastDriver.DepositAdjustment.DocumentNo.FAGetValue();
                FastDriver.DepositAdjustment.Amount.FASetText("11,000.00");
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                string sDescription = "Cancel " + IssueDte;
                Support.AreEqual("True", Description.Contains(sDescription).ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                String UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();

                Support.AreEqual(@"true", UpdateTrustAccounting);
                String Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual(@"True", Loggedonuser);
                String Comment = FastDriver.DepositAdjustment.Comment.Enabled.ToString();
                Support.AreEqual(@"True", Comment);

                string AdjustmentDate = FastDriver.DepositAdjustment.AdjustmentDate.FAGetValue();
                DateTime PostedOnServerDate = Convert.ToDateTime(AdjustmentDate);
                TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Pacific SA Standard Time");
                DateTime newDateTime = TimeZoneInfo.ConvertTime(PostedOnServerDate, timeZoneInfo);
                string newdate = newDateTime.ToDateString();
                string PostedOn = FastDriver.DepositAdjustment.PostedOn.FAGetText().ToString();
                if (PostedOn == newdate)
                {
                    Reports.StatusUpdate("Verify for PostedOn date: " + PostedOn, PostedOn.Contains(newdate));
                }
                else
                {

                    Reports.StatusUpdate("Verify for PostedOn date: " + PostedOn, PostedOn.Contains(AdjustmentDate));
                }
                string PostedBy = FastDriver.DepositAdjustment.PostedBy.FAGetText().ToString();
                PostedBy = PostedBy.Replace(" ", "");
                Support.AreEqual(@"True", AutoConfig.UserName.ToUpper().Trim().Contains(PostedBy.Trim()).ToString());
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after the deposit adhoc adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "11,000.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("11,000.00-", amount);
                string nettotal = FastDriver.DepositSummary.NetTotal.FAGetText().ToString();

                Reports.TestStep = "Validate the Current Available Funds of deposits summary with Escrow File Balance Summary";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad();
                string CurrentAvailableFunds = FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText();
                Support.AreEqual("True", CurrentAvailableFunds.Contains(nettotal.Trim()).ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            //Assert.AreEqual(true, Reports.TestResult, "TestSuccess:Refer Test Reports for Details");

        }

        [TestMethod]
        public void FMUC0057_BAT0005()
        {

            try
            {
                Reports.TestDescription = "AF_002: Process a Change of Bank Account Number on a Deposit";

                #region Login & Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(2000);

                #endregion

                #region GUI Interaction
                Playback.Wait(10000);
                Reports.TestStep = "Create manual deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("11000");

                FastDriver.DepositInEscrow.Manual.FAClick();
                Playback.Wait(2000);
                string randomstr = "" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(" ");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(randomstr);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer310");

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                Playback.Wait(10000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(10000);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);


                Reports.TestStep = "Save the receipt number.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                Reports.TestStep = "Save the issued date.";
                string IssueDate = FastDriver.DepositInEscrow.IssueDte.FAGetValue();

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a Change of Bank Account Number on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Bank Acct");
                string Description = FastDriver.DepositAdjustment.Description.Enabled.ToString();
                Support.AreEqual("False", Description);
                string Comment = FastDriver.DepositAdjustment.Comment.Enabled.ToString();
                Support.AreEqual("False", Comment);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.DepositAdjustment.CorrectBankAccountEnabled.FASelectItemByIndex(2);
                string CorrectDescription = FastDriver.DepositAdjustment.CorrectDescription.FAGetValue();
                string sDescription = "Correct Bank Acct " + IssueDate;
                Support.AreEqual("True", CorrectDescription.Contains(sDescription).ToString());

                string AdjustmentDate = FastDriver.DepositAdjustment.AdjustmentDate.FAGetValue();
                DateTime PostedOnServerDate = Convert.ToDateTime(AdjustmentDate);
                TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Pacific SA Standard Time");
                // DateTime newDateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
                DateTime newDateTime = TimeZoneInfo.ConvertTime(PostedOnServerDate, timeZoneInfo);
                string Date = newDateTime.ToDateString();
                string PostedOn = FastDriver.DepositAdjustment.PostedOn.FAGetText();
                // Support.AreEqual(@"True", Support.value.Contains(General.data).ToString());
                if (PostedOn == Date)
                {
                    Reports.StatusUpdate("Verify for PostedOn date: " + Date, PostedOn.Contains(Date));
                }
                else
                {

                    Reports.StatusUpdate("Verify for PostedOn date: " + Date, AdjustmentDate.Contains(PostedOn));
                }

                string PostedBy = FastDriver.DepositAdjustment.PostedBy.FAGetText().ToString();
                PostedBy = PostedBy.Replace(" ", "");
                Support.AreEqual(@"True", AutoConfig.UserName.ToUpper().Trim().Contains(PostedBy.Trim()).ToString());
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after the deposit adjusted by correct bank acct no.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");

                FastDriver.DepositSummary.WaitForScreenToLoad();
                string Receipts_DepositActivitytable = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "0.00", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("0.00 ", Receipts_DepositActivitytable);

                Reports.TestStep = "Verifying for deposit adjustment in Event Log";
                Playback.Wait(7000);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                Playback.Wait(5000);
                string EventTableoperation = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Deposit Adjustment]", "Comments", TableAction.GetText).Message.ToString();
                Reports.TestStep = "Verifying for deposit adjustment";
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Support.AreEqual("True", EventTableoperation.Contains("Adjustment Reason: Correct Bank Acct").ToString());
                Support.AreEqual("True", EventTableoperation.Contains(ReceiptNo).ToString());
                Support.AreEqual("True", EventTableoperation.Contains("Amount: 11000.00").ToString());


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_BAT0006()
        {

            try
            {
                ProjectFileChk(true);
                Reports.TestDescription = "AF_007: Adjust Deposit Receipt Issued in Another Owning Office";
                #region Login and Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(2000);
                #endregion

                #region GUI Interaction
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer");

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Save the deposited to account and receipt number.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                string ReceiptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                string IssueDte = FastDriver.DepositInEscrow.IssueDte.FAGetValue();
                string DepositBankName = FastDriver.DepositInEscrow.DepositBankName.FAGetText();

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                Playback.Wait(10000);
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(10000);
                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Cancel").ToString());

                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();

                Support.AreEqual(@"true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual(@"True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after the deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string tableamount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("8,000.00-", tableamount);
                // 
                // 
                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Playback.Wait(1000);
                FastDriver.FileHomepage.ChangeOO.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "To change the own office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");

                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(10000);

                Reports.TestStep = "Changing owning office";
               FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
              string popup =ChangeOwningOfficeRemoveServiceType.ChangeOwningOfficeRemovemessage;
                Support.AreEqual("Workflow Tasks are currently assigned to the removed Escrow owning office. Do you want to assign those same Workflow Tasks to the new Escrow owning office?", popup);


                Reports.TestStep = "To select the adjusted deposit and repost.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                tableamount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.Click).Element.Text.ToString();
                Support.AreEqual("8,000.00-", tableamount);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Validate IE message for Adjust Deposit Receipt Issued in Another Owning Office";
                popup = FastDriver.WebDriver.HandleDialogMessage(true, true);
                Support.AreEqual("Deposit cannot be adjusted. If it was made to the file's Title Owning Office account, please add Sub Escrow service in order to adjust the deposit. If it was made to the file's Escrow Owning Office account, please add Escrow service in order to adjust the deposit. If it was made in another owning office, please change the owning office back to the original office in which deposit was issued in order to adjust the deposit.", popup);
                Playback.Wait(10000);


                Reports.TestStep = "Click on View Details.";
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.ViewDetails.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Validate the details in View details after changing the owning office.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string BankAcount = FastDriver.DepositAdjustment.BankAcount.FAGetSelectedItem();
                Support.AreEqual(DepositedTo, BankAcount);
                string DocumentNo = FastDriver.DepositAdjustment.DocumentNo.FAGetValue();
                Support.AreEqual(ReceiptNo, DocumentNo);
                string IssueDate = FastDriver.DepositAdjustment.IssueDate.FAGetValue();
                Support.AreEqual(IssueDate, IssueDte);
                string BankName = FastDriver.DepositAdjustment.BankName.FAGetText();
                Support.AreEqual("True", BankName.Contains(DepositBankName).ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion BAT

        #region REG

        [TestMethod]
        public void FMUC0057_REG0001()
        {


            Reports.TestDescription = "MF1: Create Outside Escrow Company Process.";
            try
            {

                #region Login and Baseic file creation
                IISLOGIN();
                CreateBasicFile();
                #endregion


                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");

                DepositCash("10501.00", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "PayorEscro");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Cancel ").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual(@"True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Deposit adjustment.";
                string popupmsg = FastDriver.WebDriver.HandleDialogMessage(false, true);
                Support.AreEqual(@"Accounting Adjustment Form is ready for printing. Continue?", popupmsg);
                Playback.Wait(5000);

                Reports.TestStep = "Perform Print";
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print");
                Playback.Wait(5000);
                Reports.TestStep = "Verifying for deposit adjustment";
                Playback.Wait(7000);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                Playback.Wait(5000);
                string deposit = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Deposit Adjustment]", "Comments", TableAction.GetText).Message.ToString();

                Reports.TestStep = "Verifying for deposit adjustment";
                Support.AreEqual("True", deposit.Contains("Adjustment Reason: Cancel").ToString());


                Reports.TestStep = "Validate after the deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "10,501.00", "Amount", TableAction.Click);
                string adjustenable = FastDriver.DepositSummary.Adjust.Enabled.ToString();
                Support.AreEqual(@"False", adjustenable);

                Reports.TestStep = "Validate File balance summary for one-sided deposit adj.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad();
                string TotalIssuedDeposit = FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText();
                Support.AreEqual("10,501.00", TotalIssuedDeposit);
                string NetDepositAdjustment = FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText();
                Support.AreEqual("10,501.00-", NetDepositAdjustment);
                string NetDepositTotal = FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText().ToString();
                Support.AreEqual("0.00", NetDepositTotal);


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0002_PH()
        {

            try
            {
                Reports.TestDescription = "BR_FM1759_ER02_FM3145A_PlaceHolder: Validate manually in the PDF";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }


        }

        [TestMethod,Obsolete]
        public void FMUC0057_REG0003()
        {

            try
            {
                Reports.TestDescription = "BR_FM3145B: Select deposit to adjust  and also verify in SettlementStatement";
                Reports.TestStep = "Navigate to Print Escrow Settlement Statement screen.";
                Reports.StatusUpdate("BR_FM3145B:Functionality has covered in FMUC0057_REG0002_PH", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0004_PH()
        {

            try
            {
                Reports.TestDescription = "BR_FM3145B_Placeholder: Validate manually in the PDF";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY",false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0005()
        {

            try
            {
                Reports.TestDescription = "BR_FM2803_FM2897_ER-13: Valid reasons for dep adj";

                #region Login and Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Interaction
                Reports.TestStep = "Create manual deposit.";
                FastDriver.LeftNavigation.Navigate<DepositAdjustment>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string Random = "" + Support.RandomString("NNNNNNNN");
                DepositCash("10501", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "payor501");

                FastDriver.DepositInEscrow.Manual.FAClick();
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(" ");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(Random);
                Playback.Wait(2000);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                Playback.Wait(2000);
                Playback.Wait(10000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                // 
                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "To validate Valid reasons for deposit adj.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string AdjustmentReason = FastDriver.DepositAdjustment.AdjustmentReason.FAGetText().ToString();
                Support.AreEqual("Cancel Change Payor Name Correct Amount Correct Bank Acct Correct Document No Input Error NSF", AdjustmentReason);
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "To click on adhoc adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.AdHocAdjustment.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "To validate reasons for adhoc deposit adj.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                AdjustmentReason = FastDriver.DepositAdjustment.AdjustmentReason.FAGetText();
                Support.AreEqual("Cancel Input Error NSF", AdjustmentReason);

                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                Playback.Wait(5000);

                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Payor", "payor501", "Payor", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Chose adjustment reason as change payor name, try to save the adjust without changing payor name.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Change Payor Name");
                string Amount = FastDriver.DepositAdjustment.Amount.Enabled.ToString();
                Support.AreEqual(@"False", Amount);
                Playback.Wait(3000);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                // 
                Reports.TestStep = "To verify the error message for same payor name.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string ErrorMessage = FastDriver.DepositAdjustment.ErrorMessage.FAGetText();
                Support.AreEqual("True", ErrorMessage.Contains("Payor Name: You must enter different Payor name to create an adjustment").ToString());
                FastDriver.DepositAdjustment.Payorname.FASetText("payor501 changed");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Save();
                Playback.Wait(10000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0006()
        {

            try
            {
                Reports.TestDescription = "BR_ES7601_ER04: Adjust Deposit Receipt Issued in Another Owning Office";
                ProjectFileChk(true);
                #region Login and Basic File creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Interaction
                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");

                FastDriver.DepositInEscrow.WaitForScreenToLoad();

                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Pay103");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                string Descriptione = FastDriver.DepositAdjustment.Description.FAGetValue();
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                // 
                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after the deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("8,000.00-", amount);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Playback.Wait(1000);
                FastDriver.FileHomepage.ChangeOO.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "To change the own office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(10000);

                Reports.TestStep = "Changing owning office";
                FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                string popup = ChangeOwningOfficeRemoveServiceType.ChangeOwningOfficeRemovemessage;
                Support.AreEqual("Workflow Tasks are currently assigned to the removed Escrow owning office. Do you want to assign those same Workflow Tasks to the new Escrow owning office?", popup);

                Reports.TestStep = "To select the adjusted deposit and repost.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string tableamount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.Click).Element.Text.ToString();
                Support.AreEqual("8,000.00-", tableamount);

                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(2000);

                // 
                // 

                Reports.TestStep = "Validate IE message for Adjust Deposit Receipt Issued in Another Owning Office";
                popup = FastDriver.WebDriver.HandleDialogMessage(true, true);
                Support.AreEqual("Deposit cannot be adjusted. If it was made to the file's Title Owning Office account, please add Sub Escrow service in order to adjust the deposit. If it was made to the file's Escrow Owning Office account, please add Escrow service in order to adjust the deposit. If it was made in another owning office, please change the owning office back to the original office in which deposit was issued in order to adjust the deposit.", popup);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0007()
        {

            try
            {
                Reports.TestDescription = "BR_ES7604: Disable Adj of Title Owning Office's Dep for Title + Escrow File";

                #region Login and Basic File creation
                IISLOGIN();
                _CreateFile();
                #endregion

                #region GUI Interaction
                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");

                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Payor198");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                // 
                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                string Description = FastDriver.DepositAdjustment.Description.FAGetText();
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(2000);

                Reports.TestStep = "Validate after the deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");


                FastDriver.DepositSummary.WaitForScreenToLoad();
                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("8,000.00-", amount);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Playback.Wait(1000);
                FastDriver.FileHomepage.ChangeOO.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Escrow and select different EOO.";
                Playback.Wait(3000);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.Escrow.FASetCheckbox(true);
                FastDriver.FileHomepage.EscrowOwningOfficeOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");
                Playback.Wait(2000);
                FastDriver.BottomFrame.Save();
                Playback.Wait(12000);

                Reports.TestStep = "To select the adjusted deposit and repost.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string tableamount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.Click).Element.Text.ToString();
                Support.AreEqual("8,000.00-", tableamount);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Validate IE message for Adjust Deposit Receipt Issued in Another Owning Office";
                string popup = FastDriver.WebDriver.HandleDialogMessage(true, true);
                Support.AreEqual("Deposit cannot be adjusted. If it was made to the file's Title Owning Office account, please add Sub Escrow service in order to adjust the deposit. If it was made to the file's Escrow Owning Office account, please add Escrow service in order to adjust the deposit. If it was made in another owning office, please change the owning office back to the original office in which deposit was issued in order to adjust the deposit.", popup);
                Playback.Wait(5000);

                Reports.TestStep = "Deposit a cash more than sales price.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "firstname");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(10000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Cancel ").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after the deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                tableamount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.Click).Element.Text.ToString();
                Support.AreEqual("8,000.00-", tableamount);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0008()
        {

            try
            {
                Reports.TestDescription = "BR_ES7603: Disable Deposit Adjustments for Title Only File";
                #region Login and Basic File creation
                IISLOGIN();
                _CreateFile();
                #endregion

                #region GUI Interaction

                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer61");

                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();

                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");

                Support.value = FastDriver.DepositAdjustment.Description.FAGetValue();

                Support.AreEqual("True", Support.value.Contains("Cancel").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");

                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual(@"true", UpdateTrustAccounting);
                Support.value = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual(@"True", Support.value);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after the deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("8,000.00-", amount);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Playback.Wait(1000);
                FastDriver.FileHomepage.ChangeOO.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "To select the adjusted deposit and repost.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "validate error message on try to make changes to the  exist deposit which was issued earlier.";
                string popup = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Deposit cannot be adjusted. If it was made to the file's Title Owning Office account, please add Sub Escrow service in order to adjust the deposit. If it was made to the file's Escrow Owning Office account, please add Escrow service in order to adjust the deposit. If it was made in another owning office, please change the owning office back to the original office in which deposit was issued in order to adjust the deposit.", popup);

                Playback.Wait(5000);

                Reports.TestStep = "Click on Sub Escrow.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");

                Playback.Wait(3000);

                FastDriver.FileHomepage.WaitForScreenToLoad();

                Playback.Wait(1000);
                FastDriver.FileHomepage.SubEscrow.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(12000);

                Reports.TestStep = "To select the adjusted deposit and repost.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");


                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Reverse a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();

                string AdjustmentReason = FastDriver.DepositAdjustment.AdjustmentReason.FAGetSelectedItem();
                Support.AreEqual(@"REPOST", AdjustmentReason);
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("REPOST ").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Repost deposit");
                UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual(@"true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual(@"True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after repost deposit.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string RepostDescription = FastDriver.DepositSummary.RepostDescription.FAGetText();
                Support.AreEqual("True", RepostDescription.Contains("REPOST ").ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0009()
        {

            try
            {
                Reports.TestDescription = "BR_FM2034: Adjust correcting entry";
                #region Login and Basic File creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Interaction
                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer46");
                String DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a Correcting Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                Playback.Wait(1000);
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("7,000.00");
                string CorrectDescription = FastDriver.DepositAdjustment.CorrectDescription.FAGetValue();
                Support.AreEqual("True", CorrectDescription.Contains("Correct Amount ").ToString());
                FastDriver.DepositAdjustment.CorrectComment.FASetText("Amount corrected");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);

                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after correct amt deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("8,000.00-", amount);

                Reports.TestStep = "Validate after correct amt deposit adjustment.";
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "7,000.00", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                Description = FastDriver.DepositAdjustment.Description.FAGetText();
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");

                UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after the deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "7,000.00", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("7,000.00 ", amount);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0057_REG0010()
        {

            try
            {
                Reports.TestDescription = "BR_FM3146_FM3144_FM3147A: One-sided adj on Balance Sheet and also verify in HUD";
                #region Login and Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion

                #region GUI Interaction
                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer47");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual(@"True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate File balance summary for one-sided deposit adj.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad();
                string TotalIssuedDeposit = FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText();
                Support.AreEqual(@"8,000.00", TotalIssuedDeposit);
                string NetDepositAdjustment = FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText();
                Support.AreEqual(@"8,000.00-", NetDepositAdjustment);
                string NetDepositTotal = FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText().ToString();
                Support.AreEqual(@"0.00", NetDepositTotal);
                FastDriver.BottomFrame.Done();

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0011_PH()
        {

            try
            {
                Reports.TestDescription = "BR_FM3146_FM3144_FM3147A_Placeholder: Validate manually in the PDF";


                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY",false);



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0012_PH()
        {

            try
            {
                Reports.TestDescription = "BR_FM3147B: One-sided adj on Balance Sheet and also verify in SettlementStatement";
                Reports.TestStep = "This Flow has NOT been Automated Please perform this MANUALLY";
                Reports.StatusUpdate("BR_FM3147B: One-sided adj on Balance Sheet and also verify in SettlementStatement : Functionality has covered in FMUC0057_REG0013PH", true);


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0013_PH()
        {

            try
            {
                Reports.TestDescription = "BR_FM3147B_Placeholder: Validate manually in the PDF";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0014()
        {

            try
            {
                Reports.TestDescription = "BR_FM3150_FM3144_FM3151A: Re-post on Balance Sheet  and also verify in HUD "+
                    "User Story 716431:Direct - Show who Reposted a Deposit/Disbursement";

                #region prerequisite
                #region Login and Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                #endregion


                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer47");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual(@"True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate File balance summary for one-sided deposit adj.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad();
                string TotalIssuedDeposit = FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText();
                Support.AreEqual(@"8,000.00", TotalIssuedDeposit);
                string NetDepositAdjustment = FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText();
                Support.AreEqual(@"8,000.00-", NetDepositAdjustment);
                string NetDepositTotal = FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText().ToString();

                Support.AreEqual(@"0.00", NetDepositTotal);
                FastDriver.BottomFrame.Done();

               

                #endregion

                #region GUI Interaction
                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.Click);

                FastDriver.DepositSummary.Adjust.FAClick();
                Reports.TestStep = "Reverse a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();

                string AdjustmentReason = FastDriver.DepositAdjustment.AdjustmentReason.FAGetSelectedItem();
                Support.AreEqual(@"REPOST", AdjustmentReason);
                Description = FastDriver.DepositAdjustment.Description.FAGetValue();

                Support.AreEqual("True", Description.Contains("REPOST").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Repost deposit");

                UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();

                Support.AreEqual(@"true", UpdateTrustAccounting);
                Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();

                Support.AreEqual(@"True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                Support.MessageHandler(true);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after repost deposit.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string RepostDescription = FastDriver.DepositSummary.RepostDescription.FAGetText();
                Support.AreEqual("True", RepostDescription.Contains("REPOST ").ToString());
                // 
                // 
                Reports.TestStep = "Validate File balance summary for deposit Repost.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad();
                TotalIssuedDeposit = FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText();
                Support.AreEqual(@"8,000.00", TotalIssuedDeposit);
                NetDepositAdjustment = FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText();
                Support.AreEqual(@"0.00", NetDepositAdjustment);
                NetDepositTotal = FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText();
                Support.AreEqual(@"8,000.00", NetDepositTotal);
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                Reports.TestStep = "Validate Repost for deposit Repost. in Event Logs";
                FastDriver.EventTrackingLog.Open();
                Reports.TestStep = "Verify Event Screen";
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Support.AreEqual("[Deposit Repost]".ToLower(), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.ToLower());

                Reports.TestStep = "Verify for Adjustment Reason in comments of Deposit adjustment event for Repost";
                Reports.StatusUpdate("Adjustment Reason present in comments (i.e. Adjustment Reason: Re-post )", FastDriver.EventTrackingLog.Comments.FAGetText().Contains(@"Adjustment Reason: Re-post"));
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            //Assert.AreEqual(true, Reports.TestResult, "TestSuccess:Refer Test Reports for Details");

        }

        [TestMethod]
        public void FMUC0057_REG0015_PH()
        {

            try
            {
                Reports.TestDescription = "BR_FM3150_FM3144_FM3151A_Placeholder: Validate manually in the PDF";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0017_PH()
        {

            try
            {
                Reports.TestDescription = "BR_FM3151B_Placeholder: Validate manually in the PDF";
                // 
                // 
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY",false);

                // 
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0018()
        {

            try
            {
                Reports.TestDescription = "BR_FM3148_FM3144_FM3149A: Two-sided adj on Balance Sheet and also verify in HUD";
                #region Basic File creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer121");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a Correcting Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                Playback.Wait(1000);
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Correct Amount").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual(@"true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual(@"True", Loggedonuser);
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("7,000.00");
                string CorrectDescription = FastDriver.DepositAdjustment.CorrectDescription.FAGetValue();
                Support.AreEqual("True", CorrectDescription.Contains("Correct Amount").ToString());
                FastDriver.DepositAdjustment.CorrectComment.FASetText("Amount corrected");
                FastDriver.BottomFrame.Save();
                Playback.Wait(10000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(5000);

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after correct amt deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("8,000.00-", amount);

                Reports.TestStep = "Validate after correct amt deposit adjustment.";
                FastDriver.DepositSummary.WaitForScreenToLoad();
                amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "7,000.00", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("7,000.00 ", amount);

                Reports.TestStep = "Validate File balance summary for Two-sided deposit adj.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad();
                string TotalIssuedDeposit = FastDriver.EscrowFileBalanceSummary.TotalIssuedDeposit.FAGetText();
                Support.AreEqual(@"8,000.00", TotalIssuedDeposit);
                string NetDepositAdjustment = FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText();
                Support.AreEqual(@"1,000.00-", NetDepositAdjustment);
                string NetDepositTotal = FastDriver.EscrowFileBalanceSummary.NetDepositTotal.FAGetText();
                Support.AreEqual(@"7,000.00", NetDepositTotal);
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0019_PH()
        {

            try
            {
                Reports.TestDescription = "BR_FM3148_FM3144_FM3149A_PlaceHolder: Validate manually in the PDF";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

                // 
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0021_PH()
        {

            try
            {
                Reports.TestDescription = "BR_FM3149B_Placeholder: Validate manually in the PDF";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);

                // 
                // 
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0022()
        {

            try
            {
                Reports.TestDescription = "BR_FM3011A  : Event for adjustments";

                #region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Interaction
                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer100");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Playback.Wait(5000);
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string DocumentNumber_fmuc0057 = FastDriver.DepositAdjustment.DocumentNo.FAGetValue();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Cancel").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual(@"true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual(@"True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Verify details of Event displayed in the eventlog for deposit adjustment";
                Playback.Wait(7000);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                Playback.Wait(10000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();

                Reports.TestStep = "Verifying for deposit adjustment";
                string deposit = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Deposit Adjustment]", "Comments", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", deposit.Contains("Adjustment Reason: Cancel").ToString());
                Reports.StatusUpdate("Verify for Document Number", deposit.Contains("Document Number: " + DocumentNumber_fmuc0057));
                Reports.StatusUpdate("Verify for Amount", deposit.Contains("Amount: 8000.00"));


                string sdateone = DateTime.Today.ToString("M-d-yyyy"); ;
                sdateone = sdateone.Replace("-", "/");
                Reports.StatusUpdate("Verify for Issue Date:" + sdateone, deposit.Contains("Issue Date: " + sdateone));
                Reports.StatusUpdate("Verify for Banking Account Number", deposit.Contains("Depositing Bank Account:"));
                Reports.StatusUpdate("Verify for Payor", deposit.Contains("Payor: Buyer100"));
                Reports.StatusUpdate("Verify for Update Trust Accounting", deposit.Contains("Update Trust Accounting=Yes"));
                Reports.TestStep = "Verify the Event Log for File created(User)";
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                string value = FastDriver.EventTrackingLog.EventTable.PerformTableAction("User", AutoConfig.UserName.ToUpper(), "User", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", value.Contains(AutoConfig.UserName.ToUpper()).ToString());
                Reports.TestStep = "Verify the Event Log for DepositAdjustment(Source)";
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                string username = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Deposit Adjustment]", "Source", TableAction.GetText).Message.ToString();
                Support.AreEqual("QA07, FAST", username);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0023()
        {

            try
            {
                Reports.TestDescription = "BR_FM3011B: Event for correcting adjustments";
                #region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Interaction
                Reports.TestStep = "Deposit a cash.";
                DepositCash("800", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer250");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a Correcting Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                Playback.Wait(1000);
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Correct Amount").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual(@"true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual(@"True", Loggedonuser);
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("700.00");
                string CorrectDescription = FastDriver.DepositAdjustment.CorrectDescription.FAGetValue();
                Support.AreEqual("True", CorrectDescription.Contains("Correct Amount ").ToString());
                FastDriver.DepositAdjustment.CorrectComment.FASetText("Amount corrected");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate after correct amt deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string tableamount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "800.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("800.00-", tableamount);

                Reports.TestStep = "Validate after correct amt deposit adjustment.";
                FastDriver.DepositSummary.WaitForScreenToLoad();
                tableamount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "700.00", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("700.00 ", tableamount);

                Reports.TestStep = "Verifying for deposit adjustment";
                Playback.Wait(7000);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                Playback.Wait(1000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();

                Reports.TestStep = "Verify for Corrected To and adjustment reason in comments of disbursement adjustment event";
                string deposit = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Deposit Adjustment]", "Comments", TableAction.GetText).Message.ToString();
                Support.AreEqual("True", deposit.Contains("Adjustment Reason: Correct Amount").ToString());
                Reports.StatusUpdate("Verify for Amount", deposit.Contains("Corrected To:700"));

                string username = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Deposit Adjustment]", "Source", TableAction.GetText).Message.ToString();
                Support.AreEqual("QA07, FAST", username);

                // 
                // 
                // ************************************************************************************************
                Reports.TestStep = "Validation for the adjustment reason Change Payor Name.";
                // ************************************************************************************************

                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");

                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("5555");

                string random = "" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.Manual.FAClick();
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(" ");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(random);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer251");
                DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                Playback.Wait(2000);
                Playback.Wait(10000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(10000);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Save the Receipt number.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string OriginalReceiptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "5,555.00", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a Correcting Payor Name Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Change Payor Name");
                Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Change Payor Name").ToString());
                UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual(@"true", UpdateTrustAccounting);
                Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual(@"True", Loggedonuser);
                FastDriver.DepositAdjustment.Payorname.FASetText("Buyer 251 to 252");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Save the issued date.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string IssueDate = FastDriver.DepositAdjustment.IssueDate.FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the deposits for payor name change.";
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "5,555.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("5,555.00-", amount);

                string Payor = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Payor", "Buyer 251 to 252", "Payor", TableAction.GetText).Message.ToString();
                Support.AreEqual("Buyer 251 to 252", Payor);

                Reports.TestStep = "Verifying for deposit adjustment in Event Log";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                Playback.Wait(5000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                deposit = FastDriver.EventTrackingLog.EventTable.FAGetText();

                Reports.TestStep = "Verifying for deposit adjustment";
                Support.AreEqual("True", deposit.Contains("Adjustment Reason: Change Payor Name").ToString());
                Support.AreEqual("True", deposit.Contains(OriginalReceiptNo).ToString());
                Support.AreEqual("True", deposit.Contains("Corrected To:Buyer 251 to 252").ToString());
                Support.AreEqual("True", deposit.Contains("Update Trust Accounting=Yes").ToString());

                // *************************************************************************************************************
                Reports.TestStep = "Validation for the adjustment type Change bank account.";
                // *************************************************************************************************************

                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Payor", "Buyer 251 to 252", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Correct Bank Account. To second value in the drop down list";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Bank Acct");
                Playback.Wait(1000);
                FastDriver.DepositAdjustment.CorrectBankAccountEnabled.FASelectItemByIndex(2);
                FastDriver.BottomFrame.Save();
                Playback.Wait(10000);
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Save the changed account number.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string ChangedDepAccount = FastDriver.DepositAdjustment.CorrectBankAcctNumber.FAGetSelectedItem();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying for deposit adjustment in Event Log";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                Playback.Wait(5000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                deposit = FastDriver.EventTrackingLog.EventTable.FAGetText();

                Reports.TestStep = "Verifying for deposit adjustment";
                Support.AreEqual("True", deposit.Contains("Adjustment Reason: Correct Bank Acct").ToString());
                Support.AreEqual("True", deposit.Contains("Update Trust Accounting=Yes").ToString());

                // *************************************************************************************************************
                Reports.TestStep = "Validation for the adjustment type Change Document Number.";
                // *************************************************************************************************************

                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Payor", "Buyer 251 to 252", "Payor", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(5000);
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Document No");
                Playback.Wait(1000);

                random = "" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositAdjustment.CorrectDocumentNo.FASetText(random);
                Playback.Wait(2000);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Save the changed deposit number.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string ModifiedDocNumber = FastDriver.DepositAdjustment.CorrectDocumentNo.FAGetValue();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                Reports.TestStep = "Verifying for deposit adjustment in Event Log";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();

                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                Playback.Wait(10000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                deposit = FastDriver.EventTrackingLog.EventTable.FAGetText();
                Reports.TestStep = "Verifying for deposit adjustment";
                Support.AreEqual("True", deposit.Contains("Adjustment Reason: Correct Document No").ToString());
                Support.AreEqual("True", deposit.Contains(OriginalReceiptNo).ToString());
                Support.AreEqual("True", deposit.Contains(ModifiedDocNumber).ToString());
                Support.AreEqual("True", deposit.Contains("Update Trust Accounting=Yes").ToString());

                // *************************************************************************************************************
                Reports.TestStep = "Validation for the adjustment type Input Error.";
                
                // *************************************************************************************************************
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.SelectRowInaTable();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Input Error type adjustment validation";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Input Error");
                Playback.Wait(1000);
                FastDriver.DepositAdjustment.Comment.FASetText("Test Comments while adjust");
                Playback.Wait(2000);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying for deposit adjustment in Event Log";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                Playback.Wait(10000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                deposit = FastDriver.EventTrackingLog.EventTable.FAGetText();
                Reports.TestStep = "Verifying for deposit adjustment";
                Support.AreEqual("True", deposit.Contains("Adjustment Reason: Input Error").ToString());
                Support.AreEqual("True", deposit.Contains(OriginalReceiptNo).ToString());
                Support.AreEqual("True", deposit.Contains(ModifiedDocNumber).ToString());
                Support.AreEqual("True", deposit.Contains("Update Trust Accounting=Yes").ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0024()
        {

            try
            {
                Reports.TestDescription = "ER_01: Duplicate Receipt number";

                #region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer201");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Save Automatic Reciept Number";
                Playback.Wait(5000);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string FirstAutoReceiptNum = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();

                Reports.TestStep = "Create a manual deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                Playback.Wait(3000);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Playback.Wait(2000);
                FastDriver.DepositInEscrow.Amount.FASetText("55.00");
                FastDriver.DepositInEscrow.Manual.FAClick();
                Playback.Wait(2000);
                Playback.Wait(1000);
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(" ");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(FirstAutoReceiptNum);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("#");
                DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                // ****************************************************START*****************************************************
                Reports.TestStep = "Error message for duplicate deposit receipt number.";
                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Receipt number already exists within Office.", errormsg);
                string random = "" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(" ");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(random);
                DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                Playback.Wait(2000);
                Playback.Wait(10000);

                FastDriver.WebDriver.HandleDialogMessage();
                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Save 1st Manual Reciept Number";
                Playback.Wait(5000);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string firsttManualRecieptNumber = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Manual.FAClick();
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(" ");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(FirstAutoReceiptNum);
                FastDriver.DepositInEscrow.Amount.FASetText("123.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Payor name");
                DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                // ****************************************************START*****************************************************
                Reports.TestStep = "Error message for duplicate  manual deposit receipt number.";
                errormsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Receipt number already exists within Office.", errormsg);

                //****************************************************END * ******************************************************
                random = "" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(" ");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(random);
                DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                Playback.Wait(2000);
                Playback.Wait(10000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string FinalReceipt = FastDriver.DepositInEscrow.ReceiptNo.FAGetText();

                Reports.TestStep = "To get document no, payor and save it in a variable.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string DocumentNo1 = FastDriver.DepositSummary.DocumentNo1.FAGetValue();

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "55.00", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Correct Document No.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Document No");
                FastDriver.DepositAdjustment.CorrectDocumentNo.FASetText(" ");
                FastDriver.DepositAdjustment.CorrectDocumentNo.FASetText(firsttManualRecieptNumber);
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "Click on OK button.";
                errormsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Error(s) occured. See Message pane.", errormsg);

                Reports.TestStep = "To verify the error message for same document no.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string ErrorMessage = FastDriver.DepositAdjustment.ErrorMessage.FAGetText();
                Support.AreEqual("True", ErrorMessage.Contains("Document No.: You must change Document No. to create this adjustment").ToString());
                FastDriver.DepositAdjustment.CorrectDocumentNo.FASetText(FirstAutoReceiptNum);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Error message for duplicate deposit receipt number.";
                errormsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Accounting Adjustment Form is ready for printing. Continue?", errormsg);
                Playback.Wait(5000);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0025()
        {

            try
            {
                Reports.TestDescription = "ER_03: Cash in excess of 10,000";
                #region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer202");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Deposit a cash more than sales price.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("6000");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("#");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(10000);

                Reports.TestStep = "Validate the Static Message on Deposit in Escrow Screen on Deposit More Amount.";
                string message = FastDriver.WebDriver.HandleDialogMessage(false, false);
                Support.AreEqual("True", message.Contains("The credit to party contains total cash or similar deposits in excess of $10,000.").ToString());
                Support.AreEqual("True", message.Contains("Form 8300 is required to be completed and filed with the IRS within 15 days.").ToString());
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                // **********************************************START******************************************
                //
                Reports.TestStep = "Validation for the Warning on Excessive cash deposits of type Money order.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("5000.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Money Order");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Initial Deposit");
                FastDriver.DepositInEscrow.Description.FASetText("Initial Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("#");
                FastDriver.DepositInEscrow.CheckNumber.FASetText("1234567889");
                FastDriver.DepositInEscrow.ABANumber.FASetText("1234567895");
                FastDriver.DepositInEscrow.BankName.FASetText("23testbank");
                FastDriver.DepositInEscrow.AccountNumber.FASetText("1234567895");
                FastDriver.BottomFrame.Save();


                Reports.TestStep = "Validate the Static Message on Deposit in Escrow Screen on Deposit More Amount.";
                message = FastDriver.WebDriver.HandleDialogMessage(false, false);
                Support.AreEqual("True", message.Contains("The credit to party contains total cash or similar deposits in excess of $10,000.").ToString());
                Support.AreEqual("True", message.Contains("Form 8300 is required to be completed and filed with the IRS within 15 days.").ToString());
                Playback.Wait(5000);
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage(false, false);


                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a Correcting Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                Playback.Wait(1000);
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Correct Amount").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("7,000.00");
                string CorrectDescription = FastDriver.DepositAdjustment.CorrectDescription.FAGetValue();
                Support.AreEqual("True", CorrectDescription.Contains("Correct Amount ").ToString());
                FastDriver.DepositAdjustment.CorrectComment.FASetText("Amount corrected");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Error message for cash deposit in excess of 10,000.";
                Playback.Wait(5000);
                message = FastDriver.WebDriver.HandleDialogMessage(false,false);
                Support.AreEqual("True", message.Contains("The credit to party contains total cash or similar deposits in excess of $10,000.").ToString());
                Support.AreEqual("True", message.Contains("Form 8300 is required to be completed and filed with the IRS within 15 days.").ToString());
                Playback.Wait(5000);
                Playback.Wait(1000);
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0026()
        {

            try
            {
                Reports.TestDescription = "ER_05_06: Process an Ad-Hoc Deposit Adjustment without issuedate";
                #region Baic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Interaction
                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer203");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "To click on adhoc adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.AdHocAdjustment.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Process an Ad-Hoc Deposit Adjustment.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string random = "#" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositAdjustment.DocumentNo.FASetText(random);
                string AdhocDepositReceiptNo = FastDriver.DepositAdjustment.DocumentNo.FAGetValue();
                FastDriver.DepositAdjustment.Amount.FASetText("6,000.00");
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Cancel").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                // 
                // 
                Reports.TestStep = "Clear Issue date in adhoc adjustment.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.IssueDate.FASetText(" ");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "To verify the error message for blank issue date.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string Issuedateblank = FastDriver.DepositAdjustment.ErrorMessage.FAGetText();
                Support.AreEqual("True", Issuedateblank.Contains("Issue Date: Issue Date is required").ToString());

                Reports.TestStep = "Clear Adjustment date in adhoc adjustment and enter issue date.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.IssueDate.FASetText("8-12-2012'");
                FastDriver.DepositAdjustment.AdjustmentDate.FASetText("");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "To verify the error message for blank adjustment date.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string Adjustmentdateblank = FastDriver.DepositAdjustment.ErrorMessage.FAGetText();
                Support.AreEqual("True", Adjustmentdateblank.Contains("Adjustment Date: Adjustment Date is required").ToString());

                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();
                Playback.Wait(2000);
                Playback.Wait(5000);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0027()
        {

            try
            {
                Reports.TestDescription = "ER_07: User tries to save Deposit Adjustment instance without entering different Deposit Amount.";
                #region Baic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Interaction

                Reports.TestStep = "Create a manual deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                Playback.Wait(3000);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Playback.Wait(2000);
                FastDriver.DepositInEscrow.Amount.FASetText("55.00");
                FastDriver.DepositInEscrow.Manual.FAClick();
                Playback.Wait(2000);
                Playback.Wait(1000);
                string random = "" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(" ");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(random);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("#");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                Playback.Wait(2000);
                Playback.Wait(10000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "55.00", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Correct Document No without entering corrected document no.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Document No");
                Playback.Wait(3000);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "To verify the error message for same document no.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string ErrorMessage = FastDriver.DepositAdjustment.ErrorMessage.FAGetText();
                Support.AreEqual("True", ErrorMessage.Contains("Document No.: You must change Document No. to create this adjustment").ToString());
                Reports.TestStep = "Correct Amount adjustment type without changing the amount.";
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                Playback.Wait(3000);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "To verify the error message for same amount.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                ErrorMessage = FastDriver.DepositAdjustment.ErrorMessage.FAGetText();
                Support.AreEqual("True", ErrorMessage.Contains("Deposit Amount: You must enter different Deposit Amount to create this adjustment").ToString());
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("10");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0028()
        {

            try
            {
                Reports.TestDescription = "BR_FM1757_BR_ES7602_FM2995_FM2996: Process a One-Sided Adjustment on a Deposit";

                #region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer309");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Save the receipt number.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNum = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Cancel").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Verifying for deposit adjustment";
                Playback.Wait(7000);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                Playback.Wait(5000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                string deposit = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Deposit Adjustment]", "Comments", TableAction.GetText).Message.ToString();
                Reports.TestStep = "Verifying for deposit adjustment in the event";
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Support.AreEqual("True", deposit.Contains("Adjustment Reason: Cancel").ToString());
                Support.AreEqual("True", deposit.Contains(ReceiptNum).ToString());
                Support.AreEqual("True", deposit.Contains("Amount: 8000.00").ToString());

                Reports.TestStep = "Validate after the deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("8,000.00-", amount);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0029()
        {

            try
            {
                Reports.TestDescription = "BR_FM1757_BR_FM2031: Reverse a One-Sided Adjustment on a Deposit";
                #region PreRequisites
                #region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion


                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer309");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Save the receipt number.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string ReceiptNum = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Cancel").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "To select the adjusted deposit and repost.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Reverse a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string AdjustmentReason = FastDriver.DepositAdjustment.AdjustmentReason.FAGetSelectedItem();
                Support.AreEqual("REPOST", AdjustmentReason);
                Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("REPOST").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Repost deposit");
                UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                Playback.Wait(5000);

                Reports.TestStep = "Validate after repost deposit.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string RepostDescription = FastDriver.DepositSummary.RepostDescription.FAGetText();
                Support.AreEqual("True", RepostDescription.Contains("REPOST").ToString());
                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Description", RepostDescription, "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("8,000.00 ", amount);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0030()
        {

            try
            {
                Reports.TestDescription = "BR_FM1757_BR_FM2030_FM2995_FM2997: Process a Correcting Adjustment on a Deposit";

                #region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer302");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a Correcting Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                Playback.Wait(1000);
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Correct Amount").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("7,000.00");
                string CorrectDescription = FastDriver.DepositAdjustment.CorrectDescription.FAGetValue();
                Support.AreEqual("True", CorrectDescription.Contains("Correct Amount ").ToString());
                FastDriver.DepositAdjustment.CorrectComment.FASetText("Amount corrected");
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                Playback.Wait(5000);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Validate after correct amt deposit adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "8,000.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("8,000.00-", amount);

                Reports.TestStep = "Validate after correct amt deposit adjustment.";
                amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "7,000.00", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("7,000.00 ", amount);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0057_REG0031()
        {

            try
            {
                Reports.TestDescription = "BR_FM2801_BR_ES7602_FM2995_FM2996: Process an Ad-Hoc Deposit Adjustment";
                #region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer304");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "To click on adhoc adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.AdHocAdjustment.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Process an Ad-Hoc Deposit Adjustment.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string random = "#" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositAdjustment.DocumentNo.FASetText(random);
                string AdhocDepositReceiptNo = FastDriver.DepositAdjustment.DocumentNo.FAGetValue();
                FastDriver.DepositAdjustment.Amount.FASetText("6,000.00");
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Cancel").ToString());
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Validate after the deposit adhoc adjustment.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "6,000.00-", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("6,000.00-", amount);
                string Tp = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "6,000.00-", "Tp", TableAction.GetText).Message.ToString();
                Support.AreEqual("RA", Tp);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0032()
        {

            try
            {
                Reports.TestDescription = "BR_FM3006: Process a Change of Bank Account Number on a Deposit";
                #region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Create manual deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("8000");
                FastDriver.DepositInEscrow.Manual.FAClick();
                Playback.Wait(2000);

                string random = "" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(" ");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(random);
                string DepositReceiptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                Support.DataSave("ReceiptNo", "DepositReceiptNo", DepositReceiptNo);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer306");
                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                Playback.Wait(2000);
                Playback.Wait(10000);

                Reports.TestStep = "Click on ok button.";
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                Playback.Wait(15000);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a Change of Bank Account Number on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Bank Acct");
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.DepositAdjustment.CorrectBankAccountEnabled.FASelectItemByIndex(3);
                string CorrectDescription = FastDriver.DepositAdjustment.CorrectDescription.FAGetValue();
                Support.AreEqual("True", CorrectDescription.Contains("Correct Bank Acct").ToString());
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Validate after the deposit adjusted by correct bank acct no.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string amount = FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "0.00", "Amount", TableAction.GetText).Message.ToString();
                Support.AreEqual("0.00 ", amount);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0033()
        {

            try
            {
                Reports.TestDescription = "FD1: Field validations";

                #region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Intreaction
                Reports.TestStep = "Create manual deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("55.00");
                FastDriver.DepositInEscrow.Manual.FAClick();
                Playback.Wait(2000);

                string random = "" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(" ");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(random);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("#");
                string DepositedToAcctNo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                Playback.Wait(10000);

                Reports.TestStep = "Click on ok button.";
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                Playback.Wait(15000);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "To get document no, payor and save it in a variable.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                string DocumentNumber1 = FastDriver.DepositSummary.DocumentNo1.FAGetText();
                string Payor = FastDriver.DepositSummary.Payor.FAGetText();
                string Amount1 = FastDriver.DepositSummary.Amount1.FAGetText();
                string Issuedate1 = FastDriver.DepositSummary.Issuedate1.FAGetText();

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "55.00", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Field validation.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string DocumentNo = FastDriver.DepositAdjustment.DocumentNo.FAGetValue();
                Support.AreEqual(DocumentNo, DocumentNumber1);
                string Amount = FastDriver.DepositAdjustment.Amount.FAGetValue();
                Support.AreEqual("55.00", Amount);
                string IssueDate = FastDriver.DepositAdjustment.IssueDate.FAGetValue();
                Support.AreEqual(IssueDate, Issuedate1);
                string ItemType = FastDriver.DepositAdjustment.ItemType.Exists().ToString();
                Support.AreEqual("True", ItemType);
                string Payorname = FastDriver.DepositAdjustment.Payorname.Exists().ToString();
                Support.AreEqual("True", Payorname);
                string Depositdescription = FastDriver.DepositAdjustment.Depositdescription.Exists().ToString();
                Support.AreEqual("True", Depositdescription);
                string User = FastDriver.DepositAdjustment.User.Exists().ToString();
                Support.AreEqual("True", User);
                string AdjustmentReason = FastDriver.DepositAdjustment.AdjustmentReason.FAGetText().ToString();
                Support.AreEqual("Cancel Change Payor Name Correct Amount Correct Bank Acct Correct Document No Input Error NSF", AdjustmentReason);
                FastDriver.DepositAdjustment.Description.FASetText("testdepositdescriptionforfield");
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("testdepositdescriptionforfield", Description);
                FastDriver.DepositAdjustment.Comment.FASetText("fieldvalidationforcommentmaxmi");
                FastDriver.DepositAdjustment.Comment.SendKeys(Keys.Tab);
                string Comment = FastDriver.DepositAdjustment.Comment.FAGetValue();
                Support.AreEqual("fieldvalidationforcommentmaxmi", Comment);
                string Enabled = FastDriver.DepositAdjustment.UpdateTrustAccounting.Enabled.ToString();
                Support.AreEqual("True", Enabled);

                Reports.TestStep = "Field validation-Amount-Min.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("1234567891.12");
                FastDriver.DepositAdjustment.CorrectAmount.SendKeys(Keys.Tab);
                string CorrectAmount = FastDriver.DepositAdjustment.CorrectAmount.FAGetValue();
                Support.AreEqual("1,234,567,891.12", CorrectAmount);

                Reports.TestStep = "Field validation-Amount-Exact.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("12345678912.120001");
                FastDriver.DepositAdjustment.CorrectAmount.SendKeys(Keys.Tab);
                CorrectAmount = FastDriver.DepositAdjustment.CorrectAmount.FAGetValue();
                Support.AreEqual("12,345,678,912.12", CorrectAmount);

                Reports.TestStep = "Field validation-Amount-Max.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("123456789123.10001");
                FastDriver.DepositAdjustment.CorrectAmount.SendKeys(Keys.Tab);
                CorrectAmount = FastDriver.DepositAdjustment.CorrectAmount.FAGetValue();
                Support.AreEqual("?", CorrectAmount);


                Reports.TestStep = "To clear corrected Amount.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("");

                Reports.TestStep = "Field validation-Amount-decimal low.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("12345678912.1");
                FastDriver.DepositAdjustment.CorrectAmount.SendKeys(Keys.Tab);
                CorrectAmount = FastDriver.DepositAdjustment.CorrectAmount.FAGetValue();
                Support.AreEqual("12,345,678,912.10", CorrectAmount);

                Reports.TestStep = "Field validation-Amount-decimal Max.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("1234567891.123");
                FastDriver.DepositAdjustment.CorrectAmount.SendKeys(Keys.Tab);
                CorrectAmount = FastDriver.DepositAdjustment.CorrectAmount.FAGetValue();
                Support.AreEqual("1,234,567,891.12", CorrectAmount);

                Reports.TestStep = "Field validation-Document No-Min.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Document No");
                FastDriver.DepositAdjustment.CorrectDocumentNo.FASetText(" ");
                FastDriver.DepositAdjustment.CorrectDocumentNo.FASetText("123456789");
                FastDriver.DepositAdjustment.CorrectDocumentNo.SendKeys(Keys.Tab);
                string CorrectDocumentNo = FastDriver.DepositAdjustment.CorrectDocumentNo.FAGetValue();
                Support.AreEqual("123456789", CorrectDocumentNo);

                Reports.TestStep = "Field validation-Document No-Exact.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.CorrectDocumentNo.FASetText("1234567891");
                FastDriver.DepositAdjustment.CorrectDocumentNo.SendKeys(Keys.Tab);
                CorrectDocumentNo = FastDriver.DepositAdjustment.CorrectDocumentNo.FAGetValue();
                Support.AreEqual("1234567891", CorrectDocumentNo);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Playback.Wait(5000);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0034()
        {

            try
            {
                Reports.TestDescription = "FD2: Field validations";
                #region Basic File Creation
                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Interaction
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").GetFileNumber();
                FastDriver.FileHomepage.WaitForScreenToLoad();


                Reports.TestStep = "Get and save file number.";
                Playback.Wait(3000);

                FastDriver.FileHomepage.WaitForScreenToLoad();
                string FileNum1 = FastDriver.FileHomepage.FileNum.FAGetValue();

                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("8000");
                FastDriver.DepositInEscrow.Manual.FAClick();
                Playback.Wait(2000);

                string random = "" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(" ");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(random);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer307");
                string Comment = FastDriver.DepositInEscrow.Comment.Enabled.ToString();
                Support.AreEqual("True", Comment);
                string DepositedToAcctNo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                string ReceiptNum = FastDriver.DepositInEscrow.ReceiptNo.FAGetValue();
                string Deliver = FastDriver.DepositInEscrow.Deliver.Enabled.ToString();
                Support.AreEqual("False", Deliver);
                string Print = FastDriver.DepositInEscrow.Print.Enabled.ToString();
                Support.AreEqual("False", Print);

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                // 
                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                Playback.Wait(10000);

                Reports.TestStep = "Click on ok button.";
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Reports.TestStep = "Print the checks.";
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                Playback.Wait(15000);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Deposit.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                Deliver = FastDriver.DepositAdjustment.Deliver.Enabled.ToString();
                Support.AreEqual("False", Deliver);
                Print = FastDriver.DepositAdjustment.Print.Enabled.ToString();
                Support.AreEqual("True", Print);

                // **************************************************************************************************

                // Validation for Comment Default Matrix
                Reports.TestStep = "Validation for  the Comment Default MAtrix.";
                Reports.TestStep = "Validation of the Comment for adjustment type cancel";
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                string Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Cancel").ToString());
                Comment = FastDriver.DepositAdjustment.Comment.Enabled.ToString();
                Support.AreEqual("True", Comment);

                Reports.TestStep = "Validation of the Comment for adjustment type Change Payor Name";
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Change Payor Name");
                Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Change Payor Name").ToString());

                FastDriver.DepositAdjustment.Payorname.FASetText("Payor name 2");
                FastDriver.DepositAdjustment.Payorname.SendKeys("{Tab}");

                Comment = FastDriver.DepositAdjustment.Comment.Enabled.ToString();
                Support.AreEqual("True", Comment);

                string CorrectComment = FastDriver.DepositAdjustment.CorrectComment.FAGetValue();
                Support.AreEqual("", CorrectComment);

                string CorrectDescription = FastDriver.DepositAdjustment.CorrectDescription.FAGetValue();
                Support.AreEqual("True", CorrectDescription.Contains("Change Payor Name").ToString());

                Reports.TestStep = "Validation of the Comment for adjustment type Correct Amount";
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Correct Amount").ToString());

                Comment = FastDriver.DepositAdjustment.Comment.Enabled.ToString();
                Support.AreEqual("True", Comment);
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("100");
                FastDriver.DepositAdjustment.CorrectAmount.SendKeys("{Tab}");
                Comment = FastDriver.DepositAdjustment.Comment.FAGetValue();
                Support.AreEqual("", Comment);
                CorrectComment = FastDriver.DepositAdjustment.CorrectComment.FAGetValue();
                Support.AreEqual("", CorrectComment);
                CorrectDescription = FastDriver.DepositAdjustment.CorrectDescription.FAGetValue();
                Support.AreEqual("True", CorrectDescription.Contains("Correct Amount").ToString());

                Reports.TestStep = "Validation of the Comment for adjustment type Correct Bank Account";
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Bank Acct");
                FastDriver.DepositAdjustment.CorrectBankAccountEnabled.FASelectItem("1234-56-789");
                FastDriver.DepositAdjustment.CorrectBankAccountEnabled.SendKeys("{Tab}");
                Comment = FastDriver.DepositAdjustment.Comment.FAGetValue();
                Support.AreEqual("", Comment);
                CorrectComment = FastDriver.DepositAdjustment.CorrectComment.FAGetValue();
                Support.AreEqual("Was " + DepositedToAcctNo + "", CorrectComment);
                CorrectDescription = FastDriver.DepositAdjustment.CorrectDescription.FAGetValue();
                Support.AreEqual("True", CorrectDescription.Contains("Correct Bank Acct").ToString());

                Reports.TestStep = "Validation of the Comment for adjustment type Correct Document Number";
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Document No");
                Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Correct Document No").ToString());

                Comment = FastDriver.DepositAdjustment.Comment.Enabled.ToString();
                Support.AreEqual("True", Comment);

                random = "" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositAdjustment.CorrectDocumentNo.Highlight();
                FastDriver.DepositAdjustment.CorrectDocumentNo.FASetText(random);
                FastDriver.DepositAdjustment.CorrectDocumentNo.SendKeys("{Tab}");
                Comment = FastDriver.DepositAdjustment.Comment.FAGetValue();
                CorrectComment = FastDriver.DepositAdjustment.CorrectComment.FAGetValue();
                Support.AreEqual("Was " + ReceiptNum, CorrectComment);
                CorrectDescription = FastDriver.DepositAdjustment.CorrectDescription.FAGetValue();
                Support.AreEqual("True", CorrectDescription.Contains("Correct Document No").ToString());
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Input Error");
                Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("Input Error").ToString());
                Comment = FastDriver.DepositAdjustment.Comment.FAGetValue();
                Support.AreEqual("", Comment);
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("NSF");
                Description = FastDriver.DepositAdjustment.Description.FAGetValue();
                Support.AreEqual("True", Description.Contains("NSF").ToString());
                Support.value = FastDriver.DepositAdjustment.Comment.Enabled.ToString();

                // **********************************************************************************************
                string UpdateTrustAccounting = FastDriver.DepositAdjustment.UpdateTrustAccounting.FAGetAttribute("checked").ToString();
                Support.AreEqual("true", UpdateTrustAccounting);
                Loggedonuser = FastDriver.DepositAdjustment.Loggedonuser.Exists().ToString();
                Support.AreEqual("True", Loggedonuser);
                FastDriver.DepositAdjustment.Comment.FASetText("Deposit Adjustment");

                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                // Adding validations for print and deliver button in deposit adjustment screen

                Deliver = FastDriver.DepositAdjustment.Deliver.Enabled.ToString();
                Support.AreEqual("True", Deliver);

                Print = FastDriver.DepositAdjustment.Print.Enabled.ToString();
                Support.AreEqual("True", Print);
                // 
                // 
                Reports.TestStep = "To verify For Credit to, Posted By, Posted on, File Number, Deliver button.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string FileNumber = FastDriver.DepositAdjustment.FileNumber.FAGetText();
                Support.AreEqual(FileNumber, FileNum1);
                string CredittoBuyer = FastDriver.DepositAdjustment.CredittoBuyer.FAGetAttribute("Selected");
                Support.AreEqual("true", CredittoBuyer);
                string CredittoSeller = FastDriver.DepositAdjustment.CredittoSeller.IsSelected().ToString();
                Support.AreEqual("False", CredittoSeller);
                string CredittoOther = FastDriver.DepositAdjustment.CredittoOther.IsSelected().ToString();
                Support.AreEqual("False", CredittoOther);
                string PostedBy = FastDriver.DepositAdjustment.PostedBy.FAGetText();
                // Support.AreEqual("True", Support.value.Contains(FASTLibrary.FASTLibrary.UserIDTypes.SplitViewWithSpace.ToUpper()).ToString());
                Support.AreEqual("FAST QA07", PostedBy);

                string time = DateTime.Now.ToDateString();
                time = time.Replace("/", "-");
                string PostedOn = FastDriver.DepositAdjustment.PostedOn.FAGetText().ToString();
                Deliver = FastDriver.DepositAdjustment.Deliver.Enabled.ToString();
                Support.AreEqual("True", Deliver);
                Print = FastDriver.DepositAdjustment.Print.Enabled.ToString();
                Support.AreEqual("True", Print);

                //FALibHS.GetControl("IIS.PrintEscrowSetlleStmt", "Method.FASelectItem("Preview");
                //FALibHS.GetControl("IIS.PrintEscrowSetlleStmt", "Deliver.FAClick();

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0035_PH()
        {

            try
            {
                Reports.TestDescription = "FM3010_ES10064 _PlaceHolder: Audit trail of all adjustments_Adjust Rejected IBA Deposit Receipt Automatically_Need to verify the impact of the updated information in the Balance Sheet, HUD-1 and Closing statements_Need to add the event log entry for this.";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0036()
        {

            try
            {
                Reports.TestDescription = "ES14178 Default Account after Adjustment of 1st Deposit";

                #region Basic File Creartion

                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Intreaction
                // 
                Reports.TestStep = "Get and save file number.";
                Playback.Wait(3000);
                string FileNum1 = FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").GetFileNumber();


                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();

                FastDriver.DepositInEscrow.Amount.FASetText("8000");
                FastDriver.DepositInEscrow.Manual.FAClick();
                Playback.Wait(2000);
                string random = "" + Support.RandomString("NNNNNNNN");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(" ");
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(random);
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Sanity Deposit In Escrow");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer700");
                string DefaultDepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "Enter Manual Reason and Click on OK."; FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                Playback.Wait(2000);
                Playback.Wait(10000);

                Reports.TestStep = "Click on ok button.";
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleDialogMessage();

                Playback.Wait(10000);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();
                Playback.Wait(15000);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "To click on adjustment button in Deposit History.";
                FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Adjust.FAClick();

                Reports.TestStep = "Correct Bank Account. To second value in the drop down list";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Bank Acct");
                Playback.Wait(1000);
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string CorrectBankAcctNumber = FastDriver.DepositAdjustment.CorrectBankAcctNumber.FAGetSelectedItem();
                Support.AreEqual(CorrectBankAcctNumber, DefaultDepositedTo);
            IList<IWebElement> accnumbers=    FastDriver.DepositAdjustment.CorrectBankAcctNumber.FAGetDropdownOptions();
                foreach(IWebElement el in accnumbers)
                {
                    if(el.Text.ToString()!=CorrectBankAcctNumber)
                    {
                        FastDriver.DepositAdjustment.CorrectBankAccountEnabled.FASelectItem(el.Text.ToString());
                        break;
                    }
                }
               
                FastDriver.BottomFrame.Save();
                Playback.Wait(10000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Save the changed account number.";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                string ChangedDepAccount = FastDriver.DepositAdjustment.CorrectBankAcctNumber.FAGetSelectedItem();

                Reports.TestStep = "Navigate to Deposit in Escrow and validate the deposited to account";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();
                Support.AreNotEqual(DepositedTo, DefaultDepositedTo);
                Support.AreEqual(ChangedDepAccount, DepositedTo);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0037()
        {

            try
            {
                Reports.TestDescription = "ES10063_Flow1: Prevent Manual IBA Receipt Adjustments.";


                #region Basic File Creartion

                IISLOGIN();
                CreateBasicFile();
                Playback.Wait(1000);
                #endregion

                #region GUI Intreaction
                // 
                Reports.TestStep = "Get and save file number.";
                Playback.Wait(3000);
                string FileNum1 = FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").GetFileNumber();

                Reports.TestStep = "Deposit a cash.";
                DepositCash("8000", "Cash", "Additional Closing Costs", "Sanity Deposit In Escrow", "Buyer", "Buyer307");
                string DepositedTo = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem();

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);
                Playback.Wait(5000);

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Add Beneficiary and transaction amount in IBA for Partial Withdrawn";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts");
                Playback.Wait(2000);
                FastDriver.InterestBearingAccounts.New.FAClick();
                Playback.Wait(2000);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FAClick();
                FastDriver.SelectIBABeneficiaryDlg.OtherName.FASetText("Beneficiary Name1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine1.FASetText("Beneficiary Name1 Address Line 1");
                FastDriver.SelectIBABeneficiaryDlg.OtherAddressLine2.FASetText(" Beneficiary Name1 Address Line 2");
                FastDriver.SelectIBABeneficiaryDlg.OtherCity.FASetText("Beneficiary Name1 Santa ana");
                FastDriver.SelectIBABeneficiaryDlg.OtherState.FASelectItem("CA");
                FastDriver.SelectIBABeneficiaryDlg.OtherZip.FASetText("92727");
                FastDriver.SelectIBABeneficiaryDlg.SSNTINNumber.FASetText("123456789");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(2000);
                Playback.Wait(4000);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Enter IBA Bank Account. Let the default account be selected.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Enter the Transaction Amount and save.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.Transactions.FAClick();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("50.00");
                string txt = FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, "Open IBA", 1, TableAction.GetText).Message.ToString();
                Support.AreEqual("Open IBA", txt);
                FastDriver.BottomFrame.Save();
                Playback.Wait(10000);

                Reports.TestStep = "ES10063_Flow2: Login TO FAST Application using FASTQA06 user and approve IBA requests";

                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);

                Reports.TestStep = "Approve the Transaction.";
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>("Home>Business Unit Processing>IBA Interface>IBA Transaction Approval");

                Playback.Wait(20000);
                FastDriver.IBATransactionApproval.WaitForScreenToLoad();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                Playback.Wait(10000);

                //Support.DataLoad("Numbers", "FileNum1");

                FastDriver.IBATransactionApproval.IBAApproval.FASetCheckbox(true);
                //FastDriver.IBATransactionApproval.IBAApproval.FAClick();
                FastDriver.IBATransactionApproval.Approve.FAClick();
                Playback.Wait(10000);
                Playback.Wait(10000);
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "ES10063_Flow3: Add partial withdrawn and approce it from 2nd user.";
                IISLOGIN();

                Reports.TestStep = "Enter file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search");
                FastDriver.FileSearch.WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(10000);
                FastDriver.FileSearch.WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Numbers.FASetText(FileNum1);

                Reports.TestStep = "Click on Find button after enter file number.";
                FastDriver.FileSearch.WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.FindNow.FAClick();
                Playback.Wait(32000);

                Reports.TestStep = "Navigate to IBA screen and checking for the status. Add button is enabled once transaction is completed.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts");

                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.RecordSummaryTable.PerformTableAction(5, "50.00", 5, TableAction.Click);
                FastDriver.InterestBearingAccounts.Transactions.FAClick();
                Playback.Wait(5000);


                for (int i = 0; i < 10; i++)
                {
                    if (!(FastDriver.InterestBearingAccounts.Add.IsEnabled().ToString() == "True"))
                    {
                        Playback.Wait(30000);
                        FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts");

                        FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                        Playback.Wait(20000);
                        FastDriver.InterestBearingAccounts.Transactions.FAClick();
                        Playback.Wait(20000);
                    }
                    else
                    {
                        break;
                    }
                }
                Support.value = FastDriver.InterestBearingAccounts.Add.Enabled.ToString();
                FastDriver.InterestBearingAccounts.Add.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Add Partial Withdrawal.";

                FastDriver.AddIBATransactionDlg.WaitForScreenToLoad();
                FastDriver.AddIBATransactionDlg.PartialWithdrawal.FASetCheckbox(true);
                //if (!(FastDriver.AddIBATransactionDlg.PartialWithdrawal.IsSelected().ToString() == "True"))
                //    FastDriver.AddIBATransactionDlg.PartialWithdrawal.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(2000);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.PartialWithdrawnAmount.FASetText("25.00");
                Playback.Wait(2000);

                string transactionvalue = FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, "Partial Withdrawal", 1, TableAction.GetText).Message.ToString();
                Support.AreEqual("Partial Withdrawal", transactionvalue);

                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                Reports.TestStep = "Login TO FAST Application using FASTQA06 user and approve IBA requests";
                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);

                Reports.TestStep = "Approve the Transaction.";
                FastDriver.LeftNavigation.Navigate<IBATransactionApproval>("Home>Business Unit Processing>IBA Interface>IBA Transaction Approval");

                Playback.Wait(20000);
                FastDriver.IBATransactionApproval.WaitForScreenToLoad();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                Playback.Wait(10000);

                //Support.DataLoad("Numbers", "FileNum1");

                FastDriver.IBATransactionApproval.IBAApproval.FASetCheckbox(true);
                //FastDriver.IBATransactionApproval.IBAApproval.FAClick();
                FastDriver.IBATransactionApproval.Approve.FAClick();
                Playback.Wait(10000);
                if (FastDriver.IBATransactionApproval.isAlertPresent())
                {
                    Reports.TestStep = "Click on Ok button.";
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                else
                {

                    FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(10000);
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                }

                Reports.TestDescription = "ES10063_Flow4: Validate the issue deposit for partial withdrawn and Validate the status of buttons for IBA deposit.";


                IISLOGIN();

                Reports.TestStep = "Enter file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search");
                FastDriver.FileSearch.WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Country.FASelectItem("USA");
                Playback.Wait(10000);
                FastDriver.FileSearch.WaitForFileSearchScreenToLoad();
                Playback.Wait(10000);
                FastDriver.FileSearch.Numbers.FASetText(FileNum1);

                Reports.TestStep = "Click on Find button after enter file number.";
                FastDriver.FileSearch.WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.FindNow.FAClick();
                Playback.Wait(32000);

                Reports.TestStep = "Navigate to Deposit Summary and store the deposit number for IBA Partial withdrawn";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
                FastDriver.DepositSummary.WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "25.00", "Amount", TableAction.Click);

                Reports.TestStep = "Validate the status of buttons for IBA deposit.";

                Support.value = FastDriver.DepositSummary.ViewDetails.Enabled.ToString();
                Support.AreEqual("True", Support.value);

                Support.value = FastDriver.DepositSummary.Adjust.Enabled.ToString();
                Support.AreEqual("False", Support.value);

                Support.value = FastDriver.DepositSummary.AdHocAdjustment.Enabled.ToString();
                Support.AreEqual("False", Support.value);


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0038_PH()
        {
            try
            {

                Reports.TestDescription = "ES14330-ES14381: BR's related to Incoming Wire.";
                Reports.TestStep = "Incoming wires are not available..Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);


            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0057_REG0039_PH()
        {

            try
            {
                Reports.TestDescription = "ES14338_ES14340: IW - Cancel Receipt Allowed_IW - Cancel Receipt for IW posted to Multiple Files";
                Reports.TestStep = "Incoming wires are not available..Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void FMUC0057_REG0040_PH()
        {

            try
            {
                Reports.TestDescription = "ES14340  IW - Cancel Receipt for IW posted to Multiple Files.";
                Reports.TestStep = "Incoming wires are not available..Dummy subtest to use it as a Place holder for Non Automated scenarios.";

                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY",false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        #endregion

        #region Private TestMethods


        private void IISLOGIN(string UserName = null, string Password = null)
        {
            var credentials = new Credentials() { UserName = UserName, Password = Password };
            if (UserName == null)
            {
                credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            }
            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
        }
        private void CreateBasicFile()
        {

            var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            Reports.TestStep = "Create File using web service.";

            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

        }

        private void DepositCash(string Amount, string TypeOfFund, string Representing, string Description, string RecievedFrom, string Payor, string Comment = null)
        {

            Reports.TestStep = "Deposit a cash.";
            FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");

            FastDriver.DepositInEscrow.WaitForScreenToLoad();
            FastDriver.DepositInEscrow.Amount.FASetText(Amount);
            FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(TypeOfFund);
            FastDriver.DepositInEscrow.Representing.FASelectItem(Representing);
            FastDriver.DepositInEscrow.Description.FASetText(Description);
            FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(RecievedFrom);
            FastDriver.DepositInEscrow.Payor.FASetText(Payor);
            if (Comment != null)
                FastDriver.DepositInEscrow.Comment.FASetText(Comment);
        }

        private void _CreateFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = FormType.CD;
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.SalesPriceAmount = 5000;
            customizableFileRequest.File.LiabilityAmount = 5000;

            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        } 
                };

            customizableFileRequest.File.Services = new Service[] 
                    { 
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "TO"
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "SEO"
                        }
                    };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            #region CreateNewLoan
            var newLoan = new NewLoanParameters()
            {
                Type = "",
                Amount = "",
                GABCode = "247"
            };
            #endregion

        }

        public void SavePDFgenerated(string settlementstatementtype, out string strSavesettlementgenerated)
        {
            Playback.Wait(2000);
            string ReportsDir = Reports.RUNRESULTDIR + "\\PDF" + "\\" + this.TestContext.TestName;
            CreateDirectory(ReportsDir);
            strSavesettlementgenerated = ReportsDir + @"\SettlementStatment" + settlementstatementtype + ".pdf";
            Playback.Wait(1000);

            // SavePDF(strSavesettlementgenerated);
            Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "File Path:" + strSavesettlementgenerated, Reports.Result(true), "");

        }
        public void CompareGeneratedandbaselinedPDF(string strSavesettlementgenerated, string settlementstatmenttype)
        {
            Playback.Wait(5000);
            Reports.TestStep = "Compare PDFs files";
            string strSettlementStatmentExpected;
            string baselinedocpath = Support.ReadAppSettings("appSettings", "sharedLocation");
            if (ClosingDisclosureSupport.IMDFormType == "CD")
                strSettlementStatmentExpected = baselinedocpath + @"\BaselinedPDFs\Baseline_CD_SS_" + settlementstatmenttype + ".pdf";
            else
            {
                strSettlementStatmentExpected = baselinedocpath + @"\BaselinedPDFs\Baseline_SS_" + settlementstatmenttype + ".pdf";
            }
            string strSettlementStatementComparisionreport = Reports.RUNRESULTDIR + "\\PDF" + "\\" + this.TestContext.TestName;
            CreateDirectory(strSettlementStatementComparisionreport);
            // ComparePDFs(strSettlementStatmentExpected, strSavesettlementgenerated, strSettlementStatementComparisionreport);
            Reports.UpdateDebugLog("Done with Compare PDF file", "", "", "", "", "Verify PDF", Reports.Result(true), "");

        }

        public void CreateDirectory(string DirectoryName)
        {
            if (!Directory.Exists(DirectoryName))
            {
                Directory.CreateDirectory(DirectoryName);
            }
        }
        private void ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);

        }

         #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
