﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using System.Linq;
using System.Collections.Generic;




namespace EscrowTransactions
{
     [CodedUITest]
    public class FMUC0140 : MasterTestClass
    {
        #region r12.2016
         [TestMethod]
        public void FMUC0140_REG0001()
        {
             try
            {
                Reports.TestDescription = "US#896935:To verify   Buyer tab  design  in Fractional Settlement Statement screen";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                 //TDS
               // string FirstSalesAmount = "234567483.22";
                string SecondSalesAmount = "45678.12";
                string ThirdSalesAmount = "876";
                String TDSDesc = "Updaed Desc in TDS Screen";

                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Through UI
                Reports.TestStep = "Create File with Commercial business type.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("Property 1");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Agricultural Land");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationTRact.FASetText("Tract1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First property: Address1 line 1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("First property: Address1 line 2");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("First property: Address1 line 3");
                FastDriver.QuickFileEntry.PropertyBookAddrLin4.FASetText("First property: Address1 line 4");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("City1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("NV");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("89003");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Nye");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFN1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLN1");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFN1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLN1");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("420");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                FastDriver.FileHomepage.Open();
                string fileNum = FastDriver.FileHomepage.FileNumPrefix.FAGetValue() + "-" + FastDriver.FileHomepage.FileNum.FAGetValue() + "-" + FastDriver.FileHomepage.FileNumSufix.FAGetValue();
                FastDriver.TopFrame.SwitchToContentFrame();
                string[] EscrowOfficerName = FastDriver.FileHomepage.EscrowOwningOfficeOfficer.FAGetSelectedItem().Split(',');
                #endregion

                #region Adding Charges in All Screens
                #region TDS
                Reports.TestStep = "Navigate to the Terms/Dates/Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad().SwitchToContentFrame();
                Reports.TestStep = "Verify the Edit SP/OPL button is displayed in the Terms/Dates/Status screen";
                Support.AreEqual("true", FastDriver.TermsDatesStatus.Edit_SP_OPL.Exists().ToString(), true);
                Reports.TestStep = "Verify the SP/OPL pop up dialog is opened after clicking the Edit SP/OPL button.";
                FastDriver.TermsDatesStatus.Edit_SP_OPL.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities", true, 30);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SwitchToDialogContentFrame();
                Support.AreEqual("True", FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SP_OPL_Dlg_Frame.Exists().ToString(), true);

                Reports.TestStep = "Enter Sales Price/Owner's Policy Liabilities Amounts.";
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceDesc.FASetText(TDSDesc);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.SecondSalePriceAmount.FASetText(SecondSalesAmount);
                FastDriver.SalePrice_OwnerPolicyLiabilityDlg.ThirdSalePriceAmount.FASetText(ThirdSalesAmount);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15,switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15, switchBackToFastWindow:true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region  Deposits in Escrow
                Reports.TestStep = "Add Deposits";

                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("50000000.13");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Credit Card");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Closing Costs");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Seller");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 15);
                //KeyboardSendKeys(FAKeys.Escape);

                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("0.07");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Other");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Miscellaneous Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Other");
                FastDriver.DepositInEscrow.Payor.FASetText("Sangakkara");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 15);

                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("123456789");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 15);

                #endregion

                #region Navigate to REB screen and create REB instances with REB charges
                Reports.TestStep = "Navigate to REB screen and create REB instances with REB charges";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(5000);
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDSLLRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("200.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("300.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Seller REBC Desc1" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("20.00" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText("30.00" + FAKeys.Tab);

                Keyboard.SendKeys("{TAB}");

                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription2.FASetText("Seller REBC Desc2" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit2.FASetText("10.00" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit1.FASetText("40.00" + FAKeys.Tab);
                Keyboard.SendKeys("{TAB}");
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText("Seller POC by Broker" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("60.00" + FAKeys.Tab);
                Keyboard.SendKeys("{TAB}");

                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDBUYRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("400.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("100.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Buyer REBC Desc" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("600.00" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText("150.00" + FAKeys.Tab);
                Keyboard.SendKeys("{TAB}");
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText("Buyer POC by Broker" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("26.66" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FADoubleClick();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();

                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("12,345,678,912.22" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Other1REBCharges" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("12,456,789,230.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FADoubleClick();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDOTHRBR2");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("56.55" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("3.55" + FAKeys.Tab);

                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText("Other2POC by Broker" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("20.50" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Deposits outside Escrow
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Seller's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("8000");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem("Buyer's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText("321143215.66");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("321151215.66");
                FastDriver.BottomFrame.Save();
                #endregion

                #region Adjustment
                Reports.TestStep = "Create Misc Adjustment Instance (data from test case BAT0001).";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.BuyerCredit.FASetText("50.00" + FAKeys.Tab);
                FastDriver.AdjustmentMisc.BuyerCredit2.FASetText("8787.00" + FAKeys.Tab);
                if (!AutoConfig.UseCDFormType)
                    FastDriver.AdjustmentMisc.SellerCredit.FASetText("50.00" + FAKeys.Tab);

                Reports.TestStep = "Create off-set adjustment.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("50.00" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCredit.FASetText("50.00" + FAKeys.Tab);
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentOffset.BuyerCredit.FASetText("50.00" + FAKeys.Tab);
                    FastDriver.AdjustmentOffset.SellerCharge.FASetText("50.00" + FAKeys.Tab);
                }
                #endregion 

                #region Attorney
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FMUC0135.CreateAttorney(BuyerCharge: "432165432.11", SellerCharge: "2134654321.88", GabCode: "HUDATASTL1");
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "First Instance Second cahrge A987", 453.00, null, null, null, 92.00);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "First Instance Third cahrge B876", null, null, 7654.00, null, 65.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FMUC0135.CreateAttorney(BuyerCharge: "432165432.11", SellerCharge: "2134654321.88", GabCode: "HUDSELATT1");
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "First Instance Second cahrge A987", 453.00, null, null, null, 92.00);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "First Instance Third cahrge B876", null, null, 7654.00, null, 65.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region NewLoan
                Reports.TestStep = "Navigate to New Loan";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Pull GAB code";
                FastDriver.NewLoan.FindGABCode("HUDNWLNDR1");
                //FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("22233344455.66");

                Reports.TestStep = "Click on Loan Charges tab";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Enter data in Interest Calculation section";
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");


                Reports.TestStep = "In the Origination Charges section, enter amounts in a few charge fields";
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", buyerCharge: 100);
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Origination Fee", buyerCredit: 200);
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Underwriting Fee", sellerCharge: 300);
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Processing Fee", sellerCredit: 400);
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Verification Fee", buyerCharge: 500, buyerCredit: 600, sellerCharge: 700, sellerCredit: 800);


                #endregion

                #region Payoffloan

                Reports.TestStep = "Navigate to Payoff Loan screen and add 2 instances of Payoff Lender with values for buyer and seller charges and credits.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();

                FastDriver.PayoffLoanDetails.FindGABCode("HUDPAYOFF1");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.FASetText("20000");

                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Reconveyance Fee", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Late Charge", "Seller Charge", TableAction.SetText, "10000.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Prepayment Penalty", "Buyer Credit", TableAction.SetText, "200.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Prepayment Penalty", "Seller Credit", TableAction.SetText, "300.00");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Recording Fee", "Buyer Credit", TableAction.SetText, "700.00");
                FastDriver.BottomFrame.Done();
                #endregion 

                #region AssumptionLoan
                Reports.TestStep = "Navigate to Payoff Loan screen and add 2 instances of Payoff Lender with values for buyer and seller charges and credits.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
               
                FastDriver.AssumptionLoanDetails.FindGABCode("HUDASLNDR1");
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.FASetText("20000");

                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Buyer Charge", TableAction.SetText, "5000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Seller Charge", TableAction.SetText, "3000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Document Fee", "Buyer Charge", TableAction.SetText, "10000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Late Charge", "Seller Charge", TableAction.SetText, "786000.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Balance of Impounds/Reserves Acct.", "Buyer Credit", TableAction.SetText, "200.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Balance of Impounds/Reserves Acct.", "Seller Credit", TableAction.SetText, "300.00");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Assumption Transfer Fee", "Seller Credit", TableAction.SetText, "600.00");

               
                FastDriver.BottomFrame.Done();
               
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to the Survey screen and add values for buyer and seller charges.";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.FindGABCode("HUDSURVEY1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("11.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("12.00");
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, "1st Instance Second cahrge G876", 765432187.00, null, null, null, 92.00);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, "1st Instance Third cahrge H654", null, null, 123456789.22, null, 65.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region  Lease 
                Reports.TestStep = "Navigate to the Lease screen and add values for buyer and seller charges.";
                FastDriver.LeaseDetail.Open().WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE01");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("132456721.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("432156788.54");
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.ChargeTable, "1st Instance Second charge Z333", null, null, 453.00, null, 92.00);
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.ChargeTable, "1st Instance Third charge E222", 8765.00, null, null, null, 65.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Utility
                Reports.TestStep = "Navigate to the Utility screen and add values for buyer and seller charges.";
                FastDriver.UtilityDetail.Open().WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("1000");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText("1300");
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, "1st Instance Second charge H543", 654322198.11, null, null, null, 92.00);
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, "1st Instance Third charge J765", null, null, 234154321.44, null, 65.00);
                FastDriver.BottomFrame.Done();

                #endregion

                #region  Home Warranty
                Reports.TestStep = "Create Home Warranty Detail Screen.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HUDHMWRNT1");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", sellerCharge: 50.00);
                FastDriver.BottomFrame.Done();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                #endregion

                #region Homeowner Association
                Reports.TestStep = "Navigate to Homeowner Association and add values to buyer and seller.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                FastDriver.HomeownerAssociation.FindGABCode("HUDHMOWNR1");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FASetText("1200");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge1.FASetText("12500000000");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge2.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge3.FASetText("5000");

                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FASetText("500");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge1.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge2.FASetText("500");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge3.FASetText("1000");
                Reports.TestStep = "Adding POC amounts for Homeowner Association Subsection in Disbursement section.";
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                FastDriver.HomeownerAssociation.SwitchToDialogContentFrame();
                FastDriver.HomeownerAssociation.AssociationCharge1PBbyBuyer.FASetText("1000");
                FastDriver.HomeownerAssociation.AssociationBuyerCharge1PBbyOther.FASetText("200");
                FastDriver.HomeownerAssociation.AssociationBuyerCharge1PBotherDropdown.FASelectItem("POC-L");
                FastDriver.HomeownerAssociation.SwitchToDialogBottomFrame();
                FastDriver.HomeownerAssociation.PPDDone.FAClick();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Tax Check
                Reports.TestStep = "Navigate to the Property Tax Check screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("HUDPRTXCH1");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("3000");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_3.FASetText("200");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_5.FASetText("100");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_2.FASetText("250");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_4.FASetText("250");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToDialogContentFrame();
                FastDriver.PropertyTaxCheck.PTPBbyBuyerAtClosing.FASetText("2000");
                FastDriver.PropertyTaxCheck.PTBPbyOthers.FASetText("1000");
                FastDriver.PropertyTaxCheck.DropdownPT.FASelectItem("POC-L");
                FastDriver.PropertyTaxCheck.SwitchToDialogBottomFrame();
                FastDriver.PropertyTaxCheck.PDDdone.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Outside Escrow Company
                Reports.TestStep = "Navigate to the Outside Escrow Company screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC1");
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("Outside Charges" + Keys.Tab);
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FASendKeys("2000");
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FASetText("13000000000");
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToDialogContentFrame();
                FastDriver.OutsideEscrowCompanyDetail.OEPBbyBuyerAtClosing.FASetText("1000");
                FastDriver.OutsideEscrowCompanyDetail.OEBPbyOthers.FASetText("1000");
                FastDriver.OutsideEscrowCompanyDetail.DropdownOE.FASelectItem("POC");
                FastDriver.OutsideEscrowCompanyDetail.SwitchToDialogBottomFrame();
                FastDriver.OutsideEscrowCompanyDetail.PDDdone.FAClick();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance
                Reports.TestStep = "Navigate to the Insurance screen and add values for buyer and seller charges.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FindGAB("HUDFRINSR1 ");
                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("10000000000");
                FastDriver.InsuranceFire.FireSellerCharge.FASetText("500");
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad().Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.FindGAB("HUDFLINSR1");
                FastDriver.Insuranceflood.FloodBuyercharge.FASetText("500");
                FastDriver.Insuranceflood.FloodSellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad().Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.FindGAB("HUDWDINSR1");
                FastDriver.InsuranceWind.WindBuyerCharge.FASetText("4500");
                FastDriver.InsuranceWind.WindSellerCharge.FASetText("1000");
                FastDriver.InsuranceWind.WindPaymentDetails.FAClick();
                FastDriver.InsuranceWind.SwitchToDialogContentFrame();
                FastDriver.InsuranceWind.WindPBbyBuyerAtClosing.FASetText("2500");
                FastDriver.InsuranceWind.WindBPbyOthers.FASetText("2000");
                FastDriver.InsuranceWind.DropdownWind.FASelectItem("POC-L");
                FastDriver.InsuranceWind.SwitchToDialogBottomFrame();
                FastDriver.InsuranceWind.PPDDone.FAClick();
                FastDriver.InsuranceWind.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad().EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.FindGAB("HUDERINSR1");
                FastDriver.InsuranceEarth.EarthBuyerCharge.FASetText("1000");
                FastDriver.InsuranceEarth.EarthSellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Inspection Repair
                Reports.TestStep = "Navigate to Inspection Repair Pest screen and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.FindGAB("HUDPEST001");
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("50000000000");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("1000");
                FastDriver.InspectionRepairPest.buyerCharge1.FASetText("8662");
                FastDriver.InspectionRepairPest.buyerCharge1.FASetText("8662");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Inspection Repair Septic and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").WaitForScreenToLoad();
                FastDriver.InspectionRepairSeptic.FindGAB("HUDSEPTIC1");
                FastDriver.InspectionRepairSeptic.BuyerCharge.FASetText("5000");
                FastDriver.InspectionRepairSeptic.SellerCharge.FASetText("1000");
                FastDriver.InspectionRepairSeptic.PaymentDetails.FAClick();
                FastDriver.InspectionRepairSeptic.SwitchToDialogContentFrame();
                FastDriver.InspectionRepairSeptic.SepticPBbyBuyerAtClosing.FASetText("2000");
                FastDriver.InspectionRepairSeptic.SepticBPbyOthers.FASetText("3000");
                FastDriver.InspectionRepairSeptic.DropdownSepticOtherBuyer.FASelectItem("POC");
                FastDriver.InspectionRepairSeptic.SwitchToDialogBottomFrame();
                FastDriver.InspectionRepairSeptic.SepticPPDdone.FAClick();
                FastDriver.InspectionRepairSeptic.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Inspection Repair Other and add values to buyer and seller.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.FindGAB("246");
                FastDriver.InspectionRepairOther.BuyerCharge.FASetText("500");
                FastDriver.InspectionRepairOther.SellerCharge.FASetText("1000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Miscellaneous Disbursement setup
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                Playback.Wait(3000);
                FMUC0135.FillMiscDisbursementDetail(Description: "1stInstFirstcharge", BuyerCharge: "7865", SellerCharge: "9876");
                FastDriver.MiscDisbursementDetail.LoanEstimate.SendKeys(FAKeys.Tab);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "1stInstSecondcharge", 432154326.11, null, null, null, 76.00);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "1stInstThirdcharge", null, null, 654334562.55, null, null);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Adding Taxes
                Reports.TestStep = "Test data, Prorations";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.New.FAClick();
                Playback.Wait(2000);
                FastDriver.ProrationTax.Amount.FASetText("1000");
                FastDriver.ProrationTax.Desc.FASetText("Proration tax and special char ABCabc123!@#");
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(2000);
                FastDriver.ProrationTax.bc.FASetText("50");
                FastDriver.ProrationTax.sc.FASetText("50");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Test data, Funds held";
                FastDriver.LeftNavigation.Navigate<HoldFunds>(@"Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Reason For First Hold Fund Instance.");
                FastDriver.HoldFunds.SellerCharge.FASetText("100");
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(2000);
                FastDriver.ProrationTax.New.FAClick();
                Playback.Wait(2000);
                FastDriver.HoldFunds.FindGABCode("BOA");
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText("10.96");
                FastDriver.BottomFrame.New();
                FastDriver.HoldFunds.WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Test Buyer Fund");
                FastDriver.HoldFunds.RadbtnBuyer.FASetCheckbox(true);
                FastDriver.HoldFunds.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.FindGABCode("247");
                FastDriver.HoldFunds.HoldFundBuyerCharge1.FASetText("11.11");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Fees
                Reports.TestStep = "Navigate to the Title/Escrow Fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItemBySendingKeys("All");

                FastDriver.FileFees.FindNow.FAClick();

                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFeeTable, continueOnFailure: true);
                FMUC0135.RandomFeeSelect();
                FastDriver.FileFees.WaitForScreenToLoad();

                if (FastDriver.FileFees.AddedFeeBuyerCharge0.Exists())
                    FastDriver.FileFees.WaitForScreenToLoad().AddedFeeBuyerCharge0.FASetText("100");
                if (FastDriver.FileFees.AddedFeeBuyerCharge1.Exists())
                    FastDriver.FileFees.AddedFeeBuyerCharge1.FASetText("100");
                if (FastDriver.FileFees.AddedFeeBuyerCharge2.Exists())
                    FastDriver.FileFees.AddedFeeBuyerCharge2.FASetText("100");
                if (FastDriver.FileFees.AddedFeeBuyerCharge3.Exists())
                    FastDriver.FileFees.AddedFeeBuyerCharge3.FASetText("100");
                else
                    Keyboard.SendKeys("{TAB}");

                if (FastDriver.FileFees.AddedFeeSellerCharge0.Exists())
                    FastDriver.FileFees.AddedFeeSellerCharge0.FASetText("50");
                if (FastDriver.FileFees.AddedFeeSellerCharge1.Exists())
                    FastDriver.FileFees.AddedFeeSellerCharge1.FASetText("50");
                if (FastDriver.FileFees.AddedFeeSellerCharge2.Exists())
                    FastDriver.FileFees.AddedFeeSellerCharge2.FASetText("50");
                if (FastDriver.FileFees.AddedFeeSellerCharge3.Exists())
                    FastDriver.FileFees.AddedFeeSellerCharge3.FASetText("50");
                else
                    Keyboard.SendKeys("{TAB}");

                FastDriver.BottomFrame.Done();
                #endregion

                #endregion

                #region Navigate to Fractional SS

                Reports.TestStep = "Navigate to Fractional SS";
                FastDriver.ViewFractionalSettlementStmt.Open();
                FastDriver.ViewFractionalSettlementStmt.FSSGrid.Highlight();
                String Data = FastDriver.ViewFractionalSettlementStmt.FSSGrid.PerformGridAction("Description", "Consideration", "Description", TableAction.GetText).ToString();
                Support.AreEqual("Consideration", Data);
                #endregion   



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion
    
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
