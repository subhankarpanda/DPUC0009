﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0061 : MasterTestClass
    {
        #region BAT
        [TestMethod]
        public void FMUC0061_BAT0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "MF1_00: Create a Fee Transfer Disbursement";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                Reports.TestStep = "Enter second fee in Title and escrow.";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "11.11");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "33.33");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Verify the Charge Detail text box and “Fee Transfer” in the ‘Disburse As” dropdown box.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Fee Transfer", FastDriver.EditDisbursement.DisburseAs.FAGetSelectedItem().Clean(), "DisburseAs");
                Support.AreEqual(false, FastDriver.EditDisbursement.DisburseAs.IsEnabled(), "DisburseAs IsEnabled");
                Support.AreEqual(true, FastDriver.EditDisbursement.VoucherChargeDetail.FAGetText().Clean().Contains("New Home Rate (Title Only): 4.98"), "VoucherChargeDetail contains New Home Rate (Title Only): 4.98");
                Support.AreEqual(true, FastDriver.EditDisbursement.VoucherChargeDetail.FAGetText().Clean().Contains("New Home Rate Eagle Lender Policy-1: 44.44"), "VoucherChargeDetail contains New Home Rate Eagle Lender Policy-1: 44.44");

                Reports.TestStep = "Verify pending fee transfer Disbursement.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.PrintDlg.SelectPrinter().ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Verify issued fee transfer.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                string status = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.GetText).Message.Clean();
                Support.AreEqual("Issued", status, "Fee Transfer status");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_BAT0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "AF1_00: Edit a Fee Transfer Disbursement";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                Reports.TestStep = "Enter second fee in Title and escrow.";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "11.11");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "33.33");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Edit Pend Fee Transfer.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Edit Fee Transfer Disbursement.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.EditDisbursement.DisburseAs.IsEnabled(), "DisburseAs IsEnabled");
                FastDriver.EditDisbursement.VoucherDescription.FASetText("Title and Escrow Fees Description Edited");
                FastDriver.EditDisbursement.VoucherMemo.FASetText("Voucher info edited for Title and Escrow Fees");
                Support.AreEqual(false, FastDriver.EditDisbursement.VoucherChargeDetail.IsEnabled(), "VoucherChargeDetail IsEnabled");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Edit Fee Transfer Disbursement.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual("Title and Escrow Fees Description Edited", FastDriver.EditDisbursement.VoucherDescription.FAGetValue().Clean(), "VoucherDescription");
                Support.AreEqual("Voucher info edited for Title and Escrow Fees", FastDriver.EditDisbursement.VoucherMemo.FAGetValue().Clean(), "VoucherMemo");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_BAT0003_04()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "AF2: Adjust an Issued Fee Transfer Disbursement-CorrectBankAccount/Input Error/Cancel/Repost";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                Reports.TestStep = "Enter second fee in Title and escrow.";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Verify pending fee transfer.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Print the checks.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickCancel();

                Reports.TestStep = "Verify issued fee transfer.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                string status = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.GetText).Message.Clean();
                Support.AreEqual("Issued", status, "Fee Transfer status");

                Reports.TestStep = "Adjust disbursement.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "9.96", "Amount", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Start of BAT0004.";
                Reports.StatusUpdate("AF2 continuation", true);

                Reports.TestStep = "Correct Bank Acct.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Correct Bank Acct");
                FastDriver.DisbursementAdjustment.CorrectBankAcctNumber.FASelectItemByIndex(4);
                Support.AreEqual("Fee Transfer", FastDriver.DisbursementAdjustment.TypeOfFunds.FAGetSelectedItem().Clean(), "TypeOfFunds");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Store the description for Currect Bank account adjustment.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                string currentBankAccountDescription = FastDriver.DisbursementAdjustment.CorrectingTransDescription.FAGetValue().Clean();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Input Error ADJ.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Description", currentBankAccountDescription, "Description", TableAction.Click);
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "9.96", "Amount", TableAction.Click);
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "F", "Description", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Input Error.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Input Error");
                FastDriver.DisbursementAdjustment.Comment.FASetText("Adjusted for Input Error");
                Support.AreEqual("Fee Transfer", FastDriver.DisbursementAdjustment.TypeOfFunds.FAGetSelectedItem().Clean(), "TypeOfFunds");
                FastDriver.DisbursementAdjustment.UpdateTrustAccounting.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Store the description for Input Error adjustment.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                string errorAdjustmentDescription = FastDriver.DisbursementAdjustment.Description.FAGetValue().Clean();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Input Error and click on Adjust.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Description", errorAdjustmentDescription, "Description", TableAction.Click);
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "FA", "Tp.", TableAction.GetText).Message.Clean();
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Repost Input error.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("REPOST");
                FastDriver.DisbursementAdjustment.UpdateTrustAccounting.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Store the description for Repost adjustment.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                string repostAdjustmentDescription = FastDriver.DisbursementAdjustment.Description.FAGetValue().Clean();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Repost and click on Adjust.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Description", repostAdjustmentDescription, "Description", TableAction.Click);
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "FA", "Description", TableAction.GetText).Message.Clean();
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Cancel.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DisbursementAdjustment.Comment.FASetText("Adjusted Cancelled");
                Support.AreEqual("Fee Transfer", FastDriver.DisbursementAdjustment.TypeOfFunds.FAGetSelectedItem().Clean(), "TypeOfFunds");
                FastDriver.DisbursementAdjustment.UpdateTrustAccounting.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Store the description for Cancel type adjustment.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                string cancelTypeAdjustmentDescription = FastDriver.DisbursementAdjustment.Description.FAGetValue().Clean();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Cancel ADJ and click on Adjust.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Description", cancelTypeAdjustmentDescription, "Description", TableAction.Click);
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "FA", "Description", TableAction.GetText).Message.Clean();
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Repost Cancel adjustment.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("REPOST");
                FastDriver.DisbursementAdjustment.UpdateTrustAccounting.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Deliver a Disbursement Adjustment Form";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Description", cancelTypeAdjustmentDescription, "Description", TableAction.Click);
                FastDriver.DisbursementHistory.Deliver.FAClick();

                Reports.TestStep = "Perform Print.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.SelectPrinter().ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Verify File Balance Summary.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                string NetIssuedAmount = FastDriver.DisbursementHistory.NetIssuedAmount.FAGetText().Clean();
                string NetAdjAmount = FastDriver.DisbursementHistory.NetAdjAmount.FAGetText().Clean();
                string NetDisbAmount = FastDriver.DisbursementHistory.NetDisbAmount.FAGetText().Clean();
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>(@"Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual(NetIssuedAmount, FastDriver.EscrowFileBalanceSummary.NetIssuedDisb.FAGetText().Clean(), "NetIssuedDisb");
                Support.AreEqual(NetAdjAmount, FastDriver.EscrowFileBalanceSummary.NetDepositAdjustment.FAGetText().Clean(), "NetDepositAdjustment");
                Support.AreEqual(NetDisbAmount, FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText().Clean(), "NetTotalDisbursements");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_BAT0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "AF3_00: Place a Hold on a Pending Fee Transfer Disbursement";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                Reports.TestStep = "Enter second fee in Title and escrow.";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Edit Pend Fee Transfer.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Hold Fee.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.HoldInformation.FAClick();
                int daysToHold = (DateTime.Today.AddDays(1).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(1).DayOfWeek.ToString() == "Sunday") ? 3 : 1;
                FastDriver.EditDisbursement.HoldFor.FASetText(daysToHold.ToString());
                FastDriver.EditDisbursement.PurposeOfHold.FASetText("Test Data for Purpose of Hold");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Held Fee.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                string status = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.GetText).Message.Clean();
                Support.AreEqual("Held", status, "Fee Transfer status");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_BAT0006()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "AF4_00: Edit Fees on a Pending Fee Transfer";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                Reports.TestStep = "Enter second fee in Title and escrow.";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Verify the amount entered in Fee entry screen.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Fee Transfer", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                FastDriver.ChangeFileStatusDlg.ConfirmStatus();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.PrintDlg.ClickCancel();

                Reports.TestStep = "Validate that system does not allow to decrease the issued fee amount (Buyer).";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                var element = FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input");
                element.Click();
                element.FASendKeys("0.50" + FAKeys.Tab);

                Reports.TestStep = "Validate the Adjust informational message.";
                string alertMessage = FastDriver.WebDriver.HandleDialogMessage().Clean();
                Support.AreEqual("Fee amount cannot be decreased if it will cause an out of balance Fee Transfer. Void or cancel disbursement to proceed with changes.", alertMessage);

                Reports.TestStep = "Validate that system does not allow to decrease the issued fee amount (Seller).";
                FastDriver.FileFees.WaitForScreenToLoad();
                element = FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input");
                element.Click();
                element.FASendKeys("0.50" + FAKeys.Tab);

                Reports.TestStep = "Validate the Adjust informational message.";
                alertMessage = FastDriver.WebDriver.HandleDialogMessage().Clean();
                Support.AreEqual("Fee amount cannot be decreased if it will cause an out of balance Fee Transfer. Void or cancel disbursement to proceed with changes.", alertMessage);

                Reports.TestStep = "Validate that the system displays a pending fee transfer for the increased amount (Buyer).";
                FastDriver.FileFees.WaitForScreenToLoad();
                element = FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input");
                element.Click();
                element.FASendKeys("10.11" + FAKeys.Tab);

                Reports.TestStep = "Validate the Adjust informational message.";
                alertMessage = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (AutoConfig.UseCDFormType)
                    Support.AreEqual("This change will update Split Fee and/or Retained amounts, and may create additional pending Split Fee Disbursements and/or Fee Transfers. Continue?", alertMessage);
                else
                    Support.AreEqual("This change will update Split Fee and/or Retained amounts, and may create additional pending Split Fee Disbursements and/or Fee Transfers, and may remove Underwriter and Agent premium splits. Continue?", alertMessage);

                Reports.TestStep = "Validate that the system displays a pending fee transfer for the increased amount (Seller).";
                FastDriver.FileFees.WaitForScreenToLoad();
                element = FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input");
                element.Click();
                element.FASendKeys("10.11" + FAKeys.Tab);

                Reports.TestStep = "Validate the Adjust informational message.";
                alertMessage = FastDriver.WebDriver.HandleDialogMessage().Clean();
                if (AutoConfig.UseCDFormType)
                    Support.AreEqual("This change will update Split Fee and/or Retained amounts, and may create additional pending Split Fee Disbursements and/or Fee Transfers. Continue?", alertMessage);
                else
                    Support.AreEqual("This change will update Split Fee and/or Retained amounts, and may create additional pending Split Fee Disbursements and/or Fee Transfers, and may remove Underwriter and Agent premium splits. Continue?", alertMessage);

                Reports.TestStep = "Verify the fee edited in Fee entry screen.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                string amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Amount", TableAction.GetText).Message.Clean();
                Support.AreEqual("15.24", amount, "Pending amount");
                amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Issued", "Amount", TableAction.GetText).Message.Clean();
                Support.AreEqual("9.96", amount, "Issued amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region REG
        [TestMethod]
        public void FMUC0061_REG0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7580_ES7581: Fee Transfer Disbursements, Net Retained Amount";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileFees.WaitForScreenToLoad();
                string totalFees = FastDriver.FileFees.TotalFees.FAGetText().Clean().Substring(1);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the fee transfer amount in active disbursement sumamry.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                string amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Amount", TableAction.GetText).Message.Clean();
                Support.AreEqual(totalFees, amount, "Pending Amount");

                Reports.TestStep = "Enter Second fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "10");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "10");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.FileFees.WaitForScreenToLoad();
                totalFees = FastDriver.FileFees.TotalFees.FAGetText().Clean().Substring(1);

                Reports.TestStep = "Verify the fee transfer amount in active disbursement sumamry.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Amount", TableAction.GetText).Message.Clean();
                Support.AreEqual(totalFees, amount, "Pending Amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_REG0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7582_ES7579_ES7580_ES7592_ES7584: Print a Fee Transfer Report, Use Fee Transfer for Escrow Owning Office,";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                Reports.TestStep = "Enter Second fee in Title and escrow.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "10");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "10");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Verify for Escrow office, Disable the manual button, Print All, Split, Click on Fee transfer.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                string payee = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Payee", TableAction.GetText).Message.Clean();
                Support.AreEqual(AutoConfig.SelectedOfficeName, payee, "Payee = Escrow Office");
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Payee", TableAction.Click);
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Manual.IsEnabled(), "Manual IsEnabled");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Print.IsEnabled(), "Print IsEnabled");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Split.IsEnabled(), "Split IsEnabled");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Wire.IsEnabled(), "Wire IsEnabled");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.PrintAll.IsEnabled(), "PrintAll IsEnabled");
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();

                Reports.TestStep = "Click on Done button.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Cancel print.";
                FastDriver.PrintDlg.ClickCancel();

                Reports.TestStep = "Validate: Re-Print a Fee Transfer Report on Demand.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                string amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Issued", "Amount", TableAction.GetText).Message.Clean();
                Support.AreEqual("24.98", amount, "Issued amount");
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                amount = FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Amount", TableAction.GetText).Message.Clean();
                Support.AreEqual("24.98", amount, "Issued amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_REG0004_05_06()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7589_ES7590_ES7584_ES7591: Void an Issued Fee Transfer Disbursement. Issue a Fee Transfer.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                Reports.TestStep = "Enter Second fee in Title and escrow.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "10");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "10");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click Fee Transfer.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();

                Reports.TestStep = "Click on Done button.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Cancel print.";
                FastDriver.PrintDlg.ClickCancel();

                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                string amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Issued", "Amount", TableAction.GetText).Message.Clean();
                Support.AreEqual("24.98", amount, "Issued amount");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Void.IsEnabled(), "Void IsEnabled");
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Issued", "Amount", TableAction.Click);
                Support.AreEqual(true, FastDriver.ActiveDisbursementSummary.Void.IsEnabled(), "Void IsEnabled");

                Reports.TestStep = "Click on void button.";
                FastDriver.ActiveDisbursementSummary.Void.FAClick();

                Reports.TestStep = "To Void Disbursement.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Reason to void the Disbursement");
                FastDriver.VoidDlg.OK.FAClick();

                Reports.TestStep = "Click on Edit button by check the amount.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Void.IsEnabled(), "Void IsEnabled");
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "24.98", "Amount", TableAction.Click);
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Void.IsEnabled(), "Void IsEnabled");
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "REG05: Chk for Disburse button disable.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.EditDisbursement.DisburseAs.IsEnabled(), "DisburseAs IsEnabled");

                Reports.TestStep = "REG06: Click on Deliver.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.Deliver.FAClick();

                Reports.TestStep = "Perform Print.";
                FastDriver.PrintDlg.SelectPrinter().Print.FAClick();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_REG0007_08_09_10()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7594: Prevent a Fee Transfer Check Disbursement | ES7595: Ability to adjust a fee transfer | ES7596_ES7600: Fee Transfer Adjustment Types,Deliver a Disbursement History report | ES7598_ES7592: Perform Preview Deliveries in Escrow File Balance Summary Screen";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                Reports.TestStep = "Enter Second fee in Title and escrow.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "10");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "10");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click Fee Transfer.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                string amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Amount", TableAction.GetText).Message.Clean();
                Support.AreEqual("24.98", amount, "Pending amount");
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();

                Reports.TestStep = "Click on Done button.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Perform print.";
                FastDriver.PrintDlg.SelectPrinter().ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Steps for REG0008";
                Reports.StatusUpdate("ES7595: Adjust a Fee Transfer Disbursement", true);

                Reports.TestStep = "Verified for issued and click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                amount = FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Amount", TableAction.GetText).Message.Clean();
                Support.AreEqual("24.98", amount, "Issued amount");
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Amount", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Steps for REG0009";
                Reports.StatusUpdate("ES7596_ES7600 Fee Transfer Adjustment Types,Deliver a Disbursement History report", true);

                Reports.TestStep = "Chk whether the Adjustment Reason is enabled";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                Support.AreEqual("Cancel Correct Bank Acct Input Error", FastDriver.DisbursementAdjustment.AdjustmentReason.FAGetText().Clean(), "AdjustmentReason options");

                Reports.TestStep = "Adjust the amount and save the data.";
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DisbursementAdjustment.Comment.FASetText("comments for adhoc adjs");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the Adjust informational message.";
                Support.AreEqual("Accounting Adjustment Form is ready for printing. Continue?", FastDriver.WebDriver.HandleDialogMessage(), "Issued amount");

                Reports.TestStep = "Perform print.";
                FastDriver.PrintDlg.SelectPrinter().ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Steps for REG0010";
                Reports.StatusUpdate("ES7598_ES7592: Perform Preview Deliveries in Escrow File Balance Summary Screen", true);

                Reports.TestStep = "Perform Preview Deliveries in Escrow File Balance Summary Screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>(@"Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                FastDriver.EscrowFileBalanceSummary.cboMethod.FASelectItem("Preview");
                FastDriver.EscrowFileBalanceSummary.btnDeliver.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_REG0011()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7585_ES7586: Edit a Fee Transfer Disbursement";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                Reports.TestStep = "Enter Second fee in Title and escrow.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "10");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "10");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Edit button by check the amount.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "24.98", "Amount", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Edit Fee Transfer Disbursement.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.EditDisbursement.DisburseAs.IsEnabled(), "DisburseAs IsEnabled");
                FastDriver.EditDisbursement.VoucherDescription.FASetText("Title and Escrow Fees Description Edited");
                FastDriver.EditDisbursement.VoucherMemo.FASetText("Voucher info edited for Title and Escrow Fees");
                Support.AreEqual(false, FastDriver.EditDisbursement.VoucherChargeDetail.IsEnabled(), "VoucherChargeDetail IsEnabled");
                FastDriver.BottomFrame.Save();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_REG0012()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7585_ES7586_ES7587_ES7588: Prevent Fee Transfer to be disbursed via Print All functionality_Prevent Disbursement Split on Fee Transfers_Edit a Fee Transfer Disbursement_Prevent Void of Pending or Held Fee Transfer Disbursement.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Validate Print all button and Void button for Prnding Fee Transfer.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.98", "Status", TableAction.Click);
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Print.IsEnabled(), "Print IsEnabled");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.PrintAll.IsEnabled(), "PrintAll IsEnabled");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Split.IsEnabled(), "Split IsEnabled");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Void.IsEnabled(), "Void IsEnabled");

                Reports.TestStep = "Verify that charge details and Reference fields are disabled for fee transfer in edit disbursement screen";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.EditDisbursement.VoucherChargeDetail.IsEnabled(), "Void IsEnabled");
                Support.AreEqual(false, FastDriver.EditDisbursement.Reference.IsEnabled(), "Void IsEnabled");

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Print all button is disabled in active disbursement when a fee transfer is selected.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.ActiveDisbursementSummary.PrintAll.IsEnabled(), "PrintAll IsEnabled");
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.Click);
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Print.IsEnabled(), "Print IsEnabled");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.PrintAll.IsEnabled(), "PrintAll IsEnabled");
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Status", TableAction.Click);
                Support.AreEqual(true, FastDriver.ActiveDisbursementSummary.Print.IsEnabled(), "Print IsEnabled");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.PrintAll.IsEnabled(), "PrintAll IsEnabled");
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Status", TableAction.Click);

                Reports.TestStep = "Validate that Fee transfer is not included in th Print checks when Print all is Clicked.";
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.PrintChecks.CheckListTable.FAGetText().Contains("4.98"), "CheckList table contains 4.98");

                Reports.TestStep = "Verify Void button for held Fee Transfer.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.HoldInformation.FAClick();
                int daysToHold = (DateTime.Today.AddDays(1).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(1).DayOfWeek.ToString() == "Sunday") ? 3 : 1;
                FastDriver.EditDisbursement.HoldFor.FASetText(daysToHold.ToString());
                FastDriver.EditDisbursement.PurposeOfHold.FASetText("Test Data for Purpose of Hold");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                string status = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.GetText).Message.Clean();
                Support.AreEqual("Held", status, "Fee Transfer status");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Void.IsEnabled(), "Void IsEnabled");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_REG0014()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7589: Addfees and Deliver it in invoiceFees page and convert it to 'Prelim'. Go to Active disbursments and do the Fee transfer. Navigate to disbursment history and click on Adjust. In Disbursement Adjustme";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Deliver Invoice after traversing to Invoice fees.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.Format.FASetCheckbox(true);
                FastDriver.InvoiceFees.Deliver.FAClick();

                Reports.TestStep = "Perform Print.";
                FastDriver.PrintDlg.SelectPrinter().ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Click on Fee Transfer Button After selection of Payee.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();

                Reports.TestStep = "Click on Done button.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Perform print.";
                FastDriver.PrintDlg.SelectPrinter().ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Click on Adjust on Issued status.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Change Adjustment Reason to Cancel.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DisbursementAdjustment.Description.FASetText("Adjusted to Cancel");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Deposit adjustment.";
                Support.AreEqual("Accounting Adjustment Form is ready for printing. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Print the checks.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickCancel();

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_REG0016()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7589_EstimatedCancel: Addfees and Deliver it in invoiceFees page and convert it to 'Prelim'. Go to Active disbursments and do the Fee transfer. Navigate to disbursment history and click on Adjust. In Disbursement";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Deliver Invoice after traversing to Invoice fees.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.Format.FASetCheckbox(true);
                FastDriver.InvoiceFees.Deliver.FAClick();

                Reports.TestStep = "Perform Print.";
                FastDriver.PrintDlg.SelectPrinter().ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Click on Fee Transfer Button After selection of Payee.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();

                Reports.TestStep = "Click on Done button.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Perform print.";
                FastDriver.PrintDlg.SelectPrinter().ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Click on Adjust on Issued status.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Change Adjustment Reason to Correct Bank Acct.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Correct Bank Acct");
                FastDriver.DisbursementAdjustment.CorrectBankAcctNumberEdit.FASelectItemByIndex(2);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Deposit adjustment.";
                Support.AreEqual("Accounting Adjustment Form is ready for printing. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Print the checks.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickCancel();

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_REG0018()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7589: Repost";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Deliver Invoice after traversing to Invoice fees.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.Format.FASetCheckbox(true);
                FastDriver.InvoiceFees.Deliver.FAClick();

                Reports.TestStep = "Perform Print.";
                FastDriver.PrintDlg.SelectPrinter().ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Click on Fee Transfer Button After selection of Payee.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();

                Reports.TestStep = "Click on Done button.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Perform print.";
                FastDriver.PrintDlg.SelectPrinter().ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                Reports.TestStep = "Click on Adjust on Issued status.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Change Adjustment Reason to Input Error.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Input Error");
                FastDriver.DisbursementAdjustment.Description.FASetText("Adjusted to Input Error");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Deposit adjustment.";
                Support.AreEqual("Accounting Adjustment Form is ready for printing. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Print the checks.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickCancel();

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verified for Description and click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                string amount = FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Description", "Adjusted to Input Error", "Amount", TableAction.GetText).Message.Clean();
                Support.AreEqual("4.98-", amount, "Adjusted amount");
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Description", "Adjusted to Input Error", "Amount", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Repost Input error.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("REPOST");
                FastDriver.DisbursementAdjustment.Comment.FASetText("Adjusted Reposted");
                FastDriver.DisbursementAdjustment.UpdateTrustAccounting.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Deposit adjustment.";
                Support.AreEqual("Accounting Adjustment Form is ready for printing. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Print the checks.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickCancel();

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_REG0020()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7589_Estimate: Estimate and Estimate Adjust";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Estimate.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 5, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummarygrid.FASetCheckbox(true);
                FastDriver.InvoiceFees.Estimate.FAClick();

                Reports.TestStep = "Validate Estimate Status.";
                Playback.Wait(1000);
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTIMATED", 5, TableAction.Click);

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement History.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.DisbursementHistory.DisbursementTable.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.DisbursementHistory.DisbursementTable.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Deselect invoice fees/Estimated.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTIMATED", 6, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummarygrid.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement history.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.DisbursementHistory.DisbursementTable.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.DisbursementHistory.DisbursementTable.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Validate Disbursement sumamry for Fee transfer after Estimate Adjusted (fee is removed).";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Det", TableAction.On);
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Lender");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("Lender");
                }
                else
                {
                    FastDriver.PaymentDetails.WaitForScreenToLoad();
                    FastDriver.PaymentDetails.selBuyPayMethod.FASelectItem("FEE");
                    FastDriver.PaymentDetails.selsellerPayMethod.FASelectItem("FEE");
                }
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate that Buyer list is present in Disbursement summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("2", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(true, FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Validate that Buyer list is present in Disbursement History.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("2", FastDriver.DisbursementHistory.DisbursementTable.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(true, FastDriver.DisbursementHistory.DisbursementTable.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_REG0022()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7589_step2_Finalcancel: Final and Final Adjust";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Set on FINAL.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(3, "4.98", 2, TableAction.Click);
                Support.AreEqual(true, FastDriver.InvoiceFees.Final.IsEnabled(), "Final IsEnabled");
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "Validate Final Status.";
                Playback.Wait(1000);
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 5, TableAction.Click);

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement History.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.DisbursementHistory.DisbursementTable.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.DisbursementHistory.DisbursementTable.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Deselect invoice fees/Estimated.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 6, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummarygrid.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement history.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.DisbursementHistory.DisbursementTable.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.DisbursementHistory.DisbursementTable.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Navigate to Invoice Fees for file event.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();

                Reports.TestStep = "Cancel an Invoice/Final.";
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINALADJ", 6, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummarygrid.FASetCheckbox(true);
                FastDriver.InvoiceFees.Cancel.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement history.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.DisbursementHistory.DisbursementTable.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.DisbursementHistory.DisbursementTable.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Validate Disbursement sumamry for Fee transfer after Final Adjusted (Fee is removed).";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Det", TableAction.On);
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Lender");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("Lender");
                }
                else
                {
                    FastDriver.PaymentDetails.WaitForScreenToLoad();
                    FastDriver.PaymentDetails.selBuyPayMethod.FASelectItem("FEE");
                    FastDriver.PaymentDetails.selsellerPayMethod.FASelectItem("FEE");
                }
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate that Buyer list is present in Disbursement summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("2", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(true, FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Validate that Buyer list is present in Disbursement History.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("2", FastDriver.DisbursementHistory.DisbursementTable.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(true, FastDriver.DisbursementHistory.DisbursementTable.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_REG0023()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7578_ES7579: Define Fee Transmittal Type_Use Fee Transfer for Escrow Owning Office";

                Reports.TestStep = "Log into FAST ADM site and make Fee Transmittal type as Check.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Office Setup screen";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                if (FastDriver.OfficeSetupOffice.FeeTransmittalType.FAGetSelectedItem().Clean() == "Fee Transfer")
                    FastDriver.OfficeSetupOffice.FeeTransmittalType.FASelectItem("Check");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST IIS site.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Verify that fund type is check for the fee entered in Active Disbursement Summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                string amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Amount", TableAction.GetText).Message.Clean();
                Support.AreEqual("4.98", amount, "Check amount");
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST ADM site and make Fee Transmittal type as Fee Transfer.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);
                FastDriver.HomePage.WaitForHomeScreen();

                Reports.TestStep = "Navigate to Office Setup screen";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                if (FastDriver.OfficeSetupOffice.FeeTransmittalType.FAGetSelectedItem().Clean() == "Check")
                    FastDriver.OfficeSetupOffice.FeeTransmittalType.FASelectItem("Fee Transfer");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST IIS site.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Search order.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Verify that fund type is Changed to Fee Transfer in Active Disbursement Summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Amount", TableAction.GetText).Message.Clean();
                Support.AreEqual("4.98", amount, "Check amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_REG0024()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7589_Fee transfer disbursement with the invoice status as Estimate Cancelled";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Verify that fund type is Changed to Fee Transfer in Active Disbursement Summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                string funds = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.98", "Funds", TableAction.GetText).Message.Clean();
                Support.AreEqual("Fee Transfer", funds, "Funds type");

                Reports.TestStep = "Navigate to Invoice Fees and Estimate.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 5, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummarygrid.FASetCheckbox(true);
                FastDriver.InvoiceFees.Estimate.FAClick();

                Reports.TestStep = "Validate Estimate Status.";
                Playback.Wait(1000);
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTIMATED", 5, TableAction.Click);

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement History.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.DisbursementHistory.DisbursementTable.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.DisbursementHistory.DisbursementTable.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Navigate to Invoice Fees and Cancel.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTIMATED", 5, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummarygrid.FASetCheckbox(true);
                FastDriver.InvoiceFees.Cancel.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate Cancel Status.";
                Playback.Wait(1000);
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "CANCELESTI", 5, TableAction.Click);

                Reports.TestStep = "Validate Disbursement sumamry for Fee transfer after Final Adjusted (Fee is removed).";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Det", TableAction.On);
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Lender");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("Lender");
                }
                else
                {
                    FastDriver.PaymentDetails.WaitForScreenToLoad();
                    FastDriver.PaymentDetails.selBuyPayMethod.FASelectItem("FEE");
                    FastDriver.PaymentDetails.selsellerPayMethod.FASelectItem("FEE");
                }
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate that Buyer list is present in Disbursement summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("2", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(true, FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Validate that Buyer list is present in Disbursement History.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("2", FastDriver.DisbursementHistory.DisbursementTable.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(true, FastDriver.DisbursementHistory.DisbursementTable.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0061_REG0025()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7589_Fee transfer disbursement with the invoice status as Final Cancelled";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Lender Policy-1", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Verify that fund type is Changed to Fee Transfer in Active Disbursement Summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                string funds = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.98", "Funds", TableAction.GetText).Message.Clean();
                Support.AreEqual("Fee Transfer", funds, "Funds type");

                Reports.TestStep = "Navigate to Invoice Fees and click Final.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "UNINVOICED", 5, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummarygrid.FASetCheckbox(true);
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "Validate Final Status.";
                Playback.Wait(1000);
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 5, TableAction.Click);

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Validate that Buyer list is not present in Disbursement History.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.DisbursementHistory.DisbursementTable.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(false, FastDriver.DisbursementHistory.DisbursementTable.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Navigate to Invoice Fees and Cancel.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 5, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummarygrid.FASetCheckbox(true);
                FastDriver.InvoiceFees.Cancel.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate Cancel Status.";
                Playback.Wait(1000);
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "CANCELFINL", 5, TableAction.Click);

                Reports.TestStep = "Validate Disbursement sumamry for Fee transfer after Final Adjusted (Fee is removed).";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Det", TableAction.On);
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Lender");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("Lender");
                }
                else
                {
                    FastDriver.PaymentDetails.WaitForScreenToLoad();
                    FastDriver.PaymentDetails.selBuyPayMethod.FASelectItem("FEE");
                    FastDriver.PaymentDetails.selsellerPayMethod.FASelectItem("FEE");
                }
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate that Buyer list is present in Disbursement summary.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("2", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(true, FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");

                Reports.TestStep = "Validate that Buyer list is present in Disbursement History.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("2", FastDriver.DisbursementHistory.DisbursementTable.GetRowCount().ToString(), "Disbursements row count");
                Support.AreEqual(true, FastDriver.DisbursementHistory.DisbursementTable.FAGetText().Contains("4.98"), "Disbursements table contains 4.98");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}