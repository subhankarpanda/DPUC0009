﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Linq;


namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0075 : MasterTestClass
    {
        #region BAT
        [TestMethod]
        public void FMUC0075_BAT0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Services = new FASTWCFHelpers.FastFileService.Service[]
                    {
                        RequestFactory.GetService("TO"),
                        RequestFactory.GetService("SEO"),
                    };
                #endregion

                Reports.TestDescription = "MF1: Issue a Check.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order with Escrow and Sub Escrow, using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Verify REB Summary and Default data on New Broker Screen.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.Exists().ToString());
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.SellerBuyerRemove.Exists().ToString());
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.Exists().ToString(), "BrokerInformationAdHoc");
                Support.AreEqual("", FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FAGetText().Clean(), "BrokerInformationGABcode");
                Support.AreEqual("", FastDriver.RealEstateBrokerAgent.BrokerContactGABName.FAGetText().Clean(), "BrokerContactGABName");
                Support.AreEqual("", FastDriver.RealEstateBrokerAgent.CreditBuyerAmount.FAGetText().Clean(), "CreditBuyerAmount");
                Support.AreEqual("", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetText().Clean(), "CommisionChargeAmountSellerCharge");
                Support.AreEqual("", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FAGetText().Clean(), "RealEstateBrokerChargesBuyerCharge");
                Support.AreEqual("", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FAGetText().Clean(), "RealEstateBrokerChargesSellerCharge");

                Reports.TestStep = "Create New Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.Exists().ToString(), "SellerBuyerEdit");
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.SellerBuyerRemove.Exists().ToString(), "SellerBuyerRemove");
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.Click();

                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText(@"Alameda");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Add Adhoc Contact.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerContactAdHoc.FAClick();

                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText(@"Alameda");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Enter Commission Amount.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"10");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Print.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Status", TableAction.GetText).Message.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PrintDlg.SelectPrinter().Print.FAClick();
                FastDriver.OverdraftConfirmationDlg.Handle();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_BAT0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                        {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                        };
                fileRequest.File.Services = new FASTWCFHelpers.FastFileService.Service[]
                        {
                        RequestFactory.GetService("TO"),
                        RequestFactory.GetService("SEO"),
                        };
                #endregion

                Reports.TestDescription = "MF2: Issue a Fee Transfer.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order with Escrow and Sub Escrow, using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                Reports.TestStep = "Navigate to Active Disb Summary and Fee amount row.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.OverdraftConfirmationDlg.Handle();

                Reports.TestStep = "Validate File status as Closed.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                Support.AreEqual("Closed", FastDriver.ChangeFileStatusDlg.FileStatus.FAGetSelectedItem().Clean());
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintDlg.SelectPrinter().Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print");

                // Changing as per the Gap analyis coverage.
                // Flow/ BR number: Main Course 2: Issue a Fee Transfer
                // Reports.TestStep = "Navigate to Disbursement History and Deliver the Issued Wire.";
                Reports.TestStep = "Highlight the issued fee and clik on View Details.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "F", "Tp.", TableAction.Click);
                FastDriver.DisbursementHistory.ViewDetails.FAClick();

                Reports.TestStep = "Verifying for the Issued Status for the Fee Transferred.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.StatusLbl);
                Support.AreEqual("ISSUED", FastDriver.EditDisbursement.StatusLbl.FAGetText().Clean());
                FastDriver.EditDisbursement.OpenDisbDetails.FAClick();
                Support.AreEqual("Fee Transfer", FastDriver.EditDisbursement.DisburseAs.FAGetSelectedItem().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Default Payee for Fee in Record Transfer Tax.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                string payeename = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Payee", TableAction.GetText).Message.Clean();
                Support.AreEqual("QA Automation Office - DO NOT TOUCH", payeename, "Default payee name");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0075_BAT0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Services = new FASTWCFHelpers.FastFileService.Service[]
                    {
                        RequestFactory.GetService("TO"),
                        RequestFactory.GetService("SEO"),
                    };
                #endregion

                Reports.TestDescription = "AF2: Issue a Wire";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order with Escrow and Sub Escrow, using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create New Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.Exists().ToString(), "SellerBuyerEdit");
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.SellerBuyerRemove.Exists().ToString(), "SellerBuyerRemove");
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.Click();

                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText(@"Alameda");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Add Adhoc Contact.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerContactAdHoc.FAClick();

                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText(@"Alameda");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Enter Commission Amount.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"10");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, retryWithAutoIT: true);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Validate for status pending.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Status", TableAction.GetText).Message.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);

                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad(FastDriver.SelectWireInstructionsDlg.Instruction1);
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.ReceivingBankABANumber);
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Select the wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);

                Reports.TestStep = "Click on Wire button.";
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();

                Reports.TestStep = "Disburse the wire.";
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                FastDriver.OverdraftConfirmationDlg.Handle();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying for the Wire Issued.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Status", TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_BAT0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Services = new FASTWCFHelpers.FastFileService.Service[]
                    {
                        RequestFactory.GetService("TO"),
                        RequestFactory.GetService("SEO"),
                    };
                #endregion

                Reports.TestDescription = "AF3: Record a Manual Check.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order with Escrow and Sub Escrow, using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create New Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.Exists().ToString(), "SellerBuyerEdit");
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.SellerBuyerRemove.Exists().ToString(), "SellerBuyerRemove");
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.Click();

                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText(@"Alameda");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Add Adhoc Contact.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerContactAdHoc.FAClick();

                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText(@"Alameda");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Enter Commission Amount.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"10");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Manual.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Status", TableAction.GetText).Message.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue Manual Check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                Support.AreEqual("Check", FastDriver.IssueManualCheck.DisburseAs.FAGetSelectedItem().Clean());
                Support.AreEqual("", FastDriver.IssueManualCheck.Reference.FAGetValue().Clean());
                string receiptNumber = Support.RandomString("NNNNNNNN");
                FastDriver.IssueManualCheck.CheckNo.FASetText(receiptNumber);
                FastDriver.BottomFrame.Save();
                FastDriver.OverdraftConfirmationDlg.Handle();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Verifying for Issued Status.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("#5", receiptNumber, "Status", TableAction.GetText).Message.Clean());

                // Date: 16-Apr-2015
                // Reason For Change: FASt Automation  - Gap Coverage
                // Description: Adding the step to verify manual check eventlog
                Reports.TestStep = "Verifying for [Manual Check] Confirmation Event in Event Tracking Log.";
                FastDriver.LeftNavigation.Navigate<EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                Playback.Wait(4000);
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.FAGetText().Contains(receiptNumber).ToString(), string.Format("EventTable text contains '{0}'", receiptNumber));
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_BAT0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Services = new FASTWCFHelpers.FastFileService.Service[]
                    {
                        RequestFactory.GetService("TO"),
                        RequestFactory.GetService("SEO"),
                    };
                #endregion

                Reports.TestDescription = "AF1: Issue all Pending Checks.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order with Escrow and Sub Escrow, using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create New Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.Exists().ToString(), "SellerBuyerEdit");
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.SellerBuyerRemove.Exists().ToString(), "SellerBuyerRemove");
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.Click();

                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText(@"Alameda");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Add Adhoc Contact.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerContactAdHoc.FAClick();

                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText(@"Alameda");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Enter Commission Amount.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"10");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Print All checks.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(); //handle SDN search dialog

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                // 21-Apr-2015
                // Adding validation as per the Gap analyis coverage.
                // Business Rule: Error / Warning Conditions 5
                // Removed from usecase - Reports.TestStep = "Validate for issuing a disbursement that is less than or equal to the total combined balance of Available Funds and Overdraft amounts.";
                FastDriver.OverdraftConfirmationDlg.Handle();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0075_BAT0006()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Services = new FASTWCFHelpers.FastFileService.Service[]
                    {
                        RequestFactory.GetService("TO"),
                        RequestFactory.GetService("SEO"),
                    };
                #endregion

                Reports.TestDescription = "AF4: Issue all Pending Wires";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order with Escrow and Sub Escrow, using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create New Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.Click();

                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText(@"Alameda");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Add Adhoc Contact.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerContactAdHoc.FAClick();

                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText(@"Alameda");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Enter Commission Amount.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"10");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create New Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAdHoc.Click();

                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText(@"Alameda");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Enter different Commission Amount.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"10");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, retryWithAutoIT: true);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Validate for status pending.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Status", TableAction.GetText).Message.Clean());
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001", "Payee", TableAction.Click);

                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad(FastDriver.SelectWireInstructionsDlg.Instruction1);
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.ReceivingBankABANumber);
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Wire button.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.WireAll.FAClick();

                Reports.TestStep = "Validate wires.";
                FastDriver.DisburseWires.WaitForScreenToLoad(FastDriver.DisburseWires.WireNumberToBeIssued);
                Support.AreEqual("1", FastDriver.DisburseWires.WireNumberToBeIssued.FAGetText().Clean(), "WireNumberToBeIssued");

                Reports.TestStep = "Disburse wires.";
                FastDriver.DisburseWires.Disburse.FAClick();
                FastDriver.OverdraftConfirmationDlg.Handle();
                FastDriver.BottomFrame.Done();

                

                Reports.TestStep = "Validate wire is issued.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "REB001 Albany,CA", "Status", TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_BAT0007()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "NEWLDR"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                            RoleTypeObjectCD = "DIRECTEDBY"
                        },
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                            RoleTypeObjectCD = "ASSOTDPTY"
                        }
                    };
                #endregion

                Reports.TestDescription = "AF5: Issue IBA Disbursements.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Deposit a cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(new DepositParameters { Amount = 10.00, TypeofFunds = "Cash", Representing = "Additional Closing Costs", Description = "Sanity Deposit In Escrow", ReceivedFrom = "Buyer" });
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel Button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Add the other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.AddOtherBeneficiary(new IBABeneficiary { BeneficiaryName = "Beneficiary TFS_104161", AddressLine1 = "Address Line 1", AddressLine2 = "Address Line 2", City = "Santa Ana", State = "CA", ZipCode = "92727", selectSSN = true, SSNTINnumber = "123456789" });

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter IBA Bank Account. Let the default account be selected.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.IBABank);
                FastDriver.InterestBearingAccounts.IBABank.FAClick();
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select a IBA product if it is empty.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.IBAType);
                FastDriver.InterestBearingAccounts.IBAType.FASelectItemByIndex(1);

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.Transactions.FAClick();
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Print All checks.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "IBA", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "IBA# fbo Beneficiary TFS_104161", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintDlg.SelectPrinter();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.PasswordConfirmationDlg.Handle();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region REG
        [TestMethod]
        public void FMUC0075_REG0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES9897_FM2484_FM4055: Issue Pending disbursements/change status to Issued/Change File Status & Fee Date";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                // 20-Apr-2015
                // Adding the validation as per the Gap analyis coverage.
                // Business Rule: ES9897  Issue Pending disbursements
                Reports.TestStep = "Validate that print button is in disabled state";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.Print.IsEnabled().ToString(), "Print IsEnabled");

                // 20-Apr-2015
                // Adding the validation as per the Gap analyis coverage.
                // Business Rule: ES9897  Issue Pending disbursements
                Reports.TestStep = "Add Home warranty charges to validate that the system shall not allow disbursement when active disbursement is in Created status .";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on split button.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();

                Reports.TestStep = "Enter amount to split and saves changes made.";
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionPercentage.FASetText("60" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab + FAKeys.Tab);
                FastDriver.SplitDisbursement.SplitDistributionPercentage1.FASetText("40" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate Print button for disbursement in created and pending state.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.Print.IsEnabled().ToString(), "Print IsEnabled");

                Reports.TestStep = "Validate that Fee Transfer button is in enabled state and Click on Fee Transfer Button.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                // Business Rule: ES9897  Issue Pending disbursements
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.FeeTransfer.IsEnabled().ToString(), "FeeTransfer IsEnabled");
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.OverdraftConfirmationDlg.Handle();

                Reports.TestStep = "Validate File status as Closed.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                Support.AreEqual("Closed", FastDriver.ChangeFileStatusDlg.FileStatus.FAGetSelectedItem().Clean(), "FileStatus SelectedItem");
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();

                Reports.TestStep = "Validate Fee transfer after issue the checks.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.FeeTransfer.IsEnabled().ToString(), "FeeTransfer IsEnabled");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Changed File status in TDS screen.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem().Clean(), "Status SelectedItem");
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.ToPST().ToDateString());

                Reports.TestStep = "Click on Void Button.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Void.FAClick();

                Reports.TestStep = "To Void Disbursement.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Reason to void the Disbursement");
                FastDriver.VoidDlg.OK.FAClick();

                Reports.TestStep = "Click on Fee Transfer Button.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.OverdraftConfirmationDlg.Handle();

                Reports.TestStep = "Change File status and Fee date.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.ChangeFileStatusDlg.FileStatus.FASelectItem("Open");
                FastDriver.ChangeFileStatusDlg.FeeDate.FASetText("09-26-2012");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();

                Reports.TestStep = "Validate Changed File status in TDS screen.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem().Clean(), "Status SelectedItem");
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.AddHours(-13).ToDateString());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                #endregion

                Reports.TestDescription = "FM4075: File Default Status";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Fee Transfer Button.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.OverdraftConfirmationDlg.Handle();

                Reports.TestStep = "Change File status and Fee date.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.ChangeFileStatusDlg.FileStatus.FASelectItem("Cancelled");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Print the checks.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();

                Reports.TestStep = "Validate Changed File status in TDS screen.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Cancelled", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem().Clean(), "Status SelectedItem");
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.ToPST().ToDateString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Void Button.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Void.FAClick();

                Reports.TestStep = "To Void Disbursement.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Reason to void the Disbursement");
                FastDriver.VoidDlg.OK.FAClick();

                Reports.TestStep = "Click on Fee Transfer Button.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.OverdraftConfirmationDlg.Handle();

                Reports.TestStep = "Change File status and Fee date.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.ChangeFileStatusDlg.FileStatus.FASelectItem("Open In Error");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Print the checks.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();

                Reports.TestStep = "Validate Changed File status in TDS screen.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("Open In Error", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem().Clean(), "Status SelectedItem");
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Now.ToPST().ToDateString());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0075_REG0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES9898_FM2484_FM2483_ES7621_FM2888: Issue All Disbursements/change status to Issued/Mark disb as Issued/Issue Wire/Record exceptions as events";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Add a Lease charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("LEASE");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                //// Adding the SDN validations as per the Gap analyis coverage.
                //// Business Rule: ES14473  Check SDN Search Status of Payee Before Issuing Disbursements 
                ////                ES14474  Display Warning When Payee Not Searched
                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, retryWithAutoIT: true);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                    return true; //if it gets to this part, the documents table is visible and we can continue
                }, timeout: 120);

                Reports.TestStep = "Click Edit on Created Status.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Disburse All.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();

                Reports.TestStep = "Issue The Wires.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.IssueDisbursements.Disburse.FAClick();

                Reports.TestStep = "Perform Print.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.SelectPrinter().Print.FAClick();
                FastDriver.PasswordConfirmationDlg.Handle();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print);

                Reports.TestStep = "Click on Done.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Issued Wire transfers.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Status", TableAction.GetText).Message.Clean());

                Reports.TestStep = "Verify Issued Check transfers.";
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Status", TableAction.GetText).Message.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying for Exception cases in Event Tracking Log.";
                FastDriver.LeftNavigation.Navigate<EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                Playback.Wait(4000);
                Support.AreEqual("QA07, FAST", FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Wire]", "Source", TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                #endregion

                Reports.TestDescription = "FM944_FM945_FM946_FM1991: Verify available funds/Compute excess funds/Overdraft notification/Event for overdraft.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "25.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "29.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify available and excess funds.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.ExcessFunds.IsDisplayed().ToString(), "ExcessFunds IsDisplayed");
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.TotalFundsAvailable.IsDisplayed().ToString(), "TotalFundsAvailable IsDisplayed");
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.PendingFunds.IsDisplayed().ToString(), "PendingFunds IsDisplayed");
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.HeldFunds.IsDisplayed().ToString(), "HeldFunds IsDisplayed");

                Reports.TestStep = "Click on Pend status to Disburse.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                // 21-Apr-2015
                // Adding validation as per the Gap analyis coverage.
                // Business Rule: Error / Warning Conditions 4
                Reports.TestStep = "Validate that password is required for Disbursement whose Amount exceeds available funds";
                FastDriver.PasswordConfirmationDlg.Handle();

                Reports.TestStep = "Click on Cancel.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();

                Reports.TestStep = "Verifying for [Overdraft] Confirmation Event in Event Tracking Log.";
                FastDriver.LeftNavigation.Navigate<EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                Playback.Wait(4000);
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Overdraft]", "Event", TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                #endregion

                Reports.TestDescription = "FM1771_FM1772_FM2028_FM1992_FM2484_EWC3: Manually issue disbursement /Record manual check/Event for manual check/change status to Issued";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Manually issue disbursement.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue Manual Check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                Support.AreEqual("Check", FastDriver.IssueManualCheck.DisburseAs.FAGetSelectedItem().Clean(), "DisburseAs SelectedItem");
                Support.AreEqual("", FastDriver.IssueManualCheck.Reference.FAGetValue().Clean(), "Reference");
                string checkNo = Support.RandomString("NNNNNNNN");
                FastDriver.IssueManualCheck.CheckNo.FASetText(checkNo);
                FastDriver.BottomFrame.Save();
                FastDriver.PasswordConfirmationDlg.Handle();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying for [Manual Check] Confirmation Event in Event Tracking Log.";
                FastDriver.LeftNavigation.Navigate<EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                Playback.Wait(4000);
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Manual Check]", "Comments", TableAction.GetText).Message.Contains(checkNo).ToString(), "Manual Check comments contain CheckNo");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0006()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                #endregion

                Reports.TestDescription = "FM2028_EWC4: Number must be unique";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Manually issue disbursement.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue Manual Check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                Support.AreEqual("Check", FastDriver.IssueManualCheck.DisburseAs.FAGetSelectedItem().Clean(), "DisburseAs SelectedItem");
                Support.AreEqual("", FastDriver.IssueManualCheck.Reference.FAGetValue().Clean(), "Reference");
                string checkNo = Support.RandomString("NNNNNNNN");
                FastDriver.IssueManualCheck.CheckNo.FASetText(checkNo);
                FastDriver.BottomFrame.Save();
                FastDriver.PasswordConfirmationDlg.Handle();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a Lease charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("LEASE");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Manually issue disbursement.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue Manual Check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                Support.AreEqual("Check", FastDriver.IssueManualCheck.DisburseAs.FAGetSelectedItem().Clean(), "DisburseAs SelectedItem");
                Support.AreEqual("", FastDriver.IssueManualCheck.Reference.FAGetValue().Clean(), "Reference");
                FastDriver.IssueManualCheck.CheckNo.FASetText(checkNo);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate for Document Number already exists within this Bank Account and Office";
                Support.AreEqual("Check number " + checkNo.ToString() + " already exists within this Bank Account and Office. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.OverdraftConfirmationDlg.Handle();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify for [Duplicate Manual Check] Confirmation Event in Event Track Log.";
                FastDriver.LeftNavigation.Navigate<EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Accounting/Privacy");
                Playback.Wait(4000);
                Support.AreEqual("True", FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Duplicate Manual Check Number]", "Comments", TableAction.GetText).Message.Contains(checkNo).ToString(), "Duplicate Manual Check Number comments contain CheckNo");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0007_8_9()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES9733: Pre-requisite: Issue a pending check from an inactive bank account";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Navigate to Office Setup screen";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                FastDriver.OfficeSetupBankAccounts.BankAccountsMenu.FAClick();
                FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
                FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction("Account Desc.", "Description for account", "Account Desc.", TableAction.Click);
                string accountNumber = FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction("Account Desc.", "Description for account", "Account Number", TableAction.GetText).Message.Clean();
                string accountStatus = FastDriver.OfficeSetupBankAccounts.BankStatus.FAGetText().Clean();
                Reports.StatusUpdate("Bank account status: " + accountStatus, true);
                Reports.StatusUpdate("Bank account number: " + accountNumber, true);
                if (accountStatus == "Active")
                {
                    Reports.TestStep = "View Change Bank Account Status.";
                    FastDriver.OfficeSetupBankAccounts.ViewChangeStatus.FAClick();

                    Reports.TestStep = "Change the Status to Deactivate.";
                    FastDriver.StatusEdit.WaitForScreenToLoad();
                    FastDriver.StatusEdit.Comments.FASetText("deactivated the bank account");
                    FastDriver.StatusEdit.Deactivate.FAClick();

                    Reports.TestStep = "Click on Ok button.";
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                    Reports.TestStep = "Click on Ok button.";
                    FastDriver.WebDriver.HandleDialogMessage();

                    Reports.TestStep = "Click On Done.";
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Verify Bank Status changed to InActive.";
                    FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad(FastDriver.OfficeSetupBankAccounts.BankAccountsMenu);
                    FastDriver.OfficeSetupBankAccounts.BankAccountsMenu.FAClick();
                    FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad(FastDriver.OfficeSetupBankAccounts.BanksTable);
                    FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction("Account Desc.", "Description for account", "Account Desc.", TableAction.Click);
                    Support.AreEqual("InActive", FastDriver.OfficeSetupBankAccounts.BankStatus.FAGetText().Clean(), "BankStatus");
                    FastDriver.BottomFrame.Done();
                }
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Issue a pending check from an inactive bank account.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreNotEqual(accountNumber, FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem().Clean(), "FromAccount");

                Reports.TestStep = "Click on Disburse All.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();

                Reports.TestStep = "Issue The Wires.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.IssueDisbursements.Disburse.FAClick();

                Reports.TestStep = "Perform Print.";
                FastDriver.PrintDlg.SelectPrinter().Print.FAClick();
                FastDriver.PasswordConfirmationDlg.Handle();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print");

                Reports.TestStep = "Click on Done.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Issued Check transfers.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Status", TableAction.GetText).Message.Clean(), "Check status");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0010_11()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES12586_FM2254: Pending Check Disbursement Split/Split disb must crossfoot; FM2644_FM2645: Track issue of split disb/Event for issue of split disb";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Add another Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW2");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("10.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on split button.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();

                Reports.TestStep = "Enter amount to split and saves changes made.";
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("2998.20" + FAKeys.Tab);

                Reports.TestStep = "Total of split amount cannot be greater than master amount.";
                Support.AreEqual("Total of split amount cannot be greater than master amount.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter amount to split and saves changes made.";
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                // 22-Apr-2015 Adding as per the Gap analyis coverage.
                // Business Rule: FM2254  Split disb must crossfoot*
                FastDriver.SplitDisbursement.SplitDistributionPercentage.FASetText("33" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab + FAKeys.Tab);
                FastDriver.SplitDisbursement.SplitDistributionPercentage1.FASetText("67" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);
                Support.AreEqual("0.00", FastDriver.SplitDisbursement.AmountRemaining.FAGetText().Clean());
                FastDriver.SplitDisbursement.SplitDistributionPercentage.FASetText("" + FAKeys.Tab + FAKeys.Tab);
                FastDriver.SplitDisbursement.SplitDistributionPercentage1.FASetText("" + FAKeys.Tab);
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("6.00" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab + FAKeys.Tab);
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FASetText("4.00" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete);
                FastDriver.BottomFrame.Save();

                // 20-Apr-2015 Adding the validation as per the Gap analyis coverage.
                // Business Rule: 17.0  ES12586  Pending Check Disbursement Split 
                Reports.TestStep = "Validating the payee name for duplicate checks after split.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("HW2 name 1 HW2 name 2", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Split", "Payee", TableAction.GetText).Message.Clean(), "Split payee");
                Support.AreEqual("HW2 name 1 HW2 name 2", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Payee", TableAction.GetText).Message.Clean(), "Pending payee");

                Reports.TestStep = "Click Edit on Created Status.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Edit payee name for split disbursements.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisbursementPayee1.FASetText("Testing Payee");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate payees added in split disbursement.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Testing Payee", "Status", TableAction.GetText).Message.Clean(), "Testing Payee status");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM2644_FM2645: Track issue of split disb/Event for issue of split disb.";
                Reports.StatusUpdate("FM2644_FM2645: Track issue of split disb/Event for issue of split disb", true);

                Reports.TestStep = "Click on Disburse All.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();

                Reports.TestStep = "Issue The Wires.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.IssueDisbursements.Disburse.FAClick();

                Reports.TestStep = "Perform Print.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.SelectPrinter().Print.FAClick();
                FastDriver.OverdraftConfirmationDlg.Handle();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print");

                Reports.TestStep = "Click on Done.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying for [Split Issued] Confirmation Event in Event Tracking Log.";
                FastDriver.LeftNavigation.Navigate<EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                Playback.Wait(4000);
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Split Issued]", "Event", TableAction.Click);

                //Add below steps to cover the bug id: 849954
                string commentMsg = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Print]", "Comments", TableAction.GetText).Message;
                Support.AreEqual(true, commentMsg.Contains("Documents: Disbursement Checks (4-part)"), "Verifying the Print check event through the disburseall");
                Support.AreEqual(true, commentMsg.Contains("Delivery Method: Print"), "Verifying the Print check event through the disburseall");
                Support.AreEqual(true, commentMsg.Contains("Delivery Status: Delivery Successful"), "Verifying the Print check event through the disburseall");
                //
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0012()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                #endregion

                Reports.TestDescription = "FM2255: Cannot print if out of balance";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Add another Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW2");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("10.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("20.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on split button.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();

                Reports.TestStep = "Enter amount to split and saves changes made.";
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("17.00" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab + FAKeys.Tab);
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FASetText("13.00" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Add charges to Home warranty charge.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Print after the disbursement is out of balance.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.Print.IsEnabled().ToString(), "Print IsEnabled");
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.PrintAll.IsEnabled().ToString(), "PrintAll IsEnabled");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0013()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Services = new FASTWCFHelpers.FastFileService.Service[]
                    {
                        RequestFactory.GetService("TO"),
                        RequestFactory.GetService("SEO"),
                    };
                #endregion

                Reports.TestDescription = "ES7605_ES7612: Use Title Owning Office Disbursement Accounts/Use Title Owning Office as Fee Disbursement Payee";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order with Escrow and Sub Escrow, using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate payee name.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.98", "Payee", TableAction.Click);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Title FileHomepagee Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Done();
                FastDriver.WarningDlg.WaitForScreenToLoad().Yes.FAClick();

                Reports.TestStep = "Click on Disburse All.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();

                Reports.TestStep = "Issue The Wires.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.IssueDisbursements.Disburse.FAClick();

                Reports.TestStep = "Perform Print.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.SelectPrinter().Print.FAClick();
                FastDriver.OverdraftConfirmationDlg.Handle();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print");

                Reports.TestStep = "Click on Done.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Issued Check transfers.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Status", TableAction.GetText).Message.Clean(), "Check status");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0014()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Services = new FASTWCFHelpers.FastFileService.Service[]
                    {
                        RequestFactory.GetService("EO"),
                        RequestFactory.GetService("SEO"),
                    };
                #endregion

                Reports.TestDescription = "ES7607_ES7612: Use Escrow Owning Office Disbursement Accounts/Use Escrow Owning Office as Fee Disbursement Payee";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order with Escrow and Sub Escrow, using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate payee name.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.98", "Payee", TableAction.Click);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow FileHomepagee Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Done();
                FastDriver.WarningDlg.WaitForScreenToLoad().Yes.FAClick();

                Reports.TestStep = "Click on Disburse All.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();

                Reports.TestStep = "Issue The Wires.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.IssueDisbursements.Disburse.FAClick();

                Reports.TestStep = "Perform Print.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.SelectPrinter().Print.FAClick();
                FastDriver.OverdraftConfirmationDlg.Handle();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print");

                Reports.TestStep = "Click on Done.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Issued Check transfers.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Status", TableAction.GetText).Message.Clean(), "Check status");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0015()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Services = new FASTWCFHelpers.FastFileService.Service[]
                    {
                        RequestFactory.GetService("TO"),
                    };
                #endregion

                Reports.TestDescription = "ES7608: Disable Disbursements for Title Only Files";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create an order with Escrow and Sub Escrow, using the Web Service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate payee name.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.98", "Payee", TableAction.Click);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Title FileHomepagee Own Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItem("JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Done();
                FastDriver.WarningDlg.WaitForScreenToLoad().Yes.FAClick();

                Reports.TestStep = "Validate payee name.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("JVR Company JVR Official Company name Li", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.98", "Payee", TableAction.GetText).Message.Clean(), "Payee");

                Reports.TestStep = "Click on Disburse All.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(timeout: 15);

                Reports.TestStep = "Validate Error for Escrow Disb Accounts.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.WebDriver.FAFindElement(ByLocator.Id, "__FAFErrorMessageList").IsDisplayed().ToString(), "Error message is displayed (see screenshot)");
                Support.AreEqual("1", FastDriver.IssueDisbursements.Table.GetRowCount().ToString(), "Table row count");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0016()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES7609: Debit Disbursements from File Receipts";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Deposit cash in Other.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.Deposit(new DepositParameters { Amount = 10000.00, TypeofFunds = "Cash", Representing = "Additional Closing Costs", Description = "Sanity Deposit In Escrow", ReceivedFrom = "Other", Payor = "TestOtherName" });
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Validate Deposits in other.";
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Support.AreEqual("10,000.00", FastDriver.DepositInEscrow.TotalDeposits.FAGetText().Clean(), "TotalDeposits");
                Support.AreEqual("0.00", FastDriver.DepositInEscrow.BuyerDeposits.FAGetText().Clean(), "BuyerDeposits");
                Support.AreEqual("0.00", FastDriver.DepositInEscrow.SellerDeposits.FAGetText().Clean(), "SellerDeposits");
                Support.AreEqual("10,000.00", FastDriver.DepositInEscrow.OtherDeposits.FAGetText().Clean(), "OtherDeposits");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0017()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                #endregion

                Reports.TestDescription = "ES10057: IBA Disbursements";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Deposit cash in Other.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.Deposit(new DepositParameters { Amount = 10000.00, TypeofFunds = "Cash", Representing = "Additional Closing Costs", Description = "Sanity Deposit In Escrow", ReceivedFrom = "Other", Payor = "TestOtherName" });
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";
                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>(@"Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Beneficiary);
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.AddOtherBeneficiary(new IBABeneficiary { BeneficiaryName = "Beneficiary Name1", AddressLine1 = "Address Line 1", AddressLine2 = "Address Line 2", City = "Santa Ana", State = "CA", ZipCode = "92727", selectSSN = true, SSNTINnumber = "123456789" });

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to IBA screen and selecting the IBA Bank.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();

                Reports.TestStep = "Select the IBA Bank.";
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABankDlg.SelectAutomatedBankAccount.FASetCheckbox(true);
                FastDriver.SelectIBABankDlg.IBABanks.FASelectItem("First American Trust, FSB");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.Transactions.FAClick();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.TransactionAmount);
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify Void Edit and Split button is disabled.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "IBA", "Status", TableAction.GetText).Message.Clean(), "IBA status");
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "IBA", "Status", TableAction.Click);
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.Edit.IsEnabled().ToString(), "Edit");
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.Split.IsEnabled().ToString(), "Split");
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.Void.IsEnabled().ToString(), "Void");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0018_19()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "ES9237_ES9238: Exchange Company Disbursements_Show Exchange Company as Wire Beneficiary";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create Buyer with Exchange Company.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Individual");
                Playback.Wait(500); //wait for async ajax UI refresh
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(FastDriver.BuyerSellerSetup.IndividualFirstName);
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Buyer1FN");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.GABcode.FASetText("EXCH01");
                FastDriver.ExchangeCompany.Find.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deposit cash in Buyer.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.Deposit(new DepositParameters { Amount = 20.00, TypeofFunds = "Cash", Representing = "Refund From Lender", Description = "Refund From Lender", ReceivedFrom = "Buyer" });
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Verify Exchange Company Disbursements for Buyer.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Exchange Company1 Name 1 Exchange Compan", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.GetText).Message.Clean(), "Payee name");

                Reports.TestStep = "Create Seller with Exchange Company.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(FastDriver.BuyerSellerSetup.IndividualFirstName);
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Seller First Name");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.GABcode.FASetText("EXCH01");
                FastDriver.ExchangeCompany.Find.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deposit cash in Seller.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.Deposit(new DepositParameters { Amount = 10.00, TypeofFunds = "Cash", Representing = "Loan Proceeds", Description = "Loan Proceeds", ReceivedFrom = "Seller" });
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Verify Exchange Company Disbursements for Seller.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Exchange Company1 Name 1 Exchange Compan", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "10.00", "Payee", TableAction.GetText).Message.Clean(), "Payee name");

                Reports.TestStep = "ES9238: Show Exchange Company as Wire Beneficiary";
                Reports.StatusUpdate("ES9238: Show Exchange Company as Wire Beneficiary", true);

                Reports.TestStep = "Click on Edit for Wire disbursement.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify Exchange Company Wire Disbursements for Buyer.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Exchange Company1 Name 1 Exchange Compan", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Payee", TableAction.GetText).Message.Clean(), "Payee name");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0020_21()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "ES9239: Add Exchange Company's Wire Information to Wire Disbursement";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for GAB and click on Edit.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityID.FASetText("EXCH01");
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.AddressBookSearch.WaitForScreenToLoad(FastDriver.AddressBookSearch.SearchResults);
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(7, "EXCH01", 7, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();

                Reports.TestStep = "Editing Wire details in exchange company.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.WireABANum.FASetText("123456");
                FastDriver.BusPartyOrgSetUp.WireBankName.FASetText("TestingBank");
                FastDriver.BusPartyOrgSetUp.WireBankAddr.FASetText("Test Bank Address1");
                FastDriver.BusPartyOrgSetUp.WireAccountNum.FASetText("987654321");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create Buyer with Exchange Company.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Individual");
                Playback.Wait(500); //wait for async ajax UI refresh
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(FastDriver.BuyerSellerSetup.IndividualFirstName);
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Buyer1FN");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.GABcode.FASetText("EXCH01");
                FastDriver.ExchangeCompany.Find.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deposit cash in Buyer.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.Deposit(new DepositParameters { Amount = 20.00, TypeofFunds = "Cash", Representing = "Refund From Lender", Description = "Refund From Lender", ReceivedFrom = "Buyer" });
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Click on Edit for Wire disbursement.";
                Reports.TestStep = "Click on Edit for Wire disbursement.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "20.00", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verify Wire details on Edit Disb screen.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                Support.AreEqual("Wire", FastDriver.EditDisbursement.DisburseAs.FAGetSelectedItem().Clean(), "DisburseAs");
                Support.AreEqual("123456", FastDriver.EditDisbursement.ReceivingBankABANumber.FAGetValue().Clean(), "ReceivingBankABANumber");
                Support.AreEqual("TestingBank", FastDriver.EditDisbursement.ReceivingBankName.FAGetText().Clean(), "ReceivingBankName");
                Support.AreEqual("Test Bank Address1", FastDriver.EditDisbursement.ReceivingBankAddress.FAGetText().Clean(), "ReceivingBankAddress");
                Support.AreEqual("987654321", FastDriver.EditDisbursement.BeneficiaryAccountNumber.FAGetValue().Clean(), "BeneficiaryAccountNumber");

                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0075_REG0022_23_24()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var credentialsApproval = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "ES7622: Wire Status";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, retryWithAutoIT: true);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Click Edit on Created Status.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentialsApproval, true);

                Reports.TestStep = "Open file.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click edit on Pend Wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "HW name 1 HW name 2", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Wire Instruction Image.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Image.FAClick();
                Playback.Wait(2000);
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                FastDriver.WebDriver.FAFindElements(ByLocator.CssSelector, "button.ui-dialog-titlebar-close").GetAllVisible().First().FAClick();

                Reports.TestStep = "Approve Document repository for wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Approve1.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Issued check.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                string doc = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 4, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Select Wire Record and Click on Wire button.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();

                Reports.TestStep = "Disburse Wires.";
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                FastDriver.PasswordConfirmationDlg.Handle();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Confirm Approval status.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>(@"Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(DateTime.Today.AddDays(-1).ToDateString(slash: true));
                FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(DateTime.Today.AddDays(1).ToDateString(slash: true));
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("All Accounts");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();

                Reports.TestStep = "Click on Transmit.";
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad(FastDriver.WireDisbursementApproval.WireDisbursementTable);
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(3, fileNumber, 1, TableAction.On);
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(3, fileNumber, 3, TableAction.Click);
                FastDriver.WireDisbursementApproval.Transmit.FAClick();

                Reports.TestStep = "Find all Transmitted wires.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementSummary>(@"Home>Business Unit Processing>Wire Interface>Outgoing Wire-Summary").WaitForScreenToLoad();
                FastDriver.WireDisbursementSummary.BankAccounts.FASelectItem("All Accounts");
                FastDriver.WireDisbursementSummary.Status.FASelectItem("All");
                string status = "";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.WireDisbursementSummary.FindNow.FAClick();

                    Reports.TestStep = "Verify wire status = Transmitted.";
                    FastDriver.WireDisbursementSummary.WaitForScreenToLoad(FastDriver.WireDisbursementSummary.OutGoingWireTable);
                    status = FastDriver.WireDisbursementSummary.OutGoingWireTable.PerformTableAction(1, fileNumber, 3, TableAction.GetText).Message.Clean();
                    return status != "Pending";
                }, timeout: 120, idleInterval: 15);
                Support.AreEqual("Transmitted", status, "Wire status"); //if status changed, confirm new status = transmitted
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0075_REG0025_26_27_28()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var credentialsApproval = new Credentials() { UserName = AutoConfig.UserNameSecondary, Password = AutoConfig.UserPasswordSecondary };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "ES7622_ES7623: Wire Status: Wire Disbursements";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, retryWithAutoIT: true);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Click Edit on Created Status.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                //REG0026
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentialsApproval, true);

                Reports.TestStep = "Open file.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click edit on Pend Wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "HW name 1 HW name 2", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Wire Instruction Image.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Image.FAClick();
                Playback.Wait(2000);
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                FastDriver.WebDriver.FAFindElements(ByLocator.CssSelector, "button.ui-dialog-titlebar-close").GetAllVisible().First().FAClick();

                Reports.TestStep = "Approve Document repository for wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Approve1.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                //REG0027
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Open file.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click on Wire Button.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();

                Reports.TestStep = "Disburse the wire.";
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                FastDriver.PasswordConfirmationDlg.Handle();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying for the Wire Issued.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Status", TableAction.GetText).Message.Clean());
                FastDriver.WebDriver.Quit();

                //REG0028
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentialsApproval, true);

                Reports.TestStep = "Enter file number, select QA Automation Region and click on Find now button.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Outgoing Wire Approval Screen.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>(@"Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();

                Reports.TestStep = "Click on View Details.";
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("All Accounts");
                FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(DateTime.Today.AddDays(-1).ToDateString(slash: true));
                FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(DateTime.Today.AddDays(1).ToDateString(slash: true));
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad(FastDriver.WireDisbursementApproval.WireDisbursementTable);
                FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction(3, fileNumber, 1, TableAction.On);
                FastDriver.WireDisbursementApproval.ViewDetails.FAClick();

                Reports.TestStep = "Click On Image.";
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                FastDriver.IssueWireDisbursement.Image.FAClick();
                Playback.Wait(2000);
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                FastDriver.WebDriver.FAFindElements(ByLocator.CssSelector, "button.ui-dialog-titlebar-close").GetAllVisible().First().FAClick();

                Reports.TestStep = "Check on Rejected.";
                FastDriver.IssueWireDisbursement.WaitForScreenToLoad();
                FastDriver.IssueWireDisbursement.Rejected.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Search for the record and verify for Rejected Status.";
                FastDriver.LeftNavigation.Navigate<WireDisbursementApproval>(@"Home>Business Unit Processing>Wire Interface>Outgoing Wire-Approval").WaitForScreenToLoad();
                FastDriver.WireDisbursementApproval.IssueDateFrom.FASetText(DateTime.Today.ToDateString(slash: true));
                FastDriver.WireDisbursementApproval.IssueDateTo.FASetText(DateTime.Today.ToDateString(slash: true));
                FastDriver.WireDisbursementApproval.BankAccounts.FASelectItem("All Accounts");
                FastDriver.WireDisbursementApproval.FindNow.FAClick();
                FastDriver.WireDisbursementApproval.WaitForScreenToLoad(FastDriver.WireDisbursementApproval.WireDisbursementTable);
                string status = FastDriver.WireDisbursementApproval.WireDisbursementTable.PerformTableAction("#3", fileNumber, "Status", TableAction.GetText).Message.Clean();
                Support.AreEqual("Rejected", status, "Wire status");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0029()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "EWC5_FM2886_FM2887: User tries to issue a disbursement that is less than or equal to the total combined balance of Available Funds and Overdraft amounts/Audit trail for disbursements/History as normal audit trail";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Manually issue disbursement.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue Manual Check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                Support.AreEqual("Check", FastDriver.IssueManualCheck.DisburseAs.FAGetSelectedItem().Clean(), "DisburseAs SelectedItem");
                Support.AreEqual("", FastDriver.IssueManualCheck.Reference.FAGetValue().Clean(), "Reference");
                string checkNo = Support.RandomString("NNNNNNNN");
                FastDriver.IssueManualCheck.CheckNo.FASetText(checkNo);
                FastDriver.BottomFrame.Save();
                FastDriver.PasswordConfirmationDlg.Handle();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Issued check.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                string docNumberInSummary = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 5, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Validate the Issued Check in Disbursement History.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>(@"Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                string docNumberInHistory = FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, 5, TableAction.GetText).Message.Clean();
                Support.AreEqual(docNumberInSummary, docNumberInHistory, "Doc number");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0030()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "FD_EWC2: Manually entered check number is detected as a duplicate within the bank account and office.  Evaluated upon saving the recording of a manual check.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Manually issue disbursement.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Validate Check Number and Issue date field with lower boundary.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.CheckNo.FASetText("210821088");
                Support.AreEqual("210821088", FastDriver.IssueManualCheck.CheckNo.FAGetValue().Clean(), "CheckNo");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PasswordConfirmationDlg.Handle();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a Lease charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("LEASE");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Manually issue disbursement.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Validate Check Number and Issue date field with exact value.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.CheckNo.FASetText("2108210882");
                Support.AreEqual("2108210882", FastDriver.IssueManualCheck.CheckNo.FAGetValue().Clean(), "CheckNo");
                FastDriver.IssueManualCheck.IssueDate.FASetText("10-04-2012");
                Support.AreEqual("10-04-2012", FastDriver.IssueManualCheck.IssueDate.FAGetValue().Clean(), "IssueDate");
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Check number 2108210882 already exists within this Bank Account and Office. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.OverdraftConfirmationDlg.Handle();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create a new Utility instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText("Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText("50.00");

                Reports.TestStep = "Manually issue disbursement.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Validate Check Number and Issue date field with upper boundary.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.CheckNo.FASetText("21082108821");
                Support.AreEqual("2108210882", FastDriver.IssueManualCheck.CheckNo.FAGetValue().Clean(), "CheckNo");
                FastDriver.IssueManualCheck.IssueDate.FASetText("10-04-20121");
                Support.AreEqual("10-04-2012", FastDriver.IssueManualCheck.IssueDate.FAGetValue().Clean(), "IssueDate");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Manually entered check number is detected as a duplicate within the bank account and office. Evaluated upon save the record of a manual check.";
                Support.AreEqual("True", System.Text.RegularExpressions.Regex.IsMatch(FastDriver.WebDriver.HandleDialogMessage().Clean(), "Check number [0-9]* already exists within this Bank Account and Office. Continue?").ToString(), "CheckNo in error message");
                FastDriver.PasswordConfirmationDlg.Handle();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0031()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "FD: Field Definitions for Wire details section";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verifying Field definitions in Wire details.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                Support.AreEqual("Wire", FastDriver.EditDisbursement.DisburseAs.FAGetSelectedItem().Clean(), "DisburseAs");
                FastDriver.EditDisbursement.OriginatorInformation.FASetText("");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("");
                FastDriver.EditDisbursement.BeneficiaryAddress.FASetText("");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("");

                Reports.TestStep = "Validate Fields with lower boundary.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.OriginatorInformation.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrst");
                string val = FastDriver.EditDisbursement.OriginatorInformation.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrst", val, "OriginatorInformation");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12345678");
                val = FastDriver.EditDisbursement.ReceivingBankABANumber.FAGetValue().Clean();
                Support.AreEqual("12345678", val, "ReceivingBankABANumber");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrst");
                val = FastDriver.EditDisbursement.ReceivingBankName.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrst", val, "ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrst");
                val = FastDriver.EditDisbursement.ReceivingBankAddress.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrst", val, "ReceivingBankAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("123456789012345678945632101234567");
                val = FastDriver.EditDisbursement.BeneficiaryAccountNumber.FAGetValue().Clean();
                Support.AreEqual("123456789012345678945632101234567", val, "BeneficiaryAccountNumber");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("123456789012345678945632101234567");
                val = FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FAGetValue().Clean();
                Support.AreEqual("123456789012345678945632101234567", val, "BeneficiaryConfirmAccountNumber");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("abcdefghijklmnopqrstuvwxyzabcdefgh");
                val = FastDriver.EditDisbursement.BeneficiaryName.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefgh", val, "BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryAddress.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrst");
                val = FastDriver.EditDisbursement.BeneficiaryAddress.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrst", val, "BeneficiaryAddress");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("abcdefghijklmnopqrstuvwxyzabcdefgh");
                val = FastDriver.EditDisbursement.BeneficiaryNote1.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefgh", val, "BeneficiaryNote1");
                FastDriver.EditDisbursement.BeneficiaryNote2.FASetText("abcdefghijklmnopqrstuvwxyzabcdefgh");
                val = FastDriver.EditDisbursement.BeneficiaryNote2.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefgh", val, "BeneficiaryNote2");
                FastDriver.EditDisbursement.BeneficiaryNote3.FASetText("abcdefghijklmnopqrstuvwxyzabcdefgh");
                val = FastDriver.EditDisbursement.BeneficiaryNote3.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefgh", val, "BeneficiaryNote3");
                FastDriver.EditDisbursement.BeneficiaryNote4.FASetText("abcdefghijklmnopqrstuvwxyzabcdefgh");
                val = FastDriver.EditDisbursement.BeneficiaryNote4.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefgh", val, "BeneficiaryNote4");
                FastDriver.EditDisbursement.IntermediaryBankBIC.FASetText("abcdefgh12");
                val = FastDriver.EditDisbursement.IntermediaryBankBIC.FAGetValue().Clean();
                Support.AreEqual("abcdefgh12", val, "IntermediaryBankBIC");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a Lease charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("LEASE");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Disbursement -Check.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verifying Field definitions in Wire details.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                Support.AreEqual("Wire", FastDriver.EditDisbursement.DisburseAs.FAGetSelectedItem().Clean(), "DisburseAs");
                FastDriver.EditDisbursement.OriginatorInformation.FASetText("");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("");
                FastDriver.EditDisbursement.BeneficiaryAddress.FASetText("");

                Reports.TestStep = "Validate Fields with exact value.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.OriginatorInformation.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstu");
                val = FastDriver.EditDisbursement.OriginatorInformation.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstu", val, "OriginatorInformation");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("123456789");
                val = FastDriver.EditDisbursement.ReceivingBankABANumber.FAGetValue().Clean();
                Support.AreEqual("123456789", val, "ReceivingBankABANumber");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstu");
                val = FastDriver.EditDisbursement.ReceivingBankName.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstu", val, "ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstu");
                val = FastDriver.EditDisbursement.ReceivingBankAddress.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstu", val, "ReceivingBankAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("1234567890123456789456321012345678");
                val = FastDriver.EditDisbursement.BeneficiaryAccountNumber.FAGetValue().Clean();
                Support.AreEqual("1234567890123456789456321012345678", val, "BeneficiaryAccountNumber");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("1234567890123456789456321012345678");
                val = FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FAGetValue().Clean();
                Support.AreEqual("1234567890123456789456321012345678", val, "BeneficiaryConfirmAccountNumber");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghi");
                val = FastDriver.EditDisbursement.BeneficiaryName.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghi", val, "BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryAddress.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstu");
                val = FastDriver.EditDisbursement.BeneficiaryAddress.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstu", val, "BeneficiaryAddress");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghi");
                val = FastDriver.EditDisbursement.BeneficiaryNote1.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghi", val, "BeneficiaryNote1");
                FastDriver.EditDisbursement.BeneficiaryNote2.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghi");
                val = FastDriver.EditDisbursement.BeneficiaryNote2.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghi", val, "BeneficiaryNote2");
                FastDriver.EditDisbursement.BeneficiaryNote3.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghi");
                val = FastDriver.EditDisbursement.BeneficiaryNote3.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghi", val, "BeneficiaryNote3");
                FastDriver.EditDisbursement.BeneficiaryNote4.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghi");
                val = FastDriver.EditDisbursement.BeneficiaryNote4.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghi", val, "BeneficiaryNote4");
                FastDriver.EditDisbursement.IntermediaryBankBIC.FASetText("abcdefgh123");
                val = FastDriver.EditDisbursement.IntermediaryBankBIC.FAGetValue().Clean();
                Support.AreEqual("abcdefgh123", val, "IntermediaryBankBIC");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create a new Utility instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText("Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText("50.00");

                Reports.TestStep = "Edit Disbursement -Check.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verifying Field definitions in Wire details.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                Support.AreEqual("Wire", FastDriver.EditDisbursement.DisburseAs.FAGetSelectedItem().Clean(), "DisburseAs");
                FastDriver.EditDisbursement.OriginatorInformation.FASetText("");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("");
                FastDriver.EditDisbursement.BeneficiaryAddress.FASetText("");

                Reports.TestStep = "Validate Fields with higher boundary.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.OriginatorInformation.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuv");
                val = FastDriver.EditDisbursement.OriginatorInformation.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstu", val, "OriginatorInformation");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("1234567890");
                val = FastDriver.EditDisbursement.ReceivingBankABANumber.FAGetValue().Clean();
                Support.AreEqual("123456789", val, "ReceivingBankABANumber");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuv");
                val = FastDriver.EditDisbursement.ReceivingBankName.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstu", val, "ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuv");
                val = FastDriver.EditDisbursement.ReceivingBankAddress.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstu", val, "ReceivingBankAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12345678901234567894563210123456789");
                val = FastDriver.EditDisbursement.BeneficiaryAccountNumber.FAGetValue().Clean();
                Support.AreEqual("1234567890123456789456321012345678", val, "BeneficiaryAccountNumber");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12345678901234567894563210123456789");
                val = FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FAGetValue().Clean();
                Support.AreEqual("1234567890123456789456321012345678", val, "BeneficiaryConfirmAccountNumber");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghij");
                val = FastDriver.EditDisbursement.BeneficiaryName.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghi", val, "BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryAddress.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuv");
                val = FastDriver.EditDisbursement.BeneficiaryAddress.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstu", val, "BeneficiaryAddress");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghij");
                val = FastDriver.EditDisbursement.BeneficiaryNote1.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghi", val, "BeneficiaryNote1");
                FastDriver.EditDisbursement.BeneficiaryNote2.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghij");
                val = FastDriver.EditDisbursement.BeneficiaryNote2.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghi", val, "BeneficiaryNote2");
                FastDriver.EditDisbursement.BeneficiaryNote3.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghij");
                val = FastDriver.EditDisbursement.BeneficiaryNote3.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghi", val, "BeneficiaryNote3");
                FastDriver.EditDisbursement.BeneficiaryNote4.FASetText("abcdefghijklmnopqrstuvwxyzabcdefghij");
                val = FastDriver.EditDisbursement.BeneficiaryNote4.FAGetValue().Clean();
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcdefghi", val, "BeneficiaryNote4");
                FastDriver.EditDisbursement.IntermediaryBankBIC.FASetText("abcdefgh1234");
                val = FastDriver.EditDisbursement.IntermediaryBankBIC.FAGetValue().Clean();
                Support.AreEqual("abcdefgh123", val, "IntermediaryBankBIC");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0032()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "EWC1: There are no disbursing bank accounts defined for the office. Evaluated upon issuing a disbursement.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Mofidy Escrow Owning Office";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem("Office Name - 1979 PR: STEST Off: 1979 (2951)");
                FastDriver.BottomFrame.Done();
                FastDriver.WarningDlg.Handle(false);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Print button.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                Reports.TestStep = "There are no disburse bank accounts defined for the office. Evaluated upon issue a disbursement.";
                Support.AreEqual("This office must be assigned at least one depositing bank account in order to record a disbursement", FastDriver.WebDriver.HandleDialogMessage().Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0075_REG0033()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "ES9899: Do not deliver Wire Transfer Order form";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, retryWithAutoIT: true);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Click Edit on Created Status.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a Lease charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("LEASE");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Disbursement -Check.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click Edit on Created Status.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Disburse All.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();

                Reports.TestStep = "Issue The Wires.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.IssueDisbursements.Disburse.FAClick();
                FastDriver.PasswordConfirmationDlg.Handle();

                Reports.TestStep = "Click on Done.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0075_REG0034()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "ES9900: Do not deliver Wire Transfer Order while issuing all disbursements";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create a new Utility instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText("Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText("50.00");

                Reports.TestStep = "Set an instance for Survey Details with charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("200" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, retryWithAutoIT: true);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Click Edit on Created Status.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Disburse All.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();

                Reports.TestStep = "Issue The Wires.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.IssueDisbursements.Disburse.FAClick();
                //FastDriver.PasswordConfirmationDlg.Handle();
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();

                Reports.TestStep = "Click on Done.";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0036()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "ES14473_ES14474_ES14475: Check SDN Search Status of Payee Before Issuing Disbursements / Display Warning When Payee Not Searched / Display Warning When Payee Not Cleared";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a Lease charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("LEASE");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Payee in SDN No Hit table of SDN Tracking summary screen";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.LeftNavigation.Navigate<SDNTrackingSummary>(@"Home>Order Entry>SDN Tracking Summary").WaitForScreenToLoad();
                    return !FastDriver.SDNTrackingSummary.SdnInProgressTable.FAGetText().Clean().Contains("lease name 1 lease name 2");
                }, timeout: 60, idleInterval: 10);
                Reports.TestStep = "SDN search completed.";
                Reports.StatusUpdate("Verify the Lessor name is present under SDN No HIT section.", FastDriver.SDNTrackingSummary.SDNNoHitTable.FAGetText().Clean().Contains("lease name 1 lease name 2"));

                Reports.TestStep = "Navigate to Active Disb Summary and Click on disburse all.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();

                Reports.TestStep = "Click on Disburse in Isuue Disbursements screen";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.IssueDisbursements.Disburse.FAClick();
                FastDriver.PrintDlg.SelectPrinter().Print.FAClick();
                FastDriver.OverdraftConfirmationDlg.Handle();

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on split button.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();

                Reports.TestStep = "Enter amount to split and save changes made.";
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionPercentage.FASetText("60" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab + FAKeys.Tab);
                FastDriver.SplitDisbursement.SplitDistributionPercentage1.FASetText("40" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add edit created status check with the name which shall appear in SDN hit.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Edit payee name for split disbursements.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisbursementPayee1.FASetText("Bin Laden");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disb Summary and Click on disburse all.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();

                Reports.TestStep = "Click on Disburse in Isuue Disbursements screen";
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.IssueDisbursements.Disburse.FAClick();

                Reports.TestStep = "Validate for warning which appears only if payee has not been searched against the SDN List.";
                FastDriver.WebDriver.HandleDialogMessage().Clean();
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();

                Reports.TestStep = "Wait for SDN Tracking to complete";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.LeftNavigation.Navigate<SDNTrackingSummary>(@"Home>Order Entry>SDN Tracking Summary").WaitForScreenToLoad();
                    return !FastDriver.SDNTrackingSummary.SdnInProgressTable.FAGetText().Clean().Contains("Bin Laden");
                }, timeout: 60, idleInterval: 10);
                Reports.TestStep = "SDN search completed.";
                Reports.StatusUpdate("Verify the Lessor name is present under SDN HIT section.", FastDriver.SDNTrackingSummary.SDNHitTable.FAGetText().Clean().Contains("Bin Laden"));

                Reports.TestStep = "Click on Disburse in Issue Disbursements screen";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();
                FastDriver.IssueDisbursements.WaitForScreenToLoad();
                FastDriver.IssueDisbursements.Disburse.FAClick();
                Support.AreEqual("WARNING!! Payee name search resulted in an SDN hit which has not been cleared. DO NOT disburse or close until you have properly cleared the name.", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.PrintDlg.WaitForScreenToLoad().Cancel.FAClick();

                //below code is not part of this test cases nor references any of the business rules in the test description

                //Reports.TestStep = "Owning Office Setup: Check on AgentNet Policy Number check box";
                //Reports.StatusUpdate("Open admin site...", true);
                //FastDriver.WebDriver.Quit();
                //FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                //Reports.TestStep = "Navigate to Region Level.";
                //FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                //FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);

                //Reports.TestStep = "Navigate to Office setup page.";
                //FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                //FastDriver.OfficeSetupOffice.IntegratewithExternalSystems.PerformTableAction(1, "AgentNet Policy Number", 1, TableAction.Click);
                //FastDriver.OfficeSetupOffice.ANPolicyNumber.FASetCheckbox(true);
                //FastDriver.BottomFrame.Done();
                //FastDriver.WebDriver.Quit();

                //Reports.TestStep = "Back to File site...";
                //FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //Reports.TestStep = "Validation of the following message begins: File has AgentNet Policy Numbers. Please void all policy numbers and then you can change File Status";

                //#region data setup for second order
                //var detailedFileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                //detailedFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                //detailedFileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                //    {
                //        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                //        {
                //            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                //            RoleTypeObjectCD = "BUSSOURCE"
                //        },
                //        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                //        {
                //            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                //            RoleTypeObjectCD = "NEWLDR"
                //        },
                //        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                //        {
                //            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                //            RoleTypeObjectCD = "DIRECTEDBY"
                //        },
                //        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                //        {
                //            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                //            RoleTypeObjectCD = "ASSOTDPTY"
                //        }
                //    };
                //#endregion

                //Reports.TestStep = "Create File using web service.";
                //string secondfileNumber = FastDriver.FACreateFileFromWCF(detailedFileRequest);
                //FastDriver.TopFrame.SearchFileByFileNumber(secondfileNumber);

                //Reports.TestStep = "Click on New Loan.";
                //FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                //FastDriver.NewLoan.LoanDetailsLoanAmount.Click();
                //FastDriver.NewLoan.LoanDetailsLoanAmount.FASendKeys("1000" + FAKeys.Tab);
                //FastDriver.WebDriver.HandleDialogMessage();
                //FastDriver.NewLoan.WaitForScreenToLoad();
                //FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("1234");
                //FastDriver.BottomFrame.Done();

                //Reports.TestStep = "Request Policy number";
                //FastDriver.LeftNavigation.Navigate<RequestPolicyNumber>(@"Home>Order Entry>Request Policy Number").WaitForScreenToLoad();
                //FastDriver.RequestPolicyNumber.Underwriter.FASelectItem("First American Title Insurance Company");
                //FastDriver.RequestPolicyNumber.AgentOffices.FASelectItem("DEMO - ABC Settlement Services/CA/Redding");
                //FastDriver.RequestPolicyNumber.RequestNumber.FAClick();
                ////wait for policyNumbers?
                ////FastDriver.RequestPolicyNumber.PolicyNumbers

                //Reports.TestStep = "Enter First fee in Title and escrow.";
                //FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                //FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                //FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                //FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);
                //FastDriver.BottomFrame.Done();

                //Reports.TestStep = "Navigate to Active Disb Summary and Fee amount row.";
                //FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                //FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                //FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                //FastDriver.OverdraftConfirmationDlg.Handle();

                //Reports.TestStep = "Change File status to Open In Error";
                //FastDriver.ChangeFileStatusDlg.ConfirmStatus("Open In Error");
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                //Reports.TestStep = "Validate the error message";
                //Support.AreEqual("File has AgentNet Policy Numbers. Please void all policy numbers and then you can change File Status.", FastDriver.WebDriver.HandleDialogMessage());
                //FastDriver.PrintDlg.ClickCancel();

                //Reports.TestStep = "Enter First fee in Title and escrow.";
                //FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                //FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                //var element = FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input");
                //element.Click();
                //element.FASendKeys("10.99" + FAKeys.Tab);

                //Reports.TestStep = "Validate the Adjust informational message.";
                //if (FastDriver.WebDriver.WaitForAlertToExist(2))
                //    Support.AreEqual("This change will update Split Fee and/or Retained amounts, and may create additional pending Split Fee Disbursements and/or Fee Transfers, and may remove Underwriter and Agent premium splits. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                //element = FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input");
                //element.Click();
                //element.FASendKeys("20.99" + FAKeys.Tab);

                //Reports.TestStep = "Validate the Adjust informational message.";
                //if (FastDriver.WebDriver.WaitForAlertToExist(2))
                //    Support.AreEqual("This change will update Split Fee and/or Retained amounts, and may create additional pending Split Fee Disbursements and/or Fee Transfers, and may remove Underwriter and Agent premium splits. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                //FastDriver.BottomFrame.Done();

                //Reports.TestStep = "Navigate to Active Disb Summary and Fee amount row.";
                //FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                //FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                //FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                //FastDriver.OverdraftConfirmationDlg.Handle();

                //Reports.TestStep = "Change File status to Cancelled";
                //FastDriver.ChangeFileStatusDlg.ConfirmStatus("Cancelled");

                //Reports.TestStep = "Validate the error message";
                //Support.AreEqual("File has AgentNet Policy Numbers. Please void all policy numbers and then you can change File Status.", FastDriver.WebDriver.HandleDialogMessage());
                //FastDriver.PrintDlg.ClickCancel();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0075_REG0037()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                string theOtherDepositAccount = "3109200000";

                Reports.TestDescription = "SM14667_ES14274: Issue a pending wire from an inactive bank account_Validate the Account Number for Disbursement";

                ToggleBankAccount(true, theOtherDepositAccount);

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add Home warranty charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("200.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("250.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, retryWithAutoIT: true);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Click Edit on Created Status.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Edit on Pending Status Wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Change the From account to other than default account";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                string defaultAccount = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem().Clean();
                FastDriver.EditDisbursement.FromAccount.FASelectItem(theOtherDepositAccount);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                ToggleBankAccount(false, theOtherDepositAccount);

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Check the from account after deactivating the previuosly selected from account";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Capture the default account and validate.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(defaultAccount, FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem().Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0075_REG0040()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                string theOriginalDepositAccount = "3120370000";
                string theOtherDepositAccount = "3109200000";

                Reports.TestDescription = "SM14667: Issue a pending wire from an inactive bank account_Validate the Account Number for Disbursement_1st Deposit Account, if the 1st deposit account is a Wirelink Interface Account";

                ToggleBankAccount(true, theOriginalDepositAccount);
                ToggleBankAccount(true, theOtherDepositAccount);

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Deposit in Cash.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                FastDriver.DepositInEscrow.Deposit(new DepositParameters
                {
                    Amount = 100.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    DepositedTo = theOriginalDepositAccount,
                    Payor = "TestName",
                    Comments = "Testcomments"
                });
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Add a Lease charge.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.FindGABcode("LEASE");
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Changed desc");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("10.00");
                FastDriver.LeaseDetail.SellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.DisburseAs);
                string savedAccountShownInUI = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem().Clean();
                Support.AreEqual(theOriginalDepositAccount, savedAccountShownInUI, "FromAccount");
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.FromAccount.FASelectItem(theOriginalDepositAccount);
                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
                FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
                FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
                FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
                FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();

                Reports.TestStep = "Click on Open Button.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, retryWithAutoIT: true);
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Click Edit on Wire funds.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Click on Add button for Wire Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.WaitForScreenToLoad();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Done.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Edit on Pending Status Wire.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Change the From account to other than default account";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                savedAccountShownInUI = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem().Clean();
                Support.AreEqual(theOriginalDepositAccount, savedAccountShownInUI, "FromAccount");
                FastDriver.EditDisbursement.FromAccount.FASelectItem(theOtherDepositAccount);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.Quit();

                ToggleBankAccount(false, theOtherDepositAccount);

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Search the file number.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Check the from account after deactivating the previuosly selected From Account";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Validate default account is selected when previously selected one is deactivated.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(savedAccountShownInUI, FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem().Clean());
                FastDriver.WebDriver.Quit();

                ToggleBankAccount(true, theOtherDepositAccount);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0041()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "UserStory#447094(TFS#816314), TC#637474:Verify that Track button enable for multiple issued fees disbursements, TC#637594:Validate user should be able to enter Track notes for selected disbursement, TC#639227:Validate user should be able to enter special characters in Track notes for selected disbursement ";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                //FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-2", "Sel", TableAction.On);
                //FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-2", "Buyer Charge", TableAction.SetText, "5.99" + FAKeys.Tab);
                //FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-2", "Seller Charge", TableAction.SetText, "6.99" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();

                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Acive Disbursement Summary via Home|Order Entry|Disbursements| Active Disbursement Summary";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the Pending fees and verify that the Track button is disabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                var status = !FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status.ToString().ToLower());

                Reports.TestStep = "Click on Fee Transfer button";
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                
                Reports.TestStep = "Enter the details in Password Confirmation dialog and click Done button";
                FastDriver.PasswordConfirmationDlg.Handle();

                Reports.TestStep = "Enter the details in ChangeFileStatus dialog and click on Done button";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.ChangeFileStatusDlg.ConfirmStatus("Open");

                Reports.TestStep = "Click on Cancel button of Print dialog";
                FastDriver.PrintDlg.ClickCancel();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the fee status changes to Issued";
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.98", "Status", TableAction.GetText).Message.Trim());
                

                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Enter Second fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "3.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "4.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Acive Disbursement Summary via Home|Order Entry|Disbursements| Active Disbursement Summary";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the Pending fees and verify that the Track button is disabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                var status1 = !FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status1.ToString().ToLower());

                Reports.TestStep = "Click on Fee Transfer button";
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Enter the details in Password Confirmation dialog and click Done button";
                FastDriver.PasswordConfirmationDlg.Handle();

                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter the details in ChangeFileStatus dialog and click on Done button";
                FastDriver.ChangeFileStatusDlg.ConfirmStatus("Open");

                Reports.TestStep = "Click on Cancel button of Print dialog";
                FastDriver.PrintDlg.ClickCancel();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the fee status changes to Issued";
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "8.98", "Status", TableAction.GetText).Message);

                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select more than 1 fees and validate Track button is enabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "4.98", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "8.98", 1, TableAction.Click);
                var status2 = FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status2.ToString().ToLower());

                Reports.TestStep = "Click on Track button and enter the Track notes for selected disbursement";
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                
                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.Highlight();
                FastDriver.TrackDlg.TrackInfo.FASetText(@"Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test");
                //FastDriver.TrackDlg.Done.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Notes and verify the Track Notes";
                FastDriver.FileNotes.Open();

                FastDriver.FileNotes.WaitForScreenToLoad();

                 //string tableContent = FastDriver.FileNotes.Table.FAGetValue();
                 //Support.AreEqual(true, tableContent.Contains("Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test"), "Verifying the File Notes.");
                var temp = FastDriver.FileNotes.Table.PerformTableAction(2, 1, TableAction.GetText).Message;
                 Support.AreEqual(true, temp.Contains(@"Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test"), "Verifying the File Notes.");

           
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0042()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "UserStory#447094(TFS#816314),TC#637530: Verify that Track button enable for multiple issued Escrow charge disbursements";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Utility screen and enter the Utility Charges";
                FastDriver.UtilityDetail.Open().WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.SendKeys("255");
                FastDriver.UtilityDetail.Find.FAClick();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesDescription.FAClick();
                FastDriver.UtilityDetail.UtilityChargesDescription.SendKeys(FAKeys.Space);
                FastDriver.UtilityDetail.UtilityChargesDescription.SendKeys("UtilityFees");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAClick();
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.SendKeys(FAKeys.Space);
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.SendKeys("1.99");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAClick();
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys(FAKeys.Space);
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys("2.99");
                FastDriver.BottomFrame.Done();

                FastDriver.UtilityDetail.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Lease screen and enter the Lease Charges";
                FastDriver.LeaseDetail.Open().WaitForScreenToLoad();
                FastDriver.LeaseDetail.GABcode.SendKeys("253");
                FastDriver.LeaseDetail.Find.FAClick();
                FastDriver.LeaseDetail.WaitForScreenToLoad();
                FastDriver.LeaseDetail.ChargeDescription.FAClick();
                FastDriver.LeaseDetail.ChargeDescription.SendKeys(FAKeys.Space);
                FastDriver.LeaseDetail.ChargeDescription.SendKeys("Lease Charge");
                FastDriver.LeaseDetail.BuyerCharge.FAClick();
                FastDriver.LeaseDetail.BuyerCharge.SendKeys(FAKeys.Space);
                FastDriver.LeaseDetail.BuyerCharge.SendKeys("1.50");
                FastDriver.LeaseDetail.SellerCharge.FAClick();
                FastDriver.LeaseDetail.SellerCharge.SendKeys(FAKeys.Space);
                FastDriver.LeaseDetail.SellerCharge.SendKeys("2.50");
                FastDriver.BottomFrame.Done();

                FastDriver.LeaseDetail.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Acive Disbursement Summary via Home|Order Entry|Disbursements| Active Disbursement Summary";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the Pending fees and verify that the Track button is disabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "4.00", 1, TableAction.Click);
                var status1 = !FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status1.ToString().ToLower());

                Reports.TestStep = "Click on Manual button";
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Enter the Check Number and Click on Save button";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.CheckNo.SendKeys("12345");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the warning message on clicking Save button and Click on OK button of dialog pop-up";
                string WarnMessage = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Check number 12345 already exists within this Bank Account and Office. Continue?", WarnMessage, "Verifying the message content");

                Reports.TestStep = "Enter the details in Password Confirmation dialog and click Done button";
                FastDriver.PasswordConfirmationDlg.Handle();

                Reports.TestStep = "Enter the details in Manual Check dialog";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.SendKeys("Test Automation");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the fee status changes to Issued";
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.00", "Status", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Select the 2nd Pending fees and verify that the Track button is disabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "4.98", 1, TableAction.Click);
                var status2 = !FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status2.ToString().ToLower());

                Reports.TestStep = "Click on Manual button";
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                Reports.TestStep = "Enter the Check Number and Click on Save button";
                FastDriver.IssueManualCheck.CheckNo.SendKeys("23456");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the warning message on clicking Save button and Click on OK button of dialog pop-up";
                string WarnMessage2 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Check number 23456 already exists within this Bank Account and Office. Continue?", WarnMessage2, "Verifying the message content");

                Reports.TestStep = "Enter the details in Password Confirmation dialog and click Done button";
                FastDriver.PasswordConfirmationDlg.Handle();

                Reports.TestStep = "Enter the details in Manual Check dialog";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.SendKeys("Test Automation");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the fee status changes to Issued";
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.98", "Status", TableAction.GetText).Message);

                Reports.TestStep = "Select more than 1 fees and validate Track button is enabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "4.98", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "4.00", 1, TableAction.Click);
                var status3 = FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status3.ToString().ToLower());

                Reports.TestStep = "Click on Track button and enter the Track notes for selected disbursement";
                FastDriver.ActiveDisbursementSummary.Track.FAClick();

                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.Highlight();
                FastDriver.TrackDlg.TrackInfo.FASetText(@"Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Notes and verify the Track Notes";
                FastDriver.FileNotes.Open();

                FastDriver.FileNotes.WaitForScreenToLoad();

                //Support.AreEqual(true, FastDriver.FileNotes.Table.PerformTableAction(3, 1, TableAction.GetText).Message.Contains("Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test"), "Verifying the File Notes.");
                var temp1 = FastDriver.FileNotes.Table.PerformTableAction(2, 1, TableAction.GetText).Message;
                Support.AreEqual(true, temp1.Contains(@"Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test"), "Verifying the File Notes.");
                var temp2 = FastDriver.FileNotes.Table.PerformTableAction(3, 1, TableAction.GetText).Message;
                Support.AreEqual(true, temp2.Contains(@"Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test"), "Verifying the File Notes.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0043()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "UserStory#447094(TFS#816314), TC#637689:Validate the warning message when user trying to append the existing Track for issued disbursement";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();

                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Acive Disbursement Summary via Home|Order Entry|Disbursements| Active Disbursement Summary";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the Pending fees and verify that the Track button is disabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                var status = !FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status.ToString().ToLower());

                Reports.TestStep = "Click on Fee Transfer button";
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Enter the details in Password Confirmation dialog and click Done button";
                FastDriver.PasswordConfirmationDlg.Handle();

                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter the details in ChangeFileStatus dialog and click on Done button";
                FastDriver.ChangeFileStatusDlg.ConfirmStatus("Open");

                Reports.TestStep = "Click on Cancel button of Print dialog";
                FastDriver.PrintDlg.ClickCancel();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the fee status changes to Issued";
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.98", "Status", TableAction.GetText).Message.Trim());

                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Enter Second fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "3.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "4.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Acive Disbursement Summary via Home|Order Entry|Disbursements| Active Disbursement Summary";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the Pending fees and verify that the Track button is disabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                var status1 = !FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status1.ToString().ToLower());

                Reports.TestStep = "Click on Fee Transfer button";
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Enter the details in Password Confirmation dialog and click Done button";
                FastDriver.PasswordConfirmationDlg.Handle();

                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter the details in ChangeFileStatus dialog and click on Done button";
                FastDriver.ChangeFileStatusDlg.ConfirmStatus("Open");

                Reports.TestStep = "Click on Cancel button of Print dialog";
                FastDriver.PrintDlg.ClickCancel();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the fee status changes to Issued";
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "8.98", "Status", TableAction.GetText).Message.Trim());

                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select more than 1 fees and validate Track button is enabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "4.98", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "8.98", 1, TableAction.Click);
                var status2 = FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status2.ToString().ToLower());

                Reports.TestStep = "Click on Track button and enter the Track notes for selected disbursement";
                FastDriver.ActiveDisbursementSummary.Track.FAClick();

                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.Highlight();
                FastDriver.TrackDlg.TrackInfo.FASetText(@"Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test");
                //FastDriver.TrackDlg.Done.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Notes and verify the Track Notes";
                FastDriver.FileNotes.Open();

                FastDriver.FileNotes.WaitForScreenToLoad();

                Support.AreEqual(true, FastDriver.FileNotes.Table.PerformTableAction(3, 1, TableAction.GetText).Message.Contains(@"Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test"), "Verifying the File Notes.");

                Reports.TestStep = "Navigate back to Active Disbursement screen and append the existing Track for issued disbursement";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select more than 1 fees and validate Track button is enabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "4.98", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "8.98", 1, TableAction.Click);
                var status3 = FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status3.ToString().ToLower());

                Reports.TestStep = "Click on Track button and enter the Track notes for selected disbursement";
                FastDriver.ActiveDisbursementSummary.Track.FAClick();

                Reports.TestStep = "Validate the warning message and Click on OK button of dialog pop-up";
                string WarnMessage = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("One or more of the selected issued disbursements already contains a Track entry. Do you want to proceed with the current entry by allowing the system to void the existing Track entries?", WarnMessage, "Verifying the message content");

                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.Highlight();
                FastDriver.TrackDlg.TrackInfo.FASetText(@"Updated_Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test");
                //FastDriver.TrackDlg.Done.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Notes and verify the Track Notes";
                FastDriver.FileNotes.Open();

                FastDriver.FileNotes.WaitForScreenToLoad();

                Support.AreEqual(true, FastDriver.FileNotes.Table.PerformTableAction(3, 1, TableAction.GetText).Message.Contains(@"Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test"), "Verifying the File Notes.");

                Reports.TestStep = "Append the Tack comments in File Note";
                //FastDriver.FastViewFileNotes.FileNotesGrid1.PerformTableAction(2, "FAST QA07", 3, TableAction.Click);
                FastDriver.FileNotes.Table.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.FileNotes.Append.FAClick();

                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                FastDriver.FileNotesEditor.txtNote.Highlight();
                FastDriver.FileNotesEditor.txtNote.SendKeys("Appended Text1");
                //FastDriver.FileNotesEditor.txtNote.FASetText("test");
                //FastDriver.FileNotesEditor.txtNote.Click();
                //FastDriver.PhraseEditorDlg.TextArea.FASetText("Appended Text1");
                //FastDriver.WebDriver.FAFindElement(ByLocator.XPath, @"//iframe[@id='tbContentElement']//*//body[@__vsttCommunicationElement__1='[object]']").Highlight();//SendKeys("Appended Text1");
                FastDriver.BottomFrame.Done();

                FastDriver.FileNotes.WaitForScreenToLoad();

                //Support.AreEqual(true, FastDriver.FileNotes.Table.PerformTableAction(3, 1, TableAction.GetText).Message.Contains("Appended Text1"), "Verifying the File Notes.");
                var temp1 = FastDriver.FileNotes.Table.PerformTableAction(2, 1, TableAction.GetText).Message;
                Support.AreEqual(true, temp1.Contains(@"Appended Text1"), "Verifying the File Notes.");


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0044()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "UserStory#447094(TFS#816314),TC#639218:User selects 2 Issued and 1 Pending disbursement - Track button should be disabled";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();

                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Acive Disbursement Summary via Home|Order Entry|Disbursements| Active Disbursement Summary";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the Pending fees and verify that the Track button is disabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                var status = !FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status.ToString().ToLower());

                Reports.TestStep = "Click on Fee Transfer button";
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Enter the details in Password Confirmation dialog and click Done button";
                FastDriver.PasswordConfirmationDlg.Handle();

                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter the details in ChangeFileStatus dialog and click on Done button";
                FastDriver.ChangeFileStatusDlg.ConfirmStatus("Open");

                Reports.TestStep = "Click on Cancel button of Print dialog";
                FastDriver.PrintDlg.ClickCancel();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the fee status changes to Issued";
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4.98", "Status", TableAction.GetText).Message.Trim());

                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Enter Second fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Buyer Charge", TableAction.SetText, "3.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-1", "Seller Charge", TableAction.SetText, "4.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Acive Disbursement Summary via Home|Order Entry|Disbursements| Active Disbursement Summary";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the Pending fees and verify that the Track button is disabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                var status1 = !FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status1.ToString().ToLower());

                Reports.TestStep = "Click on Fee Transfer button";
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Enter the details in Password Confirmation dialog and click Done button";
                FastDriver.PasswordConfirmationDlg.Handle();

                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter the details in ChangeFileStatus dialog and click on Done button";
                FastDriver.ChangeFileStatusDlg.ConfirmStatus("Open");

                Reports.TestStep = "Click on Cancel button of Print dialog";
                FastDriver.PrintDlg.ClickCancel();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the fee status changes to Issued";
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "8.98", "Status", TableAction.GetText).Message.Trim());

                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select more than 1 fees and validate Track button is enabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "4.98", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "8.98", 1, TableAction.Click);
                var status2 = FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status2.ToString().ToLower());

                Reports.TestStep = "Click on Track button and enter the Track notes for selected disbursement";
                FastDriver.ActiveDisbursementSummary.Track.FAClick();

                FastDriver.TrackDlg.WaitForScreenToLoad();
                FastDriver.TrackDlg.TrackInfo.Highlight();
                FastDriver.TrackDlg.TrackInfo.FASetText(@"Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test");
                //FastDriver.TrackDlg.Done.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Notes and verify the Track Notes";
                FastDriver.FileNotes.Open();

                FastDriver.FileNotes.WaitForScreenToLoad();

                //Support.AreEqual(true, FastDriver.FileNotes.Table.PerformTableAction(3, 1, TableAction.GetText).Message.Contains("Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test"), "Verifying the File Notes.");
                var temp1 = FastDriver.FileNotes.Table.PerformTableAction(2, 1, TableAction.GetText).Message;
                Support.AreEqual(true, temp1.Contains(@"Test1@Track1234567890!@#$%^&*()[]{}\':,./<>?Test"), "Verifying the File Notes.");

                Reports.TestStep = "Enter 3rd fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-2", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-2", "Buyer Charge", TableAction.SetText, "5.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate Eagle Lender Policy-2", "Seller Charge", TableAction.SetText, "6.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Acive Disbursement Summary via Home|Order Entry|Disbursements| Active Disbursement Summary";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select more than 1 fees with a pending fee and validate Track button is not enabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "4.98", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "8.98", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "12.98", 1, TableAction.Click);
                var status3 = !FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status3.ToString().ToLower());


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0045()
        {
            try 
	            {	        
		
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "UserStory#510845(TFS#816314)Direct - New Overdraft Reason Code -  RECORDING-Failed to collect accurate fees to record";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter First fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99" + FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();

                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Acive Disbursement Summary via Home|Order Entry|Disbursements| Active Disbursement Summary";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select the Pending fees and verify that the Track button is disabled";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                var status = !FastDriver.ActiveDisbursementSummary.Track.IsEnabled();
                Support.AreEqual("true", status.ToString().ToLower());

                Reports.TestStep = "Click on Fee Transfer button";
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                
                Reports.TestStep = "Enter the details in Password Confirmation dialog and click Done button";
                FastDriver.PasswordConfirmationDlg.Handle();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the details in ChangeFileStatus dialog and click on Done button";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.ChangeFileStatusDlg.ConfirmStatus("Open");

                Reports.TestStep = "Click on Cancel button of Print dialog";
                FastDriver.PrintDlg.ClickCancel();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0075_REG0046()
        {
            try
            {

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                #endregion

                Reports.TestDescription = "US#713725 -System shall display Password confirmation window with One Sided  adjustment";

                Reports.TestStep = "Log into FAST application";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Deposit in Escrow screen, making a manual deposit from buyer";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Amount.FASetText("8000.00");
                FastDriver.DepositInEscrow.Manual.FAClick();
                FastDriver.DepositInEscrow.ReceiptNo.FASetText(Support.RandomNumber(99999).ToString());
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.Description.FASetText("Testing");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Buyer Name");
                string depositToAccount = FastDriver.DepositInEscrow.DepositedTo.FAGetSelectedItem().Clean();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Enter manual deposit reason, click OK";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();

                Reports.TestStep = "Click Cancel on the print deposit receipt screen";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to Deposit/Receipt History screen, select the 8000.00 amount, click Adjust";
                FastDriver.DepositReceiptHistory.Open();
                string docNum = FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, "8,000.00", 4, TableAction.GetText).Message.Clean();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, "8,000.00", 6, TableAction.Click);
                FastDriver.DepositReceiptHistory.Adjust.FAClick();

                Reports.TestStep = "Enter Adjustment Reason";
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Input Error");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click OK on the continue? message";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 20, true);

                Reports.TestStep = "Navigate to the Event Tracking, validate account number is masked 'XXXXX####'";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("All");
                FastDriver.EventTrackingLog.WaitForScreenToLoad(FastDriver.EventTrackingLog.EventTable);
                depositToAccount = "XXXXX" + depositToAccount.Substring(5, depositToAccount.Length - 5);
                string expectedResult = "Adjustment Reason: Input Error, Document Number: " + docNum + ", Amount: 8000.00, Payor: Buyer Name, Issue Date: " + DateTime.Now.ToString("M/d/yyyy") + ", Depositing Bank Account:" + depositToAccount + ", Update Trust Accounting=Yes";
                Support.AreEqual(expectedResult, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Deposit Adjustment]", 5, TableAction.GetText).Message.Clean(), "Comments");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        #endregion

        //Utility method: Many test steps included. Cannot break apart and move it to the page objects
        private void ToggleBankAccount(bool activate, string accountNumber)
        {
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            Reports.TestStep = "Navigate to Region Level.";
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
            FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);

            Reports.TestStep = "Navigate to Office Setup screen";
            FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
            FastDriver.OfficeSetupBankAccounts.BankAccountsMenu.FAClick();
            FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
            FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction("Account Number", accountNumber, "Account Number", TableAction.Click);
            string accountStatus = FastDriver.OfficeSetupBankAccounts.BankStatus.FAGetText().Clean();
            Reports.StatusUpdate("Bank account status: " + accountStatus, true);
            if ((accountStatus == "Active" && !activate) || (accountStatus == "InActive" && activate))
            {
                Reports.TestStep = "View Change Bank Account Status.";
                FastDriver.OfficeSetupBankAccounts.ViewChangeStatus.FAClick();

                Reports.TestStep = "Change the Status to Deactivate.";
                FastDriver.StatusEdit.WaitForScreenToLoad();
                FastDriver.StatusEdit.Comments.FASetText(string.Format("{0} the bank account", activate ? "activated" : "deactivated"));
                if (activate)
                    FastDriver.StatusEdit.Activate.FAClick();
                else
                    FastDriver.StatusEdit.Deactivate.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click On Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = string.Format("Verify Bank Status changed to {0}.", activate ? "Active" : "InActive");
                FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad(FastDriver.OfficeSetupBankAccounts.BankAccountsMenu);
                FastDriver.OfficeSetupBankAccounts.BankAccountsMenu.FAClick();
                FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad(FastDriver.OfficeSetupBankAccounts.BanksTable);
                FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction("Account Number", accountNumber, "Account Number", TableAction.Click);
                Support.AreEqual(activate ? "Active" : "InActive", FastDriver.OfficeSetupBankAccounts.BankStatus.FAGetText().Clean(), "BankStatus");
                FastDriver.BottomFrame.Done();
            }
            FastDriver.WebDriver.Quit();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
