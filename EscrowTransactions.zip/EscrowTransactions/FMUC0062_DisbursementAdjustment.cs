﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Linq;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;

namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0062 : MasterTestClass
    {
        #region BAT

        #region Test FMUC0062_BAT0001

        [TestMethod]
        public void FMUC0062_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Process a One-Sided Adjustment on a Disbursement";

                #region DataSetup

                var userID = AutoConfig.UserName;
                string reversedUserID = GetParsedUserIDWithSpace(userID: userID, IsToBeReversed: true);

                string[] tempArray1 = { "", "" };

                tempArray1 = userID.Split('\\');
                UserIDTypes.ReversedUserID = tempArray1[1].Substring(4, 4) + ", " + tempArray1[1].Substring(0, 4);
                UserIDTypes.SplitViewWithSpace = tempArray1[1].Substring(0, 4) + " " + tempArray1[1].Substring(4, 4);

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Give details for Buyer and Seller fields.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 2nd survey detail.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 3rd survey detail.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();

                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("250");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields.

                #region Print All Checks

                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog.";
                FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();

                #endregion Print All Checks

                #region Click on Adjust button select 1st charge.

                Reports.TestStep = "Click on Adjust button select 1st charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);
                else
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);

                FastDriver.DisbursementHistory.Adjust.FAClick();

                #endregion Click on Adjust button select 1st charge.

                #region Process a One-Sided Adjustment on a Disbursement.

                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");
                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Process a One-Sided Adjustment on a Disbursement.

                #region Verify

                Reports.TestStep = "Verify the pending item which is created for canceled disbursement.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message.Trim());
                else
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify the status for the pending item which is created for canceled disbursement.";
                Support.AreEqual("Pending", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Payee", "Midwest Financial Group", "Status", TableAction.GetText).Message);
                if (AutoConfig.FormType.ToLower().Equals("cd"))
                    Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "5.00-", "Tp.", TableAction.GetText).Message.Trim());
                else
                    Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "14.00-", "Tp.", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verifying for Disbursement adjustment event";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory(@"Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 4, TableAction.Click);
                Support.AreEqual(UserIDTypes.ReversedUserID.ToLower(), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 4, TableAction.GetText).Message.ToLower());

                Reports.TestStep = "Verify for Adjustment Reason in comments of disbursement adjustment event for Cancel";
                Reports.StatusUpdate("Adjustment Reason present in comments", FastDriver.EventTrackingLog.Comments.FAGetText().Contains(@"Adjustment Reason: Cancel"));

                #endregion Verify
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_BAT0001

        #region Test FMUC0062_BAT0002

        [TestMethod]
        public void FMUC0062_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF3_00: Reverse a One-Sided Adjustment on a Disbursement";

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Give details for Buyer and Seller fields.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 2nd survey detail.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 3rd survey detail.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();

                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("250");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields.

                #region Print All Checks

                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog.";
                FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();

                #endregion Print All Checks

                #region Click on Adjust button select 1st charge.

                Reports.TestStep = "Click on Adjust button select 1st charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);
                else
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);

                FastDriver.DisbursementHistory.Adjust.FAClick();

                #endregion Click on Adjust button select 1st charge.

                #region ProcessOneSidedAdjstmentOnDisbrsment Cancel

                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");
                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion ProcessOneSidedAdjstmentOnDisbrsment Cancel

                #region ProcessOneSidedAdjstmentOnDisbrsment Repost

                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "CA", 2, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Reverse a One-Sided Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("REPOST", false, false, "comments for repost");
                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion ProcessOneSidedAdjstmentOnDisbrsment Repost

                #region Click on Adjust button for repost a cancelled one.

                Reports.TestStep = "Verify the status for the Adjusted item which is created for reposted disbursement.";

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                Support.AreEqual("C", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Tp.", TableAction.GetText).Message);

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "", "Amount", TableAction.GetText).Message.Trim());
                }
                else
                {
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "", "Amount", TableAction.GetText).Message.Trim());
                }

                Reports.TestStep = "Verify the adjusted item which is created for reposted disbursement.";
                Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Adjusted", "Tp.", TableAction.GetText).Message);

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", @"Iss/Adj", "Amount", TableAction.GetText).Message.Trim());
                    Support.AreEqual(@"5.00-", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Adjusted", "Amount", TableAction.GetText).Message.Trim());
                }
                else
                {
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", @"Iss/Adj", "Amount", TableAction.GetText).Message.Trim());
                    Support.AreEqual(@"14.00-", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Adjusted", "Amount", TableAction.GetText).Message.Trim());
                }

                #endregion Click on Adjust button for repost a cancelled one.
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_BAT0002

        #region Test FMUC0062_BAT0003

        [TestMethod]
        public void FMUC0062_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF1_00: Process a Correcting Adjustment on a Disbursement";

                #region DataSetup

                var userID = AutoConfig.UserName;
                string reversedUserID = GetParsedUserIDWithSpace(userID: userID, IsToBeReversed: true);

                string[] tempArray1 = { "", "" };

                tempArray1 = userID.Split('\\');
                UserIDTypes.ReversedUserID = tempArray1[1].Substring(4, 4) + ", " + tempArray1[1].Substring(0, 4);
                UserIDTypes.SplitViewWithSpace = tempArray1[1].Substring(0, 4) + " " + tempArray1[1].Substring(4, 4);

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Give details for Buyer and Seller fields.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 2nd survey detail.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 3rd survey detail.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();

                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("250");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields.

                #region Print All Checks

                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.HandleDialogMessage(); 
                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();

                #endregion Print All Checks

                #region Click on Adjust button select 1st charge.

                Reports.TestStep = "Click on Adjust button select 1st charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);
                else
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);

                FastDriver.DisbursementHistory.Adjust.FAClick();

                #endregion Click on Adjust button select 1st charge.

                #region ProcessOneSidedAdjstmentOnDisbrsment Cancel

                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");
                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion ProcessOneSidedAdjstmentOnDisbrsment Cancel

                #region ProcessOneSidedAdjstmentOnDisbrsment Repost

                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "CA", 2, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Reverse a One-Sided Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("REPOST", false, false, "comments for repost");
                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion ProcessOneSidedAdjstmentOnDisbrsment Repost

                #region Click on Adjust button for repost a cancelled one.

                Reports.TestStep = "Verify the status for the Adjusted item which is created for reposted disbursement.";

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                Support.AreEqual("C", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Tp.", TableAction.GetText).Message);

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "", "Amount", TableAction.GetText).Message.Trim());
                }
                else
                {
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "", "Amount", TableAction.GetText).Message.Trim());
                }

                Reports.TestStep = "Verify the adjusted item which is created for reposted disbursement.";
                Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Adjusted", "Tp.", TableAction.GetText).Message);

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", @"Iss/Adj", "Amount", TableAction.GetText).Message.Trim());
                    Support.AreEqual(@"5.00-", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Adjusted", "Amount", TableAction.GetText).Message.Trim());
                }
                else
                {
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", @"Iss/Adj", "Amount", TableAction.GetText).Message.Trim());
                    Support.AreEqual(@"14.00-", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Adjusted", "Amount", TableAction.GetText).Message.Trim());
                }

                #endregion Click on Adjust button for repost a cancelled one.

                #region Add a 4rd survey detail

                Reports.TestStep = "Add a 4rd survey detail.";
                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                FastDriver.SurveySummary.New.FAClick();
                FastDriver.SurveyDetail.GABcode.FASetText("251");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Manual button.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("ABCD");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                string checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                Reports.TestStep = "Save the document number.";
                string DocNum = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Adjust for Correct Adjustment.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", DocNum, "Document", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Process a Correct Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("Correct Document No", false, false);

                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the status for the Adjusted item which is created for Correct Doc No.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", "21456", "Tp.", TableAction.GetText).Message);

                Reports.TestStep = "Verify the adjusted item which is created for Correct Doc No.";

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "5.00-", "Amount", TableAction.Click);
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "5.00", "Tp.", TableAction.Click);
                }
                else
                {
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "14.00-", "Amount", TableAction.Click);
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "14.00", "Tp.", TableAction.Click);
                }

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", @"Iss/Adj", "Amount", TableAction.Click);

                Reports.TestStep = "Verify for Adjustment Reason in comments of disbursement adjustment event for Correct Doc No";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();

                FastDriver.EventTrackingLog.SelectEventCategory(@"Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                                FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 4, TableAction.Click);
                Support.AreEqual(UserIDTypes.ReversedUserID.ToLower(), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, @"[Disbursement Adjustment]", 4, TableAction.GetText).Message.ToLower());

                Reports.StatusUpdate("Verify whether comments contain the expected value", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Adjustment Reason: Correct Document No"));

                #endregion Add a 4rd survey detail
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_BAT0003

        #region Test FMUC0062_BAT0004

        [TestMethod]
        public void FMUC0062_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF2_00: Process a Change of Bank Account Number on a Disbursement";

                #region DataSetup

                var userID = AutoConfig.UserName;
                string reversedUserID = GetParsedUserIDWithSpace(userID: userID, IsToBeReversed: true);
                string[] tempArray1 = { "", "" };

                tempArray1 = userID.Split('\\');
                UserIDTypes.ReversedUserID = tempArray1[1].Substring(4, 4) + ", " + tempArray1[1].Substring(0, 4);
                UserIDTypes.SplitViewWithSpace = tempArray1[1].Substring(0, 4) + " " + tempArray1[1].Substring(4, 4);

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Give details for Buyer and Seller fields.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 2nd survey detail.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 3rd survey detail.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();

                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("250");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields.

                #region Print All Checks

                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog.";
                FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();

                #endregion Print All Checks

                #region Click on Adjust button select 1st charge.

                Reports.TestStep = "Click on Adjust button select 1st charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);
                else
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);

                FastDriver.DisbursementHistory.Adjust.FAClick();

                #endregion Click on Adjust button select 1st charge.

                #region ProcessOneSidedAdjstmentOnDisbrsment Cancel

                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");

                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion ProcessOneSidedAdjstmentOnDisbrsment Cancel

                #region ProcessOneSidedAdjstmentOnDisbrsment Repost

                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "CA", 2, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Reverse a One-Sided Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("REPOST", false, false, "comments for repost");
                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion ProcessOneSidedAdjstmentOnDisbrsment Repost

                #region Click on Adjust button for repost a cancelled one.

                Reports.TestStep = "Verify the status for the Adjusted item which is created for reposted disbursement.";

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                Support.AreEqual("C", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Tp.", TableAction.GetText).Message);

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "", "Amount", TableAction.GetText).Message.Trim());
                }
                else
                {
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "", "Amount", TableAction.GetText).Message.Trim());
                }

                Reports.TestStep = "Verify the adjusted item which is created for reposted disbursement.";
                Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Adjusted", "Tp.", TableAction.GetText).Message);

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", @"Iss/Adj", "Amount", TableAction.GetText).Message.Trim());
                    Support.AreEqual(@"5.00-", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Adjusted", "Amount", TableAction.GetText).Message.Trim());
                }
                else
                {
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", @"Iss/Adj", "Amount", TableAction.GetText).Message.Trim());
                    Support.AreEqual(@"14.00-", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Adjusted", "Amount", TableAction.GetText).Message.Trim());
                }

                #endregion Click on Adjust button for repost a cancelled one.

                #region Add a 4rd survey detail

                Reports.TestStep = "Add a 4rd survey detail.";
                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                FastDriver.SurveySummary.New.FAClick();
                FastDriver.SurveyDetail.GABcode.FASetText("251");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Manual button.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("ABCD");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                string checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                Reports.TestStep = "Save the document number.";
                string DocNum = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Adjust for Correct Adjustment.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", DocNum, "Document", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Process a Correct Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("Correct Document No", false, false);

                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the status for the Adjusted item which is created for Correct Doc No.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", "21456", "Tp.", TableAction.GetText).Message);

                Reports.TestStep = "Verify the adjusted item which is created for Correct Doc No.";
                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "5.00-", "Amount", TableAction.Click);
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "5.00", "Tp.", TableAction.Click);
                }
                else
                {
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "14.00-", "Amount", TableAction.Click);
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "14.00", "Tp.", TableAction.Click);
                }

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", @"Iss/Adj", "Amount", TableAction.Click);

                Reports.TestStep = "Verify for Adjustment Reason in comments of disbursement adjustment event for Correct Doc No";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();

                FastDriver.EventTrackingLog.SelectEventCategory(@"Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, @"[Disbursement Adjustment]", 4, TableAction.Click);
                Support.AreEqual(reversedUserID, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, @"[Disbursement Adjustment]", 4, TableAction.GetText).Message);

                Reports.StatusUpdate("Verify whether comments contain the expected value", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Adjustment Reason: Correct Document No"));

                #endregion Add a 4rd survey detail

                #region Add a 5rd survey detail

                Reports.TestStep = "Add a 5rd survey detail.";
                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText(@"252");
                FastDriver.SurveyDetail.Find.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText(@"survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText(@"1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText(@"1");
                FastDriver.BottomFrame.Done();

                #endregion Add a 5rd survey detail

                #region Click on Manual button

                Reports.TestStep = "Click on Manual button.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(@"Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                #endregion Click on Manual button

                #region Issue check

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("ABCD");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                #endregion Issue check

                #region Adjust for Correct Adjustment

                Reports.TestStep = "Click on Adjust for Correct Adjustment.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", checkNumber, "Status", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Process a Change of Bank Account Number on a Disbursement.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.AdjustmentDate.FAGetValue().Trim());

                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Correct Bank Acct");

                Support.AreEqual("false", FastDriver.DisbursementAdjustment.Description.IsEnabled().ToString().ToLower());
                Support.AreEqual("false", FastDriver.DisbursementAdjustment.Comment.IsEnabled().ToString().ToLower());
                Support.AreEqual("false", FastDriver.DisbursementAdjustment.UpdateTrustAccounting.IsEnabled().ToString().ToLower());

                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.PostedOn.FAGetText().Trim());

                Support.AreEqual(UserIDTypes.SplitViewWithSpace.ToUpper(), FastDriver.DisbursementAdjustment.PostedBy.FAGetText().Trim());
                FastDriver.DisbursementAdjustment.CorrectBankAcctNumber.FASelectItemByIndex(4);
                Support.AreEqual("true", FastDriver.DisbursementAdjustment.CorrectingTransDescription.FAGetValue().Contains(FastDriver.DisbursementAdjustment.PostedOn.FAGetText()).ToString().ToLower());
                Support.AreEqual("true", FastDriver.DisbursementAdjustment.CorrectingTransComment.IsDisplayed().ToString().ToLower());
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                #endregion Adjust for Correct Adjustment

                #region Verify

                Reports.TestStep = "Verify the status for the Adjusted item which is created for Correct Bank Account.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Amount", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify the adjusted item which is created for Correct Bank Acc.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                Support.AreEqual("0.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "M", "Amount", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify for Adjustment Reason in comments of disbursement adjustment event for Correct Bank Account";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.SelectEventCategory(@"Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 4, TableAction.Click);
                Support.AreEqual(UserIDTypes.ReversedUserID.ToLower(), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 4, TableAction.GetText).Message.ToLower());

                Reports.TestStep = "Verify for Adjustment Reason in comments of disbursement adjustment event";
                Reports.StatusUpdate("Adjustment Reason present in comments", FastDriver.EventTrackingLog.Comments.FAGetText().Contains(@"Adjustment Reason: Correct Bank Acct"));

                #endregion Verify
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_BAT0004

        #region Test FMUC0062_BAT0005

        [TestMethod]
        public void FMUC0062_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF4_00: Process an Ad-Hoc Disbursement Adjustment";

                #region DataSetup

                var userID = AutoConfig.UserName;
                string reversedUserID = GetParsedUserIDWithSpace(userID: userID, IsToBeReversed: true);
                string[] tempArray1 = { "", "" };

                tempArray1 = userID.Split('\\');
                UserIDTypes.ReversedUserID = tempArray1[1].Substring(4, 4) + ", " + tempArray1[1].Substring(0, 4);
                UserIDTypes.SplitViewWithSpace = tempArray1[1].Substring(0, 4) + " " + tempArray1[1].Substring(4, 4);

                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Give details for Buyer and Seller fields.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 2nd survey detail.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 3rd survey detail.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();

                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("250");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields.

                #region Print All Checks

                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog.";
                FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();

                #endregion Print All Checks

                #region Click on Adjust button select 1st charge.

                Reports.TestStep = "Click on Adjust button select 1st charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);
                else
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);

                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                FastDriver.DisbursementHistory.Adjust.FAClick();

                #endregion Click on Adjust button select 1st charge.

                #region ProcessOneSidedAdjstmentOnDisbrsment Cancel

                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");
                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion ProcessOneSidedAdjstmentOnDisbrsment Cancel

                #region ProcessOneSidedAdjstmentOnDisbrsment Repost

                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "CA", 2, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Reverse a One-Sided Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("REPOST", false, false, "comments for repost");
                FastDriver.BottomFrame.Save();

                FastDriver.WebDriver.HandleDialogMessage();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion ProcessOneSidedAdjstmentOnDisbrsment Repost

                #region Click on Adjust button for repost a cancelled one.

                Reports.TestStep = "Verify the status for the Adjusted item which is created for reposted disbursement.";

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                Support.AreEqual("C", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Tp.", TableAction.GetText).Message);

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "", "Amount", TableAction.GetText).Message.Trim());
                }
                else
                {
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "", "Amount", TableAction.GetText).Message.Trim());
                }

                Reports.TestStep = "Verify the adjusted item which is created for reposted disbursement.";
                Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Adjusted", "Tp.", TableAction.GetText).Message);

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", @"Iss/Adj", "Amount", TableAction.GetText).Message.Trim());
                    Support.AreEqual(@"5.00-", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Adjusted", "Amount", TableAction.GetText).Message.Trim());
                }
                else
                {
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", @"Iss/Adj", "Amount", TableAction.GetText).Message.Trim());
                    Support.AreEqual(@"14.00-", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Adjusted", "Amount", TableAction.GetText).Message.Trim());
                }

                #endregion Click on Adjust button for repost a cancelled one.

                #region Add a 4rd survey detail

                Reports.TestStep = "Add a 4rd survey detail.";
                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                FastDriver.SurveySummary.New.FAClick();
                FastDriver.SurveyDetail.GABcode.FASetText("251");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Manual button.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("ABCD");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                string checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                Reports.TestStep = "Save the document number.";
                string DocNum = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Adjust for Correct Adjustment.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", DocNum, "Document", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Process a Correct Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("Correct Document No", false, false);

                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the status for the Adjusted item which is created for Correct Doc No.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", "21456", "Tp.", TableAction.GetText).Message);

                Reports.TestStep = "Verify the adjusted item which is created for Correct Doc No.";
                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "5.00-", "Amount", TableAction.Click);
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "5.00", "Tp.", TableAction.Click);
                }
                else
                {
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "14.00-", "Amount", TableAction.Click);
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Amount", "14.00", "Tp.", TableAction.Click);
                }

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", @"Iss/Adj", "Amount", TableAction.Click);

                Reports.TestStep = "Verify for Adjustment Reason in comments of disbursement adjustment event for Correct Doc No";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();

                FastDriver.EventTrackingLog.SelectEventCategory(@"Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                                FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 4, TableAction.Click);
                Support.AreEqual(reversedUserID, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, @"[Disbursement Adjustment]", 4, TableAction.GetText).Message);

                Reports.StatusUpdate("Verify whether comments contain the expected value", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Adjustment Reason: Correct Document No"));

                #endregion Add a 4rd survey detail

                #region Add a 5rd survey detail

                Reports.TestStep = "Add a 5rd survey detail.";
                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText(@"252");
                FastDriver.SurveyDetail.Find.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText(@"survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText(@"1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText(@"1");
                FastDriver.BottomFrame.Done();

                #endregion Add a 5rd survey detail

                #region Click on Manual button

                Reports.TestStep = "Click on Manual button.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(@"Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                #endregion Click on Manual button

                #region Issue check

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("ABCD");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save(); FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                #endregion Issue check

                #region Adjust for Correct Adjustment

                Reports.TestStep = "Click on Adjust for Correct Adjustment.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", checkNumber, "Status", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Process a Change of Bank Account Number on a Disbursement.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.AdjustmentDate.FAGetValue().Trim());

                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem(@"Correct Bank Acct");

                Support.AreEqual("false", FastDriver.DisbursementAdjustment.Description.IsEnabled().ToString().ToLower());
                Support.AreEqual("false", FastDriver.DisbursementAdjustment.Comment.IsEnabled().ToString().ToLower());
                Support.AreEqual("false", FastDriver.DisbursementAdjustment.UpdateTrustAccounting.IsEnabled().ToString().ToLower());

                Support.AreEqual(CurrentPSTDate, FastDriver.DisbursementAdjustment.PostedOn.FAGetText().Trim());
                Support.AreEqual(UserIDTypes.SplitViewWithSpace.ToUpper(), FastDriver.DisbursementAdjustment.PostedBy.FAGetText().Trim());
                FastDriver.DisbursementAdjustment.CorrectBankAcctNumber.FASelectItemByIndex(4);
                Support.AreEqual("true", FastDriver.DisbursementAdjustment.CorrectingTransDescription.FAGetValue().Contains(FastDriver.DisbursementAdjustment.PostedOn.FAGetText()).ToString().ToLower());//zzzzzzzzzzzzzzzzzzz
                Support.AreEqual("true", FastDriver.DisbursementAdjustment.CorrectingTransComment.IsDisplayed().ToString().ToLower());
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                #endregion Adjust for Correct Adjustment

                #region Verify

                Reports.TestStep = "Verify the status for the Adjusted item which is created for Correct Bank Account.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("11.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Amount", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify the adjusted item which is created for Correct Bank Acc.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                Support.AreEqual("0.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "M", "Amount", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify for Adjustment Reason in comments of disbursement adjustment event for Correct Bank Account";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.SelectEventCategory(@"Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                                FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 4, TableAction.Click);
                Support.AreEqual(UserIDTypes.ReversedUserID.ToLower(), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 4, TableAction.GetText).Message.ToLower());

                Reports.TestStep = "Verify for Adjustment Reason in comments of disbursement adjustment event";
                Reports.StatusUpdate("Adjustment Reason present in comments", FastDriver.EventTrackingLog.Comments.FAGetText().Contains(@"Adjustment Reason: Correct Bank Acct"));

                #endregion Verify

                #region Click on Adhoc Adjustment button select 4th charge

                Reports.TestStep = "Click on Adhoc Adjustment button select 4th charge.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "CA", 2, TableAction.Click);
                FastDriver.DisbursementHistory.AdHocAdjustment.FAClick();

                Reports.TestStep = "Process an Ad-Hoc Disbursement Adjustment.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.DocumentNo.FASetText("9436");
                FastDriver.DisbursementAdjustment.Amount.FASetText("200.00");
                FastDriver.DisbursementAdjustment.IssueDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.DisbursementAdjustment.TypeOfFunds.FASelectItem("Check");

                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.AdjustmentDate.FAGetValue());
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Cancel");
                Support.AreEqual("Cancel " + DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.Description.FAGetValue().Trim());

                FastDriver.DisbursementAdjustment.Comment.FASetText("comments for adhoc adjs");
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.PostedOn.FAGetText().Trim());
                Support.AreEqual(UserIDTypes.SplitViewWithSpace.ToUpper(), FastDriver.DisbursementAdjustment.PostedBy.FAGetText().ToUpper().Trim());
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the status for the Adjusted item which is created for Adhoc adjustment.";

                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", "9436", "Tp.", TableAction.GetText).Message);
                Support.AreEqual(@"200.00-", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", "9436", "Amount", TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify the adjusted item which is created for Correct Bank Acc.";
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", "9436", "Status", TableAction.Click);

                Reports.TestStep = "Verify for Adjustment Reason in comments of disbursement adjustment event";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.SelectEventCategory(@"Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                                FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Disbursement Adjustment]", 4, TableAction.Click);
                Support.AreEqual(UserIDTypes.ReversedUserID.ToLower(), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, @"[Disbursement Adjustment]", 4, TableAction.GetText).Message.ToLower().Trim());
                Reports.StatusUpdate("Verify whether comments contain the expected value", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Adjustment Reason: Cancel"));

                #endregion Click on Adhoc Adjustment button select 4th charge
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_BAT0005

        #region Test FMUC0062_BAT0006

        [TestMethod]
        public void FMUC0062_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF5_00: Adjust Disbursement Issued in another Owning Office";

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Give details for Buyer and Seller fields.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 2nd survey detail.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 3rd survey detail.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();

                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("250");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields.

                #region Print All Checks

                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog."; FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();

                #endregion Print All Checks

                #region Click on Adjust button select 1st charge.

                Reports.TestStep = "Click on Adjust button select 1st charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                    //FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(7,"5.00",7,TableAction.Click);
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);
                else
                    //FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(7, "14.00", 7, TableAction.Click);
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);

                FastDriver.DisbursementHistory.Adjust.FAClick();

                #endregion Click on Adjust button select 1st charge.

                #region Process a One-Sided Adjustment on a Disbursement.

                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Done button.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                #endregion Process a One-Sided Adjustment on a Disbursement.

                #region Add a 4rd survey detail

                Reports.TestStep = "Add a 4rd survey detail.";
                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                FastDriver.SurveySummary.New.FAClick();
                FastDriver.SurveyDetail.GABcode.FASetText("251");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Manual button.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Advantage Mortgage", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("ABCD");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                string checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save(); FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                #endregion Add a 4rd survey detail

                #region Save the receipt number

                Reports.TestStep = "Save the receipt number.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                string checkNo = FastDriver.IssueManualCheck.CheckNo.FAGetValue();

                Reports.TestStep = "Click on Adjust for Correct Adjustment.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", checkNo, "Document", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Process a Correct Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("Correct Document No", false, false);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deposit a cash.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Amount.FASetText("17.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Initial Deposit");
                FastDriver.DepositInEscrow.Description.FASetText("Initial Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Abcd");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Owning Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(@"JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Yes button."; FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }

                #endregion Save the receipt number
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_BAT0006

        #region Test FMUC0062_BAT0007

        [TestMethod]
        public void FMUC0062_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF5_01: Verify for Error warming after change of office.";

                #region DataSetup

                string Message1 = @"Disbursement cannot be adjusted. If it was issued from the file's Title Owning Office account, please add Sub Escrow service in order to adjust the disbursement.";
                string Message2 = @"If it was issued from the file's Escrow Owning Office account, please add Escrow service in order to adjust the disbursement.";
                string Message3 = @"If it was issued from another owning office, please change the owning office back to the original office in which disbursement was issued in order to adjust the disbursement";

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Give details for Buyer and Seller fields.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 2nd survey detail.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 3rd survey detail.";
                //FastDriver.BottomFrame.SwitchToBottomFrame();
                //FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();

                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("250");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields.

                #region Print All Checks

                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog."; FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();

                #endregion Print All Checks

                #region Click on Adjust button select 1st charge.

                Reports.TestStep = "Click on Adjust button select 1st charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);
                else
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);

                FastDriver.DisbursementHistory.Adjust.FAClick();

                #endregion Click on Adjust button select 1st charge.

                #region Process a One-Sided Adjustment on a Disbursement.

                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Done button.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                #endregion Process a One-Sided Adjustment on a Disbursement.

                #region Add a 4rd survey detail

                Reports.TestStep = "Add a 4rd survey detail.";
                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                FastDriver.SurveySummary.New.FAClick();
                FastDriver.SurveyDetail.GABcode.FASetText("251");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Manual button.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Advantage Mortgage", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("ABCD");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                string checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save(); FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                #endregion Add a 4rd survey detail

                #region Save the receipt number

                Reports.TestStep = "Save the receipt number.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                string checkNo = FastDriver.IssueManualCheck.CheckNo.FAGetValue();

                Reports.TestStep = "Click on Adjust for Correct Adjustment.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", checkNo, "Document", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Process a Correct Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("Correct Document No", false, false);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deposit a cash.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Amount.FASetText("17.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Initial Deposit");
                FastDriver.DepositInEscrow.Description.FASetText("Initial Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Abcd");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Owning Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(@"JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Yes button."; FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }

                #endregion Save the receipt number

                #region Verify repost from different office

                Reports.TestStep = "Verify repost from different office.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(5, "21456", 5, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate the message when change the office and click on Adjust.";
                string IEmsgBoxValue = FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.StatusUpdate(IEmsgBoxValue, true);
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message1).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message2).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message3).ToString());

                #endregion Verify repost from different office
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_BAT0007

        #endregion BAT

        #region REG

        #region Test FMUC0062_REG0001

        [TestMethod]
        public void FMUC0062_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM1761_FM1758_ES7618_FM3081_FM1755: Select disbursement to adjust";

                #region DataSetup

                var userID = AutoConfig.UserName;
                string reversedUserID = GetParsedUserIDWithSpace(userID: userID, IsToBeReversed: true);

                string[] tempArray1 = { "", "" };

                tempArray1 = userID.Split('\\');
                UserIDTypes.ReversedUserID = tempArray1[1].Substring(4, 4) + ", " + tempArray1[1].Substring(0, 4);
                UserIDTypes.SplitViewWithSpace = tempArray1[1].Substring(0, 4) + " " + tempArray1[1].Substring(4, 4);

                string Message1 = @"Disbursement cannot be adjusted. If it was issued from the file's Title Owning Office account, please add Sub Escrow service in order to adjust the disbursement.";
                string Message2 = @"If it was issued from the file's Escrow Owning Office account, please add Escrow service in order to adjust the disbursement.";
                string Message3 = @"If it was issued from another owning office, please change the owning office back to the original office in which disbursement was issued in order to adjust the disbursement";

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                //string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                //FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create Order.

                #region Give details for Buyer and Seller fields.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 2nd survey detail.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 3rd survey detail.";
                //FastDriver.BottomFrame.SwitchToBottomFrame();
                //FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();

                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("250");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields.

                #region Print All Checks

                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog."; FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();

                #endregion Print All Checks

                #region Click on Adjust button select 1st charge.

                Reports.TestStep = "Click on Adjust button select 1st charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);
                else
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);

                FastDriver.DisbursementHistory.Adjust.FAClick();

                #endregion Click on Adjust button select 1st charge.

                #region Process a One-Sided Adjustment on a Disbursement.

                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                #endregion Process a One-Sided Adjustment on a Disbursement.

                #region Validate if Pend disb has created for one-sided adjustment.

                Reports.TestStep = "Validate if Pend disb has created for one-sided adjustment.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                //Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Pending", 8, TableAction.GetText).Message.Trim());
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Pending", 8, TableAction.SetText, "");

                Reports.TestStep = "Validate that the system shall prevent the user from adjusting a disbursement that was not issued in the file's current Escrow Owning Office. ";
                DepositCash("7.00", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(@"JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Yes button."; FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate the message when change the office and click on Adjust.";
                string IEmsgBoxValue = FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.StatusUpdate(IEmsgBoxValue, true);
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message1).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message2).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message3).ToString());

                Reports.TestStep = "Change the Owning Office to the one for which disbursements are issued.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Owning Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(AutoConfig.SelectedOfficeName + " PR: STEST Off: 7878 (1487)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Yes button."; FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }

                FastDriver.BottomFrame.Done();

                #endregion Validate if Pend disb has created for one-sided adjustment.
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0001

        #region Test FMUC0062_REG0002

        [TestMethod]
        public void FMUC0062_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM5321_2898: Reposting Disbur to Current Owning Office";
                ////added reg1

                #region DataSetup

                string Message1 = @"Disbursement cannot be adjusted. If it was issued from the file's Title Owning Office account, please add Sub Escrow service in order to adjust the disbursement.";
                string Message2 = @"If it was issued from the file's Escrow Owning Office account, please add Escrow service in order to adjust the disbursement.";
                string Message3 = @"If it was issued from another owning office, please change the owning office back to the original office in which disbursement was issued in order to adjust the disbursement";

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                //string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                //FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create Order.

                #region Give details for Buyer and Seller fields.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 2nd survey detail.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 3rd survey detail.";
                //FastDriver.BottomFrame.SwitchToBottomFrame();
                //FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();

                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("250");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields.

                #region Print All Checks

                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog."; FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();

                #endregion Print All Checks

                #region Click on Adjust button select 1st charge.

                Reports.TestStep = "Click on Adjust button select 1st charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);
                else
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);

                FastDriver.DisbursementHistory.Adjust.FAClick();

                #endregion Click on Adjust button select 1st charge.

                #region Process a One-Sided Adjustment on a Disbursement.

                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                #endregion Process a One-Sided Adjustment on a Disbursement.

                #region Validate if Pend disb has created for one-sided adjustment.

                Reports.TestStep = "Validate if Pend disb has created for one-sided adjustment.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                //Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Pending", 8, TableAction.GetText).Message.Trim());
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Pending", 8, TableAction.SetText, "");

                Reports.TestStep = "Validate that the system shall prevent the user from adjusting a disbursement that was not issued in the file's current Escrow Owning Office. ";
                DepositCash("7.00", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(@"JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Yes button."; FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate the message when change the office and click on Adjust.";
                string IEmsgBoxValue = FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.StatusUpdate(IEmsgBoxValue, true);
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message1).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message2).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message3).ToString());

                Reports.TestStep = "Change the Owning Office to the one for which disbursements are issued.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Owning Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(AutoConfig.SelectedOfficeName + " PR: STEST Off: 7878 (1487)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Yes button."; FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }

                FastDriver.BottomFrame.Done();

                #endregion Validate if Pend disb has created for one-sided adjustment.

                ////added reg1

                Reports.TestStep = "Click on Adjust button for repost a cancelled one.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "CA", 2, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Reverse a One-Sided Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("REPOST", false, false, "comments for repost");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Disbursement adjustment Validation for the adjustment reason Input Error.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "", 3, TableAction.GetText).Message);
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "", 3, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                ProcessOneSidedAdjstmentOnDisbrsment("Input Error", false, true, "comments for input error");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Save the description for input error adjustment.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                string description = FastDriver.DisbursementAdjustment.Description.FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Input Error adjustment in disbursement history and Repost the adjustment.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(9, description, 2, TableAction.GetText).Message.Trim());
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(9, description, 2, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                ProcessOneSidedAdjstmentOnDisbrsment("REPOST", false, false, "comments for REPOST");
                FastDriver.BottomFrame.Save();
                //FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Disbursement adjustment Validation for the adjustment reason Stop Payment.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "", 3, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                ProcessOneSidedAdjstmentOnDisbrsment("Stop Payment", false, true, "comments for Stop Payment");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Save the description for Stop Payment adjustment.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();

                description = FastDriver.DisbursementAdjustment.Description.FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Stop Payment adjustment in disbursement history and Repost the adjustment.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(9, description, 2, TableAction.GetText).Message.Trim());
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(9, description, 2, TableAction.Click);
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0002

        #region Test FMUC0062_REG0003

        [TestMethod]
        public void FMUC0062_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM2802_FM3080: Process an Ad-Hoc Disbursement Adjustment";
                ////add reg2
                ////added reg1

                #region DataSetup

                var userID = AutoConfig.UserName;
                string reversedUserID = GetParsedUserIDWithSpace(userID: userID, IsToBeReversed: true);

                string[] tempArray1 = { "", "" };

                tempArray1 = userID.Split('\\');
                UserIDTypes.ReversedUserID = tempArray1[1].Substring(4, 4) + ", " + tempArray1[1].Substring(0, 4);
                UserIDTypes.SplitViewWithSpace = tempArray1[1].Substring(0, 4) + " " + tempArray1[1].Substring(4, 4);

                string Message1 = @"Disbursement cannot be adjusted. If it was issued from the file's Title Owning Office account, please add Sub Escrow service in order to adjust the disbursement.";
                string Message2 = @"If it was issued from the file's Escrow Owning Office account, please add Escrow service in order to adjust the disbursement.";
                string Message3 = @"If it was issued from another owning office, please change the owning office back to the original office in which disbursement was issued in order to adjust the disbursement";

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                //string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                //FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #endregion Create Order.

                #region Give details for Buyer and Seller fields.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 2nd survey detail.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 3rd survey detail.";
                //FastDriver.BottomFrame.SwitchToBottomFrame();
                //FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();

                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("250");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields.

                #region Print All Checks

                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog."; FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();

                #endregion Print All Checks

                #region Click on Adjust button select 1st charge.

                Reports.TestStep = "Click on Adjust button select 1st charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);
                else
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);

                FastDriver.DisbursementHistory.Adjust.FAClick();

                #endregion Click on Adjust button select 1st charge.

                #region Process a One-Sided Adjustment on a Disbursement.

                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Done.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                #endregion Process a One-Sided Adjustment on a Disbursement.

                #region Validate if Pend disb has created for one-sided adjustment.

                Reports.TestStep = "Validate if Pend disb has created for one-sided adjustment.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                //Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Pending", 8, TableAction.GetText).Message.Trim());
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Pending", 8, TableAction.SetText, "");

                Reports.TestStep = "Validate that the system shall prevent the user from adjusting a disbursement that was not issued in the file's current Escrow Owning Office. ";
                DepositCash("7.00", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(@"JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Yes button."; FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate the message when change the office and click on Adjust.";
                string IEmsgBoxValue = FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.StatusUpdate(IEmsgBoxValue, true);
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message1).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message2).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message3).ToString());

                Reports.TestStep = "Change the Owning Office to the one for which disbursements are issued.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Owning Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(AutoConfig.SelectedOfficeName + " PR: STEST Off: 7878 (1487)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Yes button."; FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }

                FastDriver.BottomFrame.Done();

                #endregion Validate if Pend disb has created for one-sided adjustment.

                ////added reg1

                Reports.TestStep = "Click on Adjust button for repost a cancelled one.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "CA", 2, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Reverse a One-Sided Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("REPOST", false, false, "comments for repost");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Disbursement adjustment Validation for the adjustment reason Input Error.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "", 3, TableAction.GetText).Message);
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "", 3, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                ProcessOneSidedAdjstmentOnDisbrsment("Input Error", false, true, "comments for input error");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Save the description for input error adjustment.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                string description = FastDriver.DisbursementAdjustment.Description.FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Input Error adjustment in disbursement history and Repost the adjustment.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(9, description, 2, TableAction.GetText).Message.Trim());
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(9, description, 2, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                ProcessOneSidedAdjstmentOnDisbrsment("REPOST", false, false, "comments for REPOST");
                FastDriver.BottomFrame.Save();
                //FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Disbursement adjustment Validation for the adjustment reason 'Stop Payment'.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "", 3, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                ProcessOneSidedAdjstmentOnDisbrsment("Stop Payment", false, true, "comments for Stop Payment");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Save the description for Stop Payment adjustment.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();

                description = FastDriver.DisbursementAdjustment.Description.FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the Stop Payment adjustment in disbursement history and Repost the adjustment.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(9, description, 2, TableAction.GetText).Message.Trim());
                ////

                Reports.TestStep = "Click on Adhoc Adjustment button select 4th charge.";

                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "CA", 2, TableAction.Click);
                FastDriver.DisbursementHistory.AdHocAdjustment.FAClick();

                Reports.TestStep = "Validate Valid Reasons for Adhoc disbursement adjustment.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                Support.AreEqual("Cancel Input Error Stop Payment", FastDriver.DisbursementAdjustment.AdjustmentReason.FAGetText());

                Reports.TestStep = "Process an Ad-Hoc Disbursement Adjustment.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.DocumentNo.FASetText("9436");
                FastDriver.DisbursementAdjustment.Amount.FASetText("100.00");

                FastDriver.DisbursementAdjustment.IssueDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.DisbursementAdjustment.TypeOfFunds.FASelectItem("Check");
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.AdjustmentDate.FAGetValue().Trim());
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Cancel");

                Support.AreEqual("True", FastDriver.DisbursementAdjustment.Description.FAGetValue().Contains(DateTime.Now.ToDateString()).ToString());
                FastDriver.DisbursementAdjustment.Comment.FASetText("comments for adhoc adjs");

                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.PostedOn.FAGetText().Trim());
                Support.AreEqual(UserIDTypes.SplitViewWithSpace.ToUpper(), FastDriver.DisbursementAdjustment.PostedBy.FAGetText().Trim());
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate if No created or pending disb from ad-hoc.";

                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(8, "", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(5, "9436", 1, TableAction.GetText).Message.Trim());
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0003

        #region Test FMUC0062_REG0004

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0062_REG0004()
        {
            try
            {
                Reports.TestDescription = "FM2805_FM5320_FM5319_ES7617_1: Disbursing from Current Owning Office and adjusting from different Owning Office";

                #region DataSetup

                string Message1 = @"Disbursement cannot be adjusted. If it was issued from the file's Title Owning Office account, please add Sub Escrow service in order to adjust the disbursement.";
                string Message2 = @"If it was issued from the file's Escrow Owning Office account, please add Escrow service in order to adjust the disbursement.";
                string Message3 = @"If it was issued from another owning office, please change the owning office back to the original office in which disbursement was issued in order to adjust the disbursement";

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Give details for Buyer and Seller fields.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 2nd survey detail.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 3rd survey detail.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();

                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("250");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields.

                #region Print All Checks

                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog."; FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();

                #endregion Print All Checks

                #region Click on Adjust button select 1st charge.

                Reports.TestStep = "Click on Adjust button select 1st charge.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                    Support.AreEqualTrim("5.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);
                else
                    Support.AreEqualTrim("14.00", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Amount", TableAction.GetText).Message);

                FastDriver.DisbursementHistory.Adjust.FAClick();

                #endregion Click on Adjust button select 1st charge.

                #region Validate Valid Reasons for disbursement adjustment For Non-Manual issued checks

                Reports.TestStep = "Validate Valid Reasons for disbursement adjustment For Non-Manual issued checks.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                Support.AreEqual("Cancel Input Error Stale Date Stop Payment", FastDriver.DisbursementAdjustment.AdjustmentReason.FAGetText());

                Reports.TestStep = "Process a One-Sided Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion Validate Valid Reasons for disbursement adjustment For Non-Manual issued checks

                #region Add a 4th survey detail

                Reports.TestStep = "Add a 4th survey detail.";

                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("251");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Manual button.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                ////
                //FALibHS.m_errorMessage = "";
                //Mouse.Click(((UITestControlCollection)(FALibHS.GetControlByProperties("Id=dgDisbSmry_3", "HtmlRow").Get(HtmlRow.PropertyNames.Cells)))[7]);
                //if (FATAF.General.value == "False")
                //    General.Fail(FALibHS.m_errorMessage);
                ////
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue check.";

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("ABCD");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                string checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save(); FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                Reports.TestStep = "Save the document number.";
                string DocNum = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Adjust for Correct Adjustment.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", DocNum, "Document", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate Valid Reasons for disbursement adjustment For Manual issued checks.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                Support.AreEqual("Cancel Correct Bank Acct Correct Document No Input Error Stale Date Stop Payment", FastDriver.DisbursementAdjustment.AdjustmentReason.FAGetText());

                Reports.TestStep = "Process a Correct Adjustment on a Disbursement.";
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.AdjustmentDate.FAGetValue().Trim());
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem(@"Correct Bank Acct");

                Support.AreEqual("True", FastDriver.DisbursementAdjustment.CorrectingTransDescription.FAGetValue().Contains(DateTime.Now.ToDateString()).ToString());

                Support.AreEqual("false", FastDriver.DisbursementAdjustment.Description.IsEnabled().ToString().ToLower());
                Support.AreEqual("false", FastDriver.DisbursementAdjustment.Comment.IsEnabled().ToString().ToLower());
                Support.AreEqual("false", FastDriver.DisbursementAdjustment.UpdateTrustAccounting.IsEnabled().ToString().ToLower());

                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.PostedOn.FAGetText().Trim());
                Support.AreEqual(UserIDTypes.SplitViewWithSpace.ToUpper(), FastDriver.DisbursementAdjustment.PostedBy.FAGetText().Trim());
                Support.AreEqual("True", FastDriver.DisbursementAdjustment.CorrectBankAcctNumber.IsDisplayed().ToString());
                //FastDriver.DisbursementAdjustment.CorrectingTransDocumentNo.FASetText("21456");

                Support.AreEqual("true", FastDriver.DisbursementAdjustment.CorrectingTransDescription.FAGetValue().Contains(FastDriver.DisbursementAdjustment.PostedOn.FAGetText()).ToString().ToLower());
                Support.AreEqual("true", FastDriver.DisbursementAdjustment.CorrectingTransComment.IsDisplayed().ToString().ToLower());
                FastDriver.DisbursementAdjustment.CorrectBankAcctNumber.FASelectItemByIndex(4);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //Support.AreEqual("True", FastDriver.DisbursementAdjustment.CorrectingTransDescription.FAGetValue().Contains(FastDriver.DisbursementAdjustment.Description.FAGetValue()).ToString());
                //FastDriver.DisbursementAdjustment.CorrectingTransComment.FASetText("Comments1");
                //FastDriver.BottomFrame.Save();

                //Reports.TestStep = "Click on Cancel button.";
                //FastDriver.WebDriver.HandleDialogMessage(true, false);

                //Reports.TestStep = "Click on Done.";
                //FastDriver.BottomFrame.Done();

                //Reports.TestStep = "User attempts to navigate away without save changes.";
                //Support.AreEqual(@"Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "create an instance with charge-3.";

                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.SwitchToContentFrame();

                FastDriver.LeaseDetail.GABcode.FASetText("LEASE");
                FastDriver.LeaseDetail.Find.FAClick();
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Description1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("3");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Print for pending chk for lease payee";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "lease name 1 lease name 2", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog."; FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate that the system shall prevent the user from reposting a disbursement that was not issued in the file's current Escrow Owning Office. ";
                DepositCash("15.00", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(@"JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Yes button."; FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "CA", 3, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate the message when change the office and click on Adjust.";
                string IEmsgBoxValue = FastDriver.WebDriver.HandleDialogMessage(true, true);
                Reports.StatusUpdate(IEmsgBoxValue, true);
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message1).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message2).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message3).ToString());

                Reports.TestStep = "Change the Owning Office to the one for which disbursements are issued.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Escrow Owning Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(@"JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Yes button."; FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }

                ////
                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Open button and load the image document.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)

                Reports.TestStep = "Save the TIF Doc.";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Verify that Document is uploaded to the FAST.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "PO-Invoice AFFIX INV", 4, TableAction.Click);
                ////

                Reports.TestStep = "Select the disbursement with pending status";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click);

                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                ConvertToWire();

                Reports.TestStep = "Click Edit on Created Status.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                }
                else
                {
                    FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);
                }
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                ConvertToWire();

                Reports.TestStep = "Disburse Wire.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();

                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick(); FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                Reports.TestStep = "Click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "W", 3, TableAction.Click);

                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate Valid Reasons for disbursement adjustment For Wire.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                Support.AreEqual("Cancel Input Error Stop Payment", FastDriver.DisbursementAdjustment.AdjustmentReason.FAGetText());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on OK button.";
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion Add a 4th survey detail
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0004

        #region Test FMUC0062_REG0005

        [TestMethod]
        public void FMUC0062_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM5319_Disbur info on Old Owning Office.";

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                EnterFeeInTitleEscrowTab();

                Reports.TestStep = "Click on Fee Transfer Button.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Handle Overdraft Confirmation Dialog."; FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                Reports.TestStep = "Click on Cancel.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();

                //PasswordOrOverdraftConfirmationDialog();

                Reports.TestStep = "Print the checks.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Store the old owning office details.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "F", 3, TableAction.Click);
                FastDriver.DisbursementHistory.ViewDetails.FAClick();

                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.VoucherChargeDetail);
                FastDriver.EditDisbursement.OpenDisbDetails.FAClick();

                string FromAccNum = FastDriver.EditDisbursement.FromAccount.FAGetSelectedItem();
                string BankCode = FastDriver.EditDisbursement.BankCode.FAGetValue();
                string BankName = FastDriver.EditDisbursement.BankName.FAGetValue();
                string PostedOnDate = FastDriver.EditDisbursement.PostedOnDate.FAGetValue();

                Reports.TestStep = "Validate Disbur info of Old Owning Office after owning office change.";
                DepositCash("4.98", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Change OO button."; FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);

                Reports.TestStep = "Change Escrow Owning Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(@"JVR Office PR: STEST Off: 1234 (2379)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Yes button."; FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }

                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ChangeOwningOfficeRemoveServiceType.Ten99SError.FAGetText().Contains("Service File: File has issued fee disbursements. You cannot change the Owning Office or remove Service Type.").ToString());

                Reports.TestStep = "Change Escrow Owning Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.EscrowOwningOffice.FASelectItem(AutoConfig.SelectedOfficeName + " PR: STEST Off: 7878 (1487)");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Yes button."; FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Deposits summary page.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "F", 3, TableAction.Click);
                FastDriver.DisbursementHistory.ViewDetails.FAClick();

                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.VoucherChargeDetail);
                FastDriver.EditDisbursement.OpenDisbDetails.FAClick();
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0005

        #region Test FMUC0062_REG0006

        [TestMethod]
        public void FMUC0062_REG0006()
        {
            try
            {
                Reports.TestDescription = "ES7614_ES7615: Disbursement Adjustments for Title Only File";

                #region DataSetup

                string Message1 = @"Disbursement cannot be adjusted. If it was issued from the file's Title Owning Office account, please add Sub Escrow service in order to adjust the disbursement.";
                string Message2 = @"If it was issued from the file's Escrow Owning Office account, please add Escrow service in order to adjust the disbursement.";
                string Message3 = @"If it was issued from another owning office, please change the owning office back to the original office in which disbursement was issued in order to adjust the disbursement";

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                FastDriver.SurveyDetail.GABcode.FASetText("248");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }

                Reports.TestStep = "Click on New button.";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Add a 2nd survey detail.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("247");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 3rd survey detail.";
                Reports.TestStep = "Add a 3rd survey detail.";
                //FastDriver.BottomFrame.SwitchToBottomFrame();
                //FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();

                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("250");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.Clear();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Print All Checks.";

                #region Print All Checks

                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog."; FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                    Playback.Wait(10000);
                }

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();

                #endregion Print All Checks

                Reports.TestStep = "Click on Adjust button select 1st charge.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(8, "Midwest Financial Group 500 Cascade West", 8, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a 4th survey detail.";
                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("251");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Manual button.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Advantage Mortgage", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("ABCD");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                string checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save(); FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                //PasswordOrOverdraftConfirmationDialog();

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                Reports.TestStep = "Save the document number.";
                string DocNum = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Adjust for Correct Adjustment.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", DocNum, "Document", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Process a Correct Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("Correct Document No", false, false);

                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                DepositCash("9.00", "Cash", "Initial Deposit", "Initial Deposit", "Buyer", "Abcd");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify repost adjustment from different office.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(5, "21456", 5, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate the message for for Title Only File when adjust button is clicked.";
                string IEmsgBoxValue = FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.StatusUpdate(IEmsgBoxValue, true);
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message1).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message2).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message3).ToString());

                Reports.TestStep = "Verify adjustment from different office.";
                FastDriver.DisbursementHistory.WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(1, "Issued", 1, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate the message for for Title Only File when adjust button is clicked.";
                IEmsgBoxValue = FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.StatusUpdate(IEmsgBoxValue, true);
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message1).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message2).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message3).ToString());
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
            //Assert.AreEqual(true, Reports.TestResult, "TestSuccess:Refer Test Reports for Details");
        }

        #endregion Test FMUC0062_REG0006

        #region Test FMUC0062_REG0007

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0062_REG0007()
        {
            try
            {
                Reports.TestDescription = "ES7619: Restrict Void and adj after transmittal to wire interface";

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Validate for pending file before the start.

                Reports.TestStep = "Validate for pending file before the start.";
                FastDriver.LeftNavigation.Navigate<TrustAccounting>("Home>Business Unit Processing>Trust Accounting Interface").WaitForScreenToLoad(FastDriver.TrustAccounting.DiscardExtract);

                if (FastDriver.TrustAccounting.Status.FAGetText() == "Pending")
                {
                    Reports.TestStep = "Click on Trasmit Now button.";
                    FastDriver.TrustAccounting.TransmitNow.FAClick();

                    Reports.TestStep = "Click on Ok button.";
                    FastDriver.WebDriver.HandleDialogMessage();
                }

                #endregion Validate for pending file before the start.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Give details for Buyer and Seller fields

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("248");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields

                #region Disburse the survey

                Reports.TestStep = "Disburse the survey.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Midwest Financial Group", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                #endregion Disburse the survey

                #region Issue check

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("ABCD");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                string checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save(); FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                Reports.TestStep = "Click on BuildExtract";
                FastDriver.LeftNavigation.Navigate<TrustAccounting>("Home>Business Unit Processing>Trust Accounting Interface").WaitForScreenToLoad(FastDriver.TrustAccounting.DiscardExtract);
                FastDriver.TrustAccounting.BuildExtract.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate for pending file.";
                FastDriver.LeftNavigation.Navigate<TrustAccounting>("Home>Business Unit Processing>Trust Accounting Interface").WaitForScreenToLoad(FastDriver.TrustAccounting.DiscardExtract);
                Support.AreEqual("Pending", FastDriver.TrustAccounting.Status.FAGetText());

                Reports.TestStep = "Click on Trasmit Now button.";
                FastDriver.LeftNavigation.Navigate<TrustAccounting>("Home>Business Unit Processing>Trust Accounting Interface").WaitForScreenToLoad(FastDriver.TrustAccounting.DiscardExtract);
                FastDriver.TrustAccounting.TransmitNow.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verifying for the void button once transmitted to trust32";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Midwest Financial Group", "Status", TableAction.Click);
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Midwest Financial Group", "Status", TableAction.GetText).Message);
                Reports.StatusUpdate("Verifying for the void button once transmitted to trust32", FastDriver.ActiveDisbursementSummary.Void.IsEnabled());

                Reports.TestStep = "Validate for pending file before the start.";
                FastDriver.LeftNavigation.Navigate<TrustAccounting>("Home>Business Unit Processing>Trust Accounting Interface").WaitForScreenToLoad(FastDriver.TrustAccounting.DiscardExtract);

                if (FastDriver.TrustAccounting.Status.FAGetText() == "Pending")
                {
                    Reports.TestStep = "Click on Trasmit Now button.";
                    FastDriver.TrustAccounting.TransmitNow.FAClick();

                    Reports.TestStep = "Click on Ok button.";
                    FastDriver.WebDriver.HandleDialogMessage();
                }

                Reports.TestStep = "Restrict Void after transmittal to wire interface for wire transmittal.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>("Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.GABcode.FASetText("LEASE");
                FastDriver.LeaseDetail.Find.FAClick();
                FastDriver.LeaseDetail.ChargeDescription.FASetText("Description1");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("3");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForPageToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Open button and load the image document.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)

                Reports.TestStep = "Save the TIF Doc.";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Verify that Document is uploaded to the FAST.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "PO-Invoice AFFIX INV", 4, TableAction.Click);

                Reports.TestStep = "Select the disbursement with pending status";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click);

                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                ConvertToWire();

                Reports.TestStep = "Click Edit on Created Status.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                }
                else
                {
                    FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Created", "Status", TableAction.Click);
                }

                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.VoucherChargeDetail);
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.EditDisbursement.Add.FAClick();

                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.SelectWireInstructionsDlg.SelectWireInstruction();

                Reports.TestStep = "Verify from document repository and click on save.";
                FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.VoucherChargeDetail);
                //FALibHS.GetControlByProperties("InnerText" + "=" + "From Document Repository", "HtmlPane").FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Disburse Wire.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();

                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick(); FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                Reports.TestStep = "Click on BuildExtract";
                FastDriver.LeftNavigation.Navigate<TrustAccounting>("Home>Business Unit Processing>Trust Accounting Interface").WaitForScreenToLoad(FastDriver.TrustAccounting.DiscardExtract);
                FastDriver.TrustAccounting.BuildExtract.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate for pending file.";
                FastDriver.LeftNavigation.Navigate<TrustAccounting>("Home>Business Unit Processing>Trust Accounting Interface").WaitForScreenToLoad(FastDriver.TrustAccounting.DiscardExtract);
                Support.AreEqual(@"Pending", FastDriver.TrustAccounting.Status.FAGetText());

                Reports.TestStep = "Click on Trasmit Now button.";
                FastDriver.LeftNavigation.Navigate<TrustAccounting>("Home>Business Unit Processing>Trust Accounting Interface").WaitForScreenToLoad(FastDriver.TrustAccounting.DiscardExtract);
                FastDriver.TrustAccounting.TransmitNow.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verifying for the void button once transmitted to trust32";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "lease name 1 lease name 2", "Status", TableAction.Click);
                Reports.StatusUpdate("Verifying for the void button once transmitted to trust32", FastDriver.ActiveDisbursementSummary.Void.IsEnabled());

                #endregion Issue check
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0007

        #region Test FMUC0062_REG0008

        [TestMethod]
        public void FMUC0062_REG0008()
        {
            try
            {
                Reports.TestDescription = "ES7616_EWC4: Disable Adj of Title Owning Office's Disb for Title + Escrow";

                #region DataSetup

                string Message1 = @"Disbursement cannot be adjusted. If it was issued from the file's Title Owning Office account, please add Sub Escrow service in order to adjust the disbursement.";
                string Message2 = @"If it was issued from the file's Escrow Owning Office account, please add Escrow service in order to adjust the disbursement.";
                string Message3 = @"If it was issued from another owning office, please change the owning office back to the original office in which disbursement was issued in order to adjust the disbursement";

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Give details for Buyer and Seller fields

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("248");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields

                #region Disburse the survey

                Reports.TestStep = "Disburse the survey.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Midwest Financial Group", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                #endregion Disburse the survey

                #region Issue check

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("ABCD");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                string checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save(); FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                Reports.TestStep = "Deposit a cash of 14 on behalf of buyer.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.DepositInEscrow.Amount.FASetText(@"14.00");
                }
                else
                {
                    FastDriver.DepositInEscrow.Amount.FASetText(@"5.00");
                }

                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Initial Deposit");
                FastDriver.DepositInEscrow.Description.FASetText("Initial Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Abcd");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Click on Change OO button."; FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Remove Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);

                Reports.TestStep = "Remove Sub Escrow Service Type.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.SubEscrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Change OO button.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();

                Reports.TestStep = "Change Title Owning Office.";
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItem(@"JVR Office PR: STEST Off: 1234 (2379)"); //commented for IMD - HUD Type - 13-May-2015 12:55 AM
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Yes button."; FastDriver.WebDriver.HandleDialogMessage();
                if (FastDriver.ChangeOwningOfficeRemoveServiceType.IsAssignEscrowTasksDialogPresent())
                {
                    FastDriver.ChangeOwningOfficeRemoveServiceType.AssignEscrowTasksWindow();
                }

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Adjust."; FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(7, "14.00", 7, TableAction.Click);
                }
                else
                {
                    FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(7, "5.00", 7, TableAction.Click);
                }

                FastDriver.DisbursementHistory.Adjust.FAClick();
                Reports.TestStep = "Validate the message when change the office and click on Adjust.";
                string IEmsgBoxValue = FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.StatusUpdate(IEmsgBoxValue, true);
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message1).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message2).ToString());
                Support.AreEqual("True", IEmsgBoxValue.Contains(Message3).ToString());

                #endregion Issue check
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0008

        #region Test FMUC0062_REG0009

        [TestMethod]
        public void FMUC0062_REG0009()
        {
            try
            {
                Reports.TestDescription = "ES10060_1: Creating and Adjusting an IBA Disbursement";

                #region DataSetup

                string Message1 = @"Disbursement cannot be adjusted. If it was issued from the file's Title Owning Office account, please add Sub Escrow service in order to adjust the disbursement.";
                string Message2 = @"If it was issued from the file's Escrow Owning Office account, please add Escrow service in order to adjust the disbursement.";
                string Message3 = @"If it was issued from another owning office, please change the owning office back to the original office in which disbursement was issued in order to adjust the disbursement";

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Deposit a Cash of 10 on behalf of Buyer

                Reports.TestStep = "Deposit a Cash of 10 on behalf of Buyer.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Amount.FASetText("10.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Initial Deposit");
                FastDriver.DepositInEscrow.Description.FASetText("Initial Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Abcd");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";

                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                IBABeneficiary Beneficiary = new IBABeneficiary()
                {
                    BeneficiaryName = "Beneficiary Name1",
                    AddressLine1 = "Beneficiary Name1 Address Line 1",
                    AddressLine2 = "Beneficiary Name1 Address Line 2",
                    City = "Beneficiary Name1 Santa ana",
                    State = "CA",
                    ZipCode = "92727",
                    selectSSN = true,
                    SSNTINnumber = "123456789",
                };

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FASetCheckbox(false);
                FastDriver.SelectIBABeneficiaryDlg.AddOtherBeneficiary(Beneficiary);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Deposit a Cash of 10 on behalf of Buyer

                #region Select the IBA account details.

                Reports.TestStep = "Navigate to IBA screen and selecting the IBA Bank.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Select a IBA product if it is empty.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                if (FastDriver.InterestBearingAccounts.IBAType.FAGetSelectedItem() == "")
                {
                    FastDriver.InterestBearingAccounts.IBAType.FASelectItemByIndex(1);
                }

                #endregion Select the IBA account details.

                #region Enter transaction amount and Save.

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Transactions);
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                FastDriver.BottomFrame.Save();

                #endregion Enter transaction amount and Save.

                Reports.TestStep = "Verify that adhoc button is disabled for Issued IBA";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
                Support.AreEqual("False", FastDriver.DisbursementHistory.AdHocAdjustment.IsEnabled().ToString());
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0009

        #region Test FMUC0062_REG0010

        [TestMethod]
        public void FMUC0062_REG0010()
        {
            try
            {
                Reports.TestDescription = "ES10060_2: Approving an IBA Disbursement";

                ////copy reg09

                #region DataSetup

                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Deposit a Cash of 10 on behalf of Buyer

                Reports.TestStep = "Deposit a Cash of 10 on behalf of Buyer.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Amount.FASetText("10.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Initial Deposit");
                FastDriver.DepositInEscrow.Description.FASetText("Initial Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Abcd");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";

                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                IBABeneficiary Beneficiary = new IBABeneficiary()
                {
                    BeneficiaryName = "Beneficiary Name1",
                    AddressLine1 = "Beneficiary Name1 Address Line 1",
                    AddressLine2 = "Beneficiary Name1 Address Line 2",
                    City = "Beneficiary Name1 Santa ana",
                    State = "CA",
                    ZipCode = "92727",
                    selectSSN = true,
                    SSNTINnumber = "123456789",
                };

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FASetCheckbox(false);
                FastDriver.SelectIBABeneficiaryDlg.AddOtherBeneficiary(Beneficiary);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Deposit a Cash of 10 on behalf of Buyer

                #region Select the IBA account details.

                Reports.TestStep = "Navigate to IBA screen and selecting the IBA Bank.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Select a IBA product if it is empty.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                if (FastDriver.InterestBearingAccounts.IBAType.FAGetSelectedItem() == "")
                {
                    FastDriver.InterestBearingAccounts.IBAType.FASelectItemByIndex(1);
                }

                #endregion Select the IBA account details.

                #region Enter transaction amount and Save.

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Transactions);
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                FastDriver.BottomFrame.Save();

                #endregion Enter transaction amount and Save.

                Reports.TestStep = "Verify that adhoc button is disabled for Issued IBA";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
                Support.AreEqual("False", FastDriver.DisbursementHistory.AdHocAdjustment.IsEnabled().ToString());
                ////

                #region Login with second user & Approve IBA Transaction

                Reports.TestStep = "Login with second user & Approve IBA Transaction";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);

                #endregion Login with second user & Approve IBA Transaction

                #region Navigate to File

                Reports.TestStep = "Enter file number.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber1);

                #endregion Navigate to File

                #region Approve the Transaction

                Reports.TestStep = "Approve the Transaction.";
                FastDriver.IBATransactionApproval.Open();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(2, FileNumber1, 1, TableAction.On);
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.IBATransactionApproval.WaitForApproveEnabled();
                FastDriver.IBATransactionApproval.Approve.Click();
                FastDriver.WebDriver.HandleDialogMessage();

                if (FastDriver.IBATransactionPastBankCutoffTimeDlg.IsDisplayed())
                {
                    FastDriver.IBATransactionPastBankCutoffTimeDlg.WaitForScreenToLoad();
                    FastDriver.DialogBottomFrame.ClickDone();
                }

                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify system removes the File Number after approvin the IBA.";
                FastDriver.IBATransactionApproval.Open();
                string abc = FastDriver.IBATransactionApproval.TransactionTable.FAGetText();
                Support.AreEqual(false.ToString(), FastDriver.IBATransactionApproval.TransactionTable.FAGetText().Contains(FileNumber1).ToString());

                Reports.TestStep = "Search for the record approved.";
                FastDriver.IBATransactionSummary.Open();

                string FromDate = DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("MM/dd/yyyy");
                FromDate = FromDate.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(FromDate);

                string ToDate = DateTime.Today.AddDays(Convert.ToInt32("1")).ToString("MM/dd/yyyy");
                ToDate = ToDate.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(ToDate);

                FastDriver.IBATransactionSummary.FindNow.FAClick();
                FastDriver.IBATransactionSummary.WaitForTransactionTableResults();

                FastDriver.IBATransactionSummary.Table.PerformTableAction(1, FileNumber1, 1, TableAction.Click);

                #endregion Approve the Transaction
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0010

        #region Test FMUC0062_REG0011

        [TestMethod]
        public void FMUC0062_REG0011()
        {
            try
            {
                Reports.TestDescription = "ES10060_3: Adjusting an approved IBA Disbursement";
                ////copy reg10
                ////copy reg09

                #region DataSetup

                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Deposit a Cash of 10 on behalf of Buyer

                Reports.TestStep = "Deposit a Cash of 10 on behalf of Buyer.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Amount.FASetText("10.00");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Initial Deposit");
                FastDriver.DepositInEscrow.Description.FASetText("Initial Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Abcd");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Navigate to IBA screen and creating new Beneficiary.";

                FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts").WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.New.FAClick();
                FastDriver.InterestBearingAccounts.Beneficiary.FAClick();
                IBABeneficiary Beneficiary = new IBABeneficiary()
                {
                    BeneficiaryName = "Beneficiary Name1",
                    AddressLine1 = "Beneficiary Name1 Address Line 1",
                    AddressLine2 = "Beneficiary Name1 Address Line 2",
                    City = "Beneficiary Name1 Santa ana",
                    State = "CA",
                    ZipCode = "92727",
                    selectSSN = true,
                    SSNTINnumber = "123456789",
                };

                Reports.TestStep = "Add other Beneficiary details.";
                FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
                FastDriver.SelectIBABeneficiaryDlg.OthersSelect.FASetCheckbox(false);
                FastDriver.SelectIBABeneficiaryDlg.AddOtherBeneficiary(Beneficiary);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Deposit a Cash of 10 on behalf of Buyer

                #region Select the IBA account details.

                Reports.TestStep = "Navigate to IBA screen and selecting the IBA Bank.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                FastDriver.InterestBearingAccounts.IBABank.FAClick();

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Select a IBA product if it is empty.";
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad();
                if (FastDriver.InterestBearingAccounts.IBAType.FAGetSelectedItem() == "")
                {
                    FastDriver.InterestBearingAccounts.IBAType.FASelectItemByIndex(1);
                }

                #endregion Select the IBA account details.

                #region Enter transaction amount and Save.

                Reports.TestStep = "Enter the Transaction Amount and saving.";
                FastDriver.InterestBearingAccounts.clickOnTransactionsTab();
                FastDriver.InterestBearingAccounts.WaitForScreenToLoad(FastDriver.InterestBearingAccounts.Transactions);
                FastDriver.InterestBearingAccounts.TransactionAmount.FASetText("10");
                FastDriver.BottomFrame.Save();

                #endregion Enter transaction amount and Save.

                Reports.TestStep = "Verify that adhoc button is disabled for Issued IBA";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();

                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
                Support.AreEqual("False", FastDriver.DisbursementHistory.AdHocAdjustment.IsEnabled().ToString());
                ////

                #region Login with second user & Approve IBA Transaction

                Reports.TestStep = "Login with second user & Approve IBA Transaction";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);

                #endregion Login with second user & Approve IBA Transaction

                #region Navigate to File

                Reports.TestStep = "Enter file number.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber1);

                #endregion Navigate to File

                #region Approve the Transaction

                Reports.TestStep = "Approve the Transaction.";
                FastDriver.IBATransactionApproval.Open();
                FastDriver.IBATransactionApproval.Select_None.FAClick();
                FastDriver.IBATransactionApproval.TransactionTable.PerformTableAction(2, FileNumber1, 1, TableAction.On);
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.IBATransactionApproval.WaitForApproveEnabled();
                FastDriver.IBATransactionApproval.Approve.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.HandleDialogMessage();

                if (FastDriver.IBATransactionPastBankCutoffTimeDlg.IsDisplayed())
                {
                    FastDriver.IBATransactionPastBankCutoffTimeDlg.WaitForScreenToLoad();
                    FastDriver.DialogBottomFrame.ClickDone();
                }

                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify system removes the File Number after approvin the IBA.";
                FastDriver.IBATransactionApproval.Open();
                Support.AreEqual(false.ToString(), FastDriver.IBATransactionApproval.TransactionTable.FAGetText().Contains(FileNumber1).ToString());

                Reports.TestStep = "Search for the record approved.";
                FastDriver.IBATransactionSummary.Open();

                string FromDate = DateTime.Today.AddDays(Convert.ToInt32("-1")).ToString("MM/dd/yyyy");
                FromDate = FromDate.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueFromDate.FASetText(FromDate);

                string ToDate = DateTime.Today.AddDays(Convert.ToInt32("1")).ToString("MM/dd/yyyy");
                ToDate = ToDate.Replace("/", "-");
                FastDriver.IBATransactionSummary.IssueToDate.FASetText(ToDate);

                FastDriver.IBATransactionSummary.FindNow.FAClick();
                FastDriver.IBATransactionSummary.WaitForTransactionTableResults();

                FastDriver.IBATransactionSummary.Table.PerformTableAction(1, FileNumber1, 1, TableAction.Click);

                #endregion Approve the Transaction

                ////

                #region Login with first user & verify IBA Approval

                Reports.TestStep = "Login with first user & verify IBA Approval";
                MasterTestClass.PerformRequiredRegistrySettings();
                IISLOGIN(AutoConfig.UserName, AutoConfig.UserPassword);

                #endregion Login with first user & verify IBA Approval

                #region Navigate to File

                Reports.TestStep = "Enter file number.";
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber1);

                #endregion Navigate to File

                #region Verify that adhoc button is disabled for Issued IBA

                Reports.TestStep = "Verify that adhoc button is disabled for Issued IBA";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
                Support.AreEqual("False", FastDriver.DisbursementHistory.AdHocAdjustment.IsEnabled().ToString());

                #endregion Verify that adhoc button is disabled for Issued IBA
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0011

        #region Test FMUC0062_REG0012

        [TestMethod]
        public void FMUC0062_REG0012()
        {
            try
            {
                Reports.TestDescription = "FM2035_FM2998_EWC2: Adjust correcting entry";

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create a Title Sub Escrow File.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Give details for Buyer and Seller fields

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields

                #region Disburse the survey

                Reports.TestStep = "Disburse the survey.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Midwest Financial Group", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                #endregion Disburse the survey

                #region Issue check

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("Abcd");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                string checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save(); FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                Reports.TestStep = "Click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Correct Document No Adjustment on a Disbursement.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Correct Document No");
                FastDriver.DisbursementAdjustment.Description.FASetText("Description for Correct Doc No");
                FastDriver.DisbursementAdjustment.CorrectingTransDocumentNo.FASetText("1111111111");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the CA for Correct Doc no can be adjusted.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "CA", 3, TableAction.Click);
                Support.AreEqual("True", FastDriver.DisbursementHistory.Adjust.IsEnabled().ToString());

                Reports.TestStep = "Verify the CA for Correct Doc no can be adjusted.";
                Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(9, "Description for Correct Doc No", 3, TableAction.GetText).Message);

                Reports.TestStep = "Verify the CA for Correct Doc no can be adjusted.";
                Support.AreEqual("CA", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(5, "1111111111", 3, TableAction.GetText).Message);

                #endregion Issue check
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0012

        #region Test FMUC0062_REG0013

        [TestMethod]
        public void FMUC0062_REG0013()
        {
            try
            {
                Reports.TestDescription = "FM3013_FM3007_FM3012: Event for adjustments";

                #region Data Setup

                var userID = AutoConfig.UserName;
                string reversedUserID = GetParsedUserIDWithSpace(userID: userID, IsToBeReversed: true);

                string[] tempArray1 = { "", "" };

                tempArray1 = userID.Split('\\');
                UserIDTypes.ReversedUserID = tempArray1[1].Substring(4, 4) + ", " + tempArray1[1].Substring(0, 4);
                UserIDTypes.SplitViewWithSpace = tempArray1[1].Substring(0, 4) + " " + tempArray1[1].Substring(4, 4);

                #endregion Data Setup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create a Title Sub Escrow File.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Give details for Buyer and Seller fields

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                #endregion Give details for Buyer and Seller fields

                #region Disburse the survey

                Reports.TestStep = "Disburse the survey.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                #endregion Disburse the survey

                #region Issue check

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("ABCD");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                string checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save(); FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                #endregion Issue check

                #region Adjust for Correct Adjustment

                Reports.TestStep = "Click on Adjust for Correct Adjustment.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Document", checkNumber, "Status", TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Process a Change of Bank Account Number on a Disbursement.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.AdjustmentDate.FAGetValue().Trim());

                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem(@"Correct Bank Acct");

                Support.AreEqual("false", FastDriver.DisbursementAdjustment.Description.IsEnabled().ToString().ToLower());
                Support.AreEqual("false", FastDriver.DisbursementAdjustment.Comment.IsEnabled().ToString().ToLower());
                Support.AreEqual("false", FastDriver.DisbursementAdjustment.UpdateTrustAccounting.IsEnabled().ToString().ToLower());

                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.PostedOn.FAGetText().Trim());
                Support.AreEqual(UserIDTypes.SplitViewWithSpace.ToUpper(), FastDriver.DisbursementAdjustment.PostedBy.FAGetText().Trim());
                FastDriver.DisbursementAdjustment.CorrectBankAcctNumber.FASelectItemByIndex(4);
                Support.AreEqual("true", FastDriver.DisbursementAdjustment.CorrectingTransDescription.FAGetValue().Contains(FastDriver.DisbursementAdjustment.PostedOn.FAGetText()).ToString().ToLower());
                Support.AreEqual("true", FastDriver.DisbursementAdjustment.CorrectingTransComment.IsDisplayed().ToString().ToLower());
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                #endregion Adjust for Correct Adjustment

                #region Verifying for Disbursement adjustment event

                Reports.TestStep = "Verifying for Disbursement adjustment event";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory(@"Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();

                Reports.TestStep = "Verify details in disbursement adjustment event";
                Reports.StatusUpdate("EventTrackingLog Comments : " + FastDriver.EventTrackingLog.Comments.FAGetText(), true);
                Support.AreEqual(UserIDTypes.ReversedUserID.ToUpper(), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, @"[Disbursement Adjustment]", 4, TableAction.GetText).Message);
                Reports.StatusUpdate("Adjustment Reason present in comments", FastDriver.EventTrackingLog.Comments.FAGetText().Contains(@"Adjustment Reason: Correct Bank Acct"));
                Reports.StatusUpdate("Verify for Document Number", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Document Number: " + checkNumber));

                if (AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    Reports.StatusUpdate("Verify for Amount", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Amount: 5.00"));
                }
                else
                {
                    Reports.StatusUpdate("Verify for Amount", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Amount: 14.00"));
                }

                Reports.StatusUpdate("Verify for Issue Date", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Issue Date: " + DateTime.Now.ToString("M/d/yyyy")));
                Reports.StatusUpdate("Verify for Banking Account Number", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Disbursing Bank Account: "));
                Reports.StatusUpdate("Verify for Corrected to", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Corrected To:XXX"));
                Reports.StatusUpdate("Verify for Update Trust Accounting", FastDriver.EventTrackingLog.Comments.FAGetText().Contains("Update Trust Accounting=Yes"));

                #endregion Verifying for Disbursement adjustment event
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0013

        #region Test FMUC0062_REG0014

        [TestMethod]
        public void FMUC0062_REG0014()
        {
            try
            {
                Reports.TestDescription = "ES9168_EWC3_EWC5: Prevent reposting a fee transfer on Final/Est. Invoice";

                #region DataSetup

                string Message1 = "One of the fee(s) has been Invoiced, or the Payment Method is not 'FEE'";
                string Message2 = "You may reissue the Un-invoiced fee(s) from the 'Active Disbursement Summary' screen or check the Invoice fee Payment Method.";

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                EnterFeeInTitleEscrowTab();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter second fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", @"New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "New Home Rate Eagle Lender Policy-1", buyerCharge: 1.99, sellerCharge: 2.99);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Fee Transfer Button.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Click on Cancel.";
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.ChangeFileStatusDlg.ConfirmStatus("Open");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Print the checks.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate Valid Reasons for disbursement adjustment For Fee Transfer.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                Support.AreEqualTrim(@"Cancel Correct Bank Acct Input Error", FastDriver.DisbursementAdjustment.AdjustmentReason.FAGetText());

                Reports.TestStep = "Process a One-Sided Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");
                //FastDriver.DisbursementAdjustment.DocumentNo.FASetText("9436");
                //FastDriver.DisbursementAdjustment.Amount.FASetText("20");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the Adjust informational message.";
                string IEmsgBoxValue = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Accounting Adjustment Form is ready for printing. Continue?", IEmsgBoxValue);

                FastDriver.WebDriver.HandleDialogMessage();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.HandleDialogMessage();

                //Reports.TestStep = "Click on Done.";
                //FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                //FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the 2 fees.";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees");
                FastDriver.InvoiceFees.FeeSummarygrid.FASetCheckbox(true);
                FastDriver.InvoiceFees.FeeSummary1Fee.FASetCheckbox(true);

                Reports.TestStep = "Deliver Invoice.";
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                Keyboard.SendKeys("^L");
                FastDriver.WebDriver.HandleDialogMessage();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Estimate and verify the status.";
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.Estimate.FAClick();

                Reports.TestStep = "Verify the status as Estimated and deselect one of the fee.";
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTIMATED", 1, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummary1Fee.FASetCheckbox(false);

                Reports.TestStep = "Verify the status as EstimatedADJ and select 2 fees.";
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "ESTMTADJ", 1, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummary1Fee.FASetCheckbox(true);
                Support.AreEqual(@"True", FastDriver.InvoiceFees.Final.IsEnabled().ToString());
                FastDriver.InvoiceFees.Final.FAClick();

                Reports.TestStep = "Verify the status as Final and deselect one of the fee.";
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINAL", 1, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummary1Fee.FASetCheckbox(false);

                Reports.TestStep = "Verify the status as FinalADJ and select 2 fees.";
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(5, "FINALADJ", 1, TableAction.Click);
                FastDriver.InvoiceFees.FeeSummary1Fee.FASetCheckbox(true);

                Reports.TestStep = "Verify adjust for Fee transfer invoiced.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "FA", 3, TableAction.Click);

                Reports.TestStep = "Validate message for adjust for Fee transfer invoiced.";
                string IEmsgBoxValue2 = FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.StatusUpdate(IEmsgBoxValue, true);
                Support.AreEqual("True", IEmsgBoxValue2.Contains(Message1).ToString());
                Support.AreEqual("True", IEmsgBoxValue2.Contains(Message2).ToString());
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0014

        #region Test FMUC0062_REG0015

        [TestMethod]
        public void FMUC0062_REG0015()
        {
            try
            {
                Reports.TestDescription = "FD: Verify the field definitions";

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("2.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                if (!AutoConfig.FormType.ToLower().Equals("cd"))
                {
                    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Disburse the survey.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Midwest Financial Group", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.Reference.FASetText("ABCD");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                string checkNumber = FastDriver.IssueManualCheck.CheckNo.FAGetValue();
                FastDriver.BottomFrame.Save(); FastDriver.WebDriver.HandleDialogMessage(); if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    Reports.TestStep = "Click OK on Overdraftdialog.";
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
                string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
                FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Manual Reason for Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();

                Reports.TestStep = "Click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Verify lower boundary for all the fields.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();

                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.AdjustmentDate.FAGetValue());

                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Correct Document No");
                FastDriver.DisbursementAdjustment.Description.Clear();
                FastDriver.DisbursementAdjustment.Description.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABC");
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZABC", FastDriver.DisbursementAdjustment.Description.FAGetValue());
                Support.AreEqual(@"true", FastDriver.DisbursementAdjustment.UpdateTrustAccounting.FAGetAttribute("Checked"));

                FastDriver.DisbursementAdjustment.CorrectingTransDocumentNo.Clear();
                FastDriver.DisbursementAdjustment.CorrectingTransDocumentNo.FASendKeys("236547893");
                Support.AreEqual(@"236547893", FastDriver.DisbursementAdjustment.CorrectingTransDocumentNo.FAGetValue());

                FastDriver.DisbursementAdjustment.CorrectingTransDescription.Clear();
                FastDriver.DisbursementAdjustment.CorrectingTransDescription.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABC");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABC", FastDriver.DisbursementAdjustment.CorrectingTransDescription.FAGetValue());

                FastDriver.DisbursementAdjustment.CorrectingTransComment.Clear();
                FastDriver.DisbursementAdjustment.CorrectingTransComment.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABC");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABC", FastDriver.DisbursementAdjustment.CorrectingTransComment.FAGetValue());
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Verify exact values for all the fields.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();

                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Correct Document No");
                FastDriver.DisbursementAdjustment.Description.Clear();
                FastDriver.DisbursementAdjustment.Description.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", FastDriver.DisbursementAdjustment.Description.FAGetValue());

                FastDriver.DisbursementAdjustment.CorrectingTransDocumentNo.Clear();
                FastDriver.DisbursementAdjustment.CorrectingTransDocumentNo.FASendKeys("2365478293");
                Support.AreEqual(@"2365478293", FastDriver.DisbursementAdjustment.CorrectingTransDocumentNo.FAGetValue());

                FastDriver.DisbursementAdjustment.CorrectingTransDescription.Clear();
                FastDriver.DisbursementAdjustment.CorrectingTransDescription.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", FastDriver.DisbursementAdjustment.CorrectingTransDescription.FAGetValue());

                FastDriver.DisbursementAdjustment.CorrectingTransComment.Clear();
                FastDriver.DisbursementAdjustment.CorrectingTransComment.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", FastDriver.DisbursementAdjustment.CorrectingTransComment.FAGetValue());
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Verify upper boundary for all the fields.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();

                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Correct Document No");
                FastDriver.DisbursementAdjustment.Description.Clear();
                FastDriver.DisbursementAdjustment.Description.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE");
                FastDriver.DisbursementAdjustment.CorrectingTransDocumentNo.Clear();
                FastDriver.DisbursementAdjustment.CorrectingTransDocumentNo.FASendKeys("23654782932");

                FastDriver.DisbursementAdjustment.CorrectingTransDescription.Clear();
                FastDriver.DisbursementAdjustment.CorrectingTransDescription.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE");
                FastDriver.DisbursementAdjustment.CorrectingTransComment.Clear();
                FastDriver.DisbursementAdjustment.CorrectingTransComment.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE");

                Reports.TestStep = "Verify validation for upper boundary for all the fields.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();

                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", FastDriver.DisbursementAdjustment.Description.FAGetValue());
                Support.AreEqual(@"2365478293", FastDriver.DisbursementAdjustment.CorrectingTransDocumentNo.FAGetValue());

                FastDriver.BottomFrame.Reset();
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Click on Adhoc Adjustment button.";
                try
                {
                    FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                }
                catch
                {
                    FastDriver.WebDriver.HandleDialogMessage();
                    Reports.StatusUpdate("Going to exception", true);
                    FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                }
                FastDriver.DisbursementHistory.AdHocAdjustment.FAClick();

                Reports.TestStep = "Verify lower boundary for adhoc adjustment fields.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();

                FastDriver.DisbursementAdjustment.DocumentNo.Clear();
                FastDriver.DisbursementAdjustment.DocumentNo.FASendKeys("236547893");
                Support.AreEqual(@"236547893", FastDriver.DisbursementAdjustment.DocumentNo.FAGetValue());

                FastDriver.DisbursementAdjustment.Amount.Clear();
                FastDriver.DisbursementAdjustment.Amount.FASendKeys("1236540987.1");
                Support.AreEqual(@"1236540987.1", FastDriver.DisbursementAdjustment.Amount.FAGetValue());

                Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.DisbursementAdjustment.IssueDate.FAGetValue());

                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DisbursementAdjustment.Comment.Clear();
                FastDriver.DisbursementAdjustment.Comment.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABC");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABC", FastDriver.DisbursementAdjustment.Comment.FAGetValue());
                Support.AreEqual(@"true", FastDriver.DisbursementAdjustment.UpdateTrustAccounting.FAGetAttribute("Checked"));

                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Adhoc Adjustment button.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.AdHocAdjustment.FAClick();

                Reports.TestStep = "Verify exact values for adhoc adjustment fields.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.DocumentNo.Clear();
                FastDriver.DisbursementAdjustment.DocumentNo.FASendKeys("2365478293");
                Support.AreEqual(@"2365478293", FastDriver.DisbursementAdjustment.DocumentNo.FAGetValue());

                FastDriver.DisbursementAdjustment.Amount.Clear();
                FastDriver.DisbursementAdjustment.Amount.FASendKeys("12365478901.11");
                Support.AreEqual(@"12365478901.11", FastDriver.DisbursementAdjustment.Amount.FAGetValue());

                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DisbursementAdjustment.Comment.Clear();
                FastDriver.DisbursementAdjustment.Comment.SendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD");
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", FastDriver.DisbursementAdjustment.Comment.FAGetValue());
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Adhoc Adjustment button.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.AdHocAdjustment.FAClick();

                Reports.TestStep = "Verify upper boundary for adhoc adjustment fields.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.DocumentNo.Clear();
                FastDriver.DisbursementAdjustment.DocumentNo.FASendKeys("23654782932");
                FastDriver.DisbursementAdjustment.Amount.Clear();
                FastDriver.DisbursementAdjustment.Amount.FASendKeys("12365478904561.221");
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DisbursementAdjustment.Comment.Clear();
                FastDriver.DisbursementAdjustment.Comment.FASendKeys("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDE");

                Reports.TestStep = "Verify validation for upper boundary for adhoc adjustment screen.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                Support.AreEqual(@"2365478293", FastDriver.DisbursementAdjustment.DocumentNo.FAGetValue());
                Support.AreEqual(@"?", FastDriver.DisbursementAdjustment.Amount.FAGetValue().Trim());
                Support.AreEqual(@"ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", FastDriver.DisbursementAdjustment.Comment.FAGetValue());
                FastDriver.BottomFrame.Cancel();
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0015

        #region Test FMUC0062_REG0016

        //User Story 716431:Direct - Show who Reposted a Deposit/Disbursement
        // Tushar

        [TestMethod]
        public void FMUC0062_REG0016()
        {
            try
            {
                Reports.TestDescription = "Reposting a disbursement and verifying in Event Log Screen";

                #region DataSetup

                #endregion DataSetup

                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";

                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                EnterFeeInTitleEscrowTab();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter second fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", @"New Home Rate Eagle Lender Policy-1", "Sel", TableAction.On);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "New Home Rate (Title Only)", buyerCharge: 1.99, sellerCharge: 2.99);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Fee Transfer Button.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Click on Cancel.";
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                FastDriver.ChangeFileStatusDlg.ConfirmStatus("Open");

                Reports.TestStep = "Print the checks.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate Valid Reasons for disbursement adjustment For Fee Transfer.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                Support.AreEqualTrim(@"Cancel Correct Bank Acct Input Error", FastDriver.DisbursementAdjustment.AdjustmentReason.FAGetText());

                Reports.TestStep = "Process a One-Sided Adjustment on a Disbursement.";
                ProcessOneSidedAdjstmentOnDisbrsment("Cancel", false, true, "Comments for cancel");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the Adjust informational message.";
                string IEmsgBoxValue = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Accounting Adjustment Form is ready for printing. Continue?", IEmsgBoxValue);
                FastDriver.WebDriver.HandleDialogMessage();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //SRT coding starts  here  -  User Story 716431:Direct - Show who Reposted a Deposit/Disbursement
                // Automated By - Tushar Shankar - Date - 02/17/2016
                // Reason - Reposting and Verifying same in EventLog Screen

                Reports.TestStep = "Click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Process a One-Sided Adjustment on a Disbursement. (Reposting the Canceled disbursement)";
                ProcessOneSidedAdjstmentOnDisbrsment("REPOST", false, true, "Comments for cancel");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Validate the Adjust informational message.";
                IEmsgBoxValue = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"Accounting Adjustment Form is ready for printing. Continue?", IEmsgBoxValue);
                FastDriver.WebDriver.HandleDialogMessage();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Cancel.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Verify Event Screen";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem(@"Accounting/Privacy");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Support.AreEqual("[Disbursement Repost]".ToLower(), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.ToLower());

                Reports.TestStep = "Verify for Adjustment Reason in comments of disbursement adjustment event for Cancel";
                Reports.StatusUpdate("Adjustment Reason present in comments (i.e. Adjustment Reason: Re-post)", FastDriver.EventTrackingLog.Comments.FAGetText().Contains(@"Adjustment Reason: Re-post"));

                //SRT coding ends here 

            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0016

        #region Test FMUC0062_REG0017

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r07 
        //UserStory                               : User Story 351739:NCS - Preserve wire information after adjusting
        //TestCase                                : 799334 
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0062_REG00017()
        {
            try
            {
                Reports.TestDescription = "Verify wire information preserved after it is adjusted";


                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Enter a check.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1000000.00");
                //FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                //FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                //if (!AutoConfig.FormType.ToLower().Equals("cd"))
                //{
                //    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                //    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                //}
                FastDriver.BottomFrame.Done();

                #endregion Enter a check.

                #region Upload document in document repository screen

                Reports.TestStep = "Upload document in document repository screen";

                UploadDocument();

                #endregion Upload document in document repository screen

                #region Convert the check to wire and enter all the wire information.

                Reports.TestStep = "Select the wire with pending status";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click, "Check");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                ConvertToWire();

                #endregion Convert the check to wire and enter all the wire information.

                #region Issue the wire and adjust it.
                Reports.TestStep = "Disburse Wire.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click, "Wire");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                PasswordOrOverdraftConfirmationDialog();

                Reports.TestStep = "Click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "W", 3, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate Valid Reasons for disbursement adjustment For Wire.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem(@"Cancel");
                FastDriver.DisbursementAdjustment.Comment.FASetText("Adjustment");

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                #endregion Issue the wire and adjust it.

                #region Verify the adjusted wire and wire details.

                Reports.TestStep = "Select the wire with pending status";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click, "wire");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Verify all the wire informations and instructions should retain.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(@"Wire", FastDriver.EditDisbursement.DisburseAs.FAGetSelectedItem());
                Support.AreEqual("True", FastDriver.EditDisbursement.WireInstructionTable.GetRowCount() > 0 ? "True" : "False");
                Support.AreEqual("True", FastDriver.EditDisbursement.Approve1.IsSelected() == false ? "True" : "False");
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankABANumber.FAGetValue().Contains("12346689").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankName.FAGetValue().Contains("ReceivingBankName").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankAddress.FAGetValue().Contains("ReceivingBangAddress").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryAccountNumber.FAGetValue().Contains("12356465").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FAGetValue().Contains("12356465").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryName.FAGetValue().Contains("BeneficiaryName").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryNote1.FAGetValue().Contains("Benificiary Note 1").ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                #endregion Verify the adjusted wire and wire details.
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0017

        #region Test FMUC0062_REG0018

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r07 
        //UserStory                               : User Story 351739:NCS - Preserve wire information after adjusting
        //TestCase                                : 799340
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0062_REG00018()
        {
            try
            {
                Reports.TestDescription = "Verify wire information preserved after it is adjusted";


                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Enter a check.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1000000.00");
                //FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                //FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                //if (!AutoConfig.FormType.ToLower().Equals("cd"))
                //{
                //    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                //    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                //}
                FastDriver.BottomFrame.Done();

                #endregion Enter a check.

                #region Upload document in document repository screen

                Reports.TestStep = "Upload document in document repository screen";

                UploadDocument();

                #endregion Upload document in document repository screen

                #region Convert the check to wire and enter all the wire information.

                Reports.TestStep = "Select the wire with pending status";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click, "Check");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                ConvertToWire();

                #endregion Convert the check to wire and enter all the wire information.

                #region Issue the wire and void it.
                Reports.TestStep = "Disburse Wire.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click, "Wire");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();

                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                PasswordOrOverdraftConfirmationDialog();

                Reports.TestStep = "Click on void.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Issued", "Funds", TableAction.Click, "Wire");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Void.FAClick();
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.SetVoidReason("Reason to void the Disbursement");
                FastDriver.VoidDlg.ClickOk();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);


                #endregion Issue the wire and void it.

                #region Verify the void wire and wire details.

                Reports.TestStep = "Select the wire with pending status";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click, "wire");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();


                Reports.TestStep = "Verify all the wire informations and instructions should retain.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(@"Wire", FastDriver.EditDisbursement.DisburseAs.FAGetSelectedItem());
                Support.AreEqual("True", FastDriver.EditDisbursement.WireInstructionTable.GetRowCount() > 0 ? "True" : "False");
                Support.AreEqual("True", FastDriver.EditDisbursement.Approve1.IsSelected() == false ? "True" : "False");
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankABANumber.FAGetValue().Contains("12346689").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankName.FAGetValue().Contains("ReceivingBankName").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankAddress.FAGetValue().Contains("ReceivingBangAddress").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryAccountNumber.FAGetValue().Contains("12356465").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FAGetValue().Contains("12356465").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryName.FAGetValue().Contains("BeneficiaryName").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryNote1.FAGetValue().Contains("Benificiary Note 1").ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                #endregion Verify the adjusted wire and wire details.
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0021_SRT

        #region Test FMUC0062_REG0019

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r07 
        //UserStory                               : User Story 351739:NCS - Preserve wire information after adjusting
        //TestCase                                : 799349
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0062_REG00019()
        {
            try
            {
                Reports.TestDescription = "Verify wire information preserved after it is adjusted";


                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Enter a check.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1000000.00");
                //FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                //FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                //if (!AutoConfig.FormType.ToLower().Equals("cd"))
                //{
                //    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                //    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                //}
                FastDriver.BottomFrame.Done();

                #endregion Enter a check.

                #region Upload document in document repository screen

                Reports.TestStep = "Upload document in document repository screen";

                UploadDocument();

                #endregion Upload document in document repository screen

                #region Convert the check to wire and enter all the wire information.

                Reports.TestStep = "Select the wire with pending status";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click, "Check");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                ConvertToWire();

                #endregion Convert the check to wire and enter all the wire information.

                #region approve the wire using another user.

                Reports.TestStep = "Approve Wire with another user.";
                //Reports.StatusUpdate("Approve Wire with another user.", true);
                IISLOGIN(AutoConfig.UserNameSecondary, AutoConfig.UserPasswordSecondary);

                Reports.TestStep = "Enter file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.FindNow.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Edit Disbursement -Wire.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                Playback.Wait(1000);
                WireApproval("FirstApproval");

                #endregion approve the wire using another user.

                #region Login to the first user and search the file.

                IISLOGIN();
                Reports.TestStep = "Enter file number.";
                FastDriver.LeftNavigation.Navigate<FileSearch>(@"Home>Order Entry>File Search").WaitForFileSearchScreenToLoad();
                FastDriver.FileSearch.Region.FASelectItem(AutoConfig.SelectedRegionName);
                FastDriver.FileSearch.Numbers.FASetText(FileNumber1);
                FastDriver.FileSearch.FindNow.FAClick();
                Playback.Wait(3000);

                #endregion Login to the first user and search the file.

                #region Issue the wire.
                Reports.TestStep = "Disburse Wire.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click, "Wire");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                PasswordOrOverdraftConfirmationDialog();
                #endregion Issue the wire.

                #region Adjust the wire.

                Reports.TestStep = "Click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "W", 3, TableAction.Click);
                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate Valid Reasons for disbursement adjustment For Wire.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem(@"Cancel");
                FastDriver.DisbursementAdjustment.Comment.FASetText("Adjustment");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                #endregion Adjust the wire.

                #region Verify the adjusted wire and wire details.

                Reports.TestStep = "Select the wire with pending status";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click, "wire");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();


                Reports.TestStep = "Verify all the wire informations and instructions should retain.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(@"Wire", FastDriver.EditDisbursement.DisburseAs.FAGetSelectedItem());
                Support.AreEqual("True", FastDriver.EditDisbursement.WireInstructionTable.GetRowCount() > 0 ? "True" : "False");
                Support.AreEqual("True", FastDriver.EditDisbursement.Approve1.IsSelected() == false ? "True" : "False");
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankABANumber.FAGetValue().Contains("12346689").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankName.FAGetValue().Contains("ReceivingBankName").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankAddress.FAGetValue().Contains("ReceivingBangAddress").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryAccountNumber.FAGetValue().Contains("12356465").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FAGetValue().Contains("12356465").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryName.FAGetValue().Contains("BeneficiaryName").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryNote1.FAGetValue().Contains("Benificiary Note 1").ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                #endregion Verify the adjusted wire and wire details.
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0019

        #region Test FMUC0062_REG0020

        //Team                                    : ServReq-Galaxy 
        //Iteration                               : r07 
        //UserStory                               : User Story 351739:NCS - Preserve wire information after adjusting
        //TestCase                                : 799350
        //Appended By/ Created By                 : Niharika sabata

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0062_REG00020()
        {
            try
            {
                Reports.TestDescription = "Verify wire information preserved after it is adjusted";


                #region Login to file side.

                Reports.TestStep = "Login to file side.";
                IISLOGIN();

                #endregion Login to file side.

                #region Create Order.

                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                #endregion Create Order.

                #region Enter a check.

                Reports.TestStep = "Give details for Buyer and Seller fields.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("248");

                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey123456");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1000000.00");
                //FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("3.00");
                //FastDriver.SurveyDetail.BorrowerSelectedServicesGFEAmount.FASetText("1.50");

                //if (!AutoConfig.FormType.ToLower().Equals("cd"))
                //{
                //    FastDriver.SurveyDetail.GFE_4TitleServicesBuyerCharge.FASetText("3.00");
                //    FastDriver.SurveyDetail.GFE_4TitleServicesSellerCharge.FASetText("6.00");
                //}
                FastDriver.BottomFrame.Done();

                #endregion Enter a check.

                #region Upload document in document repository screen

                Reports.TestStep = "Upload document in document repository screen";

                UploadDocument();

                #endregion Upload document in document repository screen

                #region Convert the check to wire and enter all the wire information.

                Reports.TestStep = "Select the wire with pending status";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click, "Check");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                ConvertToWire();

                #endregion Convert the check to wire and enter all the wire information.

                #region Split the wire entry.

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click, "Wire");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionPercentage.FASetText("50.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                int SDRowCount1 = FastDriver.SplitDisbursement.SplitDisbTable.GetRowCount();
                for (int iterationCount = 2; iterationCount <= SDRowCount1; iterationCount++)
                {
                    FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(iterationCount, 1, TableAction.SetText, "50.00" + FAKeys.Tab);
                }
                FastDriver.BottomFrame.Save();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                #endregion Split the wire entry.

                #region Issue the split wire and adjust it.
                Reports.TestStep = "Disburse Wire.";

                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click, "Wire");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();



                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                PasswordOrOverdraftConfirmationDialog();

                Reports.TestStep = "Click on Adjust.";
                FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History").WaitForScreenToLoad();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(3, "W", 3, TableAction.Click);

                FastDriver.DisbursementHistory.Adjust.FAClick();

                Reports.TestStep = "Validate Valid Reasons for disbursement adjustment For Wire.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem(@"Stop Payment");
                FastDriver.DisbursementAdjustment.Comment.FASetText("Adjustment");

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Done.";
                FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                #endregion Issue the wire and adjust it.

                #region Verify the adjusted wire and wire details.

                Reports.TestStep = "Select the wire with pending status";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click, "wire");
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Click on edit button.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();


                Reports.TestStep = "Verify all the wire informations and instructions should retain.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                Support.AreEqual(@"Wire", FastDriver.EditDisbursement.DisburseAs.FAGetSelectedItem());
                Support.AreEqual("True", FastDriver.EditDisbursement.WireInstructionTable.GetRowCount() > 0 ? "True" : "False");
                Support.AreEqual("True", FastDriver.EditDisbursement.Approve1.IsSelected() == false ? "True" : "False");
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankABANumber.FAGetValue().Contains("12346689").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankName.FAGetValue().Contains("ReceivingBankName").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.ReceivingBankAddress.FAGetValue().Contains("ReceivingBangAddress").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryAccountNumber.FAGetValue().Contains("12356465").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FAGetValue().Contains("12356465").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryName.FAGetValue().Contains("BeneficiaryName").ToString());
                Support.AreEqual("True", FastDriver.EditDisbursement.BeneficiaryNote1.FAGetValue().Contains("Benificiary Note 1").ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                #endregion Verify the adjusted wire and wire details.
            }
            catch (Exception ex)
            {
                Support.Fail("This TestMethod failed because: " + ex.Message);
            }
        }

        #endregion Test FMUC0062_REG0020

        #endregion REG

        #region PrivateMethods

        private static void PasswordOrOverdraftConfirmationDialog()
        {
            Reports.TestStep = "Enter password confimation details dialog info.";
            FastDriver.WebDriver.WaitForWindowAndSwitch("Password Confirmation");
            FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
            FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItem("Payment: Wrong Amount");
            FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
            string chkPrintingPwd = AutoConfig.CheckPrintingPassword;
            FastDriver.PasswordConfirmationDlg.Password.FASetText(chkPrintingPwd);
            FastDriver.DialogBottomFrame.ClickDone();
        }

        private void UploadDocument()
        {

            Reports.TestStep = "Click on Upload button";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad().Upload.FAClick();

            Reports.TestStep = "Browse document.";
            string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
            FastDriver.UploadDocumentDlg.UploadFile(filePath);

            Reports.TestStep = "Save the PDF Doc.";
            //FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
            FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
            FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
            Playback.Wait(20000); //wait for PDF upload to finish

            Reports.TestStep = "Navigate to document Repository.";
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

            Reports.TestStep = "Verify that Document is uploaded to the FAST.";
            FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Miscellaneous PDFDocument", 4, TableAction.Click);

        }

        private void ProcessOneSidedAdjstmentOnDisbrsment(string AdjustmentReason, bool checkforComment, bool checkforDescription, string Comment = null)
        {
            Reports.TestStep = "Process a One-Sided Adjustment on a Disbursement.";
            FastDriver.DisbursementAdjustment.WaitForScreenToLoad();

            if (AdjustmentReason.ToLower().Equals("repost")) // || AdjustmentReason.ToLower().Equals("cancel")
                Support.AreEqual(AdjustmentReason.ToLower(), FastDriver.DisbursementAdjustment.AdjustmentReason.FAGetSelectedItem().ToLower(), "Verify Default AdjustmentReason");
            else
                Support.AreEqual("", FastDriver.DisbursementAdjustment.AdjustmentReason.FAGetSelectedItem().Trim(), "Verify Default AdjustmentReason");

            if (checkforDescription)
                Support.AreEqual("", FastDriver.DisbursementAdjustment.Description.FAGetValue().Trim(), "Verify Default Description");
            if (checkforComment)
                Support.AreEqual("", FastDriver.DisbursementAdjustment.Comment.FAGetText().Trim(), "Verify Default Comment");

            Support.AreEqual("FAST QA07", FastDriver.DisbursementAdjustment.PostedBy.FAGetText(), "Verify PostedBy");

            DateTime PSTDateTime = DateTime.UtcNow;
            PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
            string CurrentPSTDate = PSTDateTime.ToDateString();
            Support.AreEqual(CurrentPSTDate, FastDriver.DisbursementAdjustment.PostedOn.FAGetText(), "Verify PostedOn");

            FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem(AdjustmentReason);
            FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItem(AdjustmentReason);
            FastDriver.DisbursementAdjustment.Comment.FASetText(Comment);

            if (AdjustmentReason == "Correct Document No")
            {
                Support.AreEqual("True", FastDriver.DisbursementAdjustment.CorrectBankAcctNumber.IsVisible().ToString());
                FastDriver.DisbursementAdjustment.CorrectingTransDocumentNo.FASetText(@"21456");
                //Support.AreEqual("true", FastDriver.DisbursementAdjustment.CorrectingTransDescription.FAGetValue().Contains(FastDriver.DisbursementAdjustment.PostedOn.FAGetText()).ToString().ToLower());
                //Support.AreEqual("Comments1", FastDriver.DisbursementAdjustment.CorrectingTransComment.FAGetValue());
                FastDriver.DisbursementAdjustment.CorrectingTransComment.FASetText("Comments1");
            }
        }

        private void ValidateRecalOfSplitamount()
        {
            FastDriver.SplitDisbursement.WaitForScreenToLoad();
            FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(5, 1, TableAction.Click);
            FastDriver.SplitDisbursement.Remove.FAClick();
            FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(4, 1, TableAction.Click);
            FastDriver.SplitDisbursement.WaitForScreenToLoad();
            string AmtRemaining = FastDriver.SplitDisbursement.AmountRemaining.FAGetText().ToString().Trim();
            Support.AreNotEqual("0.00", AmtRemaining, true);

            int SDRowCount3 = FastDriver.SplitDisbursement.SplitDisbTable.GetRowCount();
            FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(SDRowCount3, 2, TableAction.Click);
            Keyboard.SendKeys(FAKeys.TabAway);
            int SDRowCount4 = FastDriver.SplitDisbursement.SplitDisbTable.GetRowCount();
            FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(SDRowCount4, 2, TableAction.SetText, AmtRemaining);
            FastDriver.BottomFrame.Save();
            FastDriver.SplitDisbursement.WaitForScreenToLoad();
            string LastSplit = FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(SDRowCount4, 2, TableAction.GetText).Message.ToString().Trim();
            string SecondLastSplit = FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(SDRowCount4 - 1, 2, TableAction.GetText).Message.ToString().Trim(); ;
            //double LastSplitAmt = Convert.ToDouble(LastSplit);
            //int SecondLastSplitAmt = Convert.ToDouble(SecondLastSplit);
            if ((LastSplit == "200.75") && (SecondLastSplit == "200.73"))
            {
                Reports.StatusUpdate("Adjust Remaining Amount Field is successfull when one of the split row is removed.", true);
            }
            else
            {
                Reports.StatusUpdate("Adjust Remaining Amount Field is not successfull when one of the split row is removed.", false);
            }
            FastDriver.BottomFrame.Save();
        }

        private void Split5Times()
        {
            FastDriver.SplitDisbursement.SplitDistributionPercentage.FASetText("20.00");
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            int SDRowCount1 = FastDriver.SplitDisbursement.SplitDisbTable.GetRowCount();
            for (int iterationCount = 2; iterationCount <= SDRowCount1; iterationCount++)
            {
                FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(iterationCount, 1, TableAction.SetText, "20.00" + FAKeys.Tab);
            }
        }

        private void VerifyLastSplitAndAllPercentage()
        {
            int SDRowCount2 = FastDriver.SplitDisbursement.SplitDisbTable.GetRowCount();
            for (int iterationCount = 2; iterationCount <= SDRowCount2; iterationCount++)
            {
                if (iterationCount == SDRowCount2)
                {
                    Support.AreEqual("200.73", FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(iterationCount, 2, TableAction.GetText).Message.Trim(), true);
                }
                else
                {
                    Support.AreEqual("200.75", FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(iterationCount, 2, TableAction.GetText).Message.Trim(), true);
                }
            }
            Reports.TestStep = "Validate that the percentage remains same across all the splits";
            for (int iterationCount = 2; iterationCount <= SDRowCount2; iterationCount++)
            {
                Support.AreEqual("20.00", FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(iterationCount, 1, TableAction.GetInputValue).Message.Trim(), true);
            }
        }

        private void SaveReleaseHold()
        {
            Reports.TestStep = "Release Hold and Save the changes made.";
            FastDriver.ActiveDisbursementSummary.Edit.FAClick();
            FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.VoucherChargeDetail);
            FastDriver.EditDisbursement.ReleaseHold.FAClick();
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();
        }

        private void SaveHoldDays(String Days)
        {
            Reports.TestStep = "Save the Hold Days Info";
            string value = string.Empty;
            if (DateTime.Today.AddDays(Convert.ToInt32(Days)).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(Convert.ToInt32(Days)).DayOfWeek.ToString() == "Sunday")
                value = (Convert.ToInt32(Days) + 3).ToString();
            else
                value = Days;
            int Count1 = FastDriver.WebDriver.FindElements(By.XPath("//td[@id='cBntExp8' and @class='cButtonExpandFalse']")).Count();
            if (Count1 > 0)
            {
                FastDriver.EditDisbursement.HoldInformation.FAClick();
            }
            FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.VoucherChargeDetail);
            FastDriver.EditDisbursement.HoldFor.FASetText(value);
            if (Days != "6")
            {
                FastDriver.EditDisbursement.PurposeOfHold.FASetText("Holding the disbursement", true);
            }
            FastDriver.BottomFrame.Save();
            FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.VoucherChargeDetail);
            FastDriver.BottomFrame.Done();
        }

        private void IISLOGIN(string UserName = null, string Password = null)
        {
            var website = AutoConfig.FASTHomeURL;
            if (UserName == null)
            {
                UserName = UserName ?? AutoConfig.UserName;
            }
            if (Password == null)
            {
                Password = Password ?? AutoConfig.UserPassword;
            }
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void UploadDoc()
        {
            Reports.TestStep = "Navigate to Doc Repository and Click on Upload.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
            FastDriver.DocumentRepository.Upload.FAClick();

            Reports.TestStep = "Browse document and upload it (jpg).";
            if (!((Reports.DEPLOYDIR + "\\JpegFile.jpg").ToString() == "True"))
            {
                Support.GetEmbeddedImages("AutoSupport", "support.JpegFile.jpg", Reports.DEPLOYDIR + "\\JpegFile.jpg");
            }
            string FilePath = Reports.DEPLOYDIR + "\\JpegFile.jpg";
            FastDriver.UploadDocumentDlg.UploadFile(FilePath);

            Reports.TestStep = "Save Scanned doc,entering Name so that it will appear in Edit Disb Screen.";
            FastDriver.SaveDocumentDlg.SaveDocument("Escrow: Payoff Demand/Bills", "Miscellaneous", "test");
            try
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.NoTitleWindow, false);
            }
            catch (TimeoutException)
            {
                Reports.StatusUpdate("Saving... NoTitle window has closed fast.", true);
            }
        }

        private void ConvertToWire()
        {
            Reports.TestStep = "Convert to wire attach Instruction.";
            FastDriver.EditDisbursement.WaitForScreenToLoad();
            FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
            FastDriver.EditDisbursement.Add.FAClick();

            Reports.TestStep = "Select the wire Instruction Doc.";
            FastDriver.SelectWireInstructionsDlg.SelectWireInstruction();

            Reports.TestStep = "Convert to wire attach Instruction.";
            FastDriver.EditDisbursement.WaitForScreenToLoad();
            FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
            FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
            FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
            FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
            FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
            FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
            FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();
        }

        private void ClickOnWireInstructionImageAndApprove(string ApprovalType)
        {
            Reports.TestStep = "Click on Wire Instruction Image.";
            FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.VoucherChargeDetail);
            FastDriver.EditDisbursement.Image.FAClick();

            Reports.StatusUpdate("Verify Image Load: Look for Screenshot", true);
            try
            {
                BrowserWindow sBr = new BrowserWindow();
                sBr.SearchProperties["ClassName"] = "Internet Explorer_TridentDlgFrame";
                sBr.SearchProperties.Add("Name", "Fastimages", PropertyExpressionOperator.Contains);
                sBr.SetFocus();
            }
            catch { }
            Keyboard.SendKeys("%{SPACE}C");

            Reports.TestStep = "Approve Document repository for wire DGC.";
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.EditDisbursement.WaitForScreenToLoad(FastDriver.EditDisbursement.VoucherChargeDetail);
            if (ApprovalType == "FirstApproval")
            {
                if (FastDriver.EditDisbursement.Approve1.Enabled.ToString() == "True")
                {
                    FastDriver.EditDisbursement.Approve1.FASetCheckbox(true);
                }
            }
            if (ApprovalType == "SecondApproval")
            {
                if (FastDriver.EditDisbursement.Approval2.Enabled.ToString() == "True")
                {
                    FastDriver.EditDisbursement.Approval2.FASetCheckbox(true);
                }
            }
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();
        }

        private void WireApproval(string ApprovalType)
        {
            Reports.TestStep = "Click on Wire Instruction Image.";
            FastDriver.EditDisbursement.WaitForScreenToLoad();
            FastDriver.EditDisbursement.Image.FAClick();

            Reports.StatusUpdate("Verify Image Load: Look for Screenshot", true);
            try
            {
                BrowserWindow sBr = new BrowserWindow();
                sBr.SearchProperties["ClassName"] = "Internet Explorer_TridentDlgFrame";
                sBr.SearchProperties.Add("Name", "Fastimages", PropertyExpressionOperator.Contains);
                sBr.SetFocus();
            }
            catch { }
            Playback.Wait(3000);
            //Keyboard.SendKeys("%{SPACE}C");
            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
            FastDriver.WebDriver.FindElements(By.CssSelector("[class='ui-button-icon-primary ui-icon ui-icon-closethick']"))[0].GiveFocus();
            FastDriver.WebDriver.FindElements(By.CssSelector("[class='ui-button-icon-primary ui-icon ui-icon-closethick']"))[0].FAClick();

            Reports.TestStep = "Approve Document repository for wire DGC.";
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.EditDisbursement.WaitForScreenToLoad();
            if (ApprovalType == "FirstApproval")
            {
                if (FastDriver.EditDisbursement.Approve1.Enabled.ToString() == "True")
                {
                    FastDriver.EditDisbursement.Approve1.FASetCheckbox(true);
                }
            }
            if (ApprovalType == "SecondApproval")
            {
                if (FastDriver.EditDisbursement.Approval2.Enabled.ToString() == "True")
                {
                    FastDriver.EditDisbursement.Approval2.FASetCheckbox(true);
                }
            }
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();
        }

        private void EnterFeeInTitleEscrowTab()
        {
            Reports.TestStep = "Enter first fee in Title and escrow.";
            FastDriver.FileFees.Open();
            FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
            FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99");
            FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99");
        }

        public bool isAlertPresent()
        {
            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        private string GetParsedUserIDWithSpace(string userID, bool IsToBeReversed = false)
        {
            string parsedUserID = "";
            if (userID.Contains("\\"))
            {
                parsedUserID = userID.Split('\\').LastOrDefault().Substring(0, 4) + " " + userID.Split('\\').LastOrDefault().Substring(4, 4);
            }
            if (IsToBeReversed)
            {
                parsedUserID = parsedUserID.Split(' ').LastOrDefault() + ", " + parsedUserID.Split(' ').FirstOrDefault();
                return parsedUserID.ToUpper();
            }
            return parsedUserID;
        }

        private static void DepositCash(string Amount, string TypeOfFund, string Representing, string Description, string RecievingFrom, string Payor, string Comment = null)
        {
            Reports.TestStep = "Deposit cash.";
            FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
            FastDriver.DepositInEscrow.SwitchToContentFrame();

            FastDriver.DepositInEscrow.Amount.FASetText(Amount);
            FastDriver.DepositInEscrow.TypeofFunds.FASelectItem(TypeOfFund);
            FastDriver.DepositInEscrow.Representing.FASelectItem(Representing);
            FastDriver.DepositInEscrow.Description.FASetText(Description);
            FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem(RecievingFrom);
            FastDriver.DepositInEscrow.Comment.FASetText(Comment);
        }

        #endregion PrivateMethods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}