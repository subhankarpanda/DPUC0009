﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using System.Linq;
using System.Collections.Generic;

namespace EscrowTransactions
{
    public partial class FMUC0135 : MasterTestClass
    {
        #region r10.2016
        /// <summary>
        /// FMUC0135_REG0042 - This test method covers the US 675522 from r10
        /// FMUC0135_REG0043 - This test method covers the US 672340 from r10
        /// FMUC0135_REG0044 - This test method covers the US 668248 and 670842 from r10
        /// FMUC0135_REG0037 - This Test method covers the US 761804 from r09
        /// </summary>
        [TestMethod]
        public void FMUC0135_REG0042()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "#US 675522 for Allow user to modify Property Address which needs to be displayed in the Settlement Statement Header section..";
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Through UI
                Reports.TestStep = "Create File with Commercial business type.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.EscrowOwningOfficeOfficer.FASelectItem("Y, Yeshwanth");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("Property 1");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Agricultural Land");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationTRact.FASetText("Tract1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First property: Address1 line 1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("First property: Address1 line 2");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("First property: Address1 line 3");
                FastDriver.QuickFileEntry.PropertyBookAddrLin4.FASetText("First property: Address1 line 4");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("City1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("NV");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("89003");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Nye");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFN1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLN1");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFN1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLN1");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("420");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                FastDriver.FileHomepage.Open();
                string fileNum = FastDriver.FileHomepage.FileNumPrefix.FAGetValue() + "-" + FastDriver.FileHomepage.FileNum.FAGetValue() + "-" + FastDriver.FileHomepage.FileNumSufix.FAGetValue();
                FastDriver.TopFrame.SwitchToContentFrame();
                string[] EscrowOfficerName = FastDriver.FileHomepage.EscrowOwningOfficeOfficer.FAGetSelectedItem().Split(',');
                #endregion

                #region Setting test data for Property 
                Reports.TestStep = "Navigate to Properties/Tax Info and add Property details";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("First property: Address2 line 1");//Property 1 Address 2 
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("First property: Address2 line 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("First property: Address2 line 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("First property: Address2 line 4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("City2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("AZ");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("85925");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Apache");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("First property: Address3 line 1");//Property 1 Address 3
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("First property: Address3 line 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("First property: Address3 line 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("First property: Address3 line 4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("City3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("FL");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("32003");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Clay");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Playback.Wait(10000);
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                //Property 2
                FastDriver.PropertiesSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("Property 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FASelectItem("Condominium");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Second property: Address1 line 1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("Second property: Address1 line 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("Second property: Address1 line 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("Second property: Address1 line 4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("City2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("KS");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("66901");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Cloud");
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText("Lot2");
                FastDriver.PropertyTaxInfoLegalDesciption.Tract.FASetText("Tract2");
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("Unit2");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Playback.Wait(10000);
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                //Property 3
                FastDriver.PropertiesSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("Property 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FASelectItem("Industrial");
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                Playback.Wait(5000);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Third property: Address1 line 1");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("Third property: Address1 line 2");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("Third property: Address1 line 3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("Third property: Address1 line 4");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("City3");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("HI");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("96708");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Maui");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                
                #endregion

                #region Verify the Header section in the View settlement statement
                Reports.TestStep = "Navigate to viewsettlement statement and verify the header section";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Reports.TestStep = "Verify the Property section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderpropertylabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.propertyPlusIcon.IsDisplayed().ToString());
                Playback.Wait(3000);
                Reports.TestStep = "Verify the Pop up dialog of Property section of Header section in ViewSettlement Statement";
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.propertyPlusIcon.Highlight();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.propertyPlusIcon.FAClick();
                Playback.Wait(5000);
                Support.AreEqual("First property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/textarea").FAGetText().ToString());
                Support.AreEqual("First property: Address2 line 1, First property: Address2 line 2, First property: Address2 line 3, First property: Address2 line 4, City2, AZ 85925\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[3]/textarea").FAGetText().ToString());
                Support.AreEqual("First property: Address3 line 1, First property: Address3 line 2, First property: Address3 line 3, First property: Address3 line 4, City3, FL 32003\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[5]/td[3]/textarea").FAGetText().ToString());
                Support.AreEqual("Second property: Address1 line 1, Second property: Address1 line 2, Second property: Address1 line 3, Second property: Address1 line 4, City2, KS 66901\r\nLot: Lot2 Unit: Unit2 Tract: Tract2", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[6]/td[3]/textarea").FAGetText().ToString());
                Support.AreEqual("Third property: Address1 line 1, Third property: Address1 line 2, Third property: Address1 line 3, Third property: Address1 line 4, City3, HI 96708", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[7]/td[3]/textarea").FAGetText().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/span/img[1]").IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/span/img[2]").IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.AddressSelectAll.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.AddressSelectAll.Enabled.ToString());
                Reports.TestStep = "Verify the Numbering of the property details displayed in the Pop up dialog";
                Support.AreEqual("1.1", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[1]").FAGetText().ToString());
                Support.AreEqual("First property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/textarea").FAGetText().ToString());
                Support.AreEqual("1.2", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[1]").FAGetText().ToString());
                Support.AreEqual("First property: Address2 line 1, First property: Address2 line 2, First property: Address2 line 3, First property: Address2 line 4, City2, AZ 85925\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[3]/textarea").FAGetText().ToString());
                Support.AreEqual("1.3", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[5]/td[1]").FAGetText().ToString());
                Support.AreEqual("2", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[6]/td[1]").FAGetText().ToString());
                Support.AreEqual("3", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[7]/td[1]").FAGetText().ToString());
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                #endregion

                #region Edit the Property details and Verify the modified changes in View Settlement statement
                Reports.TestStep = "Navigate to viewsettlement statement";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Reports.TestStep = "Edit the property details and the verify the Broken link and refresh icon and verify the Refresh button functionality";
                FastDriver.NCSViewSettlementStatement.propertyPlusIcon.FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/textarea").FASetText("Modified address1" + Keys.Tab);
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/span/img[1]").IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/span/img[2]").IsDisplayed().ToString());
                FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/textarea").FASetText("" + Keys.Tab);
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.propertyPlusIcon.FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/textarea").FASetText("Property address modified" + Keys.Tab);
                FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/span/img[1]").FAClick();
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/span/img[1]").IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/span/img[2]").IsDisplayed().ToString());
                Support.AreEqual("First property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/textarea").FAGetText().ToString());
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Support.AreEqual("First property: Address1 line 1, First property: Address1 line 2, First property: Address1 line 3, First property: Address1 line 4, City1, NV 89003\r\nLot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[1]/div[1]").FAGetText());
                Reports.TestStep = "Edit the second property details and also in the property source screen and the verify both the changes in the Header section in View Settlement Statement";
                FastDriver.NCSViewSettlementStatement.propertyPlusIcon.FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[6]/td[3]/textarea").FASetText("Second property modified address" + FAKeys.Tab);
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Playback.Wait(3000);
                Support.AreEqual("Second property modified address", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[2]/div[2]").FAGetText());
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                Reports.TestStep = "Navigate to Properties/Tax Info and edit the second Property detail";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Table.PerformTableAction(3, 2, TableAction.DoubleClick);
                FastDriver.PropertiesSummary.Edit.FAClick();
                Playback.Wait(3000);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Modified from source screen, Second property: Address1 line 1");
                //FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("Modified from source screen, Second property: Address1 line 2");
                //FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("Modified from source screen, Second property: Address1 line 3");
                //FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("Modified from source screen, Second property: Address1 line 4");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                Reports.TestStep = "Navigate to VSS and verify the changes of source screen is not reflected in Header section and pop up dialog in View settlement statement.";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("Second property modified address", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[2]/div[2]").FAGetText());
                FastDriver.NCSViewSettlementStatement.propertyPlusIcon.FAClick();
                Support.AreEqual("Second property modified address", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[6]/td[3]/textarea").FAGetText().ToString());
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                Reports.TestStep = "Edit the Third property in the pop up and verify it by deleting from source screen";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.propertyPlusIcon.FAClick();
                FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[7]/td[3]/textarea").FASetText("Third address modidfied");
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Support.AreEqual("Third address modidfied", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[4]/div[3]/div").FAGetText());
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                Reports.TestStep = "Navigate to Properties/Tax Info and delete the third Property detail";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info");
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                FastDriver.PropertiesSummary.Table.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.PropertiesSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Reports.TestStep = "Verify the deleted instance of property in Header section and pop up dialog";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.HeaderSection.FAGetText().Contains("Third address modidfied").ToString());//Header section
                FastDriver.NCSViewSettlementStatement.propertyPlusIcon.FAClick();
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.propertydetailsdialogbox.FAGetText().Contains("Third address modidfied").ToString());//Pop up dialog
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                #endregion
            }
            catch (Exception ex)
            { FailTest(ex.Message); }
        }
        [TestMethod]
        public void FMUC0135_REG0043()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "#US 672340 for Allow user to modify Lender Name and Address which needs to be displayed in the Settlement Statement Header section..";
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Through UI
                Reports.TestStep = "Create File with Commercial business type.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("420");

                if (!FastDriver.QuickFileEntry.Title.Selected)
                {
                    FastDriver.QuickFileEntry.Title.FAClick();
                }

                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                {
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                }

                Playback.Wait(100);
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.EscrowOwningOfficeOfficer.FASelectItem("Y, Yeshwanth");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("3000000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("1500000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("Property 1");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Agricultural Land");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationTRact.FASetText("Tract1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("First property: Address1 line 1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("First property: Address1 line 2");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("First property: Address1 line 3");
                FastDriver.QuickFileEntry.PropertyBookAddrLin4.FASetText("First property: Address1 line 4");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("City1");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("NV");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("89003");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Nye");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFN1");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLN1");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFN1");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLN1");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("420");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                #endregion

                #region Setting test data for Lender
                Reports.TestStep = "Navigate to New Loan screen and add Lender details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("800");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("2,20,000.00");
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to Assumption Loan screen and add Lender details";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("boa");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("473");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Playback.Wait(5000);
                //FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                //FastDriver.AddressBookSearchDlg.FileaddressBookRadio_1.FAClick();
                //Playback.Wait(5000);
                //FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio1.FAClick();
                //FastDriver.AddressBookSearchDlg.SwitchToDialogBottomFrame();
                //FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                #endregion

                #region Verify the Header section in the View settlement statement
                Reports.TestStep = "Navigate to viewsettlement statement and verify the header section";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Playback.Wait(3000);
                Reports.TestStep = "Verify the Lender section of Header section in ViewSettlement Statement";
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.customheaderLenderlabel.IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.LenderPlusIcon.IsDisplayed().ToString());
                Reports.TestStep = "Verify the Pop up dialog of Lender section of Header section in ViewSettlement Statement";
                FastDriver.NCSViewSettlementStatement.LenderPlusIcon.FAClick();
                Playback.Wait(3000);
                Support.AreEqual("The Northern Trust Company", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FAGetText().ToString());
                Support.AreEqual("4811 Emerson, Palatine, IL 60067     ", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/textarea").FAGetText().ToString());
                Support.AreEqual("First American Title Company", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[2]/textarea").FAGetText().ToString());
                Support.AreEqual("12600 Hesperia Road #C, Victorville, CA 92392     ", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[3]/textarea").FAGetText().ToString());
                Support.AreEqual("Lenders Advantage A Division Of First American Title Ins.", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[5]/td[2]/textarea").FAGetText().ToString());
                Support.AreEqual("15441 94Th Avenue, Orland Park, IL 60462     ", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[5]/td[3]/textarea").FAGetText().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/span/img[1]").IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/span/img[2]").IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/span/img[1]").IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/span/img[2]").IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.NameSelectAll.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.NameSelectAll.Enabled.ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.AddressSelectAll.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.AddressSelectAll.Enabled.ToString());
                Reports.TestStep = "Verify the Assumption Loan details not displayed in the Pop up dialog";
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAGetText().Contains("Bank of America").ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAGetText().Contains("World Savings Bank").ToString());
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                #endregion

                #region Edit the Lender details and Verify the modified changes in View Settlement statement
                Reports.TestStep = "Navigate to viewsettlement statement";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Playback.Wait(3000);
                Reports.TestStep = "Edit the Lender details and the verify the Broken link and refresh icon and verify the Refresh button functionality";
                FastDriver.NCSViewSettlementStatement.LenderPlusIcon.FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FASetText("Modified Name" + Keys.Tab);
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/span/img[1]").IsDisplayed().ToString());
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/span/img[2]").IsDisplayed().ToString());
                FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FASetText("" + Keys.Tab);
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Support.AreEqual("Name cannot be blank...", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FAGetText().ToString());
                FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/span/img[1]").FAClick();
                Support.AreEqual("The Northern Trust Company", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FAGetText().ToString());
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
                FastDriver.NCSViewSettlementStatement.LenderPlusIcon.FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FASetText("Lender Name modified" + Keys.Tab);
                FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/textarea").FASetText("Lender address modified" + Keys.Tab);
                FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/span/img[1]").FAClick();
                FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/span/img[1]").FAClick();
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/span/img[1]").IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/span/img[2]").IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/span/img[1]").IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/span/img[2]").IsDisplayed().ToString());
                Support.AreEqual("The Northern Trust Company", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FAGetText().ToString());
                Support.AreEqual("4811 Emerson, Palatine, IL 60067     ", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[3]/textarea").FAGetText().ToString());
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Support.AreEqual("The Northern Trust Company\r\n4811 Emerson, Palatine, IL 60067     ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[1]/div[1]").FAGetText());
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                Reports.TestStep = "Edit the second Lender details and also in the property source screen and the verify both the changes in the Header section in View Settlement Statement";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.LenderPlusIcon.FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[2]/textarea").FASetText("Second Lender Name modified");
                FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[3]/textarea").FASetText("");
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Support.AreEqual("Second Lender Name modified", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[1]/div[2]").FAGetText());
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                Reports.TestStep = "Navigate to New Loan screen and edit the second Lender detail";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.DoubleClick);
                FastDriver.NewLoanSummary.Edit.FAClick();
                Playback.Wait(3000);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("boa");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Navigate to VSS and verify the changes of source screen is not reflected in Header section and pop up dialog in View settlement statement.";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("Second Lender Name modified", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[1]/div[2]").FAGetText());
                FastDriver.NCSViewSettlementStatement.LenderPlusIcon.FAClick();
                Support.AreEqual("Second Lender Name modified", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[2]/textarea").FAGetText().ToString());
                Support.AreEqual("", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[3]/textarea").FAGetText().ToString());
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                Reports.TestStep = "Delete all the New Lender information and verify the pop up dialog and Header seciton";
                Reports.TestStep = "Navigate to New Loan screen and delete Lender details";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                Reports.TestStep = "Navigate to View Settlement statement";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Support.AreEqual("Bank of America", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[1]/div[1]").FAGetText());
                Support.AreEqual("World Savings Bank\r\n1144 Lake Street, Oak Park, IL 60301     ", FastDriver.NCSViewSettlementStatement.HeaderSection.FAFindElement(ByLocator.XPath, "//div[@id='tblHeaderData']/div[13]/div[1]/div[2]").FAGetText());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.HeaderSection.FAGetText().Contains("The Northern Trust Company\r\n4811 Emerson, Palatine, IL 60067     ").ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.HeaderSection.FAGetText().Contains("First American Title Company\r\n12600 Hesperia Road #C, Victorville, CA 92392     ").ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.HeaderSection.FAGetText().Contains("Lenders Advantage A Division Of First American Title Ins.\r\n15441 94Th Avenue, Orland Park, IL 60462     ").ToString());
                FastDriver.NCSViewSettlementStatement.LenderPlusIcon.FAClick();
                Support.AreEqual("Bank of America", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FAGetText().ToString());
                Support.AreEqual("World Savings Bank", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[2]/textarea").FAGetText().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAGetText().Contains("The Northern Trust Company").ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAGetText().Contains("First American Title Company").ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.lenderdetailsdialogbox.FAGetText().Contains("Lenders Advantage A Division Of First American Title Ins.").ToString());
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                #endregion
            }
            catch (Exception ex)
            { FailTest(ex.Message); }
        }
        [TestMethod]
        public void FMUC0135_REG0044()
        {
            try
            {
                Reports.TestDescription = "US 668248 Allow user to modify Buyer Name and Address which needs to be displayed in the View Settlement Statement Header section 670842 Allow user to modify Seller Name and Address which needs to be displayed in the Settlement Statement Header section.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log into FAST application automation region/office with automation credentials";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Reports.TestStep = "Set up a basic escrow order that contain multiple buyer/seller details";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.txtBusinessSourceGABID.FASetText("800");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                { FastDriver.QuickFileEntry.Title.FASetCheckbox(true); }
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                { FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true); }
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.FormType_CD.FAClick();
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Trust/Estate");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Business Entity");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2fni 2abcdefgh");
                FastDriver.QuickFileEntry.Seller2MiddleName.FASetText("Seller2mni 2abcdefgh");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2lni 2abcdefgh");
                FastDriver.QuickFileEntry.Seller2Suffix.FASetText("Selle");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2fnhi 2abcdefgh");
                FastDriver.QuickFileEntry.Buyer2MiddleName.FASetText("Buyer2mnhi 2abcdefgh");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2lnhi 2abcdefgh");
                FastDriver.QuickFileEntry.Buyer2Suffix.FASetText("Buyer");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("Property1name");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Retail");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("property1addre1line1");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("property1addre1line2");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("property1addre1line3");
                FastDriver.QuickFileEntry.PropertyBookAddrLin4.FASetText("property1addre1line4");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("property1addre1city");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("33610");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("hillsborough");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("FL");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Seller3ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab" + FAKeys.Tab);
                FastDriver.BuyerSellerSetup.TrustLastNameFor1099SReporting.FASetText("david warner maxwell" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "Trust/Estate", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Bangalore Mysore");
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "Individual", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("OK");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
                Playback.Wait(3000);
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Buyer3fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab" + FAKeys.Tab);
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FAClick();
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Testing refresh/broken link icons functionality on the buyer/seller details webpage dialog boxes";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.NCSViewSettlementStatement.sellerPlusIcon.FAClick();
                Playback.Wait(5000);
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.RefreshIcon.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.BrokenLink.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FASetText("!@#$%^&*()_+" + Keys.Tab);
                FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[3]/textarea").FASetText("1234aA!@#" + Keys.Tab);
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                int a = FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "refreshImage").GetAllVisible().Count();
                int b = FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "brokenImage").GetAllVisible().Count();
                Support.AreEqual("2", a.ToString());
                Support.AreEqual("2", b.ToString());
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.sellerPlusIcon.FAClick();
                Playback.Wait(5000);
                FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FASetText("!@#$%^&*()_+" + Keys.Tab);
                FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[3]/textarea").FASetText("1234aA!@#" + Keys.Tab);
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.sellerPlusIcon.FAClick();
                Playback.Wait(5000);
                int c = FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "refreshImage").GetAllVisible().Count();
                int d = FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "brokenImage").GetAllVisible().Count();
                Support.AreEqual("2", c.ToString());
                Support.AreEqual("2", d.ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                string[] e = new string[3];
                e[0] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610";
                e[1] = "1234aA!@#";
                e[2] = "property1addre1line2, property1addre1line4, Bangalore Mysore, FL 33610";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList()[i].FAGetText() == e[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes current address contents on the seller details webpage dialog box", false); }
                }
                string[] f = new string[3];
                f[0] = "!@#$%^&*()_+";
                f[1] = "Seller2fni 2abcdefgh Seller2mni 2abcdefgh Seller2lni 2abcdefgh Selle";
                f[2] = "Seller3ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtName").ToList()[i].FAGetText() == f[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes name contents on the seller details webpage dialog box", false); }
                }
                FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FASetText("" + Keys.Tab);
                Support.AreEqual("Name cannot be blank...", FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FAGetText(), "Verifying the watermark message");
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.IsDisplayed().ToString());
                /*Support.AreEqual("Name cannot be blank", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true).Clean(), "Verifying that the message is: Name cannot be blank");
                Playback.Wait(2000);
                FastDriver.NCSViewSettlementStatement.SwitchToContentFrame();
                Support.AreEqual("!@#$%^&*()_+", FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/table/tbody/tr[3]/td[2]/textarea").FAGetText());*/
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.buyerPlusIcon.FAClick();
                Playback.Wait(5000);
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.RefreshIcon.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.BrokenLink.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FASetText("!@#$%^&*()_+" + Keys.Tab);
                FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[3]/textarea").FASetText("1234aA!@#" + Keys.Tab);
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                int g = FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "refreshImage").GetAllVisible().Count();
                int h = FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "brokenImage").GetAllVisible().Count();
                Support.AreEqual("2", g.ToString());
                Support.AreEqual("2", h.ToString());
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.buyerPlusIcon.FAClick();
                Playback.Wait(5000);
                FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FASetText("!@#$%^&*()_+" + Keys.Tab);
                FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[3]/textarea").FASetText("1234aA!@#" + Keys.Tab);
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.buyerPlusIcon.FAClick();
                Playback.Wait(5000);
                int j = FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "refreshImage").GetAllVisible().Count();
                int k = FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "brokenImage").GetAllVisible().Count();
                Support.AreEqual("2", c.ToString());
                Support.AreEqual("2", d.ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                string[] l = new string[3];
                l[0] = "";
                l[1] = "1234aA!@#";
                l[2] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList()[i].FAGetText() == l[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes current address contents on the buyer details webpage dialog box", false); }
                }
                string[] m = new string[3];
                m[0] = "!@#$%^&*()_+";
                m[1] = "Buyer2fnhi 2abcdefgh Buyer2mnhi 2abcdefgh Buyer2lnhi 2abcdefgh Buyer";
                m[2] = "Buyer3fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtName").ToList()[i].FAGetText() == m[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes name contents on the buyer details webpage dialog box", false); }
                }
                FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FASetText("" + Keys.Tab);
                Support.AreEqual("Name cannot be blank...", FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/textarea").FAGetText(), "Verifying the watermark message");
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                Support.AreEqual("True", FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.IsDisplayed().ToString());
                /*Support.AreEqual("Name cannot be blank", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true).Clean(), "Verifying that the message is: Name cannot be blank");
                Playback.Wait(2000);
                FastDriver.NCSViewSettlementStatement.SwitchToContentFrame();
                Support.AreEqual("!@#$%^&*()_+", FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/table/tbody/tr[3]/td[2]/textarea").FAGetText());*/
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframecancelbutton.FAClick();
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                Reports.TestStep = "Editing source screens data and revalidating the functionality";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "BusinessEntity", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("Mahela Jayawardena" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "Individual", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Melbourne Swimming Pool");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("#17/40, 1F (B)" + FAKeys.Tab);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "Trust/Estate", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("James bond 123!@#" + FAKeys.Tab);
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FAClick();
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Type", "Individual", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.CurrentSetToProperty.FAClick();
                Playback.Wait(3000);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.SS.FAClick();
                Playback.Wait(5000);
                FastDriver.TopFrame.SwitchToContentFrame();
                FastDriver.NCSViewSettlementStatement.sellerPlusIcon.FAClick();
                Playback.Wait(5000);
                string[] n = new string[3];
                n[0] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610";
                n[1] = "1234aA!@#";
                n[2] = "property1addre1line2, property1addre1line4, Bangalore Mysore, FL 33610";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList()[i].FAGetText() == n[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes current address contents on the seller details webpage dialog box", false); }
                }
                string[] o = new string[3];
                o[0] = "!@#$%^&*()_+";
                o[1] = "Seller2fni 2abcdefgh Seller2mni 2abcdefgh Seller2lni 2abcdefgh Selle";
                o[2] = "Seller3ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtName").ToList()[i].FAGetText() == o[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes name contents on the seller details webpage dialog box", false); }
                }
                FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/span/img[1]").Highlight();
                FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/span/img[1]").FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[3]/span/img[1]").Highlight();
                FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[3]/span/img[1]").FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                FastDriver.NCSViewSettlementStatement.sellerPlusIcon.FAClick();
                Playback.Wait(5000);
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.RefreshIcon.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.BrokenLink.IsDisplayed().ToString());
                string[] p = new string[3];
                p[0] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610";
                p[1] = "Melbourne Swimming Pool, #17/40, 1F (B), OK";
                p[2] = "property1addre1line2, property1addre1line4, Bangalore Mysore, FL 33610";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList()[i].FAGetText() == p[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes current address contents on the seller details webpage dialog box", false); }
                }
                string[] q = new string[3];
                q[0] = "Mahela Jayawardena";
                q[1] = "Seller2fni 2abcdefgh Seller2mni 2abcdefgh Seller2lni 2abcdefgh Selle";
                q[2] = "Seller3ghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.sellerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtName").ToList()[i].FAGetText() == q[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes name contents on the seller details webpage dialog box", false); }
                }
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                Keyboard.SendKeys("^q");
                FastDriver.NCSViewSettlementStatement.buyerPlusIcon.FAClick();
                Playback.Wait(5000);
                string[] r = new string[3];
                r[0] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610";
                r[1] = "1234aA!@#";
                r[2] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList()[i].FAGetText() == r[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes current address contents on the buyer details webpage dialog box", false); }
                }
                string[] s = new string[3];
                s[0] = "!@#$%^&*()_+";
                s[1] = "Buyer2fnhi 2abcdefgh Buyer2mnhi 2abcdefgh Buyer2lnhi 2abcdefgh Buyer";
                s[2] = "Buyer3fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtName").ToList()[i].FAGetText() == s[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes name contents on the buyer details webpage dialog box", false); }
                }
                FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/span/img[1]").Highlight();
                FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[3]/td[2]/span/img[1]").FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[3]/span/img[1]").Highlight();
                FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElement(ByLocator.XPath, "//custom-header-pop-up[@id='customPopUp']/div/table/tbody/tr[4]/td[3]/span/img[1]").FAClick();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.FAClick();
                FastDriver.NCSViewSettlementStatement.buyerPlusIcon.FAClick();
                Playback.Wait(5000);
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.RefreshIcon.IsDisplayed().ToString());
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.BrokenLink.IsDisplayed().ToString());
                string[] t = new string[3];
                t[0] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610";
                t[1] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610";
                t[2] = "property1addre1line1, property1addre1line2, property1addre1line3, property1addre1line4, property1addre1city, FL 33610";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtAddr").ToList()[i].FAGetText() == t[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes current address contents on the buyer details webpage dialog box", false); }
                }
                string[] u = new string[3];
                u[0] = "James bond 123!@#";
                u[1] = "Buyer2fnhi 2abcdefgh Buyer2mnhi 2abcdefgh Buyer2lnhi 2abcdefgh Buyer";
                u[2] = "Buyer3fghi 2abcdefghi 3abcdefghi 4abcdefghi 5abcdefghi 6abcdefghi 7abcdefghi 8ab";
                for (int i = 0; i <= 2; i++)
                {
                    if (FastDriver.NCSViewSettlementStatement.buyerdetailsdialogbox.FAFindElements(ByLocator.Id, "txtName").ToList()[i].FAGetText() == u[i])
                    { }
                    else
                    { Reports.StatusUpdate("Error with htmltextboxes name contents on the buyer details webpage dialog box", false); }
                }
                Support.AreEqual("False", FastDriver.NCSViewSettlementStatement.dialogboxbottomframedonebutton.IsEnabled().ToString());
                Keyboard.SendKeys("^q");
                FastDriver.BottomFrame.Done();
                Playback.Wait(10000);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0135_REG0037()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion
                #region Loginto IIs and create file with business segment as commercial
                Reports.TestStep = "Loginto IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create file with business segment as commercial";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.Click();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Accommodation");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("Firstamway");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();


                #endregion
                #region Create Miscellaneous Disbursement instances
                Reports.TestStep = "Create Miscellaneous Disbursement instances";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("255");
                Playback.Wait(8000);

                FillMiscDisbursementDetail("Miscellaneous description1", "76.88", "34.65");


                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDLEASE01");
                Playback.Wait(8000);
                FillMiscDisbursementDetail("Miscellaneous description2", "237.45", "874.76");

                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDLEASE02");
                Playback.Wait(8000);
                FillMiscDisbursementDetail("Miscellaneous description3", "642.6", "13.78");
                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDFLINSR1");
                Playback.Wait(8000);
                FillMiscDisbursementDetail("Miscellaneous description4", "94753.65", "12.89");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to View Setlement Statement and validate Tooltip text on Miscellaneous Disbursement header
                Reports.TestStep = "Navigate to View Setlement Statement and validate Tooltip text on Miscellaneous Disbursement header";
                FastDriver.LeftNavigation.Navigate<NCSViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.");

                Support.AreEqual("Right click for subtotals", FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable.FindElements(By.TagName("tr"))[0].FAGetAttribute("title"), "Validate Tooltip text for Miscellaneous Disbursement header");



                #endregion
            }
            catch (Exception ex)
            { FailTest(ex.Message); }
        }
        [TestMethod]
        public void FMUC0135_REG0045()
        {
            try
            {
                Reports.TestDescription = "US#770456: To Verify Re-sequence the groups/individual charge in the Miscellaneous Disbursement section - UI";

                #region LOGIN
                #region data setup//change credentials here
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion
                Reports.TestStep = "Login into the IIS Side.";
                Reports.TestStep = "Login FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create File.";
                CreateFile_WS();
                #endregion

                #region Creating Instances
                Reports.TestStep = "Create a Instances on Misc Disbursement Details screen.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                Playback.Wait(3000);
                FillMiscDisbursementDetail(Description: "1stInstFirstcharge", BuyerCharge: "7865", SellerCharge: "9876");
                FastDriver.MiscDisbursementDetail.LoanEstimate.SendKeys(FAKeys.Tab);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "1stInstSecondcharge", 432154326.11, null, 654334562.55, null, 76.00);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "1stInstThirdcharge", 453, null, 876, null, 87.00);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "1stInstFourthcharge", 6541, null, 2345, null, null);
                FastDriver.MiscDisbursementDetail.Description1.JSClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.Click();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details -- Webpage Dialog", true, 20);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("1000");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("2000");

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                Playback.Wait(3000);

                Reports.TestStep = "Create a second Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                Playback.Wait(3000);
                FillMiscDisbursementDetail(Description: "2ndInstFirstCharge", BuyerCharge: "345212345.43", SellerCharge: "563212348.99");
                FastDriver.MiscDisbursementDetail.LoanEstimate.SendKeys(FAKeys.Tab);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "2ndInstSecondCharge", null, null, null, null, 76.00);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "2ndInstThirdCharge", 231, null, 432, null, 65.99);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "2ndInstFourthCharge", 7643, null, 2121, null, null);
                FastDriver.MiscDisbursementDetail.Description1.JSClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.Click();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details -- Webpage Dialog", true, 20);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2551");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("2551");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("2551");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");

                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2921");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("2921");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("2921");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Summary screen and Click on NEW.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.New.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();

                Reports.TestStep = "Create a Third Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB3");
                Playback.Wait(3000);
                FillMiscDisbursementDetail(Description: "3rdInstFirstCharge", BuyerCharge: "7676", SellerCharge: "6753");
                FastDriver.MiscDisbursementDetail.LoanEstimate.SendKeys(FAKeys.Tab);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "3rdInstSecondCharge", 345532134.33, null, 546887832.11, null, 86.00);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "3rdInstThirdCharge", 21, null, 43, null, 435.88);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "3rdInstFourthCharge", 4251, null, 1143, null, null);
                FastDriver.MiscDisbursementDetail.Description.JSClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.Click();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details -- Webpage Dialog", true, 20);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("114321456.11");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("256");

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                #endregion

                #region Creating Groups in Miscellaneous Disbursement Section
                Reports.TestStep = "Navigate to View Settlestatement";
                FastDriver.NCSViewSettlementStatement.Open();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable.Highlight();

                #region Creating First Group
                Reports.TestStep = "Creating  First Group on Miscellaneous Disbursement section";
                var documents = new List<string> { "1stInstFirstcharge ", "2ndInstSecondCharge ", "1stInstSecondcharge " };
                FastDriver.NCSViewSettlementStatement.SelectDocuments(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents);
                var documents1 = new List<string> { "2ndInstSecondCharge " };
                RightclickonCharge(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents1);
                FastDriver.NCSViewSettlementStatement.CreateGroup.Highlight();
                FastDriver.NCSViewSettlementStatement.CreateGroup.FASelectContextMenuItem();
                #endregion

                #region Creating Second Group
                Reports.TestStep = "Creating Second Group on Miscellaneous Disbursement section";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                var documents2 = new List<string> { "3rdInstSecondCharge ", "2ndInstFirstCharge ", "3rdInstFirstCharge " };
                FastDriver.NCSViewSettlementStatement.SelectDocuments(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents2);
                var documents3 = new List<string> { "3rdInstFirstCharge " };
                RightclickonCharge(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents3);
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.RemovefromGroupDisabled.IsEnabled(), "Verifying RemovefromGroup Button Disiabled in Miscellaneous Disbursement section");
                FastDriver.NCSViewSettlementStatement.CreateGroup.Highlight();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.AddtoGroup.IsEnabled(), "Verifying AddtoGroup button  enabled in Miscellaneous Disbursement section");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.CreateGroup.IsEnabled(), "Verifying CreateGroup button  enabled in Miscellaneous Disbursement section");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.CreateGroup.IsDisplayed(), "Verifying CreateGroup Button Displayed in Miscellaneous Disbursement section");
                FastDriver.NCSViewSettlementStatement.CreateGroup.FASelectContextMenuItem();
                Playback.Wait(8000);
                #endregion

                #region Creating Third Group
                Reports.TestStep = "Creating Second Group on Miscellaneous Disbursement section";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                var documents4 = new List<string> { "1stInstThirdcharge ", "2ndInstThirdCharge ", "3rdInstThirdCharge " };
                FastDriver.NCSViewSettlementStatement.SelectDocuments(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents4);
                var documents5 = new List<string> { "3rdInstThirdCharge " };
                RightclickonCharge(FastDriver.NCSViewSettlementStatement.MiscellaneousDisbursementTable, documents5);
                Support.AreEqual(false, FastDriver.NCSViewSettlementStatement.RemovefromGroupDisabled.IsEnabled(), "Verifying RemovefromGroup Button Disiabled in Miscellaneous Disbursement section");
                FastDriver.NCSViewSettlementStatement.CreateGroup.Highlight();
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.AddtoGroup.IsEnabled(), "Verifying AddtoGroup button  enabled in Miscellaneous Disbursement section");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.CreateGroup.IsEnabled(), "Verifying CreateGroup button  enabled in Miscellaneous Disbursement section");
                Support.AreEqual(true, FastDriver.NCSViewSettlementStatement.CreateGroup.IsDisplayed(), "Verifying CreateGroup Button Displayed in Miscellaneous Disbursement section");
                FastDriver.NCSViewSettlementStatement.CreateGroup.FASelectContextMenuItem();
                Playback.Wait(8000);
                #endregion


                FastDriver.BottomFrame.Done();
                Playback.Wait(8000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(5000);
                #endregion

                #region Verify the re-sequencing of charges within Groups under Miscellaneous Disbursement section
                Reports.TestStep = "Verify the re-sequencing of charges within Groups under Miscellaneous Disbursement section";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd__1st_1stCharge.Highlight();
                int BBB = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd__1st_1stCharge.FAGetLocation().Y;
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_2nd_2ndCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd__1st_1stCharge);
                Support.AreNotEqual(BBB.ToString(), FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd__1st_1stCharge.FAGetLocation().Y.ToString(), "Validation After swapping");
                FastDriver.BottomFrame.Reset();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(3000);
                BBB += 1;
                Support.AreEqual(BBB.ToString(), FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd__1st_1stCharge.FAGetLocation().Y.ToString(), "Validation After Reset Button");
                string CCC = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_2nd_2ndCharge.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_2nd_2ndCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd__1st_1stCharge);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Support.AreNotEqual(CCC, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_2nd_2ndCharge.FAGetLocation().Y.ToString(), "Validation After swapping");
                #endregion

                #region Resquence the Groups on Miscellaneous Disbursement section
                Reports.TestStep = "Resquence the Groups on Miscellaneous Disbursement section";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_FirstGroup.Highlight();
                string LInst1 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_FirstGroup.FAGetLocation().Y.ToString();
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_ThirdGroup.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_FirstGroup);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                string Linst3 = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_ThirdGroup.FAGetLocation().Y.ToString();
                Support.AreNotEqual(LInst1, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_FirstGroup.FAGetLocation().Y.ToString(), "Validation After navigating to Some other page");
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_ThirdGroup.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Commission);
                Playback.Wait(1000);
                Support.AreEqual(Linst3, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_ThirdGroup.FAGetLocation().Y.ToString(), "Validation After moving Out from Instance");

                #endregion

                #region Verify the re-sequencing of UnGrouped charges under Miscellaneous Disbursement section
                Reports.TestStep = "Verify the re-sequencing of UnGrouped charges under Miscellaneous Disbursement section";
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();//System should display the NCS View Settlement Statement screen with defaults
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_3rd_4thCharge.Highlight();
                int URC = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_1st_4thCharge.FAGetLocation().Y;
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_3rd_4thCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_1st_4thCharge);
                Support.AreNotEqual(URC.ToString(), FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_1st_4thCharge.FAGetLocation().Y.ToString(), "Validation After swapping");
                string RUC = FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_3rd_4thCharge.FAGetLocation().Y.ToString();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_3rd_4thCharge.FADragAndDrop(FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd__1st_1stCharge);
                Support.AreEqual(RUC, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_3rd_4thCharge.FAGetLocation().Y.ToString(), "Validation after instering into Groups ");
                #endregion

                #region Navigate to Miscellaneous Disbursement Screen
                Reports.TestStep = "Navigate to  Misc Disbursement Details screen and Perform Action like Remove Instance/Edit Charges/Changing Gab ID/Updating Payee Name.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 1 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();
                Playback.Wait(3000);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("Boa");
                Playback.Wait(3000);
                FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText("5439.00");
                FastDriver.MiscDisbursementDetail.SellerCharge.FASetText("4321.00");
                FastDriver.BottomFrame.Done();
                FastDriver.MiscellaneousDisbursementSummary.WaitForScreenToLoad();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 2 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();
                Playback.Wait(3000);
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.Description1.JSClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.Click();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details -- Webpage Dialog", true, 20);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.USEDEFAULT.FASetCheckbox(false);
                if (FastDriver.PaymentDetailsDlg.PayeeName.Enabled == true)
                {
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Updated Payee Name for Testing Misc Disd");
                }
                else
                {
                    FailTest("Payee textbox was not enabled.");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();
                FastDriver.MiscellaneousDisbursementSummary.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 3 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Remove.FAClick();
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(3000);
                #endregion

                #region Validating Already resqenced Items
                Reports.TestStep = "Navigate to NCSViewSettlementStatement and verify the re-sequencing of charges/instances after inserting charge/Instances under Miscellaneous Disbursement Screen";
                FastDriver.NCSViewSettlementStatement.Open().WaitForScreenToLoad();//System should display the NCS View Settlement Statement screen with defaults
                Playback.Wait(3000);
                Support.AreNotEqual(BBB.ToString(), FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd__1st_1stCharge.FAGetLocation().Y.ToString(), "Validation after Insteting charges in MISD screen");
                Support.AreNotEqual(CCC, FastDriver.NCSViewSettlementStatement.Disbursement_Paid_Misd_2nd_2ndCharge.FAGetLocation().Y.ToString(), "Validation after Insteting charges in MISD screen");
                #endregion


            }
            catch (Exception ex)
            {
                FailTest("Test case US_770456_NCS_849698 failed because " + ex.Message);
            }
        }
        #endregion
        #region r11.2016
        /// <summary>
        /// FMUC0135_REG0046 - 
        /// </summary>
        [TestMethod]
        public void FMUC0135_REG0046()
        {
            Reports.TestDescription = "To test US#813834- To verify  Do not display the payee name in the charge description on Commission  Section";
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                #region Loginto IIs and create file with business segment as commercial
                Reports.TestStep = "Loginto IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create file with business segment as commercial";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.btnBusinessSourceGABFind.Click();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
                FastDriver.QuickFileEntry.TransactionType.FASelectItem("Accommodation");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("Firstamway");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("92707");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
                FastDriver.BottomFrame.Done();


                #endregion

                #region Navigate to REB screen and create REB instances with REB charges
                Reports.TestStep = "Navigate to REB screen and create REB instances with REB charges";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(5000);
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDSLLRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("200.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("300.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Seller REBC Desc1" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("20.00" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText("30.00" + FAKeys.Tab);

                Keyboard.SendKeys("{TAB}");

                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription2.FASetText("Seller REBC Desc2" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit2.FASetText("10.00" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit1.FASetText("40.00" + FAKeys.Tab);
                Keyboard.SendKeys("{TAB}");
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText("Seller POC by Broker" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("60.00" + FAKeys.Tab);
                Keyboard.SendKeys("{TAB}");

                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDBUYRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("400.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("100.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Buyer REBC Desc" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("600.00" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText("150.00" + FAKeys.Tab);
                Keyboard.SendKeys("{TAB}");
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText("Buyer POC by Broker" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("26.66" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FADoubleClick();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();

                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("12,345,678,912.22" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Other1REBCharges" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("12,456,789,230.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FADoubleClick();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDOTHRBR2");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForElementToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("56.55" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("3.55" + FAKeys.Tab);

                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText("Other2POC by Broker" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("20.50" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify UnSubtotal functionality
                FastDriver.NCSViewSettlementStatement.Open();
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(2000);
                FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.FASetCheckbox(false);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.NewCommissionsTable.Highlight();
                Reports.TestStep = "Verify Without Subtotal functionality for Buyer Broker in Commission Section";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 1, 1);
                Support.AreEqual("Broker: Buyer's Broker 1 for HUD Test Name 1 Buyer's Broker 1 for HUD Test Name 2", Description, "Validating the Buyer Broker Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 1, 2);
                Support.AreEqual("Real Estate Commission", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("400.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("100.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 1, 3);
                Support.AreEqual("Buyer REBC Desc", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("600.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("150.00", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 1, 4);
                Support.AreEqual("Buyer POC by Broker POC $26.66", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                Reports.TestStep = "Verify Without Subtotal functionality for Seller Broker in Commission Section";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 1);
                Support.AreEqual("Broker: Seller's Broker 1 for HUD Test Name 1 Seller's Broker 1 for HUD Test Name 2", Description, "Validating Seller Broker Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 2);
                Support.AreEqual("Real Estate Commission", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("200.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("300.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 3);
                Support.AreEqual("Seller REBC Desc1", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("20.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("30.00", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 4);
                Support.AreEqual("Seller REBC Desc2", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("10.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("40.00", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 5);
                Support.AreEqual("Seller POC by Broker POC $60.00", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Verify Without Subtotal functionality for Other Broker in Commission Section";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 3, 1);
                Support.AreEqual("Broker: Other Broker 1 for HUD Test Name 1 Other Broker 1 for HUD Test Name 2", Description, "Validating the Other Broker Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 3, 2);
                Support.AreEqual("Real Estate Commission", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("12,345,678,912.22", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 3, 3);
                Support.AreEqual("Other1REBCharges", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("12,456,789,230.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Verify Without Subtotal functionality for Other Broker1 in Commission Section";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 4, 1);
                Support.AreEqual("Broker: Other Broker 2 for HUD Test Name 1 Other Broker 2 for HUD Test Name 2", Description, "Validating the Other Broker Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 4, 2);
                Support.AreEqual("Real Estate Commission", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("56.55", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("3.55", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 4, 3);
                Support.AreEqual("Other2POC by Broker POC $20.50", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");



                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion

                #region Verify Subtotal functionality
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                Playback.Wait(2000);
                FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.FASetCheckbox(true);
                FastDriver.NCSViewSettlementStatement.WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.NewCommissionsTable.Highlight();
                Reports.TestStep = "Verify Subtotal functionality for Buyer Broker in Commission Section";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 1, 1);
                Support.AreEqual("Total to Buyer's Broker 1 for HUD Test Name 1 Buyer's Broker 1 for HUD Test Name 2", Description, "Validating the Buyer Broker Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("200.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("50.00", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 1, 2);
                Support.AreEqual("Real Estate Commission B: 400.00\r\nS: 100.00", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 1, 3);
                Support.AreEqual("Buyer REBC Desc B: (600.00)\r\nS: (150.00)", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 1, 4);
                Support.AreEqual("Buyer POC by Broker (POC 26.66)", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                Reports.TestStep = "Verify  Subtotal functionality for Seller Broker in Commission Section";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 1);
                Support.AreEqual("Total to Seller's Broker 1 for HUD Test Name 1 Seller's Broker 1 for HUD Test Name 2", Description, "Validating Seller Broker Header under Description Column");
                Support.AreEqual("170.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("230.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 2);
                Support.AreEqual("Real Estate Commission B: 200.00\r\nS: 300.00", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 3);
                Support.AreEqual("Seller REBC Desc1 B: (20.00)\r\nS: (30.00)", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 4);
                Support.AreEqual("Seller REBC Desc2 B: (10.00)\r\nS: (40.00)", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 5);
                Support.AreEqual("Seller POC by Broker (POC 60.00)", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Validating  Subtotal functionality for Other Broker in Commission Section";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 3, 1);
                Support.AreEqual("Total to Other Broker 1 for HUD Test Name 1 Other Broker 1 for HUD Test Name 2", Description, "Validating the Other Broker Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("12,456,789,230.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("12,345,678,912.22", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 3, 2);
                Support.AreEqual("Real Estate Commission S: 12,345,678,912.22", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 3, 3);
                Support.AreEqual("Other1REBCharges B: (12,456,789,230.00)", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Validating  Subtotal functionality for Other Broker1 in Commission Section";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 4, 1);
                Support.AreEqual("Total to Other Broker 2 for HUD Test Name 1 Other Broker 2 for HUD Test Name 2", Description, "Validating the Other Broker Header under Description Column");
                Support.AreEqual("56.55", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("3.55", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 4, 2);
                Support.AreEqual("Real Estate Commission B: 56.55\r\nS: 3.55", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 4, 3);
                Support.AreEqual("Other2POC by Broker (POC 20.50)", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");



                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion

                #region Edit REB charges by adding the charge or removing the charge
                Reports.TestStep = "Navigate to REB and Updated the GAB ID";
                FastDriver.RealEstateBrokerAgentSummary.Open().WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(2, "Other Broker 1 for HUD Test Name 1", 2, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("BOA");
                FastDriver.BottomFrame.Done();


                

                #endregion

                #region Navigate to View SS and verify the PayeeName As per New Gab ID Name
                Reports.TestStep = "Navigate to View SS ";
                FastDriver.NCSViewSettlementStatement.Open().WaitForScreenToLoad();
                FastDriver.NCSViewSettlementStatement.Commissions_SubtotalCheckbox.FASetCheckbox(false);
                FastDriver.NCSViewSettlementStatement.NewCommissionsTable.Highlight();
                Reports.TestStep = "Verify Without Subtotal functionality for Seller Broker in Commission Section After updating GAB ID in Source Screen";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 1);
                Support.AreEqual("Broker: Lenders Advantage A Division Of First American Title Ins.", Description, "Validating Seller Broker Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 2);
                Support.AreEqual("Real Estate Commission", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("200.00", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("300.00", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 3);
                Support.AreEqual("Seller REBC Desc1", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("20.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("30.00", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 4);
                Support.AreEqual("Seller REBC Desc2", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("10.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("40.00", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 2, 5);
                Support.AreEqual("Seller POC by Broker POC $60.00", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");

                Reports.TestStep = "Verify Without Subtotal functionality for Other Broker in Commission Section After updating GAB ID in Source Screen";
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 3, 1);
                Support.AreEqual("Broker: Bank of America", Description, "Validating the Other Broker Header under Description Column");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 3, 2);
                Support.AreEqual("Real Estate Commission", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("12,345,678,912.22", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                VerifydatainSS(FastDriver.NCSViewSettlementStatement.NewCommissionsTable, 3, 3);
                Support.AreEqual("Other1REBCharges", Description, "Validating Charge description without PayeeName");
                Support.AreEqual("", BuyerCharge, "Validating Buyer Charge Value in BuyerCharge Column");
                Support.AreEqual("12,456,789,230.00", BuyerCredit, "Validating Buyer Credit Value in BuyerCredit Column");
                Support.AreEqual("", SellerCharge, "Validating Seller Charge Value in SellerCharge Column");
                Support.AreEqual("", SellerCredit, "Validating Seller Credit Value in SellerCredit Column");
                #endregion
            }
            catch (Exception ex)
            { FailTest(ex.Message); }
        }
        #endregion
    }
}