﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using System.Linq;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using System.Windows.Input;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;
using SeleniumInternalHelpers;
using System.IO;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using System.Text;


namespace EscrowTransactions
{
    /// <summary>
    /// Summary description for FMUC0074 Void Disbursements
    /// </summary>
    [CodedUITest]

    public class FMUC0074 : MasterTestClass
    {
        #region Class Level Objects
        Dictionary<string, string> PropertyDictry = new Dictionary<string, string>();
        Dictionary<string, string> BuyerDictry = new Dictionary<string, string>();
        Dictionary<string, string> SellerDictry = new Dictionary<string, string>();
        #endregion

        #region BAT
        #region Test FMUC0074_BAT0001

        /// <summary>
        /// MF_01: To create issued feetransfer,check and created wire disbursements in Active Disbursement Summary.
        /// </summary>
        [TestMethod]
        public void FMUC0074_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF_01: To create issued feetransfer,check and created wire disbursements in Active Disbursement Summary.";

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Verify the data in File Home Page
                Reports.TestStep = "Verify the data in File Home Page";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();


                string FileFromFHP = FastDriver.FileHomepage.GetFileNumber();
                Support.AreEqual(FileNumber1, FileFromFHP, true);
                #endregion

                #region Navigate to Survey & entering GAB.
                Reports.TestStep = "Navigate to Survey & entering GAB.";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Change the description and charge.
                Reports.TestStep = "Change the description and charge.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: "Changed desc", buyerCharge: 10.00, sellerCharge: 11.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter first fee in Title and escrow.
                Reports.TestStep = "Enter first fee in Title and escrow.";
                EnterFeeInTitleEscrowTab();
                FastDriver.BottomFrame.Done();
                #endregion

                #region To click on Fee Transfer button in Active Disbursement Summary.
                Reports.TestStep = "To click on Fee Transfer button in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.ChangeFileStatusDlg.SwitchToDialogContentFrame();
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                PerformPrintDelivery();
                #endregion

                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                #region To Issue the check in Active Disbursement Summary.
                Reports.TestStep = "To Issue the check in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                Keyboard.SendKeys("{l}", ModifierKeys.Control);
                PerformPrintDeliveryWithPasswordDialog();
                FastDriver.BottomFrame.Done();
                #endregion

                #region To click on Void button in Active Disbursement Summary.
                Reports.TestStep = "To click on Void button in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.GetText).Message.ToString(), true);
                FastDriver.ActiveDisbursementSummary.Void.FAClick();
                #endregion

                #region Deposit Summary.
                Reports.TestStep = "Deposit Summary.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.SetVoidReason("Reason to void the Disbursement");
                FastDriver.VoidDlg.ClickCancel();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region To click on Void button in Active Disbursement Summary.
                Reports.TestStep = "To click on Void button in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Void.FAClick();
                #endregion

                #region To Void Disbursement.
                Reports.TestStep = "To Void Disbursement.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.SetVoidReason("Reason to void the Disbursement");
                FastDriver.VoidDlg.ClickOk();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region To verify the voided disbursement is changed to Pend.
                Reports.TestStep = "To verify the voided disbursement is changed to Pend.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.GetText).Message.ToString(), true);
                #endregion

                #region Navigate to Disbursement History To verify the voided disbursement.
                Reports.TestStep = "Navigate to Disbursement History.";
                FastDriver.DisbursementHistory.Open();
                Reports.TestStep = "To verify the voided disbursement.";
                Support.AreEqual("Void", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "F", "Status", TableAction.GetText).Message.ToString(), true);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest("This TestMethod failed because: " + ex.Message);
            }
        }
        #endregion

        #endregion BAT

        #region REG


        #region Test FMUC0074_REG0001
        /// <summary>
        /// FM2285_FM2494_FM2495_FM2486_FM2485: Creating charges and Issuing and Voiding, FM2283: Disbursement Summary History.
        /// </summary>
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void FMUC0074_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM2285_FM2494_FM2495_FM2486_FM2485: Creating charges and Issuing and Voiding, FM2283: Disbursement Summary History.";

                #region Data
                var sdate = string.Empty;
                #endregion

                #region Login to file side.
                Reports.TestStep = "Login to file side.";
                IISLOGIN();
                #endregion

                #region Create Order.
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                #endregion

                #region Verify the data in File Home Page
                Reports.TestStep = "Verify the data in File Home Page";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Verify the data in File Home Page";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                PropertyDictry = FastDriver.FileHomepage.GetPropDetails;
                BuyerDictry = FastDriver.FileHomepage.GetByrDtlsOnFhp;
                SellerDictry = FastDriver.FileHomepage.GetSelrDtlsOnFhp;

                string FileFromFHP = FastDriver.FileHomepage.GetFileNumber();
                Support.AreEqual(FileNumber1, FileFromFHP, true);

                Support.AreEqual("Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem().ToString().Trim(), true);
                Support.AreEqual("5,000.00", FastDriver.FileHomepage.TermsDatesPrice.FAGetValue().ToString().Trim(), true);
                Support.AreEqual("J305", PropertyDictry["PropertyName"], true);
                Support.AreEqual("", PropertyDictry["PropertyType"], true);
                Support.AreEqual("Lot1", PropertyDictry["PropertyLotName"], true);
                Support.AreEqual("Block1", PropertyDictry["PropertyBlock"], true);
                Support.AreEqual("Unit1", PropertyDictry["PropertyUnit"], true);
                Support.AreEqual("", PropertyDictry["PropertyPropTaxAPN1"], true);
                Support.AreEqual("", PropertyDictry["PropertyPropTaxAPN2"], true);
                Support.AreEqual("J305", PropertyDictry["PropertyBookAddressLine1"], true);
                Support.AreEqual("JJEJAMQ", PropertyDictry["PropertyBookAddressLine2"], true);
                Support.AreEqual("JJEJAMQ", PropertyDictry["PropertyBookAddressLine3"], true);
                Support.AreEqual("ALBANY", PropertyDictry["PropertyAddressBookCity"], true);
                Support.AreEqual("CA", PropertyDictry["PropertyState"], true);
                Support.AreEqual("ALAMEDA", PropertyDictry["PropertyCounty"], true);


                Support.AreEqual("Individual", BuyerDictry["Buyer1Type"], true);
                Support.AreEqual("Buyer1Firstname", BuyerDictry["Buyer1FirstName"], true);
                Support.AreEqual("Buyer1Lastname", BuyerDictry["Buyer1LastName"], true);
                Support.AreEqual("Husband/Wife", BuyerDictry["Buyer2Type"], true);
                Support.AreEqual("Buyer2Firstname", BuyerDictry["Buyer2FirstName"], true);
                Support.AreEqual("Buyer2SpouseName", BuyerDictry["Buyer2SpouseFirstName"], true);
                Support.AreEqual("Buyer2LastName", BuyerDictry["Buyer2SpouseLastName"], true);
                Support.AreEqual("Individual", SellerDictry["Seller1Type"], true);
                Support.AreEqual("Seller1FirstName", SellerDictry["Seller1FirstName"], true);
                Support.AreEqual("Seller1Lastname", SellerDictry["Seller1LastName"], true);
                Support.AreEqual("Husband/Wife", SellerDictry["Seller2Type"], true);
                Support.AreEqual("Seller2Firstname", SellerDictry["Seller2FirstName"], true);
                Support.AreEqual("Seller2SpouseName", SellerDictry["Seller2SpouseFirstName"], true);
                Support.AreEqual("Seller2Lastname", SellerDictry["Seller2SpouseLastName"], true);
                #endregion

                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                #region Scan and verify scanned document doc in DocRep
                Reports.TestStep = "Click on Scan button for scan.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                string s = FastDriver.DocumentRepository.Scan.IsDisplayed().ToString();
                if (FastDriver.DocumentRepository.Scan.IsDisplayed().ToString() == "False")
                {
                    FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                    FastDriver.DocumentRepository.WaitForTemplatesScreenToLoad();
                }

                FastDriver.DocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Open button and load the image document.";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)

                Reports.TestStep = "Save the TIF Doc.";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Payoff Demand/Bills", "PO-Invoice", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

                Reports.TestStep = "Navigate to document Repository.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();

                Reports.TestStep = "Verify that Document is uploaded to the FAST.";
                FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "PO-Invoice AFFIX INV", 4, TableAction.Click);
                #endregion

                #region Navigate to Survey & entering GAB.
                Reports.TestStep = "Navigate to Survey & entering GAB.";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add Lease Charge
                Reports.TestStep = "Change the description and charge.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, "Changed Desc", buyerCharge: 10.00, sellerCharge: 11.00);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter first fee in Title and escrow.
                EnterFeeInTitleEscrowTab();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify the status of Void button and status of Fund after the fee is voided.
                Reports.TestStep = "Navigate to Active Disbursement Summary screen.";
                FastDriver.ActiveDisbursementSummary.Open();
                Reports.TestStep = "Verify the status of Void button and status of Fund before the fee is voided";
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.GetText).Message.ToString().Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.Click);
                Support.AreEqual("false", FastDriver.ActiveDisbursementSummary.Void.IsEnabled().ToString().Trim().ToLower(), true);

                Reports.TestStep = "To click on Fee Transfer button in Active Disbursement Summary.";
                // FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();

                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.ChangeFileStatusDlg.SwitchToDialogContentFrame();
                FastDriver.DialogBottomFrame.ClickCancel();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                PerformPrintDelivery();
                #endregion

                #region To Issue the check in Active Disbursement Summary.
                Reports.TestStep = "To Issue the check in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                Keyboard.SendKeys("{l}", ModifierKeys.Control);
                PerformPrintDeliveryWithPasswordDialog();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Convert to wire
                Reports.TestStep = "Click on Edit Button.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Pending", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();

                Reports.TestStep = "Convert to wire attach Instruction.";
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.ConvertToWire();
                #endregion

                #region Disburse the wire.
                Reports.TestStep = "Select the wire and Disburse.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Wire.FAClick();
                FastDriver.DisburseWires.WaitForScreenToLoad();
                FastDriver.DisburseWires.Disburse.FAClick();

                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");
                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region To click on Void button in Active Disbursement Summary, Cancel void.
                Reports.TestStep = "To click on Void button in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.GetText).Message.ToString().Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                if (FastDriver.ActiveDisbursementSummary.Void.IsEnabled().ToString().ToLower() == "true")
                {
                    FastDriver.ActiveDisbursementSummary.Void.FAClick();
                }

                Reports.TestStep = "Deposit Summary.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.SetVoidReason("Reason to void the Disbursement");
                FastDriver.VoidDlg.ClickCancel();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region To click on Void button in Active Disbursement Summary, OK Void.
                Reports.TestStep = "To click on Void button in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                if (FastDriver.ActiveDisbursementSummary.Void.IsEnabled().ToString().ToLower() == "true")
                {
                    FastDriver.ActiveDisbursementSummary.Void.FAClick();
                }

                Reports.TestStep = "Deposit Summary.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.SetVoidReason("Reason to void the Disbursement");
                FastDriver.VoidDlg.ClickOk();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region To verify that the voided Fee is changed to Pend and Void button is disabled.
                Reports.TestStep = "To verify that the voided disbursement is changed to Pend.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Status", TableAction.GetText).Message.ToString().Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Fee Transfer", "Funds", TableAction.Click);
                Reports.TestStep = "To verify taht the void button is disabled.";
                Support.AreEqual("false", FastDriver.ActiveDisbursementSummary.Void.IsEnabled().ToString().Trim().ToLower(), true);
                #endregion

                #region Select Wire and click on Void.
                Reports.TestStep = "Select Wire and click on Void.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Void.FAClick();

                Reports.TestStep = "To Void Disbursement.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.SetVoidReason("Reason to void the Disbursement");
                FastDriver.VoidDlg.ClickOk();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region To verify that After Void Wire Void Button is disable and Fund is in Pend status.
                Reports.TestStep = "To verify that After Void Wire Void Button is disable and Fund is in Pend status.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Status", TableAction.GetText).Message.ToString().Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Status", TableAction.Click);
                Support.AreEqual("false", FastDriver.ActiveDisbursementSummary.Void.IsEnabled().ToString().Trim().ToLower(), true);
                #endregion

                #region Select Check and click on Void.
                Reports.TestStep = "Select Check and click on Void.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Funds", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Void.FAClick();

                Reports.TestStep = "To Void Disbursement.";
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.SetVoidReason("Reason to void the Disbursement");
                FastDriver.VoidDlg.ClickOk();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region To verify that After Void Check Void Button is disable and Fund is in Pend status.
                Reports.TestStep = "To verify that After Void Check Void Button is disable and Fund is in Pend status.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4,986.01", "Status", TableAction.GetText).Message.ToString().Trim(), true);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "4,986.01", "Status", TableAction.Click);
                Support.AreEqual("false", FastDriver.ActiveDisbursementSummary.Void.IsEnabled().ToString().Trim().ToLower(), true);
                #endregion

                #region To verify the Wire after Pending status is in Created status.
                Reports.TestStep = "To verify the Wire after Pending status is in Created status.";
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Created", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Wire", "Status", TableAction.GetText).Message.ToString().Trim(), true);
                #endregion

                #region To verify the voided disbursements.
                Reports.TestStep = "Navigate to Disbursement History.";
                FastDriver.DisbursementHistory.Open();

                Reports.TestStep = "To verify the Voided Fee Status.";
                Support.AreEqual("Void", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "F", "Status", TableAction.GetText).Message.ToString().Trim(), true);

                Reports.TestStep = "Verify for the Voided Wire Status.";
                Support.AreEqual("Void", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "W", "Status", TableAction.GetText).Message.ToString().Trim(), true);

                Reports.TestStep = "Verify for the Voided Check Status.";
                Support.AreEqual("Void", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "C", "Status", TableAction.GetText).Message.ToString().Trim(), true);
                #endregion

                #region Verify for the Issued Date.
                Reports.TestStep = "Verify for the Issued Date.";
                sdate = DateTime.Now.ToString("MM/dd/yyyy");
                sdate = sdate.Replace("/", "-");
                Support.AreEqual(sdate, FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Tp.", "W", "Issue Date", TableAction.GetText).Message.ToString().Trim(), true);
                #endregion
            }

            catch (Exception ex)
            {
                FailTest("This TestMethod failed because: " + ex.Message);
            }
        }
        #endregion

        #region Test FMUC0074_REG0002
        /// <summary>
        /// FM2285_FM2494_FM2495_FM2486_FM2485: Creating charges and Issuing and Voiding - covered in FMUC0074_REG0001.
        /// </summary>
        [TestMethod, Obsolete]
        public void FMUC0074_REG0002()
        {
            Reports.TestDescription = "FM2285_FM2494_FM2495_FM2486_FM2485: Creating charges and Issuing and Voiding - covered in FMUC0074_REG0001.";
            Reports.StatusUpdate("The same has been covered in FMUC0074_REG0001.", true);
        }
        #endregion

        #region Test FMUC0074_REG0003
        /// <summary>
        /// FM2283: Disbursement Summary History.
        /// </summary>
        [TestMethod, Obsolete]
        public void FMUC0074_REG0003()
        {
            Reports.TestDescription = "FM2283: Disbursement Summary History - covered in FMUC0074_REG0001.";
            Reports.StatusUpdate("The same has been covered in FMUC0074_REG0001.", true);
        }
        #endregion

        #region Test FMUC0074_REG0004
        /// <summary>
        /// FM2282 : Validate transmission date
        /// </summary>
        [TestMethod]
        public void FMUC0074_REG0004()
        {
            Reports.TestDescription = "FM2282 : Validate transmission date";

            #region Login to file side.
            Reports.TestStep = "Login to file side.";
            IISLOGIN();
            #endregion

            #region Validate the Pending file.
            Reports.TestStep = "Validate the Pending file.";
            FastDriver.TrustAccounting.Open();
            //int Count1 = FastDriver.WebDriver.FindElements(By.XPath("//td[@id='dgTrust32_0_lblStatus']")).Count();
            //if (Count1 >= 1)
            string PendingStatus0 = FastDriver.TrustAccounting.Status.Exists().ToString();
            if (PendingStatus0 == "True")
            {
                Reports.TestStep = "Click on Trasmit Now button.";
                FastDriver.TrustAccounting.TransmitNow.FAClick();
                Thread.Sleep(5000);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            }
            #endregion

            #region Create Order.
            Reports.TestStep = "Create File using web service.";
            FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
            fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
            FastDriver.TopFrame.SwitchToTopFrame();
            FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
            string FileNumber1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
            #endregion

            #region Enter the buyer and seller charges for survey.
            Reports.TestStep = "Enter the buyer and seller charges for survey.";
            FastDriver.SurveyDetail.Open();
            FastDriver.SurveyDetail.FindGABCode("248");
            FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, "Test Description", buyerCharge: 15.00, sellerCharge: 200.00);
            FastDriver.BottomFrame.Done();
            #endregion

            #region Add Lease Charge
            Reports.TestStep = "Change the description and charge.";
            FastDriver.LeaseDetail.Open();
            FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
            FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, "Changed Desc", buyerCharge: 10.00, sellerCharge: 11.00);
            FastDriver.BottomFrame.Done();
            #endregion

            Reports.TestStep = "Wait for SDN search to complete.";
            FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

            #region Select the pending Check and check that Void Button is Disable.
            Reports.TestStep = "Select the pending Check and check that Void Button is Disable.";
            FastDriver.ActiveDisbursementSummary.Open();
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Amount", TableAction.Click);
            Support.AreEqual("false", FastDriver.ActiveDisbursementSummary.Void.IsEnabled().ToString().ToLower().Trim(), true);
            #endregion

            #region Perform Print
            FastDriver.ActiveDisbursementSummary.Print.FAClick();
            FastDriver.PrintChecks.WaitForScreenToLoad();
            Keyboard.SendKeys("{l}", ModifierKeys.Control);
            FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
            FastDriver.PrintDlg.ClickPrint();
            FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
            FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
            FastDriver.WebDriver.WaitForDeliveryWindow();
            FastDriver.BottomFrame.Done();
            #endregion

            #region Select the Issued Check and check that Void Button is Enable.
            Reports.TestStep = "Select the Issued Check and check that Void Button is Enable.";
            FastDriver.ActiveDisbursementSummary.Open();
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Amount", TableAction.Click);
            Support.AreEqual("true", FastDriver.ActiveDisbursementSummary.Void.IsEnabled().ToString().ToLower().Trim(), true);
            FastDriver.ActiveDisbursementSummary.Void.FAClick();

            Reports.TestStep = "To Void Disbursement.";
            FastDriver.VoidDlg.WaitForScreenToLoad();
            FastDriver.VoidDlg.SetVoidReason("Reason to void the Disbursement");
            FastDriver.VoidDlg.ClickOk();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            #endregion

            #region Issue the pending report manually.
            Reports.TestStep = "Issue the pending report manually.";
            FastDriver.ActiveDisbursementSummary.Open();
            Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Status", TableAction.GetText).Message.ToString(), true);
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Status", TableAction.Click);
            FastDriver.ActiveDisbursementSummary.Manual.FAClick();
            FastDriver.IssueManualCheck.WaitForScreenToLoad();
            FastDriver.IssueManualCheck.CheckNo.FASetText("1000");
            FastDriver.BottomFrame.Save();
            FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
            FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
            FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
            FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
            FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Release the amount");
            FastDriver.ManualCheckReceiptReason.OK.FAClick();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.BottomFrame.Done();
            #endregion

            #region Verify report status is Issued and Void button is enabled
            Reports.TestStep = "Verify report status is Issued and Void button is enabled";
            FastDriver.ActiveDisbursementSummary.Open();
            Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Status", TableAction.GetText).Message.ToString(), true);
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Status", TableAction.Click);
            Support.AreEqual("true", FastDriver.ActiveDisbursementSummary.Void.IsEnabled().ToString().ToLower().Trim(), true);
            #endregion

            #region FM2282 : Validate transmission date
            Reports.TestStep = "FM2282 : Validate transmission date _ Verify for build extract enabled status";
            FastDriver.TrustAccounting.Open();
            Support.AreEqual("true", FastDriver.TrustAccounting.BuildExtract.IsEnabled().ToString().ToLower().Trim(), true);

            Reports.TestStep = "Click on BuildExtract";
            FastDriver.TrustAccounting.BuildExtract.FAClick();

            Reports.TestStep = "Validate the message You have just submitted the Trust32 Extract Report job for this office to the queue.";
            string Trust32Message = FastDriver.WebDriver.HandleDialogMessage(true, true, 5).ToString();
            Support.AreEqual("You have just submitted the Trust32 Extract Report job for this office to the queue. All jobs will be processed in the order received. It may take a few minutes to initiate.", Trust32Message, true);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

            Reports.TestStep = "Naviagte to Trust32 screen.";
            FastDriver.TrustAccounting.Open();
            int Count2 = FastDriver.WebDriver.FindElements(By.XPath("//td[@id='dgTrust32_0_lblStatus']")).Count();
            string PendingStatus = FastDriver.TrustAccounting.Status.Exists().ToString();
            if (!(PendingStatus == "True"))
            {
                Reports.TestStep = "Wait for the pending reocrd in the table.";
                Thread.Sleep(20000);
                int tries = 0;
                do
                {
                    FastDriver.TrustAccounting.Open();
                    string PendingStatus2 = FastDriver.TrustAccounting.Status.Exists().ToString();
                    if (PendingStatus2 == "True")
                    {
                        break;
                    }
                    else
                    {
                        tries = tries + 1;
                        Playback.Wait(5000);
                    }
                } while (tries <= 5);
            }

            Reports.TestStep = "Click on Trasmit Now button.";
            string TransmitNwBtnStatus = FastDriver.TrustAccounting.TransmitNow.IsEnabled().ToString();
            if (TransmitNwBtnStatus == "False")
            {
                Thread.Sleep(10000);
                int tries = 0;
                do
                {
                    FastDriver.TrustAccounting.Open();
                    string Status2 = FastDriver.TrustAccounting.TransmitNow.IsEnabled().ToString();
                    if (Status2 == "True")
                    {
                        FastDriver.TrustAccounting.TransmitNow.FAClick();
                        FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                        Thread.Sleep(15000);
                        break;
                    }
                    else
                    {
                        tries = tries + 1;
                        Playback.Wait(5000);
                    }
                } while (tries <= 5);
            }
            else
            {
                FastDriver.TrustAccounting.TransmitNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                Thread.Sleep(15000);
            }

            Reports.TestStep = "Verify for build extract enabled status";
            FastDriver.TrustAccounting.Open();
            Support.AreEqual("true", FastDriver.TrustAccounting.BuildExtract.IsEnabled().ToString().ToLower().Trim(), true);

            Reports.TestStep = "Verify void of the record after disbursement is passed in Trust Accounting system.";
            FastDriver.ActiveDisbursementSummary.Open();
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
            Support.AreEqual("false", FastDriver.ActiveDisbursementSummary.Void.IsEnabled().ToString().ToLower().Trim(), true);

            Reports.TestStep = "Click View details for Issued Check.";
            FastDriver.DisbursementHistory.Open();
            FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Issued", "Status", TableAction.Click);
            FastDriver.DisbursementHistory.ViewDetails.FAClick();

            Reports.TestStep = "Verify the Transmission date.";
            FastDriver.EditDisbursement.SwitchToContentFrame();
            if (FastDriver.EditDisbursement.OpenDisbDetails.IsDisplayed().ToString() == "True")
            {
                FastDriver.EditDisbursement.OpenDisbDetails.FAClick();
            }
            // FastDriver.EditDisbursement.OpenDisbDetails.FindElement(By.XPath("//td[@id='cBntExp2']")).FAClick();
            DateTime sDate = DateTime.Now;
            sDate = sDate.ToUniversalTime();
            sDate = sDate.AddHours(-8);
            string ConvertedDate = sDate.ToDateString();
            string ActualDate = FastDriver.EditDisbursement.Trust32ExtractDate.FAGetText().ToString();
            Support.AreEqual(ConvertedDate, FastDriver.EditDisbursement.Trust32ExtractDate.FAGetText().ToString().Trim(), true);
            // FastDriver.BottomFrame.Save();

            Reports.TestStep = "Select the pending Check and check that Void Button is Disabled.";
            FastDriver.ActiveDisbursementSummary.Open();
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "21.00", "Status", TableAction.Click);
            Support.AreEqual("false", FastDriver.ActiveDisbursementSummary.Void.IsEnabled().ToString().ToLower().Trim(), true);
            #endregion

            #region FM2283 :Update tx fields with void
            Reports.TestStep = "FM2283 :Update tx fields with void _ Click on Print button.";
            FastDriver.ActiveDisbursementSummary.Open();
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "215.00", "Amount", TableAction.Click);

            FastDriver.ActiveDisbursementSummary.Print.FAClick();
            FastDriver.PrintChecks.WaitForScreenToLoad();
            Keyboard.SendKeys("{l}", ModifierKeys.Control);
            PerformPrintDeliveryWithPasswordDialog();
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Void the issued amount.";
            FastDriver.ActiveDisbursementSummary.Open();
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "215.00", "Amount", TableAction.Click);
            FastDriver.ActiveDisbursementSummary.Void.FAClick();

            FastDriver.VoidDlg.WaitForScreenToLoad();
            FastDriver.VoidDlg.SetVoidReason("Reason to void the Disbursement");
            FastDriver.VoidDlg.ClickOk();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

            Reports.TestStep = "Verify for Void and Void reason.";
            FastDriver.DisbursementHistory.Open();
            Support.AreEqual("Reason to void the disbursement", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", "Void", "Description", TableAction.GetText).Message.ToString().Trim(), true);


            #endregion

        }
        #endregion

        #region Test FMUC0074_REG0005
        /// <summary>
        /// Create Issued Status of Report
        /// </summary>
        [TestMethod, Obsolete]
        public void FMUC0074_REG0005()
        {
            Reports.TestDescription = "Create Issued Status of Report - covered in FMUC0074_REG0004.";
            Reports.StatusUpdate("The same has been covered in FMUC0074_REG0004.", true);
        }
        #endregion

        #region Test FMUC0074_REG0006
        /// <summary>
        /// FM2282 : Validate transmission date
        /// </summary>
        [TestMethod, Obsolete]
        public void FMUC0074_REG0006()
        {
            Reports.TestDescription = "FM2282 : Validate transmission date - covered in FMUC0074_REG0004.";
            Reports.StatusUpdate("The same has been covered in FMUC0074_REG0004.", true);
        }
        #endregion

        #region Test FMUC0074_REG0007
        /// <summary>
        /// FM2283 :Update tx fields with void
        /// </summary>
        [TestMethod, Obsolete]
        public void FMUC0074_REG0007()
        {
            Reports.TestDescription = "FM2283 :Update tx fields with void - covered in FMUC0074_REG0004.";
            Reports.StatusUpdate("The same has been covered in FMUC0074_REG0004.", true);
        }


        #endregion

        #endregion REG



        #region PrivateMethods

        private void IISLOGIN(string UserName = null, string Password = null)
        {
            var website = AutoConfig.FASTHomeURL;
            if (UserName == null)
            {
                UserName = UserName ?? AutoConfig.UserName;
            }
            if (Password == null)
            {
                Password = Password ?? AutoConfig.UserPassword;
            }
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private void ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            if (UserName == null)
            {
                UserName = UserName ?? AutoConfig.UserName;
            }
            if (Password == null)
            {
                Password = Password ?? AutoConfig.UserPassword;
            }
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);
        }

        private static void PerformPrintDelivery()
        {
            Reports.TestStep = "Perform Print.";
            FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
            FastDriver.PrintDlg.ClickPrint();
            FastDriver.WebDriver.WaitForDeliveryWindow();
        }

        private static void PerformPrintDeliveryWithPasswordDialog()
        {
            Reports.TestStep = "Perform Print.";
            FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
            FastDriver.PrintDlg.ClickPrint();
            FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
            FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
            FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
            FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("Password confirmation comments has to be more than 50 characters.");
            FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

            Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
            FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.WaitForDeliveryWindow();
        }

        private static void PerformPreviewDelivery()
        {
            FastDriver.DepositAdjustment.Method.FASelectItem("Preview");
            FastDriver.DepositAdjustment.Deliver.FAClick();
            FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 200);
            FastDriver.WebDriver.ClosePreviewWindow();
            FastDriver.DepositAdjustment.WaitForScreenToLoad();
        }
        private static void DoNotPerformPrintDelivery()
        {
            Reports.TestStep = "Do not Perform Print.";
            FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
            FastDriver.PrintDlg.ClickCancel();
        }

        private void EnterFeeInTitleEscrowTab()
        {
            Reports.TestStep = "Enter first fee in Title and escrow.";
            FastDriver.FileFees.Open();
            FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
            FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Buyer Charge", TableAction.SetText, "1.99");
            FastDriver.FileFees.TitleandEscrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Seller Charge", TableAction.SetText, "2.99");
        }

        #endregion PrivateMethods
    }
}