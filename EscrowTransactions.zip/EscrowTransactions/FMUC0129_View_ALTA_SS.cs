﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using FASTSelenium.ImageRecognition;

namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0129 : MasterTestClass
    {
        #region US_565455_ALTA_SS_View_Settlement_Statement_in_ALTA_SS_Format
        
        #region Test Case 610420

        [TestMethod]
        public void FMUC0129_REG0001()
        {
            try
            {
                Reports.TestDescription = "To Test US#565455 - To verify the ALTA Settlement Statement charge and credit data content is shown in the View Settlement Statement screen for files where Business Segment is not Commercial and/or Property and Escrow Owning Office Business Address State";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with Business Segmenet = Commercial and Property Address State = TX via Home | Order Entry | Quick File Entry";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "TX";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "DALLAS";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "DALLAS";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to View Settlement Statement screen via Home | Order Entry | Escrow Closing | View Settlement Statement";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForOldScreenToLoad();

                Reports.TestStep = "Verify that the P2504 (TRID F6) (not ALTA) View Settlement Statement screen format is displayed.";
                Reports.StatusUpdate("View Settlement Statement proper screen format is displayed? -> " + FastDriver.ViewSettlementStatement.CashSectionTable.Displayed.ToString(),
                    FastDriver.ViewSettlementStatement.CashSectionTable.Displayed);
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);

                Reports.TestStep = "Navigate to File HomePage via Home | Order Entry | File HomePage";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Change the Business Segment to Residential and click on Save.";
                FastDriver.FileHomepage.BusinessSegment.FASelectItemBySendingKeys("Resi");
                Keyboard.SendKeys("^S");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to View Settlement Statement screen via Home | Order Entry | Escrow Closing | View Settlement Statement";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForOldScreenToLoad();

                Reports.TestStep = "Verify that the P2504 (TRID F6) (not ALTA) View Settlement Statement screen format is displayed.";
                Reports.StatusUpdate("View Settlement Statement proper screen format is displayed? -> " + FastDriver.ViewSettlementStatement.isNotALTA().ToString(),
                    FastDriver.ViewSettlementStatement.isNotALTA());

                Reports.TestStep = "Navigate to Properties/Tax Info screen via Home | Order Entry | Properties/Tax Info";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();

                Reports.TestStep = "Select the current address and press Edit button";
                FastDriver.PropertiesSummary.PropertyName1.FAClick();
                FastDriver.PropertiesSummary.Edit.FAClick();

                Reports.TestStep = "Change the Property Adrress state to CA and click on Save";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("ALAMEDA");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("ALBANY");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.Click();
                Keyboard.SendKeys("CA");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to View Settlement Statement screen via Home | Order Entry | Escrow Closing | View Settlement Statement";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.TestStep = "Verify that the ALTA View Settlement Statement format is displayed.";
                Reports.StatusUpdate("View Settlement Statement proper screen format is displayed? -> " + (!FastDriver.ViewSettlementStatement.isNotALTA()).ToString(),
                    !FastDriver.ViewSettlementStatement.isNotALTA());

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion

        #region Test Case 610422

        [TestMethod]
        public void FMUC0129_REG0002()
        {
            try
            {
                Reports.TestDescription = "To Test US#565455 - To verify that the View Settlement Statement screen shows all columns and buttons cordially.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with Business Segment = Residential and Property Address State = CA";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to View Settlement Statement screen via Home | Order Entry | Escrow Closing | View Settlement Statement";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.TestStep = "Verify that the ALTA View Settlement Statement format is displayed.";
                Reports.StatusUpdate("View Settlement Statement proper screen format is displayed? -> " + (!FastDriver.ViewSettlementStatement.isNotALTA()).ToString(),
                    !FastDriver.ViewSettlementStatement.isNotALTA());

                Reports.TestStep = "Verify that the 'Seller Debit' and 'Seller Credit' columns are located on the left side of the screen respectively";
                FastDriver.ViewSettlementStatement.verifyColumnsLocation(SellerDebit: "Seller Debit", SellerCredit: "Seller Credit");

                Reports.TestStep = "Verify that the 'Borrower/Buyer Debit' and 'Borrower/Buyer Credit' columns are locate on the right side of the screen respectively";
                FastDriver.ViewSettlementStatement.verifyColumnsLocation(BuyerDebit: @"Borrower/ Buyer Debit", BuyerCredit: @"Borrower/ Buyer Credit");

                Reports.TestStep = "Verify that the 'Description' column are locate on the center of the screen";
                FastDriver.ViewSettlementStatement.verifyColumnsLocation(Description: "Description");

                Reports.TestStep = "Verify that the last four rows in the screen are for the 'Subtotals' section.";
                FastDriver.ViewSettlementStatement.verifyRowsForSubtotalsSection();

                Reports.TestStep = "Verify if the 'Print/Deliver' button is available in the View Settlement Statement screen";
                Reports.StatusUpdate("'Print/Deliver' button is available in the View Settlement Statement screen?", FastDriver.ViewSettlementStatement.PrintDeliver.Exists());

                Reports.TestStep = "Verify if the 'Done' button is available in the View Settlement Statement screen";
                FastDriver.BottomFrame.SwitchToBottomFrame(); //we need to explicity switch to bottom frame to be able to verify whether the button Done does not exist
                Reports.StatusUpdate("'Done' button is available in the View Settlement Statement screen?", FastDriver.BottomFrame.btnDone.Exists());

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion

        #endregion

        #region US619427 ALTA SS-View Settlement Statement Screen: Revise Sort Order of Charges in All Sections According to Mapping Spreadsheet

        #region Test Case 631791

        [TestMethod]
        public void FMUC0129_REG0003()
        {
            try
            {
                try
                {
                    Reports.TestDescription = "Tests US#619427 - ALTA SS - View SS Screen - Verify Sort Order for Commission Section";

                    #region data setup
                    var credentials = new Credentials()
                    {
                        UserName = AutoConfig.UserName,
                        Password = AutoConfig.UserPassword
                    };
                    #endregion

                    #region GUI interaction

                    Reports.TestStep = "Log into IIS Server";
                    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                    Reports.TestStep = "Create a basic CD file";
                    FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                    fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                    var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                    FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                    Reports.TestStep = "Verify Expected order for Commission Section";
                    FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                    FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                    FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                    Playback.Wait(250);
                    FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                    FastDriver.RealEstateBrokerAgent.FindGAB("247");
                    FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("50");

                    if (!FastDriver.RealEstateBrokerAgent.RealEstateBrokerCreditsTable.Displayed)
                        FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                    FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerCreditsTable, "REB Credit 1", buyerCredit: 100);

                    if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerTable.Displayed)
                        FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                    FastDriver.WebDriver.WaitForActionToComplete(() => {
                        return FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed();
                    });
                    FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText("POC Seller" + FAKeys.Tab);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    //Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.Click();
                    FastDriver.WebDriver.WaitForActionToComplete(() => {
                        FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.Click();
                        AutoIt.AutoItX.Send("{DEL}");
                        FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("200" + FAKeys.Tab);
                        //Keyboard.SendKeys(FAKeys.TabAway);

                        return FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue().Clean() == "200.00";
                    }, timeout: 120, idleInterval: 5);

                    FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                    FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.CommissionTable, 0, "Commission", isTitleLabel: true);
                    FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.CommissionTable, 1, "Real Estate Commission to Lenders Advantage A Division Of First American Title Ins.");
                    FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.CommissionTable, 2, "Lenders Advantage A Division Of First American Title Ins. Credit to Buyer");
                    FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.CommissionTable, 3, "REB Credit 1 $100.00");
                    FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.CommissionTable, 4, "POC Seller POC $200.00");

                    #endregion GUI interaction

                }
                catch (Exception ex)
                {
                    FailTest(ex.Message);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test Case 634028

        [TestMethod]
        public void FMUC0129_REG0004()
        {
            try
            {
                Reports.TestDescription = "Tests US#619427 - ALTA SS - View SS Screen - Verify Sort Order for Financial Section";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string receiptNo;
                string issueDate;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Log into IIS Server";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic CD file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify Expected order for Financial Section";
                Reports.TestStep = @"Navigate to Terms/Dates/Status screen. Set Settlement Date & Disbursement Date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("50");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.UpdateCharge(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Sale Price of Any Personal Property Included in Sale", buyerCharge: 100);

                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("227");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("150");

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("242");
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateCharge(FastDriver.AssumptionLoanCharges.UnpaidPrincipalLoanChargesTable, "Unpaid Principal Balance", buyerCredit: 200);
                FastDriver.AssumptionLoanCharges.InterestProrationPerDiemAmount.FASetText("10");
                FastDriver.AssumptionLoanCharges.InterestProrationFromDate.FASetText("08-05-2015");
                FastDriver.AssumptionLoanCharges.InterestProrationToDate.FASetText("12-05-2015");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.UpdateCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 300);


                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Amount.FASetText("400");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Earnest Money Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Charge");
                if (!FastDriver.DepositInEscrow.CredittoBuyer.Selected)
                    FastDriver.DepositInEscrow.CredittoBuyer.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                receiptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetAttribute("value");
                issueDate = FastDriver.DepositInEscrow.IssueDte.FAGetAttribute("value");

                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("500");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("200");
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText("150");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Seller's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FASetText("testName");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("150");
                FastDriver.BottomFrame.Save();

                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FinancialTable, 0, "Financial", isTitleLabel: true);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FinancialTable, 1, "Sale Price");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FinancialTable, 2, "Sale Price of Any Personal Property Included in Sale");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FinancialTable, 3, "Loan Amount- Royal American Bank");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FinancialTable, 4, "Existing Loan Assumed or Taken Subject To: Daniel J. Haynes, Esq.");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FinancialTable, 5, "Unpaid Principal Balance");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FinancialTable, 6, "Assumption Loan Interest Proration 08/05/15 to 12/05/15 @$10.000000/day");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FinancialTable, 7, "Statement/Forwarding Fee");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FinancialTable, 8, "Deposit: Receipt No. " + receiptNo + " on " + issueDate.Replace("-", "/") + " by Charge");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FinancialTable, 9, "Total Deposit/Earnest Money");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FinancialTable, 10, "Disbursed as Proceeds ($200.00)");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FinancialTable, 11, "Excess Deposit");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FinancialTable, 12, "Earnest Money Held By: testName");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test Case 634036

        [TestMethod]
        public void FMUC0129_REG0005()
        {
            try
            {
                Reports.TestDescription = "Tests US#619427 - ALTA SS - View SS Screen - Verify Sort Order for Funds Held Section";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Log into IIS Server";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic CD file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify Expected order for Funds Held Section";
                FastDriver.LeftNavigation.Navigate<HoldFunds>("Home>Order Entry>Escrow Charge Processes>Hold Funds").WaitForScreenToLoad();
                FastDriver.HoldFunds.Reason.FASetText("Hold Funds policy");
                FastDriver.HoldFunds.SellerCharge.FASetText("100.00" + FAKeys.Tab);
                FastDriver.HoldFunds.New.FAClick();
                FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText("227");
                FastDriver.HoldFunds.Find.FAClick();
                FastDriver.HoldFunds.UpdateCharge(FastDriver.HoldFunds.HoldFundChargesTable, "Ad Hoc Entry", sellerCharge: 50);

                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FundsHeldTable, 0, "Funds Held", isTitleLabel: true);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FundsHeldTable, 1, "Funds Held: Hold Funds policy");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.FundsHeldTable, 2, "Ad Hoc Entry to Royal American Bank");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test Case 634032

        [TestMethod]
        public void FMUC0129_REG0006()
        {
            try
            {
                Reports.TestDescription = "Tests US#619427 - ALTA SS - View SS Screen - Verify Sort Order for Funds Held Section";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string impoundDesc;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Log into IIS Server";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic CD file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = " Verify Exepcted order for Impounds Section";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("227");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("100");

                //New Loan / Loan Charges tab / Impounds / Aggregate Accounting Adjustment
                impoundDesc = FastDriver.WebDriver.FAFindElement(ByLocator.Id, "tNL_tLC_NLC_icgIC_dcs_0_tdsc").FAGetValue().Clean();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesImpoundsTable, impoundDesc, months: 1);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesImpoundsTable, impoundDesc, monthlyCharges: 10);
                Keyboard.SendKeys(FAKeys.TabAway);

                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.ImpoundsTable, 0, "Impounds", isTitleLabel: true);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.ImpoundsTable, 1, impoundDesc + " 1 mo(s) @$10.00/mo");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.ImpoundsTable, 2, "Aggregate Adjustment");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test Case 634030

        [TestMethod]
        public void FMUC0129_REG0007()
        {
            try
            {
                Reports.TestDescription = "Tests US#619427 - ALTA SS - View SS Screen - Verify Sort Order for Loan Charges Section";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Log into IIS Server";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic CD file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify Expected order for Loan Section";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("227");

                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 50, sellerCharge: 50);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", buyerCharge: 150, sellerCharge: 150);

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("10");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("7-30-2015");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("7-30-2016");
                Keyboard.SendKeys(FAKeys.TabAway);

                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", buyerCharge: 250, sellerCharge: 250);

                if (!FastDriver.NewLoan.LoanCharges_LenderCreditTable.Displayed)
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanCharges_LenderCreditTable, "Non-Specific Lender Credits", buyerCredit: 250);

                if (!FastDriver.NewLoan.LoanChargesPrincipalReductiontable.Displayed)
                    FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 350, sellerCharge: 350);

                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 0, "Loan Charges", isTitleLabel: true);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 1, "Loan Charges to Royal American Bank");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 2, "Prepaid Interest 07/30/15 to 07/30/16 @$10.000000/day");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 3, "Application Fee");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 4, "% of Loan Amount (Points)");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 5, "Appraisal Fee");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 6, "Principal Reduction Payment");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 7, "Non-Specific Lender Credits");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test Case 631790

        [TestMethod]
        public void FMUC0129_REG0008()
        {
            try
            {
                Reports.TestDescription = "Verify Expected Order for all charges under Miscellaneous Section";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Log into IIS Server";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic CD file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify Expected Order for all charges under Miscellaneous Section";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: "Attorney Fee", buyerCharge: 50, sellerCharge: 50);

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.GABcode.FASetText("232");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: "Attorney Fee", buyerCharge: 100, sellerCharge: 100);

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("227", waitForElementDisplayed: false);
                var chargeDesc = FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FAGetValue().Clean();
                if (String.IsNullOrEmpty(chargeDesc))
                {
                    FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: "General Excise Tax", buyerCharge: 150, sellerCharge: 150);
                }
                else
                {
                    FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: chargeDesc, buyerCharge: 150, sellerCharge: 150, editDescription: "General Excise Tax");
                }

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("334");
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, chargeDescription: "Transfer Fee", buyerCharge: 200, sellerCharge: 200);

                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, chargeDescription: "Document Fee", buyerCharge: 250, sellerCharge: 250);

                if (!FastDriver.HomeownerAssociation.HOALienPayOffTable.Displayed)
                    FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.HOALienPayOffTable, chargeDescription: "Lien Payoff", buyerCharge: 300, sellerCharge: 300);

                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("230");
                FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, chargeDescription: "Home Warranty", buyerCharge: 350, sellerCharge: 350);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("10");
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("7-30-2015");
                FastDriver.HomeWarrantyDetail.ToDate.FASetText("7-30-2016");
                Keyboard.SendKeys(FAKeys.TabAway);

                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("240");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, chargeDescription: "Pest Inspection", buyerCharge: 400, loanEstimate: 400);

                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").WaitForScreenToLoad();
                FastDriver.InspectionRepairSeptic.GABcode.FASetText("210");
                FastDriver.InspectionRepairSeptic.Find.FAClick();
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, chargeDescription: "Septic Inspection", buyerCharge: 450, loanEstimate: 450);

                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.GABcode.FASetText("220");
                FastDriver.InspectionRepairOther.Find.FAClick();
                FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: "Other Inspection", buyerCharge: 500, loanEstimate: 500);

                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                Playback.Wait(250);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FindGAB("270");
                FastDriver.InsuranceFire.UpdateCharge(FastDriver.InsuranceFire.InsuranceChargesTable, chargeDescription: "Homeowner's Insurance Premium", buyerCharge: 550, loanEstimate: 550);

                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                Playback.Wait(250);
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                FastDriver.Insuranceflood.FindGAB("280");
                FastDriver.Insuranceflood.UpdateCharge(FastDriver.Insuranceflood.FloodChargesTable, chargeDescription: "Flood Insurance Premium", buyerCharge: 600, loanEstimate: 600);

                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                Playback.Wait(250);
                FastDriver.InsuranceWind.WaitForScreenToLoad();
                FastDriver.InsuranceWind.FindGAB("290");
                FastDriver.InsuranceWind.UpdateCharge(FastDriver.InsuranceWind.WindChargesTable, chargeDescription: "Wind Insurance Premium", buyerCharge: 650, loanEstimate: 650);

                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                Playback.Wait(250);
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                FastDriver.InsuranceEarth.FindGAB("300");
                FastDriver.InsuranceEarth.UpdateCharge(FastDriver.InsuranceEarth.EarthChargesTable, chargeDescription: "Earthquake Insurance Premium", buyerCharge: 700, loanEstimate: 700);

                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 0, "Miscellaneous", isTitleLabel: true);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 1, "Attorney Fee to Lenders Advantage A Division Of First American Title Ins.");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 2, "Attorney Fee to R.J. Financial Services, Inc.");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 3, "General Excise Tax to Royal American Bank");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 4, "Transfer Fee to Harris Bank");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 5, "Document Fee to Harris Bank");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 6, "Lien Payoff to Harris Bank");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 7, "Home Warranty to Maine Mortgage Company");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 8, "Home Warranty to Early Coverage to Maine Mortgage Company");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 9, "Pest Inspection to Daniel H. Brown");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 10, "Septic Inspection to Universal Lending Group, Inc.");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 11, "Other Inspection to Harris Bank Woodstock");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 12, "Homeowner's Insurance Premium to Norwest Mortgage Inc.");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 13, "Flood Insurance Premium to Franklin J. Furlett Law Offices");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 14, "Wind Insurance Premium to Resource Mortgage Corporation");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.MiscTable, 15, "Earthquake Insurance Premium to Old Kent Bank");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test Case 634031

        [TestMethod]
        public void FMUC0129_REG0009()
        {
            try
            {
                Reports.TestDescription = "Tests US#619427 - ALTA SS - View SS Screen - Verify Sort Order for Other Loan Charges Section";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Log into IIS Server";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic CD file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify Expected order for Loan Section";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("20");
                FastDriver.NewLoan.CreditChargePointsPercentageIRSPoints.FASetText("20");
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 50, sellerCharge: 50);
                FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FillPaymentDetailsDialog(useDefault: false, payeeName: "Payee Name");
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.OriginationChargesTable);

                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", buyerCharge: 150, sellerCharge: 150);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FillPaymentDetailsDialog(useDefault: false, payeeName: "Payee Name");
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.LoanChargesInterestCalculationInterestType);

                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("10");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("7-30-2015");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("7-30-2016");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FillPaymentDetailsDialog(useDefault: false, payeeName: "Payee Name");
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.NewLoanChargesTable);

                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", buyerCharge: 250, sellerCharge: 250);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FillPaymentDetailsDialog(useDefault: false, payeeName: "Payee Name");
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails);

                if (!FastDriver.NewLoan.LoanCharges_LenderCreditTable.Displayed)
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanCharges_LenderCreditTable, "Non-Specific Lender Credits", buyerCredit: 350);
                FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FillPaymentDetailsDialog(useDefault: false, payeeName: "Payee Name");
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails);

                if (!FastDriver.NewLoan.LoanChargesPrincipalReductiontable.Displayed)
                    FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 450, sellerCharge: 450);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FillPaymentDetailsDialog(useDefault: false, payeeName: "Payee Name");
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.NewLoanChargesTable);

                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("248");
                FastDriver.NewLoan.MortgageFind.FAClick();

                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.Click();
                    Keyboard.SendKeys("{DEL}");
                    FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FASetText("550" + FAKeys.Tab);
                    //Keyboard.SendKeys(FAKeys.TabAway);

                    return FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FAGetValue().Clean() == "550.00";
                }, timeout: 120, idleInterval: 5);

                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 650, sellerCharge: 650);

                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_LenderCreditTable, "Non-Specific Lender Credits", buyerCredit: 750);
                var futureRecordingDesc = FastDriver.NewLoan.MortgageGFE_7MortgageBrokerDescription.FAGetValue().Clean();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, futureRecordingDesc, buyerCharge: 850);

                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 0, "Loan Charges", isTitleLabel: true);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 1, "Loan Charges to Lenders Advantage A Division Of First American Title Ins.");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 2, "Prepaid Interest 07/30/15 to 07/30/16 @$10.000000/day to Payee Name");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 3, "Application Fee to Payee Name");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 4, "20% of Loan Amount (Points) to Payee Name");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 5, "Appraisal Fee to Payee Name");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 6, "Principal Reduction Payment to Payee Name");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 8, "Mortgage Broker: Midwest Financial Group");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 9, "Broker Fee to Midwest Financial Group", POCDesc: "POC $550.00");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 10, "Appraisal Fee to Midwest Financial Group");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 11, "Non-Specific Lender Credits to Midwest Financial Group");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 0, "Government Recording and Transfer Charges", isTitleLabel: true);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 1, futureRecordingDesc + " to Midwest Financial Group");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test Case 634035

        [TestMethod]
        public void FMUC0129_REG0010()
        {
            try
            {
                Reports.TestDescription = "Tests US#619427 - ALTA SS - View SS Screen - Verify Sort Order for Other Loan Charges Section";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Log into IIS Server";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic CD file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify Exepcted order for PayOffs Section";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("HUDFLINSR1");
                
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.UpdateCharge(FastDriver.PayoffLoanCharges.LoanChargesTable, "Principal Balance", buyerCharge: 50, sellerCharge: 50);
                
                FastDriver.PayoffLoanCharges.UpdateCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 100, sellerCharge: 100);

                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.PayOffTable, 0, "Payoff(s)", isTitleLabel: true);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.PayOffTable, 1, "Lender: Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.PayOffTable, 2, "Principal Balance to Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.PayOffTable, 3, "Statement/Forwarding Fee to Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2");

                #endregion GUI interaction


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test Case 634029

        [TestMethod]
        public void FMUC0129_REG0011()
        {
            try
            {
                Reports.TestDescription = "Tests US#619427 - ALTA SS - View SS Screen - Verify Sort Order for Other Loan Charges Section";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Log into IIS Server";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic CD file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify Exepcted order for Proration Adjustment Section";
                Reports.TestStep = "Navigate to Homeowner Association via Home | Order Entry | Escrow Charge Processes |Homeowner Association";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("100");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-30-2015");
                FastDriver.HomeownerAssociation.ToDate.FASetText("07-30-2016");
                FastDriver.HomeownerAssociation.ProrationBuyerCharge.FASetText("50");
                FastDriver.HomeownerAssociation.ProrationSellerCredit.FASetText("50");
                
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                Playback.Wait(250);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FindGAB("247");
                FastDriver.InsuranceFire.FireAmount.FASetText("100");
                FastDriver.InsuranceFire.FireFromDate.FASetText("07-30-2015");
                FastDriver.InsuranceFire.FireToDate.FASetText("07-30-2016");
                FastDriver.InsuranceFire.FireBuyerCharge1.FASetText("100");
                FastDriver.InsuranceFire.FireSellerCredit1.FASetText("100");
                
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.CityCell.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(250);
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.Amount.FASetText("100");
                FastDriver.ProrationDetail.FromDate.FASetText("07-30-2015");
                FastDriver.ProrationDetail.ToDate.FASetText("07-30-2016");
                FastDriver.ProrationDetail.BuyerCharge.FASetText("200");
                FastDriver.ProrationDetail.SellerCredit.FASetText("200");
                
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad();
                FastDriver.ProrationTax.Rent1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(250);
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.Amount.FASetText("100");
                FastDriver.ProrationDetail.FromDate.FASetText("07-30-2015");
                FastDriver.ProrationDetail.ToDate.FASetText("07-30-2016");
                FastDriver.ProrationDetail.BuyerCharge.FASetText("300");
                FastDriver.ProrationDetail.SellerCredit.FASetText("300");
                
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Miscellaneous").WaitForScreenToLoad();
                FastDriver.ProrationTax.Miscellaneous1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(250);
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.Amount.FASetText("100");
                FastDriver.ProrationDetail.FromDate.FASetText("07-30-2015");
                FastDriver.ProrationDetail.ToDate.FASetText("07-30-2016");
                FastDriver.ProrationDetail.BuyerCharge.FASetText("400");
                FastDriver.ProrationDetail.SellerCredit.FASetText("400");
                
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("247");
                FastDriver.UtilityDetail.ProrationAmount.FASetText("100");
                FastDriver.UtilityDetail.FromDate.FASetText("07-30-2015");
                FastDriver.UtilityDetail.ToDate.FASetText("07-30-2016");
                FastDriver.UtilityDetail.ProrationBuyerCharge.FASetText("500");
                FastDriver.UtilityDetail.ProrationSellerCredit.FASetText("500");
                
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.UpdateCharge(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Lease/Rent", buyerCharge: 600, sellerCharge: 600);
                
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.AddCharge(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Tax Remaining", buyerCharge: 700, sellerCharge: 700);

                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.ProrationTable, 0, "Prorations/Adjustments", isTitleLabel: true);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.ProrationTable, 1, "Association Dues 07/30/15 to 07/30/16 @$100.00/mo");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.ProrationTable, 2, "Fire Insurance 07/30/15 to 07/30/16 @$100.00/yr");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.ProrationTable, 3, "City/Town Taxes 07/30/15 to 07/30/16 @$100.00/yr");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.ProrationTable, 4, "Rents 07/30/15 to 07/30/16 @$100.00/mo");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.ProrationTable, 5, "Assessments 07/30/15 to 07/30/16 @$100.00/yr");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.ProrationTable, 6, "Utilities 07/30/15 to 07/30/16 @$100.00/mo");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.ProrationTable, 7, "Assign Tenant Lease/Rent");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.ProrationTable, 8, "Tax Remaining");

                #endregion GUI interaction


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test Case 634034

        [TestMethod]
        public void FMUC0129_REG0012()
        {
            try
            {
                Reports.TestDescription = "Tests US#619427 - ALTA SS - View SS Screen - Verify Sort Order for Recording Fees Section";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string Rdeed = string.Empty;
                string RdeedPayee = string.Empty;
                string RdeedOTCPayee = string.Empty;
                string Rmortgage = string.Empty;
                string RmortgagePayee = string.Empty;
                string RmortgageOTCPayee = string.Empty;
                string Rrelease = string.Empty;
                string RreleasePayee = string.Empty;
                string RreleaseOTCPayee = string.Empty;
                string Rmiscellaneous = string.Empty;
                string RmiscellaneousPayee = string.Empty;
                string RmiscellaneousOTCPayee = string.Empty;
                string Tdeed = string.Empty;
                string TdeedPayee = string.Empty;
                string TdeedOTCPayee = string.Empty;
                string Tmortgage = string.Empty;
                string TmortgagePayee = string.Empty;
                string TmortgageOTCPayee = string.Empty;
                string Tmiscellaneous = string.Empty;
                string TmiscellaneousPayee = string.Empty;
                string TmiscellaneousOTCPayee = string.Empty;
                string NLrecordingFee = string.Empty;
                string MBrecordingFee = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a FAST file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify Exepcted order for Recording Fees Section";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                Playback.Wait(3000);
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Recording Fee - Deed");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                Rdeed = FastDriver.FileFees.SearchResultsFeeDescription.Text.Clean();
                
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Recording Fee - Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                Rmortgage = FastDriver.FileFees.SearchResultsFeeDescription.Text.Clean();
                
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Recording Fee - Release");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                Rrelease = FastDriver.FileFees.SearchResultsFeeDescription.Text.Clean();
                
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Recording Fee - Miscellaneous");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                Rmiscellaneous = FastDriver.FileFees.SearchResultsFeeDescription.Text.Clean();
                
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Transfer Tax - Deed");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                Tdeed = FastDriver.FileFees.SearchResultsFeeDescription.Text.Clean();
                
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Transfer Tax - Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                Support.AreEqual(FastDriver.FileFees.SearchResultsFeeDescription.Displayed.ToString(), "True");
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                Tmortgage = FastDriver.FileFees.SearchResultsFeeDescription.Text.Clean();
                
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Transfer Tax - Miscellaneous");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                Tmiscellaneous = FastDriver.FileFees.SearchResultsFeeDescription.Text.Clean();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.AddFeesTax);
                RdeedPayee = setBuyerAndSellerChargeRecordingTaxTable(Rdeed, 50.00, true);
                RmortgagePayee = setBuyerAndSellerChargeRecordingTaxTable(Rmortgage, 75.00, true);
                RreleasePayee = setBuyerAndSellerChargeRecordingTaxTable(Rrelease, 100.00, true);
                RmiscellaneousPayee = setBuyerAndSellerChargeRecordingTaxTable(Rmiscellaneous, 125.00, true);
                TdeedPayee = setBuyerAndSellerChargeRecordingTaxTable(Tdeed, 150.00, true);
                TmortgagePayee = setBuyerAndSellerChargeRecordingTaxTable(Tmortgage, 175.00, true);
                TmiscellaneousPayee = setBuyerAndSellerChargeRecordingTaxTable(Tmiscellaneous, 200.00, true);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                if (!FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable.Displayed)
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                NLrecordingFee = FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderDescription.FAGetValue().Clean();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, NLrecordingFee, buyerCharge: 225);
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("boa");
                FastDriver.NewLoan.MortgageFind.FAClick();
                if (!FastDriver.NewLoan.Mortgage_FutureRecFeesTable.Displayed)
                    FastDriver.NewLoan.Mortgage_ExpandFutureRecFees.FAClick();
                MBrecordingFee = FastDriver.NewLoan.MortgageGFE_7MortgageBrokerDescription.FAGetValue().Clean();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, MBrecordingFee, buyerCharge: 250);
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("242");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.OutsideTitleCompanyDetail.AddRecordingFees.FAClick();
                FastDriver.AddOTCFees.WaitForScreenToLoad();
                FastDriver.AddOTCFees.FeeTable.PerformTableAction("Description", Rdeed, "Sel", TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction("Description", Rmortgage, "Sel", TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction("Description", Rrelease, "Sel", TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction("Description", Rmiscellaneous, "Sel", TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction("Description", Tdeed, "Sel", TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction("Description", Tmortgage, "Sel", TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction("Description", Tmiscellaneous, "Sel", TableAction.On);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.OutsideTitleCompanyDetail.WaitForScreenToLoad();
                
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.RecFeesAndTTaxTable, Rdeed, buyerCharge: 55, sellerCharge: 55);
                RdeedOTCPayee = getOTCPayeeNameRecordingFees(viewSS: true);
                
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.RecFeesAndTTaxTable, Rmortgage, buyerCharge: 80, sellerCharge: 80);
                RmortgageOTCPayee = getOTCPayeeNameRecordingFees(viewSS: true);
                
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.RecFeesAndTTaxTable, Rrelease, buyerCharge: 105, sellerCharge: 105);
                RreleaseOTCPayee = getOTCPayeeNameRecordingFees(viewSS: true);
                
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.RecFeesAndTTaxTable, Rmiscellaneous, buyerCharge: 130, sellerCharge: 130);
                RmiscellaneousOTCPayee = getOTCPayeeNameRecordingFees(viewSS: true);
                
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.RecFeesAndTTaxTable, Tdeed, buyerCharge: 155, sellerCharge: 155);
                TdeedOTCPayee = getOTCPayeeNameRecordingFees(viewSS: true);
                
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.RecFeesAndTTaxTable, Tmortgage, buyerCharge: 180, sellerCharge: 180);
                TmortgageOTCPayee = getOTCPayeeNameRecordingFees(viewSS: true);
                
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.RecFeesAndTTaxTable, Tmiscellaneous, buyerCharge: 205, sellerCharge: 205);
                TmiscellaneousOTCPayee = getOTCPayeeNameRecordingFees(viewSS: true);

                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 0, "Government Recording and Transfer Charges", isTitleLabel: true);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 1, Rdeed + RdeedPayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 2, Rmortgage + RmortgagePayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 3, Rrelease + RreleasePayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 4, Rmiscellaneous + RmiscellaneousPayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 5, Tdeed + TdeedPayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 6, Tmortgage + TmortgagePayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 7, Tmiscellaneous + TmiscellaneousPayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 8, NLrecordingFee + " to Lenders Advantage A Division Of First American Title Ins.");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 9, MBrecordingFee + " to Bank of America");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 10, Rrelease + RreleaseOTCPayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 11, Rmiscellaneous + RmiscellaneousOTCPayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 12, Rdeed + RdeedOTCPayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 13, Rmortgage + RmortgageOTCPayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 14, Tdeed + TdeedOTCPayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 15, Tmortgage + TmortgageOTCPayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.RecordingTransferChargesTable, 16, Tmiscellaneous + TmiscellaneousOTCPayee);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test Case 634033

        [TestMethod]
        public void FMUC0129_REG0013()
        {
            try
            {
                Reports.TestDescription = "Tests US#619427 - ALTA SS - View SS Screen - Verify Sort Order for Title and Escrow Charges Section";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string TownersPolicy = string.Empty;
                string TownersPayee = string.Empty;
                string LossRecovery = string.Empty;
                string RdeedOTCPayee = string.Empty;
                string TlendersPolicy = string.Empty;
                string TlendersPayee = string.Empty;
                string RmortgageOTCPayee = string.Empty;
                string TendorsementFee = string.Empty;
                string TendorsementPayee = string.Empty;
                string RreleaseOTCPayee = string.Empty;
                string Tmisc = string.Empty;
                string TmiscPayee = string.Empty;
                string RmiscellaneousOTCPayee = string.Empty;
                string EscrowFee = string.Empty;
                string EcrowFeePayee = string.Empty;
                string TdeedOTCPayee = string.Empty;
                string OtherFee = string.Empty;
                string OtherFeePayee = string.Empty;
                string TmortgageOTCPayee = string.Empty;
                string ServiceFee = string.Empty;
                string ServiceFeePayee = string.Empty;
                string TmiscellaneousOTCPayee = string.Empty;
                string NLrecordingFee = string.Empty;
                string MBrecordingFee = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a FAST file";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Verify Exepcted order for Recording Fees Section";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                Playback.Wait(3000);
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                TownersPolicy = FastDriver.FileFees.SearchResultsFeeDescription.Text.Clean();
                
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                TlendersPolicy = FastDriver.FileFees.SearchResultsFeeDescription.Text.Clean();
                
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Endorsement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                TendorsementFee = FastDriver.FileFees.SearchResultsFeeDescription.Text.Clean();
                
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Miscellaneous");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                Tmisc = FastDriver.FileFees.SearchResultsFeeDescription.Text.Clean();

                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FindNow.FAClick();
                Support.AreEqual(FastDriver.FileFees.SearchResultsFeeDescription.Displayed.ToString(), "True");
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                EscrowFee = FastDriver.FileFees.SearchResultsFeeDescription.Text.Clean();
                
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Other Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 1, TableAction.On);
                OtherFee = FastDriver.FileFees.SearchResultsFeeDescription.Text.Clean();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                
                FastDriver.FileFees.WaitForScreenToLoad();
                TownersPayee = setBuyerAndSellerChargeRecordingTaxTable(TownersPolicy, 50.00, true, isTitleAndEscrow: true);
                TlendersPayee = setBuyerAndSellerChargeRecordingTaxTable(TlendersPolicy, 75.00, true, isTitleAndEscrow: true);
                TendorsementPayee = setBuyerAndSellerChargeRecordingTaxTable(TendorsementFee, 100.00, true, isTitleAndEscrow: true);
                TmiscPayee = setBuyerAndSellerChargeRecordingTaxTable(Tmisc, 125.00, true, isTitleAndEscrow: true);
                EcrowFeePayee = setBuyerAndSellerChargeRecordingTaxTable(EscrowFee, 150.00, true, isTitleAndEscrow: true);
                OtherFeePayee = setBuyerAndSellerChargeRecordingTaxTable(OtherFee, 175.00, true, isTitleAndEscrow: true);

                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("247");
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: "Outside Escrow Charge", buyerCharge: 250, loanEstimate: 250);
                
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("247");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, chargeDescription: "Title - Title Examination", buyerCharge: 275, loanEstimate: 275);
                
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable, chargeDescription: "Title - Lender Policy and Endorsements", buyerCharge: 295, loanEstimate: 295);
                
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable, chargeDescription: "Title - Owner Policy (Optional)", buyerCharge: 300, loanEstimate: 300);

                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.TitleEscrowTable, 0, "Title Charges & Escrow / Settlement Charges", isTitleLabel: true);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.TitleEscrowTable, 1, TownersPolicy + TownersPayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.TitleEscrowTable, 2, TlendersPolicy + TlendersPayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.TitleEscrowTable, 3, TendorsementFee.Replace("to", "") + " $200.00 Sales Tax: $19.20 " + TendorsementPayee/*, POCDesc: "POC-L $200.00"*/);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.TitleEscrowTable, 4, Tmisc + TmiscPayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.TitleEscrowTable, 5, EscrowFee.Replace("to", "") + " $300.00 Sales Tax: $28.80 " + EcrowFeePayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.TitleEscrowTable, 6, OtherFee + OtherFeePayee);
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.TitleEscrowTable, 7, "Outside Escrow Charge to Lenders Advantage A Division Of First American Title Ins.");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.TitleEscrowTable, 8, "Title - Title Examination to Lenders Advantage A Division Of First American Title Ins.");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.TitleEscrowTable, 9, "Title - Lender Policy and Endorsements to Lenders Advantage A Division Of First American Title Ins.");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.TitleEscrowTable, 10, "Title - Owner Policy (Optional) to Lenders Advantage A Division Of First American Title Ins.");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region US#748638 - INC2525651 - 10.1 UAT, New Loan Charge(s) w/ 3rd payee not rendering to View S/S
        [TestMethod]
        public void FMUC0129_REG0014()
        {
            try
            {
                Reports.TestDescription = "To test US# 748638 - Verify New Loan Charge renders with a third party payee in View S/S";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion
                #region UI

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Pull GAB code";
                FastDriver.NewLoan.FindGABCode("242");

                Reports.TestStep = "Click on Loan Charges tab";
                FastDriver.NewLoan.LoanChargesTab.FAClick();

                Reports.TestStep = "In the Origination Charges section, enter amounts in a couple charge fields";
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", buyerCharge: 100);
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Origination Fee", buyerCharge: 200);

                Reports.TestStep = "In one of the New Loan charge fields enter an amount";
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", buyerCharge: 500);

                Reports.TestStep = "Open Payment Details for Appraisal, uncheck the Use Default Checkbox and enter Third Party Payee in the Payee Name field";
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Third Party Payee");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to View Settlement Statement";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.TestStep = "Verify Third Party Payee charge is displayed";
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 4, "Appraisal Fee to Third Party Payee");

                Reports.TestStep = "Navigate to New Loan- Loan Charges screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();

                Reports.TestStep = "Add another charge in the New Loan charges section with a default payee";
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Credit Report", buyerCharge: 50);

                Reports.TestStep = "Navigate to View Settlement Statement";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.TestStep = "Verify the new charge is displayed";
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 4, "Credit Report");
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 5, "Appraisal Fee to Third Party Payee");

                Reports.TestStep = "Navigate to New Loan- Loan Charges screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();

                Reports.TestStep = "Add a third party payee to the last charge added";
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Credit Report", buyerCharge: 50);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Third Party Payee");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to View Settlement Statement";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.TestStep = "Verify the new charge with Third Party Payee is displayed";
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 5, "Credit Report to Third Party Payee");

                Reports.TestStep = "Verify the old charge with Third Party Payee charge is displayed";
                FastDriver.ViewSettlementStatement.VerifyChargeDesc(FastDriver.ViewSettlementStatement.LoanChargesTable, 4, "Appraisal Fee to Third Party Payee");

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region US_769937_ALTA SS - View SS - Print/Deliver button

        #region FMUC0129_REG0015

        [TestMethod]
        public void FMUC0129_REG0015()
        {
            try
            {
                Reports.TestDescription = "To Test US769937_TC800454 - When User click on ALTA SS - View SS - (new )Print/Deliver button systerm shall navigate to the Print Escrow Settlement Statement screen for CD files.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var value = string.Empty;
                #endregion

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with Business Segment = Residential and Property Address State = CA";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to View Settlement Statement screen via Home | Order Entry | Escrow Closing | View Settlement Statement";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>(@"Home>Order Entry>Escrow Closing>View Settlement Stmt.").WaitForScreenToLoad();

                Reports.TestStep = "Verify that the ALTA View Settlement Statement format is displayed.";
                Reports.StatusUpdate("View Settlement Statement proper screen format is displayed? -> " + (!FastDriver.ViewSettlementStatement.isNotALTA()).ToString(), !FastDriver.ViewSettlementStatement.isNotALTA());

                Reports.TestStep = "Verify if the 'Print/Deliver' button is available in the View Settlement Statement screen";
                Reports.StatusUpdate("'Print/Deliver' button is available in the View Settlement Statement screen?", FastDriver.ViewSettlementStatement.PrintDeliver.IsEnabled());

                Reports.TestStep = "When User click on ALTA SS - View SS - (new )Print/Deliver button systerm shall navigate to the Print Escrow Settlement Statement screen";
                FastDriver.ViewSettlementStatement.PrintDeliver.FAClick();
                FastDriver.PrintEscrowSetlleStmt.WaitForScreenToLoad();

                Reports.TestStep = "Verify if click the 'Print/Deliver' button it will nav to Settlement Statement screen";
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.Deliver.IsEnabled(), "Deliver Buttom enabled");

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        #endregion US_769937_ALTA SS - View SS - Print/Deliver button

        #endregion

        #region UAT ISSUES
        [TestMethod]
        [Description("Bug 865225 - Sanity_EVAL03_ALTS SS delivery - Signature image is not rendering for delivery with Combined Client Format")]
        [DeploymentItem(@"ImageRecognition\Media\PDF\")]
        public void UAT_REG0001()
        {
            /*
             * Pre-conditions:
             * On the admin side of FAST enter a Signature File, under Employee Setup for the user logged (user's examples: TestSignature1.gif,TestingA.Longername II.gif,TestingSig3.gif) 
             * and with employee type as Escrow officer 
             */

            #region Debugging
            //IRConfig.canSaveScreenSamples = true;
            //IRConfig.saveAllSamples = true;
            #endregion

            try
            {
                #region Environment Settings
                TurnOffAcrobatReaderAccessibilityWizard();
                AcrobatReaberStartMaximized();
                SetAdobeRenderingNoSmoothing();
                SetAdobeDefaultZoom100();
                #endregion

                Reports.TestDescription = "Bug 865225 - Sanity_EVAL03_ALTS SS delivery - Signature image is not rendering for delivery with Combined Client Format";

                #region Set up test the user signature
                Reports.TestStep = "Set up test the user signature";
                FASTHelpers.FAST_Login_ADM();
                FastDriver.EmployeeSearch.Open();
                FastDriver.EmployeeSearch.SearchEmployee(new FASTSelenium.DataObjects.ADM.EmployeeSearchParameters()
                {
                    LoginName = "FASTTS\\FASTQA07",
                    Region = "QA Automation Region - DO NOT TOUCH",
                    Office = "QA Automation Office - DO NOT TOUCH PR: STEST Off: 7878",
                });
                FastDriver.EmployeeSearch.EditEmployee("FASTTS\\FASTQA07");
                FastDriver.EmployeeSetup.WaitForScreenToLoad();
                if (FastDriver.EmployeeSetup.SignatureFile.FAGetText() != "eagle.gif")
                    FastDriver.EmployeeSetup.SignatureFile.FASetText("eagle.gif");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Login to IIS Server
                Reports.TestStep = "Login to IIS Server";
                FASTHelpers.FAST_Login_IIS();
                #endregion

                #region Create a basic ALTA file
                Reports.TestStep = "Create a basic ALTA file";
                FASTHelpers.FAST_WCF_File_IIS();
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.EscrowOwningOfficeOfficer.FASelectItem("QA07, FAST");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Settlement Statement screen
                Reports.TestStep = "Navigate to Settlement Statement screen";
                FastDriver.PrintEscrowSetlleStmt.Open();
                Support.AreEqual("true", FastDriver.PrintEscrowSetlleStmt.Combined.FAGetAttribute("status").ToLowerInvariant(), "Combined client format should be checked");
                Support.AreEqual("true", FastDriver.PrintEscrowSetlleStmt.PrintBlankSignatureLineWithEscrowOfficerName.FAGetAttribute("status").ToLowerInvariant(), "Print Escrow Officer's Signature Image should be checked");
                Support.AreEqual("FAST QA07", FastDriver.PrintEscrowSetlleStmt.PrintBlankSignatureLineText.FAGetValue(), "Escrow Officer Name");
                FastDriver.PrintEscrowSetlleStmt.PrintAltaEscrowOfficerSignature.FASetCheckbox(true);
                #endregion

                #region Preview Settlement Statement
                Reports.TestStep = "Preview Settlement Statement";
                FastDriver.Delivery.Perform(FADeliveryMethod.Preview);
                FastDriver.PDFDocument.WaitDocumentToLoad(15);
                Support.IsTrue(FastDriver.PDFDocument.IREagleSignature.Visible(), "Eagle Signature is present in PDF Document");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region HelpMethods

        private void FillPaymentDetailsDialog(string BuyerPaidByOtherMethod = null, double? BuyerPaidAtClosing = null, double? BuyerPaidBeforeClosing = null, double? BuyerPaidByOther = null, double? SellerCharge = null, double? PaidbySellerAtClosing = null, double? PaidbySellerBeforeClosing = null, double? PaidbySellerOthers = null, double? sellerCredit = null, string SellerPaidbyOthersPaymentMethod = "", string description = "", bool? useDefault = null, string payeeName = "", string SellerCreditPaymentMethod = "")
        {

            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

            if (BuyerPaidByOtherMethod != null && BuyerPaidByOtherMethod != "")
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem(BuyerPaidByOtherMethod);

            if (BuyerPaidAtClosing.HasValue)
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(BuyerPaidAtClosing.ToString());

            if (BuyerPaidBeforeClosing.HasValue)
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText(BuyerPaidBeforeClosing.ToString());

            if (BuyerPaidByOther.HasValue)
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText(BuyerPaidByOther.ToString());

            if (SellerCharge.HasValue)
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(SellerCharge.ToString());

            if (PaidbySellerAtClosing.HasValue)
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(PaidbySellerAtClosing.ToString());

            if (PaidbySellerBeforeClosing.HasValue)
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText(PaidbySellerBeforeClosing.ToString());

            if (PaidbySellerOthers.HasValue)
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(PaidbySellerOthers.ToString());

            if (sellerCredit.HasValue)
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText(sellerCredit.ToString());

            if (!SellerPaidbyOthersPaymentMethod.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem(SellerPaidbyOthersPaymentMethod);

            if (!SellerCreditPaymentMethod.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem(SellerCreditPaymentMethod);

            if (!description.Equals(""))
                FastDriver.PaymentDetailsDlg.Description.FASetText(description);

            if (useDefault.HasValue)
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(useDefault);

            if (payeeName.Equals("EMPTY"))
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("");

            else if (!payeeName.Equals(""))
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText(payeeName);

            FastDriver.DialogBottomFrame.ClickDone();
            if (!(FastDriver.WebDriver.HandleDialogMessage().Length > 1))
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
        }
        
        private string setBuyerAndSellerChargeRecordingTaxTable(string desc, double amt, bool viewSS = false, bool isTitleAndEscrow = false)
        {
            string payeeName = string.Empty;
            string descID = "";
            string BuyerChargeID = "";
            string SellerChargeID = "";
            string FeesDetailID = "";

            for (int i = 0; i < 7; i++)
            {
                if (!isTitleAndEscrow)
                {
                    descID = "tFF_rF1_gR_";
                    BuyerChargeID = "tFF_rF1_gR_";
                    SellerChargeID = "tFF_rF1_gR_";
                    FeesDetailID = "tFF_rF1_gR_";
                }
                else
                {
                    descID = "tFF_tF1_gT_";
                    BuyerChargeID = "tFF_tF1_gT_";
                    SellerChargeID = "tFF_tF1_gT_";
                    FeesDetailID = "tFF_tF1_gT_";
                }
                descID = descID + i + "_txFDes";
                BuyerChargeID = BuyerChargeID + i + "_tbc";
                SellerChargeID = SellerChargeID + i + "_tsc";
                FeesDetailID = FeesDetailID + i + "_btnFeeDetails";
                var element = FastDriver.WebDriver.FAFindElement(ByLocator.Id, descID);
                string value = element.FAGetValue().Clean();
                if (value == desc)
                {
                    FastDriver.WebDriver.FAFindElement(ByLocator.Id, BuyerChargeID).FASetText(amt.ToString());
                    FastDriver.WebDriver.FAFindElement(ByLocator.Id, SellerChargeID).FASetText(amt.ToString());
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.WebDriver.FAFindElement(ByLocator.Id, FeesDetailID).FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    if (FastDriver.PaymentDetailsDlg.PayeeNameCD.Enabled)
                    {
                        FastDriver.PaymentDetailsDlg.PayeeNameCD.FASetText("PayeeName");
                        payeeName = "PayeeName";
                    }
                    else
                    {
                        payeeName = FastDriver.PaymentDetailsDlg.PayeeNameCD.FAGetValue().Clean();
                    }
                    FastDriver.DialogBottomFrame.ClickDone();
                    Playback.Wait(250);
                    FastDriver.FileFees.WaitForScreenToLoad();
                    break;
                }
            }

            return viewSS && (payeeName != "") ? " to " + payeeName : !viewSS && (payeeName != "") ? "  to " + payeeName : "";
        }

        private string getOTCPayeeNameRecordingFees(bool viewSS = false)
        {
            string OTCPayee = string.Empty;

            FastDriver.OutsideTitleCompanyDetail.WaitForScreenToLoad();
            FastDriver.OutsideTitleCompanyDetail.RFeesTTaxesPaymentDetails.FAClick();
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            if (FastDriver.PaymentDetailsDlg.PayeeNameCD.Enabled)
            {
                FastDriver.PaymentDetailsDlg.PayeeNameCD.FASetText("OTCPayee");
                OTCPayee = "OTCPayee";
            }
            else
            {
                OTCPayee = FastDriver.PaymentDetailsDlg.PayeeNameCD.FAGetValue().Clean();
            }
            FastDriver.DialogBottomFrame.ClickDone();
            Playback.Wait(250);
            FastDriver.OutsideTitleCompanyDetail.WaitForScreenToLoad();

            return viewSS && (OTCPayee != "") ? " to " + OTCPayee : !viewSS && (OTCPayee != "") ? "  to " + OTCPayee : "";
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup()
        {
            Support.CloseAllProcessStartingWith("AcroRd32");
            Support.CloseAllProcessStartingWith("Acrobat");
            Support.CloseAllProcessStartingWith("IEDriverServer");
        }
    }
}