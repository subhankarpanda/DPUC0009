﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using System.Windows.Input;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using FASTSelenium.ImageRecognition;


namespace EscrowTransactions
{
    [CodedUITest]
    public class FMUC0137_ViewAndDeliverTDI_For_Texas : FASTHelpers
    {
	    

        #region US 632029: Texas Dept of Insurance (TDI) - Deliver T-64 Form

        #region TC_826210

        [TestMethod]
        public void FMUC0137_REG0001()
        {
            try
            {
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to New Loan sccreen and create a new instance. ";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("197");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Print Delivery method.";

                #region Print

                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Print");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();

                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SendPrint("*TEXT_FILE_PRINTER");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HUD1PrintOptions.SwitchToContentFrame();

                #endregion

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 700);
                FastDriver.WebDriver.ClosePreviewWindow();

                //FastDriver.WebDriver.HandleAdobeReaderDialog();
                #endregion

                #region Email
                Reports.TestStep = "Perform Email Delivery method.";
                FastDriver.TexasDisclosure.WaitForScreenToLoad();
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Email");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                Reports.TestStep = "Select to and click on email delivery";
                FastDriver.EmailDlg.WaitForScreenToLoad();
                FastDriver.EmailDlg.ToText.FASetText(AutoConfig.DeliverEmailTo, clearFirst: false); // Starting from v10.03.0003 build, it doesn't work if not passing clearFirst: false
                string emailSubject = Environment.MachineName + " -" + AutoConfig.FASTHomeURL;
                FastDriver.EmailDlg.Subject.FASetText(emailSubject);
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 700);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Imagedoc
                Reports.TestStep = "Perform Imagedoc delivery";
                FastDriver.TexasDisclosure.WaitForScreenToLoad();
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Imagedoc");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                //Support.AreEqual("true", FastDriver.ImageDocDlg.AddQCClosingReport.Selected.ToString().ToLower());
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);
                FastDriver.TexasDisclosure.SwitchToContentFrame();
                #endregion

                #region Fax
                Reports.TestStep = "Perform Fax Delivery method.";
                //FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>(@"Home>Order Entry>Escrow Closing>HUD-1 Statement");
                FastDriver.TexasDisclosure.WaitForScreenToLoad();
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Fax");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Fax", true, 20);
                FastDriver.FaxDlg.WaitForScreenToLoad();
                FastDriver.FaxDlg.Insert.FAClick();
                FastDriver.FaxDlg.Name.FASetText(@"QA");
                FastDriver.FaxDlg.Attn.FASetText(@"1");
                FastDriver.FaxDlg.FAXNumber.FASetText(AutoConfig.DeliverFaxTo);
                FastDriver.FaxDlg.FAX.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Fax", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.TexasDisclosure.SwitchToContentFrame();
                //FastDriver.HUD1PrintOptions.SwitchToContentFrame();
                //FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_828302

        [TestMethod]
        public void FMUC0137_REG0002()
        {
            try
            {
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to New Loan sccreen and create a new instance. ";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("197");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Print Delivery method.";

                #region Print

                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Print");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();

                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }
                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SendPrint("*TEXT_FILE_PRINTER");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HUD1PrintOptions.SwitchToContentFrame();

                #endregion

                #region Email
                Reports.TestStep = "Perform Email Delivery method.";
                FastDriver.TexasDisclosure.WaitForScreenToLoad();
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Email");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                Reports.TestStep = "Select to and click on email delivery";
                FastDriver.EmailDlg.WaitForScreenToLoad();
                FastDriver.EmailDlg.ToText.FASetText(AutoConfig.DeliverEmailTo, clearFirst: false); // Starting from v10.03.0003 build, it doesn't work if not passing clearFirst: false
                string emailSubject = Environment.MachineName + " -" + AutoConfig.FASTHomeURL;
                FastDriver.EmailDlg.Subject.FASetText(emailSubject);
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 700);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Imagedoc
                Reports.TestStep = "Perform Imagedoc delivery";
                FastDriver.TexasDisclosure.WaitForScreenToLoad();
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Imagedoc");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                //Support.AreEqual("true", FastDriver.ImageDocDlg.AddQCClosingReport.Selected.ToString().ToLower());
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);
                FastDriver.TexasDisclosure.SwitchToContentFrame();
                #endregion

                #region Fax
                Reports.TestStep = "Perform Fax Delivery method.";
                //FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>(@"Home>Order Entry>Escrow Closing>HUD-1 Statement");
                FastDriver.TexasDisclosure.WaitForScreenToLoad();
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Fax");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Fax", true, 20);
                FastDriver.FaxDlg.WaitForScreenToLoad();
                FastDriver.FaxDlg.Insert.FAClick();
                FastDriver.FaxDlg.Name.FASetText(@"QA");
                FastDriver.FaxDlg.Attn.FASetText(@"1");
                FastDriver.FaxDlg.FAXNumber.FASetText(AutoConfig.DeliverFaxTo);
                FastDriver.FaxDlg.FAX.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Fax", 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.TexasDisclosure.SwitchToContentFrame();
                //FastDriver.HUD1PrintOptions.SwitchToContentFrame();
                //FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Go to Document Repository screen";
                FastDriver.DocumentRepository.Open();

                Reports.TestStep = "Go to Document  and verify that there's an Imagedoc for each Delivery performed except for Preview method.";
                //FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(2, 3, TableAction.Click, "", true);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Texas Dept of Insurance (TDI)", 3, TableAction.Click);
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Texas Dept of Insurance (TDI)", 4, TableAction.Click);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Texas Dept of Insurance (TDI)", 5, TableAction.Click);
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "Texas Dept of Insurance (TDI)", 6, TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region US 510557: Delivery - Texas Dept of Insurance (TDI) - Section 1 Display Transaction Information on the TDI form delivery - Property Address

        #region TC_823004
        [TestMethod]
        public void FMUC0137_REG0003()
        {

            try
            {
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                //FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 700);
                //FastDriver.WebDriver.ClosePreviewWindow();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NAN") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Support.AreEqual(true, pdfText.Contains("Property Address"), "Verify Property Address filed on TDI Form.");
                Support.AreEqual(true, pdfText.Contains("123 Testing, tdi, tdi"), "Verify Property Address line 1 on TDI Form.");
                Support.AreEqual(true, pdfText.Contains("Houston, TX 77777"), "Verify Property Address line 2 on TDI Form.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region TC_835735

        [TestMethod]
        public void FMUC0137_REG0004()
        {
            try
            {
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("", continueOnFailure: true);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("", continueOnFailure: true);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("", continueOnFailure: true);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("", continueOnFailure: true);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText(" ");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("College Station");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText(" ");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("51000");

                Reports.TestStep = "Click on Legal Description tab.";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab();

                Reports.TestStep = "Enter data in Lot field";
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText("Lot1");

                Reports.TestStep = "Enter data in Unit field";
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("Unit1");

                Reports.TestStep = "Enter data in Tract field ";
                FastDriver.PropertyTaxInfoLegalDesciption.Tract.FASetText("Tract1");

                Reports.TestStep = "Click on Done Button.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                //FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 700);
                //FastDriver.WebDriver.ClosePreviewWindow();           

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NAN") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Support.AreEqual(true, pdfText.Contains("Property Address"), "Verify Property Address filed on TDI Form.");
                Support.AreEqual(true, pdfText.Contains("Lot: Lot1 Unit: Unit1 Tract: Tract1"), "Verify Property Address line 1 on TDI Form.");
                Support.AreEqual(true, pdfText.Contains("College Station, TX 51000"), "Verify Property Address line 2 on TDI Form.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }


        }

        #endregion

        #endregion

        #region US 822051: Screen - Texas Dept of Insurance (TDI) - Section 1 Display Transaction Information on the TDI form delivery - Property Address

        #region TC_828319
        [TestMethod]
        public void FMUC0137_REG0005()
        {
            try
            {
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Verify in Transaction Information section Property Address field exist.";
                Support.Equals(true, FastDriver.TexasDisclosure.PropertyAddress.Exists());

                Reports.TestStep = "Verify in Transaction Information section Borrower(s) field exist.";
                Support.Equals(true, FastDriver.TexasDisclosure.Borrowers.Exists());

                Reports.TestStep = "Verify in Transaction Information section Borrower(s) Address field exist.";
                Support.Equals(true, FastDriver.TexasDisclosure.BorrowerAddresses.Exists());

                Reports.TestStep = "Verify in Transaction Information section Seller(s) field exist.";
                Support.Equals(true, FastDriver.TexasDisclosure.Sellers.Exists());

                Reports.TestStep = "Verify in Transaction Information section Seller(s) Address field exist.";
                Support.Equals(true, FastDriver.TexasDisclosure.SellersAddresses.Exists());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion       

        #region TC_835768

        [TestMethod]
        public void FMUC0137_REG0006()
        {
            try
            {
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("", continueOnFailure: true);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("", continueOnFailure: true);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("", continueOnFailure: true);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("", continueOnFailure: true);
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText(" ");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("College Station");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText(" ");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("51000");

                Reports.TestStep = "Click on Legal Description tab.";
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab();

                Reports.TestStep = "Enter data in Lot field";
                FastDriver.PropertyTaxInfoLegalDesciption.Lot.FASetText("Lot1");

                Reports.TestStep = "Enter data in Unit field";
                FastDriver.PropertyTaxInfoLegalDesciption.Unit.FASetText("Unit1");

                Reports.TestStep = "Enter data in Tract field ";
                FastDriver.PropertyTaxInfoLegalDesciption.Tract.FASetText("Tract1");

                Reports.TestStep = "Click on Done Button.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "In Transaction Information section Verify the property address.";
                //var strPropertyAddress = ;
                Support.AreEqual("Lot: Lot1 Unit: Unit1 Tract: Tract1", FastDriver.TexasDisclosure.PropertyAddressValue.FAGetText().Clean(), "Verify if addresses are equal.");

                Reports.TestStep = " Verify City Text box of Property Address";
                var strCity = FastDriver.TexasDisclosure.StateZipValue.Text;
                Support.Equals(true, strCity.Contains("College Station"));

                Reports.TestStep = " Verify State Text box of Property Address";
                Support.Equals(true, strCity.Contains("TX"));

                Reports.TestStep = " Verify Zip Text box of Property Address";
                Support.Equals(true, strCity.Contains("51000"));
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region US 510589: Delivery - Texas Dept of Insurance(TDI) - Section 2 Lender information under Lender and Settlement Agent section in TDI Form

        #region TC_829256

        [TestMethod]
        public void FMUC0137_REG0007()
        {
            try
            {
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to New Loan sccreen and create a new instance. ";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("197");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                //FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 700);
                //FastDriver.WebDriver.ClosePreviewWindow();
                #endregion

                Reports.TestStep = "Save PDF file";
                string tempPdfFile = @"C:\Temp\Test_Docs" + Support.RandomString("NAN") + "_.PDF";
                //SavePDFFile(tempPdfFile);
                Support.SavePDF(tempPdfFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Support.AreEqual(true, pdfText.Contains("Lender:"), "Verify if Lender Field Exist.");
                Support.AreEqual(true, pdfText.Contains("First Chicago/Nbd Mortgage Company"), "Verify if Lender Name Exist");
                Support.AreEqual(true, pdfText.Contains("400 Central Avenue"), "Verify Property Address line 1 on TDI Form.");
                Support.AreEqual(true, pdfText.Contains("Northfield, IL 60093"), "Verify Property Address line 2 on TDI Form.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #endregion

        #region US 822055: Screen - Texas Dept of Insurance (TDI) - Section 2 Lender information under Lender and Settlement Agent section in TDI Form

        #region TC_829324

        [TestMethod]
        public void FMUC0137_REG0008()
        {
            try
            {
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to New Loan sccreen and create a new instance. ";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("197");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Expand Lender and Settlement Agent section.";
                FastDriver.TexasDisclosure.LenderAndSettlementAgent.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad();

                Reports.TestStep = "Verify if Lender Label Exist ";
                Support.AreEqual(true, FastDriver.TexasDisclosure.LenderName.Exists(), "Verify if Lender Label Exist");

                Reports.TestStep = "Verify if Lender Name Exist ";
                Support.AreEqual(true, FastDriver.TexasDisclosure.LenderName1Value.Text.Contains("First Chicago/Nbd Mortgage Company"), "Verify if Lender Name Exist ");

                Reports.TestStep = "Verify if Lender Address Label Exist ";
                Support.AreEqual(true, FastDriver.TexasDisclosure.LenderAddress.Exists(), "Verify if Lender Label Exist");

                Reports.TestStep = "Verify if Lender Address Exist ";
                Support.AreEqual(true, FastDriver.TexasDisclosure.LenderAddressValue.Text.Contains("400 Central Avenue"), "Verify if Lender Address Line 1 Exist ");
                Support.AreEqual(true, FastDriver.TexasDisclosure.LenderAddressCSZValue.Text.Contains("Northfield, IL 60093"), "Verify if Lender Address Line 2 Exist ");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #endregion

        #region US 822061: Screen - Texas Dept of Insurance (TDI) - Section 2 Display Settlement Agent information in Lender and Settlement Section in TDI Form

        #region TC_830132

        [TestMethod]
        public void FMUC0137_REG0009()
        {
            try
            {
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to New Loan sccreen and create a new instance. ";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("197");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Expand Lender and Settlement Agent section.";
                FastDriver.TexasDisclosure.LenderAndSettlementAgent.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad();

                Reports.TestStep = "Verify if Settlement Agent Label Exist ";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SettlemetnAgentName.Exists(), "Verify if Settlement Agent Label Exist");

                Reports.TestStep = "Verify if Settlement Agent Name Exist ";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SettlemetnAgentName1Value.Text.Contains("First American Title Insurance"), "Verify if Settlement Agent Name Exist ");
                Support.AreEqual(true, FastDriver.TexasDisclosure.SettlemetnAgentName2Value.Text.Contains("Company"), "Verify if Settlement Agent Name Exist ");

                Reports.TestStep = "Verify if Settlement Agent Address Label Exist ";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SettlemetnAgentAddress.Exists(), "Verify if Settlement Agent Label Exist");

                Reports.TestStep = "Verify if Settlement Agent Address Exist ";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SettlemetnAgentAddressLine1Value.Text.Contains("P. O. Box 3456"), "Verify if Settlement Agent Address Line 1 Exist ");
                Support.AreEqual(true, FastDriver.TexasDisclosure.SettlementAgentAddressCSZValue.Text.Contains("Austin, TX 90346"), "Verify if Settlement Agent Address Line 2 Exist ");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #endregion

        #region US 510590:	Delivery - Texas Dept of Insurance (TDI) - Section 2 Display Settlement Agent information in Lender and Settlement Section in TDI Form

        #region TC_831850

        [TestMethod]
        public void FMUC0137_REG0010()
        {
            try
            {
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to New Loan sccreen and create a new instance. ";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("197");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                //FastDriver.WebDriver.WaitForDeliveryWindow("Preview", 700);
                //FastDriver.WebDriver.ClosePreviewWindow();
                #endregion

                Reports.TestStep = "Save PDF file";
                string tempPdfFile = @"C:\Temp\Test_Docs" + Support.RandomString("NAN") + "_.PDF";
                //SavePDFFile(tempPdfFile);
                Support.SavePDF(tempPdfFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Support.AreEqual(true, pdfText.Contains("Settlement Agent:"), "Verify if Settlement Agent: Field Exist.");
                Support.AreEqual(true, pdfText.Contains("First American Title Insurance Company"), "Verify if Settlement Agent Name Exist");
                Support.AreEqual(true, pdfText.Contains("P. O. Box 3456"), "Verify Property Address line 1 on TDI Form.");
                Support.AreEqual(true, pdfText.Contains("Austin, TX 90346"), "Verify Property Address line 2 on TDI Form.");
            }
            catch (Exception)
            {

                throw;
            }


        }

        #endregion

        #endregion

        #region US 632229: Delivery - Texas Dept of Insurance (TDI)-T-64 Font Type
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\TexasDisclosure\")]
        public void FMUC0137_REG0011()
        {
            try
            {
                IRConfig.canSaveScreenSamples = true;

                #region Login to FINT32
                Reports.TestDescription = "Texas Dept of Insurance (TDI)-T-64 Font Type";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                Reports.TestStep = "Create a New File.";
                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();
                #endregion

                #region Verify T-64 Font Type on PDF File
                Reports.TestStep = "Verify T-64 Font Type on PDF File";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");
                Playback.Wait(3000);
                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);
                FASTHelpers.KeyboardSendKeys("^1"); // Zoom at 100% with keystroke {Ctrl + 1}

                var NameNumberInfo = FastDriver.TexasDisclosurePDF.IRTitleTexasDisclosure.Offset(600, 180).Visible();
                Support.IsTrue(NameNumberInfo, "IRTitleTexasDisclosure is Visible?");
                var formT64 = FastDriver.TexasDisclosurePDF.IRDescFormType.Offset(600, 210).Visible();
                Support.IsTrue(formT64, "IRDescFormType is Visible?");

                var tempPDF = Reports.DEPLOYDIR + "\\temp.pdf";
                SavePDFFile(tempPDF);
                var pdfText = Support.ReadPdfFile(tempPDF);
                Support.Match("This form provides additional disclosures and Texas Disclosure acknowledgements required in Texas\\. It is used with the federal Closing Disclosure form\\.", pdfText);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally
            {
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");
            }
        }
        #endregion

        #region US 592199: Delivery - Texas Dept of Insurance (TDI)- Display Form Name, Number and Purpose on Texas Disclosure Form
        [TestMethod]
        public void FMUC0137_REG0012()
        {

            try
            {
                #region Login to FINT32
                Reports.TestDescription = "Delivery - Display Form Name, Number and Purpose on Texas Disclosure Form";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Closing Disclosure screen";

                Enter_Closing_Information();

                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();
                Reports.TestDescription = "Verify T-64 Font Type on PDF File";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file";
                string tempPdfFile = @"C:\Temp\Test_Docs" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Support.AreEqual(true.ToString(), pdfText.Contains("Texas Disclosure").ToString(), "Verifying pdf contains \"Texas Disclosure\"");
                Support.AreEqual(true.ToString(), pdfText.Contains("Form T-64").ToString(), "Verifying pdf contains \"Form T-64\"");
                Support.AreEqual(true.ToString(), pdfText.Contains("This form provides additional disclosures and ").ToString(), "Verifying pdf contains \"This form provides additional disclosures and\"");
                Support.AreEqual(true.ToString(), pdfText.Contains("Texas Disclosure ").ToString(), "Verifying pdf contains \"Texas Disclosure\"");
                Support.AreEqual(true.ToString(), pdfText.Contains("acknowledgements required in Texas.").ToString(), "Verifying pdf contains \"acknowledgements required in Texas.\"");
                Support.AreEqual(true.ToString(), pdfText.Contains("It is used with the \nfederal Closing Disclosure form.").ToString(), "Verifying pdf contains \"It is used with the \nfederal Closing Disclosure form.\"");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region US 822037: Screen - Texas Dept of Insurance (TDI)- Display Form Name, Number and Purpose on Texas Disclosure Form
        [TestMethod]
        public void FMUC0137_REG0013()
        {
            try
            {
                #region Login to FINT32
                Reports.TestDescription = "Screen - Display Form Name, Number and Purpose on Texas Disclosure Form";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion


                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to TEXAS DISCLOSURE screen";
                FastDriver.TexasDisclosure.Open();

                Reports.TestDescription = "Verify Form Name, Number and Purose on Texas Disclosure Form";
                var headingText = FastDriver.TexasDisclosure.Heading_Table.FAGetText().Replace("\r\n", "");
                Support.AreEqual(true, headingText.Contains("Texas Disclosure"), "Texas Disclosure label is in displays");
                Support.AreEqual(true, headingText.Contains("Form T-64"), "Form T-64 label is in displays");
                Support.AreEqual(true, headingText.Contains("This form provides additional disclosures and acknowledgements required in Texas. It is used with the federal Closing Disclosure form."), "TDI Screen showing: This form provides additional disclosures and acknowledgements required in Texas. It is used with the federal Closing Disclosure form.");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region US 510549: Delivery - Texas Dept of Insurance (TDI) - Section 1 Display Closing Information Section on the TDI form
        [TestMethod]
        public void FMUC0137_REG0014()
        {
            try
            {
                #region Login to FINT32
                Reports.TestDescription = "Delivery: Section 1 Display Closing Information Section on the TDI form";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                Reports.TestDescription = "Get Sale Princes and New Loan Amount Values in File Homepage screen";
                FastDriver.FileHomepage.Open();
                var getSalePrice = FastDriver.FileHomepage.TermsDatesPrice.FAGetValue();
                var getNewLoan = FastDriver.FileHomepage.TermsDatesNewLoanAmnt.FAGetValue();
                var getFileNumber = FastDriver.FileHomepage.GetFileNumber();


                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Get Issued and Closing Dates Values in Closing Disclosure screen";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                #region Start Testing
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();
                var getIssuedDate = FastDriver.TexasDisclosure.IssuedDate.FAGetText();
                var getClosingDate = FastDriver.TexasDisclosure.ClosingDate.FAGetText();
                Reports.TestDescription = "Display Closing Information Section on the TDI form.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file";
                string tempPdfFile = @"C:\Temp\Test_Docs" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Support.AreEqual(true, pdfText.Contains(getIssuedDate), "Issued Date label is in displays");
                Support.AreEqual(true, pdfText.Contains(getClosingDate), "Closing Date label is in displays");
                Support.AreEqual(true, pdfText.Contains(getFileNumber), "File Number label is in displays");
                Support.AreEqual(true, pdfText.Contains(getSalePrice), "Sale Price label is in displays");
                Support.AreEqual(true, pdfText.Contains(getNewLoan), "Loan Amount label is in displays");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region US 822042: Screen - Texas Dept of Insurance (TDI) - Section 1 Display Closing Information Section on the TDI form
        [TestMethod]
        public void FMUC0137_REG0015()
        {

            try
            {
                #region Login to FINT32
                Reports.TestDescription = "Screen: Section 1 Display Closing Information Section on the TDI form";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Closing Disclosure screen";

                Enter_Closing_Information();

                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();
                Reports.TestDescription = "Verify Form Name, Number and Purpose on Texas Disclosure Form";
                Support.AreNotEqual(string.Empty, FastDriver.TexasDisclosure.Information_Table.PerformTableAction(1, 2, TableAction.GetText).Message, "Pass");
                Support.AreNotEqual(string.Empty, FastDriver.TexasDisclosure.Information_Table.PerformTableAction(2, 2, TableAction.GetText).Message, "Pass");
                Support.AreNotEqual(string.Empty, FastDriver.TexasDisclosure.Information_Table.PerformTableAction(3, 2, TableAction.GetText).Message, "Pass");
                Support.AreNotEqual(string.Empty, FastDriver.TexasDisclosure.Information_Table.PerformTableAction(4, 2, TableAction.GetText).Message, "Pass");
                Support.AreNotEqual(string.Empty, FastDriver.TexasDisclosure.Information_Table.PerformTableAction(5, 2, TableAction.GetText).Message, "Pass");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region US 853806: Texas Dept of Insurance (TDI) - Enable Underwriter/AgentDetail button if TDI config is true.
        #region TC_856334
        [TestMethod]
        public void FMUC0137_REG0017()
        {
            try
            {
                #region Login to FINT32
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Enable Underwriter/AgentDetail button if TDI config is true.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                Reports.TestStep = "Verify if Underwriter/Agent Detail button Exist";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.Underwriter.FAGetValue();
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent1.FAGetValue();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion
        #endregion

        #region US 612276: Texas Dept of Insurance (TDI)- Section 3 Title Premium Disclosure: Calculate and display Owner's Policy Premium amount

        #region TC_847660
        [TestMethod]
        public void FMUC0137_REG0018()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Screen - Section 3 Title Premium Disclosure: Calculate and Display Owner's Policy Premium amount";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Owners Policy Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen.";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Display Owner's Policy Premium amount in Texas Disclosure screen.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad(FastDriver.TexasDisclosure.OwnerPolicyAmount);
                Support.AreEqual(FastDriver.TexasDisclosure.OwnerPolicyAmount.FAGetText(), "$" + (BuyerCharge + SellerCharge).ToString() + ".00", "Owner Policy Amount is in Display");

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_847681
        [TestMethod]
        public void FMUC0137_REG0019()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Form - Section 3 Title Premium Disclosure: Calculate and Display Owner's Policy Premium amount.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Owners Policy Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen.";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Preview Texas Disclosure Document.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file.";
                string tempPdfFile = @"C:\Temp\temp" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Reports.TestDescription = "Display Owner's Policy Premium amount on PDF Form.";
                Support.AreEqual(true, pdfText.Contains("$200.00 \nTitle Agent: Owner’s Policy Premium"), "Owner Policy Amount is in Display.");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_861182
        [TestMethod]
        public void FMUC0137_REG0020()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Screen - Section 3 Title Premium Disclosure: Calculate and Display Owner's Policy Premium amount - Other Fee selected.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Escrow Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Owners Policy Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var FeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen.";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Display Owner's Policy Premium amount on Texas Disclosure screen.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad(FastDriver.TexasDisclosure.OwnerPolicyAmount);
                Support.AreEqual(FastDriver.TexasDisclosure.OwnerPolicyAmount.FAGetText(), "$" + (BuyerCharge + SellerCharge).ToString() + ".00", "Owner Policy Amount is $200.00");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_861184
        [TestMethod]
        public void FMUC0137_REG0021()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Form - Section 3 Title Premium Disclosure: Calculate and Display Owner's Policy Premium amount - Other Fee selected.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion


                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Escrow Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Fee Entry screen.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Owners Policy Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var FeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen.";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Preview Texas Dsiclosure Document.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file.";
                string tempPdfFile = @"C:\Temp\temp" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Reports.TestStep = "Display Owner's Policy Premium amount on PDF Form.";
                Support.AreEqual(true, pdfText.Contains("$200.00 \nTitle Agent: Owner’s Policy Premium"), "Owner Policy Amount is in TDI PDF Document");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region US 612284:Texas Dept of Insurance (TDI)- Section 3 Title Premium Disclosure: Calculate and display Loan Policy Premium amount.

        #region TC_849988

        [TestMethod]
        public void FMUC0137_REG0022()
        {
            try
            {

                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Screen - Section 3 Title Premium Disclosure: Calculate and display Loan Policy Premium amount.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion


                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Lenders Policy Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Display Lender's Policy Premium amount on Texas Disclosure screen.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad(FastDriver.TexasDisclosure.LoanPolicyAmount);
                Support.AreEqual(FastDriver.TexasDisclosure.LoanPolicyAmount.FAGetText(), "$" + (BuyerCharge + SellerCharge).ToString() + ".00", "Loan Policy Amount is in Display");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_849990

        [TestMethod]
        public void FMUC0137_REG0023()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Form - Section 3 Title Premium Disclosure: Calculate and display Loan Policy Premium amount.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Lenders Policy Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Preview Texas Disclosure Document.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file.";
                string tempPdfFile = @"C:\Temp\temp" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Reports.TestStep = "Display Lenders Policy Premium amount on PDF Form.";
                Support.AreEqual(true, pdfText.Contains("$200.00 \n  Loan Policy Premium"), "Lender Policy Amount is in Display");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_861187
        [TestMethod]
        public void FMUC0137_REG0024()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Screen - Section 3 Title Premium Disclosure: Calculate and display Loan Policy Premium amount - Other Fee selected.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Escrow Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Lenders Policy Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var FeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen.";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Display Lender Policy Premium amount on Texas Disclosure screen.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad(FastDriver.TexasDisclosure.LoanPolicyAmount);
                Support.AreEqual(FastDriver.TexasDisclosure.LoanPolicyAmount.FAGetText(), "$" + (BuyerCharge + SellerCharge).ToString() + ".00", "Loan Policy Amount is $200.00");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_861188
        [TestMethod]
        public void FMUC0137_REG0025()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Form - Section 3 Title Premium Disclosure: Calculate and display Loan Policy Premium amount - Other Fee Selected.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Escrow Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Lenders Policy Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var FeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen.";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Preview Texas Disclosure Document.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file.";
                string tempPdfFile = @"C:\Temp\temp" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Reports.TestStep = "Display Loan Policy Premium amount on PDF Form.";
                Support.AreEqual(true, pdfText.Contains("$200.00 \n  Loan Policy Premium"), "Loan Policy Amount is in TDI PDF Document");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region US 612297: Texas Dept of Insurance (TDI)- Section 3 Title Premium Disclosure:  Calculate and display Endorsements amount.

        #region TC_850022
        [TestMethod]
        public void FMUC0137_REG0026()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Screen - Section 3 Title Premium Disclosure: Calculate and Display Endorsements amount.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Endorsement Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Endorsement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Display Endorsement Policy Premium amount on Texas Disclosure screen.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad(FastDriver.TexasDisclosure.EndoresementAmount);
                Support.AreEqual(FastDriver.TexasDisclosure.EndoresementAmount.FAGetText(), "$" + (BuyerCharge + SellerCharge).ToString() + ".00", "Endorsement Amount is in Display");

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_850023
        [TestMethod]
        public void FMUC0137_REG0027()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Form - Section 3 Title Premium Disclosure: Calculate and Display Endorsments amount.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Endorsement Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Endorsement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();


                Reports.TestStep = "Preview Texas Disclosure Document.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file.";
                string tempPdfFile = @"C:\Temp\temp" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Reports.TestStep = "Display Endorsements Policy Premium amount on PDF Form.";
                Support.AreEqual(true, pdfText.Contains("$200.00 \nUnderwriter: Endorsements"), "Endorsement Policy Amount is in Display");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_857721
        [TestMethod]
        public void FMUC0137_REG0028()
        {
            try
            {
                #region Login to FINT32
                Reports.TestDescription = "TDI Screen - Section 3 Title Premium Disclosure: Calculate and Display Endorsements amount - FACC Fee type with Product of Texas.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                Reports.TestStep = "In File Homepage select a Product from Texas state.";
                FastDriver.FileHomepage.AddFileProduct("*Texas Owner Policy (T1)");
                FastDriver.FileHomepage.ProductCheckbox(0).FASetCheckbox(false);
                FastDriver.BottomFrame.Done();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.TitleRates.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.TitleFeesTitlePolicy);

                Reports.TestStep = "Select a Product from Texas State in Calculate Fee screen.";
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("Texas Owner Policy (T1)");
                Playback.Wait(5000);
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.AddEndorsementsButton_Product1.FAClick();
                FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Select a Endoresement.";
                FastDriver.FACCEndorsementsDlg.SelectEndorsement.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.CalculateFees.WaitForScreenToLoad();
                var FACCEndorsementTitle = FastDriver.CalculateFees.TitleFeesTable.PerformTableAction(3, 4, TableAction.GetText).Message;
                FastDriver.CalculateFees.Next.FAClick();

                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 4, TableAction.SelectItemByIndex, "1");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 4, TableAction.SelectItemByIndex, "1");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(3, 5, TableAction.SelectItem, "Seller");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Save Buyer/Seller Charges.";
                FastDriver.FileFees.WaitForScreenToLoad();
                var TotalCharge = FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FACCEndorsementTitle, "Total Charge", TableAction.GetInputValue).Message;
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen.";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Display FACC Endorsement and amount on Texas Disclosure screen.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad(FastDriver.TexasDisclosure.EndoresementAmount);
                Support.AreEqual(FastDriver.TexasDisclosure.EndoresementAmount.FAGetText(), "$" + TotalCharge, "Endorsement Amount is in Display");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_861230
        [TestMethod]
        public void FMUC0137_REG0029()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Screen - Section 3 Title Premium Disclosure: Calculate and Display Endorsements amount - Other Fee selected.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Escrow Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Fee Entry screen.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Endorsement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var FeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen.";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Display Owner's Policy Premium amount on Texas Disclosure screen.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad(FastDriver.TexasDisclosure.EndoresementAmount);
                Support.AreEqual(FastDriver.TexasDisclosure.EndoresementAmount.FAGetText(), "$" + (BuyerCharge + SellerCharge).ToString() + ".00", "Endorsement Fee Amount is $200.00");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_861236
        [TestMethod]
        public void FMUC0137_REG0030()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Form - Section 3 Title Premium Disclosure: Calculate and Display Endorsments amount - Other Fee selected.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Escrow Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Endorsement Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Endorsement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var FeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen.";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Preview Texas Disclosure Document.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file.";
                string tempPdfFile = @"C:\Temp\temp" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Reports.TestStep = "Display Endorsement amount on PDF Form.";
                Support.AreEqual(true, pdfText.Contains("$200.00 \nUnderwriter: Endorsements"), "Endorsement Amount is in TDI PDF Document");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region US 511333: Texas Dept of Insurance (TDI)- Section 3 Title Premium Disclosure:  Display Title Insurance Premium sections

        #region TC_850035
        [TestMethod]
        public void FMUC0137_REG0031()
        {
            try
            {
                #region Login to FINT32
                Reports.TestDescription = "TDI Form- Section 3 Title Premium Disclosure: Display Title Insurance Premium sections.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Display Title Insurance Premium sections.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file.";
                string tempPdfFile = @"C:\Temp\temp" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Reports.TestStep = "Verify Title Insurance Premium Text in Texas Disclosure Screen.";
                Support.AreEqual(true, pdfText.Contains("\nTitle Insurance Premiums"), "Title Insurance Premiums is in displays");
                Support.AreEqual(true, pdfText.Contains("\nIf you are buying both an owner’s policy and a loan policy, the title insurance premiums on this form might be \ndifferent than the premiums on the Closing Disclosure."), "Text is in displays");
                Support.AreEqual(true, pdfText.Contains("The owner’s policy premium listed on the Closing Disclosure \nwill probably be lower than on this form, and the loan policy premium will probably be higher."), "Text is in displays");
                Support.AreEqual(true, pdfText.Contains("If you add the two \npolicies’ premiums on the Closing Disclosure together, however, the total should be the same as the total of the two \npremiums on this form."), "Text is in displays");
                Support.AreEqual(true, pdfText.Contains("\nThe premiums are different on the two forms because the Closing Disclosure is governed by federal law, while this \nform is governed by Texas law."), "Text is in displays");
                Support.AreEqual(true, pdfText.Contains("The owner’s policy and loan policy premiums are set by the Texas commissioner of \ninsurance."), "Text is in displays");
                Support.AreEqual(true, pdfText.Contains("When you buy both an owner’s policy and a loan policy in the same transaction, you are charged the full \npremium for the owner’s policy but receive a discount on the loan policy premium."), "Text is in displays");
                Support.AreEqual(true, pdfText.Contains("Federal and Texas law differ on \nwhere the discount is shown."), "Text is in displays");
                Support.AreEqual(true, pdfText.Contains("Texas law requires the discount to be reflected in the loan policy premium, while federal \nlaw requires the discount to be reflected in the owner’s policy premium."), "Text is in displays");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_856020
        [TestMethod]
        public void FMUC0137_REG0032()
        {
            try
            {
                #region Login to FINT32
                Reports.TestDescription = "TDI Screen - Section 3 Title Premium Disclosure: Display Title Insurance Premium sections.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Display Title Insurance Premium sections in Texas Disclosure screen.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                var TIP_table_section = FastDriver.TexasDisclosure.TIP_Table.FAGetText().Replace("\r\n", "");

                Support.AreEqual(true, TIP_table_section.Contains("If you are buying both an owner’s policy and a loan policy, the title insurance premiums on this form might be"), "Text is in displays");
                Support.AreEqual(true, TIP_table_section.Contains("different than the premiums on the Closing Disclosure. The owner’s policy premium listed on the Closing"), "Text is in displays");
                Support.AreEqual(true, TIP_table_section.Contains("Disclosure will probably be lower than on this form, and the loan policy premium will probably be higher. If you"), "Text is in displays");
                Support.AreEqual(true, TIP_table_section.Contains("add the two policies’ premiums on the Closing Disclosure together, however, the total should be the same as the"), "Text is in displays");
                Support.AreEqual(true, TIP_table_section.Contains("total of the two premiums on this form."), "Text is in displays");
                Support.AreEqual(true, TIP_table_section.Contains("The premiums are different on the two forms because the Closing Disclosure is governed by federal law, while this"), "Text is in displays");
                Support.AreEqual(true, TIP_table_section.Contains("form is governed by Texas law. The owner’s policy and loan policy premiums are set by the Texas commissioner of"), "Text is in displays");
                Support.AreEqual(true, TIP_table_section.Contains("insurance. When you buy both an owner’s policy and a loan policy in the same transaction, you are charged the full"), "Text is in displays");
                Support.AreEqual(true, TIP_table_section.Contains("premium for the owner’s policy but receive a discount on the loan policy premium. Federal and Texas law differ on"), "Text is in displays");
                Support.AreEqual(true, TIP_table_section.Contains("where the discount is shown. Texas law requires the discount to be reflected in the loan policy premium, while"), "Text is in displays");
                Support.AreEqual(true, TIP_table_section.Contains("federal law requires the discount to be reflected in the owner’s policy premium."), "Text is in displays");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion



        #endregion

        #region US 612305: Texas Dept of Insurance (TDI)- Section 3 Title Premium Disclosure: Calculate and display 'Other' amount.

        #region TC_850875

        [TestMethod]
        public void FMUC0137_REG0033()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Screen - Section 3 Title Premium Disclosure: Calculate and Display 'Other' amount.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion


                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Miscellaneous Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Miscellaneous");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Display Other Amount on Texas Disclosure screen.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad(FastDriver.TexasDisclosure.OtherAmount);
                Support.AreEqual(FastDriver.TexasDisclosure.OtherAmount.FAGetText(), "$" + (BuyerCharge + SellerCharge).ToString() + ".00", "Other Amount is in Display");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_850878
        [TestMethod]
        public void FMUC0137_REG0034()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Form - Section 3 Title Premium Disclosure: Calculate and Display 'Other' amount.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Miscellaneous Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Miscellaneous");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Preview Texas Disclosure Document";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file.";
                string tempPdfFile = @"C:\Temp\temp" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Reports.TestDescription = "Display Other amount on PDF Form.";
                Support.AreEqual(true, pdfText.Contains("\n$200.00 \n  Other"), "Other Amount is in Display");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_861335
        [TestMethod]
        public void FMUC0137_REG0035()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Screen - Section 3 Title Premium Disclosure: Calculate and Display 'Other' amount - Other Fee Selected.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Escrow Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Miscellaneous Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Miscellaneous");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var FeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Display Other Amount on Texas Disclosure screen.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad(FastDriver.TexasDisclosure.OtherAmount);
                Support.AreEqual(FastDriver.TexasDisclosure.OtherAmount.FAGetText(), "$" + (BuyerCharge + SellerCharge).ToString() + ".00", "Other Amount is $200.00");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_861348
        [TestMethod]
        public void FMUC0137_REG0036()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100.00;
                var SellerCharge = 100.00;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Form - Section 3 Title Premium Disclosure: Calculate and Display 'Other' amount - Other Fee Selected";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion


                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen and add a Fee Type = Escrow Fee";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Escrow Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.buyercharge.FASetText(BuyerCharge.ToString() + FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText(SellerCharge.ToString() + FAKeys.TabAway);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Select a Title - Miscellaneous Fee Type.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Miscellaneous");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var FeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Enter Buyer/Seller Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", FeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Preview Texas Disclosure Document";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file.";
                string tempPdfFile = @"C:\Temp\temp" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Reports.TestStep = "Display Other Policy Premium amount on PDF Form.";
                Support.AreEqual(true, pdfText.Contains("\n$200.00 \n  Other"), "Owner Policy Amount is in TDI PDF Document");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region US 612323: Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display Title Agent name

        #region TC_853986
        [TestMethod]
        public void FMUC0137_REG0037()
        {
            try
            {
                #region Login to FINT32
                Reports.TestDescription = "TDI Screen: Section 3 Title Premium Disclosure - Display Agent Name";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                var TitleAgentNameValue = FastDriver.UnderwriterAgentDetailDlg.TitleAgent1.FAGetValue();
                FastDriver.DialogBottomFrame.ClickDone();


                //Reports.TestStep = "Navigate to Closing Disclosure screen";
                //Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();
                Reports.TestDescription = "Display Title Agent Name in Title Insurance Premiums in Texas Disclosure screen.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad(FastDriver.TexasDisclosure.TitleAgentName);
                Support.AreEqual(FastDriver.TexasDisclosure.TitleAgentName.FAGetText(), TitleAgentNameValue, "Title Agent Name is in Display");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_856019
        [TestMethod]
        public void FMUC0137_REG0038()
        {
            try
            {
                #region Login to FINT32
                Reports.TestDescription = "TDI Screen: Section 3 Title Premium Disclosure - Display Agent Name";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                var TitleAgentNameValue = FastDriver.UnderwriterAgentDetailDlg.TitleAgent1.FAGetValue();
                FastDriver.DialogBottomFrame.ClickDone();


                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Display Total amount on PDF Form.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file";
                string tempPdfFile = @"C:\Temp\temp" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);
                Support.AreEqual(true, pdfText.Contains("\nFirst American Title Insurance Company $0 \nTitle Agent:"), "Title Agent in Display");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_861656
        [TestMethod]
        public void FMUC0137_REG0039()
        {
            try
            {
                #region Login to FINT32
                Reports.TestDescription = "TDI Screen: Section 3 Title Premium Disclosure - Display Agent Name - Enter a Title Agent Name manually";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent1.FASetText("Test Title Agent 1");
                var TitleAgentNameValue = FastDriver.UnderwriterAgentDetailDlg.TitleAgent1.FAGetValue();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();
                Reports.TestDescription = "Display Title Agent Name in Title Insurance Premiums in Texas Disclosure screen.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad(FastDriver.TexasDisclosure.TitleAgentName);
                Support.AreEqual(FastDriver.TexasDisclosure.TitleAgentName.FAGetText(), TitleAgentNameValue, "Title Agent Name is in Display");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_864019
        [TestMethod]
        public void FMUC0137_REG0040()
        {
            try
            {
                #region Login to FINT32
                Reports.TestDescription = "TDI Screen: Section 3 Title Premium Disclosure - Display Agent Name";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent1SelectButton.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.IDCode.FASetText("1128");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                Playback.Wait(10000);
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "1128", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                var TitleAgentNameValue = FastDriver.UnderwriterAgentDetailDlg.TitleAgent1.FAGetValue();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestDescription = "Display Total amount on PDF Form.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file";
                string tempPdfFile = @"C:\Temp\temp" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);
                Support.AreEqual(true, pdfText.Contains(TitleAgentNameValue), "Title Agent in Display");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion
        #endregion

        #region US 612316: Texas Dept of Insurance (TDI)- Section 3 Title Premium Disclosure:  Calculate and display 'Total' amount for Title Insurance Premiums.

        #region TC_850880

        [TestMethod]
        public void FMUC0137_REG0041()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100;
                var SellerCharge = 100;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Screen - Section 3 Title Premium Disclosure: Calculate and Display 'Total' amount for Title Insurance Premiums.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Add a Title - Owners Policy Fee";
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var OwnerFeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", OwnerFeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", OwnerFeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a Title - Lenders Policy Fee";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var LoanFeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", LoanFeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", LoanFeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a Title - Endorsement Fee";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Endorsement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var EndorsementFeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", EndorsementFeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", EndorsementFeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a Title - Miscellaneous Fee";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Miscellaneous");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var MiscellaneousFeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", MiscellaneousFeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", MiscellaneousFeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Display Other amount on Texas Disclosure screen.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad(FastDriver.TexasDisclosure.TotalAmount);

                Reports.TestStep = "Sum All amounts and display Total amounst on Texas Disclosure screen.";
                var OwnerAmounts = Convert.ToInt64(Math.Floor(Convert.ToDouble(FastDriver.TexasDisclosure.OwnerPolicyAmount.FAGetText().Substring(1))));
                var LoanAmounts = Convert.ToInt64(Math.Floor(Convert.ToDouble(FastDriver.TexasDisclosure.LoanPolicyAmount.FAGetText().Substring(1))));
                var EndorsementAmounts = Convert.ToInt64(Math.Floor(Convert.ToDouble(FastDriver.TexasDisclosure.EndoresementAmount.FAGetText().Substring(1))));
                var OtherAmounts = Convert.ToInt64(Math.Floor(Convert.ToDouble(FastDriver.TexasDisclosure.OtherAmount.FAGetText().Substring(1))));

                Support.AreEqual(FastDriver.TexasDisclosure.TotalAmount.FAGetText(), "$" + (OwnerAmounts + LoanAmounts + EndorsementAmounts + OtherAmounts) + ".00", "Total Amount is in Display");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region TC_850884
        [TestMethod]
        public void FMUC0137_REG0042()
        {
            try
            {
                #region Data Setup
                var BuyerCharge = 100;
                var SellerCharge = 100;
                #endregion

                #region Login to FINT32
                Reports.TestDescription = "TDI Screen - Section 3 Title Premium Disclosure: Calculate and Display 'Total' amount for Title Insurance Premiums.";
                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                #endregion

                NEW_TDI_FILE();

                #region Start Testing
                Reports.TestStep = "Navigate to Fee Entry screen.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();

                Reports.TestStep = "Add a Title - Owners Policy Fee.";
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var OwnerFeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", OwnerFeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", OwnerFeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a Title - Lenders Policy Fee.";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var LoanFeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", LoanFeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", LoanFeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a Title - Endorsement Fee.";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Endorsement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var EndorsementFeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", EndorsementFeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", EndorsementFeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a Title - Miscellaneous Fee.";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Miscellaneous");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                var MiscellaneousFeeName = FastDriver.FileFees.AddFeeTable.PerformTableAction(1, 2, TableAction.GetText).Message;
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", MiscellaneousFeeName, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", MiscellaneousFeeName, "Seller Charge", TableAction.SetText, SellerCharge.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen.";
                Enter_Closing_Information();

                Reports.TestStep = "Navigate to Texas Disclosure screen.";
                FastDriver.TexasDisclosure.Open();
                FastDriver.TexasDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Preview Texas Disclosure Document.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Preview");

                Reports.TestStep = "Save PDF file.";
                string tempPdfFile = @"C:\Temp\temp" + Support.RandomString("NAN") + "_.PDF";
                SavePDFFile(tempPdfFile);

                TexasDisclosurePDF.Maximize();
                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: tempPdfFile);

                Reports.TestStep = "Display Total amount on PDF Form.";
                Support.AreEqual(true, pdfText.Contains("\n$800.00 \n  TOTAL"), "Total Amount is in Display");


                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion
        #endregion

        #region US 510572: Texas Dept of Insurance (TDI) - Section 1 Display Seller Information under Transaction Information

        #region TC_850896_1

        [TestMethod]
        public void FMUC0137_REG0043()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Display Seller Information under Transaction Information -> Screen-> Seller";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Seller screen and create a new Seller with an address.";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "SellerName SellerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.Sellers.Exists(), "Verify if Seller(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s) name value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SellersValues.Text.Contains("SellerName SellerLastName"), "Verify if Seller(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SellersAddresses.Exists(), "Verify if  Seller's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es) value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SellersAddressesValue.FAGetText().Contains("Line1Line1Line1Line1Line1Line1Line1, " +
                    "Line2Line2Line2Line2Line2Line2Line2, Line3Line3Line3Line3Line3Line3Line3, Line4Line4Line4Line4Line4Line4Line4"), "Verify if Seller's Address(es) value exist.");
                Support.AreEqual("Santa Ana, CA 51000", FastDriver.TexasDisclosure.SellerSateZipValue.FAGetText().Clean(), "Verify if Seller's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region TC_850989_2

        [TestMethod]
        public void FMUC0137_REG0044()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Display Seller Information under Transaction Information -> Delivery-> Seller";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Seller screen and create a new Seller with an address.";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "SellerName SellerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf. ";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NAN") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s): label exist.";
                Support.AreEqual(true, pdfText.Contains("Seller(s):"), "Verify if Seller(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s) name value exist.";
                Support.AreEqual(true, pdfText.Contains("SellerName SellerLastName"), "Verify if Seller(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es): label exist.";
                Support.AreEqual(true, pdfText.Contains("Address(es):"), "Verify if  Seller's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es) value exist.";
                Support.AreEqual(true, pdfText.Contains("Line1Line1Line1Line1Line1Line1Line1,"), "Verify if Seller's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Santa Ana, CA 51000"), "Verify if Seller's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region TC_851581_3

        [TestMethod]
        public void FMUC0137_REG0045()
        {
            Reports.TestDescription = "TC_510572_3: Texas Dept of Insurance (TDI) - Section 1 Display Seller Information under Transaction Information -> Screen -> Seller -> Husband/Wife";

            Reports.TestStep = "Log into Fast";
            FAST_Login_IIS();

            Reports.TestStep = "Change to QA SANDPOINTE REGION";
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

            Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
            CreateBasicTDI_File();

            Reports.TestStep = "Go to Seller screen.";
            FastDriver.BuyerSellerSummary.Open(isBuyer: false);
            FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "SellerName SellerLastName", 2, TableAction.Click);
            FastDriver.BuyerSellerSummary.btnEdit.FAClick();
            FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Husband/Wife");
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("SpouseSellerName");
            FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
            FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
            FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
            FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
            FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
            FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
            FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
            FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Go to Texas disclosure screen.";
            FastDriver.TexasDisclosure.Open();

            Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s): label exist.";
            Support.AreEqual(true, FastDriver.TexasDisclosure.Sellers.Exists(), "Verify if Seller(s): label exist.");

            Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s) name value exist.";
            Support.AreEqual(true, FastDriver.TexasDisclosure.SellersValues.Text.Contains("SellerName SellerLastName and SpouseSellerName SellerLastName"), "Verify if Seller(s) name value exist.");

            Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es): label exist.";
            Support.AreEqual(true, FastDriver.TexasDisclosure.SellersAddresses.Exists(), "Verify if  Seller's Address(es): label exist.");

            Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es) value exist.";
            Support.AreEqual(true, FastDriver.TexasDisclosure.SellersAddressesValue.FAGetText().Contains("Line1Line1Line1Line1Line1Line1Line1, " +
                     "Line2Line2Line2Line2Line2Line2Line2, Line3Line3Line3Line3Line3Line3Line3, Line4Line4Line4Line4Line4Line4Line4"), "Verify if Seller's Address(es) value exist.");
            Support.AreEqual("Santa Ana, CA 51000", FastDriver.TexasDisclosure.SellerSateZipValue.FAGetText().Clean(), "Verify if Seller's Address(es) value exist.");
        }

        #endregion

        #region TC_852345_4

        [TestMethod]
        public void FMUC0137_REG0046()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Display Seller Information under Transaction Information -> Screen-> Seller -> Business Entity";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Seller screen.";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "SellerName SellerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Business Entity");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("ShortNameBE");
                FastDriver.BuyerSellerSetup.BusinessEntityName.FASetText("NameOfEntityBE");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.Sellers.Exists(), "Verify if Seller(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s) name value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SellersValues.Text.Contains("ShortNameBE"), "Verify if Seller(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SellersAddresses.Exists(), "Verify if  Seller's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es) value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SellersAddressesValue.FAGetText().Contains("Line1Line1Line1Line1Line1Line1Line1, " +
                    "Line2Line2Line2Line2Line2Line2Line2, Line3Line3Line3Line3Line3Line3Line3, Line4Line4Line4Line4Line4Line4Line4"), "Verify if Seller's Address(es) value exist.");
                Support.AreEqual("Santa Ana, CA 51000", FastDriver.TexasDisclosure.SellerSateZipValue.FAGetText().Clean(), "Verify if Seller's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_852346_5

        [TestMethod]
        public void FMUC0137_REG0047()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Display Seller Information under Transaction Information -> Screen-> Seller -> Business Entity";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Seller screen.";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "SellerName SellerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Trust/Estate");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Trust/EstateTE");
                FastDriver.BuyerSellerSetup.TrusteeName.FASetText("NameOfEntityTE");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.Sellers.Exists(), "Verify if Seller(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s) name value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SellersValues.Text.Contains("Trust/EstateTE"), "Verify if Seller(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SellersAddresses.Exists(), "Verify if  Seller's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es) value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SellersAddressesValue.FAGetText().Contains("Line1Line1Line1Line1Line1Line1Line1, " +
                    "Line2Line2Line2Line2Line2Line2Line2, Line3Line3Line3Line3Line3Line3Line3, Line4Line4Line4Line4Line4Line4Line4"), "Verify if Seller's Address(es) value exist.");
                Support.AreEqual("Santa Ana, CA 51000", FastDriver.TexasDisclosure.SellerSateZipValue.FAGetText().Clean(), "Verify if Seller's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_852347_6

        [TestMethod]
        public void FMUC0137_REG0048()
        {
            try
            {
                Reports.TestDescription = "TC_510572_6: Texas Dept of Insurance (TDI) - Section 1 Display Seller Information under Transaction Information -> Delivery-> Seller -> Husband/Wife";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Seller screen.";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "SellerName SellerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("SpouseSellerName");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf. ";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NAN") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s): label exist.";
                Support.AreEqual(true, pdfText.Contains("Seller(s):"), "Verify if Seller(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s) name value exist.";
                Support.AreEqual(true, pdfText.Contains("SellerName SellerLastName and SpouseSellerName \n \nSellerLastName"), "Verify if Seller(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es): label exist.";
                Support.AreEqual(true, pdfText.Contains("Address(es):"), "Verify if  Seller's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es) value exist.";
                Support.AreEqual(true, pdfText.Contains("Line1Line1Line1Line1Line1Line1Line1, " +
                    "\nLine2Line2Line2Line2Line2Line2Line2, \nLine3Line3Line3Line3Line3Line3Line3, " +
                    "\nLine4Line4Line4Line4Line4Line4Line4"), "Verify if Seller's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Santa Ana, CA 51000"), "Verify if Seller's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_852348_7

        [TestMethod]
        public void FMUC0137_REG0049()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Display Seller Information under Transaction Information -> Delivery-> Seller -> Business Entity";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Seller screen.";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "SellerName SellerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Business Entity");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("ShortNameBE");
                FastDriver.BuyerSellerSetup.BusinessEntityName.FASetText("NameOfEntityBE");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf. ";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NAN") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s): label exist.";
                Support.AreEqual(true, pdfText.Contains("Seller(s):"), "Verify if Seller(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s) name value exist.";
                Support.AreEqual(true, pdfText.Contains("ShortNameBE"), "Verify if Seller(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es): label exist.";
                Support.AreEqual(true, pdfText.Contains("Address(es):"), "Verify if  Seller's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es) value exist.";
                Support.AreEqual(true, pdfText.Contains("Line1Line1Line1Line1Line1Line1Line1, " +
                    "\nLine2Line2Line2Line2Line2Line2Line2, \nLine3Line3Line3Line3Line3Line3Line3, " +
                    "\nLine4Line4Line4Line4Line4Line4Line4"), "Verify if Seller's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Santa Ana, CA 51000"), "Verify if Seller's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_852350_8

        [TestMethod]
        public void FMUC0137_REG0050()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Display Seller Information under Transaction Information -> Delivery-> Seller -> Trust/Estate";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Seller screen.";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false);
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "SellerName SellerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Trus/Estate");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Trust/EstateTE");
                FastDriver.BuyerSellerSetup.TrusteeName.FASetText("NameOfEntityTE");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf. ";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NAN") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s): label exist.";
                Support.AreEqual(true, pdfText.Contains("Seller(s):"), "Verify if Seller(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s) name value exist.";
                Support.AreEqual(true, pdfText.Contains("Trust/EstateTE"), "Verify if Seller(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es): label exist.";
                Support.AreEqual(true, pdfText.Contains("Address(es):"), "Verify if  Seller's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es) value exist.";
                Support.AreEqual(true, pdfText.Contains("Line1Line1Line1Line1Line1Line1Line1, " +
                     "\nLine2Line2Line2Line2Line2Line2Line2, \nLine3Line3Line3Line3Line3Line3Line3, " +
                     "\nLine4Line4Line4Line4Line4Line4Line4"), "Verify if Seller's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Santa Ana, CA 51000"), "Verify if Seller's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_852388_9

        [TestMethod]
        public void FMUC0137_REG0051()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Display Seller Information under Transaction Information -> Screen -> Seller -> Multiple Sellers";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Seller screen.";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false);

                Reports.TestStep = "Create multiple Sellers.";

                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "SellerName SellerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                for (int i = 0; i <= 3; i++)
                {
                    FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                    FastDriver.BuyerSellerSummary.btnNew.FAClick();
                    FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("SellerName" + i.ToString());
                    FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("SellerLastName" + i.ToString());
                    FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                    FastDriver.BottomFrame.Done();
                    FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                }


                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf. ";
                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.Sellers.Exists(), "Verify if Seller(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s) name value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SellersValues.Text.Contains("*SellerName SellerLastName, SellerName0 SellerLastName0, SellerName1 SellerLastName1, "
                    + "SellerName2 SellerLastName2, SellerName3"), "Verify if Seller(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SellersAddresses.Exists(), "Verify if  Seller's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es) value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.SellersAddressesValue.FAGetText().Contains("*Line1Line1Line1Line1Line1Line1Line1, " +
                    "Line2Line2Line2Line2Line2Line2Line2, Line3Line3Line3Line3Line3Line3Line3, Line4Line4Line4Line4Line4Line4Line4"), "Verify if Seller's Address(es) value exist.");
                Support.AreEqual("Santa Ana, CA 51000", FastDriver.TexasDisclosure.SellerSateZipValue.FAGetText().Clean(), "Verify if Seller's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_852392_10

        [TestMethod]
        public void FMUC0137_REG0052()
        {
            try
            {
                Reports.TestDescription = "TC_510572_10: Texas Dept of Insurance (TDI) - Section 1 Display Seller Information under Transaction Information -> Delivery -> Seller -> Multiple Sellers";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Seller screen.";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false);

                Reports.TestStep = "Create multiple Sellers.";

                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "SellerName SellerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                for (int i = 0; i <= 3; i++)
                {
                    FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                    FastDriver.BuyerSellerSummary.btnNew.FAClick();
                    FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("SellerName" + i.ToString());
                    FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("SellerLastName" + i.ToString());
                    FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                    FastDriver.BottomFrame.Done();
                    FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                }


                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf. ";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NAN") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s): label exist.";
                Support.AreEqual(true, pdfText.Contains("Seller(s):"), "Verify if Seller(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Seller(s) name value exist.";
                Support.AreEqual(true, pdfText.Contains("*SellerName SellerLastName, SellerName0 \n \nSellerLastName0, " +
                    "SellerName1 SellerLastName1, \nSellerName2 SellerLastName2, SellerName3"), "Verify if Seller(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es): label exist.";
                Support.AreEqual(true, pdfText.Contains("Address(es):"), "Verify if  Seller's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Seller's Address(es) value exist.";
                Support.AreEqual(true, pdfText.Contains("*Line1Line1Line1Line1Line1Line1Line1, " +
                    "\nLine2Line2Line2Line2Line2Line2Line2, \nLine3Line3Line3Line3Line3Line3Line3, " +
                    "\nLine4Line4Line4Line4Line4Line4Line4"), "Verify if Seller's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Santa Ana, CA 51000"), "Verify if Seller's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region US 510584: Texas Dept of Insurance (TDI) - Section 1 Borrower Details under Transaction Information        

        #region TC_850998_1

        [TestMethod]
        public void FMUC0137_REG0053()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Display Borrower Information under Transaction Information -> Delivery -> Borrower";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.BusinessSegment.FASelectItemBySendingKeys("Refinance");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Go to Seller screen and create a new Borrower with an address.";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "BuyerName BuyerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("BorrowerName");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("BorrowerLastName");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf. ";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s): label exist.";
                Support.AreEqual(true, pdfText.Contains("Borrower(s):"), "Verify if Borrower(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s) name value exist.";
                Support.AreEqual(true, pdfText.Contains("BorrowerName BorrowerLastName"), "Verify if Borrower(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es): label exist.";
                Support.AreEqual(true, pdfText.Contains("Address(es):"), "Verify if  Borrower's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es) value exist.";
                Support.AreEqual(true, pdfText.Contains("Line1Line1Line1Line1Line1Line1Line1"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line2Line2Line2Line2Line2Line2Line2"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line3Line3Line3Line3Line3Line3Line3"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line4Line4Line4Line4Line4Line4Line4"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Santa Ana, CA 51000"), "Verify if Seller's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region TC_850999_2

        [TestMethod]
        public void FMUC0137_REG0054()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Display Seller Information under Transaction Information -> Screen -> Borrower";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Seller screen and create a new Borrower with an address.";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "BuyerName BuyerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("BorrowerName");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("BorrowerLastName");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.Borrowers.Exists(), "Verify if Borrower(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s) name value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowersValue.Text.Contains("BorrowerName BorrowerLastName"), "Verify if Seller(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowerAddresses.Exists(), "Verify if  Borrower's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es) value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowerAddressesValue.FAGetText().Contains("Line1Line1Line1Line1Line1Line1Line1, " +
                    "Line2Line2Line2Line2Line2Line2Line2, Line3Line3Line3Line3Line3Line3Line3, Line4Line4Line4Line4Line4Line4Line4"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual("Santa Ana, CA 51000", FastDriver.TexasDisclosure.BorrowerCSZValue.FAGetText().Clean(), "Verify if Borrower's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region TC_852487_3

        [TestMethod]
        public void FMUC0137_REG0055()
        {
            Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Borrower Details under Transaction Information -> Screen -> Borrower -> Husband/Wife";

            Reports.TestStep = "Log into Fast";
            FAST_Login_IIS();

            Reports.TestStep = "Change to QA SANDPOINTE REGION";
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

            Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
            CreateBasicTDI_File();

            Reports.TestStep = "Go to Seller screen.";
            FastDriver.BuyerSellerSummary.Open();
            FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "BuyerName BuyerLastName", 2, TableAction.Click);
            FastDriver.BuyerSellerSummary.btnEdit.FAClick();
            FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Husband/Wife");
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("BorrowerName");
            FastDriver.BuyerSellerSetup.HusbandLastName.FASetText("BorrowerLastName");
            FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("SpouseBorrowerName");
            FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
            FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
            FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
            FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
            FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
            FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
            FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
            FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Go to Texas disclosure screen.";
            FastDriver.TexasDisclosure.Open();

            Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s): label exist.";
            Support.AreEqual(true, FastDriver.TexasDisclosure.Borrowers.Exists(), "Verify if Borrower(s): label exist.");

            Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s) name value exist.";
            Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowersValue.Text.Contains("BorrowerName BorrowerLastName and SpouseBorrowerName BorrowerLastName"), "Verify if Borrower(s) name value exist.");

            Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es): label exist.";
            Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowerAddresses.Exists(), "Verify if  Borrower's Address(es): label exist.");

            Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es) value exist.";
            Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowerAddressesValue.FAGetText().Contains("Line1Line1Line1Line1Line1Line1Line1, " +
                    "Line2Line2Line2Line2Line2Line2Line2, Line3Line3Line3Line3Line3Line3Line3, Line4Line4Line4Line4Line4Line4Line4"), "Verify if Borrower's Address(es) value exist.");
            Support.AreEqual("Santa Ana, CA 51000", FastDriver.TexasDisclosure.BorrowerCSZValue.FAGetText().Clean(), "Verify if Borrower's Address(es) value exist.");
        }

        #endregion

        #region TC_852347_4

        [TestMethod]
        public void FMUC0137_REG0056()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Borrower Details under Transaction Information -> Delivery -> Borrower -> Husband/Wife";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Seller screen.";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "BuyerName BuyerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("BorrowerName");
                FastDriver.BuyerSellerSetup.HusbandLastName.FASetText("BorrowerLastName");
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("SpouseBorrowerName");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf. ";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s): label exist.";
                Support.AreEqual(true, pdfText.Contains("Seller(s):"), "Verify if Borrower(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s) name value exist.";
                Support.AreEqual(true, pdfText.Contains("BorrowerName BorrowerLastName and"), "Verify if Borrower(s) name value exist.");
                Support.AreEqual(true, pdfText.Contains("SpouseBorrowerName BorrowerLastName"), "Verify if Borrower(s) Spouse name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es): label exist.";
                Support.AreEqual(true, pdfText.Contains("Address(es):"), "Verify if  Seller's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es) value exist.";
                Support.AreEqual(true, pdfText.Contains("Line1Line1Line1Line1Line1Line1Line1"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line2Line2Line2Line2Line2Line2Line2"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line3Line3Line3Line3Line3Line3Line3"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line4Line4Line4Line4Line4Line4Line4"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Santa Ana, CA 51000"), "Verify if Borrower's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_852527_5

        [TestMethod]
        public void FMUC0137_REG0057()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Borrower Details under Transaction Information -> Screen -> Borrower -> Business Entity";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Borrower screen.";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "BuyerName BuyerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Business Entity");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("ShortNameBE");
                FastDriver.BuyerSellerSetup.BusinessEntityName.FASetText("NameOfEntityBE");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.Borrowers.Exists(), "Verify if Seller(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s) name value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowersValue.Text.Contains("ShortNameBE"), "Verify if Borrower(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowerAddresses.Exists(), "Verify if  Borrower's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es) value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowerAddressesValue.FAGetText().Contains("Line1Line1Line1Line1Line1Line1Line1, " +
                    "Line2Line2Line2Line2Line2Line2Line2, Line3Line3Line3Line3Line3Line3Line3, Line4Line4Line4Line4Line4Line4Line4"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual("Santa Ana, CA 51000", FastDriver.TexasDisclosure.BorrowerCSZValue.FAGetText().Clean(), "Verify if Borrower's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_852531_6

        [TestMethod]
        public void FMUC0137_REG0058()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Borrower Details under Transaction Information -> Delivery-> Borrower -> Business Entity";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Borrower screen.";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "BuyerName BuyerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Business Entity");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BusinessEntityShortname.FASetText("ShortNameBE");
                FastDriver.BuyerSellerSetup.BusinessEntityName.FASetText("NameOfEntityBE");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf. ";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s): label exist.";
                Support.AreEqual(true, pdfText.Contains("Borrower(s):"), "Verify if Borrower(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s) name value exist.";
                Support.AreEqual(true, pdfText.Contains("ShortNameBE"), "Verify if Borrower(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es): label exist.";
                Support.AreEqual(true, pdfText.Contains("Address(es):"), "Verify if  Borrower's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es) value exist.";
                Support.AreEqual(true, pdfText.Contains("Line1Line1Line1Line1Line1Line1Line1"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line2Line2Line2Line2Line2Line2Line2"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line3Line3Line3Line3Line3Line3Line3"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line4Line4Line4Line4Line4Line4Line4"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Santa Ana, CA 51000"), "Verify if Borrower's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_852849_7

        [TestMethod]
        public void FMUC0137_REG0059()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Borrower Details under Transaction Information -> Screen -> Borrower -> Trust/Estate";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Borrower screen.";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "BuyerName BuyerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Trust/Estate");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Trust/EstateTE");
                FastDriver.BuyerSellerSetup.TrusteeName.FASetText("NameOfEntityTE");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.Borrowers.Exists(), "Verify if Borrower(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s) name value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowersValue.Text.Contains("Trust/EstateTE"), "Verify if Borrower(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowerAddresses.Exists(), "Verify if  Borrower's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es) value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowerAddressesValue.FAGetText().Contains("Line1Line1Line1Line1Line1Line1Line1, " +
                    "Line2Line2Line2Line2Line2Line2Line2, Line3Line3Line3Line3Line3Line3Line3, Line4Line4Line4Line4Line4Line4Line4"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual("Santa Ana, CA 51000", FastDriver.TexasDisclosure.BorrowerCSZValue.FAGetText().Clean(), "Verify if Borrower's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion                

        #region TC_852858_8

        [TestMethod]
        public void FMUC0137_REG0060()
        {
            try
            {
                Reports.TestDescription = "TC_510584_8: Texas Dept of Insurance (TDI) - Section 1 Borrower Details under Transaction Information -> Delivery -> Borrower -> Trust/Estate";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Borrower screen.";
                FastDriver.BuyerSellerSummary.Open();
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "BuyerName BuyerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Trust/Estate");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.TrusteeShortName.FASetText("Trust/EstateTE");
                FastDriver.BuyerSellerSetup.TrusteeName.FASetText("NameOfEntityTE");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf. ";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s): label exist.";
                Support.AreEqual(true, pdfText.Contains("Borrower(s):"), "Verify if Borrower(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s) name value exist.";
                Support.AreEqual(true, pdfText.Contains("Trust/EstateTE"), "Verify if Borrower(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es): label exist.";
                Support.AreEqual(true, pdfText.Contains("Address(es):"), "Verify if  Borrower's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es) value exist.";
                Support.AreEqual(true, pdfText.Contains("Line1Line1Line1Line1Line1Line1Line1"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line2Line2Line2Line2Line2Line2Line2"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line3Line3Line3Line3Line3Line3Line3"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line4Line4Line4Line4Line4Line4Line4"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Santa Ana, CA 51000"), "Verify if Borrower's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_852867_9

        [TestMethod]
        public void FMUC0137_REG0061()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Borrower Details under Transaction Information -> Screen -> Borrower -> Multiple Borrowers";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Borrower screen.";
                FastDriver.BuyerSellerSummary.Open();

                Reports.TestStep = "Create multiple Borrowers.";

                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "BuyerName BuyerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("BorrowerName");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("BorrowerLastName");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                for (int i = 0; i <= 3; i++)
                {
                    FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                    FastDriver.BuyerSellerSummary.btnNew.FAClick();
                    FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("BorrowerName" + i.ToString());
                    FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("BorrowerLastName" + i.ToString());
                    FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Borrower" + i.ToString() + "Line1Line1Line1Line1Line1");
                    FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Borrower" + i.ToString() + "Line2Line2Line2Line2Line2");
                    FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Borrower" + i.ToString() + "Line3Line3Line3Line3Line3");
                    FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Borrower" + i.ToString() + "Line4Line4Line4Line4Line4");
                    FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                    FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                    FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                    FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                    FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                    FastDriver.BottomFrame.Done();
                    FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                }


                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf. ";
                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.Borrowers.Exists(), "Verify if Borrower(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s) name value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowersValue.Text.Contains("BorrowerName BorrowerLastName, BorrowerName0 BorrowerLastName0, BorrowerName1 BorrowerLastName1, "
                    + "BorrowerName2 BorrowerLastName2, BorrowerName3 BorrowerLastName3"), "Verify if Borrower(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es): label exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowerAddresses.Exists(), "Verify if  Borrower's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es) value exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.BorrowerAddressesValue.FAGetText().Contains("*Line1Line1Line1Line1Line1Line1Line1, " +
                    "Line2Line2Line2Line2Line2Line2Line2, Line3Line3Line3Line3Line3Line3Line3, Line4Line4Line4Line4Line4Line4Line4"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual("Santa Ana, CA 51000", FastDriver.TexasDisclosure.BorrowerCSZValue.FAGetText().Clean(), "Verify if Borrower's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_852868_10

        [TestMethod]
        public void FMUC0137_REG0062()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 1 Borrower Details under Transaction Information -> Delivery-> Borrower -> Multiple Borrowers";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Seller screen.";
                FastDriver.BuyerSellerSummary.Open();

                Reports.TestStep = "Go to Borrower screen.";
                FastDriver.BuyerSellerSummary.Open();

                Reports.TestStep = "Create multiple Borrowers.";

                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable(2, "BuyerName BuyerLastName", 2, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("BorrowerName");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("BorrowerLastName");
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Line1Line1Line1Line1Line1Line1Line1");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Line2Line2Line2Line2Line2Line2Line2");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Line3Line3Line3Line3Line3Line3Line3");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Line4Line4Line4Line4Line4Line4Line4");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                for (int i = 0; i <= 3; i++)
                {
                    FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                    FastDriver.BuyerSellerSummary.btnNew.FAClick();
                    FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("BorrowerName" + i.ToString());
                    FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("BorrowerLastName" + i.ToString());
                    FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText("Borrower" + i.ToString() + "Line1Line1Line1Line1Line1");
                    FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText("Borrower" + i.ToString() + "Line2Line2Line2Line2Line2");
                    FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText("Borrower" + i.ToString() + "Line3Line3Line3Line3Line3");
                    FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText("Borrower" + i.ToString() + "Line4Line4Line4Line4Line4");
                    FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                    FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                    FastDriver.BuyerSellerSetup.CurrentZip.FASetText("51000");
                    FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");
                    FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                    FastDriver.BottomFrame.Done();
                    FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                }


                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf. ";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s): label exist.";
                Support.AreEqual(true, pdfText.Contains("Seller(s):"), "Verify if Borrower(s): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if Borrower(s) name value exist.";
                Support.AreEqual(true, pdfText.Contains("BorrowerName BorrowerLastName, BorrowerName0"), "Verify if Borrower(s) name value exist.");
                Support.AreEqual(true, pdfText.Contains("BorrowerLastName0, BorrowerName1"), "Verify if Borrower(s) name value exist.");
                Support.AreEqual(true, pdfText.Contains("BorrowerLastName1, BorrowerName2"), "Verify if Borrower(s) name value exist.");
                Support.AreEqual(true, pdfText.Contains("BorrowerLastName2, BorrowerName3 \n \nBorrowerLastName3"), "Verify if Borrower(s) name value exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es): label exist.";
                Support.AreEqual(true, pdfText.Contains("Address(es):"), "Verify if  Borrower's Address(es): label exist.");

                Reports.TestStep = "In Transaction Information section (Section 1) verify if  Borrower's Address(es) value exist.";
                Support.AreEqual(true, pdfText.Contains("Line1Line1Line1Line1Line1Line1Line1"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line2Line2Line2Line2Line2Line2Line2"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line3Line3Line3Line3Line3Line3Line3"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Line4Line4Line4Line4Line4Line4Line4"), "Verify if Borrower's Address(es) value exist.");
                Support.AreEqual(true, pdfText.Contains("Santa Ana, CA 51000"), "Verify if Borrower's Address(es) value exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region US 612330: Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display Underwriter name

        #region TC_852873_1

        [TestMethod]
        public void FMUC0137_REG0063()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display Underwriter name -> Screen";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to File Homepage and select an Underwriter.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItemBySendingKeys("First American Outside UW - 2");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "In Section 3 expand Title Insurance Premiums";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();

                Reports.TestStep = "Verify if Underwriter label Exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.UnderWriter.Exists(), "Verify if Underwriter label Exist.");

                Reports.TestStep = "Verify if Underwriter value Exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.UnderWriterValue.Text.Contains("First American Outside UW - 2"), "Verify if Underwriter value Exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_856302_2

        [TestMethod]
        public void FMUC0137_REG0064()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display Underwriter name -> Delivery";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to File Homepage and select an Underwriter.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItemBySendingKeys("First American Outside UW - 2");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf. ";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "Verify if Underwriter: label Exist.";
                Support.AreEqual(true, pdfText.Contains("Underwriter:"), "Verify if Underwriter: label Exist.");

                Reports.TestStep = "Verify if Underwriter: value Exist.";
                Support.AreEqual(true, pdfText.Contains("First American Outside UW - 2"), "Verify if Underwriter: label Exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_856317_3

        [TestMethod]
        public void FMUC0137_REG0065()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display Underwriter name -> Delivery";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to File Homepage and select an Underwriter.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItemBySendingKeys("First American Outside UW - 2");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Verify that the Underwriter match with Underwriter in File Homepage.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                Playback.Wait(5000);
                Support.AreEqual(true, FastDriver.UnderwriterAgentDetailDlg.Underwriter.FAGetValue().ToString().Contains("First American Outside UW - 2"), "Verify that the Underwriter match with Underwriter in File Homepage.");

                Reports.TestStep = "Delete and enter a new Underwriter.";
                FastDriver.UnderwriterAgentDetailDlg.Underwriter.FASetText("UnverwriterTest");
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform a Preview delivery and check the pdf.";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "Verify if Underwriter: label Exist.";
                Support.AreEqual(true, pdfText.Contains("Underwriter:"), "Verify if Underwriter: label Exist.");

                Reports.TestStep = "Verify if Underwriter value Exist.";
                Support.AreEqual(true, pdfText.Contains("UnverwriterTest"), "Verify if Underwriter value Exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_857357_4

        [TestMethod]
        public void FMUC0137_REG0066()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display Underwriter name -> Underwriter/Agent Detail -> Screen";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to File Homepage and select an Underwriter.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.TitleOwningOfficeUndrwriter.FASelectItemBySendingKeys("First American Outside UW - 2");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Verify that the Underwriter match with Underwriter in File Homepage.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                Playback.Wait(5000);
                Support.AreEqual(true, FastDriver.UnderwriterAgentDetailDlg.Underwriter.FAGetValue().ToString().Contains("First American Outside UW - 2"), "Verify that the Underwriter match with Underwriter in File Homepage.");

                Reports.TestStep = "Delete and enter a new Underwriter.";
                FastDriver.UnderwriterAgentDetailDlg.Underwriter.FASetText("UnverwriterTest");
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "In Section 3 expand Title Insurance Premiums.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();

                Reports.TestStep = "Verify if Underwriter: label Exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.UnderWriter.Exists(), "Verify if Underwriter: label Exist.");

                Reports.TestStep = "Verify if Underwriter value Exist.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.UnderWriterValue.Text.Contains("UnverwriterTest"), "Verify if Underwriter value Exist.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region US 612978: Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display Underwriter and Title Agents amount/ Percentage

        #region TC_857396_1

        [TestMethod]
        public void FMUC0137_REG0067()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display Underwriter and Title Agents amount/ Percentage -> Screen.";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Edit Split% amount for Underwriter";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");

                Reports.TestStep = "Edit Split% amount for Title Agent 1 ";
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("60");
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.Underwriter.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Go to Title Insurance Premium section and expand it.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad();

                Reports.TestStep = "Make sure that Underwriter split amount or split % from Underwriter/Agent detail dialog  shall be displayed.";
                //var underwriterAmount = FastDriver.TexasDisclosure.UnderwriteSplitAmountValue.FAGetValue().ToString();
                Support.AreEqual(true, FastDriver.TexasDisclosure.UnderwriteSplitAmountValue.Text.Contains("$64.00"), "Make sure that Underwriter split amount or split % from Underwriter/Agent detail dialog  shall be displayed.");
                //var underWriterPercent = FastDriver.TexasDisclosure.UnderwriteSplitAmountPercentValue.FAGetValue().ToString();
                Support.AreEqual(true, FastDriver.TexasDisclosure.UnderwriteSplitAmountPercentValue.Text.Contains("40%"), "Make sure that Underwriter split amount or split % from Underwriter/Agent detail dialog  shall be displayed.");

                Reports.TestStep = "Make sure that  Title Agent split amount or split % from Underwriter/Agent detail dialog  shall be displayed.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent1SplitAmountValue.Text.Contains("$96.00"), "Make sure that  Title Agent split amount or split % from Underwriter/Agent detail dialog  shall be displayed.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent1SplitAmountPercentValue.Text.Contains("60%"), "Make sure that  Title Agent split amount or split % from Underwriter/Agent detail dialog  shall be displayed.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860355_2

        [TestMethod]
        public void FMUC0137_REG0068()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display Underwriter and Title Agents amount/ Percentage -> Delivery.";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Edit Split% amount for Underwriter";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");

                Reports.TestStep = "Edit Split% amount for Title Agent 1 ";
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("60");
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.Underwriter.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Preview delivery.";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "Make sure that Underwriter split amount or split % from Underwriter/Agent detail dialog  shall be displayed.";
                //var underwriterAmount = FastDriver.TexasDisclosure.UnderwriteSplitAmountValue.FAGetValue().ToString();
                Support.AreEqual(true, pdfText.Contains("$64.00"), "Make sure that Underwriter split amount or split % from Underwriter/Agent detail dialog  shall be displayed.");
                //var underWriterPercent = FastDriver.TexasDisclosure.UnderwriteSplitAmountPercentValue.FAGetValue().ToString();
                Support.AreEqual(true, pdfText.Contains("40%"), "Make sure that Underwriter split amount or split % from Underwriter/Agent detail dialog  shall be displayed.");

                Reports.TestStep = "Make sure that  Title Agent split amount or split % from Underwriter/Agent detail dialog  shall be displayed.";
                Support.AreEqual(true, pdfText.Contains("$96.00"), "Make sure that  Title Agent split amount or split % from Underwriter/Agent detail dialog  shall be displayed.");
                Support.AreEqual(true, pdfText.Contains("60%"), "Make sure that  Title Agent split amount or split % from Underwriter/Agent detail dialog  shall be displayed.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region US 612983: Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display Other Parties (Title Agent 2 ) details in Title Insurance Premium

        #region TC_860598_1

        [TestMethod]
        public void FMUC0137_REG0069()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Screen -> Verify Table details.";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");

                Reports.TestStep = "Make sure that Calculate % of total Premium radio button for Title Agent 2 is checked.";
                //Support.AreEqual(true, FastDriver.UnderwriterAgentDetailDlg.Agent2TotalPremium.IsSelected(), "Make sure that Calculate % of total Premium radio button for Title Agent 2 is checked.");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Edit Split% amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitPercent.FASetText("10");

                Reports.TestStep = "Click on done button.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Go to Title Insurance Premium section and expand it.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad();

                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2OtherAgentAmount.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhom.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.OtherAgentService.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860603_2

        [TestMethod]
        public void FMUC0137_REG0070()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance(TDI) - Section 3 Title Premium Disclosure - Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium->Delivery->Verify Table details.";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");

                Reports.TestStep = "Make sure that Calculate % of total Premium radio button for Title Agent 2 is checked.";
                //Support.AreEqual(true, FastDriver.UnderwriterAgentDetailDlg.Agent2TotalPremium.IsSelected(), "Make sure that Calculate % of total Premium radio button for Title Agent 2 is checked.");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Edit Split% amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitPercent.FASetText("10");

                Reports.TestStep = "Click on done button.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Preview delivery.";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);


                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, pdfText.Contains("Amount ($ or %)"), "Verify that in this section exist a Table containing column- Amount ($ or %).");
                Support.AreEqual(true, pdfText.Contains("To Whom"), "Verify that in this section exist a Table containing column- To Whom.");
                Support.AreEqual(true, pdfText.Contains("For Services"), "Verify that in this section exist a Table containing column- For Services.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860611_3

        [TestMethod]
        public void FMUC0137_REG0071()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Screen -> Calculate % of total Premium";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");

                Reports.TestStep = "Make sure that Calculate % of total Premium radio button for Title Agent 2 is checked.";
                //Support.AreEqual(true, FastDriver.UnderwriterAgentDetailDlg.Agent2TotalPremium.IsSelected(), "Make sure that Calculate % of total Premium radio button for Title Agent 2 is checked.");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Edit Split% amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitPercent.FASetText("10");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Click on done button.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Go to Title Insurance Premium section and expand it.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad();

                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2OtherAgentAmount.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhom.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.OtherAgentService.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");

                Reports.TestStep = "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2OtherAgentAmountValue.Text.Contains("$16.00"), "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.");

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhomValue.Text.Contains("Title Agent 2 Test"), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry. ");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860612_4

        [TestMethod]
        public void FMUC0137_REG0072()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Delivery -> Calculate % of total Premium";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");

                Reports.TestStep = "Make sure that Calculate % of total Premium radio button for Title Agent 2 is checked.";
                //Support.AreEqual(true, FastDriver.UnderwriterAgentDetailDlg.Agent2TotalPremium.IsSelected(), "Make sure that Calculate % of total Premium radio button for Title Agent 2 is checked.");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Edit Split% amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitPercent.FASetText("10");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Click on done button.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Preview delivery.";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, pdfText.Contains("Amount ($ or %)"), "Verify that in this section exist a Table containing column- Amount ($ or %).");
                Support.AreEqual(true, pdfText.Contains("To Whom"), "Verify that in this section exist a Table containing column- To Whom.");
                Support.AreEqual(true, pdfText.Contains("For Services"), "Verify that in this section exist a Table containing column- For Services.");

                Reports.TestStep = "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("$16.00"), "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.");

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("Title Agent 2 Test"), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry. ");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860613_5

        [TestMethod]
        public void FMUC0137_REG0073()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Screen -> Calculate % of Net Premium.";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Check Calculate % of Net Premium radio button for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.Agent1NetPremium.FASetCheckbox(true);
                FastDriver.UnderwriterAgentDetailDlg.Agent2NetPremium.FASetCheckbox(true);


                Reports.TestStep = "Edit Split% amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("15");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Click on done button.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Go to Title Insurance Premium section and expand it.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad();

                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2OtherAgentAmount.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhom.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.OtherAgentService.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");

                Reports.TestStep = "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2OtherAgentAmountValue.Text.Contains("$68.00"), "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.");

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhomValue.Text.Contains("Title Agent 2 Test"), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry. ");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860614_6

        [TestMethod]
        public void FMUC0137_REG0074()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Delivery -> Calculate % of Net Premium.";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Check Calculate % of Net Premium radio button for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.Agent1NetPremium.FASetCheckbox(true);
                FastDriver.UnderwriterAgentDetailDlg.Agent2NetPremium.FASetCheckbox(true);


                Reports.TestStep = "Edit Split% amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("15");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Click on done button.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Preview delivery.";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, pdfText.Contains("Amount ($ or %)"), "Verify that in this section exist a Table containing column- Amount ($ or %).");
                Support.AreEqual(true, pdfText.Contains("To Whom"), "Verify that in this section exist a Table containing column- To Whom.");
                Support.AreEqual(true, pdfText.Contains("For Services"), "Verify that in this section exist a Table containing column- For Services.");

                Reports.TestStep = "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("$68.00"), "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.");

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("Title Agent 2 Test"), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry. ");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860616_7

        [TestMethod]
        public void FMUC0137_REG0075()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Screen -> Edit $";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Check Calculate $ of Net Premium radio button for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.Agent2EditAmt.FASetCheckbox(true);


                Reports.TestStep = "Edit Split$ amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitAmt.FASetText("16");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Click on done button.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Go to Title Insurance Premium section and expand it.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad();

                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2OtherAgentAmount.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhom.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.OtherAgentService.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");

                Reports.TestStep = "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2OtherAgentAmountValue.Text.Contains("$16.00"), "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.");

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhomValue.Text.Contains("Title Agent 2 Test"), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry. ");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860617_8

        [TestMethod]
        public void FMUC0137_REG0076()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Delivery -> Edit $";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Check Calculate $ of Net Premium radio button for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.Agent2EditAmt.FASetCheckbox(true);


                Reports.TestStep = "Edit Split$ amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitAmt.FASetText("16");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Click on done button.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Preview delivery.";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, pdfText.Contains("Amount ($ or %)"), "Verify that in this section exist a Table containing column- Amount ($ or %).");
                Support.AreEqual(true, pdfText.Contains("To Whom"), "Verify that in this section exist a Table containing column- To Whom.");
                Support.AreEqual(true, pdfText.Contains("For Services"), "Verify that in this section exist a Table containing column- For Services.");

                Reports.TestStep = "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("$16.00"), "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.");

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("Title Agent 2 Test"), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry. ");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860622_9

        [TestMethod]
        public void FMUC0137_REG0077()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Screen -> Add One Services";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Check Calculate $ of Net Premium radio button for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.Agent2EditAmt.FASetCheckbox(true);


                Reports.TestStep = "Edit Split$ amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitAmt.FASetText("16");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);
                FastDriver.UnderwriterAgentDetailDlg.ServiceFTE.FASetCheckbox(true);
                //FastDriver.UnderwriterAgentDetailDlg.ServiceTE.FASetCheckbox(true);
                //FastDriver.UnderwriterAgentDetailDlg.ServiceCT.FASetCheckbox(true);

                Reports.TestStep = "Click on done button.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Go to Title Insurance Premium section and expand it.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad();

                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2OtherAgentAmount.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhom.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.OtherAgentService.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");

                Reports.TestStep = "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2OtherAgentAmountValue.Text.Contains("$16.00"), "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.");

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhomValue.Text.Contains("Title Agent 2 Test"), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry. ");

                Reports.TestStep = "Verify in For Services column is displaying the same Services as checked before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.OtherAgentServiceValue.Text.Contains("Furnishing Title Evidence"), "Verify in For Services column is displaying the same Services as checked before in Underwriter/Agent Detail from Fee Entry.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860623_10

        [TestMethod]
        public void FMUC0137_REG0078()
        {
            try
            {
                Reports.TestDescription = "TexasTexas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Delivery -> Add One Service";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Check Calculate $ of Net Premium radio button for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.Agent2EditAmt.FASetCheckbox(true);


                Reports.TestStep = "Edit Split$ amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitAmt.FASetText("16");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);
                FastDriver.UnderwriterAgentDetailDlg.ServiceFTE.FASetCheckbox(true);
                //FastDriver.UnderwriterAgentDetailDlg.ServiceTE.FASetCheckbox(true);
                //FastDriver.UnderwriterAgentDetailDlg.ServiceCT.FASetCheckbox(true);

                Reports.TestStep = "Click on done button.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Preview delivery.";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, pdfText.Contains("Amount ($ or %)"), "Verify that in this section exist a Table containing column- Amount ($ or %).");
                Support.AreEqual(true, pdfText.Contains("To Whom"), "Verify that in this section exist a Table containing column- To Whom.");
                Support.AreEqual(true, pdfText.Contains("For Services"), "Verify that in this section exist a Table containing column- For Services.");

                Reports.TestStep = "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("$16.00"), "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.");

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("Title Agent 2 Test"), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry. ");

                Reports.TestStep = "Verify in For Services column is displaying the same Services as checked before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("Furnishing Title Evidence"), "Verify in For Services column is displaying the same Services as checked before in Underwriter/Agent Detail from Fee Entry.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860625_11

        [TestMethod]
        public void FMUC0137_REG0079()
        {
            try
            {
                Reports.TestDescription = "TexasTexas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Delivery -> Add Two Service";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Check Calculate $ of Net Premium radio button for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.Agent2EditAmt.FASetCheckbox(true);


                Reports.TestStep = "Edit Split$ amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitAmt.FASetText("16");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);
                FastDriver.UnderwriterAgentDetailDlg.ServiceFTE.FASetCheckbox(true);
                FastDriver.UnderwriterAgentDetailDlg.ServiceTE.FASetCheckbox(true);
                //FastDriver.UnderwriterAgentDetailDlg.ServiceCT.FASetCheckbox(true);

                Reports.TestStep = "Click on done button.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Preview delivery.";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, pdfText.Contains("Amount ($ or %)"), "Verify that in this section exist a Table containing column- Amount ($ or %).");
                Support.AreEqual(true, pdfText.Contains("To Whom"), "Verify that in this section exist a Table containing column- To Whom.");
                Support.AreEqual(true, pdfText.Contains("For Services"), "Verify that in this section exist a Table containing column- For Services.");

                Reports.TestStep = "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("$16.00"), "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.");

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("Title Agent 2 Test"), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry. ");

                Reports.TestStep = "Verify in For Services column is displaying the same Services as checked before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("Furnishing Title Evidence,Title Examination"), "Verify in For Services column is displaying the same Services as checked before in Underwriter/Agent Detail from Fee Entry.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860627_12

        [TestMethod]
        public void FMUC0137_REG0080()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Screen -> Add Two Services";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Check Calculate $ of Net Premium radio button for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.Agent2EditAmt.FASetCheckbox(true);


                Reports.TestStep = "Edit Split$ amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitAmt.FASetText("16");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);
                FastDriver.UnderwriterAgentDetailDlg.ServiceFTE.FASetCheckbox(true);
                FastDriver.UnderwriterAgentDetailDlg.ServiceTE.FASetCheckbox(true);
                //FastDriver.UnderwriterAgentDetailDlg.ServiceCT.FASetCheckbox(true);

                Reports.TestStep = "Click on done button.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Go to Title Insurance Premium section and expand it.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad();

                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2OtherAgentAmount.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhom.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.OtherAgentService.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");

                Reports.TestStep = "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2OtherAgentAmountValue.Text.Contains("$16.00"), "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.");

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhomValue.Text.Contains("Title Agent 2 Test"), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry. ");

                Reports.TestStep = "Verify in For Services column is displaying the same Services as checked before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.OtherAgentServiceValue.Text.Contains("Furnishing Title Evidence,Title Examination"), "Verify in For Services column is displaying the same Services as checked before in Underwriter/Agent Detail from Fee Entry.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860634_13

        [TestMethod]
        public void FMUC0137_REG0081()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Screen -> Add Three Services";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Check Calculate $ of Net Premium radio button for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.Agent2EditAmt.FASetCheckbox(true);


                Reports.TestStep = "Edit Split$ amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitAmt.FASetText("16");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);
                FastDriver.UnderwriterAgentDetailDlg.ServiceFTE.FASetCheckbox(true);
                FastDriver.UnderwriterAgentDetailDlg.ServiceTE.FASetCheckbox(true);
                FastDriver.UnderwriterAgentDetailDlg.ServiceCT.FASetCheckbox(true);

                Reports.TestStep = "Click on done button.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Go to Title Insurance Premium section and expand it.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad();

                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2OtherAgentAmount.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhom.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");
                Support.AreEqual(true, FastDriver.TexasDisclosure.OtherAgentService.Exists(), "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.");

                Reports.TestStep = "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2OtherAgentAmountValue.Text.Contains("$16.00"), "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.");

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhomValue.Text.Contains("Title Agent 2 Test"), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry. ");

                Reports.TestStep = "Verify in For Services column is displaying the same Services as checked before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.OtherAgentServiceValue.Text.Contains("Furnishing Title Evidence,Title Examination,Closing Transaction"), "Verify in For Services column is displaying the same Services as checked before in Underwriter/Agent Detail from Fee Entry.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_860637_14

        [TestMethod]
        public void FMUC0137_REG0082()
        {
            try
            {
                Reports.TestDescription = "TexasTexas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Delivery -> Add Three Service";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "Enter a name in Title Agent 2 Input.";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASetText("Title Agent 2 Test");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Check Calculate $ of Net Premium radio button for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.Agent2EditAmt.FASetCheckbox(true);


                Reports.TestStep = "Edit Split$ amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitAmt.FASetText("16");
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);
                FastDriver.UnderwriterAgentDetailDlg.ServiceFTE.FASetCheckbox(true);
                FastDriver.UnderwriterAgentDetailDlg.ServiceTE.FASetCheckbox(true);
                FastDriver.UnderwriterAgentDetailDlg.ServiceCT.FASetCheckbox(true);

                Reports.TestStep = "Click on done button.";
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Preview delivery.";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "Verify that in this section exist a Table containing three columns- Amount ($ or %),  To Whom and For Services.";
                Support.AreEqual(true, pdfText.Contains("Amount ($ or %)"), "Verify that in this section exist a Table containing column- Amount ($ or %).");
                Support.AreEqual(true, pdfText.Contains("To Whom"), "Verify that in this section exist a Table containing column- To Whom.");
                Support.AreEqual(true, pdfText.Contains("For Services"), "Verify that in this section exist a Table containing column- For Services.");

                Reports.TestStep = "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("$16.00"), "Verify in Amount($ or %) column is displaying the same amount as entered before in Underwriter/Agent Detail from Fee Entry.");

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("Title Agent 2 Test"), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry. ");

                Reports.TestStep = "Verify in For Services column is displaying the same Services as checked before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("Furnishing Title Evidence,Title Examination,Closing \nTransaction"), "Verify in For Services column is displaying the same Services as checked before in Underwriter/Agent Detail from Fee Entry.");


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_861191_15

        [TestMethod]
        public void FMUC0137_REG0083()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Screen -> Title Agent 2 name from GAB";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "In Title Agent To Click on ... button and search for a GAB";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2SelectButton.FAClick();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "245");

                Reports.TestStep = "Make sure that Calculate % of total Premium radio button for Title Agent 2 is checked.";
                //Support.AreEqual(true, FastDriver.UnderwriterAgentDetailDlg.Agent2TotalPremium.IsSelected(), "Make sure that Calculate % of total Premium radio button for Title Agent 2 is checked.");
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Edit Split% amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitPercent.FASetText("10");

                Reports.TestStep = "Click on done button.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Go to Title Insurance Premium section and expand it.";
                FastDriver.TexasDisclosure.TitleInsurancePremiums.FAClick();
                FastDriver.TexasDisclosure.WaitForScreenToLoad();

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, FastDriver.TexasDisclosure.TitleAgent2ToWhomValue.Text.Contains("Semmelman & Bertucci, Ltd."), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_861192_16

        [TestMethod]
        public void FMUC0137_REG0084()
        {
            try
            {
                Reports.TestDescription = "Texas Dept of Insurance (TDI) - Section 3 Title Premium Disclosure- Display  Other Parties (Title Agent 2 ) details in Title Insurance Premium -> Delivery -> Title Agent 2 name from GAB";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Fee Entry.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Enter some Fee Charges.";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 4, TableAction.SetText, "30");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"1999 Eagle Manufactured Home Jr. Lien Policy", 7, TableAction.SetText, "50");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 4, TableAction.SetText, "20");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, @"ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", 7, TableAction.SetText, "60");

                Reports.TestStep = "Click on Underwriter/Agent Detail button.";
                FastDriver.FileFees.CDUnderwriterAgentDetail.FAClick();
                Playback.Wait(5000);
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                Reports.TestStep = "In Title Agent To Click on ... button and search for a GAB";
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2SelectButton.FAClick();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "245");

                Reports.TestStep = "Make sure that Calculate % of total Premium radio button for Title Agent 2 is checked.";
                //Support.AreEqual(true, FastDriver.UnderwriterAgentDetailDlg.Agent2TotalPremium.IsSelected(), "Make sure that Calculate % of total Premium radio button for Title Agent 2 is checked.");
                FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();
                FastDriver.UnderwriterAgentDetailDlg.TitleAgent2.FASendKeys(FAKeys.Tab);

                Reports.TestStep = "Edit Split% amount for Title Agent 2.";
                FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent.FASetText("40");
                FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent.FASetText("50");
                FastDriver.UnderwriterAgentDetailDlg.Agent2SplitPercent.FASetText("10");

                Reports.TestStep = "Click on done button.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Preview delivery.";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.";
                Support.AreEqual(true, pdfText.Contains("Semmelman & Bertucci, Ltd."), "Verify in To Whom column is displaying the same Name (Title Agent 2) as entered before in Underwriter/Agent Detail from Fee Entry.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region US 511325: PLACEHOLDER-Texas Dept of Insurance (TDI)- Section 7 Acknowledgements: Display the signature block section in TDI form

        #region TC_861232_1

        [TestMethod]
        public void FMUC0137_REG0085()
        {
            try
            {
                Reports.TestDescription = "PLACEHOLDER-Texas Dept of Insurance (TDI)- Section 7 Acknowledgements: Display the signature block section in TDI form -> Delivery -> Acknowledgements";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Preview delivery.";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "Verify that  the acknowledgement block section in TDI form is displayed.";

                var line1 = "The Closing Disclosure was assembled from the best information available from other sources. The Settlement";
                var line2 = "Agent cannot guarantee the accuracy of that information.";
                var line3 = "Tax and insurance prorations and reserves were based on figures for the preceding year or supplied by others, or";
                var line4 = "are estimates for current year. If there is any change for the current year, all necessary adjustments must be";
                var line5 = "made directly between Seller and Borrower, if applicable.";
                var line6 = "I (We) acknowledge receiving this Texas Disclosure and the Closing Disclosure. I (We) authorize the Settlement";
                var line7 = "Agent to make the expenditures and disbursements on the Closing Disclosure and I (we) approve those";
                var line8 = "payments. If I am (we are) the Borrower(s), I (we) acknowledge receiving the Loan Funds, if applicable, in the";
                var line9 = "amount on the Closing Disclosure";

                Support.AreEqual(true, pdfText.Contains(line1), "Verify that  the acknowledgement block section in TDI form is displayed.");
                Support.AreEqual(true, pdfText.Contains(line2), "Verify that  the acknowledgement block section in TDI form is displayed.");
                Support.AreEqual(true, pdfText.Contains(line3), "Verify that  the acknowledgement block section in TDI form is displayed.");
                Support.AreEqual(true, pdfText.Contains(line4), "Verify that  the acknowledgement block section in TDI form is displayed.");
                Support.AreEqual(true, pdfText.Contains(line5), "Verify that  the acknowledgement block section in TDI form is displayed.");
                Support.AreEqual(true, pdfText.Contains(line6), "Verify that  the acknowledgement block section in TDI form is displayed.");
                Support.AreEqual(true, pdfText.Contains(line7), "Verify that  the acknowledgement block section in TDI form is displayed.");
                Support.AreEqual(true, pdfText.Contains(line8), "Verify that  the acknowledgement block section in TDI form is displayed.");
                Support.AreEqual(true, pdfText.Contains(line9), "Verify that  the acknowledgement block section in TDI form is displayed.");


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TC_861234_2

        [TestMethod]
        public void FMUC0137_REG0086()
        {
            try
            {
                Reports.TestDescription = "PLACEHOLDER-Texas Dept of Insurance (TDI)- Section 7 Acknowledgements: Display the signature block section in TDI form -> Delivery -> Signatures";

                Reports.TestStep = "Log into Fast";
                FAST_Login_IIS();

                Reports.TestStep = "Change to QA SANDPOINTE REGION";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");

                Reports.TestStep = "Create a File with Owning Office and Property address are Texas.";
                CreateBasicTDI_File();

                Reports.TestStep = "Go to Texas disclosure screen.";
                FastDriver.TexasDisclosure.Open();

                Reports.TestStep = "Perform Preview delivery.";

                #region Preview

                Reports.TestStep = "Perform Preview Delivery method.";
                FastDriver.TexasDisclosure.DeliveryMethod.FASelectItem("Preview");
                FastDriver.TexasDisclosure.DeliveryButton.FAClick();
                #endregion

                var TempPDFFile = @"C:\Temp\Test_Docs" + Support.RandomString("NA") + "_.PDF";
                Playback.Wait(3000);
                Support.SavePDF(TempPDFFile);

                TexasDisclosurePDF.Maximize();

                Playback.Wait(3000);

                var reader = new PdfReader(TempPDFFile);

                var page = PdfTextExtractor.GetTextFromPage(reader, 2);

                //var pdfText = Support.ReadPdfFile(PDFFileWithPath: TempPDFFile);

                Reports.TestStep = "Verify that  the acknowledgement block section in TDI form is displayed.";

                var borrowerSignature = "\nBorrower: BuyerName BuyerLastName";
                var sellerSignature = "Seller: SellerName SellerLastName";
                var settlementAgent = "Settlement Agent:";
                var by = "First American Title Insurance Company";
                var officer = "Escrow Officer";

                Support.AreEqual(true, page.Contains(borrowerSignature), "Verfiy Borrowers signatures");
                Support.AreEqual(true, page.Contains(sellerSignature), "Verfiy Sellers signatures.");
                Support.AreEqual(true, page.Contains(settlementAgent), "Verfiy Settlement Agent signatures");
                Support.AreEqual(true, page.Contains(by), "Verfiy Settlement Agent signatures");
                Support.AreEqual(true, page.Contains(officer), "Verfiy Settlement Agent signatures");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

        #region Private Methods
        private void CreateBasicTDI_File()
        {
            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.File.Services[0].OfficeInfo.RegionID = 189;
            customizableFileRequest.File.Services[0].OfficeInfo.BUID = 1863;
            customizableFileRequest.File.Services[1].OfficeInfo.RegionID = 189;
            customizableFileRequest.File.Services[1].OfficeInfo.BUID = 1863;
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = 1128;
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "TX",  
                            City = "Houston", 
                            County = "Harris", 
                            Country = "USA",
                            Zip = "77777",
                            AddrLine1 = "123 Testing",
                            AddrLine2 = "tdi",
                            AddrLine3 = "tdi"
                        } 
                    },
                   
                } 
            };

            var TDI_File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(TDI_File.FileNumber);
        }

        private void CreateTDIFile()
        {
            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.File.Services[0].OfficeInfo.RegionID = 189;
            customizableFileRequest.File.Services[0].OfficeInfo.BUID = 1863;
            customizableFileRequest.File.Services[1].OfficeInfo.RegionID = 189;
            customizableFileRequest.File.Services[1].OfficeInfo.BUID = 1863;
            customizableFileRequest.File.BusinessParties[0].AddrBookEntryID = 1128;
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property()
                {
            
                    PropertyAddress = new PhysicalAddress[]
                    {
                                new PhysicalAddress()
                                {
                                    State = "TX",
                                    City = "Houston",
                                    County = "Harris",
                                    Country = "USA",
                                    Zip = "77777",
                                    AddrLine1 = "Test St",
                                    AddrLine2 = "Test St",
                                    AddrLine3 = "Test St"
                                }
                    },     
                }
            };

            var TDI_File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(TDI_File.FileNumber);
        }

        private void NEW_TDI_FILE()
        {
            #region Create a file for TEXAS DISCLOSURE
            Reports.TestStep = "Create a TDI File";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
            FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("1128");
            FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
            FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
            FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
            FastDriver.QuickFileEntry.FormType_CD.FAClick();
            FastDriver.QuickFileEntry.EscrowOwningOffice.FASelectItem("TEXAS OWNING OFFICE PR: QAREGION Off: 213 (1863)");
            FastDriver.QuickFileEntry.TermsDatesSalesPrice.Clear();
            FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("600000.00");
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("10000");
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("Test St 1");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("Test St 2");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("Test St 3");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("Houston");
            FastDriver.QuickFileEntry.SelectState("TX");
            FastDriver.QuickFileEntry.PropertyZip.FASetText("77777");
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("Harris");
            FastDriver.QuickFileEntry.SwitchToBottomFrame();
            FastDriver.BottomFrame.Done();
            Playback.Wait(5000);
            FastDriver.FileHomepage.WaitForScreenToLoad();
            #endregion
        }

        private void Enter_Closing_Information()
        {

            FastDriver.ClosingDisclosure.Open();
            FastDriver.ClosingDisclosure.SwitchToContentFrame();
            FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
            FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
            FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Now.ToString("M-d-yyyy"));
            FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText(DateTime.Now.ToString("M-d-yyyy"));
            FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText(DateTime.Now.ToString("M-d-yyyy"));
            FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
            FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItem("Imagedoc");
            FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
            FastDriver.ImageDocDlg.WaitForScreenToLoad();
            FastDriver.ImageDocDlg.ImageDoc.FAClick();
            Playback.Wait(5000);
        }

        public void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);

            }
        }

        private bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }
        #endregion
    }
}

