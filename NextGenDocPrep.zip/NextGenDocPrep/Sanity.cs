﻿using FASTSelenium.Common;
using FASTSelenium.ImageRecognition;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Input;

namespace NextGenDocPrep
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class Sanity : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        private static FASTWCFHelpers.FastFileService.OrderDetailsResponse _file;
        private int fileID;

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }
        
        private void WaitForDeliveryWindow(FADeliveryMethod method, int timeout, bool toExist = false, bool switchBackToWindow = true)
        {
            try
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.Delivery.GetDeliveryWindowTitle(method), toExist, timeout, switchBackToWindow);
            }
            catch 
            { 
                FastDriver.WebDriver.ClosePreviewWindow(); 
            }
        }
        
        #region UploadImage Service
        private OperationResponse UploadImage(int fileID, string docName, string docType, int docTypeID, string imageFileName)
        {
            OperationResponse response = null;

            byte[] bytes = System.IO.File.ReadAllBytes(imageFileName);

            try
            {
                var request = RequestFactory.GetUploadImageDefaultRequest(fileID, docName, docType, docTypeID, bytes);
                response = FASTWCFHelpers.FileService.UploadImage(request);

                Reports.StatusUpdate("UploadImage", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UploadImage", false, ex.Message);
            }

            return response;
        }
        #endregion

        #region CreateBasicFileMethod
        private int CreateBasicFileWithFileID()
        {

            var nextGenRequest = GetNextGenWCFFileRequest();
            Reports.TestStep = "Create File using web service.";
            fileID = FastDriver.FACreateFileGetFileId(nextGenRequest);
            _file = FileService.GetOrderDetails(fileID);

            Reports.TestStep = "Search File";
            FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
           
            return fileID;
        }
        #endregion
                       
        [TestMethod]
        public void SAN_NEXTGEN_01_CreateDocument()
        {
            try
            {
                Reports.TestDescription = "Create a Document in NextGen Document Repository";

                // Pre-Condition
                if(FASTHelpers.VerifyTemplates(0, 13, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "5", "FAMOS") == -1)
                {
                    FASTHelpers.CreateNewTemplate("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                }

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for a Escrow Instruction type template using template search criteria
                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                #endregion

                #region Select the template from Template Results , Right click and select Create Document
                // Perform Right Click on a table row using Document Name 
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Verify Created Document in File Documents Table grid
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Document exists on the Search Result Table");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void SAN_NEXTGEN_02_Upload_Document()
        {
            try
            {
                Reports.TestDescription = "Verify Upload Document";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Upload button
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();
                #endregion

                #region Browse document
                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);
                #endregion

                #region Save the PDF Document
                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is uploaded to the FAST
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        [DeploymentItem(@"Common\Support\RemoveDLLs32bit.bat")]
        [DeploymentItem(@"Common\Support\RemoveDLLs64bit.bat")]
        [DeploymentItem(@"ImageRecognition\Media\ImagingWorkbench\")]
        public void SAN_NEXTGEN_03_Scan_Document()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);

                Reports.TestDescription = "Verify Scan Document";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Scan button
                Reports.TestStep = "Click on Scan button";
                FastDriver.NextGenDocumentRepository.Scan.FAClick();
                if (FastDriver.WebDriver.WaitForAlertToExist(5))
                {
                    if (!(System.IO.File.Exists(Reports.DEPLOYDIR + "\\RemoveDLLs64bit.bat") || System.IO.File.Exists(Reports.DEPLOYDIR + "\\RemoveDLLs32bit.bat")))
                        throw new ImageBenchException("Image Bench is outdated (must delete older files)");
                    else
                        FastDriver.WebDriver.HandleDialogMessage(true, true);
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Click on Open button and load the image document
                Reports.TestStep = "Click on Open button and load the image document";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                //FastDriver.ImagingWorkBench.IROpen.SubPlaneR1().SubPlaneR1().SubPlaneR2().FAClick();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)
                #endregion

                #region Save the TIF Document
                Reports.TestStep = "Save the TIF Document";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: CLosing Disclosure", "CD - From Lender - Corrected AFTER Closing", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is scanned to the FAST
                Reports.TestStep = "Verify that Document is scanned to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("AFFIX INV", "Escrow: Closing Disclosure");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
        public void SAN_NEXTGEN_04_Split_Document()
        {
            try
            {
                SetDisplayPDFinBrowser_ON();
                
                Reports.TestDescription = "Verify Split Document";               

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                CreateBasicFileWithFileID();

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                 // Upload Image using web service method
                string filePath = Reports.DEPLOYDIR + @"\CECONTRACT_4438673_LEG.pdf";
                UploadImage(fileID, "Miscellaneous", ".pdf", 49, filePath);

                // Need to remove below statement of code to reduce the sanity execution time.

                //#region Click on Upload button
                //Reports.TestStep = "Click on Upload button";
                //FastDriver.NextGenDocumentRepository.Upload.FAClick();
                //#endregion

                //#region Browse document
                //Reports.TestStep = "Browse document";

                //FastDriver.UploadDocumentDlg.UploadFile(filePath);
                //#endregion

                //#region Save the PDF Document
                //Reports.TestStep = "Save the PDF Document";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                //FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //#endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is uploaded to the FAST
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Split document
                Reports.TestStep = "Split document";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous", "Name", TableAction.Click);
                // TODO: need to refactor move to PO
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous", "#4", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgSplit").FAClick();
                FastDriver.SplitDocumentScreenDlg.WaitForDialogToLoad();
                FastDriver.SplitDocumentScreenDlg.PageRange.FASetText("2-3");
                FastDriver.SplitDocumentScreenDlg.Split.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.SplitDocumentScreenDlg.WaitForDialogToLoad();
                FastDriver.NextGenDocumentRepository.HandleAdobeReaderError();  // don't see this on my machine
                FastDriver.SplitDocumentScreenDlg.Save.FAClick();
                FastDriver.WebDriver.ClosePreviewWindow();
                FastDriver.DocumentNameDlg.WaitForDialogLoad1();
                FastDriver.DocumentNameDlg.DocName.FASetText("Split Check");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.SplitDocumentScreenDlg.WaitForDialogToLoad();
                FastDriver.SplitDocumentScreenDlg.Fax.FAClick();
                #endregion

                #region Perform fax delivery
                Reports.TestStep = "Perform fax delivery";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Fax", true, 10);
                FastDriver.FaxDlg.WaitForScreenToLoad();
                FastDriver.FaxDlg.SendFax();
                FastDriver.WebDriver.WaitForDeliveryWindow("Fax", 200);
                #endregion

                #region Perform email delivery
                Reports.TestStep = "Perform email delivery";
                FastDriver.SplitDocumentScreenDlg.WaitForDialogToLoad();
                FastDriver.SplitDocumentScreenDlg.Email.FAClick();
                FastDriver.EmailDlg.WaitForDialogToLoad1().SendEmail();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);
                #endregion

                #region Click Done
                Reports.TestStep = "Click Done";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to document Repository
                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify Created Split doc in the Document Repository Screen
                Reports.TestStep = "Verify Created Split doc in the Document Repository Screen";
                docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Split Check", "Miscellaneous");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally
            {
                SetDisplayPDFinBrowser_OFF();
            }

        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        [DeploymentItem(@"ImageRecognition\Media\ImagingWorkbench\")]
        public void SAN_NEXTGEN_05_Edit_Image()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);

                Reports.TestDescription = "Verify Edit Image Feature";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                CreateBasicFileWithFileID();

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion
                
                // Upload Image using web service method
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                UploadImage(fileID, "Miscellaneous", ".tif", 49, filePath);

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is scanned to the FAST
                Reports.TestStep = "Verify that Document is scanned to the FAST";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.EditImage.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
                #endregion

                #region Click on Edit image option to open ImageWorkbench
                Reports.TestStep = "Click on Edit image option to open ImageWorkbench";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickRotateRight();
                FastDriver.ImagingWorkBench.ClickInvertPage();
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)
                #endregion

                #region Save the Edited Image
                Reports.TestStep = "Save the Edited Image";
                FastDriver.SaveDocumentDlg.SaveEditImageUsingAutoIt();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);
                #endregion

                #region Navigate to document Repository
                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Edited Image is present in the File Documents
                Reports.TestStep = "Verify that Edited Image is present in the File Documents";
                int row = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous", "Name", TableAction.Click).CurrentRow;
                row = row + 2;
                FastDriver.NextGenDocumentRepository.VersionIcon.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(row, 7, TableAction.Click);  // TODO: use column Name if possible
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        public void SAN_NEXTGEN_06_ImportRecordedDocs()
        {
            try
            {
                Reports.TestDescription = "Verify import Recorded Documents";

                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Import Recorded docs button
                Reports.TestStep = "Click on Import Recorded docs button";
                FastDriver.NextGenDocumentRepository.ImportedRecordedDocs.FAClick();
                #endregion

                #region Enter Recorded documents information
                Reports.TestStep = "Enter Recorded documents information";
                FastDriver.RecordedDocsDlg.WaitForScreenToLoad();
                FastDriver.RecordedDocsDlg.EnterRecordingInformation();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Navigate to document Repository
                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify recorded document in the document repository
                Reports.TestStep = "Verify recorded document in the document repository";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Assessment Map-45.7", "Miscellaneous");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void SAN_NEXTGEN_07_Distribution_and_Delivery_Instructions()
        {
            try
            {
                Reports.TestDescription = "Verify Distribution and Delivery Instructions";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Distribution and Delivery Insructions button
                Reports.TestStep = "Click on Distribution and Delivery Insructions button";
                FastDriver.NextGenDocumentRepository.DeliveryInstructions.FAClick();
                #endregion

                #region Enter Delivery Instructions
                Reports.TestStep = "Enter Delivery Instructions";
                FastDriver.ViewDeliveryInstrucionsDlg.EnterDeliveryInstructions();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Navigate to document Repository
                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify Distribution and Delivery Instructions Imaged Document is created in the document repostiory
                Reports.TestStep = "Verify Distribution and Delivery Instructions Imaged Document is created in the document repostiory";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Distribution And Delivery Instructions", "Imaged Document");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void SAN_NEXTGEN_08_Remove_A_Document()
        {
            try
            {
                Reports.TestDescription = "Remove a Document in NextGen Document Repository";

                // Pre-Condition
                var templateID = FASTHelpers.VerifyTemplates(0, 13, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "5", "FAMOS");
                if (templateID == -1)
                {
                    CreateNewTemplate("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                }

                Reports.TestStep = "Open FAST file side and Create File using web service.";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");

                #region Create Document
                Reports.TestStep = "Create Document";
                CreateDoc(templateID, 5, "FAMOS");
                #endregion

                #region Verify Created Document in File Documents Table grid
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.Open();
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Select created document and remove from the document repository
                Reports.TestStep = "Select created document and remove from the document repository";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Remove.FAClick();
                FastDriver.NextGenDocumentRepository.TypeFilter.FAClick();
                FastDriver.NextGenDocumentRepository.RemovedItemsCheckBox.FAClick();
                FastDriver.NextGenDocumentRepository.OKTypeFilter.FAClick();
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verified Removed document present in the Search Result List
                Reports.TestStep = "Verified Removed document present in the Search Result List";
                var text = FastDriver.NextGenDocumentRepository.DocumentsTable.Text;
                Support.Match("NEXTGEN_SAN_EscrowInstruction_DoNotTouch.+Escrow Instruction", text);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void SAN_NEXTGEN_09_Add_Watermark()
        {
            try
            {
                Reports.TestDescription = "Verify Add WaterMark feature";
                
                // Pre-Condition
                var templateID = FASTHelpers.VerifyTemplates(0, 13, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "5", "FAMOS");
                if (templateID == -1)
                {
                    CreateNewTemplate("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                }   

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");
                
                CreateDoc(templateID, 5, "FAMOS");
                
                #region Verify Created Document in File Documents Table grid
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.Open();
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                // FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "SAN_NEXTGEN_09");

                #region Select the document Right-Click and select 'Add Watermark' option from context
                Reports.TestStep = "Select the document Right-Click and select 'Add Watermark' option from context";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.AddWatermark.FASelectContextMenuItem();
                #endregion

                #region Select Watermark Option 'Draft' and Click on Done Button
                Reports.TestStep = "Select Watermark Option 'Draft' and Click on Done Button";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.WaterMark_SelectWatermarkOption);
                FastDriver.NextGenDocumentRepository.WaterMark_SelectWatermarkOption.FASelectItemBySendingKeys("draft");
                FastDriver.NextGenDocumentRepository.WaterMark_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Perform Preview Delivery
                Reports.TestStep = "Perform Preview Delivery";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                //  Trick or Treat!
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverPreview.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 60);
                #endregion

                #region Verify Watermark on the preview document
                Reports.TestStep = "Verify Watermark on the preview document";
                WaitForDeliveryWindow(FADeliveryMethod.Preview, 300);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        public void SAN_NEXTGEN_10_Document_Deliveries()
        {
            try
            {
                Reports.TestDescription = "Verify Document Deliveries Print/Fax/Email/Preview and Imagedoc";

                var DocumentName = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                // Pre-Condition
                var templateID = FASTHelpers.VerifyTemplates(0, 13, DocumentName, "5", "FAMOS");
                if(templateID == -1)
                {
                    CreateNewTemplate("SAN-NEXTGEN100", DocumentName, "Escrow Instruction");
                }

                Reports.TestStep = "Open FAST file side and Create File using web service.";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");

                CreateDoc(templateID, 5, "FAMOS");              

                #region Verify Created Document in File Documents Table grid
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.Open();
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument(DocumentName, "Escrow Instruction");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Perform Print Delivery
                Reports.TestStep = "Perform Print Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", DocumentName, "Name", TableAction.GetCell).Element.FARightClick();
                //  Trick or Treat!
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverPrint.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 15);
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                WaitForDeliveryWindow(FADeliveryMethod.Print, 300);
                #endregion

                #region Perform Fax Delivery
                Reports.TestStep = "Perform Fax Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", DocumentName, "Name", TableAction.GetCell).Element.FARightClick();
                //  Trick or Treat!
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverFax.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Fax", true, 15);
                FastDriver.FaxDlg.WaitForScreenToLoad().SendFax();
                WaitForDeliveryWindow(FADeliveryMethod.Fax, 200);
                #endregion

                #region Perform Email Delivery
                Reports.TestStep = "Perform Email Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", DocumentName, "Name", TableAction.GetCell).Element.FARightClick();
                //  Trick or Treat!
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverEmail.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 15);
                FastDriver.EmailDlg.WaitForDialogToLoad().SendEmail();
                WaitForDeliveryWindow(FADeliveryMethod.Email, 200);
                #endregion

                #region Perform Preview Delivery
                Reports.TestStep = "Perform Preview Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", DocumentName, "Name", TableAction.GetCell).Element.FARightClick();
                //  Trick or Treat!
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverPreview.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30);
                WaitForDeliveryWindow(FADeliveryMethod.Preview, 300);
                #endregion

                #region Perform ImageDoc Delivery
                Reports.TestStep = "Perform ImageDoc Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", DocumentName, "Name", TableAction.GetCell).Element.FARightClick();
                //  Trick or Treat!
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 200);
                #endregion

                #region Navigate to Event/Tracking Log in FAST Nav
                Reports.TestStep = "Navigate to Event/Tracking Log in FAST Nav";
                FastDriver.EventTrackingLog.Open();
                #endregion

                #region Select Doc Delivery from the Event Category dropdown
                Reports.TestStep = "Select Doc Delivery from the Event Category dropdown";
                FastDriver.EventTrackingLog.EventCategory.FASelectItemBySendingKeys("doc delivery");
                Playback.Wait(1000);    // TODO: find a better way to check if table finishes loading. wait until .//option[@selected][text()='Doc Delivery']
                FastDriver.EventTrackingLog.WaitForWindowToLoad(); // create a WaitForTableToLoad(string eventCategory) method 
                #endregion

                #region Verifying Print Delivery
                Reports.TestStep = "Verifying Print Delivery";
                string printServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Print]", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", printServiceComment.Contains(File.FileNumber).ToString(), "Verify Print Service Comments contains 'File Number: " + File.FileNumber + "'");
                Support.AreEqual("True", printServiceComment.Contains(DocumentName).ToString(), "Verify Print Service Comments contains 'Documents: " + DocumentName + "'");
                Support.AreEqual("True", printServiceComment.Contains("Delivery Method: Print").ToString(), "Verify Print Service Comments contains 'Delivery Method: Print'");
                Support.Match("Delivery Status: Delivery (Successful|Queued)", printServiceComment, "Verify Print Service Comments contains 'Delivery Status: Delivery Successful'");
                #endregion

                #region Verifying Fax Delivery
                Reports.TestStep = "Verifying Fax Delivery";
                var faxNumber = String.Format("{0:1(###)###-####}", Convert.ToInt64(AutoConfig.DeliverFaxTo.Replace("-", "")));
                var faxServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Fax]", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", faxServiceComment.Contains(File.FileNumber).ToString(), "Verify Fax Service Comments contains 'File Number: " + File.FileNumber + "'");
                Support.AreEqual("True", faxServiceComment.Contains(DocumentName).ToString(), "Verify Fax Service Comments contains 'Documents: " + DocumentName + "'");
                Support.AreEqual("True", faxServiceComment.Contains("Delivery Method: Fax").ToString(), "Verify Fax Service Comments contains 'Delivery Method: Fax'");
                Support.AreEqual("True", faxServiceComment.Contains(faxNumber).ToString(), "Verify Fax Service Comments contains fax number: " + faxNumber);
                #endregion

                #region Verifying Email Delivery
                Reports.TestStep = "Verifying Email Delivery";
                var emailServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[E-mail]", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", emailServiceComment.Contains(File.FileNumber).ToString(), "Verify Email Service Comments contains 'File Number: " + File.FileNumber + "'");
                Support.AreEqual("True", emailServiceComment.Contains(DocumentName).ToString(), "Verify Email Service Comments contains 'Documents: " + DocumentName + "'");
                Support.AreEqual("True", emailServiceComment.Contains("Delivery Method: Email").ToString(), "Verify Email Service Comments contains 'Delivery Method: Email'");
                Support.AreEqual("True", emailServiceComment.Contains("Recipients: " + AutoConfig.DeliverEmailTo).ToString(), "Verify Email Service Comments contains 'Recipients: " + AutoConfig.DeliverEmailTo + "'");
                Support.Match("Delivery Status: Delivery (Successful|Queued)", emailServiceComment, "Verify Email Service Comments contains 'Delivery Status: Delivery Successful'");
                #endregion

                #region Verifying ImageDoc Delivery
                Reports.TestStep = "Verifying ImageDoc Delivery";
                var imageDocServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[ImageDoc]", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", imageDocServiceComment.Contains(File.FileNumber).ToString(), "Verify ImageDoc Service Comments contains 'File Number: " + File.FileNumber + "'");
                Support.AreEqual("True", imageDocServiceComment.Contains(DocumentName).ToString(), "Verify ImageDoc Service Comments contains 'Documents: " + DocumentName + "'");
                Support.AreEqual("True", imageDocServiceComment.Contains("Delivery Method: Image Doc").ToString(), "Verify ImageDoc Service Comments contains 'Delivery Method: Image Doc'");
                Support.Match("Delivery Status: Delivery (Successful|Queued)", imageDocServiceComment, "Verify ImageDoc Service Comments contains '" + DocumentName + " : ImageDoc Successful'");
                #endregion

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify Fax cover sheet
                Reports.TestStep = "Verify Fax cover sheet";
                var docStatus1 = FastDriver.NextGenDocumentRepository.WaitForDocument("Fax Cover Sheet", "Fax Cover Sheet");
                Support.IsTrue(true, "Fax Cover Sheet exists on the table = " + docStatus1.ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        public void SAN_NEXTGEN_11_Edit_Document()
        {
            try
            {
                Reports.TestDescription = "Verify Edit Document feature";

                var DocumentName = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                // Pre-Condition
                var templateID = FASTHelpers.VerifyTemplates(0, 13, DocumentName, "5", "FAMOS");
                if (templateID == -1)
                {
                    CreateNewTemplate("SAN-NEXTGEN100", DocumentName, "Escrow Instruction");
                }

                Reports.TestStep = "Open FAST file side and Create File using web service.";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");

                CreateDoc(templateID, 5, "FAMOS");   

                #region Verify Created Document in File Documents Table grid
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.Open();
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Select the document Right-Click and select "View/Edit" option from context
                Reports.TestStep = "Select the document Right-Click and select \"View/Edit\" option from context";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                #endregion

                #region Get value of data element
                Reports.TestStep = "Get value of data element";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.RefreshDocument);
                //var dataElement = FastDriver.NextGenDocumentRepository.DataElement("Buyer Contact: Name");
                var dataElement = FastDriver.NextGenDocumentRepository.DataElement("Buyer First Name");
                var priorValue = dataElement["Input"].FAGetText();
                #endregion

                #region Edit value of any data element and click on "Save" Button
                Reports.TestStep = "Edit value of any data element and click on \"Save\" Button";
                var editedBuyerFirstName = "Edited-Buyer-First-Name";
                dataElement["Input"].FASetText(editedBuyerFirstName);
                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                #endregion

                #region Perform Preview from DE screen
                Reports.TestStep = "Perform Preview from DE screen";
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItemBySendingKeys("preview");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30);     // wait for delivery window to appear
                WaitForDeliveryWindow(FADeliveryMethod.Preview, 300);   // wait for delivery window to disappear
                #endregion

                #region Save PDF file
                Reports.TestStep = "Save PDF file";
                string tempPdfFile = @"C:\Temp\temp.PDF";
                SavePDFFile(tempPdfFile);
                Playback.Wait(1000);
                #endregion

                #region Validate the PDF has 'Edited-Buyer-First-Name' in the document
                Reports.TestStep = "Validate the PDF has 'Edited-Buyer-First-Name' in the document";
                var pdfTextContent = Support.ReadPdfFile(tempPdfFile);
                Support.AreEqual("True", pdfTextContent.Contains(editedBuyerFirstName).ToString(), true);
                #endregion

                #region Close the Preview document
                Reports.TestStep = "Close the Preview document";
                FastDriver.WebDriver.ClosePreviewWindow();
                #endregion

                #region Click on "Refresh" icon of the data element
                Reports.TestStep = "Click on \"Refresh\" icon of the data element";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.RefreshDocument);
                FastDriver.NextGenDocumentRepository.RefreshDocument.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Verify data element's prior value is restored
                Reports.TestStep = "Verify data element's prior value is restored";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.RefreshDocument);
                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.RefreshDocument);
                dataElement = FastDriver.NextGenDocumentRepository.DataElement("Buyer First Name");
                Support.AreEqual(priorValue, dataElement["Input"].FAGetText().Trim(), "Data element's value");
                #endregion

                #region Document should be previewed as per previous state
                Reports.TestStep = "Document should be previewed as per previous state";
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItemBySendingKeys("preview");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30);     // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 300);   // wait for delivery window to disappear
                #endregion

                #region Save PDF file
                Reports.TestStep = "Save PDF file";
                tempPdfFile = @"C:\Temp\temp2.PDF";
                SavePDFFile(tempPdfFile);
                #endregion

                #region Validate the PDF doesn't have 'SAN_NEXTGEN_11' in the docuemnt
                Reports.TestStep = "Validate the PDF doesn't have 'SAN_NEXTGEN_11' in the docuemnt";
                Support.AreNotEqual("True", Support.ReadPdfFile(tempPdfFile).Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString(), "PDF doesn't contains NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion

                //#region Close the Preview document
                //Reports.TestStep = "Close the Preview document";
                //FastDriver.WebDriver.ClosePreviewWindow();
                //#endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        public void SAN_NEXTGEN_12_Create_Multiple_Documents()
        {
            try
            {
                Reports.TestDescription = "Verify Creating Muliple Documents";

                // Pre-Condition
                string DocumentName = "NEXTGEN_SAN_TitleReports_DoNotTouch";
                string DocumentName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                //LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                //LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");

                // Pre-Condition
                FASTHelpers.VerifyTemplates(0, 4, DocumentName, "5", "FAMOS");
                FASTHelpers.VerifyTemplates(0, 13, DocumentName1, "5", "FAMOS");


                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select Multiple templates (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "NEXTGEN_SAN_TitleReports_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Navigates to Search Results section of File Documents screen and created mulitple documents should be displayed in the list
                Reports.TestStep = "Navigates to Search Results section of File Documents screen and created mulitple documents should be displayed in the list";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                var documentTable = FastDriver.NextGenDocumentRepository.DocumentsTable.FAGetText();
                Support.AreEqual("True", documentTable.Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString(), "Document table contains NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                Support.AreEqual("True", documentTable.Contains("NEXTGEN_SAN_TitleReports_DoNotTouch").ToString(), "Document table contains NEXTGEN_SAN_TitleReports_DoNotTouch");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void SAN_NEXTGEN_13_AddPhrase_MiscPhraseAndTemplate()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Verify Ability to Add Phrase, Misc Pharse and Template in the document editor";
                // Pre-Condition
                var templateID = FASTHelpers.VerifyTemplates(0, 13, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "5", "FAMOS");
                if (templateID == -1)
                {
                    CreateNewTemplate("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                }

                Reports.TestStep = "Open FAST file side and Create File using web service.";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");
                
                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Create a File Document
                Reports.TestStep = "Create a File Document";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select the Document , Right-Click and select "View/Edit" option from the context
                Reports.TestStep = "Select the Document , Right-Click and select \"View/Edit\" option from the context";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateEditDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                #endregion

                #region Click on "Document View" Button in the Data Elements screen
                Reports.TestStep = "Click on \"Document View\" Button in the Data Elements screen";
                //FastDriver.NextGenDocumentRepository.DocumentEditor.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FADoubleClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region In the left pane of the Editor Right-Click on InsertPhrase Phrase marker Select Top/Bottom
                Reports.TestStep = "In the left pane of the Editor Right-Click on InsertPhrase Phrase marker Select Top/Bottom";
                FastDriver.DocumentEditor.InsertPhraseBelow(tplPhraseName: "NEXTGEN-SAN-EscrowPhrase-DoNotTouch", phraseDescription: "NextGen*");
                #endregion

                #region InsertPhrase Phrase marker Select Top/Bottom and select Misc.Phrase option
                Reports.TestStep = "InsertPhrase Phrase marker Select Top/Bottom and select Misc.Phrase option";
                FastDriver.DocumentEditor.InsertMiscPhrase();
                #endregion

                #region Insert phrases associated to template
                Reports.TestStep = "Insert phrases associated to template";
                FastDriver.DocumentEditor.InsertTemplate("Title Reports");
                #endregion

                FastDriver.DocumentEditor.SaveAndClose();

                #region Verify documents added in editor screen will also displayed in DE Screen
                Reports.TestStep = "Verify documents added in editor screen will also displayed in DE Screen";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string phraseDataElements = FastDriver.NextGenDocumentRepository.PhraseDataElementTable.FAGetText();
                Support.AreEqual("True", phraseDataElements.Contains("NEXTGEN-SAN-EscrowPhrase-DoNotTouch").ToString(), "Data Element screen contains NEXTGEN-SAN-EscrowPhrase-DoNotTouch");
                Support.AreEqual("True", phraseDataElements.Contains("Misc. Phrase").ToString(), "Data Element screen contains Misc. Phrase");
                //Support.AreEqual("True", phraseDataElements.Contains("Automation Phrase PLSDNT*****1").ToString(), "Data Element screen contains Automation Phrase PLSDNT*****1");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally
            {
                SetSilverlightClipboardPermission_NO();
            }
        }
        
        [TestMethod]
        public void SAN_NEXTGEN_14_Create_AssociateDocs_Package_Deliveries()
        {
            try
            {
                Reports.TestDescription = "Verify Creating Associate Docs Package and Deliveries";

                // Pre-Condition
                //LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");

                // Pre-Condition
                Reports.TestStep = "Open FAST file side and Create File using web service.";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");

                // Pre-Condition
                FASTHelpers.VerifyTemplates(0, 13, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "5", "FAMOS");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Create multiple documents in the Document Repository
                Reports.TestStep = "Create multiple documents in the Document Repository";
                for (int i = 1; i <= 2; i++)
                {
                    FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "NEXTGEN-SAN-14-0" + i.ToString());
                }
                #endregion

                #region On the Document Repository screen, highlight minimum of the documents that are to be included in the document package
                Reports.TestStep = "On the Document Repository screen, highlight minimum of the documents that are to be included in the document package";
                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                #endregion

                #region Right-Click on Highlighted documents and select "Add to Associate Package"
                Reports.TestStep = "Right-Click on Highlighted documents and select \"Add to Associate Package\"";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN-SAN-14-01", "Name", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Edit Name in the editable package name and selection radio button option
                Reports.TestStep = "Edit Name in the editable package name and selection radio button option";
                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.AssociatePackages.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("NEXTGEN-SAN-14-DocPackage");
                #endregion

                #region Click on Done Button
                Reports.TestStep = "Click on Done Button";
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();
                #endregion

                #region Click on "OK" button in the Alert Message box
                Reports.TestStep = "Click on \"OK\" button in the Alert Message box";
                FastDriver.WebDriver.HandleDialogMessage(true, true, 15);
                #endregion

                #region Click on "PACKAGES" link
                Reports.TestStep = "Click on \"PACKAGES\" link";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                // TODO: check if Packages tab is expanded. If not, expand it
                //                if (FastDriver.NextGenDocumentRepository.PackagesTree.IsDisplayed())    // expand Packages tab
                //                    FastDriver.NextGenDocumentRepository.Packages.FAClick();
                #endregion

                #region Select the package created in the above steps and verify the documents
                Reports.TestStep = "Select the package created in the above steps and verify the documents";
                var package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("NEXTGEN-SAN-14-DocPackage");
                var packageContent = package.GetAttribute("textContent");
                Support.AreEqual("True", packageContent.Contains("NEXTGEN-SAN-14-01").ToString(), "Package contains NEXTGEN-SAN-14-01");
                Support.AreEqual("True", packageContent.Contains("NEXTGEN-SAN-14-02").ToString(), "Package contains NEXTGEN-SAN-14-02");
                package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("NEXTGEN-SAN-14-DocPackage", true);
                #endregion

                //Reports.TestStep = "Right-Click on the Package and select Print Delivery option from the context window";
                //Reports.TestStep = "Perform the above step for all the delivery methods \"Fax,Email,Preview and Imagedoc\"";

                #region Perform Fax Delivery
                Reports.TestStep = "Perform Fax Delivery";
                package.FARightClick();
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Deliver.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverFax);
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverPrint.FAMoveToElement();
                var fax = FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverFax;
                var faxActions = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).MoveToElement(fax);
                faxActions.Click().Perform();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Fax", true, 15);
                FastDriver.FaxDlg.WaitForScreenToLoad().SendFax();
                WaitForDeliveryWindow(FADeliveryMethod.Fax, 200);
                #endregion

                #region Perform Email Delivery
                Reports.TestStep = "Perform Email Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                package.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Deliver);
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Deliver.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverEMail);
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverPrint.FAMoveToElement();
                var email = FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverEMail;
                var emailActions = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).MoveToElement(email);
                emailActions.Click().Perform();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 15);
                FastDriver.EmailDlg.WaitForDialogToLoad().SendEmail();
                WaitForDeliveryWindow(FADeliveryMethod.Email, 200);
                #endregion

                #region Perform ImageDoc Delivery
                Reports.TestStep = "Perform ImageDoc Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                package.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Deliver);
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Deliver.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverImageDoc);
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverPrint.FAMoveToElement();
                var imageDoc = FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverImageDoc;
                var imageDocActions = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).MoveToElement(imageDoc);
                imageDocActions.Click().Perform();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 200);
                #endregion

                #region Perform Preview Delivery
                Reports.TestStep = "Perform Preview Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                package.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Deliver);
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Deliver.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverPreview);
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverPrint.FAMoveToElement();
                var preview = FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverPreview;
                var previewActions = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).MoveToElement(preview);
                previewActions.Click().Perform();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30);     // wait for delivery window to appear
                WaitForDeliveryWindow(FADeliveryMethod.Preview, 300);   // wait for delivery window to disappear
                #endregion

                #region Navigate to Event/Tracking Log in FAST Nav
                Reports.TestStep = "Navigate to Event/Tracking Log in FAST Nav";
                FastDriver.EventTrackingLog.Open();
                #endregion

                #region Select Doc Deivery from the Event Category dropdown
                Reports.TestStep = "Select Doc Deivery from the Event Category dropdown";
                FastDriver.EventTrackingLog.EventCategory.FASelectItemBySendingKeys("Doc Delivery");
                Playback.Wait(1000);    // TODO: find a better way to check if table finishes loading. wait until .//option[@selected][text()='Doc Delivery']
                #endregion

                #region Verify package delivery events in the Event Tracking log table list
                Reports.TestStep = "Verify package delivery events in the Event Tracking log table list";
                FastDriver.EventTrackingLog.WaitForWindowToLoad(); // create a WaitForTableToLoad(string eventCategory) method 
                #endregion

                #region Verifying Fax Delivery
                Reports.TestStep = "Verifying Fax Delivery";
                var faxServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "Fax Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", faxServiceComment.Contains("NEXTGEN-SAN-14-DocPackage").ToString(), "Verify Fax Service Comments contains document name: NEXTGEN-SAN-14-DocPackage");
                #endregion

                #region Verifying Email Delivery
                Reports.TestStep = "Verifying Email Delivery";
                var emailServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "Email Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", emailServiceComment.Contains("NEXTGEN-SAN-14-DocPackage").ToString(), "Verify Email Service Comments contains document name: NEXTGEN-SAN-14-DocPackage");
                #endregion

                #region Verifying ImageDoc Delivery
                Reports.TestStep = "Verifying ImageDoc Delivery";
                var imageDocServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "ImageDoc Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", imageDocServiceComment.Contains("NEXTGEN-SAN-14-DocPackage").ToString(), "Verify ImageDoc Service Comments contains document name: NEXTGEN-SAN-14-DocPackage");
                #endregion

                #region Verifying Print Preview Delivery
                Reports.TestStep = "Verifying Print Preview Delivery";
                var printServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "Print Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", printServiceComment.Contains("NEXTGEN-SAN-14-DocPackage").ToString(), "Verify Print Service Comments contains document name: NEXTGEN-SAN-14-DocPackage");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        public void SAN_NEXTGEN_15_Create_RTM_Package_Deliveries()
        {
            try
            {
                Reports.TestDescription = "Verify Creating RTM package and deliveries";

                // Pre-Condition
                //LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");

                // Pre-Condition
                Reports.TestStep = "Open FAST file side and Create File using web service.";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");

                // Pre-Condition
                FASTHelpers.VerifyTemplates(0, 13, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "5", "FAMOS");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Create multiple documents in the Document Repository
                Reports.TestStep = "Create multiple documents in the Document Repository";
                for (int i = 1; i <= 2; i++)
                {
                    FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "NEXTGEN-SAN-15-0" + i.ToString());
                }
                #endregion

                #region Create RTM Package
                Reports.TestStep = "Create RTM Package";
                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN-SAN-15-01", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.AddToRTMPackage.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.RTMPakageRadio.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Select Mail To address
                Reports.TestStep = "Select Mail To address";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.MailTo);
                FastDriver.NextGenDocumentRepository.MailTo.FAClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.SelectAddresses);
                FastDriver.NextGenDocumentRepository.SelectAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Select File Business Parties
                Reports.TestStep = "Select File Business Parties";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FileBusinessPartyTable.PerformTableAction(6, "Business Source", 1, TableAction.On);
                FastDriver.NextGenDocumentRepository.DoneSearchAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Select Return To address
                Reports.TestStep = "Select Return To address";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.ReturnTo);
                FastDriver.NextGenDocumentRepository.ReturnTo.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.OfficeSelection);
                FastDriver.NextGenDocumentRepository.OfficeSelection.FASelectItemByIndex(1);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Select Return To address
                Reports.TestStep = "Click on Packages link";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Packages.FASelectContextMenuItem(); // Send Enter key to the control
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.RTMPackageLink);
                #endregion

                #region Perform Fax delivery
                Reports.TestStep = "Perform Fax delivery";
                if (!FastDriver.NextGenDocumentRepository.FirstRTMPackage.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.FirstRTMPackage);
                }
                FastDriver.NextGenDocumentRepository.FirstRTMPackage.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DeliverRTM);
                FastDriver.NextGenDocumentRepository.DeliverRTM.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.FaxRTM);
                //FastDriver.NextGenDocumentRepository.PrintRTM.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.FaxRTM.JSClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Fax", true, 15);
                FastDriver.FaxDlg.WaitForScreenToLoad().SendFax();
                WaitForDeliveryWindow(FADeliveryMethod.Fax, 200);
                #endregion

                #region Perform Email Delivery
                Reports.TestStep = "Perform Email Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FirstRTMPackage.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DeliverRTM);
                FastDriver.NextGenDocumentRepository.DeliverRTM.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.EmailRTM);
                //FastDriver.NextGenDocumentRepository.PrintRTM.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.EmailRTM.JSClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 15);
                FastDriver.EmailDlg.WaitForDialogToLoad().SendEmail();
                WaitForDeliveryWindow(FADeliveryMethod.Email, 200);
                #endregion

                #region Perform ImageDoc Delivery
                Reports.TestStep = "Perform ImageDoc Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FirstRTMPackage.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DeliverRTM);
                FastDriver.NextGenDocumentRepository.DeliverRTM.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.ImageDocRTM);
                //FastDriver.NextGenDocumentRepository.PrintRTM.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.ImageDocRTM.JSClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 200);
                #endregion

                #region Perform Preview Delivery
                Reports.TestStep = "Perform Preview Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FirstRTMPackage.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DeliverRTM);
                FastDriver.NextGenDocumentRepository.DeliverRTM.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.PreviewRTM);
                //FastDriver.NextGenDocumentRepository.PrintRTM.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.PreviewRTM.JSClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30);     // wait for delivery window to appear
                WaitForDeliveryWindow(FADeliveryMethod.Preview, 300);
                #endregion

                #region Navigate to Event/Tracking Log in FAST Nav
                Reports.TestStep = "Navigate to Event/Tracking Log in FAST Nav";
                FastDriver.EventTrackingLog.Open();
                #endregion

                #region Select Doc Delivery from the Event Category dropdown
                Reports.TestStep = "Select Doc Delivery from the Event Category dropdown";
                FastDriver.EventTrackingLog.EventCategory.FASelectItemBySendingKeys("doc delivery");
                #endregion

                #region Verify package delivery events in the Event Tracking log table list
                Reports.TestStep = "Verify package delivery events in the Event Tracking log table list";
                FastDriver.EventTrackingLog.WaitForWindowToLoad();
                #endregion

                #region Verifying Fax Delivery
                Reports.TestStep = "Verifying Fax Delivery";
                var faxServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "Fax Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", faxServiceComment.Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString(), "Verify Fax Service Comments contains document name: NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion 

                #region Verifying Email Delivery
                Reports.TestStep = "Verifying Email Delivery";
                var emailServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "Email Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", emailServiceComment.Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString(), "Verify Email Service Comments contains document name: NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion

                #region Verifying ImageDoc Delivery
                Reports.TestStep = "Verifying ImageDoc Delivery";
                var imageDocServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "ImageDoc Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", imageDocServiceComment.Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString(), "Verify ImageDoc Service Comments contains document name: NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion

                #region Verifying Print Preview Delivery
                Reports.TestStep = "Verifying Print Preview Delivery";
                var printServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "Print Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", printServiceComment.Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString(), "Verify Print Service Comments contains document name: NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void SAN_NEXTGEN_16_Create_Commitment_Policy()
        {
            try
            {
                Reports.TestDescription = "Verify Create a Commitment , Lender/Owner Policy and associate endorsement/guarantee to policy and Verify Finalize and Unfinalize of Documents";

                // Pre-Condition
                if(FASTHelpers.VerifyTemplates(0, 4, "NEXTGEN_SAN_TitleReports_DoNotTouch", "5", "FAMOS") == -1)
                {
                    CreateNewTemplate("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                }
                if (FASTHelpers.VerifyTemplates(0, 6, "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "5", "FAMOS") == -1)
                {
                    CreateNewTemplate("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                }
                if (FASTHelpers.VerifyTemplates(0, 7, "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "5", "FAMOS") == -1)
                {
                    CreateNewTemplate("SAN-NEXTGEN500", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");
                }

                Reports.TestStep = "Open FAST file side and Create File using web service.";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Add new Lender with Liability";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FillNewLoanForm(new FASTSelenium.DataObjects.IIS.NewLoanParameters() { GABCode = "508", Amount = "1000000" });
                
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_TitleReports_DoNotTouch", "SAN_NEXTGEN_16_TitleReports");
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_LenderPolicy_DoNotTouch", "SAN_NEXTGEN_16_LenderPolicy");
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "SAN_NEXTGEN_16_EndorsementGuarantee");
             
                Reports.TestStep = "Select Policy document Right-Click and select \"view/edit\" option";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_16_LenderPolicy", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();

                Reports.TestStep = "Select an Effective Date";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.PolicyInfoSave);
                FastDriver.NextGenDocumentRepository.Policy_EffectiveDate.FASetText(DateTime.Now.AddWeekDays(-1).Date.ToString("MM/dd/yyyy"));
                FastDriver.NextGenDocumentRepository.Policy_IssueDate.FASetText(DateTime.Now.Date.ToString("MM/dd/yyyy"));

                Reports.TestStep = "When Auto Number is checked Click on Assign Policy Num";
                FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.FASetText(Support.RandomString("AAAAAANNNN"));

                Reports.TestStep = "Once the information has been modified, click Save (Alt+S).";
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                //
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.EstimattedSettlementDate.FASetText(DateTime.Now.Date.ToDateString());
                FastDriver.BottomFrame.Done();
                if (FastDriver.WebDriver.WaitForAlertToExist(5))
                {
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                FastDriver.ProrationDateChangedDlg.WaitForScreenToLoad().SelectAll.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                if (FastDriver.WebDriver.WaitForAlertToExist(5))
                {
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_16_LenderPolicy", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                //

                Reports.TestStep = "Select the Status \"Finalized\" from the status dropdown";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentStatus.FASelectItemBySendingKeys("Finalized");
                try
                {
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                }
                catch
                {
                    if (FastDriver.WebDriver.WaitForAlertToExist(5))
                    {
                        FastDriver.WebDriver.HandleDialogMessage();
                    }
                }

                Reports.TestStep = "Click Done";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.AssignPolicyNum);
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                if (FastDriver.WebDriver.WaitForAlertToExist(5))
                {
                    FastDriver.WebDriver.HandleDialogMessage();
                }

                Reports.TestStep = "Perform Fax Delivery";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_16_LenderPolicy", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.SearchResult_Deliver);
                FastDriver.NextGenDocumentRepository.SearchResult_Deliver.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverPrint.FAMoveToElement();
                var fax = FastDriver.NextGenDocumentRepository.SearchResult_DeliverFax;
                var faxActions = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).MoveToElement(fax);
                faxActions.Click().Perform();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Fax", true, 15);
                FastDriver.FaxDlg.WaitForScreenToLoad().SendFax();
                if (FastDriver.WebDriver.WaitForAlertToExist(5))
                {
                    Support.IsTrue(false, FastDriver.WebDriver.HandleDialogMessage());
                }
                else
                {
                    WaitForDeliveryWindow(FADeliveryMethod.Fax, 200);
                }

                Reports.TestStep = "Perform Email Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_16_LenderPolicy", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.SearchResult_Deliver);
                FastDriver.NextGenDocumentRepository.SearchResult_Deliver.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverPrint.FAMoveToElement();
                var email = FastDriver.NextGenDocumentRepository.SearchResult_DeliverEmail;
                var emailActions = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).MoveToElement(email);
                emailActions.Click().Perform();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 15);
                FastDriver.EmailDlg.WaitForDialogToLoad().SendEmail();
                if (FastDriver.WebDriver.WaitForAlertToExist(5))
                {
                    Support.IsTrue(false, FastDriver.WebDriver.HandleDialogMessage());
                }
                else
                {
                    WaitForDeliveryWindow(FADeliveryMethod.Email, 200);
                }

                Reports.TestStep = "Perform ImageDoc Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_16_LenderPolicy", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.SearchResult_Deliver);
                FastDriver.NextGenDocumentRepository.SearchResult_Deliver.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverPrint.FAMoveToElement();
                var imageDoc = FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc;
                var imageDocActions = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).MoveToElement(imageDoc);
                imageDocActions.Click().Perform();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                if (FastDriver.WebDriver.WaitForAlertToExist(5))
                {
                    Support.IsTrue(false, FastDriver.WebDriver.HandleDialogMessage());
                }
                else
                {
                    WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 200);
                }

                Reports.TestStep = "Perform Preview Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_16_LenderPolicy", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.SearchResult_Deliver);
                FastDriver.NextGenDocumentRepository.SearchResult_Deliver.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverPrint.FAMoveToElement();
                var preview = FastDriver.NextGenDocumentRepository.SearchResult_DeliverPreview;
                var previewActions = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).MoveToElement(preview);
                previewActions.Click().Perform();
                if (FastDriver.WebDriver.WaitForAlertToExist(5))
                {
                    Support.IsTrue(false, FastDriver.WebDriver.HandleDialogMessage());
                }
                else
                {
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30);     // wait for delivery window to appear
                    WaitForDeliveryWindow(FADeliveryMethod.Preview, 300);
                }

                Reports.TestStep = "Navigate to Event/Tracking Log in FAST Nav";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();

                Reports.TestStep = "Select Doc Deivery from the Event Category dropdown";
                FastDriver.EventTrackingLog.EventCategory.FASelectItemBySendingKeys("doc delivery");
                Playback.Wait(3000);    // TODO: find a better way to check if table finishes loading. wait until .//option[@selected][text()='Doc Delivery']
                FastDriver.EventTrackingLog.WaitForWindowToLoad(); // create a WaitForTableToLoad(string eventCategory) method 

                Reports.TestStep = "Verifying Fax Delivery";
                var faxServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "Fax Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", faxServiceComment.Contains("SAN_NEXTGEN_16_LenderPolicy").ToString(), "Verify Fax Service Comments contains document name: SAN_NEXTGEN_16_LenderPolicy");

                Reports.TestStep = "Verifying Email Delivery";
                var emailServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "Email Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", emailServiceComment.Contains("SAN_NEXTGEN_16_LenderPolicy").ToString(), "Verify Email Service Comments contains document name: SAN_NEXTGEN_16_LenderPolicy");

                Reports.TestStep = "Verifying ImageDoc Delivery";
                var imageDocServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "ImageDoc Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", imageDocServiceComment.Contains("SAN_NEXTGEN_16_LenderPolicy").ToString(), "Verify ImageDoc Service Comments contains document name: SAN_NEXTGEN_16_LenderPolicy");

                Reports.TestStep = "Verifying Print Preview Delivery";
                var printServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "Print Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", printServiceComment.Contains("SAN_NEXTGEN_16_LenderPolicy").ToString(), "Verify Print Service Comments contains document name: SAN_NEXTGEN_16_LenderPolicy");



            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        public void SAN_NEXTGEN_17A_StarterRef_NextGen_To_NextGen()
        {
            try
            {
                Reports.TestDescription = "Verify Starter/Ref Functionality NextGen to NextGen";

                // Pre-Condition
                if (FASTHelpers.VerifyTemplates(0, 4, "NEXTGEN_SAN_TitleReports_DoNotTouch", "5", "FAMOS") == -1)
                {
                    CreateNewTemplate("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                }

                #region Create 1st File (Next Gen) as previous
                Reports.TestStep = "Create 1st File (Next Gen) as previous";
                var nextGenRequest = GetNextGenWCFFileRequest();
                var response = FileService.CreateFile(nextGenRequest);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                var File = FileService.GetOrderDetails(response.FileID ?? 0);
                #endregion

                #region Create 2nd File (Next Gen) as previous
                Reports.TestStep = "Create 2nd File (Next Gen) as previous";
                var response2 = FileService.CreateFile(nextGenRequest);
                Support.AreEqual("1", response2.OperationResponse.Status.ToString(), response2.OperationResponse.StatusDescription);
                var File2 = FileService.GetOrderDetails(response2.FileID ?? 0);
                #endregion

                Reports.TestStep = "Login to FAST to open 1st File";
                FAST_Login_IIS(int.Parse(File.FileNumber), regionId: File.Services[0].OfficeInfo.RegionID);

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_TitleReports_DoNotTouch", "SAN_NEXTGEN_17A_TitleReports");

                #region Select Policy document Right-Click and select "view/edit" option
                Reports.TestStep = "Select Policy document Right-Click and select \"view/edit\" option";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_17A_TitleReports", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                #endregion

                #region Select an Effective Date
                Reports.TestStep = "Select an Effective Date";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocInfo_CopyFrom);
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText(DateTime.Now.Date.ToString("MM/dd/yyyy"));
                #endregion

                #region Click Save
                Reports.TestStep = "Click Save";
                FastDriver.NextGenDocumentRepository.DocInfo_Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Click Done
                Reports.TestStep = "Click Done";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocInfo_Done);
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                #endregion

                #region Create an image document
                Reports.TestStep = "Create an image document";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_17A_TitleReports", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Deliver.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverPrint.FAMoveToElement();
                var imageDoc = FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc;
                var imageDocActions = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).MoveToElement(imageDoc);
                imageDocActions.Click().Perform();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.WaitForScreenToLoad(FastDriver.ImageDocDlg.ImageDoc);
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);
                #endregion

                #region Load target file
                Reports.TestStep = "Load target file";
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);
                #endregion

                #region Navigate to Starter/Ref screen
                Reports.TestStep = "Navigate to Starter/Ref screen";
                FastDriver.StarterReference.Open();
                #endregion

                #region In the Nextgen Starter File Number field, enter the file number(Created in Pre-Condition)
                Reports.TestStep = "In the Nextgen Starter File Number field, enter the file number(Created in Pre-Condition)";
                FastDriver.StarterReference.StarterFileNumber.FASetText(File.FileNumber);
                #endregion

                #region Select the Copy Documents check box in the Select Document to Copy section
                Reports.TestStep = "Select the Copy Documents check box in the Select Document to Copy section";
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
                #endregion

                #region Select Multiple documents, including documents and any imaged documents
                Reports.TestStep = "Select Multiple documents, including documents and any imaged documents";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
                #endregion

                #region Click Done
                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                #endregion

                #region Click Copy Now or (Alt+C)
                Reports.TestStep = "Click Copy Now or (Alt+C)";
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                Playback.Wait(10000);
                #endregion

                //#region Navigate to Document Repository
                //Reports.TestStep = "Navigate to Document Repository";
                //FastDriver.NextGenDocumentRepository.Open();
                //#endregion

                #region Wait up to 5 min for document copy to complete
                Reports.TestStep = "Wait up to 5 min for document copy to complete";
                var copyDocumentStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("SAN_NEXTGEN_17A_TitleReports", "Imaged Document") ||
                    FastDriver.NextGenDocumentRepository.WaitForDocument("SAN_NEXTGEN_17A_TitleReports", "Title Reports");
                Support.IsTrue(copyDocumentStatus, "Document copied from Starter Ref file");
                #endregion

                #region Navigate to Event/Tracking Log
                Reports.TestStep = "Navigate to Event/Tracking Log";
                FastDriver.EventTrackingLog.Open();
                #endregion

                #region Verify Event Logs for Starter/Ref
                Reports.TestStep = "Verify Event Logs for Starter/Ref";
                var fileItemCopy = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Starter Ref File Item Copy Completed]", "Comments", TableAction.GetText).Message;
                Support.Match("\"" + File.FileNumber.ToString() + "\" to \"" + File2.FileNumber.ToString() + "\", request was submitted.", fileItemCopy, "Verify Starter Ref File Item Copy");
                var copyDocuments = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Starter Ref Copy Images Completed]"/*"[Starter Ref Copy Documents Completed]"*/, "Comments", TableAction.GetText).Message;
                //Support.Match("\"" + File.FileNumber.ToString() + "\" to \"" + File2.FileNumber.ToString() + "\" completed", copyDocuments, "Verify Starter Ref Copy Documents");
                Support.Match("Starter Ref Copy Image from " + File.FileNumber.ToString() + " to " + File2.FileNumber.ToString() + " completed", copyDocuments, "Verify Starter Ref Copy Documents");
                #endregion

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Right Click on a document and select "View/Edit"
                Reports.TestStep = "Right Click on a document and select \"View/Edit\"";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_17A_TitleReports", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Click Phrase View tab or Data Elements tab
                Reports.TestStep = "Click Phrase View tab or Data Elements tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.PhraseViewTab.Exists())
                {
                    FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                }
                else
                {
                    Reports.StatusUpdate("ATENTION: missing Data Elements tab", true);
                }
                #endregion

                if (FastDriver.NextGenDocumentRepository.DataElementsTab.Exists())
                {
                    //  Inconsistent across environments
                    FastDriver.NextGenDocumentRepository.DataElementsTab.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.AllElements);

                    #region Update Data element value and click on "Referesh Data Element" Icon
                    Reports.TestStep = "Update Data element value and click on \"Referesh Data Element\" Icon";
                    var dataElement = FastDriver.NextGenDocumentRepository.DataElement("Seller First Name");
                    var priorValue = dataElement["Input"].FAGetText();
                    dataElement["Input"].FASetText("SAN_NEXTGEN_17A");
                    dataElement["Refresh"].FAClick();
                    var dlgMsg = FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    #endregion

                    #region Verify that data element restores value
                    Reports.TestStep = "Verify that data element restores value";
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.AllElements);
                    dataElement = FastDriver.NextGenDocumentRepository.DataElement("Seller First Name");
                    Support.AreEqual(priorValue, dataElement["Input"].FAGetText(), "Data element value");
                    #endregion
                }
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        public void SAN_NEXTGEN_17B_StarterRef_Legacy_To_NextGen()
        {
            try
            {
                Reports.TestDescription = "Verify Starter/Ref Functionality Legacy to NextGen";

                // Pre-Condition
                if (FASTHelpers.VerifyTemplates(0, 13, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "5", "FAMOS") == -1)
                {
                    CreateNewTemplate("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                }

                #region Create 1st File (Legacy) as previous
                Reports.TestStep = "Create 1st File (Legacy) as previous";
                var legacyRequest = GetNextGenWCFFileRequest();
                legacyRequest.Source = "FAST";
                var response = FileService.CreateFile(legacyRequest);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                var File = FileService.GetOrderDetails(response.FileID ?? 0);
                #endregion

                #region Create 2nd File (Next Gen) as previous
                Reports.TestStep = "Create 2nd File (Next Gen) as previous";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.Source = "LVIS";
                var response2 = FileService.CreateFile(nextGenRequest);
                Support.AreEqual("1", response2.OperationResponse.Status.ToString(), response2.OperationResponse.StatusDescription);
                var File2 = FileService.GetOrderDetails(response2.FileID ?? 0);
                #endregion

                Reports.TestStep = "Login to FAST to open 1st File";
                FAST_Login_IIS(int.Parse(File.FileNumber), regionId: File.Services[0].OfficeInfo.RegionID);

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.DocumentRepository.Open();
                #endregion

                #region Click on Add Button
                Reports.TestStep = "Click on Add Button";
                FastDriver.DocumentRepository.Add.FAClick();
                #endregion

                #region Add Escrow Instruction Document
                Reports.TestStep = "Add Escrow Instruction Document";
                FastDriver.AdHocDocuments.SearchDocument("Both", "Escrow Instruction", "a*", "");
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Type", "Escrow Instruction", "Type", TableAction.Click);
                string EscrowInstructionDescription = FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction("Type", "Escrow Instruction", "Description", TableAction.GetText).Message.Trim();
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                #endregion

                #region Verify document added
                Reports.TestStep = "Verify document added";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForDocumentsScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, EscrowInstructionDescription, 4, TableAction.Click);
                #endregion

                #region Perform Image Doc Delivery
                Reports.TestStep = "Perform Image Doc Delivery";
                FastDriver.DocumentRepository.SelectDeliveryMethod("IMAGEDOC").ClickDeliver();
                #endregion

                #region Click on Imagedoc button
                Reports.TestStep = "Click on Imagedoc button";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.WaitForScreenToLoad(FastDriver.ImageDocDlg.ImageDoc);   // switch to FAFDialog_0_iframe
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);
                #endregion

                #region Load target file
                Reports.TestStep = "Load target file";
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);
                #endregion

                #region Navigate to Starter/Ref screen
                Reports.TestStep = "Navigate to Starter/Ref screen";
                FastDriver.LeftNavigation.Navigate<StarterReference>("Home>Order Entry>Starter/Ref.").WaitForScreenToLoad();
                #endregion

                #region In the Nextgen Starter File Number field, enter the file number(Created in Pre-Condition)
                Reports.TestStep = "In the Nextgen Starter File Number field, enter the file number(Created in Pre-Condition)";
                FastDriver.StarterReference.StarterFileNumber.FASetText(File.FileNumber);
                #endregion

                #region Select the Copy Documents check box in the Select Document to Copy section
                Reports.TestStep = "Select the Copy Documents check box in the Select Document to Copy section";
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
                Playback.Wait(3000);
                #endregion

                #region Select Multiple documents, including documents and any imaged documents
                Reports.TestStep = "Select Multiple documents, including documents and any imaged documents";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
                #endregion

                #region Click Done
                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                #endregion

                #region Click Copy Now or (Alt+C)
                Reports.TestStep = "Click Copy Now or (Alt+C)";
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                Playback.Wait(10000);
                #endregion

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that the document was copied (imaged)
                Reports.TestStep = "Verify that the document was copied (imaged)";
                var documentStatus = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EscrowInstructionDescription, "Status", TableAction.GetText).Message;
                Support.AreEqual("Imaged", documentStatus, "Document " + EscrowInstructionDescription + " failed to copy from Starter file " + File.FileNumber);
                #endregion

                #region Navigate to Event/Tracking Log
                Reports.TestStep = "Navigate to Event/Tracking Log";
                FastDriver.EventTrackingLog.Open();
                #endregion

                #region Verify Event Logs for Starter/Ref
                Reports.TestStep = "Verify Event Logs for Starter/Ref";
                var fileItemCopy = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Starter Ref File Item Copy Completed]", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", fileItemCopy.Contains("\"" + File.FileNumber.ToString() + "\" to \"" + File2.FileNumber.ToString() + "\", request was submitted.").ToString(), "Starter Ref File Item Copy");
                #endregion

                //var copyDocuments = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Starter Ref Copy Images Completed]", "Comments", TableAction.GetText).Message;
                //Support.AreEqual("True", copyDocuments.Contains("\"" + fileNumber.ToString() + "\" to \"" + targetFileNumber.ToString() + "\" completed").ToString(), "Starter Ref Copy Images");

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Right Click on a document and select "View/Edit"
                Reports.TestStep = "Right Click on a document and select \"View/Edit\"";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EscrowInstructionDescription, "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDetails);
                #endregion

                if (FastDriver.NextGenDocumentRepository.DocumentDetails.FAGetText().Contains("Image cannot be edited due to multiple references"))
                    Reports.StatusUpdate("Image Edit Status: Image cannot be edited due to multiple references", true);
                else
                {
                    #region Click Phrase View tab or Data Elements tab
                    Reports.TestStep = "Click Phrase View tab or Data Elements tab";
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    if (FastDriver.NextGenDocumentRepository.PhraseViewTab.Exists())
                        FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                    else
                        FastDriver.NextGenDocumentRepository.DataElementsTab.FAClick();
                    #endregion

                    #region Update Data element value and click on "Referesh Data Element" Icon
                    Reports.TestStep = "Update Data element value and click on \"Referesh Data Element\" Icon";
                    FastDriver.NextGenDocumentRepository.RefreshDocument.FAClick();
                    var dlgMsg = FastDriver.WebDriver.HandleDialogMessage();
                    #endregion

                    #region Verify that Phrase refresh is not allowed
                    Reports.TestStep = "Verify that Phrase refresh is not allowed";
                    Support.AreEqual("The document is copied from a Legacy file. Phrase refresh is not allowed.", dlgMsg, "Error Message");
                    #endregion
                }
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        public void SAN_NEXTGEN_18_Verify_SDN_Search_Results()
        {
            try
            {
                Reports.TestDescription = "Verify SDN Search Results";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFileWithNewLoan() || NextGen_FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Navigate to Buyers screen
                Reports.TestStep = "Navigate to Buyers screen";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true);
                #endregion

                #region Create a Buyer instance which is present in SDN Hit List
                Reports.TestStep = "Create a Buyer instance which is present in SDN Hit List";
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("bin");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("laden");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to SDN Tracking Summary screen
                Reports.TestStep = "Navigate to SDN Tracking Summary screen";
                FastDriver.SDNTrackingSummary.Open();
                #endregion

                for (int i = 1; i <= 10; i++)
                {
                    FastDriver.SDNTrackingSummary.Open();
                    FastDriver.SDNTrackingSummary.SwitchToContentFrame();
                    string hitNameTable = FastDriver.SDNTrackingSummary.SDNHitTable.FAGetText();

                    if (hitNameTable.Contains("bin laden") && i <= 10)
                    {
                        Support.AreEqual("bin laden", FastDriver.SDNTrackingSummary.SDNHitTable.PerformTableAction(2, "bin laden", 2, TableAction.GetText).Message);
                        break;
                    }
                    else if (!hitNameTable.Contains("bin laden") && i == 11)
                    {
                        Support.Fail("Hit name not found after 20 seconds");
                    }
                }

                #region Verify a document is generated in Doucment Repository for the SDN Hit List name
                Reports.TestStep = "Verify a document is generated in Doucment Repository for the SDN Hit List name";
                System.Threading.Thread.Sleep(10000); // Wait for document to appear
                FastDriver.NextGenDocumentRepository.Open();
                try
                {
                    Support.AreEqual("SDN Search Results - bin laden, " + DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.NextGenDocumentRepository.GetTextLabelFromTableCell(FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(9, "SDN Result", 6, TableAction.GetCell).Element), "SDN Search Document Name");
                }
                catch // Try again after wait 10 seconds
                {
                    System.Threading.Thread.Sleep(10000); // Wait for document to appear
                    FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
                    Support.AreEqual("SDN Search Results - bin laden, " + DateTime.Now.ToString("MM/dd/yyyy"), FastDriver.NextGenDocumentRepository.GetTextLabelFromTableCell(FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(9, "SDN Result", 6, TableAction.GetCell).Element), "SDN Search Document Name");
                }
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void SAN_NEXTGEN_19_Verify_Create_New_Template_ADM()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();
                //  
                string RandomGroupName = Support.RandomString("AAA");
                string RandomNamePhrasesProperties = Support.RandomString("AAA");
                string RandomtemplateName = Support.RandomString("AAAAAAA");

                Reports.TestDescription = "Create New Template DocGen ";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                //Pre-Condition: To Create a New Template we need to have a phrase to associate it with Create a phrase with at least one data element in it.

                #region Creating a New Phrase Group
                Reports.TestStep = "Creating a New Phrase";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.CreateNewPhrases.FAClick();
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(RandomGroupName);
                FastDriver.NextGenDocumentPreparation.Description.FASetText("SAN-NEXTGEN-19-PhraseGroup");
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Escrow Phrase[ESCROW]");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                #endregion

                #region Add New Phrase
                Reports.TestStep = "Add New Phrases";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrases().FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomNamePhrasesProperties);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("SAN-NEXTGEN-19-Phrase");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                #endregion

                #region Phrase View or Edit
                Reports.TestStep = "Phrase View or Edit";
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.IRDocumentInsertTemplate();
                //
                Reports.TestStep = "Select the 1st data element on the result table";
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItemBySendingKeys("Buyer");
                FastDriver.DataElementSelectionDlg.WaitCreation(FastDriver.DataElementSelectionDlg.SearchResult);
                FastDriver.DataElementSelectionDlg.GetSearchResult(0).FAClick();
                FastDriver.DataElementSelectionDlg.Select.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Creating a New Template
                Reports.TestStep = "Creating a New Template";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                Playback.Wait(6000); // WaitForReady()
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateType);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("SAN-NEXTGEN-19-Template");
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                #region Edit Template
                Reports.TestStep = "Edit Template";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                //
                Reports.TestStep = "In the left pane of the Editor Right-Click on InsertPhrase Phrase marker Select Top/Bottom ";
                var phraseName = RandomNamePhrasesProperties + "/" + RandomNamePhrasesProperties;
                FastDriver.DocumentEditor.InsertPhraseBelowAndSave(tplPhraseName: phraseName, phraseDescription: "SAN-NEXTGEN-19-Phrase");
                //
                Reports.TestStep = "Search for Template";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearchTab);
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FADoubleClick();
                Playback.Wait(9000);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("SAN-NEXTGEN-19-Template");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Verify Template exists on table";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateResultsTable);
                var templateName = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Name", RandomtemplateName, "Description", TableAction.GetText).Message.Trim();
                Support.AreEqual("SAN-NEXTGEN-19-Template", templateName, "SAN-NEXTGEN-19-Template exists on table");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally
            {
                SetSilverlightClipboardPermission_NO();
            }
        }

        [TestMethod]
        public void SAN_NEXTGEN_20_Create_Filtered_Template_ADM()
        {
            try
            {
                Reports.TestDescription = "Verify Creating a Filtered Template_ADM";

                // Pre-Condition
                if(FASTHelpers.VerifyTemplates(0, 4, "NEXTGEN_SAN_TitleReports_DoNotTouch", "5", "FAMOS") == -1)
                {
                    CreateNewTemplate("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                }

                FAST_Login_ADM(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to Document Preparation Screen
                Reports.TestStep = "Navigate to Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Click on Templates tab
                Reports.TestStep = "Click on Templates tab";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("NEXTGEN_SAN_TitleReports_DoNotTouch");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select View/Edit NEXTGEN_SAN_TitleReports_DoNotTouch template
                Reports.TestStep = "Select View/Edit NEXTGEN_SAN_TitleReports_DoNotTouch template";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateResultsTable);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
                #endregion

                #region Click on Filtering tab
                // Note: For Lender/Owner /Endorsement and policy w/o title report documents by default Required Filter will be present - do we need to verify this?
                Reports.TestStep = "Click on Filtering tab";
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Click on "*" Button to add Suggested Filter Type
                Reports.TestStep = "Click on \" * \" Button to add Suggested Filter Type";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddFilterGroup);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                #endregion

                #region Click on "Edit Filter" Icon
                Reports.TestStep = "Click on \"Edit Filter\" Icon";
                var EditFilter = FastDriver.NextGenDocumentPreparation.GetGroupEditFilter();    // last group
                EditFilter.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                #endregion

                #region Under the Geographic Filter In the state row click on "Add/Remove" button
                // Note: By default All values are selected under geographic filter - do we need to verify this?
                Reports.TestStep = "Under the Geographic Filter In the state row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("State Selection", true, 15);
                #endregion

                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                #endregion

                #region Set "CA" check box and click on "Select" button
                Reports.TestStep = "Set \"CA\" check box and click on \"Select\" button";
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", "CA", "Select", TableAction.On);
                FastDriver.StateSelectionDlg.Select.FAClick();
                #endregion

                #region Verify CA is displayed under Geographic filter
                Reports.TestStep = "Verify CA is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("CA", FastDriver.NextGenDocumentPreparation.GeographicFilterState.FAGetText().Trim(), "Geographic Filter State");
                #endregion

                #region In the county row click on "Add/Remove" button
                Reports.TestStep = "In the county row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.CountyAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("County Selection", true, 15);
                #endregion

                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                FastDriver.CountySelectionDlg.Clear.FAClick();
                #endregion

                #region Set "ORANGE" check box and click on "Select" button
                Reports.TestStep = "Set \"ORANGE\" check box and click on \"Select\" button";
                FastDriver.CountySelectionDlg.Table.PerformTableAction("County", "ORANGE", "Select", TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                #endregion

                #region Verify ORANGE is displayed under Geographic filter
                Reports.TestStep = "Verify ORANGE is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("ORANGE", FastDriver.NextGenDocumentPreparation.GeographicFilterCounty.FAGetText().Trim(), "Geographic Filter County");
                #endregion

                #region In the City row click on "Add/Remove" button
                Reports.TestStep = "In the City row click on \"Add/Remove\" button";
                FastDriver.NextGenDocumentPreparation.CityAddRemove.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("City Selection", true, 15);
                #endregion

                #region Click on "Clear" button
                Reports.TestStep = "Click on \"Clear\" button";
                FastDriver.CountySelectionDlg.WaitForScreenToLoad(null, true);  // City Selection
                FastDriver.CountySelectionDlg.Clear.FAClick();
                #endregion

                #region Set "SANTA ANA" check box and click on "Select" button
                Reports.TestStep = "Set \"SANTA ANA\" check box and click on \"Select\" button";
                FastDriver.CountySelectionDlg.Table.PerformTableAction("City", "SANTA ANA", "Select", TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                #endregion

                #region Verify SANTA ANA is displayed under Geographic filter
                Reports.TestStep = "Verify SANTA ANA is displayed under Geographic filter";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("SANTA ANA", FastDriver.NextGenDocumentPreparation.GeographicFilterCity.FAGetText().Trim(), "Geographic Filter City");
                #endregion

                #region Set "Title" and "Escrow" check boxes under service type
                Reports.TestStep = "Set \"Title\" and \"Escrow\" check boxes under service type";
                FastDriver.NextGenDocumentPreparation.Title.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.Escrow.FASetCheckbox(true);
                #endregion

                #region Select "Single Family Residence" Property Type
                Reports.TestStep = "Select \"Single Family Residence\" Property Type";
                FastDriver.NextGenDocumentPreparation.PropertyType.FASelectItem("Single Family Residence");
                #endregion

                #region Select "ALTA Expanded (Eagle Loan) Polcy" Product
                Reports.TestStep = "Select \"ALTA Expanded (Eagle Loan) Polcy\" Product";
                FastDriver.NextGenDocumentPreparation.Products.FASelectItem("ALTA Expanded (Eagle Loan) Policy");
                #endregion

                #region Select "Residential" Business Segment
                Reports.TestStep = "Select \"Residential\" Business Segment";
                FastDriver.NextGenDocumentPreparation.BusinessSegment.FASelectItem("Residential");
                #endregion

                #region Select "Accommodation" Transaction Typ
                Reports.TestStep = "Select \"Accommodation\" Transaction Type";
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Accommodation");
                #endregion

                #region Clcik on "Done" button
                Reports.TestStep = "Clcik on \"Done\" button";
                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                #endregion

                #region Under Suggested Filter Group selected filtering Values will be displayed
                Reports.TestStep = "Under Suggested Filter Group selected filtering Values will be displayed";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddFilterGroup);
                var filterContent = FastDriver.NextGenDocumentPreparation.FilterTable.GetAttribute("textContent");
                Support.AreEqual("True", filterContent.Contains("CA").ToString(), "Filter contains CA");
                Support.AreEqual("True", filterContent.Contains("ORANGE").ToString(), "Filter contains ORANGE");
                Support.AreEqual("True", filterContent.Contains("SANTA ANA").ToString(), "Filter contains SANTA ANA");
                Support.AreEqual("True", filterContent.Contains("Title, Escrow").ToString(), "Filter contains Title, Escrow");
                Support.AreEqual("True", filterContent.Contains("Accommodation").ToString(), "Filter contains Accommodation");
                Support.AreEqual("True", filterContent.Contains("Single Family Residence").ToString(), "Filter contains Single Family Residence");
                Support.AreEqual("True", filterContent.Contains("ALTA Expanded (Eagle Loan) Policy").ToString(), "Filter contains ALTA Expanded (Eagle Loan) Policy");
                Support.AreEqual("True", filterContent.Contains("Residential").ToString(), "Filter contains Residential");
                #endregion

                #region Click on "Save" Button
                Reports.TestStep = "Click on \"Save\" Button";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void SAN_NEXTGEN_21_Exception_Document()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Verify to view the Exceptions Document by Adding Exceptions/ Requirements/ informational Notes in the Title Production tab of Property Tax/Info";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFileWithNewLoan() || NextGen_FAST_CreateFile(), "File created successfully");

                #region Navigate to Properties/Tax Info
                Reports.TestStep = "Navigate to Properties/Tax Info";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                #endregion

                #region Click Edit
                Reports.TestStep = "Click Edit";
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                #endregion

                #region Click on Title Production Tab
                Reports.TestStep = "Click on Title Production Tab";
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.TitleProductionTab.FAClick();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                #endregion

                #region Enter Exceptions/Requirements/Informational Valid Phrase Codes Manually
                Reports.TestStep = "Enter Exceptions/Requirements/Informational Valid Phrase Codes Manually";
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionExceptions.FASetText("*E/1, *B/1");   //"ASHV/ANNI"
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionRequirements.FASetText("R/7");
                FastDriver.PropertyTaxInfoTitleProd.TitleProductionInformationalNotes.FASetText("INFO/11");
                #endregion

                #region Click on Save button
                Reports.TestStep = "Click on Save button";
                FastDriver.PropertyTaxInfoTitleProd.ExceptionRequestInformationSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                #endregion

                #region Click on "Exception Document" button
                Reports.TestStep = "Click on \"Exception Document\" button";
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoTitleProd.ExceptionDocuments.FADoubleClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                #endregion

                #region Perform Preview Delivery
                Reports.TestStep = "Perform Preview Delivery";
                if (FastDriver.DocumentEditor.IRToolsDownArrow2.DelayOnce(30).Visible())   //    1680 * 1050 
                {
                    FastDriver.DocumentEditor.IRToolsDownArrow2.FAClick();
                    FastDriver.DocumentEditor.IRToolsPreviewDelivery2.FAClick();
                }
                else
                {
                    Support.Fail("'Delivery/Down Arrow' was not found by ImageRecognition");
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30);     // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 300);   // wait for delivery window to disappear
                FastDriver.WebDriver.ClosePreviewWindow();
                #endregion

                #region Perform Print Delivery
                Reports.TestStep = "Perform Print Delivery";
                if (FastDriver.DocumentEditor.IRToolsDownArrow2.Visible())   //    1680 * 1050 
                {
                    FastDriver.DocumentEditor.IRToolsDownArrow2.FAClick();
                    FastDriver.DocumentEditor.IRToolsPrintDelivery2.FAClick();
                }
                else
                {
                    Support.Fail("'Delivery/Down Arrow' was not found by ImageRecognition");
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 15);
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 300);
                #endregion

                #region Perform Fax Delivery
                Reports.TestStep = "Perform Fax Delivery";
                if (FastDriver.DocumentEditor.IRToolsDownArrow2.Visible())   //    1680 * 1050 
                {
                    FastDriver.DocumentEditor.IRToolsDownArrow2.FAClick();
                    FastDriver.DocumentEditor.IRToolsFaxDelivery2.FAClick();
                }
                else
                {
                    Support.Fail("'Delivery/Down Arrow' was not found by ImageRecognition");
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Fax", true, 15);
                FastDriver.FaxDlg.WaitForScreenToLoad().SendFax();
                FastDriver.WebDriver.WaitForDeliveryWindow("Fax", 300);
                #endregion

                #region Perform Email Delivery
                Reports.TestStep = "Perform Email Delivery";
                if (FastDriver.DocumentEditor.IRToolsDownArrow2.Visible())   //    1680 * 1050 
                {
                    FastDriver.DocumentEditor.IRToolsDownArrow2.FAClick();
                    FastDriver.DocumentEditor.IRToolsEmailDelivery2.FAClick();
                }
                else
                {
                    Support.Fail("'Delivery/Down Arrow' was not found by ImageRecognition");
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 15);
                FastDriver.EmailDlg.WaitForDialogToLoad().SendEmail();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 300);
                #endregion

                #region Click on "Close" Button
                Reports.TestStep = "Click on \"Close\" Button";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FASendKeys(FAKeys.Enter);
                #endregion

                #region Navigate to Event/Tracking Log in FAST Nav
                Reports.TestStep = "Navigate to Event/Tracking Log in FAST Nav";
                FastDriver.EventTrackingLog.Open();
                #endregion

                #region Select Doc Deivery from the Event Category dropdown
                Reports.TestStep = "Select Doc Deivery from the Event Category dropdown";
                FastDriver.EventTrackingLog.EventCategory.FASelectItemBySendingKeys("doc delivery");
                Playback.Wait(2000);    // TODO: find a better way to check if table finishes loading. wait until .//option[@selected][text()='Doc Delivery']
                FastDriver.EventTrackingLog.WaitForScreenToLoad(); // create a WaitForTableToLoad(string eventCategory) method 
                #endregion

                #region Verifying Print Preview Delivery
                Reports.TestStep = "Verifying Print Preview Delivery";
                var printServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "Print Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", printServiceComment.Contains("Title Production, Property").ToString(), "Verify Print Service Comments contains document name: Title Production, Property");
                #endregion

                #region Verifying Fax Delivery
                Reports.TestStep = "Verifying Fax Delivery";
                var faxServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "Fax Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", faxServiceComment.Contains("Title Production, Property").ToString(), "Verify Fax Service Comments contains document name: Title Production, Property");
                #endregion

                #region Verifying Email Delivery
                Reports.TestStep = "Verifying Email Delivery";
                var emailServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", "Email Service", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", emailServiceComment.Contains("Title Production, Property").ToString(), "Verify Email Service Comments contains document name: Title Production, Property");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally
            {
                SetSilverlightClipboardPermission_NO();
            }
        }

        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void SAN_NEXTGEN_22_Pro_Active_ADM_Setup()
        {
            try
            {
                Reports.TestDescription = "SAN_NEXTGEN_22_Pro-Active Notification Pre-Condition: Creating Task Notification_ADM";

                // Pre-Condition
                FAST_Login_ADM(isSuperUser: AutoConfig.FASTAdmURL.ToUpperInvariant().Contains("SNAVPADMFAST") ? false:true, regionId: regionId);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentPreparation>("Home>System Maintenance>NextGen Document Preparation");
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for Existing Message Template with description";

                int mrows = FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Message Template", "SAN-MSG-TEMP-PRONO");

                if (mrows < 1)
                {
                    #region Create New Message Template
                    Reports.TestStep = "Creating New Message Template with description";
                    FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(Support.RandomString("AAAAAANNNN"));
                    FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("SAN-MSG-TEMP-PRONO");
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Message Template");
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                    Support.AreEqual("FALSE", FastDriver.NextGenDocumentPreparation.NotificationCandidate.IsSelected().ToString().ToUpper());
                    Support.AreEqual("FALSE", FastDriver.NextGenDocumentPreparation.NotificationCandidate.IsEnabled().ToString().ToUpper());
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    Playback.Wait(10000);
                    #endregion

                    #region Editor
                    Reports.TestStep = "Adding Phrase in the Template";
                    FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                    FastDriver.DocumentEditor.WaitForScreenToLoad();
                    FastDriver.DocumentEditor.DocumentTitle.GiveFocus();

                    Reports.TestStep = "In the left pane of the Editor Right-Click on InsertPhrase and Select Bottom ";
                    if (FastDriver.DocumentEditor.IRInsertPhrase6.DelayOnce(60).Visible())
                    {
                        FastDriver.DocumentEditor.IRInsertPhrase6.ContextClick();
                        FastDriver.DocumentEditor.IRInsertPhraseBottom6.FAClick();
                        FastDriver.DocumentEditor.IRInsertSearch1st4.DelayOnce(1).DoubleClick();
                    }
                    else if (FastDriver.DocumentEditor.IRInsertPhrase2.Visible())   //  1680 * 1050
                    {
                        FastDriver.DocumentEditor.IRInsertPhrase2.ContextClick();
                        FastDriver.DocumentEditor.IRInsertPhraseBottom2.FAClick();
                        FastDriver.DocumentEditor.IRInsertSearch1st2.DelayOnce(3).DoubleClick();
                    }
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 30);
                    
                    Reports.TestStep = "Select a phrase from the phrase search dialog and click on done button";
                    FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                    FastDriver.PhraseSelectDlg.Description.FASetText("NextGen*");
                    FastDriver.PhraseSelectDlg.Search.Click();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                    FastDriver.WebDriver.SwitchToWindow("Phrase Selection");
                    FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                    FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(2, "NEXTGEN-SAN-EscrowPhrase-DoNotTouch", 2, TableAction.Click);
                    FastDriver.DialogBottomFrame.ClickDone();
                    Playback.Wait(250);

                    #region Click on "Save" Button
                    Reports.TestStep = "Click on \"Save\" Button";
                    SaveDocumentEditor();
                    #endregion

                    #region Click on "Close" Button
                    Reports.TestStep = "Click on \"Close\" Button";
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.DocumentEditor.WaitForScreenToLoad();
                    FastDriver.DocumentEditor.Close.FASendKeys(FAKeys.Enter);   // workaround
                    Playback.Wait(6000);
                    #endregion

                    #endregion
                }

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.LeftNavigation.Navigate<NextGenDocumentPreparation>("Home>System Maintenance>NextGen Document Preparation");
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for Existing Attachment Template with description";

                int erows = FastDriver.NextGenDocumentPreparation.SearchExistingTemplate("Escrow Instruction", "SAN-EI-TEMP-PRONO");

                if (erows < 1)
                {
                    #region Create New Attachment Template
                    Reports.TestStep = "Creating New Attachment Template with description";
                    FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(Support.RandomString("AAAAAANNNN"));
                    FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("SAN-EI-TEMP-PRONO");
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Escrow Instruction");
                    FastDriver.NextGenDocumentPreparation.NotificationCandidate.FASetCheckbox(true);
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    Playback.Wait(10000);
                    #endregion

                    #region Editor
                    Reports.TestStep = "Adding Phrase in the Template";
                    FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                    FastDriver.DocumentEditor.WaitForScreenToLoad();

                    Reports.TestStep = "In the left pane of the Editor Right-Click on InsertPhrase and Select Bottom ";
                    if (FastDriver.DocumentEditor.IRInsertPhrase6.DelayOnce(60).Visible())
                    {
                        FastDriver.DocumentEditor.IRInsertPhrase6.ContextClick();
                        FastDriver.DocumentEditor.IRInsertPhraseBottom6.FAClick();
                        FastDriver.DocumentEditor.IRInsertSearch1st4.DelayOnce(1).DoubleClick();
                    }
                    else if (FastDriver.DocumentEditor.IRInsertPhrase2.Visible())   //  1680 * 1050
                    {
                        FastDriver.DocumentEditor.IRInsertPhrase2.ContextClick();
                        FastDriver.DocumentEditor.IRInsertPhraseBottom2.FAClick();
                        FastDriver.DocumentEditor.IRInsertSearch1st2.DelayOnce(3).DoubleClick();
                    }
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 30);

                    Reports.TestStep = "Select a phrase from the phrase search dialog and click on done button";
                    FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                    FastDriver.PhraseSelectDlg.Description.FASetText("NextGen*");
                    FastDriver.PhraseSelectDlg.Search.Click();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                    //FastDriver.WebDriver.SwitchToWindow("Phrase Selection");
                    //FastDriver.PhraseSelectDlg.SwitchToDialogContentFrame();
                    FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(2, "NEXTGEN-SAN-EscrowPhrase-DoNotTouch", 2, TableAction.Click);
                    FastDriver.DialogBottomFrame.ClickDone();
                    Playback.Wait(250);

                    #region Click on "Save" Button
                    Reports.TestStep = "Click on \"Save\" Button";
                    SaveDocumentEditor();
                    #endregion

                    #region Click on "Close" Button
                    Reports.TestStep = "Click on \"Close\" Button";
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.DocumentEditor.WaitForScreenToLoad();
                    FastDriver.DocumentEditor.Close.FASendKeys(FAKeys.Enter);   // workaround
                    Playback.Wait(6000);
                    #endregion
                    
                    #endregion
                }

                Reports.TestStep = "Navigate to Task Template Screen";
                FastDriver.LeftNavigation.Navigate<TaskTemplateSelection>("Home>System Maintenance>Process Setup>Task Templates");
                FastDriver.TaskTemplateSelection.WaitForScreenToLoad();

                Reports.TestStep = "Search for Existing Task";
                string taskexists = FastDriver.TaskTemplateSelection.TasksForTable.FeeExistOnTable("SAN_TASK_PRONO").ToString().ToUpper();

                if (taskexists == "FALSE")
                {
                    #region Creating a new task and notification
                    Reports.TestStep = "Creating a new task";

                    FastDriver.TaskTemplateSelection.New.FAClick();
                    Playback.Wait(3000);
                    string tasktablerow = FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount().ToString();
                    OperationStatus Success = FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(1, tasktablerow, 3, TableAction.SetText, "SAN_TASK_PRONO").Status;
                    OperationStatus Success1 = FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(1, tasktablerow, 5, TableAction.SelectItem, "Yes").Status;
                    OperationStatus Success2 = FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(1, tasktablerow, 4, TableAction.SetText, "SAN_TASK_PRONO").Status;
                    FastDriver.BottomFrame.Save();
                    Playback.Wait(10000);
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(5000);
                    Reports.TestStep = "Navigate to Task Template Screen";
                    FastDriver.LeftNavigation.Navigate<TaskTemplateSelection>("Home>System Maintenance>Process Setup>Task Templates");
                    FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
                    Reports.TestStep = "Select the new task and click Notification";
                    FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction("#3", "SAN_TASK_PRONO", "#3", TableAction.Click);
                    Playback.Wait(1000);

                    Support.AreEqual("TRUE", FastDriver.TaskTemplateSelection.Notification.IsEnabled().ToString().ToUpper());
                    Reports.TestStep = "Setting up notification for the task";

                    FastDriver.TaskTemplateSelection.Notification.FAClick();
                    FastDriver.NotificationSetup.WaitForScreenToLoad();
                    FastDriver.NotificationSetup.TaskStatus.FASelectItem("Started");
                    FastDriver.NotificationSetup.DeliveryMethod.FASelectItem("Email");

                    Reports.TestStep = "Selecting Message Template";
                    FastDriver.NotificationSetup.Select.FAClick();
                    FastDriver.MessageTemplateSelectionDlg.WaitForScreenToLoad();
                    FastDriver.MessageTemplateSelectionDlg.TemplateDescription.FASetText("SAN-MSG-TEMP-PRONO");
                    FastDriver.MessageTemplateSelectionDlg.FindNow.FAClick();
                    FastDriver.MessageTemplateSelectionDlg.SearchResults.PerformTableAction("Description", "SAN-MSG-TEMP-PRONO", "Description", TableAction.Click);
                    Support.AreEqual("TRUE", FastDriver.MessageTemplateSelectionDlg.Select.IsEnabled().ToString().ToUpper());
                    FastDriver.MessageTemplateSelectionDlg.Select.FAClick();
                    Playback.Wait(3000);
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.NotificationSetup.WaitForScreenToLoad();

                    Reports.TestStep = "Selecting Business Source";
                    FastDriver.NotificationSetup.FileRoles.FAClick();
                    FastDriver.SelectFBPRolesDlg.WaitForScreenToLoadAndSwitch();
                    FastDriver.SelectFBPRolesDlg.WaitForScreenToLoad();
                    FastDriver.SelectFBPRolesDlg.Table.PerformTableAction(2, "Business Source", 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    Playback.Wait(5000);
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.NotificationSetup.WaitForScreenToLoad();

                    Reports.TestStep = "Selecting Receiver Name and mail address";
                    FastDriver.NotificationSetup.TaskEmailAddresses.FAClick();
                    FastDriver.NotificationEmailAddressesDlg.WaitForScreenToLoad();
                    FastDriver.NotificationEmailAddressesDlg.Name1.FASetText("Test Name");
                    FastDriver.NotificationEmailAddressesDlg.Email1.FASetText("ighosh@firstam.com");
                    FastDriver.DialogBottomFrame.ClickDone();
                    Playback.Wait(5000);
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.NotificationSetup.WaitForScreenToLoad();

                    Reports.TestStep = "Inserting Data Element";
                    FastDriver.NotificationSetup.InsertDataElement.FAClick();
                    Playback.Wait(3000);
                    FastDriver.groupElementsDlg.WaitForScreenToLoad();
                    FastDriver.groupElementsDlg.Table.PerformTableAction(2, 2, TableAction.Click);
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.NotificationSetup.WaitForScreenToLoad();

                    FastDriver.NotificationSetup.AvailabeSender.FASelectItem("Designated Sender");
                    FastDriver.NotificationSetup.AddSender.FAClick();


                    Reports.TestStep = "Setting DesignatedSenderName and DesignatedSenderEmail";
                    Support.AreEqual("TRUE", FastDriver.NotificationSetup.DesignatedSenderName.IsEnabled().ToString().ToUpper());
                    Support.AreEqual("TRUE", FastDriver.NotificationSetup.DesignatedSenderEmailAddress.IsEnabled().ToString().ToUpper());
                    FastDriver.NotificationSetup.DesignatedSenderName.FASetText("Test Sender");
                    FastDriver.NotificationSetup.DesignatedSenderEmailAddress.FASetText("ighosh@firstam.com");

                    Reports.TestStep = "Adding Attachment Template";
                    FastDriver.NotificationSetup.DocumentsAddRemove.FAClick();
                    FastDriver.DocumentSelectionDlg.WaitForScreenLoad();
                    FastDriver.DocumentSelectionDlg.TemplateType.FASelectItem("Escrow Instruction");
                    FastDriver.DocumentSelectionDlg.FindNow.FAClick();
                    Playback.Wait(5000);
                    FastDriver.DocumentSelectionDlg.DocumnentSearchTable.PerformTableAction(2, "SAN-EI-TEMP-PRONO", 5, TableAction.On);
                    FastDriver.DocumentSelectionDlg.DocumnentSearchTable.PerformTableAction(2, "SAN-EI-TEMP-PRONO", 1, TableAction.On);
                    FastDriver.DocumentSelectionDlg.Add.FAClick();
                    Playback.Wait(2000);
                    FastDriver.DocumentSelectionDlg.DocumentSelectionTable.PerformTableAction(2, "SAN-EI-TEMP-PRONO", 1, TableAction.On);
                    FastDriver.DocumentSelectionDlg.Select.FAClick();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.NotificationSetup.WaitForScreenToLoad();
                    FastDriver.BottomFrame.Save();
                    Playback.Wait(5000);
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(5000);
                    #endregion
                }
            }


            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        public void SAN_NEXTGEN_23_Pro_Active_Notification_Task_Triggering()
        {
            try
            {
                Reports.TestDescription = "SAN_NEXTGEN_23_ProActive Notification Task Triggering in File Workflow";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFile() || NextGen_FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to File Workflow screen";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow");
                FastDriver.FileWorkflow.WaitForScreenToLoad();

                string expbutton = FastDriver.FileWorkflow.ExpandButton.IsEnabled().ToString().ToUpper();

                Reports.TestStep = "Adding Task to a Process";

                if (expbutton == "TRUE")
                {
                    FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                    FastDriver.FileWorkflow.ExpandButton.FAClick();
                    Playback.Wait(2000);
                    FastDriver.FileWorkflow.Process.PerformTableAction(1, 5, TableAction.Click);
                    FastDriver.FileWorkflow.AddTask.FAClick();
                    Playback.Wait(2000);
                    FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                    FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();
                    Playback.Wait(2000);
                    FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                    Playback.Wait(5000);
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, "SAN_TASK_PRONO", 3, TableAction.Click);
                    FastDriver.TaskTemplateSelectionDlg.SelectTask.FAClick();
                    Playback.Wait(2000);
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.FileWorkflow.WaitForScreenToLoad();
                    FastDriver.FileWorkflow.ExpandButton.FAClick();
                    Playback.Wait(3000);
                    FastDriver.FileWorkflow.Process.PerformTableAction(5, "SAN_TASK_PRONO", 1, TableAction.On);
                    FastDriver.BottomFrame.Apply();
                    Playback.Wait(80000);

                    Reports.TestStep = "Verifi the Document in Document Repository";

                    FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>("Home>Order Entry>Document Repository");
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    Support.AreEqual("TRUE", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable("SAN-EI-TEMP-PRONO").ToString().ToUpper());

                }

            }


            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        public void SAN_NEXTGEN_24_Filtered_Templates_Search_IIS()
        {
            try
            {
                Reports.TestDescription = "Verify Searching for a Filtered Template _IIS";

                // Pre-Condition
                CreateNewTemplate("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(NextGen_WCF_CreateFileWithNewLoan() || NextGen_FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_TitleReports_DoNotTouch");
                FastDriver.NextGenDocumentRepository.Keywords_filter_0.FASelectItem("State");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_CA_1.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 30);

                Reports.TestStep = "Verify Filtered template is available in the search result";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.Click);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Get Template deatils form GetDocTemplates() now using template name and Invoke CreateDocument() and finally GetDocuments() from the created document order")]
        public void SAN_NEXTGEN_25_GetDocTemplates_CreateDocument_GetDocuments()
        {
            try
            {
                Reports.TestDescription = "Get Template deatils form GetDocTemplates() now using template name and Invoke CreateDocument() and finally GetDocuments() from the created document order";
                
                //For Reference Adding DocTemplateTypeId list
                //CPL                       93          //Endorsement/Guarantee     7      //Escrow Instruction        13      //Escrow Ltr/Transmittal    57 
                //Fax Cover Sheet           15          //Form                      10     //Gen'd Data Element        59      //Legal Size Paper          62 
                //Legal/Recordable Doc      12          //Lender Policy             6      //Misc Escrow Document      58      //Misc Title Document       56 
                //Owner Policy              5           //Policy w/o Title Reports  82     //SDN Result                64      //Title Ltr/Transmittal     55 
                //Title Reports             4 

                Reports.TestStep = "GetDocTempales using GetDocTemplates() service";
                
                int TemplatePos = 0;
                int docTemplateTypeID = 4;
                int empid = 5;
                string src = "FAMOS";
                string docName = "Preliminary Report-TEST";


                DocTemplateResponse responceObj = FASTHelpers.GetDefaultDocTemplates(docTemplateTypeID, regionId, "Preliminary Report-TEST", "5");
                Support.AreEqual("1", responceObj.Status.ToString());
                Support.AreEqual("PRELIMDT", responceObj.Templates[TemplatePos].ObjectCd.ToString());
                Support.AreEqual(docName, responceObj.Templates[TemplatePos].Descr.ToString());
                Support.AreEqual("Title Reports", responceObj.Templates[TemplatePos].TemplateType.ToString());
                int templateID = responceObj.Templates[TemplatePos].TemplateID.Value;
                Reports.PrintLog(templateID.ToString());

                Reports.TestStep = "Open FAST file side and Create File using web service.";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                FAST_WCF_CreateFile(GetNextGenWCFFileRequest());                
                                
                Reports.TestStep = "Create Document using CreateDocuments() service by using Template from the GetDocTemplates() Response";
                
                int DocumentID = FASTHelpers.CreateDoc(templateID, empid, src);          

                Reports.TestStep = "Verify Created document in UI";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var createddoc = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Preliminary Report-TEST", "Name", TableAction.GetText).Message;
                Support.AreEqual(createddoc, "Preliminary Report-TEST", "Document exists on the Search Result Table");

                Reports.TestStep = "Get the Documents by using GetDocuments() service";
                DocumentListResponse docResponceResopnce = FASTWCFHelpers.FileService.GetDocuments(Convert.ToInt32(File.FileID));

                foreach (Document doc in docResponceResopnce.Documents)
                {
                    if (doc.DocumentName == docName)
                    {
                        Support.AreEqual(docName, doc.DocumentName, "GetDocuments Retured the expected document successfully");
                        break;
                    }
                }

            }
            catch(Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Change File Owning Option to non-DocGen office")]
        public void SAN_NEXTGEN_26_Change_File_Owning_Option_to_non_DocGen_office()
        {
            try
            {
                string Escr_Title_Owningoffice = "Test Office NG PR: QANG Off: 2222 (13316)";
                string Tempname = "Preliminary Report-TEST";
                string TempType = "Title Reports";

                Reports.TestDescription = "Change File Owning Option to non-DocGen office and Verify Create Document";
                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: regionId);

                Reports.TestStep = "Change the Office to New NextGen";
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Navigate to QFE Screen";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                Reports.TestStep = "Create a basic file by changing the Escrow/Title owning office to Non DocGen office";

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);


                Reports.TestStep = "Change Escrow Owning office to non NextGen Office";
                FastDriver.QuickFileEntry.EscrowOwningOffice.FASelectItem(Escr_Title_Owningoffice);
                FastDriver.WebDriver.WaitForWindowAndSwitch("please wait...", true, 10);

                Reports.TestStep = "Change Title Owning office to non NextGen Office";
                FastDriver.QuickFileEntry.TitleOwningOffice.FASelectItem(Escr_Title_Owningoffice);
                FastDriver.WebDriver.WaitForWindowAndSwitch("please wait...", true, 10);

                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItemBySendingKeys("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    FastDriver.BottomFrame.Done();
                }

                Reports.TestStep = "Click on Add Button.";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForTemplatesScreenToLoad();
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.AddDocument("Both", TempType, Tempname, "CA");

                Reports.TestStep = "Verify Document is added";
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                string document = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Type", TempType, "Name", TableAction.GetText).Message.ToString();
                Support.AreEqual(Tempname, document);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        #region Private methods

        private void SaveDocumentEditor()
        {
            FastDriver.DocumentEditor.IRClickSave();
        }

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        #endregion
        
        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }

    public class ImageBenchException : Exception, System.Runtime.Serialization.ISerializable
    {
        public ImageBenchException() : base() { }

        public ImageBenchException(string message) : base(message) { }

        public ImageBenchException(string format, params object[] args)
            : base(string.Format(format, args))
        { }

        public ImageBenchException(string message, Exception innerException)
            : base(message, innerException)
        { }

        public ImageBenchException(string format, Exception innerException, params object[] args)
            : base(string.Format(format, args), innerException)
        { }
    }
}
