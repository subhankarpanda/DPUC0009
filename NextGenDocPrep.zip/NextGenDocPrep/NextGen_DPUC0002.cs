﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System;


namespace NextGenDocPrep
{

    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class NextGen_DPUC0003 : MasterTestClass
    {
        private static int regionId = 12837;
        private static int officeId = 12839;
        private SilverlightSupport FALibSL;

        #region Private methods

        private void InsertPhrase(string tplPhraseName, string phraseDescription)
        {
            if (FastDriver.DocumentEditor.IRInsertPhrase3.DelayOnce(60).Visible())
            {
                FastDriver.DocumentEditor.IRInsertPhrase3.ContextClick();
                FastDriver.DocumentEditor.IRInsertPhraseBottom3.FAClick();
                FastDriver.DocumentEditor.IRInsertSearch1st3.DoubleClick();
            }
            else if (FastDriver.DocumentEditor.IRInsertPhrase2.Visible())
            {
                FastDriver.DocumentEditor.IRInsertPhrase2.ContextClick();
                FastDriver.DocumentEditor.IRInsertPhraseBottom2.FAClick();
                FastDriver.DocumentEditor.IRInsertSearch4.DoubleClick();
            }
            else
            {
                Support.Fail("'Insert Phrase/Search' was not found by ImageRecognition");
            }
            //
            Reports.TestStep = "Enter phrase code and hit enter to insert phrase (or) Click Search Button \"…\" for inserting phrase";
            FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
            //
            Reports.TestStep = "Select a phrase from the phrase search dialog and click on done button";
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.Description.FASetText(phraseDescription);
            FastDriver.PhraseSelectDlg.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, tplPhraseName, 1, TableAction.Click);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            if (FastDriver.DocumentEditor.IRSave2.DelayOnce(6).Visible())
                FastDriver.DocumentEditor.IRSave2.FAClick();
            else if (FastDriver.DocumentEditor.IRSave3.Visible())
                FastDriver.DocumentEditor.IRSave3.FAClick();
            else
                Support.Fail("'Save Button' was not found by ImageRecognition");
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.Close.FAClick();
            FastDriver.DocumentEditor.WaitCreation(FastDriver.DocumentEditor.Yes);
            FastDriver.DocumentEditor.Yes.FAClick();
            Playback.Wait(6000);
        }

        #endregion

        #region REG

        #region NextGen_DPUC0002_BAT0001
        [TestMethod]
        public void DPUC0002_BAT0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Maintain Documents";
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();

                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                // Perform Right Click on a table row using Document Name 
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Document exists on the Search Result Table");

                Reports.TestStep = "Select the created file document from the File documents search result click \"view/edit\" ";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.Click).Element.FADoubleClick();
                //FastDriver.NextGenDocumentRepository.ViewEdit.FAClick();

                Reports.TestStep = "Verify Phrases Move in the document";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 8, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseContextMove.FAClickAction();
                // FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//div/span[text()='Phrase Re-Sequence']/ancestor::div[2]//div[@id='viewPhrases']/table[@id='tblPhraseView']").PerformTableAction(1, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseDesc.PerformTableAction(1, 2, TableAction.GetCell).Element.FAClick();
                FastDriver.NextGenDocumentRepository.MovePhrasesDown.FAClick();

                //FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Using drag and drop Resequence documents in the package.";
                FastDriver.NextGenDocumentRepository.PhraseDescription1.Highlight();
                FastDriver.NextGenDocumentRepository.PhraseDescription2.Highlight();
                FastDriver.NextGenDocumentRepository.PhraseDescription2.FADragAndDrop(FastDriver.NextGenDocumentRepository.PhraseDescription1);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.Highlight(5);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();


                Reports.TestStep = "Verify Phrases Delete in the document";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseContextDelete.FADoubleClick();
                //FastDriver.NextGenDocumentRepository.Delete_PhraseContext.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.DeletePhraseReason.FASendKeys("Testing delete");
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Done_Reasonbutton.Highlight(5);
                FastDriver.NextGenDocumentRepository.Done_Reasonbutton.FAClick();


                FastDriver.WebDriver.WaitForWindowAndSwitch("Deleting.. please wait...", false, 60);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 30);

                Reports.TestStep = "Verify Phrases Insert-RestartNumbering in the document";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 8, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Insert.FAMouseOver();
                FastDriver.NextGenDocumentRepository.Above.FAMouseOver();
                FastDriver.NextGenDocumentRepository.AboveRestartNumbering.Highlight(5);
                FastDriver.NextGenDocumentRepository.AboveRestartNumbering.FASelectContextMenuItem();



                Reports.TestStep = "Verify Phrases misc in the document";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 8, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Insert.FAMouseOver();
                FastDriver.NextGenDocumentRepository.Above.FAMouseOver();
                FastDriver.NextGenDocumentRepository.AboveMiscPhrase.Highlight(5);
                FastDriver.NextGenDocumentRepository.AboveMiscPhrase.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClickAction();


                Reports.TestStep = "Verify Insert Template in the document";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Insert.FAMouseOver();
                FastDriver.NextGenDocumentRepository.Above.FAMouseOver();
                FastDriver.NextGenDocumentRepository.AddTemplate.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SwitchToDialogContentFrame();

                FastDriver.NextGenDocumentRepository.TemplateType.FAClickAction();
                FastDriver.NextGenDocumentRepository.TemplateType.FASelectItem("Endorsement/Guarantee");

                FastDriver.TemplateSelectionDlg.TemplateTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.Click).Element.FAClick();

                FastDriver.DialogBottomFrame.ClickDone();




                FastDriver.NextGenDocumentRepository.CollapseIcon.Highlight(5);
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClickAction();
                FastDriver.NextGenDocumentRepository.DocInfo_Done.Highlight(5);
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClickAction();
                //string[] boxes = new string [100];
                //var Val = FastDriver.NextGenDocumentRepository.PhraseDataElementTable.FAFindElements(By.ClassName("checkbox")).ToListString();
                //int cou = Val.Count();

                //int numberOfBoxes = boxes.size();


                FastDriver.NextGenDocumentRepository.DocumentEditor.Highlight(5);
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClickAction();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                //this.saveandclose();



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion






        #endregion
    }
}
