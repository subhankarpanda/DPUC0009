﻿using FASTSelenium.Common;
using FASTSelenium.ImageRecognition;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Input;

namespace NextGenDocPrep.r12._2016.PS
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_901796 : MasterTestClass
    {
        #region Data Setup and Re Usable Methods

        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        private static FASTWCFHelpers.FastFileService.OrderDetailsResponse _file;
        private int fileID;

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }


        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = FileRequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FASTHelpers.FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FASTHelpers.FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void CreateNewTemplate(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FASTHelpers.FAST_Login_ADM(isSuperUser: false);
            FASTHelpers.FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region templates

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            string[] templates = new string[5];
            templates[0] = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";
            templates[1] = "NEXTGEN_SAN_TitleReports_DoNotTouch";
            templates[2] = "NEXTGEN_SAN_LenderPolicy_DoNotTouch";
            templates[3] = "NEXTGEN_SAN_OwnerPolicy_DoNotTouch";
            templates[4] = "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch";

            string[] tempname = new string[5];
            tempname[0] = "SAN-NEXTGEN100";
            tempname[1] = "SAN-NEXTGEN200";
            tempname[2] = "SAN-NEXTGEN300";
            tempname[3] = "SAN-NEXTGEN400";
            tempname[4] = "SAN-NEXTGEN500";

            string[] temptype = new string[5];
            temptype[0] = "Escrow Instruction";
            temptype[1] = "Title Reports";
            temptype[2] = "Lender Policy";
            temptype[3] = "Owner Policy";
            temptype[4] = "Endorsement/Guarantee";

            #endregion

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (templateExists == false)
            {

                #region Create Escrow Instruction

                if (templateType == "Escrow Instruction")
                {
                    Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                    FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                    FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                    FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Escrow Instruction QA MJJP Test 1");
                    FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                    FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Escrow Instruction QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[0]);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[0]);
                    FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[0]);
                    if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                    Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                }
                else
                {
                    Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
                }

                #endregion
                #region Create Title Reports

                if (templateType == "Title Reports")
                {
                    Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                    FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                    FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                    FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Title Report QA MJJP 1");
                    FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                    FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Title Report QA MJJP 1", "Description", TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[1]);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[1]);
                    FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[1]);
                    if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                    Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                }
                else
                {
                    Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
                }

                #endregion
                #region Create Lender Policy

                if (templateType == "Lender Policy")
                {
                    Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                    FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                    FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                    FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Lender Policy QA MJJP Test 1");
                    FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                    FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Lender Policy QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[2]);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[2]);
                    FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[2]);
                    if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                    Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                }
                else
                {
                    Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
                }

                #endregion
                #region Create Owner Policy

                if (templateType == "Owner Policy")
                {
                    Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                    FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                    FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                    FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Owner Policy QA MJJP Test 1");
                    FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                    FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Owner Policy QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[3]);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[3]);
                    FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[3]);
                    if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                    Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                }
                else
                {
                    Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
                }

                #endregion
                #region Endorsement/Guarantee

                if (templateType == "Endorsement/Guarantee")
                {
                    Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                    FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                    FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                    FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Template QA MJJP-DO NOT TOUCH02");
                    FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                    FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Template QA MJJP-DO NOT TOUCH02", "Description", TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[4]);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[4]);
                    FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[4]);
                    if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                    Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                }
                else
                {
                    Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
                }

                #endregion

            }

            FASTHelpers.CloseRelatedProcesses();
        }

        private void WaitForDeliveryWindow(FADeliveryMethod method, int timeout, bool toExist = false, bool switchBackToWindow = true)
        {
            try
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.Delivery.GetDeliveryWindowTitle(method), toExist, timeout, switchBackToWindow);
            }
            catch
            {
                FastDriver.WebDriver.ClosePreviewWindow();
            }
        }

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        #region VerifyTemplates

        #region Invoke GetDefaultDocTemplates service
        private DocTemplateResponse GetDefaultDocTemplates(int DocTemplateTypeId = 0, int Region = 0, string tempdesc = null, string empobjcd = null)
        {

            Reports.TestStep = "Call GetDocTemplates service to get TemplateID, DocType and Document name";
            var GetDocTempReq = GetDocTemplatesDefaultRequest(DocTemplateTypeId, Region, tempdesc, empobjcd);
            return FASTWCFHelpers.FileService.GetDocTemplates(GetDocTempReq);

        }
        #endregion

        #region GetDocTEmplatesRequest

        public DocTemplateRequest GetDocTemplatesDefaultRequest(int DocTemplateTypeId, int Region, string tempdesc, string empobjcd)
        {
            return new DocTemplateRequest()
            {
                CityID = null,
                CountyID = null,
                DocTemplateTypeCdID = DocTemplateTypeId,
                DocumentSource = DocSource.Both,
                RegionID = Region,
                StateID = 0,
                NextGenFlag = true,
                TemplateDescription = tempdesc,
                EmployeeObjectCD = empobjcd,
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS",

            };
        }

        #endregion
        /// <summary>
        ///     Verify if template exists by using the Web Service GetDefaultDocTemplates
        /// </summary>
        /// <param name="TemplatePos"></param>
        /// <param name="docTemplateTypeID"></param>
        /// <param name="tempdesc"></param>
        /// <param name="empid"></param>
        /// <param name="src"></param>
        /// <returns>Template ID</returns>
        public int VerifyTemplates(int TemplatePos, int docTemplateTypeID, string tempdesc, string empid, string src)
        {
            DocTemplateResponse responceObj = GetDefaultDocTemplates(docTemplateTypeID, regionId, tempdesc, empid);
            Support.AreEqual("1", responceObj.Status.ToString());
            //Support.AreEqual(tempdesc, responceObj.Templates.Length > TemplatePos ? responceObj.Templates[TemplatePos].Descr.ToString() : "", "Template Description");
            int templateID = responceObj.Templates.Length > TemplatePos ? responceObj.Templates[TemplatePos].TemplateID.Value : -1;
            Reports.PrintLog(templateID.ToString());
            Reports.StatusUpdate("Did the web service GetDocTemplates returned templates? " + (responceObj.Status == 1 && templateID != -1).ToString().ToUpperInvariant(), true);
            Reports.StatusUpdate("Template ID: " + templateID, true);

            return templateID;
        }

        #endregion


        #endregion

        [TestMethod]
        [Description("Verify system Fax cover sheet subject is not cut when its long")]
        public void TestCase_918028()
        {
            try
            {
                Reports.TestDescription = "Verify system Fax cover sheet subject is not cut when its long";

                if (VerifyTemplates(0, 13, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "5", "FAMOS") == -1)
                {
                    CreateNewTemplate("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                }

                FASTHelpers.FAST_Login_IIS(regionId: regionId);
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                //Data
                string DocumentName = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";
                string FAXMessage = Support.RandomString("ANANANNANNANANANANANANANNANANANANANNNAANANANANANANANAANANANANANANANANANANANANANANANANAANANANNANNANANANANANANANNANANANANANNNAANANANANANANANAANANANANANANANANANANANANANANANANA");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for a Escrow Instruction type template using template search criteria
                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(DocumentName);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                #endregion

                #region Select the template from Template Results , Right click and select Create Document
                // Perform Right Click on a table row using Document Name 
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Verify Created Document in File Documents Table grid
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Document exists on the Search Result Table");
                #endregion

                #region Perform Fax Delivery
                Reports.TestStep = "Perform Fax Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", DocumentName, "Name", TableAction.GetCell).Element.FARightClick();
                //  Trick or Treat!
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.SearchResult_Deliver);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverFax.FASelectContextMenuItem();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Fax", true, 15);
                FastDriver.FaxDlg.WaitForScreenToLoad();
                FastDriver.FaxDlg.Insert.FAClick();
                FastDriver.FaxDlg.FaxRecipientsTable(1, "", 1, TableAction.SetText, "Testing Fax");
                FastDriver.FaxDlg.FaxRecipientsTable(1, "Testing Fax", 3, TableAction.SetText, AutoConfig.DeliverFaxTo);
                FastDriver.FaxDlg.Message.FASetText(FAXMessage);
                FastDriver.FaxDlg.FAX.FAClick();
                WaitForDeliveryWindow(FADeliveryMethod.Fax, 200);
                #endregion

                #region Navigate to Event/Tracking Log in FAST Nav
                Reports.TestStep = "Navigate to Event/Tracking Log in FAST Nav";
                FastDriver.EventTrackingLog.Open();
                #endregion

                #region Select Doc Delivery from the Event Category dropdown
                Reports.TestStep = "Select Doc Delivery from the Event Category dropdown";
                FastDriver.EventTrackingLog.EventCategory.FASelectItemBySendingKeys("doc delivery");
                Playback.Wait(1000);    // TODO: find a better way to check if table finishes loading. wait until .//option[@selected][text()='Doc Delivery']
                FastDriver.EventTrackingLog.WaitForWindowToLoad(); // create a WaitForTableToLoad(string eventCategory) method 
                #endregion

                #region Verifying Fax Delivery
                Reports.TestStep = "Verifying Fax Delivery";
                var faxNumber = String.Format("{0:1(###)###-####}", Convert.ToInt64(AutoConfig.DeliverFaxTo.Replace("-", "")));
                var faxServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Fax]", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", faxServiceComment.Contains(FASTHelpers.File.FileNumber).ToString(), "Verify Fax Service Comments contains 'File Number: " + FASTHelpers.File.FileNumber + "'");
                Support.AreEqual("True", faxServiceComment.Contains(DocumentName).ToString(), "Verify Fax Service Comments contains 'Documents: " + DocumentName + "'");
                Support.AreEqual("True", faxServiceComment.Contains("Delivery Method: Fax").ToString(), "Verify Fax Service Comments contains 'Delivery Method: Fax'");
                Support.AreEqual("True", faxServiceComment.Contains(faxNumber).ToString(), "Verify Fax Service Comments contains fax number: " + faxNumber);
                #endregion

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify Fax cover sheet
                Reports.TestStep = "Verify Fax cover sheet";
                var docStatus1 = FastDriver.NextGenDocumentRepository.WaitForDocument("Fax Cover Sheet", "Fax Cover Sheet");
                Support.IsTrue(true, "Fax Cover Sheet exists on the table = " + docStatus1.ToString());
                #endregion

                #region Select Fax Cover sheet perform preview and verify complete message is displayed or not
                Reports.TestStep = "Select Fax Cover sheet perform preview and verify complete message is displayed or not";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Fax Cover Sheet", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverPreview.JSClick();                
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30);
                WaitForDeliveryWindow(FADeliveryMethod.Preview, 300);

                #endregion

                #region Save PDF file
                Reports.TestStep = "Save PDF file";
                string tempPdfFile = @"C:\Temp\temp.PDF";
                SavePDFFile(tempPdfFile);
                Playback.Wait(1000);
                #endregion

                #region Validate the preview PDF have fax message 
                Reports.TestStep = "Validate the preview PDF have fax message ";
                Support.AreEqual(bool.TrueString, Support.ReadPdfFile(tempPdfFile).Contains(FAXMessage).ToString(), "PDF contains"+FAXMessage);
                #endregion

                #region Close the Preview document
                Reports.TestStep = "Close the Preview document";
                FastDriver.WebDriver.ClosePreviewWindow();
                #endregion

                #region Select Fax Cover sheet Navigate to Phrase View screen and verify fax message
                Reports.TestStep = "Select Fax Cover sheet Navigate to Phrase View screen and verify fax message";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Fax Cover Sheet", "Name", TableAction.Click).Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", true,60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.RefreshDocument);
                var previewmessage = FastDriver.WebDriver.FAFindElement(ByLocator.XPath, "//table[@id='Table']//td/label[text()='Deliver Coversheet SUBJECT:']/ancestor::tr[1]").FAGetText();
                //var dataElement = FastDriver.NextGenDocumentRepository.DataElement("Deliver Coversheet SUBJECT:");
                //var previewmessage = dataElement["Text"].FAGetText().Trim();
                Support.AreEqual("True", previewmessage.Contains(FAXMessage).ToString(), "Phrase view data element contains" + FAXMessage);
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestInitialize]
        public override void TestInitialize()
        {
            FASTHelpers.CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
