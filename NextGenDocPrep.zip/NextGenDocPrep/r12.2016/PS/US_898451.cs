﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using System.Windows.Input;
using FASTSelenium.DataObjects;

namespace NextGenDocPrep.r12._2016.US_PS
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_898451 : FASTHelpers
    {
        #region Data Setup
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
       
        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        #endregion

        #region Private Methods

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.PropertyValueTypeCD = 15;
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                //FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        public bool CreateStandardFile_OtherRegion(string GABID)
        {
            Reports.TestStep = "Create File using FAST GUI.";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
            try
            {
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            }
            catch
            {
                Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
            }

            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(GABID);
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(GABID);
            FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
            if (!FastDriver.QuickFileEntry.Title.Selected)
                FastDriver.QuickFileEntry.Title.FAClick();
            if (!FastDriver.QuickFileEntry.Escrow.Selected)
                FastDriver.QuickFileEntry.Escrow.FAClick();
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
            FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

            FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
            FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
            FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
            FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
            FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
            FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
            FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
            FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
            FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
            FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
            FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
            FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
            FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
            FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
            FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
            FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
            FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
            FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
            FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
            FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
            FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
            FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
            FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
            FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
            Playback.Wait(1000);
            //Keyboard.SendKeys("^{D}"); //Send Control + D
            //FastDriver.BottomFrame.Done();

            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                throw new Exception("File could not be created");
            }

            return true;
        }
        private bool FAST_CreateFilewithprogramtype()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateCustomizedFileWithProgramType();
                //FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        #endregion



        #region TestCase 943518 To verify system displays the Templates using the GetdocTemplates method when the docprep template has a specific owning region

        [TestMethod]
        [DeploymentItem(@"Common\Support\GeneralForm3.docx")]
        public void TestCase_936237()
        {
            Reports.TestDescription = "ADM: Verify system allows to preview a template though it has a checked out form";
            try
            {

                string tempname = Support.RandomString("AAANNNANANA");
                string tempdesc = Support.RandomString("AAANNNANANAANANANANANA");
                string tplPhraseName = "EN06/1";
                Reports.TestStep = "Login to FAST Admin side";
                FAST_Login_ADM(isSuperUser: true);
                Reports.TestStep = "Navigate to Region";
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on the Forms tab and add a new form";
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddNewForm);
                FastDriver.NextGenDocumentPreparation.AddNewForm.FAClick();


                string formName = "(*FORM)";
                FastDriver.NextGenDocumentPreparation.FileLocation.FAClick();
                string fileLoc = Reports.DEPLOYDIR + @"\GeneralForm3.docx";
                FastDriver.OpenImageDlg.UploadImage(fileLoc);
               // System.IO.File.Copy(Reports.DEPLOYDIR + @"\GeneralForm.doc", fileLoc, true);
                FastDriver.NextGenDocumentPreparation.FormDesc.FASetText(formName);
                FastDriver.NextGenDocumentPreparation.FormDone.FAClick();


                Reports.TestStep = "checkout form";
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CheckedOutStatusAllForm.FAClick();
                FastDriver.NextGenDocumentPreparation.SearchForm.FAClick();
                Support.SendKeys("^{CNTR + F}");
                //Enter the formName name
                FastDriver.NextGenDocumentPreparation.Formcheckout.FAClick();

                Reports.TestStep = "Create a Template and select the checked out form";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab.FAClick();
                string TempRegn = FastDriver.NextGenDocumentPreparation.TemplateRegion.FAGetSelectedItem().ToString();
                Support.AreEqual("DOCPREP Corporate Region", TempRegn);
                string Temptype = FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FAGetSelectedItem().ToString();
                Support.AreEqual("Endorsement/Guarantee", Temptype);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(tempdesc);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatePhrases);

                Reports.TestStep = "Open the Editor";
                FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                Playback.Wait(5000);
                
                #region Insert a form
                Reports.TestStep = "Insert a form";
                FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                Playback.Wait(5000);
                // FastDriver.DocumentEditor.InsertRegionFormBelowAndSave(groupName + "/" + phraseName, phraseDescription);
                FastDriver.DocumentEditor.InsertRegionFormBelowAndSave2();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.TemplatePreview.FASetText("789");
                FastDriver.NextGenDocumentPreparation.SeachtemplateButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Preview", true, 300);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                #endregion

                Reports.TestDescription = "TestCase_935349: IIS: Verify system allows to deliver a document though it has a checked out form";
                Reports.TestStep = "Login to FAST File side";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(tempdesc, tempname);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempname, "Name", TableAction.GetCell).Element.FARightClick();
                //FastDriver.NextGenDocumentRepository.SearchResult_Deliver.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.SearchResult_Deliver);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverPreview.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 300);

            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }



        #endregion

        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}

