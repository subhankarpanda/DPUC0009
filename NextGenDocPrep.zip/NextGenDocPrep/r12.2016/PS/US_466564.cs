﻿using System;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using System.Windows.Input;
using FASTWCFHelpers.FastFileService;

namespace NextGenDocPrep.r12._2016.PS
{

    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]

    public class US_466564 : FASTHelpers
    {
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        private static FASTWCFHelpers.FastFileService.OrderDetailsResponse _file;
        private int fileID;

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private void InsertDataElement()
        {
            try
            {
                Playback.Wait(6000);
                var currentLine = FastDriver.DocumentEditor.IRDocumentCurrentLine2;
                currentLine.ContextHighlight();
                if (currentLine.DelayOnce(10).Visible() == false)
                    currentLine.DelayOnce(60);
                Playback.Wait(3000);
                currentLine.FAClick();
                Keyboard.SendKeys(FAKeys.Enter);
                FastDriver.DocumentEditor.IRDocumentCurrentLine6.ContextHighlight();
                FastDriver.DocumentEditor.IRDocumentCurrentLine6.DelayOnce(3).ContextClick();
                Playback.Wait(3000);
                FastDriver.DocumentEditor.IR_CM_InsertDataElement3.ContextHighlight();
                FastDriver.DocumentEditor.IR_CM_InsertDataElement3.DelayOnce(3).FAClick();
                FastDriver.DocumentEditor.IRInsertSearch5.ContextHighlight();
                FastDriver.DocumentEditor.IRInsertSearch5.DoubleClick();
                Keyboard.SendKeys(FAKeys.Enter);
                Playback.Wait(6000);
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItemBySendingKeys("Buyer");
                FastDriver.DataElementSelectionDlg.WaitCreation(FastDriver.DataElementSelectionDlg.SearchResult);
                FastDriver.DataElementSelectionDlg.GetSearchResult(0).FAClick();
                FastDriver.DataElementSelectionDlg.Select.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();

                if (FastDriver.DocumentEditor.IRSave.DelayOnce(6).Offset(1850, 50).Visible())   // 1920 * 1280
                    FastDriver.DocumentEditor.IRSave.Offset(1850, 50).FAClick();
                else if (FastDriver.DocumentEditor.IRSave.Offset(1850 - 240, 50).Visible())     // 1680 * 1050
                    FastDriver.DocumentEditor.IRSave.Offset(1850 - 240, 50).FAClick();
                else if (FastDriver.DocumentEditor.IRSave.Offset(1850 - 320, 50).Visible())     // 1600 * 1200
                    FastDriver.DocumentEditor.IRSave.Offset(1850 - 320, 50).FAClick();
                else if (FastDriver.DocumentEditor.IRSave.Offset(1850 - 640, 50).Visible())     // 1280 * 1024
                    FastDriver.DocumentEditor.IRSave.Offset(1850 - 640, 50).FAClick();
                else
                    Support.Fail("'Save' was not found by ImageRecognition");


                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FAClick();
                FastDriver.DocumentEditor.Yes.FAClick();
                Playback.Wait(6000);

            }
            catch (Exception ex)
            {
                MasterTestClass.FailTest(MasterTestClass.GetExceptionInfo(ex));
            }
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = FileRequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        /// <summary>       
        /// To verify Template Versioning when updating a Phrase's DE for a specific index value through the Template Editor
        /// Script Writen By - Hemlata Saini
        /// </summary>
        [TestMethod]
        public void TestCase_466564()
        {

            #region ADM NextGen Doc Prep create a Phrase with a Data Element and add it to a new Template

            Reports.TestStep = "Navigate to ADM site";
            FAST_Login_ADM(isSuperUser: false);
            FAST_OpenRegionOrOffice(officeId);
            Reports.TestStep = "Navigate NexGen Document Preparation";
            FastDriver.NextGenDocumentPreparation.Open();
            Reports.TestStep = "Create new phrase group";
            FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
            FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
            FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
            var groupName = Support.RandomString("ANAN");
            FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);
            var groupDescription = "TEST--" + Support.RandomString("AN".Repeat(17));
            FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);
            FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Escrow Phrase[ESCROW]");
            FastDriver.NextGenDocumentPreparation.SaveButtom.FADoubleClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
            Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
            Reports.TestStep = "Add phrases";
            FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
            FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
            var phraseName = Support.RandomString("ANAN");
            FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);
            var phraseDescription = "TEST--" + Support.RandomString("AN".Repeat(17));
            FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);
            FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
            var PhrasePropId = FastDriver.NextGenDocumentPreparation.PhrasePropId.FAGetText().ToString();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
            Reports.TestStep = "Insert phrases";
            FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
            Playback.Wait(10000);
            this.InsertDataElement();
            //FastDriver.DocumentEditor.InsertDataElement();  
            Reports.TestStep = "Create template";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
            FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            var templateName = "TEST--" + Support.RandomString("AN".Repeat(4));
            FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
            var templateDescription = "TEST--" + Support.RandomString("AN".Repeat(26));
            FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDescription);
            FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(true);
            FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Escrow Instruction");
            FastDriver.NextGenDocumentPreparation.Save.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
            var VersioningTemplateId = FastDriver.NextGenDocumentPreparation.VersioningTemplate.FAGetText().ToString();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            FastDriver.NextGenDocumentPreparation.TemplatePhrases.FADoubleClick();
            Reports.TestStep = "insert phrase into the crated template fron template phrases tab";
            FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
            FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[0]);
            FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
            FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
            FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
            FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();
            Reports.TestStep = "Select any phrase from Phrase selection dialogbox";
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.PhraseName.FASetText(groupName + "/" + phraseName);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab);
            FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
            FastDriver.NextGenDocumentPreparation.Save.FAClick();
            var VersioningTemplate = FastDriver.NextGenDocumentPreparation.VersioningTemplate.FAGetText().ToString();
            Playback.Wait(10000);

            #endregion

            #region On the IIS, create a NG file and add the document from the precondition

            Reports.TestDescription = "Login to IIS site";
            FAST_Login_IIS(regionId: regionId);
            FAST_OpenRegionOrOffice(_regionId);
            Reports.TestStep = "Create File with unique Id";
            Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
            var fileNum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue().ToString();
            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.NextGenDocumentRepository.Open();
            Reports.TestStep = "Click on Template Search button";
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FADoubleClick();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(templateDescription);
            FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            Reports.TestStep = "Hold Right Click";
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", templateDescription, "Description", TableAction.GetCell).Element.FARightClick();
            Reports.TestStep = "Select Create Document option from the context menu";
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            Playback.Wait(6000);

            #endregion

            #region Go back to the ADM and note the Template ID and Phrase ID
            Reports.TestStep = "Navigate to ADM site";
            FAST_Login_ADM(isSuperUser: false);
            FAST_OpenRegionOrOffice(officeId);
            Reports.TestStep = "Navigate NexGen Document Preparation";
            FastDriver.NextGenDocumentPreparation.Open();
            Reports.TestStep = "Search Template in- Templates Search Criteria";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FADoubleClick();
            Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateType.Exists().ToString());
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Escrow Instruction");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.SendKeys(templateDescription);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
            Reports.TestStep = "Select a Template and right click for View/Edit Template option";
            FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", templateDescription, "Description", TableAction.Click).Element.FARightClick();
            FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FASelectContextMenuItem();
            FastDriver.NextGenDocumentPreparation.TemplatePhrases.FADoubleClick();

            #endregion

            #region Edit the Template from the precondition to change the index of the Phrase's DE to Different combinations like 2,3,4 et.and save it
            FastDriver.NextGenDocumentPreparation.Editor.FAClick();
            // editor make index 2 and save it
            // get phrase and template id





            var _VersioningTemplateId = FastDriver.NextGenDocumentPreparation.VersioningTemplate.FAGetText().ToString();
            FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
            FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(2, templateDescription, 2, TableAction.DoubleClick);
           // var _PhraseGroupId = FastDriver.NextGenDocumentPreparation.PhraseGroupId.FAGetText().ToString();
            Playback.Wait(3000);

            #endregion

            #region On the IIS, add the newly versioned document on the NG Doc Rep

            Reports.TestDescription = "Login to IIS site";
            FAST_Login_IIS(regionId: regionId);
            FAST_OpenRegionOrOffice(_regionId);
            Reports.TestStep = "Open File with previous unique Id";
            FastDriver.TopFrame.SetNumberAndPressEnter(fileNum);
            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.NextGenDocumentRepository.Open();
            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.NextGenDocumentRepository.Open();
            Reports.TestStep = "Click on Template Search button";
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FADoubleClick();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(templateDescription);
            FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", templateDescription, "Description", TableAction.GetCell).Element.FARightClick();
            Reports.TestStep = "Select Create Document option from the context menu";
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            FastDriver.BuyerSellerSetup.Open(true);
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            Playback.Wait(10000);
            FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Individual", 1, TableAction.GetCell).Element.FAClick();
            FastDriver.BuyerSellerSummary.Edit();
            FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Himani");
            FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Saini");
            FastDriver.BottomFrame.Done();
            FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
            FastDriver.BuyerSellerSummary.New();
            FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Saini");
            FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Himani");
            FastDriver.BottomFrame.Done();
            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.NextGenDocumentRepository.Open();
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, templateDescription, 1, TableAction.GetCell).Element.FARightClick();
            Reports.TestStep = "Select Phrase View/Edit option from the context menu";
            FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.NextGenDocumentRepository.Open();
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, templateDescription, 2, TableAction.GetCell).Element.FARightClick();
            Reports.TestStep = "Select Phrase View/Edit option from the context menu";
            FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

            Playback.Wait(6000);


            #endregion
        }



        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            MasterTestClass.CleanupClass();
        }
    }
}
