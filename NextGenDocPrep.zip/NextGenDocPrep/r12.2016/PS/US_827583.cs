﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using System.Windows.Input;
using FASTSelenium.DataObjects;

namespace NextGenDocPrep.r12._2016.US_PS
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_827583 : FASTHelpers
    {
        #region Data Setup
        // Maybe these should be in Config?
        private static int _regionId = 349;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        private static string natgabid = "ATTY3419";
        private static string mortgageid = "A101";

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        #endregion

        #region Private Methods

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.PropertyValueTypeCD = 15;
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                //FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        public bool CreateStandardFile_OtherRegion(string GABID)
        {
            Reports.TestStep = "Create File using FAST GUI.";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
            try
            {
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            }
            catch
            {
                Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
            }

            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(GABID);
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(GABID);
            FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
            if (!FastDriver.QuickFileEntry.Title.Selected)
                FastDriver.QuickFileEntry.Title.FAClick();
            if (!FastDriver.QuickFileEntry.Escrow.Selected)
                FastDriver.QuickFileEntry.Escrow.FAClick();
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
            FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

            FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
            FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
            FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
            FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
            FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
            FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
            FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
            FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
            FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
            FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
            FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
            FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
            FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
            FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
            FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
            FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
            FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
            FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
            FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
            FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
            FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
            FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
            FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
            FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
            Playback.Wait(1000);
            //Keyboard.SendKeys("^{D}"); //Send Control + D
            //FastDriver.BottomFrame.Done();

            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                throw new Exception("File could not be created");
            }

            return true;
        }
        private bool FAST_CreateFilewithprogramtype()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateCustomizedFileWithProgramType();
                //FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        #endregion



        #region TestCase 943518 To verify system displays the Templates using the GetdocTemplates method when the docprep template has a specific owning region

        [TestMethod]
        public void TestCase_943518()
        {
            Reports.TestDescription = "To verify system displays the Templates using the GetdocTemplates method when the docprep template has a specific owning region";

            try
            {
                int corpregionid = 196;

                string tempname = Support.RandomString("AAANNNANANA");
                string tempdesc = Support.RandomString("AAANNNANANAANANANANANA");
                string tplPhraseName = "EN06/1";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                Reports.TestStep = "Login to FAST Admin side";
                FAST_Login_ADM(true);

                Reports.TestStep = "Navigate to Corporate Region";
                FAST_OpenRegionOrOffice(corpregionid);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on the templates tab and create new template type of endorsement";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab.FAClick();
                string TempRegn = FastDriver.NextGenDocumentPreparation.TemplateRegion.FAGetSelectedItem().ToString();
                Support.AreEqual("DOCPREP Corporate Region", TempRegn);
                string Temptype = FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FAGetSelectedItem().ToString();
                Support.AreEqual("Endorsement/Guarantee", Temptype);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(tempdesc);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatePhrases);

                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                Reports.TestStep = "Create phrases from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();

                Reports.TestStep = "Select any phrase from Phrase selection dialogbox";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(tplPhraseName);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FilteringTab);

                Reports.TestStep = "Click on Filtering and add Suggested filter";
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", true, 20);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddFilterGroup);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);

                Reports.TestStep = "Select a Specific owning regions";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                FastDriver.NextGenDocumentPreparation.OwningRegionSelectAll.FAClick();
                FastDriver.NextGenDocumentPreparation.SelectOwningRegion.FASelectItem("Mortgage Services");

                FastDriver.NextGenDocumentPreparation.Title.FAClick();
                FastDriver.NextGenDocumentPreparation.Escrow.FAClick();
                FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.FAClick();
                FastDriver.NextGenDocumentPreparation.PropertyType.FASelectItem("Single Family Residence");
                FastDriver.NextGenDocumentPreparation.BusinessSegment.FASelectItem("Residential");
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");

                Reports.TestStep = "Clcik on \"Done\" button";
                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.UnderConstruction);

                Reports.TestStep = "Uncheck the under construction and save the template";
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                Playback.Wait(2000);

                Reports.TestDescription = "Get Template deatils form GetDocTemplates() now using template name and Invoke CreateDocument() and finally GetDocuments() from the created document order";

                //For Reference Adding DocTemplateTypeId list
                //CPL                       93          //Endorsement/Guarantee     7      //Escrow Instruction        13      //Escrow Ltr/Transmittal    57 
                //Fax Cover Sheet           15          //Form                      10     //Gen'd Data Element        59      //Legal Size Paper          62 
                //Legal/Recordable Doc      12          //Lender Policy             6      //Misc Escrow Document      58      //Misc Title Document       56 
                //Owner Policy              5           //Policy w/o Title Reports  82     //SDN Result                64      //Title Ltr/Transmittal     55 
                //Title Reports             4 

                Reports.TestStep = "GetDocTempales using GetDocTemplates() service";

                int TemplatePos = 0;
                int docTemplateTypeID = 7;
                int empid = 5;
                string src = "FAMOS";
                string docName = tempdesc;

                DocTemplateResponse responceObj = FASTHelpers.GetDefaultDocTemplates(docTemplateTypeID, regionId, tempdesc, "5");
                Support.AreEqual("1", responceObj.Status.ToString());
                Support.AreEqual(tempname, responceObj.Templates[TemplatePos].ObjectCd.ToString());
                Support.AreEqual(docName, responceObj.Templates[TemplatePos].Descr.ToString());
                Support.AreEqual("Endorsement/Guarantee", responceObj.Templates[TemplatePos].TemplateType.ToString());
                int templateID = responceObj.Templates[TemplatePos].TemplateID.Value;
                Reports.PrintLog(templateID.ToString());


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex)); 
            }
        }




        #endregion

        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
