﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using System.Windows.Input;
using FASTWCFHelpers.FastFileService;

namespace NextGenDocPrep.r12._2016.PS
{

    // Working on this-------------------------------------------------------------------------------


    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]

    public class US_924532 : MasterTestClass
    {

        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        private static FASTWCFHelpers.FastFileService.OrderDetailsResponse _file;
        private int fileID;

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = FileRequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }
        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FASTHelpers.FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }
        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FASTHelpers.FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }
        private int CreateBasicFileWithFileID()
        {

            var nextGenRequest = GetNextGenWCFFileRequest();
            Reports.TestStep = "Create File using web service.";
            fileID = FastDriver.FACreateFileGetFileId(nextGenRequest);
            _file = FileService.GetOrderDetails(fileID);

            Reports.TestStep = "Search File";
            FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);

            return fileID;
        }

        [TestMethod]
        public void TestCase_925644()
        {
            try
            {

            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        [TestMethod]
        public void TC_924532_DocGen_Docs_missing_in_All_Templates_search()
        {
            try
            {
                #region Login into ADM
                Reports.TestDescription = "Login into ADM Account";
                FASTHelpers.FAST_Login_ADM(isSuperUser: true);
                FASTHelpers.FAST_OpenRegionOrOffice(regionId);
                #endregion

                #region Create Template
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                Reports.TestStep = "Go to Create New Templat";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                Reports.TestStep = "Create Template with unique Id";
                string _templateName = Support.RandomString("AAAANNNNNN");
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(_templateName);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(_templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                #region Login into IIS
                Reports.TestDescription = "Login to IIS site";
                //FAST_Login_IIS_SUPER(isSuperUser: true);
                FASTHelpers.FAST_Login_IIS(regionId: regionId);
                FASTHelpers.FAST_OpenRegionOrOffice(_regionId);
                #endregion

                #region Create File
                Reports.TestStep = "Create File with unique Id";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion 

                #region Search Template of ADM into Template search criteria
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(_templateName);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(6000);
                #endregion 

                #region Template should not present 
                Reports.TestStep = "Template should not present in Templates table";
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.TemplatesTable.FAGetText().Contains(_templateName).ToString(), false);
                Playback.Wait(2000);
                #endregion 

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }



        [TestInitialize]
        public override void TestInitialize()
        {
            FASTHelpers.CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            MasterTestClass.CleanupClass();
        }

    }

}
