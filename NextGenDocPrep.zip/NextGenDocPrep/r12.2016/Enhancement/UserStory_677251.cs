﻿using FASTSelenium.Common;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers;
using OpenQA.Selenium;
using System.Threading;
using FASTSelenium.DataObjects;

namespace NextGenDocPrep.r12._2016.Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class UserStory_677251 : FASTHelpers
    {
        #region Data Setup
        public static int _regionId = 12837;
        public static int _officeId = 12839;

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        #endregion

        #region Private Methods

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }
        #endregion


        #region TestCase_929284 Verify user is able to upload a document and add it to Frequently Used Documents List
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void TestCase_929284()
        {
            try
            {
                Reports.TestDescription = "Verify user is able to upload a document and add it to Frequently Used Documents List";

                // Data **********
                string docType = "Escrow: Payoff Demand/Bills";
                string docName = "Miscellaneous";
                string addtlInfo = "PDFDocument";

                //**********Data//

                #region Login to FAST application and create a basic file
                Reports.TestStep = "Login to FAST Application file side";
                FAST_Login_IIS(regionId: _officeId);           
                
                Reports.TestStep = "Change office to Doc Gen enabled office";
                FAST_OpenRegionOrOffice(regionId: _officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File Created Successfully");

                #endregion

                #region Navigate to Document Repository and upload a document
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();

                //Pre-condition before the favorite documents data clear verification
                Reports.TestStep = "Pre-condition before the favorite documents data clear verification";
                FastDriver.NextGenDocumentRepository.ClearFavoritedocsdata();

                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();

                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);               
                FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem(docType);
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem(docName);
                string documentname = FastDriver.SaveDocumentDlg.DocumentName.FAGetText();
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText(addtlInfo);          
                Playback.Wait(2000);
                // Verify  Add to Favorites Check box is selected by default unchecked
                Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                FastDriver.SaveDocumentDlg.Ok.Click();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Verify the document is saved in Favorite Documents list

                Reports.TestStep = "Verify the document got uploaded to File Documents Search Results";
                FastDriver.NextGenDocumentRepository.Open();
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");

                Reports.TestStep = "Verify the uploaded document is added in favorite documents list";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FavoriteDocsUIButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done);
                Support.AreEqual("Miscellaneous PDFDocument",FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table.PerformTableAction(2,2, TableAction.GetText).Message, "Uploaded document is saved to Favorite documents successfully");

                #endregion



            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase_929287 Verify user is able to upload a documents and add it to Favorite Documents List with a maximum of 15 documents
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void TestCase_929287()
        {
            try
            {
                Reports.TestDescription = "Verify user is able to upload a documents and add it to Favorite Documents List with a maximum of 15 documents";
               
                #region Login to FAST application and create a basic file
                Reports.TestStep = "Login to FAST Application file side";
                FAST_Login_IIS(regionId: _officeId);

                Reports.TestStep = "Change office to Doc Gen enabled office";
                FAST_OpenRegionOrOffice(regionId: _officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File Created Successfully");

                #endregion

                #region Navigate to NextGen Document Repository screen and clear existing favorite docs data if any

                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();

                //Pre-condition before the favorite documents data clear verification
                Reports.TestStep = "Pre-condition before the favorite documents data clear verification";
                FastDriver.NextGenDocumentRepository.ClearFavoritedocsdata();
                #endregion

                #region Upload Documents upto 15 a maximum and verify them in favorite documents list

                string[] doctype = new string[] { "Corporate Underwriting", "Escrow: Closing Disclosure", "Escrow: Closing Statements", "Escrow: Misc", "Escrow: Payoff Demand/Bills", "Escrow: Signed Instructions", "Exchange : Delayed", "Exchange : Reverse", "Exchange : Secured", "Title: Misc", "Title: Search Package", "Title: Tax Info", "Title: Title Policy", "Title: Title Products", "Miscellaneous"};
                string[] docname = new string[] { "UW Hi Li Approval", "SEC-CD", "INC HUD", "Audit PKG", "PO-Commission Instructions", "INST-Affidavits", "REL-Documents", "MISCELLANEOUS", "SEC-CIP", "Amended", "Map-Assessor", "SEC-TAX-Tax Certificate", "Critical Docs", "Exhibit A", "PDFDocument"};
                List<string> documentname = new List<string>();
                int j;
                for (j = 0; j < 15;j++ )
                {
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    Reports.TestStep = "Click on Upload button";                   
                    FastDriver.NextGenDocumentRepository.Upload.FAClick();

                    Reports.TestStep = "Browse document";
                    string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                    FastDriver.UploadDocumentDlg.UploadFile(filePath);

                    Reports.TestStep = "Save the PDF Document";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                    FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                    FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                    FastDriver.SaveDocumentDlg.DocumentType.FASelectItem(doctype[j]);
                    if(j == 14)
                    {                        
                        FastDriver.SaveDocumentDlg.WaitForScreenToLoad(FastDriver.SaveDocumentDlg.DocumentNameText);
                        FastDriver.SaveDocumentDlg.DocumentNameText.FASetText(docname[j]);
                        Keyboard.SendKeys(FAKeys.TabAway);
                        FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("test");
                        Playback.Wait(2000);
                        Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                        Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                        FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                        Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                        FastDriver.SaveDocumentDlg.Ok.Click();
                        FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                        Playback.Wait(2000);
                        break;
                    }
                    FastDriver.SaveDocumentDlg.DocumentName.FASelectItem(docname[j]);     
                   
                    documentname.Add(FastDriver.SaveDocumentDlg.DocumentName.FAGetText().ToString());
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("test");
                    Playback.Wait(2000);
                    // Verify  Add to Favorites Check box is selected by default unchecked
                    Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                    Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                    FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                    Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                    FastDriver.SaveDocumentDlg.Ok.Click();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    Playback.Wait(2000);                                       
                }
               
                #endregion

                #region Verify documents uploaded/created in File Documents and Favorite Documents dialog
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Verify uploaded documents in File Documents screen";
                for(j=0;j<14;j++)
                {
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument(docname[j],doctype[j]);
                Support.AreEqual("True", docStatus.ToString(), docname[j]+"Document exists on the table");
                }

                string filedocs = FastDriver.NextGenDocumentRepository.DocumentsTable.FAGetText();

                Reports.TestStep = "Verify documents added in Favorite Documents";
                FastDriver.NextGenDocumentRepository.FavoriteDocsUIButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table);
                List<IWebElement> rows = FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table.FAFindElements(ByLocator.TagName, "tr").ToList();
               if(rows.Count == 16)
               {
                  
                   foreach(IWebElement row in rows)
                   {
                       if (row == rows[0])
                           continue;
                       j = 1;
                       Support.AreEqual("True", filedocs.Contains(row.FAGetText()).ToString(), row.FAGetText()+"Document is uploaded successfully into the Favorite Documents");
                       j++;                 
                                               
                   }
                   Reports.StatusUpdate("Maximum 15 Documents uploaded successfully", true);
               }
                else
               {
                   Reports.StatusUpdate("15 Documents are not uploaded to favorited documents", true);
               }


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase_929288 Verify Alert message when user is trying to upload documents and add it to Favorite Upload Doc List after reaching maximum limit of 15 documents
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void TestCase_929288()
        {
            try
            {
                Reports.TestDescription = "Verify Alert message when user is trying to upload documents and add it to Favorite Upload Doc List after reaching maximum limit of 15 documents";
                #region Login to FAST application and create a basic file
                Reports.TestStep = "Login to FAST Application file side";
                FAST_Login_IIS(regionId: _officeId);

                Reports.TestStep = "Change office to Doc Gen enabled office";
                FAST_OpenRegionOrOffice(regionId: _officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File Created Successfully");

                #endregion

                #region Navigate to NextGen Document Repository screen and clear existing favorite docs data if any

                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();

                //Pre-condition before the favorite documents data clear verification
                Reports.TestStep = "Pre-condition before the favorite documents data clear verification";
                FastDriver.NextGenDocumentRepository.ClearFavoritedocsdata();
                #endregion

                #region Upload Documents upto 15 a maximum and verify them in favorite documents list

                string[] doctype = new string[] { "Corporate Underwriting", "Escrow: Closing Disclosure", "Escrow: Closing Statements", "Escrow: Misc", "Escrow: Payoff Demand/Bills", "Escrow: Signed Instructions", "Exchange : Delayed", "Exchange : Reverse", "Exchange : Secured", "Title: Misc", "Title: Search Package", "Title: Tax Info", "Title: Title Policy", "Title: Title Products", "Miscellaneous" };
                string[] docname = new string[] { "UW Hi Li Approval", "SEC-CD", "INC HUD", "Audit PKG", "PO-Commission Instructions", "INST-Affidavits", "REL-Documents", "MISCELLANEOUS", "SEC-CIP", "Amended", "Map-Assessor", "SEC-TAX-Tax Certificate", "Critical Docs", "Exhibit A", "PDFDocument" };
                List<string> documentname = new List<string>();
                int j;
                for (j = 0; j < 15; j++)
                {
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    Reports.TestStep = "Click on Upload button";
                    FastDriver.NextGenDocumentRepository.Upload.FAClick();

                    Reports.TestStep = "Browse document";
                    string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                    FastDriver.UploadDocumentDlg.UploadFile(filePath);

                    Reports.TestStep = "Save the PDF Document";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                    FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                    FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                    FastDriver.SaveDocumentDlg.DocumentType.FASelectItem(doctype[j]);
                    if (j == 14)
                    {
                        FastDriver.SaveDocumentDlg.WaitForScreenToLoad(FastDriver.SaveDocumentDlg.DocumentNameText);
                        FastDriver.SaveDocumentDlg.DocumentNameText.FASetText(docname[j]);
                        Keyboard.SendKeys(FAKeys.TabAway);
                        FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("test");
                        Playback.Wait(2000);
                        Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                        Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                        FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                        Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                        FastDriver.SaveDocumentDlg.Ok.Click();
                        FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                        Playback.Wait(2000);
                        break;
                    }
                    FastDriver.SaveDocumentDlg.DocumentName.FASelectItem(docname[j]);

                    documentname.Add(FastDriver.SaveDocumentDlg.DocumentName.FAGetText().ToString());
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("test");
                    Playback.Wait(2000);
                    // Verify  Add to Favorites Check box is selected by default unchecked
                    Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                    Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                    FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                    Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                    FastDriver.SaveDocumentDlg.Ok.Click();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    Playback.Wait(2000);
                }

                #endregion

                #region Verify documents uploaded/created in File Documents and Favorite Documents dialog
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Verify uploaded documents in File Documents screen";
                for (j = 0; j < 14; j++)
                {
                    var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument(docname[j], doctype[j]);
                    Support.AreEqual("True", docStatus.ToString(), docname[j] + "Document exists on the table");
                }

                string filedocs = FastDriver.NextGenDocumentRepository.DocumentsTable.FAGetText();

                Reports.TestStep = "Verify documents added in Favorite Documents";
                FastDriver.NextGenDocumentRepository.FavoriteDocsUIButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table);
                List<IWebElement> rows = FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table.FAFindElements(ByLocator.TagName, "tr").ToList();
                if (rows.Count == 16)
                {

                    foreach (IWebElement row in rows)
                    {
                        if (row == rows[0])
                            continue;
                        j = 1;
                        Support.AreEqual("True", filedocs.Contains(row.FAGetText()).ToString(), row.FAGetText() + "Document is uploaded successfully into the Favorite Documents");
                        j++;

                    }
                    Reports.StatusUpdate("Maximum 15 Documents uploaded successfully", true);
                }
                else
                {
                    Reports.StatusUpdate("15 Documents are not uploaded to favorited documents", true);
                }


                #endregion

                #region Verify Alert message after 15 documents uploaded by user and trying to add another document
                Reports.TestStep = "Verify Alert message after 15 documents uploaded by user and trying to add another document";
                FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();

                Reports.TestStep = "Browse document";
                string Path = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(Path);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Payoff Demand/Bills");
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem("PO-Invoice");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("test");
                Playback.Wait(2000);
                // Verify  Add to Favorites Check box is selected by default unchecked
                Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                FastDriver.SaveDocumentDlg.Ok.Click();

                Reports.TestStep = "Verify the alert message when adding 16th favorite document";
                string alertmsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("You have reached maximum limit of 15 Favorite Documents! Please uncheck the 'Add to favorite document' checkbox", alertmsg);
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(false);
                FastDriver.SaveDocumentDlg.Ok.Click();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

               
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion
        
        #region TestCase_929289 Verify Alert message when user adds the same document with (Doc Type,Name and Trigger)to Favorite Documents
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void TestCase_929289()
        {
            try
            {
                Reports.TestDescription = "Verify Alert message when user adds the same document with (Doc Type,Name and Trigger)to Favorite Documents";
                // Data **********
                string docType = "Escrow: Payoff Demand/Bills";
                string docName = "Miscellaneous";
                

                //**********Data//

                #region Login to FAST application and create a basic file
                Reports.TestStep = "Login to FAST Application file side";
                FAST_Login_IIS(regionId: _officeId);

                Reports.TestStep = "Change office to Doc Gen enabled office";
                FAST_OpenRegionOrOffice(regionId: _officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File Created Successfully");

                #endregion

                #region Navigate to Document Repository and upload a document
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();

                //Pre-condition before the favorite documents data clear verification
                Reports.TestStep = "Pre-condition before the favorite documents data clear verification";
                FastDriver.NextGenDocumentRepository.ClearFavoritedocsdata();

                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();

                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem(docType);
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem(docName);
                string documentname = FastDriver.SaveDocumentDlg.DocumentName.FAGetText();
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("test");
                Playback.Wait(2000);
                // Verify  Add to Favorites Check box is selected by default unchecked
                Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                FastDriver.SaveDocumentDlg.Ok.Click();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Verify the document is saved in Favorite Documents list

                Reports.TestStep = "Verify the document got uploaded to File Documents Search Results";
                FastDriver.NextGenDocumentRepository.Open();
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");

                Reports.TestStep = "Verify the uploaded document is added in favorite documents list";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FavoriteDocsUIButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done);
                Support.AreEqual("Miscellaneous test", FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table.PerformTableAction(2, 2, TableAction.GetText).Message, "Uploaded document is saved to Favorite documents successfully");
                FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Verify Alert Message when user addes the same document as added in above steps
                Reports.TestStep = "Verify Alert Message when user addes the same document as added in above steps";
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();

                Reports.TestStep = "Browse document";                
                FastDriver.UploadDocumentDlg.UploadFile(filePath);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem(docType);
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem(docName);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("test");
                Playback.Wait(2000);
                // Verify  Add to Favorites Check box is selected by default unchecked
                Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                FastDriver.SaveDocumentDlg.Ok.Click();
                string alertmsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Image already exist with same Document Type, Document Name and Image Trigger Name in Favorite Images!", alertmsg);
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase_929290 Verify Error warning message when user deletes the document(s) from the Favorite Documents
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void TestCase_929290()
        {
            try
            {
                Reports.TestDescription = "Verify Error warning message when user deletes the document(s) from the Favorite Documents";
                // Data **********
                string docType = "Escrow: Payoff Demand/Bills";
                string docName = "Miscellaneous";
                string addtlInfo = "PDFDocument";

                //**********Data//

                #region Login to FAST application and create a basic file
                Reports.TestStep = "Login to FAST Application file side";
                FAST_Login_IIS(regionId: _officeId);

                Reports.TestStep = "Change office to Doc Gen enabled office";
                FAST_OpenRegionOrOffice(regionId: _officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File Created Successfully");

                #endregion

                #region Navigate to Document Repository and upload a document
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();

                //Pre-condition before the favorite documents data clear verification
                Reports.TestStep = "Pre-condition before the favorite documents data clear verification";
                FastDriver.NextGenDocumentRepository.ClearFavoritedocsdata();

                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();

                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem(docType);
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem(docName);
                string documentname = FastDriver.SaveDocumentDlg.DocumentName.FAGetText();
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText(addtlInfo);
                Playback.Wait(2000);
                // Verify  Add to Favorites Check box is selected by default unchecked
                Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                FastDriver.SaveDocumentDlg.Ok.Click();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Verify the document is saved in Favorite Documents list

                Reports.TestStep = "Verify the document got uploaded to File Documents Search Results";
                FastDriver.NextGenDocumentRepository.Open();
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");            
                Reports.TestStep = "Verify the uploaded document is added in favorite documents list";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FavoriteDocsUIButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done);
                Support.AreEqual("Miscellaneous PDFDocument", FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table.PerformTableAction(2, 2, TableAction.GetText).Message, "Uploaded document is saved to Favorite documents successfully");
                FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table.PerformTableAction(2, 4, TableAction.GetCell).Element.FindElement(By.TagName("img")).FAClick();
                FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done.FAClick();
                #endregion

                #region Verify error warning message when user deletes the docuemnts from the favorite docs
                Reports.TestStep = "Verify error warning message when user deletes the docuemnts from the favorite docs";
                string alertmsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("You have selected a Miscellaneous PDFDocument for deletion, do you want to continue?", alertmsg);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FavoriteDocsUIButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done);
                if (FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table.GetRowCount() == 1)
                    Reports.StatusUpdate("Document deleted from the favorite documents successfully", true);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase_929291 Verify when document add to file documents from Favorite Documents list , System should add appropriate Document Name, Document Type
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void TestCase_929291()
        {
            try
            {
                Reports.TestDescription = "Verify when document add to file documents from Favorite Documents list , System should add appropriate Document Name, Document Type";
                // Data **********
                string docType = "Escrow: Payoff Demand/Bills";
                string docName = "Miscellaneous";
                string addtlInfo = "PDFDocument";

                //**********Data//

                #region Login to FAST application and create a basic file
                Reports.TestStep = "Login to FAST Application file side";
                FAST_Login_IIS(regionId: _officeId);

                Reports.TestStep = "Change office to Doc Gen enabled office";
                FAST_OpenRegionOrOffice(regionId: _officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File Created Successfully");

                #endregion

                #region Navigate to Document Repository and upload a document
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();

                //Pre-condition before the favorite documents data clear verification
                Reports.TestStep = "Pre-condition before the favorite documents data clear verification";
                FastDriver.NextGenDocumentRepository.ClearFavoritedocsdata();

                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();

                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem(docType);
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem(docName);
                string documentname = FastDriver.SaveDocumentDlg.DocumentName.FAGetText();
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText(addtlInfo);
                Playback.Wait(2000);
                // Verify  Add to Favorites Check box is selected by default unchecked
                Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                FastDriver.SaveDocumentDlg.Ok.Click();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Verify the document is saved in Favorite Documents list

                Reports.TestStep = "Verify the document got uploaded to File Documents Search Results";
                FastDriver.NextGenDocumentRepository.Open();
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                Reports.TestStep = "Verify the uploaded document is added in favorite documents list";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FavoriteDocsUIButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done);
                Support.AreEqual("Miscellaneous PDFDocument", FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table.PerformTableAction(2, 2, TableAction.GetText).Message, "Uploaded document is saved to Favorite documents successfully");
                FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Remove uploaded doc from file docs and create doc from favorite docs and verify the docnam,type etc., are added as expected
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Remove.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait.. Validating Document(s)", true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait.. Refreshing Document(s)", true);
                FastDriver.NextGenDocumentRepository.FavoriteDocsUIButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done);
                FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table.PerformTableAction(2, 3, TableAction.GetCell).Element.FindElement(By.TagName("img")).FAClick();
                FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                Support.AreEqual("Miscellaneous PDFDocument", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Name", TableAction.GetText).Message);
                Support.AreEqual("Escrow: Payoff Demand/Bills", FastDriver.NextGenDocumentRepository.DocumentsInnerTable.PerformTableAction("Type", "Escrow: Payoff Demand/Bills", "Type", TableAction.GetText).Message);
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase_929319 Verify uploading  different types of document types such as .docx,pdf,.tiff,.jpg as Favorite Documents and verify them in document repository
        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        [DeploymentItem(@"Common\Support\DOCXFormat.docx")]
        [DeploymentItem(@"Common\Support\imagesJPG.jpg")]
        [DeploymentItem(@"Common\Support\NexGen_Report.xlsx")]
        [DeploymentItem(@"Common\Support\EMAIL_Offshore_Pdf.pdf")]
        public void TestCase_929319()
        {
            try
            {
                Reports.TestDescription = "Verify uploading  different types of document types such as .docx,pdf,.tiff,.jpg as Favorite Documents and verify them in document repository";
                #region Login to FAST application and create a basic file
                Reports.TestStep = "Login to FAST Application file side";
                FAST_Login_IIS(regionId: _officeId);

                Reports.TestStep = "Change office to Doc Gen enabled office";
                FAST_OpenRegionOrOffice(regionId: _officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File Created Successfully");

                #endregion

                #region Navigate to NextGen Document Repository screen and clear existing favorite docs data if any

                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();

                //Pre-condition before the favorite documents data clear verification
                Reports.TestStep = "Pre-condition before the favorite documents data clear verification";
                FastDriver.NextGenDocumentRepository.ClearFavoritedocsdata();
                #endregion

                #region Upload Different format types of documents

                string[] doctype = new string[] { "Corporate Underwriting", "Escrow: Closing Disclosure", "Escrow: Closing Statements", "Escrow: Misc", "Escrow: Payoff Demand/Bills" };
                string[] docname = new string[] { "UW Hi Li Approval", "SEC-CD", "INC HUD", "Audit PKG", "PO-Commission Instructions" };


                #region Upload .tiff,jpg,.pdf,.xlsx,.docx format document
                Reports.TestStep = "Upload .tiff,jpg,.pdf,.xlsx,.docx format document";
                    int j = 0;
                    string filePath;
                    for (j = 0; j < 5; j++)
                    {
                        FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                        Reports.TestStep = "Click on Upload button";
                        FastDriver.NextGenDocumentRepository.Upload.FAClick();

                        Reports.TestStep = "Browse document";
                        
                        switch (j)
                        {
                            case 0:
                                {
                                    filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                                    FastDriver.UploadDocumentDlg.UploadFile(filePath);
                                    break;
                                }
                            case 1:
                                {
                                    filePath = Reports.DEPLOYDIR + @"\DOCXFormat.docx";
                                    FastDriver.UploadDocumentDlg.UploadFile(filePath);
                                    break;
                                }
                            case 2:
                                {
                                    filePath = Reports.DEPLOYDIR + @"\imagesJPG.jpg";
                                    FastDriver.UploadDocumentDlg.UploadFile(filePath);
                                    break;
                                }
                            case 3:
                                {
                                    filePath = Reports.DEPLOYDIR + @"\NexGen_Report.xlsx";
                                    FastDriver.UploadDocumentDlg.UploadFile(filePath);
                                    break;
                                }
                            case 4:
                                {
                                    filePath = Reports.DEPLOYDIR + @"\EMAIL_Offshore_Pdf.pdf";
                                    FastDriver.UploadDocumentDlg.UploadFile(filePath);
                                    break;
                                }

                        }                    
                        
                        Reports.TestStep = "Save the PDF Document";
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                        FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                        FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                        FastDriver.SaveDocumentDlg.DocumentType.FASelectItem(doctype[j]);
                        FastDriver.SaveDocumentDlg.DocumentName.FASelectItem(docname[j]);
                        Keyboard.SendKeys(FAKeys.TabAway);
                        FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("test");
                        Playback.Wait(2000);
                        // Verify  Add to Favorites Check box is selected by default unchecked
                        Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                        Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                        FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                        Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                        FastDriver.SaveDocumentDlg.Ok.Click();
                        FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                        FastDriver.NextGenDocumentRepository.Open();
                    }
                #endregion

                #endregion

                    #region Verify documents uploaded/created in File Documents and Favorite Documents dialog
                    Reports.TestStep = "Verify documents uploaded/created in File Documents and Favorite Documents dialog";
                for (j = 0; j < 5;j++ )
                {
                    FastDriver.NextGenDocumentRepository.Open();
                    FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", docname[j] + " test", "Name", TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.Remove.FASelectContextMenuItem();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait.. Validating Document(s)", true);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait.. Refreshing Document(s)", true);
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();                  
                    
                }

                for (j = 0; j < 5; j++)
                {
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.FavoriteDocsUIButton);
                    FastDriver.NextGenDocumentRepository.FavoriteDocsUIButton.FAMoveToElement();
                    FastDriver.NextGenDocumentRepository.FavoriteDocsUIButton.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done);
                    FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table.PerformTableAction(2 + j, 3, TableAction.GetCell).Element.FindElement(By.TagName("img")).FAClick();
                    FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForDocument("PO-Commission Instructions test", "Escrow: Payoff Demand/Bills");
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify format types after creating documents from Favorites Documents dialog";                                  
                Support.AreEqual("View thumbnails", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, "UW Hi Li Approval test", 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName,"img").FAGetAttribute("title"));
                Support.AreEqual("view DOCX", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, "SEC-CD test", 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "img").FAGetAttribute("title"));
                Support.AreEqual("view PDF", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, "PO-Commission Instructions test", 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "img").FAGetAttribute("title"));
                Support.AreEqual("view JPG", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, "INC HUD test", 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "img").FAGetAttribute("title"));
                Support.AreEqual("view XLSX", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, "Audit PKG test", 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "img").FAGetAttribute("title"));
                Playback.Wait(1000);

                 
              

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase_929330 Verify System should not throw any error   when user is able to upload a documents and add it to Favorite Documents List with a maximum limit of 15 documents and removes one document from the Favorite Docs List
        [TestMethod]
        public void TestCase_929330()
        {
            try
            {
                Reports.TestDescription = "Verify System should not throw any error   when user is able to upload a documents and add it to Favorite Documents List with a maximum limit of 15 documents and removes one document from the Favorite Docs List";
                #region Login to FAST application and create a basic file
                Reports.TestStep = "Login to FAST Application file side";
                FAST_Login_IIS(regionId: _officeId);

                Reports.TestStep = "Change office to Doc Gen enabled office";
                FAST_OpenRegionOrOffice(regionId: _officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File Created Successfully");

                #endregion

                #region Navigate to NextGen Document Repository screen and clear existing favorite docs data if any

                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();

                //Pre-condition before the favorite documents data clear verification
                Reports.TestStep = "Pre-condition before the favorite documents data clear verification";
                FastDriver.NextGenDocumentRepository.ClearFavoritedocsdata();
                #endregion

                #region Upload Documents upto 15 a maximum and verify them in favorite documents list

                string[] doctype = new string[] { "Corporate Underwriting", "Escrow: Closing Disclosure", "Escrow: Closing Statements", "Escrow: Misc", "Escrow: Payoff Demand/Bills", "Escrow: Signed Instructions", "Exchange : Delayed", "Exchange : Reverse", "Exchange : Secured", "Title: Misc", "Title: Search Package", "Title: Tax Info", "Title: Title Policy", "Title: Title Products", "Miscellaneous" };
                string[] docname = new string[] { "UW Hi Li Approval", "SEC-CD", "INC HUD", "Audit PKG", "PO-Commission Instructions", "INST-Affidavits", "REL-Documents", "MISCELLANEOUS", "SEC-CIP", "Amended", "Map-Assessor", "SEC-TAX-Tax Certificate", "Critical Docs", "Exhibit A", "PDFDocument" };
                List<string> documentname = new List<string>();
                int j;
                for (j = 0; j < 15; j++)
                {
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    Reports.TestStep = "Click on Upload button";
                    FastDriver.NextGenDocumentRepository.Upload.FAClick();

                    Reports.TestStep = "Browse document";
                    string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                    FastDriver.UploadDocumentDlg.UploadFile(filePath);

                    Reports.TestStep = "Save the PDF Document";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                    FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                    FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                    FastDriver.SaveDocumentDlg.DocumentType.FASelectItem(doctype[j]);
                    if (j == 14)
                    {
                        FastDriver.SaveDocumentDlg.WaitForScreenToLoad(FastDriver.SaveDocumentDlg.DocumentNameText);
                        FastDriver.SaveDocumentDlg.DocumentNameText.FASetText(docname[j]);
                        Keyboard.SendKeys(FAKeys.TabAway);
                        FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("test");
                        Playback.Wait(2000);
                        Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                        Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                        FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                        Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                        FastDriver.SaveDocumentDlg.Ok.Click();
                        FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                        Playback.Wait(2000);
                        break;
                    }
                    FastDriver.SaveDocumentDlg.DocumentName.FASelectItem(docname[j]);

                    documentname.Add(FastDriver.SaveDocumentDlg.DocumentName.FAGetText().ToString());
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("test");
                    Playback.Wait(2000);
                    // Verify  Add to Favorites Check box is selected by default unchecked
                    Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                    Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                    FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                    Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                    FastDriver.SaveDocumentDlg.Ok.Click();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    Playback.Wait(2000);
                }

                #endregion

                #region Verify documents uploaded/created in File Documents and Favorite Documents dialog
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Verify uploaded documents in File Documents screen";
                for (j = 0; j < 14; j++)
                {
                    var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument(docname[j], doctype[j]);
                    Support.AreEqual("True", docStatus.ToString(), docname[j] + "Document exists on the table");
                }

                string filedocs = FastDriver.NextGenDocumentRepository.DocumentsTable.FAGetText();

                Reports.TestStep = "Verify documents added in Favorite Documents";
                FastDriver.NextGenDocumentRepository.FavoriteDocsUIButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table);
                List<IWebElement> rows = FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table.FAFindElements(ByLocator.TagName, "tr").ToList();
                if (rows.Count == 16)
                {

                    foreach (IWebElement row in rows)
                    {
                        if (row == rows[0])
                            continue;
                        j = 1;
                        Support.AreEqual("True", filedocs.Contains(row.FAGetText()).ToString(), row.FAGetText() + "Document is uploaded successfully into the Favorite Documents");
                        j++;

                    }
                    Reports.StatusUpdate("Maximum 15 Documents uploaded successfully", true);
                }
                else
                {
                    Reports.StatusUpdate("15 Documents are not uploaded to favorited documents", true);
                }


                #endregion

                #region Verify Alert message after 15 documents uploaded by user and trying to add another document
                Reports.TestStep = "Verify Alert message after 15 documents uploaded by user and trying to add another document";
                FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();

                Reports.TestStep = "Browse document";
                string Path = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(Path);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Payoff Demand/Bills");
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem("PO-Invoice");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("test");
                Playback.Wait(2000);
                // Verify  Add to Favorites Check box is selected by default unchecked
                Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                FastDriver.SaveDocumentDlg.Ok.Click();

                Reports.TestStep = "Verify the alert message when adding 16th favorite document";
                string alertmsg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("You have reached maximum limit of 15 Favorite Documents! Please uncheck the 'Add to favorite document' checkbox", alertmsg);
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(false);
                FastDriver.SaveDocumentDlg.Ok.Click();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);


                #endregion

                #region Remove a document from the favorite upload list and upload a document and add to favorite documents system should not throw any error warning alert
                Reports.TestStep = "Remove a document from the favorite upload list and upload a document and add to favorite documents system should not throw any error warning alert";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.FavoriteDocsUIButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done);
                FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Table.PerformTableAction(2, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "img").FAClick();
                FastDriver.NextGenDocumentRepository.FavoriteDocsDialog_Done.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();

                Reports.TestStep = "Browse document";
                FastDriver.UploadDocumentDlg.UploadFile(Path);

                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem("Escrow: Payoff Demand/Bills");
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem("PO-Invoice");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText("test");
                Playback.Wait(2000);
                // Verify  Add to Favorites Check box is selected by default unchecked
                Reports.TestStep = "Verify Add to Favorite Documents check box is unchecked by default and after that select the check box";
                Support.AreEqual("False", FastDriver.SaveDocumentDlg.FavoriteUploadChk.IsSelected().ToString());
                FastDriver.SaveDocumentDlg.FavoriteUploadChk.FASetCheckbox(true);
                Support.AreEqual("true", FastDriver.SaveDocumentDlg.FavoriteUploadChk.FAGetAttribute("Checked").ToString());
                FastDriver.SaveDocumentDlg.Ok.Click();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Reports.StatusUpdate("System didn't throw any alert message while uploading one more document and made it as favorite", true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion
                
        #region TestCase_929379 Verify "Add to Favorite Documents" check box in save uploaded docs dialog should not be effected in any other region/office except Doc Gen enable region/office
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void TestCase_929379()
        {
            try
            {

                // Data **********
                string docType = "Escrow: Payoff Demand/Bills";
                string docName = "Miscellaneous";
                string addtlInfo = "PDFDocument";                
                //**********Data//
                Reports.TestDescription = "Verify Add to Favorite Documents check box in save uploaded docs dialog should not be effected in any other region/office except Doc Gen enable region/office";

                Reports.TestStep = "Login to FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                string fileNumber = "";

                #region create file
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                    Thread.Sleep(5000); //Wait for file data
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion


                Reports.TestStep = "Navigate to Document Repository and Upload and save uploaded doc, Verify \"Add to Favorite Documents\" check box should not be available";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                try
                {
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.DocumentsTab);
                    FastDriver.DocumentRepository.DocumentsTab.FAClick();
                    FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad(FastDriver.DocumentRepository.Upload);
                    FastDriver.DocumentRepository.Upload.FAClick();
                }
                catch
                {
                    Reports.TestStep = "First try failed, try Submit on Upload button";
                    Thread.Sleep(5000);
                    FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForElementToLoad(FastDriver.DocumentRepository.DocumentsTab);
                    FastDriver.DocumentRepository.DocumentsTab.FAClick();
                    FastDriver.DocumentRepository.WaitForDocumentsScreenToLoad(FastDriver.DocumentRepository.DocumentsUpload);
                    FastDriver.DocumentRepository.DocumentsUpload.FAClick();
                }

                Reports.TestStep = "Browse document.";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);                
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.WaitForScreenToLoad();
                FastDriver.SaveDocumentDlg.SwitchToDialogContentFrame();
                FastDriver.SaveDocumentDlg.WaitCreation(FastDriver.SaveDocumentDlg.DocumentType);
                FastDriver.SaveDocumentDlg.DocumentType.FASelectItem(docType);
                FastDriver.SaveDocumentDlg.DocumentName.FASelectItem(docName);
                string documentname = FastDriver.SaveDocumentDlg.DocumentName.FAGetText();
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SaveDocumentDlg.AdditionalInfo.FASetText(addtlInfo);
                Playback.Wait(2000);
                // Verify  Add to Favorites Check box should not be available
                Reports.TestStep = "Verify Add to Favorite Documents check box should not be available in the Save upload documents dialog";
                Support.value = FastDriver.WebDriver.FAFindElement(ByLocator.Id,"trFavoriteUpload").FAGetAttribute("style");
                Support.AreEqual("display: none;", Support.value);
                FastDriver.SaveDocumentDlg.Ok.Click();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);


                
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion
        //TO: DO
        #region TestCase_935913 Verify Image Trigger should trigger workflow task accordingly if task is setup to to image trigger, When uploaded document has image trigger and added from Favorite Documents list, Verify notification attachment
        [TestMethod]
        public void TestCase_935913()
        {
            try
            {
                Reports.TestDescription = "Verify Image Trigger should trigger workflow task accordingly if task is setup to to image trigger, When uploaded document has image trigger and added from Favorite Documents list, Verify notification attachment";
                Reports.TestStep = "Login to FAST ADM";
                FAST_Login_ADM(false,regionId: _regionId);

                #region Verify existing task template or create a new task template
                Reports.TestStep = "Verify existing task template or create a new task template";
                FastDriver.TaskTemplateSelection.Open();
                bool taskexists = FastDriver.TaskTemplateSelection.CheckIfTaskExists("Task935913");
                if(taskexists == false)
                {
                    int RowCount = FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount();
                    FastDriver.TaskTemplateSelection.New.FAClick();
                    FastDriver.WebDriver.WaitForActionToComplete(() =>
                    {
                        return RowCount < FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount(); //continue when new row is added
                    }, timeout: 30, idleInterval: 1);
                    FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
                    FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(RowCount + 1, 3, TableAction.SetText, "Task935913");
                    FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(RowCount + 1, 5, TableAction.SelectItem, "Yes");
                    Playback.Wait(2000);
                    FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(RowCount + 1, 4, TableAction.SetText, "Task935913");
                    FastDriver.BottomFrame.Save();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    Thread.Sleep(5000);
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                    Reports.TestStep = "Select the template and navigate to notification setup";
                    FastDriver.TaskTemplateSelection.WaitForScreenToLoad(FastDriver.TaskTemplateSelection.TasksForTable);
                    FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction("Task Name", "Task935913", "Task Name", TableAction.Click);
                    Playback.Wait(2000);
                    Support.AreEqual("true", FastDriver.TaskTemplateSelection.Notification.IsEnabled().ToString());
                    FastDriver.TaskTemplateSelection.Notification.FAClick();
                    FastDriver.NotificationSummary.SwitchToContentFrame();

                    Reports.TestStep = "Validate that same task name appear in the screen";
                    FastDriver.NotificationSetup.TaskStatus.FASelectItem("Started");
                    FastDriver.NotificationSetup.DeliveryMethod.FASelectItem("Email");

                    Reports.TestStep = "Click on File Roles.";
                    FastDriver.NotificationSetup.FileRoles.FAClick();

                    FastDriver.SelectFBPRolesDlg.SwitchToDialogContentFrame();
                    Playback.Wait(3000);
                    FastDriver.SelectFBPRolesDlg.Table.PerformTableAction(2, "Business Source", 1, TableAction.Click);
                    Playback.Wait(1000);

                    FastDriver.SelectFBPRolesDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.NotificationSetup.SwitchToContentFrame();

                    Reports.TestStep = "Enter data element";
                    FastDriver.NotificationSetup.SubjectLine.FASetText("^BSNAM1^");

                    Reports.TestStep = "Select Designed Sender.";
                    FastDriver.NotificationSetup.AvailabeSender.FASelectItem("Designated Sender");

                    Reports.TestStep = "Click on right direction.";
                    FastDriver.NotificationSetup.RightDirectionArrow.FAClick();

                    Reports.TestStep = "Enter Name for designated sender.";
                    FastDriver.NotificationSetup.DesignatedSenderName.FASetText("Designated sender name");

                    Reports.TestStep = "Enter Email address designated sender.";
                    FastDriver.NotificationSetup.DesignatedSenderEmailAddress.FASetText("designated@firstam.com");

                    Reports.TestStep = "Click on Message Template Select.";
                    FastDriver.NotificationSetup.Select.FAClick();

                    Reports.TestStep = "Select the message template.";
                    FastDriver.MessageTemplateSelectionDlg.SwitchToDialogContentFrame();
                    FastDriver.MessageTemplateSelectionDlg.FindNow.FAClick();

                    FastDriver.MessageTemplateSelectionDlg.SearchResults.PerformTableAction(3, "Active", 3, TableAction.Click);
                    Playback.Wait(2000);
                    FastDriver.MessageTemplateSelectionDlg.Select.FAClick();
//TO DO

                    FastDriver.NotificationSetup.SwitchToContentFrame();
                    Reports.TestStep = "Setup Image Trigger under Image(s) Section";
                    FastDriver.NotificationSetup.ImagesAddRemove.FAClick();
                    FastDriver.ImageSelectionDlg.WaitCreation(FastDriver.ImageSelectionDlg.Select, true);
                    FastDriver.ImageSelectionDlg.SwitchToContentFrame();
                    FastDriver.ImageSelectionDlg.ImageSelectionTable.PerformTableAction("Image Trigger", "1099", "Select", TableAction.Click);


                    Reports.TestStep = "Verify Notification details is not deleted.";
                    FastDriver.NotificationSetup.SwitchToContentFrame();
                    Reports.TestStep = "Click on Done.";
                    FastDriver.BottomFrame.SwitchToBottomFrame();
                    FastDriver.BottomFrame.btnSave.FAClick();
                    FastDriver.BottomFrame.btnDone.FAClick();

                }
                #endregion

                #region Login to File side and add the above create task manually to any process which is pulled and trigger the task

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase_936560 Verify if another user logged in and opened the same order where different user has already uploaded some documents and added to Favorite Documents , these should not get update in Favorite Documents list of user who has not selected as Favorite
        [TestMethod]
        public void TestCase_936560()
        {
            try
            {
                Reports.TestDescription = "Verify if another user logged in and opened the same order where different user has already uploaded some documents and added to Favorite Documents , these should not get update in Favorite Documents list of user who has not selected as Favorite";

            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region TestCase_938130 Verify when User uploads 15 documents in the same order and when the same user creates another order, System should throw an warning message
        [TestMethod]
        public void TestCase_938130()
        {
            try
            {
                Reports.TestDescription = "Verify when User uploads 15 documents in the same order and when the same user creates another order, System should throw an warning message";

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region TestCase_938131 Verify when User uploads say few documents in an order1 and the same user creates another order2, Adding to favorite option should be enabled
        [TestMethod]
        public void TestCase_938131()
        {
            try
            {
                Reports.TestDescription = "Verify when User uploads say few documents in an order1 and the same user creates another order2, Adding to favorite option should be enabled";

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region TestCase_940795 Verify Image Trigger event for Process and Task when favorite document is created
        [TestMethod]
        public void TestCase_940795()
        {
            try
            {
                Reports.TestDescription = "Verify Image Trigger event for Process and Task when favorite document is created";

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region TestCase_943310 Verify Purge the Image from the order from which it has been added to favorites
        [TestMethod]
        public void TestCase_943310()
        {
            try
            {
                Reports.TestDescription = "Verify Purge the Image from the order from which it has been added to favorites";

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region TestCase_943366 Verify Document Name should not reflect in order when document name is modified in the source order "But is should reflect only on Favorite Documents"
        [TestMethod]
        public void TestCase_943366()
        {
            try
            {
                Reports.TestDescription = "Verify Document Name should not reflect in order when document name is modified in the source order,But is should reflect only on Favorite Documents";

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion


        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
