﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Windows.Input;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using FASTSelenium.DataObjects;

namespace NextGenDocPrep.r12._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_781362 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS"; 
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            

            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Endrosement two phrase ***AUTOMATION DNT***");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Endrosement two phrase ***AUTOMATION DNT***", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        private void LoadTemplateOrCreateNewWithoutLogin(string templateName, string templateDesc, string templateType)
        {
            
            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Endrosement two phrase ***AUTOMATION DNT***");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Endrosement two phrase ***AUTOMATION DNT***", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        private void InsertPhrase(string tplPhraseName, string phraseDescription)
        {
            FastDriver.DocumentEditor.InsertPhraseBelowAndSave(tplPhraseName, phraseDescription);
        }
       

        

        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928894_No_1()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that Create All Documents option in the Context Menu will be disabled if the search result is not obtained by keyword or favorite search";

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen to add 1st document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all template using template search criteria";
            
               
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);
                Reports.TestStep = "Select any template from Template Results , Right click and verify Create All Documents option is disable";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("DISABLEDCSS", FastDriver.NextGenDocumentRepository.CreateAllDocuments.FAGetAttribute("class").ToString().ToUpper().Trim(), "Create All Documents option is disable");
            

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928896_No_2()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will allow the user to create all the documents obtained by keyword search";


                string EGtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                EGtempnameanddesc = "EG-" + EGtempnameanddesc;

                string EItempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                EItempnameanddesc = "EI-" + EItempnameanddesc;

                string FOtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                FOtempnameanddesc = "FO-" + FOtempnameanddesc;

                string LRDtempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                LRDtempnameanddesc = "LD-" + LRDtempnameanddesc;

                string KewwordValue = Support.RandomString("NNAANNAANNAANNAANNAA").ToString();

                LoadTemplateOrCreateNew(EGtempnameanddesc, EGtempnameanddesc, "Endorsement/Guarantee");

                LoadTemplateOrCreateNewWithoutLogin(EItempnameanddesc, EItempnameanddesc, "Escrow Instruction");

                LoadTemplateOrCreateNewWithoutLogin(FOtempnameanddesc, FOtempnameanddesc, "Form");

                LoadTemplateOrCreateNewWithoutLogin(LRDtempnameanddesc, LRDtempnameanddesc, "Legal/Recordable Doc");
                

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", EGtempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);
                
                Reports.TestStep = "Enter value in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(EItempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", EItempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Enter value in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Form");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(FOtempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", FOtempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Enter value in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);


                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Legal/Recordable Doc");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(LRDtempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", LRDtempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Enter value in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);


                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
              
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for the templates created in ADM";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.Id, "ddl_FilterTypes_2").FASelectItem("Keywords");
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.keywordsValues.FASetText(KewwordValue);
                Playback.Wait(3000);
                Reports.TestStep = "Select any template from Template Results , Right click and verify Create All Documents option is disable";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("DISABLEDCSS", FastDriver.NextGenDocumentRepository.CreateAllDocuments.FAGetAttribute("class").ToString().ToUpper().Trim(), "Create All Documents option is disable");
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);
                     
                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "DO YOU WISH TO CREATE ALL TEMPLATES?", "Error Message Verified");


                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg1 = FastDriver.WebDriver.HandleDialogMessage();
                errormsg1 = errormsg1.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg1, "DO YOU WISH TO CREATE ALL TEMPLATES?", "Error Message Verified");
                Playback.Wait(5000);

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Added");   
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Instruction- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(FOtempnameanddesc).ToString(), "Form- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LRDtempnameanddesc).ToString(), "Legal/Recordable Doc- Added");

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EGtempnameanddesc).ToString(), "Endorsement- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Instruction- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(FOtempnameanddesc).ToString(), "Form- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LRDtempnameanddesc).ToString(), "Legal/Recordable Doc- Added");
                
                         
            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928897_No_3()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will allow the user to create all the documents obtained by favorite search";


                string TRtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                TRtempnameanddesc = "TR-" + TRtempnameanddesc;
                
                string LPtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                LPtempnameanddesc = "LP-" + LPtempnameanddesc;

                string OPtempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                OPtempnameanddesc = "OP-" + OPtempnameanddesc;

                string EItempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                EItempnameanddesc = "EI-" + EItempnameanddesc;

                LoadTemplateOrCreateNew(TRtempnameanddesc, TRtempnameanddesc, "Title Reports");
                
                LoadTemplateOrCreateNewWithoutLogin(LPtempnameanddesc, LPtempnameanddesc, "Lender Policy");

                LoadTemplateOrCreateNewWithoutLogin(OPtempnameanddesc, OPtempnameanddesc, "Owner Policy");

                LoadTemplateOrCreateNewWithoutLogin(EItempnameanddesc, EItempnameanddesc, "Escrow Instruction");
                
                
                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                Playback.Wait(3000);
                Reports.TestStep = "Select any template from Template Results , Right click and verify Create All Documents option is disable";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("DISABLEDCSS", FastDriver.NextGenDocumentRepository.CreateAllDocuments.FAGetAttribute("class").ToString().ToUpper().Trim(), "Create All Documents option is disable");
                Playback.Wait(3000);

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Making all favorite template as non favorite";
                int fav_count = FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.GetRowCount();
                
                for (int i = 1; i <= fav_count; i++)
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 4, TableAction.Click);
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_rfav").FAClickAction();
                    Playback.Wait(2000);
                }


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TRtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Title Report as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);


                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Lender Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(LPtempnameanddesc);
               
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Lender Policy as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Owner Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(OPtempnameanddesc);
               
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Owner Policy as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EItempnameanddesc);
              
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Escrow Instruction as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
              
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(5000);
                
                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4,EItempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "DO YOU WISH TO CREATE ALL TEMPLATES?", "Error Message Verified");


                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4,EItempnameanddesc,4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg1 = FastDriver.WebDriver.HandleDialogMessage();
                errormsg1 = errormsg1.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg1, "DO YOU WISH TO CREATE ALL TEMPLATES?", "Error Message Verified");
                Playback.Wait(5000);

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TRtempnameanddesc).ToString(), "Title Report- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Instruction- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString(), "Owner Policy- Added");

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TRtempnameanddesc).ToString(), "Title Report- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EItempnameanddesc).ToString(), "Escrow Instruction- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString(), "Owner Policy- Added");


            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928899_No_4()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will not allow the user to create multiple title report documents obtained by keyword search";


                string TR1tempnameanddesc = Support.RandomString("ANANANANAN").ToString();
                TR1tempnameanddesc = "TR1-" + TR1tempnameanddesc;

                string TR2tempnameanddesc = Support.RandomString("NANANANANA").ToString();
                TR2tempnameanddesc = "TR2-" + TR2tempnameanddesc;

                string KewwordValue = Support.RandomString("NNAANNAANNAANNAANNAAN").ToString();

                LoadTemplateOrCreateNew(TR1tempnameanddesc, TR1tempnameanddesc, "Title Reports");

                LoadTemplateOrCreateNewWithoutLogin(TR2tempnameanddesc, TR2tempnameanddesc, "Title Reports");
                                             

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(TR1tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", TR1tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Enter value in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(TR2tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", TR2tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Enter value in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

            
                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for the templates created in ADM";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.Id, "ddl_FilterTypes_2").FASelectItem("Keywords");
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.keywordsValues.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, TR1tempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "ONLY ONE TITLE REPORT CAN BE CREATED AT A TIME", "Error Message Verified");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the documents are not created documents list";

                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.Exists().ToString(), "Document Table doesnot exist");
                

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928901_No_5()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will not allow the user to create multiple title report documents obtained by favorite search";


                string TR1tempnameanddesc = Support.RandomString("ANANANANAN").ToString();
                TR1tempnameanddesc = "TR1-" + TR1tempnameanddesc;

                string TR2tempnameanddesc = Support.RandomString("NANANANANA").ToString();
                TR2tempnameanddesc = "TR2-" + TR2tempnameanddesc;
                              

                LoadTemplateOrCreateNew(TR1tempnameanddesc, TR1tempnameanddesc, "Title Reports");

                LoadTemplateOrCreateNewWithoutLogin(TR2tempnameanddesc, TR2tempnameanddesc, "Title Reports");


                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Making all favorite template as non favorite";
                int fav_count = FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.GetRowCount();

                for (int i = 1; i <= fav_count; i++)
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 4, TableAction.Click);
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_rfav").FAClickAction();
                    Playback.Wait(2000);
                }


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TR1tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Title Report as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);


                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TR2tempnameanddesc);

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Title Report as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);
                

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, TR1tempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "ONLY ONE TITLE REPORT CAN BE CREATED AT A TIME", "Error Message Verified");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the documents are not created documents list";

                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.Exists().ToString(), "Document Table doesnot exist");
                

           

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928902_No_6()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will not allow the user to create multiple Policy documents obtained by keyword search if there is no Title Report in the file";


              
                string LPtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                LPtempnameanddesc = "LP-" + LPtempnameanddesc;

                string OPtempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                OPtempnameanddesc = "OP-" + OPtempnameanddesc;

                string KewwordValue = Support.RandomString("NNAANNAANNAANNAANNAA").ToString();   
         

                LoadTemplateOrCreateNew(LPtempnameanddesc, LPtempnameanddesc, "Lender Policy");

                LoadTemplateOrCreateNewWithoutLogin(OPtempnameanddesc, OPtempnameanddesc, "Owner Policy");
                               


                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Lender Policy");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(LPtempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", LPtempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Enter value in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Owner Policy");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(OPtempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", OPtempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Enter value in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

            
                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for the templates created in ADM";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.Id, "ddl_FilterTypes_2").FASelectItem("Keywords");
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.keywordsValues.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, LPtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "NO COMMITMENT DOCUMENT ON FILE.", "Error Message Verified");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the documents are not created documents list";

                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.Exists().ToString(), "Document Table doesnot exist");
                
               

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928904_No_7()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will not allow the user to create multiple Policy documents obtained by favorite search if there is no Title Report in the file";


               
                string LPtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                LPtempnameanddesc = "LP-" + LPtempnameanddesc;

                string OPtempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                OPtempnameanddesc = "OP-" + OPtempnameanddesc;
                              

                LoadTemplateOrCreateNew(LPtempnameanddesc, LPtempnameanddesc, "Lender Policy");

                LoadTemplateOrCreateNewWithoutLogin(OPtempnameanddesc, OPtempnameanddesc, "Owner Policy");
                

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Making all favorite template as non favorite";
                int fav_count = FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.GetRowCount();

                for (int i = 1; i <= fav_count; i++)
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 4, TableAction.Click);
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_rfav").FAClickAction();
                    Playback.Wait(2000);
                }


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Lender Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(LPtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Lender Policy as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);
                
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Owner Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(OPtempnameanddesc);

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Owner Policy as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);

              
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, LPtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);


                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "NO COMMITMENT DOCUMENT ON FILE.", "Error Message Verified");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the documents are not created documents list";

                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.Exists().ToString(), "Document Table doesnot exist");
                
               


            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928906_No_8()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will not allow the user to create Policy and Endorsement documents together obtained by keyword search";


                string EGtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                EGtempnameanddesc = "EG-" + EGtempnameanddesc;
                            
                string LPtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                LPtempnameanddesc = "LP-" + LPtempnameanddesc;

                string OPtempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                OPtempnameanddesc = "OP-" + OPtempnameanddesc;

                string KewwordValue = Support.RandomString("NNAANNAANNAANNAANNAA").ToString();


                LoadTemplateOrCreateNew(EGtempnameanddesc, EGtempnameanddesc, "Endorsement/Guarantee");

                LoadTemplateOrCreateNewWithoutLogin(LPtempnameanddesc, LPtempnameanddesc, "Lender Policy");

                LoadTemplateOrCreateNewWithoutLogin(OPtempnameanddesc, OPtempnameanddesc, "Owner Policy");
                             

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", EGtempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Enter value in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Lender Policy");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(LPtempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", LPtempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Enter value in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Owner Policy");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(OPtempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", OPtempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Enter value in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);


                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for the templates created in ADM";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.Id, "ddl_FilterTypes_2").FASelectItem("Keywords");
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.keywordsValues.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);


                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "ENDORSEMENT AND POLICY DOCUMENTS CANNOT BE CREATED AT THE SAME TIME.", "Error Message Verified");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the documents are not created documents list";

                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.Exists().ToString(), "Document Table doesnot exist");
              
            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928908_No_9()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will not allow the user to create Policy and Endorsement documents together obtained by favorite search";


                string EGtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                EGtempnameanddesc = "EG-" + EGtempnameanddesc;

                string LPtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                LPtempnameanddesc = "LP-" + LPtempnameanddesc;

                string OPtempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                OPtempnameanddesc = "OP-" + OPtempnameanddesc;

            
                LoadTemplateOrCreateNew(EGtempnameanddesc, EGtempnameanddesc, "Endorsement/Guarantee");

                LoadTemplateOrCreateNewWithoutLogin(LPtempnameanddesc, LPtempnameanddesc, "Lender Policy");

                LoadTemplateOrCreateNewWithoutLogin(OPtempnameanddesc, OPtempnameanddesc, "Owner Policy");


                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Making all favorite template as non favorite";
                int fav_count = FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.GetRowCount();

                for (int i = 1; i <= fav_count; i++)
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 4, TableAction.Click);
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_rfav").FAClickAction();
                    Playback.Wait(2000);
                }


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a template using template search criteria";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EGtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Endorsement as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);


                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Lender Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(LPtempnameanddesc);

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Lender Policy as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Owner Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(OPtempnameanddesc);

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Owner Policy as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);

             
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EGtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "ENDORSEMENT AND POLICY DOCUMENTS CANNOT BE CREATED AT THE SAME TIME.", "Error Message Verified");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the documents are not created documents list";

                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.DocumentsTable.Exists().ToString(), "Document Table doesnot exist");
              

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928909_No_10()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will display the selection popup on create multiple Policy documents obtained by keyword search if file has multiple Title Report";


                string TR1tempnameanddesc = Support.RandomString("ANANANANAN").ToString();
                TR1tempnameanddesc = "TR1-" + TR1tempnameanddesc;

                string TR2tempnameanddesc = Support.RandomString("NANANANANA").ToString();
                TR2tempnameanddesc = "TR2-" + TR2tempnameanddesc;

                string LPtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                LPtempnameanddesc = "LP-" + LPtempnameanddesc;

                string OPtempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                OPtempnameanddesc = "OP-" + OPtempnameanddesc;

                string KewwordValue = Support.RandomString("NNAANNAANNAANNAANNAA").ToString();


                LoadTemplateOrCreateNew(TR1tempnameanddesc, TR1tempnameanddesc, "Title Reports");

                LoadTemplateOrCreateNewWithoutLogin(TR2tempnameanddesc, TR2tempnameanddesc, "Title Reports");

                LoadTemplateOrCreateNewWithoutLogin(LPtempnameanddesc, LPtempnameanddesc, "Lender Policy");

                LoadTemplateOrCreateNewWithoutLogin(OPtempnameanddesc, OPtempnameanddesc, "Owner Policy");

        

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Lender Policy");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(LPtempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", LPtempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Enter value in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Owner Policy");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(OPtempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", OPtempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Enter value in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Title Reports type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TR1tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, TR1tempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString();
                docName1 = docName1.Trim();
                Support.AreEqual("True", docName1, "Title Reports exists on the Search Result Table");


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Title Reports type template using template search criteria";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TR2tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, TR2tempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName2 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR2tempnameanddesc).ToString();
                docName2 = docName2.Trim();
                Support.AreEqual("True", docName2, "Title Reports exists on the Search Result Table");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for the templates created in ADM";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.Id, "ddl_FilterTypes_2").FASelectItem("Keywords");
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.keywordsValues.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, LPtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg1 = FastDriver.WebDriver.HandleDialogMessage();
                errormsg1 = errormsg1.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg1, "DO YOU WISH TO CREATE ALL TEMPLATES?", "Error Message Verified");
                Playback.Wait(5000);

                Reports.TestStep = "Associate policy with first title report";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.LinkTemplateToDocuments(1);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");

                Playback.Wait(7000);

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString(), "Title Report 1- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR2tempnameanddesc).ToString(), "Title Report 2- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString(), "Owner Policy- Added");

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR1tempnameanddesc).ToString(), "Title Report 1- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TR2tempnameanddesc).ToString(), "Title Report 2- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString(), "Owner Policy- Added");

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928910_No_11()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will display the selection popup on create multiple Endorsement documents obtained by favorite search if file has multiple Policies";


                string TRtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                TRtempnameanddesc = "TR-" + TRtempnameanddesc;

                string LPtempnameanddesc = Support.RandomString("ANANANANANA").ToString();
                LPtempnameanddesc = "LP-" + LPtempnameanddesc;

                string OPtempnameanddesc = Support.RandomString("NANANANANAN").ToString();
                OPtempnameanddesc = "OP-" + OPtempnameanddesc;

                string EG1tempnameanddesc = Support.RandomString("ANANANANAN").ToString();
                EG1tempnameanddesc = "EG1-" + EG1tempnameanddesc;

                string EG2tempnameanddesc = Support.RandomString("NANANANANA").ToString();
                EG2tempnameanddesc = "EG2-" + EG2tempnameanddesc;
                

                LoadTemplateOrCreateNew(TRtempnameanddesc, TRtempnameanddesc, "Title Reports");

                LoadTemplateOrCreateNewWithoutLogin(LPtempnameanddesc, LPtempnameanddesc, "Lender Policy");

                LoadTemplateOrCreateNewWithoutLogin(OPtempnameanddesc, OPtempnameanddesc, "Owner Policy");

                LoadTemplateOrCreateNewWithoutLogin(EG1tempnameanddesc, EG1tempnameanddesc, "Endorsement/Guarantee");

                LoadTemplateOrCreateNewWithoutLogin(EG2tempnameanddesc, EG2tempnameanddesc, "Endorsement/Guarantee");


                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");



                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Title Reports type template using template search criteria";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TRtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, TRtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TRtempnameanddesc).ToString();
                docName1 = docName1.Trim();
                Support.AreEqual("True", docName1, "Title Reports exists on the Search Result Table");



                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Title Reports type template using template search criteria";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Lender Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(LPtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, LPtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName2 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString();
                docName2 = docName2.Trim();
                Support.AreEqual("True", docName2, "Lender Policy exists on the Search Result Table");



                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Title Reports type template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Owner Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(OPtempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, OPtempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName3 = FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString();
                docName3 = docName3.Trim();
                Support.AreEqual("True", docName3, "Owner Policy exists on the Search Result Table");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Making all favorite template as non favorite";
                int fav_count = FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.GetRowCount();

                for (int i = 1; i <= fav_count; i++)
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 4, TableAction.Click);
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_rfav").FAClickAction();
                    Playback.Wait(2000);
                }


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EG1tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Endorsement/Guarantee 1 as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);


                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EG2tempnameanddesc);

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Endorsement/Guarantee 2 as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EG1tempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg1 = FastDriver.WebDriver.HandleDialogMessage();
                errormsg1 = errormsg1.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg1, "DO YOU WISH TO CREATE ALL TEMPLATES?", "Error Message Verified");
                Playback.Wait(5000);

                Reports.TestStep = "Associate endorsement with second policy";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.LinkTemplateToDocuments(2);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");

                Playback.Wait(7000);

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TRtempnameanddesc).ToString(), "Title Report- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString(), "Owner Policy- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EG1tempnameanddesc).ToString(), "Endorsement 1- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EG2tempnameanddesc).ToString(), "Endorsement 2- Added");

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(TRtempnameanddesc).ToString(), "Title Report- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(LPtempnameanddesc).ToString(), "Lender Policy- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(OPtempnameanddesc).ToString(), "Owner Policy- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EG1tempnameanddesc).ToString(), "Endorsement 1- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EG2tempnameanddesc).ToString(), "Endorsement 2- Added");


            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928912_No_12()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will display the selection popup on creating documents having '?' indexed data elements obtained by keyword search";


                string EG1tempnameanddesc = Support.RandomString("ANANANANAN").ToString();
                EG1tempnameanddesc = "EG1-" + EG1tempnameanddesc;

                string EG2tempnameanddesc = Support.RandomString("NANANANANA").ToString();
                EG2tempnameanddesc = "EG2-" + EG2tempnameanddesc;

              
                string KewwordValue = Support.RandomString("NNAANNAANNAANNAANNAAN").ToString();

                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create new phrase group
                Reports.TestStep = "Create new phrase group";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                var groupName = Support.RandomString("ANAN");
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);
                var groupDescription = "TEST--" + Support.RandomString("AN".Repeat(17));
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Endorsement Phrase[ENDORSE]");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                #endregion

                #region Create phrases
                Reports.TestStep = "Create phrases";
                FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                var phraseName = Support.RandomString("ANAN");
                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);
                var phraseDescription = "TEST--" + Support.RandomString("AN".Repeat(17));
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                #endregion

                #region Add data element
                Reports.TestStep = "Add data element";
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.InsertDataElementwithIDandIndex("BUNAME, SENAME","?");
               
                #endregion

                #region Create template
                Reports.TestStep = "Create template";
                                
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);

                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(EG1tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(EG1tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                #endregion

                #region Insert Phrases
                Reports.TestStep = "Insert Phrases";
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertPhrase(groupName + "/" + phraseName, phraseDescription);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status") == "true")
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    // just to make sure !
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                    FastDriver.NextGenDocumentPreparation.Inactive.FAClick();
                    FastDriver.NextGenDocumentPreparation.Active.FAClick();
                }
                Support.AreEqual("false", FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status"));
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                #region Create template
                Reports.TestStep = "Create template";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);

                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(EG2tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(EG2tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                #endregion

                #region Insert Phrases
                Reports.TestStep = "Insert Phrases";
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertPhrase(groupName + "/" + phraseName, phraseDescription);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status") == "true")
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    // just to make sure !
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                    FastDriver.NextGenDocumentPreparation.Inactive.FAClick();
                    FastDriver.NextGenDocumentPreparation.Active.FAClick();
                }
                Support.AreEqual("false", FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status"));
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                         

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                #region Create File
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");

                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItemBySendingKeys("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    FastDriver.BottomFrame.Done();
                }
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

               
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for the templates created in ADM";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.Id, "ddl_FilterTypes_2").FASelectItem("Keywords");
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.keywordsValues.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EG1tempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "DO YOU WISH TO CREATE ALL TEMPLATES?", "Error Message Verified");

                Playback.Wait(5000);
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.MultiIndexValueTable1.PerformTableAction(2,1, TableAction.Click);
                FastDriver.NextGenDocumentRepository.MultiIndexValueTable2.PerformTableAction(3, 1, TableAction.Click);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");

                Playback.Wait(2000);

                FastDriver.NextGenDocumentRepository.MultiIndexValueTable1.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.NextGenDocumentRepository.MultiIndexValueTable2.PerformTableAction(2, 1, TableAction.Click);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");
                Playback.Wait(5000);

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EG1tempnameanddesc).ToString(), "Endorsement1- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EG2tempnameanddesc).ToString(), "Endorsement2- Added");

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EG1tempnameanddesc).ToString(), "Endorsement1- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EG2tempnameanddesc).ToString(), "Endorsement2- Added");
               

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928913_No_13()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will display the selection popup on creating documents having '?' indexed data elements obtained by favorite search";

                string EI1tempnameanddesc = Support.RandomString("ANANANANAN").ToString();
                EI1tempnameanddesc = "EI1-" + EI1tempnameanddesc;

                string EI2tempnameanddesc = Support.RandomString("NANANANANA").ToString();
                EI2tempnameanddesc = "EI2-" + EI2tempnameanddesc;

                               

                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create new phrase group
                Reports.TestStep = "Create new phrase group";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                var groupName = Support.RandomString("ANAN");
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);
                var groupDescription = "TEST--" + Support.RandomString("AN".Repeat(17));
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Endorsement Phrase[ENDORSE]");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                #endregion

                #region Create phrases
                Reports.TestStep = "Create phrases";
                FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                var phraseName = Support.RandomString("ANAN");
                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);
                var phraseDescription = "TEST--" + Support.RandomString("AN".Repeat(17));
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                #endregion

                #region Add data element
                Reports.TestStep = "Add data element";
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.InsertDataElementwithIDandIndex("BUNAME, SENAME", "?");

                #endregion

                #region Create template
                Reports.TestStep = "Create template";

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);

                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(EI1tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(EI1tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                #endregion

                #region Insert Phrases
                Reports.TestStep = "Insert Phrases";
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertPhrase(groupName + "/" + phraseName, phraseDescription);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status") == "true")
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    // just to make sure !
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                    FastDriver.NextGenDocumentPreparation.Inactive.FAClick();
                    FastDriver.NextGenDocumentPreparation.Active.FAClick();
                }
                Support.AreEqual("false", FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status"));
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                #region Create template
                Reports.TestStep = "Create template";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);

                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(EI2tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(EI2tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                #endregion

                #region Insert Phrases
                Reports.TestStep = "Insert Phrases";
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertPhrase(groupName + "/" + phraseName, phraseDescription);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status") == "true")
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    // just to make sure !
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                    FastDriver.NextGenDocumentPreparation.Inactive.FAClick();
                    FastDriver.NextGenDocumentPreparation.Active.FAClick();
                }
                Support.AreEqual("false", FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status"));
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion


                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);


                #region Create File
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");

                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItemBySendingKeys("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    FastDriver.BottomFrame.Done();
                }
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Making all favorite template as non favorite";
                int fav_count = FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.GetRowCount();

                for (int i = 1; i <= fav_count; i++)
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 4, TableAction.Click);
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_rfav").FAClickAction();
                    Playback.Wait(2000);
                }


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EI1tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Escrow Instruction 1 as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);


                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EI2tempnameanddesc);

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Making Escrow Instruction 2 as favorite";
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                Playback.Wait(2000);
                

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EI1tempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "DO YOU WISH TO CREATE ALL TEMPLATES?", "Error Message Verified");
                              
                Playback.Wait(5000);
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.MultiIndexValueTable1.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.NextGenDocumentRepository.MultiIndexValueTable2.PerformTableAction(3, 1, TableAction.Click);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");

                Playback.Wait(2000);

                FastDriver.NextGenDocumentRepository.MultiIndexValueTable1.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.NextGenDocumentRepository.MultiIndexValueTable2.PerformTableAction(2, 1, TableAction.Click);

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{ENTER}");
                Playback.Wait(5000);

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EI1tempnameanddesc).ToString(), "Escrow Instruction 1- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EI2tempnameanddesc).ToString(), "Escrow Instruction 2- Added");

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EI1tempnameanddesc).ToString(), "Escrow Instruction 1- Added");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EI2tempnameanddesc).ToString(), "Escrow Instruction 2- Added");
               
       

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        
        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928914_No_14()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will allow the user to create only 40 documents obtained by keyword search";

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for the templates created";
              

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
              
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.Id, "ddl_FilterTypes_2").FASelectItem("Keywords");
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.keywordsValues.FASetText("Temp");
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(15000);

                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1,4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "FIRST 40 DOCUMENTS ARE SELECTED. DO YOU WISH TO CREATE ALL TEMPLATES?", "Error Message Verified");


                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg1 = FastDriver.WebDriver.HandleDialogMessage();
                errormsg1 = errormsg1.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg1, "FIRST 40 DOCUMENTS ARE SELECTED. DO YOU WISH TO CREATE ALL TEMPLATES?", "Error Message Verified");
                Playback.Wait(30000);

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("40", FastDriver.NextGenDocumentRepository.DocTableRows.GetRowCount().ToString(), "40 documents added");

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("40", FastDriver.NextGenDocumentRepository.DocTableRows.GetRowCount().ToString(), "40 documents added");

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r12_2016_US_781362_TC_928915_No_15()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will allow the user to create only 40 documents obtained by favorite search";

                
                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Making all favorite template as non favorite";
                int fav_count = FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.GetRowCount();

                for (int i = 1; i <= fav_count; i++)
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 4, TableAction.Click);
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_rfav").FAClickAction();
                    Playback.Wait(2000);
                }


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all template using template search criteria";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");

                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.Id, "ddl_FilterTypes_2").FASelectItem("Keywords");
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.keywordsValues.FASetText("Temp");
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(15000);

                Reports.TestStep = "Making 41 template as favorite";
            

                for (int i = 1; i <= 41; i++)
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 4, TableAction.Click);
                    FastDriver.NextGenDocumentRepository.TemplatesTableInnerGrid.PerformTableAction(i, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "img_afav").FAClickAction();
                    Playback.Wait(2000);
                }
                           


                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for all favorite template";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1,4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg, "FIRST 40 DOCUMENTS ARE SELECTED. DO YOU WISH TO CREATE ALL TEMPLATES?", "Error Message Verified");


                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1,4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                string errormsg1 = FastDriver.WebDriver.HandleDialogMessage();
                errormsg1 = errormsg1.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                Support.AreEqual(errormsg1, "FIRST 40 DOCUMENTS ARE SELECTED. DO YOU WISH TO CREATE ALL TEMPLATES?", "Error Message Verified");
                Playback.Wait(20000);

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                               
                Support.AreEqual("40", FastDriver.NextGenDocumentRepository.DocTableRows.GetRowCount().ToString(), "40 documents added");

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Support.AreEqual("40", FastDriver.NextGenDocumentRepository.DocTableRows.GetRowCount().ToString(), "40 documents added");
             

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }














        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }

    
}
