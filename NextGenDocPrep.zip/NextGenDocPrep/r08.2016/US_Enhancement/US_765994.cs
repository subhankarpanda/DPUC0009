﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Windows.Input;

namespace NextGenDocPrep.r08._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_765994 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS"; 
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            

            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Endrosement two phrase ***AUTOMATION DNT***");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Endrosement two phrase ***AUTOMATION DNT***", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

       


        [TestMethod]
        public void ITR_r08_2016_US_765994_TC_819872_No_1()
        {
            try
            {

                Reports.TestDescription = "US#765994: To verify system allows to add and edit a Phrase condition from Phrases sub tab of templates which reflects in Template editor or vice-versa";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");            
                                
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);
               
              
                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select Phrase to add condition";
              
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2,3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Adding condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                FastDriver.PhraseConditionsDlg.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseConditionsDlg.DataElement.FASetText("BUNAME");
                FastDriver.PhraseConditionsDlg.Index.FASetText("");
                FastDriver.PhraseConditionsDlg.Index.FASetText("1");
                FastDriver.PhraseConditionsDlg.Operator.FASelectItem("EQ");
                FastDriver.PhraseConditionsDlg.Value.FASetText("Buyer Full Name");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select Phrase to add condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Verifying the added condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();
                                
                Playback.Wait(2000);
                Support.AreEqual("BUNAME", FastDriver.PhraseConditionsDlg.DataElement.FAGetValue().ToString());
                Support.AreEqual("1", FastDriver.PhraseConditionsDlg.Index.FAGetValue().ToString());
                Support.AreEqual("EQ", FastDriver.PhraseConditionsDlg.Operator.FAGetSelectedItem().ToString());
                Support.AreEqual("Buyer Full Name", FastDriver.PhraseConditionsDlg.Value.FAGetValue().ToString());
                Support.AreEqual("True", FastDriver.PhraseConditionsDlg.AND.IsSelected().ToString());

                Reports.TestStep = "Editing the added condition from Phrase Condition Dlg";

                FastDriver.PhraseConditionsDlg.OR.FAClick();
                Playback.Wait(1000);
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(1000);
                Keyboard.SendKeys("^{A}");
                Playback.Wait(1000);
                FastDriver.PhraseConditionsDlg.DataElement.SendKeys("SENAME");
                FastDriver.PhraseConditionsDlg.Index.FASetText("");
                FastDriver.PhraseConditionsDlg.Index.FASetText("2");
                FastDriver.PhraseConditionsDlg.Operator.FASelectItem("NE");
                FastDriver.PhraseConditionsDlg.Value.FASetText("Seller Full Name");
                FastDriver.PhraseConditionsDlg.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseConditionsDlg.DataElmts1Name.FASetText("BUNAME");
                FastDriver.PhraseConditionsDlg.DataElmts1Index.FASetText("");
                FastDriver.PhraseConditionsDlg.DataElmts1Index.FASetText("3");
                FastDriver.PhraseConditionsDlg.DataEmts1Operator.FASelectItem("NE");
                FastDriver.PhraseConditionsDlg.DataElmts1Value.FASetText("Buyer Full Name");
                
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select Phrase to add condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Verifying the edited condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                Playback.Wait(2000);
                Support.AreEqual("SENAME", FastDriver.PhraseConditionsDlg.DataElement.FAGetValue().ToString());
                Support.AreEqual("2", FastDriver.PhraseConditionsDlg.Index.FAGetValue().ToString());
                Support.AreEqual("NE", FastDriver.PhraseConditionsDlg.Operator.FAGetSelectedItem().ToString());
                Support.AreEqual("Seller Full Name", FastDriver.PhraseConditionsDlg.Value.FAGetValue().ToString());

                Support.AreEqual("BUNAME", FastDriver.PhraseConditionsDlg.DataElmts1Name.FAGetValue().ToString());
                Support.AreEqual("3", FastDriver.PhraseConditionsDlg.DataElmts1Index.FAGetValue().ToString());
                Support.AreEqual("NE", FastDriver.PhraseConditionsDlg.DataEmts1Operator.FAGetSelectedItem().ToString());
                Support.AreEqual("Buyer Full Name", FastDriver.PhraseConditionsDlg.DataElmts1Value.FAGetValue().ToString());
                Support.AreEqual("True", FastDriver.PhraseConditionsDlg.OR.IsSelected().ToString());
                FastDriver.PhraseConditionsDlg.Cancel.FAClick();
                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r08_2016_US_765994_TC_821993_No_2()
        {
            try
            {

                Reports.TestDescription = "To verify system allows to view the phrase conditions when the conditions are added from Phrases sub tab of templates";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select Phrase to add condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Adding condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                FastDriver.PhraseConditionsDlg.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseConditionsDlg.DataElement.FASetText("BUNAME");
                FastDriver.PhraseConditionsDlg.Index.FASetText("");
                FastDriver.PhraseConditionsDlg.Index.FASetText("1");
                FastDriver.PhraseConditionsDlg.Operator.FASelectItem("EQ");
                FastDriver.PhraseConditionsDlg.Value.FASetText("Daivik");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Validating the expand icon existance";

                Support.AreEqual("1", FastDriver.NextGenDocumentPreparation.GetImageCount(2, 1).ToString(), "Expand icon exists");

                Support.AreEqual("0", FastDriver.NextGenDocumentPreparation.GetImageCount(3, 1).ToString(), "Expand icon doesnot exists");
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAClick();     
                Playback.Wait(2000);
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.ViewphraseConditionAND.IsSelected().ToString(), "AND is Selected");
                Support.AreEqual("BUNAME", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 1, TableAction.GetText).Message.ToString().Trim(), "DE is Verified");
                Support.AreEqual("1", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 2, TableAction.GetText).Message.ToString().Trim(), "Index is Verified");
                Support.AreEqual("EQ", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 3, TableAction.GetText).Message.ToString().Trim(), "Operator is Verified");
                Support.AreEqual("Daivik", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString().Trim(), "Value is Verified");

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(2000);


                Reports.TestStep = "Select Phrase to edit condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Editing condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                FastDriver.PhraseConditionsDlg.OR.FAClick();
                Playback.Wait(1000);
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(1000);
                Keyboard.SendKeys("^{A}");
                Playback.Wait(1000);
                FastDriver.PhraseConditionsDlg.DataElement.SendKeys("SENAME");
                FastDriver.PhraseConditionsDlg.Index.FASetText("");
                FastDriver.PhraseConditionsDlg.Index.FASetText("?");
                FastDriver.PhraseConditionsDlg.Operator.FASelectItem("NB");
                
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Validating the changes in Condition list";
                               
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(2000);
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.ViewphraseConditionOR.IsSelected().ToString(), "OR is Selected");
                Support.AreEqual("SENAME", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 1, TableAction.GetText).Message.ToString().Trim(), "DE is Verified");
                Support.AreEqual("?", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 2, TableAction.GetText).Message.ToString().Trim(), "Index is Verified");
                Support.AreEqual("NB", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 3, TableAction.GetText).Message.ToString().Trim(), "Operator is Verified");
                Support.AreEqual("", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString().Trim(), "Value is Verified");

                Playback.Wait(2000);

                
            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r08_2016_US_765994_TC_822079_No_3()
        {
            try
            {

                Reports.TestDescription = "US#765994-To verify Phrase does not loose its phrase condtion on pulling to IIS because of versioning";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);
                Reports.TestStep = "Check UC checkbox";
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);
                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select Phrase to add condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Adding condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                FastDriver.PhraseConditionsDlg.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseConditionsDlg.DataElement.FASetText("BUNAME");
                FastDriver.PhraseConditionsDlg.Index.FASetText("");
                FastDriver.PhraseConditionsDlg.Index.FASetText("1");
                FastDriver.PhraseConditionsDlg.Operator.FASelectItem("EQ");
                FastDriver.PhraseConditionsDlg.Value.FASetText("Buyer First Name");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Saving the edited phrase";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Uncheck under construction checkbox";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Login to file side and create a basic file";

                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                              
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, tempnameanddesc).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempnameanddesc, "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, tempnameanddesc, "Document exists on the Search Result Table");

               
                  
                Reports.TestStep = "Login To Adm";

                FAST_Login_ADM(isSuperUser: false);

                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);
                
                Reports.TestStep = "Verify the added condition for phrase";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

              
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                Support.AreEqual("BUNAME", FastDriver.PhraseConditionsDlg.DataElement.FAGetValue().ToString());
                Support.AreEqual("1", FastDriver.PhraseConditionsDlg.Index.FAGetValue().ToString());
                Support.AreEqual("EQ", FastDriver.PhraseConditionsDlg.Operator.FAGetSelectedItem().ToString());
                Support.AreEqual("Buyer First Name", FastDriver.PhraseConditionsDlg.Value.FAGetValue().ToString());
                Support.AreEqual("True", FastDriver.PhraseConditionsDlg.AND.IsSelected().ToString());
                FastDriver.PhraseConditionsDlg.Cancel.FAClick();
                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);
    
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);
                Reports.TestStep = "Check UC Checkbox";

                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);
                
                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select Phrase to edit condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Editing condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                FastDriver.PhraseConditionsDlg.AND.FAClick();
                Playback.Wait(1000);
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(1000);
                Keyboard.SendKeys("^{A}");
                Playback.Wait(1000);               
                FastDriver.PhraseConditionsDlg.DataElement.SendKeys("SENAME");
                FastDriver.PhraseConditionsDlg.Index.FASetText("");
                FastDriver.PhraseConditionsDlg.Index.FASetText("2");
                FastDriver.PhraseConditionsDlg.Operator.FASelectItem("NE");
                FastDriver.PhraseConditionsDlg.Value.FASetText("Seller First Name");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Saving the edited phrase";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Uncheck UC Checkbox";
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();

                Playback.Wait(5000);
                Reports.TestStep = "Login to file side and create a basic file";

                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, tempnameanddesc).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempnameanddesc, "Name", TableAction.GetText).Message;
                Support.AreEqual(docName1, tempnameanddesc, "Document exists on the Search Result Table");

                Reports.TestStep = "Login To Adm";

                FAST_Login_ADM(isSuperUser: false);

                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Verify the edited condition for phrase";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();


                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                Support.AreEqual("SENAME", FastDriver.PhraseConditionsDlg.DataElement.FAGetValue().ToString());
                Support.AreEqual("2", FastDriver.PhraseConditionsDlg.Index.FAGetValue().ToString());
                Support.AreEqual("NE", FastDriver.PhraseConditionsDlg.Operator.FAGetSelectedItem().ToString());
                Support.AreEqual("Seller First Name", FastDriver.PhraseConditionsDlg.Value.FAGetValue().ToString());
                Support.AreEqual("True", FastDriver.PhraseConditionsDlg.AND.IsSelected().ToString());
                FastDriver.PhraseConditionsDlg.Cancel.FAClick();
                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);


            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r08_2016_US_765994_TC_822083_No_4()
        {
            try
            {

                Reports.TestDescription = "US765994-To verify system pulls the templates based on the condition";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select Phrase to add condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Adding condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                FastDriver.PhraseConditionsDlg.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseConditionsDlg.DataElement.FASetText("BUNAME");
                FastDriver.PhraseConditionsDlg.Index.FASetText("");
                FastDriver.PhraseConditionsDlg.Index.FASetText("1");
                FastDriver.PhraseConditionsDlg.Operator.FASelectItem("EQ");
                FastDriver.PhraseConditionsDlg.Value.FASetText("Buyer First Name");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Login to file side and create a basic file";

                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                #region Create File
             
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);


                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItemBySendingKeys("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                Playback.Wait(1000);
               
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    FastDriver.BottomFrame.Done();
                }
                
                #endregion

                Reports.TestStep = "Navigate to Buyer Screen and enter buyer name";
                FastDriver.BuyerSellerSetup.Open();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Buyer");
                FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText("First");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Name");
                Keyboard.SendKeys("^{D}");
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, tempnameanddesc).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempnameanddesc, "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, tempnameanddesc, "Document exists on the Search Result Table");

                Reports.TestStep = "Validating the phrases in the template";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempnameanddesc, "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                string tbldata = FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.FAGetAttribute("innerHTML").ToString().ToUpper().Trim();
                Support.AreEqual("True",tbldata.Contains("ANEP/1").ToString());

                Reports.TestStep = "Login To Adm";

                FAST_Login_ADM(isSuperUser: false);

                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select Phrase to add condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Editing condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();
             
                FastDriver.PhraseConditionsDlg.Value.FASetText("Buyer2 First Name");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Login to file side and create a basic file";

                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                #region Create File

                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);


                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItemBySendingKeys("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                Playback.Wait(1000);

                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    FastDriver.BottomFrame.Done();
                }

                #endregion

                Reports.TestStep = "Navigate to Buyer Screen and enter buyer name";
                FastDriver.BuyerSellerSetup.Open();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Buyer");
                FastDriver.BuyerSellerSetup.IndividualMiddleName.FASetText("First");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Name");
                Keyboard.SendKeys("^{D}");
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, tempnameanddesc).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName1 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempnameanddesc, "Name", TableAction.GetText).Message;
                Support.AreEqual(docName1, tempnameanddesc, "Document exists on the Search Result Table");

                Reports.TestStep = "Validating the phrases in the template";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempnameanddesc, "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                string tbldata1 = FastDriver.NextGenDocumentRepository.PhraseDataElementTable0.FAGetAttribute("innerHTML").ToString().ToUpper().Trim();
                Support.AreEqual("False", tbldata1.Contains("ANEP/1").ToString());
                string tbldata2 = FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.FAGetAttribute("innerHTML").ToString().ToUpper().Trim();
                Support.AreEqual("False", tbldata2.Contains("ANEP/1").ToString());
          


            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r08_2016_US_765994_TC_822093_No_5()
        {
            try
            {

                Reports.TestDescription = "To verify system removes the phrase condition icon as well as the condition  if the condtion is removed";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select Phrase to add condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Adding condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                FastDriver.PhraseConditionsDlg.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseConditionsDlg.DataElement.FASetText("BUNAME");
                FastDriver.PhraseConditionsDlg.Index.FASetText("");
                FastDriver.PhraseConditionsDlg.Index.FASetText("1");
                FastDriver.PhraseConditionsDlg.Operator.FASelectItem("EQ");
                FastDriver.PhraseConditionsDlg.Value.FASetText("Buyer Full Name");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Select Phrase to expand condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(2000);
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.ViewphraseConditionAND.IsSelected().ToString(), "AND is Selected");
                Support.AreEqual("BUNAME", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 1, TableAction.GetText).Message.ToString().Trim(), "DE is Verified");
                Support.AreEqual("1", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 2, TableAction.GetText).Message.ToString().Trim(), "Index is Verified");
                Support.AreEqual("EQ", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 3, TableAction.GetText).Message.ToString().Trim(), "Operator is Verified");
                Support.AreEqual("Buyer Full Name", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString().Trim(), "Value is Verified");


                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select Phrase to expand condition";
                
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(2000);
                Support.AreEqual( "True" ,FastDriver.NextGenDocumentPreparation.ViewphraseConditionAND.IsSelected().ToString(),"AND is Selected");
                Support.AreEqual("BUNAME", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 1, TableAction.GetText).Message.ToString().Trim(), "DE is Verified");
                Support.AreEqual("1", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 2, TableAction.GetText).Message.ToString().Trim(), "Index is Verified");
                Support.AreEqual("EQ", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 3, TableAction.GetText).Message.ToString().Trim(), "Operator is Verified");
                Support.AreEqual("Buyer Full Name", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString().Trim(), "Value is Verified");

                
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select Phrase to delete condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Deleting condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                FastDriver.PhraseConditionsDlg.Remove.FAClick();

                FastDriver.PhraseConditionsDlg.Done.FAClick();
                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Verify expand doesnot exist";
                Support.AreEqual("0", FastDriver.NextGenDocumentPreparation.GetImageCount(2, 1).ToString(), "Expand icon doesnot exists");
               
                Playback.Wait(2000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Verify expand doesnot exist";
                Support.AreEqual("0", FastDriver.NextGenDocumentPreparation.GetImageCount(2, 1).ToString(), "Expand icon doesnot exists");
                
                Playback.Wait(2000);

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r08_2016_US_765994_TC_823696_No_6()
        {
            try
            {

                Reports.TestDescription = "To verify system retains the condition in an expanded view on adding/removing it in the collapsed view";
                
                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select Phrase to add condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Adding condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                FastDriver.PhraseConditionsDlg.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseConditionsDlg.DataElement.FASetText("BUNAME");
                FastDriver.PhraseConditionsDlg.Index.FASetText("");
                FastDriver.PhraseConditionsDlg.Index.FASetText("1");
                FastDriver.PhraseConditionsDlg.Operator.FASelectItem("EQ");
                FastDriver.PhraseConditionsDlg.Value.FASetText("Buyer Full Name 123");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Verify phrase condition in expanded format";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.ViewphraseConditionAND.IsSelected().ToString(), "AND is Selected");
                Support.AreEqual("BUNAME", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 1, TableAction.GetText).Message.ToString().Trim(), "DE is Verified");
                Support.AreEqual("1", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 2, TableAction.GetText).Message.ToString().Trim(), "Index is Verified");
                Support.AreEqual("EQ", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 3, TableAction.GetText).Message.ToString().Trim(), "Operator is Verified");
                Support.AreEqual("Buyer Full Name 123", FastDriver.NextGenDocumentPreparation.PhraseConditionListTable.PerformTableAction(1, 4, TableAction.GetText).Message.ToString().Trim(), "Value is Verified");

                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);
                              
                Reports.TestStep = "Select Phrase to delete condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Deleting condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                FastDriver.PhraseConditionsDlg.Remove.FAClick();

                FastDriver.PhraseConditionsDlg.Done.FAClick();

                Reports.TestStep = "Verify expand doesnot exist";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                Support.AreEqual("0", FastDriver.NextGenDocumentPreparation.GetImageCount(2,1).ToString(), "Expand icon doesnot exists");
                Playback.Wait(2000);

                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);

                Reports.TestStep = "Verify expand doesnot exist";

                Support.AreEqual("0", FastDriver.NextGenDocumentPreparation.GetImageCount(2, 1).ToString(), "Expand icon doesnot exists");
                Playback.Wait(2000);
                               

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r08_2016_US_765994_TC_824195_No_7()
        {
            try
            {

                Reports.TestDescription = "To verify system displays a warining message with out saving a condition and trying to open the template editor";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select Phrase to add condition";

                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 3, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "addPhrasecdn").FAClick();

                Reports.TestStep = "Adding condition from Phrase Condition Dlg";
                FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                FastDriver.PhraseConditionsDlg.Add.FAClick();
                Playback.Wait(2000);
                FastDriver.PhraseConditionsDlg.DataElement.FASetText("BUNAME");
                FastDriver.PhraseConditionsDlg.Index.FASetText("");
                FastDriver.PhraseConditionsDlg.Index.FASetText("1");
                FastDriver.PhraseConditionsDlg.Operator.FASelectItem("EQ");
                FastDriver.PhraseConditionsDlg.Value.FASetText("Buyer Full Name");
                FastDriver.PhraseConditionsDlg.Done.FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Click on Template View button to verify the error message";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                Playback.Wait(5000);
                string error_msg= FastDriver.WebDriver.HandleDialogMessage().ToString().Trim();
                error_msg = error_msg.Replace("\r", "");
                error_msg = error_msg.Replace("\n", "");
                error_msg = error_msg.Trim();
                Support.AreEqual(error_msg, "You have made changes to this template. You must save your changes before you can edit this phrase");

                Reports.TestStep = "Saving the edited template";
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                Playback.Wait(5000);

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        


        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }

    
}
