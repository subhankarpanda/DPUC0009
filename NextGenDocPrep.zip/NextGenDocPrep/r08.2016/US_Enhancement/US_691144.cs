﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;

namespace NextGenDocPrep.r08._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_691144 : FASTHelpers
    {

        #region Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }
        #endregion

        [TestMethod]

        public void  DocGen_01_TC8095_Validate_User_ability_to_Insert_a_phrase_from_Phrases_tab_within_Template_there_by_validating_in_editor_and_preview()
        {
            try
            {
                string RandomtemplateName = Support.RandomString("AAAAAAA");


                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation 
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Create Template into Template TAB
                Reports.TestStep = "Create Template into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                #endregion             

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (true)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                }

                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion      

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion 

                #region Phrases Selection Dialogue
                Reports.TestStep = "Phrases Selection Dialogue";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseSelectDlg.Search.FAClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();  
                #endregion

                #region Click Save and Under Construction
                Reports.TestStep = "Click Save and Under Construction ";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Click Save and Template View Button
                Reports.TestStep = "Click Save and Template View Button";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                if (false)
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                }
                FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                #endregion             


                #region Click on \"Close\" Button
                Reports.TestStep = "Click on \"Close\" Button";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FASendKeys(FAKeys.Enter);   // workaround

                if (FastDriver.DocumentEditor.Yes.IsVisible(5))
                    FastDriver.DocumentEditor.Yes.FAClick();

                #endregion

                // Change a IIS 

                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search criteria All Templates Option and Created a Document
                Reports.TestStep = "Perform Select Template Search criteria All Templates Option and Created a Document";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();                
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Doble Click in Template Created
                Reports.TestStep = "Perform Doble Click in Template Created";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhrasesViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion 

              


                




            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally
            {
                SetSilverlightClipboardPermission_NO();
            }
        }



        [TestMethod]

        public void  DocGen_02_TC1524_To_verify_the_Insert_Phrase_Option_introduced_within_the_template_in_ADM()
        {
            try
            {

                string RandomtemplateName = Support.RandomString("AAAAAAA");

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion


                #region Create Template into Template TAB
                Reports.TestStep = "Create Template into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                Playback.Wait(1000);             
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Santa-Ana-Template");
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                #endregion


                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion     




            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]

        public void  DocGen_03_TC1527_To_insert_a_Phrase_within_the_template_in_ADM_side_and_create_a_document_in_file_side()
        {
            try
            {
                string RandomtemplateName = Support.RandomString("AAAAAAA");
                

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Create Template into Template TAB
                Reports.TestStep = "Create Template into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("", false);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Orange State Template");
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);               
                #endregion

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);          
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion     

                #region Phrases Selection Dialogue and Phrase Type 
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1709[1709]");              
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion      
                
                #region Click Save and Under Construction 
                Reports.TestStep = "Click Save and Under Construction ";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                // Navigate Document Repository IIS 

                #region DataSetup IIS
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search criteria All Templates Option 
                Reports.TestStep = "Perform Select Template Search criteria All Templates Option";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Orange State Template");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Doble Click in Template Created
                Reports.TestStep = "Perform Doble Click in Template Created";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhrasesViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);             
                #endregion      

            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]

        public void DocGen_04_TC1530_To_Insert_a_Phrase_within_the_already_existing_template_with_phrases_in_ADM_side_and_create_a_document_in_file_side()
        {
            try
            {

                

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion


                #region Search any Template into Template TAB
                Reports.TestStep = "Search any Template into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please.........", false);
                FastDriver.NextGenDocumentPreparation.TemplateType.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);             
                #endregion

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (false)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                }

                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion      

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion 


                #region Phrases Selection Dialogue and Phrase Type and Click Save 
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Requirements Phrase");
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("Requirements[R]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();                
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion 

                // Navigate Document Repository IIS 

                #region DataSetup IIS
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search criteria All Templates Option and Created a Document
                Reports.TestStep = "Perform Select Template Search criteria All Templates Option and Created a Document";
                FastDriver.NextGenDocumentRepository.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Doble Click in Template Created
                Reports.TestStep = "Perform Doble Click in Template Created";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhrasesViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion    




            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        

        [TestMethod]

        public void DocGen_05_TC1531_To_insert_multiple_Phrases_within_the_template_in_ADM_side_and_create_a_document_in_file_side()
        {
            try
            {

                string RandomtemplateName = Support.RandomString("AAAAAAA");

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion


                #region Create Template into Template TAB
                Reports.TestStep = "Create Template into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please........", false);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("California-State");
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please......", false);
                #endregion        
      

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion


                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion 


                #region Phrases Selection Dialogue and Phrase Type and click Save 
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type and click Save  ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Miscellaneous Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("0108 phrase group[0108]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);               
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please",false,10);
                #endregion  

               

                // Navigate Document Repository IIS 

                #region DataSetup IIS
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search criteria All Templates Option and Created a Document
                Reports.TestStep = "Perform Select Template Search criteria All Templates Option and Created a Document";
                FastDriver.NextGenDocumentRepository.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("California-State");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click, "Exchange Delayed").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Doble Click in Template Created
                Reports.TestStep = "Perform Doble Click in Template Created";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhrasesViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion    




            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


         [TestMethod]

        public void DocGen_06_TC1532_To_verify_the_versioning_of_a_template_by_inserting_a_Phrase_within_the_template_in_ADM_side()
        {
            try
            {

                string RandomtemplateName = Support.RandomString("AAAAAAA");
                

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Create Template into Template TAB
                Reports.TestStep = "Create Template into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please........", false);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Delaware-Template");
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please.....", false);
                #endregion

                #region Verify Versioning  on Template
                Reports.TestStep = "Verify Versioning  on Template ";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please.....", false,20);
                FastDriver.NextGenDocumentPreparation.VersioningTemplate.Highlight();
                #endregion

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion               

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion 

                #region Phrases Selection Dialogue and Phrase Type
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Miscellaneous Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("0108 phrase group[0108]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);   
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion


                // Navigate Document Repository IIS 

                #region DataSetup IIS
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search criteria All Templates Option
                Reports.TestStep = "Perform Select Template Search criteria All Templates Option";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Delaware-Template");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click, "Exchange Delayed").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Doble Click in Template Created
                Reports.TestStep = "Perform Doble Click in Template Created";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhrasesViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                //Come Back ADM Verify Versioning after Insert new Phrese. 

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion


                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion


                #region Find Template Created and Click View Edit
                Reports.TestStep = "Find Template Created and Click View Edit";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please.........", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please",false);
                FastDriver.NextGenDocumentPreparation.TemplateType.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Delaware-Template");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                #endregion

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion 
                
                #region Phrases Selection Dialogue and Phrase Type
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Miscellaneous Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("0108 phrase group[0108]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion             


                #region Verify Versioning  on Template
                Reports.TestStep = "Verify Versioning  on Template ";
                FastDriver.NextGenDocumentPreparation.Templates_PropertiesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.VersioningTemplate.Highlight();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please.....", false);
                #endregion



            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



         [TestMethod]

         public void DocGen_07_TC1533_To_verify_that_the_PhraseRequired_option_introduced_within_the_template_in_ADM_is_available_for_user_with_admin_access()
         {
             try
             {

                 string RandomtemplateName = Support.RandomString("AAAAAAA");

                 #region DataSetup ADM
                 Reports.TestStep = "DataSetup ADM";
                 FAST_Login_ADM(isSuperUser: false);
                 FAST_OpenRegionOrOffice(officeId);
                 #endregion


                 #region Navigate Document Preparation
                 Reports.TestStep = "Navigate Document Preparation ";
                 FastDriver.NextGenDocumentPreparation.Open();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                 #endregion


                 #region Create Template into Template TAB
                 Reports.TestStep = "Create Template into Template TAB";
                 FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                 FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please........", false);
                 FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                 FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Santa-Ana-Template");
                 FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please....", false);
                 #endregion

                 #region Click Filtering TAB Select All Select options
                 Reports.TestStep = "Click Filtering TAB Select All Select options ";
                 FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                 FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                 FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                 FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                 #endregion               

                 
                 #region Insert Phrases Option in Menu Context
                 Reports.TestStep = "Insert Phrases Option in Menu Context ";
                 FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 #endregion 


                 #region Phrases Selection Dialogue and Phrase Type
                 Reports.TestStep = "Phrases Selection Dialogue and Phrase Type ";
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                 FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                 FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.DialogBottomFrame.ClickDone();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();                 
                 FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                 #endregion 


                 #region Verify **Phrases Required Option
                 Reports.TestStep = "Verify **Phrases Required Option";
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.NextGenDocumentPreparation.PhrasesRequired.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                 #endregion



             }

             catch (Exception ex)
             {
                 FailTest(ex.Message);
             }
         }


         [TestMethod]

         public void DocGen_08_TC1535_To_verify_that_the_Phrase_name_is_appended_with_Double_asterick_when_a_phrase_is_added_as_required()
         {
             try
             {

                 string RandomtemplateName = Support.RandomString("AAAAAAA");

                 #region DataSetup ADM
                 Reports.TestStep = "DataSetup ADM";
                 FAST_Login_ADM(isSuperUser: false);
                 FAST_OpenRegionOrOffice(officeId);
                 #endregion


                 #region Navigate Document Preparation
                 Reports.TestStep = "Navigate Document Preparation ";
                 FastDriver.NextGenDocumentPreparation.Open();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                 #endregion


                 #region Create Template into Template TAB
                 Reports.TestStep = "Create Template into Template TAB";
                 FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                 FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please........", false);
                 FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                 FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Santa-Ana-Template");
                 FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please....", false);
                 #endregion

                 #region Click Filtering TAB Select All Select options
                 Reports.TestStep = "Click Filtering TAB Select All Select options ";
                 FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                 FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                 FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                 FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                 #endregion

                 #region Insert Phrases Option in Menu Context
                 Reports.TestStep = "Insert Phrases Option in Menu Context ";
                 FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 #endregion 


                 #region Phrases Selection Dialogue and Phrase Type
                 Reports.TestStep = "Phrases Selection Dialogue and Phrase Type ";
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                 FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                 FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Miscellaneous Phrase");
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("0108 phrase group[0108]");
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                 FastDriver.DialogBottomFrame.ClickDone();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                 #endregion


                 #region Verify **Phrases Required Option
                 Reports.TestStep = "Verify **Phrases Required Option";
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesRequired.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                 #endregion



             }

             catch (Exception ex)
             {
                 FailTest(ex.Message);
             }
         }


         [TestMethod]

         public void DocGen_09_TC1536_To_verify_the_delete_option_for_the_phrase_in_File_side_which_is_set_as_required_within_the_template_in_ADM()
         {
             try
             {

                 string RandomtemplateName = Support.RandomString("AAAAAAA");

                 #region DataSetup ADM
                 Reports.TestStep = "DataSetup ADM";
                 FAST_Login_ADM(isSuperUser: false);
                 FAST_OpenRegionOrOffice(officeId);
                 #endregion


                 #region Navigate Document Preparation
                 Reports.TestStep = "Navigate Document Preparation ";
                 FastDriver.NextGenDocumentPreparation.Open();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                 #endregion


                 #region Create Template into Template TAB
                 Reports.TestStep = "Create Template into Template TAB";
                 FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                 FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please........", false);
                 FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                 FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Santa-Ana-Template");
                 FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please....", false);
                 #endregion


                 #region Click Filtering TAB Select All Select options
                 Reports.TestStep = "Click Filtering TAB Select All Select options ";
                 FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                 FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                 FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                 FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                 #endregion

                 #region Insert Phrases Option in Menu Context
                 Reports.TestStep = "Insert Phrases Option in Menu Context ";
                 FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 #endregion 

                 #region Phrases Selection Dialogue and Phrase Type
                 Reports.TestStep = "Phrases Selection Dialogue and Phrase Type ";
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                 FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();                             
                 FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();  
                 FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                 FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                 FastDriver.DialogBottomFrame.ClickDone();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                 FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                 #endregion
               

                 // Navigate Document Repository IIS 

                 #region DataSetup IIS
                 var credentials = new Credentials()
                 {
                     UserName = AutoConfig.UserName,
                     Password = AutoConfig.UserPassword
                 };
                 #endregion

                 #region Login to FAST Application File Side
                 Reports.TestStep = "Login to FAST Application File Side";
                 FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                 Reports.TestStep = "Navigate to Select Office screen";
                 //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                 FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                 Reports.TestStep = "Navigate to NextGen Region/Office Level";
                 FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                 var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                 if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                     throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                 #endregion

                 #region CreateFile
                 string fileNumber = "";
                 try
                 {
                     Reports.TestStep = "Create File using web service.";
                     var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                     nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                     nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                     nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                     nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                     nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                     nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                     fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                     FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                 }
                 catch //If not able to create file via web service, create file via FAST GUI
                 {
                     Reports.TestStep = "Create File using FAST GUI.";
                     FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                     try
                     {
                         FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                     }
                     catch
                     {
                         Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                     }

                     FastDriver.QuickFileEntry.CreateStandardFile();
                     FastDriver.TopFrame.SwitchToTopFrame();
                     FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                     fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                 }
                 #endregion

                 #region  Navigate to Document Repository Screen
                 Reports.TestStep = "Navigate to Document Repository Screen";
                 FastDriver.NextGenDocumentRepository.Open();
                 #endregion

                 #region Perform Select Template Search criteria All Templates Option
                 Reports.TestStep = "Perform Select Template Search criteria All Templates Option";
                 FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                 FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                 FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                 FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                 FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Santa-Ana-Template");
                 FastDriver.NextGenDocumentRepository.Search.FAClick();
                 FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                 FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                 #endregion

                 #region Perform Doble Click in Template Created and Delete Phrase 
                 Reports.TestStep = "Perform Doble Click in Template Created";
                 FastDriver.NextGenDocumentRepository.DashboardDocuments.FADoubleClick();
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();       
                 FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                 //FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                 FastDriver.NextGenDocumentRepository.DataElementTable.FARightClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                 FastDriver.NextGenDocumentRepository.DeletePhraseTable.Highlight();
                 FastDriver.NextGenDocumentRepository.DeletePhraseTable.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                 #endregion      



             }

             catch (Exception ex)
             {
                 FailTest(ex.Message);
             }
         }


         [TestMethod]

         public void DocGen_10_TC1537_To_verify_the_versioning_of_a_template_when_the_phrase_is_added_as_required()
         {
             try
             {

                 string RandomtemplateName = Support.RandomString("AAAAAAA");

                 #region DataSetup ADM
                 Reports.TestStep = "DataSetup ADM";
                 FAST_Login_ADM(isSuperUser: false);
                 FAST_OpenRegionOrOffice(officeId);
                 #endregion


                 #region Navigate Document Preparation
                 Reports.TestStep = "Navigate Document Preparation ";
                 FastDriver.NextGenDocumentPreparation.Open();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                 #endregion


                 #region Create Template into Template TAB
                 Reports.TestStep = "Create Template into Template TAB";
                 FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                 FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please........", false);
                 FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                 FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Santa-Ana-Template");
                 FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                 FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please....", false);
                 #endregion

                 #region Click Filtering TAB Select All Select options
                 Reports.TestStep = "Click Filtering TAB Select All Select options ";
                 FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                 FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                 FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                 FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                 #endregion

                 #region Insert Phrases Option in Menu Context
                 Reports.TestStep = "Insert Phrases Option in Menu Context ";
                 FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 #endregion 

                 #region Phrases Selection Dialogue and Phrase Type
                 Reports.TestStep = "Phrases Selection Dialogue and Phrase Type ";
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                 FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                 FastDriver.DialogBottomFrame.ClickDone();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                 #endregion

                 // Navigate Document Repository IIS 

                 #region DataSetup IIS
                 var credentials = new Credentials()
                 {
                     UserName = AutoConfig.UserName,
                     Password = AutoConfig.UserPassword
                 };
                 #endregion

                 #region Login to FAST Application File Side
                 Reports.TestStep = "Login to FAST Application File Side";
                 FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                 Reports.TestStep = "Navigate to Select Office screen";
                 //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                 FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                 Reports.TestStep = "Navigate to NextGen Region/Office Level";
                 FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                 var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                 if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                     throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                 #endregion

                 #region CreateFile
                 string fileNumber = "";
                 try
                 {
                     Reports.TestStep = "Create File using web service.";
                     var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                     nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                     nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                     nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                     nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                     nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                     nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                     fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                     FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                 }
                 catch //If not able to create file via web service, create file via FAST GUI
                 {
                     Reports.TestStep = "Create File using FAST GUI.";
                     FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                     try
                     {
                         FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                     }
                     catch
                     {
                         Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                     }

                     FastDriver.QuickFileEntry.CreateStandardFile();
                     FastDriver.TopFrame.SwitchToTopFrame();
                     FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                     fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                 }
                 #endregion

                 #region  Navigate to Document Repository Screen
                 Reports.TestStep = "Navigate to Document Repository Screen";
                 FastDriver.NextGenDocumentRepository.Open();
                 #endregion

                 #region Perform Select Template Search criteria All Templates Option
                 Reports.TestStep = "Perform Select Template Search criteria All Templates Option";
                 FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                 FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                 FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                 FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                 FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Santa-Ana-Template");
                 FastDriver.NextGenDocumentRepository.Search.FAClick();
                 FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                 FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                 #endregion


                 //Come Back ADM Verify Versioning after Insert new Phrese. 

                 #region DataSetup ADM
                 Reports.TestStep = "DataSetup ADM";
                 FAST_Login_ADM(isSuperUser: false);
                 FAST_OpenRegionOrOffice(officeId);
                 #endregion


                 #region Navigate Document Preparation
                 Reports.TestStep = "Navigate Document Preparation ";
                 FastDriver.NextGenDocumentPreparation.Open();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                 #endregion


                 #region Create Template into Template TAB
                 Reports.TestStep = "Create Template into Template TAB";
                 FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please.........", false);
                 FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please.........", false);
                 FastDriver.NextGenDocumentPreparation.TemplateType.FAClick();
                 FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Exchange Delayed");
                 FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Santa-Ana-Template");
                 FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                 FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                 #endregion

                 #region Phrases Selection Dialogue and Phrase Type
                 Reports.TestStep = "Phrases Selection Dialogue and Phrase Type ";
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                 FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1216[1216]");
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                 FastDriver.DialogBottomFrame.ClickDone();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                 #endregion


                 #region Verify Versioning  on Template
                 Reports.TestStep = "Verify Versioning  on Template ";
                 FastDriver.NextGenDocumentPreparation.Templates_PropertiesTab.FAClick();
                 FastDriver.NextGenDocumentPreparation.VersioningTemplate.Highlight();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please.....", false, 50);
                 #endregion


             }

             catch (Exception ex)
             {
                 FailTest(ex.Message);
             }
         }


         [TestMethod]

         public void DocGen_11_TC5518_To_verify_system_allows_to_add_a_corporate_phrase_which_can_be_marked_as_required()
         {
             try
             {

                 string RandomtemplateName = Support.RandomString("AAAAAAA");

                 #region DataSetup ADM
                 Reports.TestStep = "DataSetup ADM";
                 FAST_Login_ADM(isSuperUser: false);
                 FAST_OpenRegionOrOffice(officeId);
                 #endregion


                 #region Navigate Document Preparation
                 Reports.TestStep = "Navigate Document Preparation ";
                 FastDriver.NextGenDocumentPreparation.Open();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                 #endregion


                 #region Create Template into Template TAB
                 Reports.TestStep = "Create Template into Template TAB";
                 FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                 FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please........", false);
                 FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                 FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Santa-Ana-Template");
                 FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                 FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please....", false);
                 #endregion

                 #region Click Filtering TAB Select All Select options
                 Reports.TestStep = "Click Filtering TAB Select All Select options ";
                 FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                 FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                 FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                 FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                 #endregion

                 #region Insert Phrases Option in Menu Context
                 Reports.TestStep = "Insert Phrases Option in Menu Context ";
                 FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 #endregion 

                 #region Phrases Selection Dialogue and Phrase Type
                 Reports.TestStep = "Phrases Selection Dialogue and Phrase Type ";
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();                 
                 FastDriver.PhraseSelectDlg.Source.FASelectItem("Corporate");
                 FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                 FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1216[1216]");
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                 FastDriver.DialogBottomFrame.ClickDone();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                 #endregion

                 #region Verify **Phrases Required Option
                 Reports.TestStep = "Verify **Phrases Required Option";
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.NextGenDocumentPreparation.PhrasesRequired.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                 #endregion



                 // Navigate Document Repository IIS 

                 #region DataSetup IIS
                 var credentials = new Credentials()
                 {
                     UserName = AutoConfig.UserName,
                     Password = AutoConfig.UserPassword
                 };
                 #endregion

                 #region Login to FAST Application File Side
                 Reports.TestStep = "Login to FAST Application File Side";
                 FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                 Reports.TestStep = "Navigate to Select Office screen";
                 //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                 FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                 Reports.TestStep = "Navigate to NextGen Region/Office Level";
                 FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                 var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                 if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                     throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                 #endregion

                 #region CreateFile
                 string fileNumber = "";
                 try
                 {
                     Reports.TestStep = "Create File using web service.";
                     var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                     nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                     nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                     nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                     nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                     nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                     nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                     fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                     FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                 }
                 catch //If not able to create file via web service, create file via FAST GUI
                 {
                     Reports.TestStep = "Create File using FAST GUI.";
                     FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                     try
                     {
                         FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                     }
                     catch
                     {
                         Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                     }

                     FastDriver.QuickFileEntry.CreateStandardFile();
                     FastDriver.TopFrame.SwitchToTopFrame();
                     FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                     fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                 }
                 #endregion

                 #region  Navigate to Document Repository Screen
                 Reports.TestStep = "Navigate to Document Repository Screen";
                 FastDriver.NextGenDocumentRepository.Open();
                 #endregion

                 #region Perform Select Template Search criteria All Templates Option
                 Reports.TestStep = "Perform Select Template Search criteria All Templates Option";
                 FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                 FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                 FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                 FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                 FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Santa-Ana-Template");
                 FastDriver.NextGenDocumentRepository.Search.FAClick();
                 FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                 FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                 #endregion

                 #region Perform Doble Click in Template Created
                 Reports.TestStep = "Perform Doble Click in Template Created";
                 FastDriver.NextGenDocumentRepository.DashboardDocuments.FADoubleClick();
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                 FastDriver.NextGenDocumentRepository.PhrasesViewEdit.FASelectContextMenuItem();
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                 FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                 #endregion      

            


             }

             catch (Exception ex)
             {
                 FailTest(ex.Message);
             }
         }


         [TestMethod]

         public void DocGen_12_TC6437_To_verify_system_allows_to_enter_cross_regional_phrases()
         {
             try
             {
                 string RandomtemplateName = Support.RandomString("AAAAAAA");

          

                 #region DataSetup ADM
                 Reports.TestStep = "DataSetup ADM";
                 FAST_Login_ADM(isSuperUser: false);
                 FAST_OpenRegionOrOffice(officeId);
                 #endregion


                 #region Navigate Document Preparation
                 Reports.TestStep = "Navigate Document Preparation ";
                 FastDriver.NextGenDocumentPreparation.Open();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                 #endregion


                 #region Create Template into Template TAB
                 Reports.TestStep = "Create Template into Template TAB";
                 FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                 FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please........", false);
                 FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                 FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Santa-Ana-Template");
                 FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                 FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please....", false);
                 #endregion

                 #region Click Filtering TAB Select All Select options
                 Reports.TestStep = "Click Filtering TAB Select All Select options ";
                 FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                 FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                 FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                 FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                 FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                 #endregion

                 #region Insert Phrases Option in Menu Context
                 Reports.TestStep = "Insert Phrases Option in Menu Context ";
                 FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 #endregion 

                 #region Phrases Selection Dialogue and Phrase Type
                 Reports.TestStep = "Phrases Selection Dialogue and Phrase Type ";
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.Source.FASelectItem("Corporate");
                 FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                 FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1216[1216]");
                 FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                 FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                 FastDriver.DialogBottomFrame.ClickDone();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                 #endregion

                 #region Verify **Phrases Required Option
                 Reports.TestStep = "Verify **Phrases Required Option";
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.NextGenDocumentPreparation.PhrasesRequired.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                 FastDriver.NextGenDocumentPreparation.Save.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                 #endregion


                 // Navigate Document Repository IIS 

                 #region DataSetup IIS
                 var credentials = new Credentials()
                 {
                     UserName = AutoConfig.UserName,
                     Password = AutoConfig.UserPassword
                 };
                 #endregion

                 #region Login to FAST Application File Side
                 Reports.TestStep = "Login to FAST Application File Side";
                 FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                 Reports.TestStep = "Navigate to Select Office screen";
                 //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                 FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                 Reports.TestStep = "Navigate to NextGen Region/Office Level";
                 FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                 var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                 if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                     throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                 #endregion

                 #region CreateFile
                 string fileNumber = "";
                 try
                 {
                     Reports.TestStep = "Create File using web service.";
                     var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                     nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                     nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                     nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                     nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                     nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                     nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                     fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                     FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                 }
                 catch //If not able to create file via web service, create file via FAST GUI
                 {
                     Reports.TestStep = "Create File using FAST GUI.";
                     FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                     try
                     {
                         FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                     }
                     catch
                     {
                         Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                     }

                     FastDriver.QuickFileEntry.CreateStandardFile();
                     FastDriver.TopFrame.SwitchToTopFrame();
                     FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                     fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                 }
                 #endregion

                 #region  Navigate to Document Repository Screen
                 Reports.TestStep = "Navigate to Document Repository Screen";
                 FastDriver.NextGenDocumentRepository.Open();
                 #endregion

                 #region Perform Select Template Search criteria All Templates Option
                 Reports.TestStep = "Perform Select Template Search criteria All Templates Option";
                 FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                 FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                 FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                 FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                 FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Santa-Ana-Template");
                 FastDriver.NextGenDocumentRepository.Search.FAClick();
                 FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                 FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                 #endregion

                 #region Perform Doble Click in Template Created
                 Reports.TestStep = "Perform Doble Click in Template Created";
                 FastDriver.NextGenDocumentRepository.DashboardDocuments.FADoubleClick();
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                 FastDriver.NextGenDocumentRepository.PhrasesViewEdit.FASelectContextMenuItem();
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                 FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                 #endregion      





             }

             catch (Exception ex)
             {
                 FailTest(ex.Message);
             }
         }


        [TestMethod]

         public void DocGen_13_T8366_To_verify_the_UnRequire_option_menu_context_after_added_any_phrases_require()
         {
             try
             {

                 

                 #region DataSetup ADM
                 Reports.TestStep = "DataSetup ADM";
                 FAST_Login_ADM(isSuperUser: false);
                 FAST_OpenRegionOrOffice(officeId);
                 #endregion


                 #region Navigate Document Preparation
                 Reports.TestStep = "Navigate Document Preparation ";
                 FastDriver.NextGenDocumentPreparation.Open();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                 #endregion


                 #region Search any Template into Template TAB
                 Reports.TestStep = "Search any Template into Template TAB";
                 FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please.........", false);
                 FastDriver.NextGenDocumentPreparation.TemplateType.FAClick();
                 FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Exchange Delayed");
                 FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Orange");
                 FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                 FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                 #endregion


                 #region Select UnRequire and **Phrase Required menu context 
                 Reports.TestStep = "Select UnRequire and **Phrase Required menu context ";
                 FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.UnRequire.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(5, 1, TableAction.Click, "").Element.FARightClick();
                 if (true)
                 {
                     FastDriver.NextGenDocumentPreparation.PhrasesRequired.FAClick();
                     FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false,15);
                 }
                  #endregion           




             }

             catch (Exception ex)
             {
                 FailTest(ex.Message);
             }
         }







        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }
        
        [ClassCleanup]
        public static void ClassCleanup()
        {
            FASTHelpers.CleanupClass();
        }        

    }
}
