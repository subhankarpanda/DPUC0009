﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;

namespace NextGenDocPrep.r08._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_736144  :FASTHelpers
    {
          #region Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }
        #endregion

        [TestMethod]

        public void DocGen_01_TC_2623_To_verify_the_phrase_Move_option_introduced_within_the_template_in_ADM()
        {
            try
            {
                string RandomtemplateName = Support.RandomString("AAAAAAA");
               

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation 
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Create Template into Template TAB
                Reports.TestStep = "Create Template into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....",false);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);               
                #endregion

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion   
                
                #region Phrases Selection Dialogue and Phrase Type and click Save
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type and click Save  ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Miscellaneous Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("0108 phrase group[0108]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion    

                #region Click Save and Under Construction
                Reports.TestStep = "Click Save and Under Construction ";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Right Click Move Phrase Option 
                Reports.TestStep = "Right Click Move Phrase Option";
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.MovePhrasescontext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion
            
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]

        public void DocGen_02_TC_2624_To_move_or_re_sequence_the_phrases_within_the_template_in_ADM_side_and_verify_the_same_in_file_side()
        {
            try
            {
                

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Search Templates into Template TAB
                Reports.TestStep = "Search Templates into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateType.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();          
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                #endregion

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (false)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                }

                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion      

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion

                #region Phrases Selection Dialogue and Phrase Type and click Save
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type and click Save  ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Miscellaneous Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("0108 phrase group[0108]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Exception Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("Zera[#]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.DialogBottomFrame.ClickDone();               
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Click Save and Under Construction
                Reports.TestStep = "Click Save and Under Construction ";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                if (false)
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick(); 
                }
                
                FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Right Click Move Phrases Option
                Reports.TestStep = "Right Click Move Phrases Option";
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.MovePhrasescontext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion


                #region Verify First phrases Move Up/Down botton 
                Reports.TestStep = "Verify First phrases Move Up/Down botton ";                
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);              
                for (int i = 0; i < 4; i++)
                {
                    FastDriver.PhraseResequenceDlg.Down.FAClick();
                    Playback.Wait(500);
                }
                for (int i = 0; i < 4; i++)
                {
                    FastDriver.PhraseResequenceDlg.Up.FAClick();
                    Playback.Wait(500);
                }

                FastDriver.PhraseResequenceDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please",false,10);
                #endregion

                #region Verify Second phrases Move Up/Down botton 
                Reports.TestStep = "Verify second phrases Move Up/Down botton ";  
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(3, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.MovePhrasescontext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                for (int i = 0; i < 4; i++)
                {
                    FastDriver.PhraseResequenceDlg.Down.FAClick();
                    Playback.Wait(500);
                }
                for (int i = 0; i < 4; i++)
                {
                    FastDriver.PhraseResequenceDlg.Up.FAClick();
                    Playback.Wait(500);
                }

                FastDriver.PhraseResequenceDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Verify third phrases Move Up/Down botton
                Reports.TestStep = "Verify second phrases Move Up/Down botton ";
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(4, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.MovePhrasescontext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                for (int i = 0; i < 4; i++)
                {
                    FastDriver.PhraseResequenceDlg.Down.FAClick();
                    Playback.Wait(500);
                }
                for (int i = 0; i < 4; i++)
                {
                    FastDriver.PhraseResequenceDlg.Up.FAClick();
                    Playback.Wait(500);
                }
                FastDriver.PhraseResequenceDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Re-Sequence the Phrase 
                Reports.TestStep = "Re-Sequence the Phrase";
                Reports.TestStep = "Verify second phrases Move Up/Down botton ";
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.MovePhrasescontext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                for (int i = 0; i < 1; i++)
                {
                    FastDriver.PhraseResequenceDlg.Down.FAClick();
                    Playback.Wait(500);
                }            
                FastDriver.PhraseResequenceDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                // Navigate Document Repository IIS 

                #region DataSetup IIS
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search criteria All Templates Option
                Reports.TestStep = "Perform Select Template Search criteria All Templates Option";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Doble Click in Template Created
                Reports.TestStep = "Perform Doble Click in Template Created";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();        
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion      










            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]

        public void DocGen_03_TC_2625_To_move_or_re_sequence_the_phrases_within_the_already_existing_template_in_ADM_side_and_verify_the_same_in_file_side()
        {
            try
            {
                

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Search Templates into Template TAB
                Reports.TestStep = "Search Templates into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateType.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 2, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                #endregion

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (false)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                }
               
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion                            

                #region Click Save and Under Construction
                Reports.TestStep = "Click Save and Under Construction ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                if (false)
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                }

                FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Re-Sequence the Phrase
                Reports.TestStep = "Re-Sequence the Phrase";               
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.MovePhrasescontext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                for (int i = 0; i < 2; i++)
                {
                    FastDriver.PhraseResequenceDlg.Down.FAClick();
                    Playback.Wait(500);
                }
                FastDriver.PhraseResequenceDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                // Navigate Document Repository IIS 

                #region DataSetup IIS
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search criteria All Templates Option
                Reports.TestStep = "Perform Select Template Search criteria All Templates Option";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click, "Exchange Delayed").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Doble Click in Template Created
                Reports.TestStep = "Perform Doble Click in Template Created";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                # endregion


                #region Select Section Break into Phrase
                Reports.TestStep = "Select Section Break into Phrase";
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.DataElementTable.PerformTableAction(3, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Insert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.Above.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.SectionBreck.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.SectionBreck.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion

                #region Select Margin Section Option
                Reports.TestStep = "Select Margin Section Option";
                FastDriver.SectionBreakDlg.WaitForScreenToLoad();
                FastDriver.SectionBreakDlg.TopMargin.FASendKeys(FAKeys.Backspace);
                FastDriver.SectionBreakDlg.TopMargin.FASendKeys(FAKeys.Backspace);
                FastDriver.SectionBreakDlg.TopMargin.FASendKeys(FAKeys.Backspace);
                FastDriver.SectionBreakDlg.TopMargin.FASendKeys("1.0");
                FastDriver.SectionBreakDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please", false, 10);
                #endregion

                #region Select Restart Numbering into Phrase
                Reports.TestStep = "Select Section Break into Phrase";
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.DataElementTable.PerformTableAction(3, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Insert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.Above.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.AboveRestartNumbering.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion







                }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void DocGen_04_TC_2626_To_verify_the_versioning_of_a_template_when_the_phrases_are_re_sequenced_within_the_template_in_ADM()
        {
            try
            {


                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Search Templates into Template TAB and Verify Template Versioning.
                Reports.TestStep = "Search Templates into Template TAB and Verify Template Versioning.";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateType.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 2, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();            
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                FastDriver.NextGenDocumentPreparation.VersioningTemplate.Highlight();
                FastDriver.WebDriver.WaitForWindowAndSwitch("View Template Versioning ", false);
                #endregion      
    
                #region Click Save and Under Construction
                Reports.TestStep = "Click Save and Under Construction ";               
                if (true)
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                }

                FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion
   

                
                // Go IIS
                
                #region DataSetup IIS
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search criteria All Templates Option
                Reports.TestStep = "Perform Select Template Search criteria All Templates Option";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click, "Exchange Delayed").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Doble Click in Template Created
                Reports.TestStep = "Perform Doble Click in Template Created";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                # endregion

                #region Select Section Break into Phrase
                Reports.TestStep = "Select Section Break into Phrase";
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.DataElementTable.PerformTableAction(3, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Insert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.Above.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.SectionBreck.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.SectionBreck.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);


                #endregion

                #region Select Section Break Margin Option
                Reports.TestStep = "Select Section Break Margin Option";
                FastDriver.SectionBreakDlg.WaitForScreenToLoad();
                FastDriver.SectionBreakDlg.TopMargin.FASendKeys(FAKeys.Backspace);
                FastDriver.SectionBreakDlg.TopMargin.FASendKeys(FAKeys.Backspace);
                FastDriver.SectionBreakDlg.TopMargin.FASendKeys(FAKeys.Backspace);
                FastDriver.SectionBreakDlg.TopMargin.FASendKeys("1.0");
                FastDriver.SectionBreakDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please", false, 10);
                #endregion

                // Come Back ADM 

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Search Templates into Template TAB
                Reports.TestStep = "Search Templates into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateType.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 2, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                FastDriver.NextGenDocumentPreparation.VersioningTemplate.Highlight();
                FastDriver.WebDriver.WaitForWindowAndSwitch("view versioning Template", false,5);
                #endregion 
                
                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion
    
                #region Phrases Selection Dialogue and Phrase Type and click Save
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type and click Save  ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Miscellaneous Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("0108 phrase group[0108]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Right Click Move Phrases Option
                Reports.TestStep = "Right Click Move Phrases Option";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.MovePhrasescontext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion

                #region Re-Sequence the Phrase
                Reports.TestStep = "Re-Sequence the Phrase";                              
                for (int i = 0; i < 2; i++)
                {
                    FastDriver.PhraseResequenceDlg.Down.FAClick();
                    Playback.Wait(500);
                }
                FastDriver.PhraseResequenceDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                #region Verify Template ID 
                Reports.TestStep = "Verify Template ID ";
                FastDriver.NextGenDocumentPreparation.PropertiesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please Loading ", false);
                FastDriver.NextGenDocumentPreparation.VersioningTemplate.Highlight();
                FastDriver.WebDriver.WaitForWindowAndSwitch("View Template Version", false);
                #endregion




            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void DocGen_05_TC_2627_To_re_sequence_the_phrases_in_Phrase_re_resequence_dialog_using_Drag_and_Drop_options_provided_within_the_template_in_ADM()
        {
            try
            {
                string RandomtemplateName = Support.RandomString("AAAAAAA");

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion                               

                #region Search Templates into Template TAB and Verify Template Versioning.
                Reports.TestStep = "Search Templates into Template TAB and Verify Template Versioning.";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateType.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(3, 2, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);              
                #endregion             

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion

                #region Phrases Selection Dialogue and Phrase Type and click Save
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type and click Save  ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Miscellaneous Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("0108 phrase group[0108]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Right Click Move Phrase Option
                Reports.TestStep = "Right Click Move Phrase Option";
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.MovePhrasescontext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion


                #region Select Any Phrases Drag and Drop
                Reports.TestStep = "Select Any Phrases Drag and Drop";                
                for (int i = 0; i < 1; i++)
                {
                    FastDriver.PhraseResequenceDlg.PhraseTable.FADragAndDrop(FastDriver.PhraseResequenceDlg.PhraseTable);
                    Playback.Wait(500);
                }
                FastDriver.PhraseResequenceDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Click on Save Button Template
                Reports.TestStep = "Click on Save Button Template ";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion


                // Go IIS

                #region DataSetup IIS
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search criteria All Templates Option
                Reports.TestStep = "Perform Select Template Search criteria All Templates Option";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click, "Exchange Delayed").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Perform Doble Click in Template Created
                Reports.TestStep = "Perform Doble Click in Template Created";
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                # endregion


                #region Select Section Break into Phrase
                Reports.TestStep = "Select Section Break into Phrase";
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.DataElementTable.PerformTableAction(3, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Insert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.Above.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.SectionBreck.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.SectionBreck.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);


                #endregion

                #region Select Section Break Margin Option
                Reports.TestStep = "Select Section Break Margin Option";
                FastDriver.SectionBreakDlg.WaitForScreenToLoad();
                FastDriver.SectionBreakDlg.TopMargin.FASendKeys(FAKeys.Backspace);
                FastDriver.SectionBreakDlg.TopMargin.FASendKeys(FAKeys.Backspace);
                FastDriver.SectionBreakDlg.TopMargin.FASendKeys(FAKeys.Backspace);
                FastDriver.SectionBreakDlg.TopMargin.FASendKeys("1.0");
                FastDriver.SectionBreakDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please", false, 10);
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void DocGen_06_TC_2628_To_verify_the_ability_to_multi_select_sequential_phrase_while_performing_drag_and_drop_of_phrases()
        {
            try
            {
                string RandomtemplateName = Support.RandomString("AAAAAAA");

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Create Template into Template TAB
                Reports.TestStep = "Create Template into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                #endregion

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion

                #region Phrases Selection Dialogue and Phrase Type and click Save
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type and click Save  ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Miscellaneous Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("0108 phrase group[0108]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Exception Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("Zera[#]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Endorsement Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("Test Phrases JL[JL3]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Title Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1528-REB[NISC]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Click Save and Under Construction
                Reports.TestStep = "Click Save and Under Construction ";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Right Click Move Phrase Option
                Reports.TestStep = "Right Click Move Phrase Option";
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.MovePhrasescontext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion

                #region Select Any Phrases Drag and Drop
                Reports.TestStep = "Select Any Phrases Drag and Drop";
                for (int i = 0; i < 3; i++)
                {
                    FastDriver.PhraseResequenceDlg.PhraseTable.FADragAndDrop(FastDriver.PhraseResequenceDlg.PhraseTable);
                    Playback.Wait(500);
                }
                FastDriver.PhraseResequenceDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                //for (int i = 0; i < 3; i++)
                //{
                //    FastDriver.PhraseResequenceDlg.PhraseTable.FADragAndDrop(FastDriver.PhraseResequenceDlg.PhraseTable);
                //    Playback.Wait(500);
                //    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                //    FastDriver.PhraseResequenceDlg.Done.FAClick();
                //    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                //}
                       #endregion
                
                

                #region Click on Save Button Template
                    Reports.TestStep = "Click on Save Button Template ";
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                    #endregion

                    // Go IIS

                    #region DataSetup IIS
                    var credentials = new Credentials()
                    {
                        UserName = AutoConfig.UserName,
                        Password = AutoConfig.UserPassword
                    };
                    #endregion

                    #region Login to FAST Application File Side
                    Reports.TestStep = "Login to FAST Application File Side";
                    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                    Reports.TestStep = "Navigate to Select Office screen";
                    //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                    FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                    Reports.TestStep = "Navigate to NextGen Region/Office Level";
                    FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                    var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                    if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                        throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                    #endregion

                    #region CreateFile
                    string fileNumber = "";
                    try
                    {
                        Reports.TestStep = "Create File using web service.";
                        var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                        nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                        nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                        nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                        nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                        nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                        nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                        fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                        FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                    }
                    catch //If not able to create file via web service, create file via FAST GUI
                    {
                        Reports.TestStep = "Create File using FAST GUI.";
                        FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                        try
                        {
                            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                        }
                        catch
                        {
                            Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                        }

                        FastDriver.QuickFileEntry.CreateStandardFile();
                        FastDriver.TopFrame.SwitchToTopFrame();
                        FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                        fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                    }
                    #endregion

                    #region  Navigate to Document Repository Screen
                    Reports.TestStep = "Navigate to Document Repository Screen";
                    FastDriver.NextGenDocumentRepository.Open();
                    #endregion

                    #region Perform Select Template Search criteria All Templates Option
                    Reports.TestStep = "Perform Select Template Search criteria All Templates Option";
                    FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                    FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                    FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                    FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Sur-Africa-Template");
                    FastDriver.NextGenDocumentRepository.Search.FAClick();
                    FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click, "Exchange Delayed").Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    #endregion

                    #region Perform Doble Click in Template Created
                    Reports.TestStep = "Perform Doble Click in Template Created";
                    FastDriver.NextGenDocumentRepository.DashboardDocuments.FADoubleClick();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    # endregion

                    #region Select Section Break into Phrase
                    Reports.TestStep = "Select Section Break into Phrase";
                    FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentRepository.DataElementTable.PerformTableAction(3, 1, TableAction.Click, "").Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.Insert.FAMouseOver();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentRepository.Above.FAMouseOver();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentRepository.SectionBreck.FAMouseOver();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentRepository.SectionBreck.FASelectContextMenuItem();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);


                    #endregion

                    #region Select Margin Section Option
                    Reports.TestStep = "Select Margin Section Option";
                    FastDriver.SectionBreakDlg.WaitForScreenToLoad();
                    FastDriver.SectionBreakDlg.TopMargin.FASendKeys(FAKeys.Backspace);
                    FastDriver.SectionBreakDlg.TopMargin.FASendKeys(FAKeys.Backspace);
                    FastDriver.SectionBreakDlg.TopMargin.FASendKeys(FAKeys.Backspace);
                    FastDriver.SectionBreakDlg.TopMargin.FASendKeys("1.0");
                    FastDriver.SectionBreakDlg.Done.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please", false, 10);
                    #endregion



                
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]

        public void DocGen_07_TC_2629_To_validate_the_Cancel_button_functionality_in_Phrase_Re_Sequence_dialog()
        {
            try
            {
                string RandomtemplateName = Support.RandomString("AAAAAAA");

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Create Template into Template TAB
                Reports.TestStep = "Create Template into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                #endregion

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion

                #region Phrases Selection Dialogue and Phrase Type and click Save
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type and click Save  ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("1794[1794]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Miscellaneous Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("0108 phrase group[0108]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Click Save and Under Construction
                Reports.TestStep = "Click Save and Under Construction ";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Right Click Move Phrase Option
                Reports.TestStep = "Right Click Move Phrase Option";
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.MovePhrasescontext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion

                #region Re-Sequence the Phrase and Click Cancel Button 
                Reports.TestStep = "Re-Sequence the Phrase and Click Cancel Button ";             
                for (int i = 0; i < 3; i++)
                {
                    FastDriver.PhraseResequenceDlg.Down.FAClick();
                    Playback.Wait(500);
                }
                FastDriver.PhraseResequenceDlg.Cancel.Highlight();
                FastDriver.PhraseResequenceDlg.Cancel.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Click on Save Button Template
                Reports.TestStep = "Click on Save Button Template ";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 30);
                #endregion

                #region Right Click Move Phrase Option
                Reports.TestStep = "Right Click Move Phrase Option";
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.MovePhrasescontext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion

            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]

        public void DocGen_08_TC_4083_To_verify_Move_button_is_disabled_for_default_section_break_or_if_a_template_has_a_single_Phrase_phrase_marker()
        {
            try
            {
                string RandomtemplateName = Support.RandomString("AAAAAAA");

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Create Template into Template TAB
                Reports.TestStep = "Create Template into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText("Sur-Africa-Template");
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                #endregion              

                #region Verify Move Option is Disable for Default Section break
                Reports.TestStep = "Verify Move Option is Disable for Default Section break";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.MovePhrasescontext.Highlight();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false,20);
                #endregion


            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }












        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }



        [ClassCleanup]
        public static void ClassCleanup()
        {
            FASTHelpers.CleanupClass();
        }        

    }
}
