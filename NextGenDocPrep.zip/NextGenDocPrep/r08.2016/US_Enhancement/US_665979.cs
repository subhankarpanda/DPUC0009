﻿using FASTSelenium.Common;
using FASTSelenium.ImageRecognition;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Input;



namespace NextGenDocPrep.r08._2016.US_Enhancement
{
    /// <summary>
    /// Author: Ravindra Kumar Mopuri
    /// Date: 4/29/2016
    /// </summary>
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_665979 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);
            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);

            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        private int CreateDocumentusingWCFService(int DocTemplateTypeId, string DocName)
        {
            var GetDocTempReq = RequestFactory.GetDocTemplateRequest(DocTemplateTypeId, regionId);
            var GetDocTempRes = FASTWCFHelpers.FileService.GetDocTemplates(GetDocTempReq);
            int index;
            for (index = 0; index < GetDocTempRes.Templates.Length - 1; index++)
            {
                if (GetDocTempRes.Templates[index].Descr.Contains(DocName))
                {
                    int templateID1 = Convert.ToInt32(GetDocTempRes.Templates[index].TemplateID);
                    break;
                }
            }
            int templateID = Convert.ToInt32(GetDocTempRes.Templates[index].TemplateID);

            var CreateDocReq = RequestFactory.GetCreateDocumentDefaultRequest(File.FileID.Value, templateID);
            CreateDocReq.TemplateID = templateID;
            CreateDocReq.FileID = File.FileID;
            CreateDocReq.TitleReportDocumentID = 0;

            var CreateDocRes = FASTWCFHelpers.FileService.CreateDocument(CreateDocReq);

            return Convert.ToInt32(CreateDocRes.DocumentID);
        }

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        private void InsertDataElement()
        {

            var currentLine = FastDriver.DocumentEditor.IRDocumentCurrentLine.Offset(624, 164);
            if (currentLine.DelayOnce(10).Visible() == false)
                currentLine.DelayOnce(60);
            currentLine.FAClick();
            Keyboard.SendKeys("[Test]");
            FastDriver.DocumentEditor.IRDocumentCurrentLine.DelayOnce(3).Offset(680, 164).ContextClick();
            FastDriver.DocumentEditor.IR_CM_InsertDataElement.DelayOnce(3).Offset(686, 170).FAClick();
            FastDriver.DocumentEditor.IRInsertSearch.Offset(1140, 160).FAClick();
            Keyboard.SendKeys(FAKeys.Enter);
            FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
            FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItemBySendingKeys("Buyer");
            FastDriver.DataElementSelectionDlg.WaitCreation(FastDriver.DataElementSelectionDlg.SearchResult);
            FastDriver.DataElementSelectionDlg.GetSearchResult(0).FAClick();
            FastDriver.DataElementSelectionDlg.Select.FAClick();
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.IRSave.DelayOnce(6).Offset(1850, 50).FAClick();
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.Close.FAClick();
            FastDriver.DocumentEditor.Yes.FAClick();
            Playback.Wait(6000);
        }

        private void InsertPhrase(string tplPhraseName, string phraseDescription)
        {
            var insertPhrase = FastDriver.DocumentEditor.IRInsertPhrase.Offset(220, 250 - 110);
            if (insertPhrase.DelayOnce(10).Visible() == false)
                insertPhrase.DelayOnce(60);
            insertPhrase.ContextClick();
            FastDriver.DocumentEditor.IRInsertPhraseBottom.Offset(240, 290 - 110).FAClick();
            //
            Reports.TestStep = "Enter phrase code and hit enter to insert phrase (or) Click Search Button \"…\" for inserting phrase";
            FastDriver.DocumentEditor.IRInsertSearch.DelayOnce(3).Offset(568, 308 - 130).DoubleClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
            //
            Reports.TestStep = "Select a phrase from the phrase search dialog and click on done button";
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.Description.FASetText(phraseDescription);
            FastDriver.PhraseSelectDlg.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, tplPhraseName, 1, TableAction.Click);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.IRSave.DelayOnce(6).Offset(1800, 50).FAClick();
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.Close.FAClick();
            FastDriver.DocumentEditor.Yes.FAClick();
            Playback.Wait(6000);
        }

        private void Phrase_phraseGrp_Template(string phraseGrp_Name, string phrase_Type, string templateName, string templateDescription, string templateType)
        {




            #region Verify that if Template is present
            Reports.TestStep = "Check if Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDescription);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDescription);
            #endregion

            if (!templateExists)
            {

                #region Create new phrase group
                Reports.TestStep = "Create new phrase group";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                var groupName = Support.RandomString(phraseGrp_Name);

                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);


                var groupDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));

                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);

                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem(phrase_Type);

                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                #endregion

                #region Add phrases
                Reports.TestStep = "Add phrases";
                FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);

                var phraseName = Support.RandomString(phraseGrp_Name);

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);

                var phraseDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));

                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                #endregion

                #region Insert phrases
                Reports.TestStep = "Insert phrases";
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertDataElement();
                #endregion

                #region Create template

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Create a new template";

                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                templateName = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(4));
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                templateDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(26));
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDescription);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                #endregion

                #region Insert template
                Reports.TestStep = "Insert template";
                FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                FastDriver.NextGenDocumentPreparation.Editor.FADoubleClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertPhrase(groupName + "/" + phraseName, phraseDescription);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDescription + " already exist", true);
            }


                #endregion

        }

        #region TestCase 821050 -Verify Delivry options dropdown in RTM Package Details screen

        [TestMethod]
        [Description("Verify Delivry options dropdown in RTM Package Details screen")]
        public void TestCase_821050()
        {
            
            try
            {
                Reports.TestDescription = "Verify Delivry options dropdown in RTM Package Details screen";
                #region Login to FAST file side and Navigate to Quick File Entry screen and create a basic file

                Reports.TestStep = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #endregion

                #region Navigate to Home| Order Entry| Document Repository

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                #endregion

                #region Create documents in the document repository landing page

                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for existing Escrow Instruction template using template search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TestCase665979");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);

                Reports.TestStep = "Select a template from the template search results";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                string temps;
                temps = FastDriver.NextGenDocumentRepository.TemplatesTable.FAFindElement(ByLocator.Id, "templateID").Exists().ToString();
                if (temps == "True")
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }
                else
                {
                    Reports.StatusUpdate("Templates not present, continue with next template type", false);
                }

               
                #endregion

                #region Select the documents, Right click and select "Add to RTM Package"

                Reports.TestStep = "Select the Document and Add to RTM Package";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Endorsement/Guarantee", "Type", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.AddToRTMPackage1.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                
                #endregion

                #region Select the Radio button and click on "Done" button

                FastDriver.NextGenDocumentRepository.RTMPakageRadio.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                #endregion

                #region Click on "OK" button

                Reports.TestStep = "Click on 'OK' Button.";

                #endregion

                #region Verify  "Delivery" dropdown is available at the right side of the screen

                Reports.TestStep = "Verify 'Delivery' dropdown is available at the right side of the screen.";
                //FastDriver.PackageDetailsDlg.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                //FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("EMail");
                Support.AreEqual(true, FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.IsDisplayed(), "Delivery methods dropdown is visible!");

                #endregion

                #region Select the delivery dropdown

                Reports.TestStep = "Select the delivery dropdown.";
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FAGetDropdownOptions().ToListString().Contains("Print").ToString(), "Print option exists.");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FAGetDropdownOptions().ToListString().Contains("Fax").ToString(), "Fax option exists.");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FAGetDropdownOptions().ToListString().Contains("EMail").ToString(), "EMail option exists.");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FAGetDropdownOptions().ToListString().Contains("Preview").ToString(), "Preview option exists.");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FAGetDropdownOptions().ToListString().Contains("ImageDoc").ToString(), "ImageDoc option exists.");
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FAGetDropdownOptions().ToListString().Contains("Real Time Mail").ToString(), "Real Time Mail option exists.");



                #endregion

                #region Click on "Mail To" Tab

                Reports.TestStep = "Click on 'Mail To' Tab.";
                FastDriver.NextGenDocumentRepository.MailTo.FAClick();

                #endregion

                #region Verify  "Delivery" dropdown is available at the right side of the screen

                Reports.TestStep = "Verify 'Delivery' dropdown is available at the right side of the screen.";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                
                Support.AreEqual(true, FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.IsDisplayed(), "Delivery methods dropdown is visible!");

                #endregion

                #region Click on "Return To" Tab

                Reports.TestStep = "Click on 'Return To' Tab.";
                FastDriver.NextGenDocumentRepository.ReturnTo.FAClick();

                #endregion

                #region Verify  "Delivery" dropdown is available at the right side of the screen

                Reports.TestStep = "Verify  'Delivery' dropdown is available at the right side of the screen.";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                
                Support.AreEqual(true, FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.IsDisplayed(), "Delivery methods dropdown is visible!");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase 821224 -Verify RTM package deliviers from the RTM Package details screen

        [TestMethod]
        [Description("Verify RTM package deliviers from the RTM Package details screen")]
        public void TestCase_821224()
        {
            // Pre-Condition Verify existing templates or created new templates in Admin side

            try
            {
                Reports.TestDescription = "Verify RTM package deliviers from the RTM Package details screen";
                #region Login to FAST file side and Navigate to Quick File Entry screen and create a basic file

                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Home| Order Entry| Document Repository

                Reports.TestStep = "Navigate to Home| Order Entry| Document Repository";
                FastDriver.NextGenDocumentRepository.Open();

                #endregion

                #region Create documents in the document repository landing page

                Reports.TestStep = "Create documents in the document repository landing page";

                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for existing Escrow Instruction template using template search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TestCase821224");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);

                Reports.TestStep = "Select a template from the template search results";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                string temps;
                temps = FastDriver.NextGenDocumentRepository.TemplatesTable.FAFindElement(ByLocator.Id, "templateID").Exists().ToString();
                if (temps == "True")
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }
                else
                {
                    Reports.StatusUpdate("Templates not present, continue with next template type", false);
                }

                #endregion

                #region Select the documents, Right click and select 'Add to RTM Package'

                Reports.TestStep = "Select the documents, Right click and select 'Add to RTM Package'";
                Reports.TestStep = "Select the Document and Add to RTM Package";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Escrow Instruction", "Type", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.AddToRTMPackage);
                FastDriver.NextGenDocumentRepository.AddToRTMPackage1.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Select the Radio button and click on 'Done' button

                Reports.TestStep = "Select the Radio button and click on 'Done' button";

                FastDriver.NextGenDocumentRepository.RTMPakageRadio.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                #endregion

                #region Click on 'OK' button
                Reports.TestStep = "Click on 'OK' button";
                #endregion

                #region Click on 'Mail To' Tab

                Reports.TestStep = "Click on 'Mail To' Tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                FastDriver.NextGenDocumentRepository.MailTo.FAClick();

                #endregion

                #region Using 'Search GAB' or 'Select Addresses' select any mail to address

                Reports.TestStep = "Using 'Search GAB' or 'Select Addresses' select any mail to address";
                FastDriver.NextGenDocumentRepository.SelectAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FileBusinessPartyTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.NextGenDocumentRepository.DoneSearchAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Click on 'Return To' Tab

                Reports.TestStep = "Click on 'Return To' Tab";
                FastDriver.NextGenDocumentRepository.ReturnTo.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);

                #endregion

                #region Selec the Office from the Name drop down

                Reports.TestStep = "Selec the Office from the Name drop down";
                FastDriver.NextGenDocumentRepository.OfficeSelection.FASelectItem("QA Sandpointe Office - Next Gen (Title Owning)");

                #endregion

                #region Verify  'Delivery' dropdown is available at the right side of the screen

                Reports.TestStep = "Verify  'Delivery' dropdown is available at the right side of the screen";
                Support.AreEqual(true, FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.IsVisible(), "Delivery methods dropdown is visible!");

                #endregion

                #region Select the 'Print' delivery option from the dropdown

                Reports.TestStep = "Select the 'Print' delivery option from the dropdown";
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Print");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.PrintDlg.WaitForScreenToLoad();

                #endregion

                #region Click on 'Print' button

                Reports.TestStep = "Click on 'Print' button";
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Verify after print delivery progress dialog closed system should retain 'Delivery' as option

                Reports.TestStep = "Verify after print delivery progress dialog closed system should retain 'Delivery' as option";
                var visibleOptionAfterPrint = FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FAGetText();
                if (visibleOptionAfterPrint == "Delivery")
                {
                    Reports.StatusUpdate("Delivery Dropdown retains 'Delivery' as option after Print Delivery completes.", true);
                }

                #endregion

                #region Select the 'Fax' delivery option from the dropdown

                Reports.TestStep = "Select the 'Fax' delivery option from the dropdown";
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Fax");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.FaxDlg.WaitForScreenToLoad();

                #endregion

                #region Click on 'Insert' button

                Reports.TestStep = "Click on 'Insert' button";
                FastDriver.FaxDlg.Insert.FAClick();
                #endregion

                #region Enter Recipient Name and Fax Number and click on 'FAX'

                Reports.TestStep = "Enter Recipient Name and Fax Number and click on 'FAX'";
                FastDriver.FaxDlg.Name.FASetText("Test User"); //enter recipient name
                FastDriver.FaxDlg.FAXNumber.FASetText("7148001572"); //enter fax number
                FastDriver.FaxDlg.FAX.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Verify after Fax delivery progress dialog closed system should retain 'Delivery' as option

                Reports.TestStep = "Verify after Fax delivery progress dialog closed system should retain 'Delivery' as option";
                var visibleOptionAfterFax = FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FAGetText();
                if (visibleOptionAfterFax == "Delivery")
                {
                    Reports.StatusUpdate("Delivery Dropdown retains 'Delivery' as option after Fax Delivery completes.", true);
                }

                #endregion

                #region Select the 'Email' delivery option from the dropdown

                Reports.TestStep = "Select the 'Email' delivery option from the dropdown";
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("EMail");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.EmailDlg.WaitForScreenToLoad();

                #endregion

                #region Enter 'To' Email address and click on 'Email'

                Reports.TestStep = "Enter 'To' Email address and click on 'Email'";
                FastDriver.EmailDlg.ToText.FASetText("aaakanksha@firstam.com");
                FastDriver.EmailDlg.Email.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Verify after Email delivery progress dialog closed system should retain 'Delivery' as option

                Reports.TestStep = "Verify after Email delivery progress dialog closed system should retain 'Delivery' as option";
                var visibleOptionAfterEmail = FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FAGetText();
                if (visibleOptionAfterEmail == "Delivery")
                {
                    Reports.StatusUpdate("Delivery Dropdown retains 'Delivery' as option after Email Delivery completes.", true);
                }

                #endregion

                #region Select the 'Preview' delivery option from the dropdown

                Reports.TestStep = "Select the 'Preview' delivery option from the dropdown";
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Preview");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                //how to close preview window

                #endregion

                #region Verify after Preivew completes system should retain 'Delivery' as option

                Reports.TestStep = "Verify after Preivew completes system should retain 'Delivery' as option";
                var visibleOptionAfterPreview = FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FAGetText();
                if (visibleOptionAfterPreview == "Delivery")
                {
                    Reports.StatusUpdate("Delivery Dropdown retains 'Delivery' as option after Preview Delivery completes.", true);
                }

                #endregion 

                #region Select the 'Imagedoc' delivery option from the dropdown

                Reports.TestStep = "Select the 'Imagedoc' delivery option from the dropdown";
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("ImageDoc");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.ImageDocDlg.WaitForScreenToLoad();

                #endregion

                #region Click on 'Imagedoc' button

                Reports.TestStep = "Click on 'Imagedoc' button";
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Verify after 'Imagedoc' delivery progress dialog closed system should retain 'Delivery' as option

                Reports.TestStep = "Verify after 'Imagedoc' delivery progress dialog closed system should retain 'Delivery' as option";
                var visibleOptionAfterImageDoc = FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FAGetText();
                if (visibleOptionAfterImageDoc == "Delivery")
                {
                    Reports.StatusUpdate("Delivery Dropdown retains 'Delivery' as option after Print Delivery completes.", true);
                }

                #endregion

                #region Select the 'Real Time Mail' delivery option from the dropdown

                Reports.TestStep = "Select the 'Real Time Mail' delivery option from the dropdown";
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Real Time Mail");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.RealTimeMailDlg.WaitForScreenToLoad();

                #endregion

                #region Select 'Imagedoc' and 'Publish' check boxes and click on 'Deliver' button

                Reports.TestStep = "Select 'Imagedoc' and 'Publish' check boxes and click on 'Deliver' button";
                FastDriver.RealTimeMailDlg.ImageDocument.FASetCheckbox(true);
                FastDriver.RealTimeMailDlg.PublishDocument.FASetCheckbox(true);
                FastDriver.RealTimeMailDlg.Deliver.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Verify after 'Real Time mail' delivery progress dialog closed system should retain 'Delivery' as option

                Reports.TestStep = "Verify after 'Real Time mail' delivery progress dialog closed system should retain 'Delivery' as option";
                var visibleOptionAfterRealTimeMail = FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FAGetText();
                if (visibleOptionAfterRealTimeMail == "Delivery")
                {
                    Reports.StatusUpdate("Delivery Dropdown retains 'Delivery' as option after Print Delivery completes.", true);
                }

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase 821316 -Verify Warining Message if Mail to/ Return to addresses are not selected

        [TestMethod]
        [Description("Verify Warining Message if Mail to/ Return to addresses are not selected")]
        public void TestCase_821316()
        {
            // Pre-Condition Verify existing templates or created new templates in Admin side

            try
            {
                Reports.TestDescription = "Verify Warining Message if Mail to/ Return to addresses are not selected";
                #region Login to FAST file side

                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #endregion

                #region Navigate to Quick File Entry screen and create a basic file
                Reports.TestStep = "Navigate to Quick File Entry screen and create a basic file";
                #endregion

                #region Navigate to Home| Order Entry| Document Repository

                Reports.TestStep = "Navigate to Home| Order Entry| Document Repository";
                FastDriver.NextGenDocumentRepository.Open();

                #endregion

                #region Create documents in the document repository landing page

                Reports.TestStep = "Create documents in the document repository landing page";

                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for existing Escrow Instruction template using template search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TestCase821316");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);

                Reports.TestStep = "Select a template from the template search results";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                string temps;
                temps = FastDriver.NextGenDocumentRepository.TemplatesTable.FAFindElement(ByLocator.Id, "templateID").Exists().ToString();
                if (temps == "True")
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }

                else
                {
                    Reports.StatusUpdate("Templates not present, continue with next template type", false);
                }

               
                #endregion

                #region Select the documents, Right click and select 'Add to RTM Package'

                Reports.TestStep = "Select the documents, Right click and select 'Add to RTM Package'";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Escrow Instruction", "Type", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.AddToRTMPackage);
                FastDriver.NextGenDocumentRepository.AddToRTMPackage1.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                
                #endregion

                #region Select the Radio button and click on 'Done' button

                Reports.TestStep = "Select the Radio button and click on 'Done' button";
                FastDriver.NextGenDocumentRepository.RTMPakageRadio.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Click on 'OK' button
                Reports.TestStep = "Click on 'OK' button";
                #endregion

                #region Select the 'Delivery' dropdown

                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Print");
                #endregion

                #region Select the 'Print' Delivery method

                Reports.TestStep = "Select the 'Print' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessagePrint1 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessagePrint1 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }
                #endregion

                #region Repeat the above steps for other Delivery methods

                Reports.TestStep = "Repeat the above steps for other Delivery methods";
               
                #region Select the 'Delivery' dropdown

                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Fax");
                #endregion

                #region Select the 'Fax' Delivery method

                Reports.TestStep = "Select the 'Fax' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessageFax1 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageFax1 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }
                #endregion

                #region Select the 'Delivery' dropdown
                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("EMail");
                #endregion

                #region Select the 'EMail' Delivery method

                Reports.TestStep = "Select the 'EMail' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessageEMail1 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageEMail1 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #region Select the 'Delivery' dropdown

                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Preview");
                #endregion

                #region Select the 'Preview' Delivery method

                Reports.TestStep = "Select the 'Preview' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessagePreview1 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessagePreview1 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }
                
                #endregion

                #region Select the 'Delivery' dropdown
                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("ImageDoc");
                #endregion

                #region Select the 'ImageDoc' Delivery method

                Reports.TestStep = "Select the 'ImageDoc' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessageImageDoc1 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageImageDoc1 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #region Select the 'Delivery' dropdown
                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Real Time Mail");
                #endregion

                #region Select the 'Real Time Mail' Delivery method

                Reports.TestStep = "Select the 'Real Time Mail' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessageRealTimeMail1 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageRealTimeMail1 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }
                
                #endregion

                #endregion

                #region Click on 'OK' button
                Reports.TestStep = "Click on 'OK' button";
                #endregion

                #region Click on 'Mail To' Tab

                Reports.TestStep = "Click on 'Mail To' Tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                FastDriver.NextGenDocumentRepository.MailTo.FAClick();

                #endregion

                #region Using 'Search GAB' or 'Select Addresses' select any mail to address

                Reports.TestStep = "Using 'Search GAB' or 'Select Addresses' select any mail to address";
                FastDriver.NextGenDocumentRepository.SelectAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FileBusinessPartyTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.NextGenDocumentRepository.DoneSearchAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Select the 'Delivery' dropdown
                //aaaaaaaaaa
                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Print");
                
                #endregion

                #region Select the 'Print' Delivery method
                Reports.TestStep = "Select the 'Print' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessagePrint2 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessagePrint2 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }


                #endregion

                #region Repeat the above steps for other Delivery methods

                Reports.TestStep = "Repeat the above steps for other Delivery methods";

                #region Select the 'Delivery' dropdown

                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Fax");
                #endregion

                #region Select the 'Fax' Delivery method

                Reports.TestStep = "Select the 'Fax' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessageFax2 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageFax2 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }
                #endregion

                #region Select the 'Delivery' dropdown
                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("EMail");
                #endregion

                #region Select the 'EMail' Delivery method

                Reports.TestStep = "Select the 'EMail' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessageEMail2 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageEMail2 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #region Select the 'Delivery' dropdown

                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Preview");
                #endregion

                #region Select the 'Preview' Delivery method

                Reports.TestStep = "Select the 'Preview' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessagePreview2 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessagePreview2 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #region Select the 'Delivery' dropdown
                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("ImageDoc");
                #endregion

                #region Select the 'ImageDoc' Delivery method

                Reports.TestStep = "Select the 'ImageDoc' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessageImageDoc2 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageImageDoc2 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #region Select the 'Delivery' dropdown
                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Real Time Mail");
                #endregion

                #region Select the 'Real Time Mail' Delivery method

                Reports.TestStep = "Select the 'Real Time Mail' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessageRealTimeMail2 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageRealTimeMail2 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #endregion

                #region Click on 'Close' Button.
                Reports.TestStep = "Click on 'Close' Button";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DoneRTMPackages);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Please Perform Vice Varsa 'Select only Return To' and deliver ,verify warining message

                Reports.TestStep = "Please Perform Vice Varsa 'Select only Return To' and deliver ,verify warining message";
                
                //create RTM package

                Reports.TestStep = "Select the Document and Add to RTM Package";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TestCase821316", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.AddToRTMPackage1);
                FastDriver.NextGenDocumentRepository.AddToRTMPackage1.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Select the Radio button and click on 'Done' button";
                FastDriver.NextGenDocumentRepository.RTMPakageRadio.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);


                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                FastDriver.NextGenDocumentRepository.ReturnTo.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.OfficeSelection.FASelectItem("QA Sandpointe Office - Next Gen (Title Owning)");
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Print");
                Playback.Wait(250);

                string Delivery_WebMessage3 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessage3 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #region Repeat the above steps for other Delivery methods

                Reports.TestStep = "Repeat the above steps for other Delivery methods";

                #region Select the 'Delivery' dropdown

                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Fax");
                #endregion

                #region Select the 'Fax' Delivery method

                Reports.TestStep = "Select the 'Fax' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessageFax3 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageFax3 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }
                #endregion

                #region Select the 'Delivery' dropdown
                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("EMail");
                #endregion

                #region Select the 'EMail' Delivery method

                Reports.TestStep = "Select the 'EMail' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessageEMail3 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageEMail3 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #region Select the 'Delivery' dropdown

                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Preview");
                #endregion

                #region Select the 'Preview' Delivery method

                Reports.TestStep = "Select the 'Preview' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessagePreview3 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessagePreview3 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #region Select the 'Delivery' dropdown
                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("ImageDoc");
                #endregion

                #region Select the 'ImageDoc' Delivery method

                Reports.TestStep = "Select the 'ImageDoc' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessageImageDoc3 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageImageDoc3 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #region Select the 'Delivery' dropdown
                Reports.TestStep = "Select the 'Delivery' dropdown";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Real Time Mail");
                #endregion

                #region Select the 'Real Time Mail' Delivery method

                Reports.TestStep = "Select the 'Real Time Mail' Delivery method";
                Playback.Wait(250);

                string Delivery_WebMessageRealTimeMail3 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageRealTimeMail3 == ("mail to / return to address missing. please add the address before delivery").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #endregion

                #region Repeat the above steps from Step- 8 for all different types of delivery methods.
                Reports.TestStep = "Repeat the above steps from Step- 8 for all different types of delivery methods.";

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase 821778 -Verify Preventing delivery of package with unedited/Finalized policy

        [TestMethod]
        [Description("Verify Preventing delivery of package with unedited/Finalized policy")]
        public void TestCase_821778()
        {
            // Pre-Condition Verify existing templates or created new templates in Admin side

            try
            {
                Reports.TestDescription = "Verify Preventing delivery of package with unedited/Finalized policy";
                #region Login to FAST file side

                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Quick File Entry screen and create a basic file
                Reports.TestStep = "Navigate to Quick File Entry screen and create a basic file";
                #endregion

                #region Navigate to Home| Order Entry| Document Repository

                Reports.TestStep = "Navigate to Home| Order Entry| Document Repository";
                FastDriver.NextGenDocumentRepository.Open();

                #endregion

                #region Click on Template Search

                Reports.TestStep = "Click on Template Search";
                FastDriver.NextGenDocumentRepository.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                #endregion
                //adding title report document.
                #region Select Title Report and Policy templates ,Right click and select 'Create Document'
                Reports.TestStep = "Select Title Report and Policy templates ,Right click and select 'Create Document'";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TC821778");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);

                string temps;
                temps = FastDriver.NextGenDocumentRepository.TemplatesTable.FAFindElement(ByLocator.Id, "templateID").Exists().ToString();
                if (temps == "True")
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }
                else
                {
                    Reports.StatusUpdate("Templates not present, continue with next template type", false);
                }

                #endregion

                //adding owner policy document

                #region Select Title Report and Policy templates ,Right click and select 'Create Document'
                Reports.TestStep = "Select Title Report and Policy templates ,Right click and select 'Create Document'";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search";
                FastDriver.NextGenDocumentRepository.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Owner Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TC821778$0");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);

                string temps1;
                temps1 = FastDriver.NextGenDocumentRepository.TemplatesTable.FAFindElement(ByLocator.Id, "templateID").Exists().ToString();
                if (temps == "True")
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }
                else
                {
                    Reports.StatusUpdate("Templates not present, continue with next template type", false);
                }

                #endregion

                #region Select desired Policy documents
                Reports.TestStep = "Select desired Policy documents";
                #endregion

                #region Right Click
                Reports.TestStep = "Right Click";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC821778$0", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.AddToRTMPackage1);
                
                #endregion

                #region Select 'Add to RTM Package' option
                Reports.TestStep = "Select 'Add to RTM Package' option";
                FastDriver.NextGenDocumentRepository.AddToRTMPackage1.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
                
                #region Select the Radio button and click on done
                Reports.TestStep = "Select the Radio button and click on done";
                FastDriver.NextGenDocumentRepository.RTMPakageRadio.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                #endregion
                
                #region Add Mail to and Return to addresses details
                Reports.TestStep = "Add Mail to and Return to addresses details";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                FastDriver.NextGenDocumentRepository.MailTo.FAClick();

                Reports.TestStep = "Using 'Search GAB' or 'Select Addresses' select any mail to address";
                FastDriver.NextGenDocumentRepository.SelectAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FileBusinessPartyTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.NextGenDocumentRepository.DoneSearchAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.ReturnTo.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.OfficeSelection.FASelectItem("QA Sandpointe Office - Next Gen (Title Owning)");
                //FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Print");
                //Playback.Wait(250);

                #endregion
                
                #region Select the 'Print' Delivery method
                Reports.TestStep = "Select the 'Print' Delivery method";
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Print");
                Playback.Wait(250);
                #endregion
                
                #region Click on 'OK' button
                Reports.TestStep = "Click on 'OK' button";
                string Delivery_WebMessagePrint4 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessagePrint4 == ("The Policy/Endorsement\r\nTC821778$0\r\nMust be finalized before it may be delivered.").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }
                

                #endregion
                
                #region Perform the above two steps for other delivey method types
                Reports.TestStep = "Perform the above two steps for other delivey method types";
                #region Select the 'Fax' Delivery method
                Reports.TestStep = "Select the 'Fax' Delivery method";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Fax");

                #endregion

                #region Click on 'OK' button
                Reports.TestStep = "Click on 'OK' button";
                string Delivery_WebMessageFax4 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageFax4 == ("The Policy/Endorsement\r\nTC821778$0\r\nMust be finalized before it may be delivered.").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion
                #region Select the 'EMail' Delivery method
                Reports.TestStep = "Select the 'EMail' Delivery method";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("EMail");

                #endregion

                #region Click on 'OK' button
                Reports.TestStep = "Click on 'OK' button";
                string Delivery_WebMessageEMail4 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageEMail4 == ("The Policy/Endorsement\r\nTC821778$0\r\nMust be finalized before it may be delivered.").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                //#region Select the 'Preview' Delivery method
                //Reports.TestStep = "Select the 'Preview' Delivery method";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                //FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                //FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Preview");

                //#endregion

                //#region Click on 'OK' button
                //Reports.TestStep = "Click on 'OK' button";
                //string Delivery_WebMessagePreview4 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                //if (Delivery_WebMessagePreview4 == ("The Policy/Endorsement\r\nTC821778$0\r\nMust be finalized before it may be delivered.").ToUpper())
                //{
                //    Playback.Wait(3000);
                //    Reports.StatusUpdate("Valid Message Generated.", true);
                //}
                //else
                //{
                //    Playback.Wait(3000);
                //    Reports.StatusUpdate("Invalid Message!", false);
                //}

                //#endregion

                #region Select the 'ImageDoc' Delivery method
                Reports.TestStep = "Select the 'ImageDoc' Delivery method";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("ImageDoc");

                #endregion

                #region Click on 'OK' button
                Reports.TestStep = "Click on 'OK' button";
                string Delivery_WebMessageImageDoc4 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageImageDoc4 == ("The Policy/Endorsement\r\nTC821778$0\r\nMust be finalized before it may be delivered.").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #region Select the 'Real Time Mail' Delivery method
                Reports.TestStep = "Select the 'Real Time Mail' Delivery method";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Real Time Mail");

                #endregion

                #region Click on 'OK' button
                Reports.TestStep = "Click on 'OK' button";
                string Delivery_WebMessageRealTimeMail4 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageRealTimeMail4 == ("The Policy/Endorsement\r\nTC821778$0\r\nMust be finalized before it may be delivered.").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #endregion
                
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase 821807 -Verify Preventing delivery of package which contains Removed (or) void document

        [TestMethod]
        [Description("Verify Preventing delivery of package which contains Removed (or) void document")]
        public void TestCase_821807()
        {
            // Pre-Condition Verify existing templates or created new templates in Admin side

            try
            {
                Reports.TestDescription = "Verify Preventing delivery of package which contains Removed (or) void document";
                #region Login to FAST file side

                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                //FastDriver.TopFrame.SearchFileByFileNumber("2172");

                #endregion

                #region Navigate to Quick File Entry screen and create a basic file
                Reports.TestStep = "Navigate to Quick File Entry screen and create a basic file";
                #endregion

                #region Navigate to Home| Order Entry| Document Repository

                Reports.TestStep = "Navigate to Home| Order Entry| Document Repository";
                FastDriver.NextGenDocumentRepository.Open();

                #endregion

                #region Click on Template Search

                Reports.TestStep = "Click on Template Search";
                FastDriver.NextGenDocumentRepository.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                #endregion

                #region Create documents in the document repository landing page
                Reports.TestStep = "Create documents in the document repository landing page";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TC821807");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);

                string temps;
                temps = FastDriver.NextGenDocumentRepository.TemplatesTable.FAFindElement(ByLocator.Id, "templateID").Exists().ToString();
                if (temps == "True")
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }
                else
                {
                    Reports.StatusUpdate("Templates not present, continue with next template type", false);
                }

                #endregion

                #region Select the documents and Add to RTM Package

                Reports.TestStep = "Select the documents and Add to RTM Package";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC821807", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.AddToRTMPackage1);
                FastDriver.NextGenDocumentRepository.AddToRTMPackage1.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.RTMPakageRadio.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                #endregion

                #region Add Mail to and Return to addresses details
                Reports.TestStep = "Add Mail to and Return to addresses details";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                FastDriver.NextGenDocumentRepository.MailTo.FAClick();

                Reports.TestStep = "Using 'Search GAB' or 'Select Addresses' select any mail to address";
                FastDriver.NextGenDocumentRepository.SelectAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FileBusinessPartyTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.NextGenDocumentRepository.DoneSearchAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.ReturnTo.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.OfficeSelection.FASelectItem("QA Sandpointe Office - Next Gen (Title Owning)");
                
                Playback.Wait(250);

                #endregion

                #region Navigate to document repository and remove any document which is added to RTM package

                Reports.TestStep = "Navigate to document repository and remove any document which is added to RTM package";
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC821807", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Remove.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Select the RTM package right click and select "Details" option

                Reports.TestStep = "Select the RTM package right click and select 'Details' option";

                FastDriver.NextGenDocumentRepository.Packages.FASelectContextMenuItem(); // Send Enter key to the control
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.RTMPackageLink);
                FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                if (!FastDriver.NextGenDocumentRepository.FirstRTMPackage.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.FirstRTMPackage);
                }
                FastDriver.NextGenDocumentRepository.FirstRTMPackage.FARightClick();
                //FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.Details);
                //FastDriver.NextGenDocumentRepository.Details.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.DetailsRTM.JSClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);

                #endregion

                #region Select the "Print" delivery option from the dropdown

                Reports.TestStep = "Select the 'Print' delivery option from the dropdown";
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Print");
                string Delivery_WebMessagePrint5 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessagePrint5 == ("Package contains a Void or Removed document and cannot be printed, emailed, faxed, imaged or delivered to any other system.\r\nDocument Name(s):TC821807").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #region Repeat the above step for all different types of deliveries and verify the warning message

                Reports.TestStep = "Repeat the above step for all different types of deliveries and verify the warning message";

                #region Select the "Fax" delivery option from the dropdown

                Reports.TestStep = "Select the 'Fax' delivery option from the dropdown";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Fax");
                string Delivery_WebMessageFax5 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageFax5 == ("Package contains a Void or Removed document and cannot be printed, emailed, faxed, imaged or delivered to any other system.\r\nDocument Name(s):TC821807").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #region Select the "EMail" delivery option from the dropdown

                Reports.TestStep = "Select the 'EMail' delivery option from the dropdown";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("EMail");
                string Delivery_WebMessageEMail5 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageEMail5 == ("Package contains a Void or Removed document and cannot be printed, emailed, faxed, imaged or delivered to any other system.\r\nDocument Name(s):TC821807").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                //#region Select the "Preview" delivery option from the dropdown

                //Reports.TestStep = "Select the 'Preview' delivery option from the dropdown";
                //FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                //FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Preview");
                //string Delivery_WebMessagePreview5 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                //if (Delivery_WebMessagePreview5 == ("Package contains a Void or Removed document and cannot be printed, emailed, faxed, imaged or delivered to any other system.\r\nDocument Name(s):TC821807").ToUpper())
                //{
                //    Playback.Wait(3000);
                //    Reports.StatusUpdate("Valid Message Generated.", true);
                //}
                //else
                //{
                //    Playback.Wait(3000);
                //    Reports.StatusUpdate("Invalid Message!", false);
                //}

                //#endregion
                #region Select the "ImageDoc" delivery option from the dropdown

                Reports.TestStep = "Select the 'ImageDoc' delivery option from the dropdown";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("ImageDoc");
                string Delivery_WebMessageImageDoc5 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageImageDoc5 == ("Package contains a Void or Removed document and cannot be printed, emailed, faxed, imaged or delivered to any other system.\r\nDocument Name(s):TC821807").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                #region Select the "Real Time Mail" delivery option from the dropdown

                Reports.TestStep = "Select the 'Real Time Mail' delivery option from the dropdown";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Real Time Mail");
                string Delivery_WebMessageRealTimeMail5 = FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString().ToUpper();
                if (Delivery_WebMessageRealTimeMail5 == ("Package contains a Void or Removed document and cannot be printed, emailed, faxed, imaged or delivered to any other system.\r\nDocument Name(s):TC821807").ToUpper())
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Valid Message Generated.", true);
                }
                else
                {
                    Playback.Wait(3000);
                    Reports.StatusUpdate("Invalid Message!", false);
                }

                #endregion

                //Pre-condition: Create a CPL document

                #region Navigate to Document repository screen via Home|Order Entry|Document Repository
                Reports.TestStep = "Navigate to Document repository screen via Home|Order Entry|Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Select the CPL document
                Reports.TestStep = "Select the CPL document";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type","CPL","Type", TableAction.Click).Element.FARightClick();
                #endregion

                #region Right click and select the option Remove
                Reports.TestStep = "Right click and select the option Remove";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.Remove);
                FastDriver.NextGenDocumentRepository.Remove.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Now click on Type coulmn filter
                Reports.TestStep = "Now click on Type coulmn filter";
                #endregion

                #region Select the option 'Removed Items'
                Reports.TestStep = "";
                #endregion

                #region Select the document Right click and select "Add to RTM Package"
                Reports.TestStep = "Select the document Right click and select 'Add to RTM Package'";
                #endregion

                #region Select the existing package ( radio button) and click on Done
                Reports.TestStep = "Select the existing package ( radio button) and click on Done";
                #endregion

                #region Right Click on RTM Docs package node 
                Reports.TestStep = "Right Click on RTM Docs package node ";
                #endregion

                #region Right click on the selected package and choose the option 'Deliver'
                Reports.TestStep = "Right click on the selected package and choose the option 'Deliver'";
                #endregion

                #region Click on 'Email' from the delivery method cascade
                Reports.TestStep = "Click on 'Email' from the delivery method cascade";
                #endregion

                #region Repeat steps for 'Fax' delivery method
                Reports.TestStep = "Repeat steps for 'Fax' delivery method";
                #endregion

                #region Repeat steps for 'Imagedoc' delivery method
                Reports.TestStep = "Repeat steps for 'Imagedoc' delivery method";
                #endregion

                #region Repleate the Above steps for RTM Package Delivery
                Reports.TestStep = "Repleate the Above steps for RTM Package Delivery";
                #endregion

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase 821844 -Verify Number of document copies in the Package delivery
        //bug 822028 
        [TestMethod]
        [Description("Verify Number of document copies in the Package delivery")]
        public void TestCase_821844()
        {
            // Pre-Condition Verify existing templates or created new templates in Admin side

            try
            {
                Reports.TestDescription = "Verify Preventing delivery of package which contains Removed (or) void document";

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase 821875 -Verify RTM package deliveries from the Details screen after creating the package from the Packages Panel

        [TestMethod]
        [Description("Verify RTM package deliveries from the Details screen after creating the package from the Packages Panel")]
        public void TestCase_821875()
        {
            // Pre-Condition Verify existing templates or created new templates in Admin side

            try
            {
                Reports.TestDescription = "Verify RTM package deliveries from the Details screen after creating the package from the Packages Panel";
                #region Login to FAST file side

                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #endregion

                #region Navigate to Quick File Entry screen and create a basic file with valid address which initiates FAST Search
                Reports.TestStep = "Navigate to Quick File Entry screen and create a basic file with valid address which initiates FAST Search";
                #endregion

                #region Navigate to Home| Order Entry| Document Repository

                Reports.TestStep = "Navigate to Home| Order Entry| Document Repository";
                FastDriver.NextGenDocumentRepository.Open();

                #endregion

                #region Create a document

                Reports.TestStep = "Create a document";

                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for existing Escrow Instruction template using template search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);

                Reports.TestStep = "Select a template from the template search results";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                string temps;
                temps = FastDriver.NextGenDocumentRepository.TemplatesTable.FAFindElement(ByLocator.Id, "templateID").Exists().ToString();
                if (temps == "True")
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }
                else
                {
                    Reports.StatusUpdate("Templates not present, continue with next template type", false);
                }

               
                #endregion

                #region Click on 'Packages' Link
                Reports.TestStep = "Click on 'Packages' Link";

                #endregion

                #region Right click on RTM packages and select Create New Package
                Reports.TestStep = "Right click on RTM packages and select Create New Package";
                #endregion

                #region Drag and drop the document from the search result grid into above created package
                Reports.TestStep = "Drag and drop the document from the search result grid into above created package";
                #endregion

                #region Right Click on the RTM package and select 'Details' option
                Reports.TestStep = "Right Click on the RTM package and select 'Details' option";
                #endregion

                #region Verify the delivery options should be present in package details screen towards right side
                Reports.TestStep = "Verify the delivery options should be present in package details screen towards right side";
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        

        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }
      

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
