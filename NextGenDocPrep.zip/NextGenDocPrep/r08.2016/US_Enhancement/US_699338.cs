﻿using FASTSelenium.Common;
using FASTSelenium.ImageRecognition;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Input;

namespace NextGenDocPrep.r08._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_699338 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {


            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Endrosement two phrase ***AUTOMATION DNT***");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Endrosement two phrase ***AUTOMATION DNT***", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        #region TestCase_819014-To verify system allows to view phrase condition for phrases/forms from phrases tab

        [TestMethod]
        //[Description("To verify system allows to view phrase condition for phrases/forms from phrases tab")]
        public void TestCase_819014()
        {
            try
            {

                Reports.TestDescription = "TestCase_819014-To verify system allows to view phrase condition for phrases/forms from phrases tab";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                //Reports.TestStep = "Select Phrase to add condition";

                //FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click).Element.FARightClick();

                //FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "movePhrase").Highlight();
                //FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "movePhrase").FAMouseOver();
                //FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FAFindElement(ByLocator.ClassName, "movePhrase").FAClick();

                //Reports.TestStep = "Adding condition from Phrase Condition Dlg";
                //FastDriver.PhraseConditionsDlg.WaitForScreenToLoad();

                //FastDriver.PhraseConditionsDlg.Add.FAClick();
                //Playback.Wait(2000);
                //FastDriver.PhraseConditionsDlg.DataElement.FASetText("BUNAME");
                //FastDriver.PhraseConditionsDlg.Index.FASetText("1");
                //FastDriver.PhraseConditionsDlg.Operator.FASelectItem("EQ");
                //FastDriver.PhraseConditionsDlg.Value.FASetText("Buyer Full Name");
                //FastDriver.PhraseConditionsDlg.Done.FAClick();
                //Playback.Wait(2000);
                //Reports.TestStep = "Saving the edited template";
                //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                //FastDriver.NextGenDocumentPreparation.Save.FAClick();
                //Playback.Wait(5000);

                //Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                //FastDriver.NextGenDocumentPreparation.Open();
                //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                //Reports.TestStep = "Search for the created template";

                //FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                //FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                //FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                //FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                //Playback.Wait(5000);


                //Reports.TestStep = "Editing the created template";

                //FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                //Playback.Wait(5000);

                //Reports.TestStep = "Navigating to Phrases Tab";
                //FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                //Playback.Wait(7000);

                Reports.TestStep = "Verify the Expand All tool tip";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable);
                string Expandtooltip = FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.FAGetAttribute("title").ToString().Trim();
                Support.AreEqual(Expandtooltip, "Expand All");
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.FAClick();
                //FastDriver.NextGenDocumentPreparation.PhraseConditionTable.FAClick();
                FastDriver.NextGenDocumentPreparation.ExpandIcon.FAClick();

                string Dataelement = FastDriver.NextGenDocumentPreparation.ViewphraseConditionTable.PerformTableAction(1, 1, TableAction.GetText).Message.ToString().Trim();
                string Index = FastDriver.NextGenDocumentPreparation.ViewphraseConditionTable.PerformTableAction(1, 2, TableAction.GetCell).ToString().Trim();
                string Operator = FastDriver.NextGenDocumentPreparation.ViewphraseConditionTable.PerformTableAction(1, 3, TableAction.GetCell).ToString().Trim();
                string Value = FastDriver.NextGenDocumentPreparation.ViewphraseConditionTable.PerformTableAction(1, 4, TableAction.GetCell).ToString().Trim();
                Support.AreEqual(Dataelement, "BUNAME");
                Support.AreEqual(Index, "1");
                Support.AreEqual(Operator, "EQ");
                Support.AreEqual(Value, "Buyer Full Name");
                Playback.Wait(4000);


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


    }
}
        #endregion
       
       // [Description("To verify system retains the condition in an expanded view on adding/removing it in the collapsed view")]
     
        