﻿using FASTSelenium.Common;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers;
using OpenQA.Selenium;

namespace NextGenDocPrep.r08._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_246102 : FASTHelpers
    {
        #region Data Setup
        public static int _regionId = 12837;
        public static int _officeId = 12839;

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        #endregion

        #region Private Methods

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }
        #endregion

        [TestMethod]
        public void TestCase_780838()
        {
            Reports.TestDescription = "To verify the \"Insert Template\" option introduced in Phrase View section using right click functionality";
            try
            {
                #region Login to File side and change office to NextGen
                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: officeId);
                FAST_OpenRegionOrOffice(officeId);

                #endregion

                #region Create a file
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document repository
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button and select any document form the search results and create document
                Reports.TestStep = "Click on Template Search button and search for any template using template search criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_TitleReports_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait,document is getting created...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
              
                #endregion

                #region Veriy Insert Template option on right click context in Phrase view screen
                Reports.TestStep = "Verify document created in Document Repository and double click navigate to Phrase view";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.Click).Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);

                Reports.TestStep = "Verify Insert Template option in the right click context in phrase view screen";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable.PerformTableAction(1, 5, TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4]);
                Support.AreEqual("Template",FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4].FAGetText());
                FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4].FAClick();
                if(FastDriver.TemplateSelectionDlg.TemplateTable.IsVisible() == true)
                {
                    Reports.StatusUpdate("Insert Template option is not disabled above the default section break", false);
                }
                else
                {
                    Reports.StatusUpdate("Insert Template option is disabled above the default section break", true);
                }
                FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4]);
                Support.AreEqual("Template", FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4].FAGetText());
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4].FAClick();
                FastDriver.TemplateSelectionDlg.WaitForScreenToLoad();
                if (FastDriver.TemplateSelectionDlg.TemplateTable.IsVisible() == true)
                {
                    Reports.StatusUpdate("Insert Template option is enabled for right click below the default section break", true);
                }
                else
                {
                    Reports.StatusUpdate("Insert Template option is not enabled enabled below the default section break", false);
                }
                    

                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
         
        }

        [TestMethod]
        public void TestCase_780841()
        {
            try
            {
                Reports.TestDescription = "To insert a template at the END of the document in Phrase view screen and verify the Page break inserted";

                #region Login to File side and change office to NextGen
                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: officeId);
                FAST_OpenRegionOrOffice(officeId);

                #endregion

                #region Create a file
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document repository
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button and select any document form the search results and create document
                Reports.TestStep = "Click on Template Search button and search for any template using template search criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_TitleReports_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait,document is getting created...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Navigate to  Phrase view screen
                Reports.TestStep = "Verify document created in Document Repository and double click navigate to Phrase view";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.Click).Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);
                #endregion

                #region Right Click on the last phrase and insert a template
                Reports.TestStep = "Select the last phrase from the phrase view list";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 5, TableAction.Click, "Misc Phrase QA MJJP Test 3").Element.FARightClick();                
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4]);
                Support.AreEqual("Template", FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4].FAGetText());
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4].JSClick();
                FastDriver.TemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TemplateSelectionDlg.Source.FASelectItem("Region");
                FastDriver.TemplateSelectionDlg.TemplateType.FASelectItem("Endorsement/Guarantee");
                Playback.Wait(5000);
                FastDriver.TemplateSelectionDlg.TemplateTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.Click).Element.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Inserting Phrase please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable2.PerformTableAction(1, 5, TableAction.GetText, "Page Break").Element.IsDisplayed().ToString());
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable3.PerformTableAction(1, 5, TableAction.GetText, "Section Break(Continuous)").Element.IsDisplayed().ToString());
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable4.PerformTableAction(1, 5, TableAction.GetText, "Phrase QA MJJP-DO NOT TOUCH01").Element.IsDisplayed().ToString());
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable5.PerformTableAction(1, 5, TableAction.GetText, "Section Break(Next Page)").Element.IsDisplayed().ToString()); 



                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void TestCase_780843()
        {
            try
            {
                Reports.TestDescription = "To insert a template at the Middle of the document in Phrase view screen and verify the Page break inserted";

                #region Login to File side and change office to NextGen
                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: officeId);
                FAST_OpenRegionOrOffice(officeId);

                #endregion

                #region Create a file
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document repository
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button and select any document form the search results and create document
                Reports.TestStep = "Click on Template Search button and search for any template using template search criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_TitleReports_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait,document is getting created...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Navigate to  Phrase view screen
                Reports.TestStep = "Verify document created in Document Repository and double click navigate to Phrase view";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.Click).Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);
                #endregion

                #region Right Click on the last phrase and insert a template
                Reports.TestStep = "Select the last phrase from the phrase view list";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable.PerformTableAction(1, 5, TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4]);
                Support.AreEqual("Template", FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4].FAGetText());
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4].JSClick();
                FastDriver.TemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TemplateSelectionDlg.Source.FASelectItem("Region");
                FastDriver.TemplateSelectionDlg.TemplateType.FASelectItem("Endorsement/Guarantee");
                Playback.Wait(5000);
                FastDriver.TemplateSelectionDlg.TemplateTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.Click).Element.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Inserting Phrase please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 5, TableAction.GetText, "Page Break").Element.IsDisplayed().ToString());
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable2.PerformTableAction(1, 5, TableAction.GetText, "Section Break(Continuous)").Element.IsDisplayed().ToString());
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable3.PerformTableAction(1, 5, TableAction.GetText, "Phrase QA MJJP-DO NOT TOUCH01").Element.IsDisplayed().ToString());
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable4.PerformTableAction(1, 5, TableAction.GetText, "Section Break(Next Page)").Element.IsDisplayed().ToString());
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable5.PerformTableAction(1, 5, TableAction.GetText, "Misc Phrase QA MJJP Test 3").Element.IsDisplayed().ToString());

                 



                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void TestCase_780848()
        {
            try
            {
                Reports.TestDescription = "To insert a template at the Middle of the document in Phrase view screen and verify the Page break inserted";

                #region Login to File side and change office to NextGen
                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: officeId);
                FAST_OpenRegionOrOffice(officeId);

                #endregion

                #region Create a file
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document repository
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button and select any document form the search results and create document
                Reports.TestStep = "Click on Template Search button and search for any template using template search criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_TitleReports_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait,document is getting created...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Navigate to  Phrase view screen
                Reports.TestStep = "Verify document created in Document Repository and double click navigate to Phrase view";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.Click).Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);
                #endregion

                #region Right Click on the last phrase and insert a template
                Reports.TestStep = "Select the last phrase from the phrase view list";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable.PerformTableAction(1, 5, TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4]);
                Support.AreEqual("Template", FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4].FAGetText());
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4].JSClick();
                FastDriver.TemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TemplateSelectionDlg.Source.FASelectItem("Region");
                FastDriver.TemplateSelectionDlg.TemplateType.FASelectItem("Endorsement/Guarantee");
                Playback.Wait(5000);
                FastDriver.TemplateSelectionDlg.TemplateTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.Click).Element.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Inserting Phrase please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 5, TableAction.GetText, "Page Break").Element.IsDisplayed().ToString());
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable2.PerformTableAction(1, 5, TableAction.GetText, "Section Break(Continuous)").Element.IsDisplayed().ToString());
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable3.PerformTableAction(1, 5, TableAction.GetText, "Phrase QA MJJP-DO NOT TOUCH01").Element.IsDisplayed().ToString());
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable4.PerformTableAction(1, 5, TableAction.GetText, "Section Break(Next Page)").Element.IsDisplayed().ToString());
                Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentRepository.PhraseDataElementTable5.PerformTableAction(1, 5, TableAction.GetText, "Misc Phrase QA MJJP Test 3").Element.IsDisplayed().ToString());
                
                #endregion

                #region Save the tempalte changes and preview the document

                Reports.TestStep = "Verify the page break inserted before/after inside the delivery window";
                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentInfoTab1.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.EffectiveDate);
                FastDriver.NextGenDocumentRepository.EffectiveDate.FASetText(DateTime.UtcNow.ToPST().ToString("MM-dd-yyyy"));
                FastDriver.NextGenDocumentRepository.DocInfo_Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("PREVIEW");
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Preview);

                //Verify the preview document manually

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void TestCase_781351()
        {
            try
            {
                Reports.TestDescription = "To verify that the \"Insert Template\" option is enabled only for \"All Elements\" scope and disabled for \"Elements missing values\" scope";
                #region Login to File side and change office to NextGen
                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: officeId);
                FAST_OpenRegionOrOffice(officeId);

                #endregion

                #region Create a file
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document repository
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button and select any document form the search results and create document
                Reports.TestStep = "Click on Template Search button and search for any template using template search criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_TitleReports_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait,document is getting created...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Veriy Insert Template option on right click context in Phrase view screen
                Reports.TestStep = "Verify document created in Document Repository and double click navigate to Phrase view";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.Click).Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);

                Reports.TestStep = "Verify Insert Template option in the right click context in phrase view screen for \"All Elements\" Scope Selected";
                Support.AreEqual("true", FastDriver.NextGenDocumentRepository.AllElements.GetAttribute("Selected"));
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable.PerformTableAction(1, 5, TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4]);
                Support.AreEqual("Template", FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4].FAGetText());
                FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4].FAClick();
                if (FastDriver.TemplateSelectionDlg.TemplateTable.IsVisible() == true)
                {
                    Reports.StatusUpdate("Insert Template option is not disabled above the default section break", false);
                }
                else
                {
                    Reports.StatusUpdate("Insert Template option is disabled above the default section break", true);
                }
                FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4]);
                Support.AreEqual("Template", FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4].FAGetText());
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4].FAClick();
                FastDriver.TemplateSelectionDlg.WaitForScreenToLoad();
                if (FastDriver.TemplateSelectionDlg.TemplateTable.IsVisible() == true)
                {
                    Reports.StatusUpdate("Insert Template option is enabled for right click below the default section break", true);
                    FastDriver.DialogBottomFrame.ClickCancel();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);
                }
                else
                {
                    Reports.StatusUpdate("Insert Template option is not enabled enabled below the default section break", false);
                }

                Reports.TestStep = "Verify Insert Template option in the right click context in phrase view screen for \"Elements missing values\" Scope Selected";
                //Support.AreEqual("False", FastDriver.NextGenDocumentRepository.Elements_Missing_Values.FAGetAttribute("Selected").ToString());
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);
                FastDriver.NextGenDocumentRepository.Elements_Missing_Values.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.Elements_Missing_Values.FASetCheckbox(true);
                Playback.Wait(2000);
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable.PerformTableAction(1, 5, TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4]);
                Support.AreEqual("Template", FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4].FAGetText());
                FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4].FAClick();
                if (FastDriver.TemplateSelectionDlg.TemplateTable.IsVisible() == true)
                {
                    Reports.StatusUpdate("Insert Template option is not disabled above the default section break", false);
                }
                else
                {
                    Reports.StatusUpdate("Insert Template option is disabled above the default section break", true);
                }
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable.PerformTableAction(1, 5, TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.AbovePhraseContextMenu.FindElements(By.TagName("A"))[4].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4]);
                Support.AreEqual("Template", FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4].FAGetText());
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4].FAClick();                
                if (FastDriver.TemplateSelectionDlg.TemplateTable.IsVisible() == true)
                {
                    Reports.StatusUpdate("Insert Template option is not disabled for right click below the default section break in Elements missing values", false);
                }
                else
                {
                    Reports.StatusUpdate("Insert Template option is disabled below the default section break", true);
                }


                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void TestCase_781353()
        {
            try
            {
                Reports.TestDescription = "To ensure that Template code option shall not be available from Phrase View screen";
                #region Login to File side and change office to NextGen
                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: officeId);
                FAST_OpenRegionOrOffice(officeId);

                #endregion

                #region Create a file
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document repository
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button and select any document form the search results and create document
                Reports.TestStep = "Click on Template Search button and search for any template using template search criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_TitleReports_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait,document is getting created...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.Click);

                #endregion

                #region Navigate to Phrase View Screen
                Reports.TestStep = "Navigate to Phrase View Screen";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.Click).Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);

                #endregion

                #region Verify Template Code option is not available in Template Selection dialog box from Phrase View screen

                Reports.TestStep = "Verify Template Code option is not available in Template Selection dialog box from Phrase View screen";
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable.PerformTableAction(1, 5, TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[4]);
                IList<IWebElement> contextitems = FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A")).ToList();
                foreach(IWebElement contextitem in contextitems)
                {
                    if( (contextitem.Text.ToString() == "Phrase") || (contextitem.Text.ToString() == "Misc") || (contextitem.Text.ToString() == "Restart Numbering") || (contextitem.Text.ToString() == "Restart Numbering") || (contextitem.Text.ToString() == "Section Break") || (contextitem.Text.ToString() == "Template"))
                    {
                        Reports.StatusUpdate("Not Found any Template Code Object/Item", true);
                    }
                }
               
                 

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
