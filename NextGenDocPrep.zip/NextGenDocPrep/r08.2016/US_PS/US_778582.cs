﻿using FASTSelenium.Common;
using FASTSelenium.ImageRecognition;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Input;

namespace NextGenDocPrep.r08._2016.US_PS
{
    /// <summary>
    /// Author: Ravi Naik
    /// Date: 5/11/2016  US_778582
    /// </summary>
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_778582 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);
            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);

            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        private int CreateDocumentusingWCFService(int DocTemplateTypeId, string DocName)
        {
            var GetDocTempReq = RequestFactory.GetDocTemplateRequest(DocTemplateTypeId, regionId);
            var GetDocTempRes = FASTWCFHelpers.FileService.GetDocTemplates(GetDocTempReq);
            int index;
            for (index = 0; index < GetDocTempRes.Templates.Length - 1; index++)
            {
                if (GetDocTempRes.Templates[index].Descr.Contains(DocName))
                {
                    int templateID1 = Convert.ToInt32(GetDocTempRes.Templates[index].TemplateID);
                    break;
                }
            }
            int templateID = Convert.ToInt32(GetDocTempRes.Templates[index].TemplateID);

            var CreateDocReq = RequestFactory.GetCreateDocumentDefaultRequest(File.FileID.Value, templateID);
            CreateDocReq.TemplateID = templateID;
            CreateDocReq.FileID = File.FileID;
            CreateDocReq.TitleReportDocumentID = 0;

            var CreateDocRes = FASTWCFHelpers.FileService.CreateDocument(CreateDocReq);

            return Convert.ToInt32(CreateDocRes.DocumentID);
        }

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        private void InsertDataElement()
        {

            var currentLine = FastDriver.DocumentEditor.IRDocumentCurrentLine.Offset(624, 164);
            if (currentLine.DelayOnce(10).Visible() == false)
                currentLine.DelayOnce(60);
            currentLine.FAClick();
            Keyboard.SendKeys("[Test]");
            FastDriver.DocumentEditor.IRDocumentCurrentLine.DelayOnce(3).Offset(680, 164).ContextClick();
            FastDriver.DocumentEditor.IR_CM_InsertDataElement.DelayOnce(3).Offset(686, 170).FAClick();
            FastDriver.DocumentEditor.IRInsertSearch.Offset(1140, 160).FAClick();
            Keyboard.SendKeys(FAKeys.Enter);
            FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
            FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItemBySendingKeys("Buyer");
            FastDriver.DataElementSelectionDlg.WaitCreation(FastDriver.DataElementSelectionDlg.SearchResult);
            FastDriver.DataElementSelectionDlg.GetSearchResult(0).FAClick();
            FastDriver.DataElementSelectionDlg.Select.FAClick();
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.IRSave.DelayOnce(6).Offset(1850, 50).FAClick();
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.Close.FAClick();
            FastDriver.DocumentEditor.Yes.FAClick();
            Playback.Wait(6000);
        }

        private void InsertPhrase(string tplPhraseName, string phraseDescription)
        {
            var insertPhrase = FastDriver.DocumentEditor.IRInsertPhrase.Offset(220, 250 - 110);
            if (insertPhrase.DelayOnce(10).Visible() == false)
                insertPhrase.DelayOnce(60);
            insertPhrase.ContextClick();
            FastDriver.DocumentEditor.IRInsertPhraseBottom.Offset(240, 290 - 110).FAClick();
            //
            Reports.TestStep = "Enter phrase code and hit enter to insert phrase (or) Click Search Button \"…\" for inserting phrase";
            FastDriver.DocumentEditor.IRInsertSearch.DelayOnce(3).Offset(568, 308 - 130).DoubleClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
            //
            Reports.TestStep = "Select a phrase from the phrase search dialog and click on done button";
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.Description.FASetText(phraseDescription);
            FastDriver.PhraseSelectDlg.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, tplPhraseName, 1, TableAction.Click);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.IRSave.DelayOnce(6).Offset(1800, 50).FAClick();
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.Close.FAClick();
            FastDriver.DocumentEditor.Yes.FAClick();
            Playback.Wait(6000);
        }

        private void Phrase_phraseGrp_Template(string phraseGrp_Name, string phrase_Type, string templateName, string templateDescription, string templateType)
        {
            #region Verify that if Template is present
            Reports.TestStep = "Check if Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDescription);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDescription);
            #endregion

            if (!templateExists)
            {

                #region Create new phrase group
                Reports.TestStep = "Create new phrase group";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                var groupName = Support.RandomString(phraseGrp_Name);

                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);


                var groupDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));

                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);

                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem(phrase_Type);

                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                #endregion

                #region Add phrases
                Reports.TestStep = "Add phrases";
                FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);

                var phraseName = Support.RandomString(phraseGrp_Name);

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);

                var phraseDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));

                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                #endregion

                #region Insert phrases
                Reports.TestStep = "Insert phrases";
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertDataElement();
                #endregion

                #region Create template

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Create a new template";

                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                templateName = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(4));
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                templateDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(26));
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDescription);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                #endregion

                #region Insert template
                Reports.TestStep = "Insert template";
                FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                FastDriver.NextGenDocumentPreparation.Editor.FADoubleClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertPhrase(groupName + "/" + phraseName, phraseDescription);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDescription + " already exist", true);
            }


            #endregion

        }

        #region TestCase 796766 -Validate message is displayed when Form is checked out by logged user in Admin | Return only by user

        [TestMethod]
        [Description(" Validate message is displayed when Form is checked out by logged user in Admin | Return only by user")]
        public void TestCase_796766()
        {
            try
            {
                Reports.TestDescription = "Validate message is displayed when Form is checked out by logged user in Admin | Return only by user";
                Reports.TestStep = "Login to ADM site";
                FAST_Login_ADM(regionId: regionId);
                               
                Reports.TestStep = "Navigate to Document Preparation screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on \"Form\" tab";
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.CheckedOutStatusForm);

                Reports.TestStep = "Active forms which are checked out";
                FastDriver.NextGenDocumentPreparation.FormsStatus.FASelectItem("Active");
                FastDriver.NextGenDocumentPreparation.CheckedOutStatusForm.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.CheckedOutStatusForm.FAClick();
                FastDriver.NextGenDocumentPreparation.CheckedOutToUser.FASetText("fastts\\fastqa07");
                
                Reports.TestStep = "Click on \"Search\" button";
                FastDriver.NextGenDocumentPreparation.SearchForm.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading.. Please Wait...", false, 100);
                FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction("Form Description", "QA MJJP Test Form Field 4", "Info", TableAction.GetCell).Element.FindElement(By.TagName("IMG")).FAClick();
                string message = FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);

                Reports.TestStep = "Verify Dialog message";
                Support.AreEqual("Document checked out by  FASTTS\\FASTQA07", message);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase 796771 - Validate message is displayed when Form is checked out by logged user in Admin | Return all forms

        [TestMethod]
        [Description("Validate message is displayed when Form is checked out by logged user in Admin | Return all forms")]
        public void TestCase_796771()
        {
            try
            {
                Reports.TestDescription = "Validate message is displayed when Form is checked out by logged user in Admin | Return all forms";
                Reports.TestStep = "Login to ADM site";
                FAST_Login_ADM(regionId: regionId);

                Reports.TestStep = "Navigate to Document Preparation screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on \"Form\" tab";
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.CheckedOutStatusForm);

                Reports.TestStep = "Active forms which are checked out Return all forms, regardless of check out state";
                FastDriver.NextGenDocumentPreparation.FormsStatus.FASelectItem("Active");
                FastDriver.NextGenDocumentPreparation.CheckedOutStatusAllForm.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.CheckedOutStatusAllForm.FAClick();
               

                Reports.TestStep = "Click on \"Search\" button";
                FastDriver.NextGenDocumentPreparation.SearchForm.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading.. Please Wait...", false, 100);

                if(FastDriver.NextGenDocumentRepository.PagingON.IsVisible() == true)
                {
                    FastDriver.NextGenDocumentRepository.PagingON.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);
                }

                FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction("Form Description", "QA MJJP Test Form Field 4", "Info", TableAction.GetCell).Element.FindElement(By.TagName("IMG")).FAClick();
                string message = FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);

                Reports.TestStep = "Verify Dialog message";
                Support.AreEqual("Document checked out by  FASTTS\\FASTQA07", message);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase 796773 - Validate message is displayed when Form is checked out by logged user in Admin | Return all forms | not check out

        [TestMethod]
        [Description("Validate message is displayed when Form is checked out by logged user in Admin | Return all forms | not check out")]
        public void TestCase_796773()
        {
            try
            {
                Reports.TestDescription = "Validate message is displayed when Form is checked out by logged user in Admin | Return all forms";
                Reports.TestStep = "Login to ADM site";
                FAST_Login_ADM(false,regionId: regionId);
               
                Reports.TestStep = "Navigate to Document Preparation screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on \"Form\" tab";
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.CheckedOutStatusForm);

                Reports.TestStep = "Active forms which are checked out Return all forms, regardless of check out state";
                FastDriver.NextGenDocumentPreparation.FormsStatus.FASelectItem("Active");
                FastDriver.NextGenDocumentPreparation.CheckedOutStatusAllForm.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.CheckedOutStatusAllForm.FAClick();


                Reports.TestStep = "Click on \"Search\" button";
                FastDriver.NextGenDocumentPreparation.SearchForm.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading.. Please Wait...", false, 100);

                if (FastDriver.NextGenDocumentRepository.PagingON.IsVisible() == true)
                {
                    FastDriver.NextGenDocumentRepository.PagingON.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);
                }
                int rows = FastDriver.NextGenDocumentPreparation.FormsTable.GetRowCount();
                for (int i = 2; i < rows; i++)
                {
                    if(FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(i, 2, TableAction.GetCell).Element.FindElements(By.TagName("IMG")).Count > 0)                    
                    {
                        continue;
                    }
                    else
                    {
                        FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(i, 6, TableAction.GetCell).Element.FindElement(By.Id("retfrmcheckout")).FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SearchForm);
                        Support.AreEqual(bool.TrueString, FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(i, 2, TableAction.GetCell).Element.FindElement(By.TagName("IMG")).Exists().ToString());
                        string formname = FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction(i, 3, TableAction.GetText).Message;

                        FastDriver.NextGenDocumentPreparation.Open();

                        Reports.TestStep = "Click on \"Form\" tab";
                        FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.CheckedOutStatusForm);

                        Reports.TestStep = "Active forms which are checked out Return all forms, regardless of check out state";
                        FastDriver.NextGenDocumentPreparation.FormsStatus.FASelectItem("Active");
                        FastDriver.NextGenDocumentPreparation.CheckedOutStatusAllForm.FASetCheckbox(true);
                        FastDriver.NextGenDocumentPreparation.CheckedOutStatusAllForm.FAClick();


                        Reports.TestStep = "Click on \"Search\" button";
                        FastDriver.NextGenDocumentPreparation.SearchForm.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Loading.. Please Wait...", false, 100);

                        if (FastDriver.NextGenDocumentRepository.PagingON.IsVisible() == true)
                        {
                            FastDriver.NextGenDocumentRepository.PagingON.FAClick();
                            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);
                        }

                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SearchForm);

                        FastDriver.NextGenDocumentPreparation.FormsTable.PerformTableAction("Form Description", formname, "Info", TableAction.GetCell).Element.FindElement(By.TagName("IMG")).FAClick();
                        string message = FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);

                        Reports.TestStep = "Verify Dialog message";
                        Support.AreEqual("Document checked out by  FASTTS\\FASTQA07", message);
                        break;
                        
                    }
                }

                

            
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase 796801 - Validate message is displayed when Form is checked out by logged user in Admin | Return only by user |  Click on top

        [TestMethod]
        [Description("Validate message is displayed when Form is checked out by logged user in Admin | Return only by user |  Click on top")]
        public void TestCase_796801()
        {
            try
            {
                Reports.TestStep = "Login to ADM site";
                FAST_Login_ADM(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Navigate to Document Preparation screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on \"Form\" tab";
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CheckedOutStatusForm.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.CheckedOutStatusForm.FAClick();
                Reports.TestStep = "Click on \"Search\" button";
                FastDriver.NextGenDocumentPreparation.SearchForm.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);
                FastDriver.NextGenDocumentPreparation.Formcheckout.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase 796803 - Validate message is displayed when Form is checked out by logged user in Admin | Return all forms | Click on top

        [TestMethod]
        [Description("Validate message is displayed when Form is checked out by logged user in Admin | Return all forms | Click on top")]
        public void TestCase_796803()
        {
            try
            {
                Reports.TestStep = "Login to ADM site";
                FAST_Login_ADM(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Navigate to Document Preparation screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on \"Form\" tab";
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CheckedOutStatusAllForm.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.CheckedOutStatusAllForm.FAClick();
                Reports.TestStep = "Click on \"Search\" button";
                FastDriver.NextGenDocumentPreparation.SearchForm.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);
                FastDriver.NextGenDocumentPreparation.Formcheckout.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region TestCase 796805 - Validate message is displayed when Form is checked out by logged user in Admin | Return all forms | not check out | Click on top

        [TestMethod]
        [Description("Validate message is displayed when Form is checked out by logged user in Admin | Return all forms | not check out | Click on top")]
        public void TestCase_796805()
        {
            try
            {
                Reports.TestStep = "Login to ADM site";
                FAST_Login_ADM(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Navigate to Document Preparation screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on \"Form\" tab";
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CheckedOutStatusAllForm.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.CheckedOutStatusAllForm.FAClick();
                Reports.TestStep = "Click on \"Search\" button";
                FastDriver.NextGenDocumentPreparation.SearchForm.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);
                FastDriver.NextGenDocumentPreparation.Formcheckout.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
