﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;

namespace NextGenDocPrep.r08._2016.US_PS
{
    /// <summary>
    /// Author: Ravi Naik
    /// Date: 5/13/2016  US_804809
    /// </summary>
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_804809 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);
            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);

            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        private int CreateDocumentusingWCFService(int DocTemplateTypeId, string DocName)
        {
            var GetDocTempReq = RequestFactory.GetDocTemplateRequest(DocTemplateTypeId, regionId);
            var GetDocTempRes = FASTWCFHelpers.FileService.GetDocTemplates(GetDocTempReq);
            int index;
            for (index = 0; index < GetDocTempRes.Templates.Length - 1; index++)
            {
                if (GetDocTempRes.Templates[index].Descr.Contains(DocName))
                {
                    int templateID1 = Convert.ToInt32(GetDocTempRes.Templates[index].TemplateID);
                    break;
                }
            }
            int templateID = Convert.ToInt32(GetDocTempRes.Templates[index].TemplateID);

            var CreateDocReq = RequestFactory.GetCreateDocumentDefaultRequest(File.FileID.Value, templateID);
            CreateDocReq.TemplateID = templateID;
            CreateDocReq.FileID = File.FileID;
            CreateDocReq.TitleReportDocumentID = 0;

            var CreateDocRes = FASTWCFHelpers.FileService.CreateDocument(CreateDocReq);

            return Convert.ToInt32(CreateDocRes.DocumentID);
        }

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        private void InsertDataElement()
        {

            var currentLine = FastDriver.DocumentEditor.IRDocumentCurrentLine.Offset(624, 164);
            if (currentLine.DelayOnce(10).Visible() == false)
                currentLine.DelayOnce(60);
            currentLine.FAClick();
            Keyboard.SendKeys("[Test]");
            FastDriver.DocumentEditor.IRDocumentCurrentLine.DelayOnce(3).Offset(680, 164).ContextClick();
            FastDriver.DocumentEditor.IR_CM_InsertDataElement.DelayOnce(3).Offset(686, 170).FAClick();
            FastDriver.DocumentEditor.IRInsertSearch.Offset(1140, 160).FAClick();
            Keyboard.SendKeys(FAKeys.Enter);
            FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
            FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItemBySendingKeys("Buyer");
            FastDriver.DataElementSelectionDlg.WaitCreation(FastDriver.DataElementSelectionDlg.SearchResult);
            FastDriver.DataElementSelectionDlg.GetSearchResult(0).FAClick();
            FastDriver.DataElementSelectionDlg.Select.FAClick();
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.IRSave.DelayOnce(6).Offset(1850, 50).FAClick();
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.Close.FAClick();
            FastDriver.DocumentEditor.Yes.FAClick();
            Playback.Wait(6000);
        }

        private void InsertPhrase(string tplPhraseName, string phraseDescription)
        {
            var insertPhrase = FastDriver.DocumentEditor.IRInsertPhrase.Offset(220, 250 - 110);
            if (insertPhrase.DelayOnce(10).Visible() == false)
                insertPhrase.DelayOnce(60);
            insertPhrase.ContextClick();
            FastDriver.DocumentEditor.IRInsertPhraseBottom.Offset(240, 290 - 110).FAClick();
            //
            Reports.TestStep = "Enter phrase code and hit enter to insert phrase (or) Click Search Button \"…\" for inserting phrase";
            FastDriver.DocumentEditor.IRInsertSearch.DelayOnce(3).Offset(568, 308 - 130).DoubleClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
            //
            Reports.TestStep = "Select a phrase from the phrase search dialog and click on done button";
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.Description.FASetText(phraseDescription);
            FastDriver.PhraseSelectDlg.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, tplPhraseName, 1, TableAction.Click);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.IRSave.DelayOnce(6).Offset(1800, 50).FAClick();
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.Close.FAClick();
            FastDriver.DocumentEditor.Yes.FAClick();
            Playback.Wait(6000);
        }

        private void Phrase_phraseGrp_Template(string phraseGrp_Name, string phrase_Type, string templateName, string templateDescription, string templateType)
        {
            #region Verify that if Template is present
            Reports.TestStep = "Check if Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDescription);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDescription);
            #endregion

            if (!templateExists)
            {

                #region Create new phrase group
                Reports.TestStep = "Create new phrase group";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                var groupName = Support.RandomString(phraseGrp_Name);

                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);


                var groupDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));

                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);

                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem(phrase_Type);

                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                #endregion

                #region Add phrases
                Reports.TestStep = "Add phrases";
                FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);

                var phraseName = Support.RandomString(phraseGrp_Name);

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);

                var phraseDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));

                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                #endregion

                #region Insert phrases
                Reports.TestStep = "Insert phrases";
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertDataElement();
                #endregion

                #region Create template

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Create a new template";

                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                templateName = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(4));
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                templateDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(26));
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDescription);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                #endregion

                #region Insert template
                Reports.TestStep = "Insert template";
                FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                FastDriver.NextGenDocumentPreparation.Editor.FADoubleClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertPhrase(groupName + "/" + phraseName, phraseDescription);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDescription + " already exist", true);
            }


            #endregion

        }

        #region Test Case 810815: User shall have the ability to create templates from Corporate

        [TestMethod]
        [Description("User shall have the ability to create templates from Corporate")]
        public void TestCase_810815()
        {
            try
            {
                Reports.TestStep = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Try search a few templates by different search type methods";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                var templateExists = templateTable.Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                if (templateExists)
                {
                    FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch").Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                    #region Document should be created in document Repository
                    Reports.TestStep = "Document should be created in document Repository";
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    var docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetText).Message;
                    Support.AreEqual(docName, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Document exists on the Search Result Table");
                }
                else
                    Reports.StatusUpdate("Template: " + "TitleReport" + "Not Found", true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Test Case 810816: User shall have the ability to get all templates from Corporate , Region or both in Search Results

        [TestMethod]
        [Description("User shall have the ability to get all templates from Corporate , Region or both in Search Results")]
        public void TestCase_810816()
        {
            try
            {
                Reports.TestStep = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Try search a few templates by different search type methods";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.TemplatesTable.FeeExistOnTable("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Test Case 810819: Filtered Templates View should be default view

        [TestMethod]
        [Description("Filtered Templates View should be default view")]
        public void TestCase_810819()
        {
            try
            {
                Reports.TestStep = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Try search a few templates by different search type methods";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.TemplatesTable.FeeExistOnTable("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Test Case 820048: User shall NOT be able to search by Another Region in Source apart from Corporate

        [TestMethod]
        [Description("User shall NOT be able to search by Another Region in Source apart from Corporate")]
        public void TestCase_820048()
        {
            try
            {
                Reports.TestStep = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Try search a few templates by different search type methods";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("MeraCord Sign up Package-N");

                FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
                FastDriver.NextGenDocumentRepository.SelectRegion.FASetCheckbox(false);
                FastDriver.NextGenDocumentRepository.Corporate.FASetCheckbox(false);
                //FastDriver.NextGenDocumentRepository.CaliforniaRegion.FAClick();

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                Support.AreNotEqual("True", FastDriver.NextGenDocumentRepository.TemplatesTable.FeeExistOnTable("MeraCord Sign up Package-N").ToString());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Test Case 820065: User shall have the ability to Search by type or Description

        [TestMethod]
        [Description("User shall have the ability to Search by type or Description")]
        public void TestCase_820065()
        {
            try
            {
                Reports.TestStep = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Try search a few templates by different search type methods";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.TemplatesTable.FeeExistOnTable("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString());

                Reports.TestStep = "Verify the Search by selecting Recently Used";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Recently Used Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Super EAGLE Commitment (all states)-N");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.TemplatesTable.FeeExistOnTable("Super EAGLE Commitment (all states)-N").ToString());

                Reports.TestStep = "Verify the Search by selecting Filtered Templates";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.TemplatesTable.FeeExistOnTable("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString());

                Reports.TestStep = "Verify the Search by selecting Favorite Templates";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TC466566");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.TemplatesTable.FeeExistOnTable("TC466566").ToString());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Test Case 820080: User shall have the ability to get templates from Corporate only when set in Source

        [TestMethod]
        [Description("User shall have the ability to get templates from Corporate only when set in Source")]
        public void TestCase_820080()
        {
            try
            {
                Reports.TestStep = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Try search a few templates by different search type methods";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Assignment of Escrow-Notice-N");
                FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FindElement(By.Id("ddcl-ddl_sources")).FADoubleClick();

                FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
                FastDriver.NextGenDocumentRepository.SelectRegion.FASetCheckbox(false);
                FastDriver.NextGenDocumentRepository.Corporate.FASetCheckbox(true);

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.TemplatesTable.FeeExistOnTable("Assignment of Escrow-Notice-N").ToString());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Test Case 820082: User shall have the ability to get templates from Region only when set in Source

        [TestMethod]
        [Description("User shall have the ability to get templates from Region only when set in Source")]
        public void TestCase_820082()
        {
            try
            {
                Reports.TestStep = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Try search a few templates by different search type methods";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FindElement(By.Id("ddcl-ddl_sources")).FADoubleClick();

                FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
                FastDriver.NextGenDocumentRepository.SelectRegion.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Corporate.FASetCheckbox(false);

                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.TemplatesTable.FeeExistOnTable("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Test Case 820085: User shall have the ability to get templates from both when set in Source

        [TestMethod]
        [Description("User shall have the ability to get templates from both when set in Source")]
        public void TestCase_820085()
        {
            try
            {
                Reports.TestStep = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Try search a few templates by different search type methods";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.TemplatesTable.FeeExistOnTable("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString());
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region To verify the versioning of a template and phrase.| ADM | IIS |

        [TestMethod]
        [Description("To verify the versioning of a template and phrases.| ADM | IIS |")]
        public void TestCase_941589()
        {
            try
            {
                string RandomtemplateName = Support.RandomString("AAAAAAA");
                string RandomDescription = Support.RandomString("AAAAAAA");
                string RamdonPhraseName = Support.RandomString("AAAA");
                string RamdonDescriptionPhrase = Support.RandomString("AAAAAA");
                //Second Phrases 
                string RamdonPhraseNameSe = Support.RandomString("AAA");
                string RamdonDescriptionPhraseSe = Support.RandomString("AAAA");
             
              


                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Create first Phrases
                Reports.TestStep = "Create first Phrases";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.CreateNewPhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("please wait...", false);
                FastDriver.NextGenDocumentPreparation.GroupName.FASendKeys(RamdonPhraseName);
                FastDriver.NextGenDocumentPreparation.Description.FASendKeys(RamdonDescriptionPhrase);
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Escrow Phrase[ESCROW]");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("please wait...", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTables.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("please wait...", false);
                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASendKeys(RamdonPhraseName);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASendKeys(RamdonDescriptionPhrase);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("please wait...", false);
                #endregion

                #region Create Second Phrases
                Reports.TestStep = "Create Second Phrases";
                FastDriver.NextGenDocumentPreparation.PhraseSearch.FAClick();                
                FastDriver.WebDriver.WaitForWindowAndSwitch("please wait...", false);
                FastDriver.NextGenDocumentPreparation.CreateNewPhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("please wait...", false);
                FastDriver.NextGenDocumentPreparation.GroupName.FASendKeys(RamdonPhraseNameSe);
                FastDriver.NextGenDocumentPreparation.Description.FASendKeys(RamdonDescriptionPhraseSe);
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Escrow Phrase[ESCROW]");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("please wait...", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTables.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("please wait...", false);
                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASendKeys(RamdonPhraseNameSe);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASendKeys(RamdonDescriptionPhraseSe);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("please wait...", false);
                #endregion

                #region Navigate to NextGen Document Preparation/Templates Search/ Create a Template
                Reports.TestStep = " Navigate to NextGen Document Preparation/Templates Search/ Create a Template";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                var templateExists = templateTable.Contains(RandomDescription);
                if (!templateExists)
                {
                    FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(RandomDescription);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Form");
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    Reports.StatusUpdate("Template: " + RandomDescription + " just created", true);

                }
                else
                {
                    Reports.StatusUpdate("Template: " + RandomDescription + " already exist", true);
                }
                FastDriver.NextGenDocumentPreparation.VersioningTemplate.Highlight();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                #endregion

                #region Verify Versioning  on Template
                Reports.TestStep = "Verify Versioning  on Template ";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please.....", false, 20);
                Support.AreNotEqual("36266", FastDriver.NextGenDocumentPreparation.VersioningTemplate.FAGetText().ToString());

                #endregion

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion

                #region Phrases Selection Dialogue and Phrase Type
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type ";
                //First Phrase
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();       
                FastDriver.PhraseSelectDlg.PhraseName.FASendKeys(RamdonPhraseName);
                FastDriver.PhraseSelectDlg.PhraseName.FASendKeys("/");
                FastDriver.PhraseSelectDlg.PhraseName.FASendKeys(RamdonPhraseName);               
                FastDriver.PhraseSelectDlg.PhraseName.FASendKeys(",");
                // Second Phrase
                FastDriver.PhraseSelectDlg.PhraseName.FASendKeys(RamdonPhraseNameSe);
                FastDriver.PhraseSelectDlg.PhraseName.FASendKeys("/");
                FastDriver.PhraseSelectDlg.PhraseName.FASendKeys(RamdonPhraseNameSe);             
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Verify version on Phrases
                Reports.TestStep = "Verify Version on Phrases";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                Support.AreNotEqual("406772", FastDriver.NextGenDocumentPreparation.PropertiesPhrasesVerssioning.FAGetText().ToString());
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(3, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                Support.AreNotEqual("406773", FastDriver.NextGenDocumentPreparation.PropertiesPhrasesVerssioning.FAGetText().ToString());
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                #endregion

                //IIS

                #region DataSetup IIS
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search criteria All Templates Option
                Reports.TestStep = "Perform Select Template Search criteria All Templates Option";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);                
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click, "Exchange Delayed").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);

                #endregion

                // ADM

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Search  a Template created above  
                Reports.TestStep = "Search  a Template created above ";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);         
                #endregion

                #region Verify version each phrases 
                Reports.TestStep = "Verify Version each Phrases";
                // Verify First Phrase 
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(2, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("24");
                FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("12");
                FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                Support.AreNotEqual("406774", FastDriver.NextGenDocumentPreparation.PropertiesPhrasesVerssioning.FAGetText().ToString());
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);

                // Verify Second Phrase 
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(3, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("28");
                FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("8");
                FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                Support.AreNotEqual("406775", FastDriver.NextGenDocumentPreparation.PropertiesPhrasesVerssioning.FAGetText().ToString());
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false,15);
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion

                #region Verify Versioning  on Template
                Reports.TestStep = "Verify Versioning  on Template ";
                FastDriver.NextGenDocumentPreparation.Templates_PropertiesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please.....", false,10);
                Support.AreNotEqual("36315", FastDriver.NextGenDocumentPreparation.VersioningTemplate.FAGetText().ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please.....", false, 10);
                #endregion



              


        #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }










        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
