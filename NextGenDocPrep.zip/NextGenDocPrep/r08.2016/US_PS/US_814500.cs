﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NextGenDocPrep.r08._2016.US_PS
{
    [CodedUITest]
    public class US_814500 : FASTHelpers
    {
        SilverlightSupport FALibSL = new SilverlightSupport();
        [TestMethod]
        [Description("US#814500 - 10.5 Release, NextGen Sanity, Error message for County/City filters")]

        public void TestCase_820336()
        {
            try
            {
               
                #region Login Fast
                Reports.TestStep = "Login into the IIS screen.";
                FAST_Login_IIS();
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

         
                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion


                #region Navigate to NextGen Document Repository/Templates Search
                Reports.TestStep = "Navigate to NextGen Document Repository screen/Templates Search";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Template Search Criteria
                Reports.TestStep = "Click on Template Search criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion.

                #region Filter options add State
                Reports.TestStep = "In filter options add State filter";
                FastDriver.NextGenDocumentRepository.ddl_FilterTypes.FASelectItem("State");
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Remove State filter
                Reports.TestStep = "Remove State filter clicking on X option";
                FastDriver.NextGenDocumentRepository.XRemoveFilter.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual(false.ToString(),FastDriver.WebDriver.WaitForAlertToExist(60).ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }


        [ClassCleanup]
        public static void ClassCleanup()
        {
            MasterTestClass.CleanupClass();
        }
    }
}
