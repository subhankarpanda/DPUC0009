﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.IIS;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;

namespace NextGenDocPrep.r08._2016.US_PS
{
    [CodedUITest]
    public class US_815572 : FASTHelpers
    {
        SilverlightSupport FALibSL = new SilverlightSupport();
        [TestMethod]
        [Description("US#815572 - INC2883916-10.5 Release, NextGen Sanity, Policy Issued date DE not displaying")]
        

        public void TestCase_821768()
        {
            try
            {

                Reports.TestDescription = "Test Case#821768- Validate Policy Issue Date is displayed in Phrase View";
                String tempName = "OWNERP-00";
                String tempDesc = "Policy Issue Date Owner Policy";
                String Temptype = "Owner Policy";
                String Phrasecode = "TP13/27";

                //Owner Policy Template Creation
                LoadOrCreateTemp(tempName, tempDesc, Temptype);
                AddPhrase(tempDesc, Temptype, Phrasecode);

                //Login to FAST
                #region Login Fast
                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                //Precondition
                #region Create a  File
                Reports.TestStep = "Create a file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD | Buyer/Seller Info | Lender";
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFirstName");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLastName");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFirstName");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLastName");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("248");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                String FileNum = FastDriver.FileHomepage.txtFileNumber.FAGetValue();
                #endregion

                #region Setting New Loan Insurance
                Reports.TestStep = "Set New Loan Insurance Information and Loan Number";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("0123456");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("0123");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to NextGen Document Repository/Templates Search
                Reports.TestStep = "Navigate to NextGen Document Repository/Templates Search";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Search  and create Title Reports Document with Effective Date and verified it was created in Document Repository screen
                Reports.TestStep = "Search  and create Title Reports Document with Effective Date:  Set Type to Filtered Templates, Title Reports type and click on Search button";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click).Element.FAClick();
                var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(3, 1, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText("05/17/2016");
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(templateName).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion
                

                
                //Inicio steps test case
                #region Login Fast
                Reports.TestStep = "Login to FAST IIS screen";
                FAST_Login_IIS();
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Search file from precondition and navigate to Document Repository screen
                Reports.TestStep = "Search for file from precondition and navigate to Document Repository screen";
                FastDriver.TopFrame.SetNumberAndPressEnter(FileNum);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search for a Policy
                Reports.TestStep = "In Template Search screen search for a Policy document";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem(Temptype);
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempDesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Add Policy in Doc Rep
                Reports.TestStep = "Add policy document to Document Repository screen";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(tempDesc).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion

                #region Select Policy and right click for Phrase View/Edit
                Reports.TestStep = "Select policy document from Document Repository and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, tempDesc, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Complete Policy Number and Policy Issue Date
                Reports.TestStep = "Complete policy number and Issue date and click on save button";
                FastDriver.NextGenDocumentRepository.Policy_IssueDate.FASetText("05/17/2016");
                FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.FASetText(FileNum);
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
                #endregion

                #region Navigate to Phrase Tab
                Reports.TestStep = "Navigate to Phrase View tab";
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search for Policy Issue Date Data Element in Phrase View screen
                Reports.TestStep = "Search for Policy Issue Date Data Element in Phrase View screen";
                Support.AreEqual("May 17, 2016", FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "Policy Issue Date", 4, TableAction.GetInputValue).Message.ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }


        }

        [TestMethod]
        public void TestCase_821795()
        {
            try
            {
                SetDisplayPDFinBrowser_ON();

                Reports.TestDescription = "Test Case#821768- Validate Policy Issue Date is displayed in Phrase View";
                String tempName = "OWNERP-00";
                String tempDesc = "Policy Issue Date Owner Policy";
                String Temptype = "Owner Policy";
                String Phrasecode = "TP13/27";

                //Owner Policy Template Creation
                LoadOrCreateTemp(tempName, tempDesc, Temptype);
                AddPhrase(tempDesc, Temptype, Phrasecode);

                //Login to FAST
                #region Login Fast
                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                //Precondition
                #region Create a  File
                Reports.TestStep = "Create a file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD | Buyer/Seller Info | Lender";
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("50,000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("50,000");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFirstName");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLastName");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFirstName");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLastName");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("248");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                String FileNum = FastDriver.FileHomepage.txtFileNumber.FAGetValue();
                #endregion

                #region Setting New Loan Insurance
                Reports.TestStep = "Set New Loan Insurance Information and Loan Number";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("0123456");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("0123");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to NextGen Document Repository/Templates Search
                Reports.TestStep = "Navigate to NextGen Document Repository/Templates Search";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Search  and create Title Reports Document with Effective Date and verified it was created in Document Repository screen
                Reports.TestStep = "Search  and create Title Reports Document with Effective Date:  Set Type to Filtered Templates, Title Reports type and click on Search button";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click).Element.FAClick();
                var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(3, 1, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText(DateTime.Now.Date.ToString("MM/dd/yyyy"));
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(templateName).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion



                //Inicio steps test case
                #region Login Fast
                Reports.TestStep = "Login to FAST IIS screen";
                FAST_Login_IIS();
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Search file from precondition and navigate to Document Repository screen
                Reports.TestStep = "Search for file from precondition and navigate to Document Repository screen";
                FastDriver.TopFrame.SetNumberAndPressEnter(FileNum);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search for a Policy
                Reports.TestStep = "In Template Search screen search for a Policy document";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem(Temptype);
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempDesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Add Policy in Doc Rep
                Reports.TestStep = "Add policy document to Document Repository screen";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(tempDesc).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion

                #region Select Policy and right click for Phrase View/Edit
                Reports.TestStep = "Select policy document from Document Repository and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, tempDesc, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Complete Policy Number and Policy Issue Date
                Reports.TestStep = "Complete policy number and Issue date and click on save button";
                FastDriver.NextGenDocumentRepository.Policy_IssueDate.FASetText(DateTime.Now.Date.ToString("MM/dd/yyyy"));
                FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.FASetText(FileNum);
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
                #endregion

                #region Navigate to Phrase Tab
                Reports.TestStep = "Navigate to Phrase View tab and finalized the document";
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentStatus.FASelectItemBySendingKeys("Finalized");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Search for Policy Issue Date Data Element in Phrase View screen
                Reports.TestStep = "Search for Policy Issue Date Data Element in Phrase View screen";

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                var validatePDF = FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "Policy Issue Date", 4, TableAction.GetInputValue).Message;

                Support.AreEqual(DateTime.Now.Date.ToString("MMMM dd, yyyy"), validatePDF.ToString());
                #endregion

               #region Preview document from Phrase View
               Reports.TestStep = "Try preview delivery method";
               FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItemBySendingKeys("preview");
               FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30);     // wait for delivery window to appear
               FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 300);   // wait for delivery window to disappear
               #endregion

               #region Save PDF file
               Reports.TestStep = "Save PDF file";
               string tempPdfFile = @"C:\Temp\temp.PDF";
               SavePDFFile(tempPdfFile);
               Playback.Wait(1600);
               #endregion

               #region Validate the PDF has 'Policy Date (and Time): May 17, 2016' in the document
               Reports.TestStep = "Validate the PDF has 'Policy Date (and Time): '" + DateTime.Now.Date.ToString("MMMM dd, yyyy") + "' in the document";
               var pdfTextContent = Support.ReadPdfFile(tempPdfFile);
               Support.AreEqual("True", pdfTextContent.Contains("Policy Date (and Time): " + DateTime.Now.Date.ToString("MMMM dd, yyyy")).ToString(), true);
               #endregion

               #region Close the Preview document
               Reports.TestStep = "Close the Preview document";
               FastDriver.WebDriver.ClosePreviewWindow();
               #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally
            {
                SetDisplayPDFinBrowser_OFF();
            }

        }


        [TestMethod]
        public void TestCase_821796()       
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                string tempName = "OWNERP-00";
                string tempDesc = "Policy Issue Date Owner Policy";
                string Temptype = "Owner Policy";
                string Phrasecode = "TP13/27";
                #endregion

                LoadOrCreateTemp(tempName, tempDesc, Temptype);
                AddPhrase(tempDesc, Temptype, Phrasecode);
                Reports.TestDescription = "User Story#815572- Validate Policy Issue Date is displayed in Document View Editor when document is finalized";

                Reports.TestStep = "Log into FAST IIS application.";
                FAST_Login_IIS();
                
                Reports.TestStep = "Navigate to Region Level";

                //Owner Policy Template Creation
                
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12839");

                #region Precondition
                Reports.TestStep = "Create a file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD | Buyer/Seller Info | Lender";
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("50,000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("50,000");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFirstName");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLastName");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFirstName");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLastName");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("248");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                String FileNum = FastDriver.FileHomepage.txtFileNumber.FAGetValue();

                Reports.TestStep = "Set New Loan Insurance Information and Loan Number";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("0123456");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("0123");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to NextGen Document Repository/Templates Search";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Search  and create Title Reports Document with Effective Date:  Set Type to Filtered Templates, Title Reports type and click on Search button";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click).Element.FAClick();
                var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(3, 1, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText(DateTime.Now.Date.ToString("MM/dd/yyyy"));
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(templateName).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }

                FastDriver.WebDriver.Quit();
                #endregion

                Reports.TestStep = "Log into FAST IIS application.";
                FAST_Login_IIS();

                Reports.TestStep = "Navigate to Region Level";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("12839");

                Reports.TestStep = "Search for file from precondition and navigate to Document Repository screen";
                FastDriver.TopFrame.SetNumberAndPressEnter(FileNum);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "In Template Search screen search for a Policy document";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem(Temptype);
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempDesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Add policy document to Document Repository screen";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(tempDesc).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }

                Reports.TestStep = "Select policy document from Document Repository and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, tempDesc, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Complete policy number and Issue date and click on save button";
                FastDriver.NextGenDocumentRepository.Policy_IssueDate.FASetText(DateTime.Now.Date.ToString("MM/dd/yyyy"));
                FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.FASetText(FileNum);
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.PhraseViewTab);
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                
                #region Navigate to Document info
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                #endregion
                

                Reports.TestStep = "Finalize Document";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempDesc, "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                
                FastDriver.WebDriver.FindElement(By.LinkText("Finalize")).FAMoveToElement();
                FastDriver.WebDriver.FindElement(By.LinkText("Finalize")).FASendKeys("{ENTER}");
                Mouse.Move(new System.Drawing.Point(0, 0));
                Playback.Wait(3000);

                FastDriver.WebDriver.FindElement(By.LinkText("Finalize")).FASelectContextMenuItem();
                Playback.Wait(3000);

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempDesc, "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.WebDriver.FindElement(By.LinkText("Document View/Edit")).FAMoveToElement();
                FastDriver.WebDriver.FindElement(By.LinkText("Document View/Edit")).FASendKeys("{ENTER}");
                Mouse.Move(new System.Drawing.Point(0, 0));
                Playback.Wait(3000);

                FastDriver.WebDriver.FindElement(By.LinkText("Document View/Edit")).FASelectContextMenuItem();

                Playback.Wait(220000);
                Keyboard.SendKeys("{HOME}");
                Playback.Wait(1000);
                Keyboard.PressModifierKeys(System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(1000);
                Keyboard.SendKeys("{END}");
                Keyboard.SendKeys("{DOWN}");
                Playback.Wait(500);
                Keyboard.SendKeys("{DOWN}");
                Keyboard.ReleaseModifierKeys(System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(1000);
                Keyboard.PressModifierKeys(System.Windows.Input.ModifierKeys.Control);
                Keyboard.SendKeys("c");
                Keyboard.ReleaseModifierKeys(System.Windows.Input.ModifierKeys.Control);
                Playback.Wait(1000);
                var content = System.Windows.Forms.Clipboard.GetText(TextDataFormat.UnicodeText);
                Reports.StatusUpdate("Teh clipboard content is: "+content, true);
                Reports.StatusUpdate("Verify whether the Data Element(s) is present within the Document.", true);
                Support.AreEqual("True", content.Contains(DateTime.Now.Date.ToString("MMMM dd, yyyy")).ToString(), true);

                
                //Moves mouse pointer to the close button on the docment editor 
                 Mouse.Move(new System.Drawing.Point(1847, 39));
                 Mouse.Click();
                 Playback.Wait(20000);
                 FastDriver.WebDriver.SwitchTo().DefaultContent();
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.Policy_IssueDate);
                 Support.AreEqual("False", string.IsNullOrEmpty(FastDriver.NextGenDocumentRepository.Policy_IssueDate.FAGetValue()).ToString());
                 Support.AreEqual("False", string.IsNullOrEmpty(FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.FAGetValue()).ToString());
                //FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Preview);
                Playback.Wait(20000);
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod]
        public void TestCase_821797()
        {
            try
            {

                SetDisplayPDFinBrowser_ON();

                Reports.TestDescription = "Test Case#821768- Validate Policy Issue Date is displayed in Phrase View";
                String tempName = "OWNERP-00";
                String tempDesc = "Policy Issue Date Owner Policy";
                String Temptype = "Owner Policy";
                String Phrasecode = "TP13/27";

                //Owner Policy Template Creation
                LoadOrCreateTemp(tempName, tempDesc, Temptype);
                AddPhrase(tempDesc, Temptype, Phrasecode);

                //Login to FAST
                #region Login Fast
                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                //Precondition
                #region Create a  File
                Reports.TestStep = "Create a file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD | Buyer/Seller Info | Lender";
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("50,000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("50,000");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFirstName");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLastName");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFirstName");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLastName");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("248");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                String FileNum = FastDriver.FileHomepage.txtFileNumber.FAGetValue();
                #endregion

                #region Setting New Loan Insurance
                Reports.TestStep = "Set New Loan Insurance Information and Loan Number";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("0123456");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("0123");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to NextGen Document Repository/Templates Search
                Reports.TestStep = "Navigate to NextGen Document Repository/Templates Search";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search  and create Title Reports Document with Effective Date and verified it was created in Document Repository screen
                Reports.TestStep = "Search  and create Title Reports Document with Effective Date:  Set Type to Filtered Templates, Title Reports type and click on Search button";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click).Element.FAClick();
                var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(3, 1, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText(DateTime.Now.Date.ToString("MM/dd/yyyy"));
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(templateName).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion



                //Inicio steps test case
                #region Login Fast
                Reports.TestStep = "Login to FAST IIS screen";
                FAST_Login_IIS();
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Search file from precondition and navigate to Document Repository screen
                Reports.TestStep = "Search for file from precondition and navigate to Document Repository screen";
                FastDriver.TopFrame.SetNumberAndPressEnter(FileNum);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search for a Policy
                Reports.TestStep = "In Template Search screen search for a Policy document";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem(Temptype);
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempDesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Add Policy in Doc Rep
                Reports.TestStep = "Add policy document to Document Repository screen";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(tempDesc).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion

                #region Select Policy and right click for Phrase View/Edit
                Reports.TestStep = "Select policy document from Document Repository and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, tempDesc, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Complete Policy Number and Policy Issue Date
                Reports.TestStep = "Complete policy number and Issue date and click on save button";
                FastDriver.NextGenDocumentRepository.Policy_IssueDate.FASetText(DateTime.Now.Date.ToString("MM/dd/yyyy"));
                FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.FASetText(FileNum);
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
                #endregion

                #region Navigate to Phrase Tab
                Reports.TestStep = "Navigate to Phrase View tab";
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search for Policy Issue Date Data Element in Phrase View screen
                Reports.TestStep = "Search for Policy Issue Date Data Element in Phrase View screen";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                var validPDF = FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "Policy Issue Date", 4, TableAction.GetInputValue).Message;
                Support.AreEqual(DateTime.Now.Date.ToString("MMMM dd, yyyy"), validPDF.ToString());
                #endregion

                #region Click Done button
                Reports.TestStep = "Click on Done button for document";
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...",false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                #endregion

                //taken from NG sanity
                #region Select Policy and right click for Delivery as preview option
                Reports.TestStep = "Select Policy and right click for Delivery as preview option";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempDesc, "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.WebDriver.FindElement(By.LinkText("Deliver")).FAMoveToElement();
                Mouse.Move(new System.Drawing.Point(0, 0));
                Playback.Wait(3000);

                FastDriver.WebDriver.FindElement(By.LinkText("Preview")).FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Preview);
                Playback.Wait(20000);
                #endregion

                #region Save PDF file
                Reports.TestStep = "Save PDF file";
                string savePath = @"C:\Reports\" + "PDFForTestting";
                CreateDirectory(savePath);
                string tempPdfFile = savePath+"\\"+ DateTime.Today.ToString("MMMddyyyy")+".PDF";
                SavePDFFile(tempPdfFile);
                Playback.Wait(1600);
                FastDriver.WebDriver.ClosePreviewWindow();
                #endregion

                #region Validate the PDF has 'Policy Date (and Time): May 17, 2016' in the document
                Reports.TestStep = "Validate the PDF has 'Policy Date (and Time): '" + DateTime.Now.Date.ToString("MMMM dd, yyyy") + "' in the document";
                var pdfTextContent = Support.ReadPdfFile(tempPdfFile);
                Support.AreEqual("True", pdfTextContent.Contains("Policy Date (and Time): " + DateTime.Now.Date.ToString("MMMM dd, yyyy")).ToString(), true);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally
            {
                SetDisplayPDFinBrowser_OFF();
            }

        }

        [TestMethod]
        public void TestCase_821788()
        {
            try
            {

                SetDisplayPDFinBrowser_ON();
                
                Reports.TestDescription = "Test Case#821768- Validate Policy Issue Date is displayed in Phrase View";
                String tempName = "OWNERP-00";
                String tempDesc = "Policy Issue Date Owner Policy";
                String Temptype = "Owner Policy";
                String Phrasecode = "TP13/27";

                //Owner Policy Template Creation
                LoadOrCreateTemp(tempName, tempDesc, Temptype);
                AddPhrase(tempDesc, Temptype, Phrasecode);

                //Login to FAST
                #region Login Fast
                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                //Precondition
                #region Create a  File
                Reports.TestStep = "Create a file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD | Buyer/Seller Info | Lender";
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("50,000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("50,000");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFirstName");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLastName");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFirstName");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLastName");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("248");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                String FileNum = FastDriver.FileHomepage.txtFileNumber.FAGetValue();
                #endregion

                #region Setting New Loan Insurance
                Reports.TestStep = "Set New Loan Insurance Information and Loan Number";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("0123456");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("0123");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to NextGen Document Repository/Templates Search
                Reports.TestStep = "Navigate to NextGen Document Repository/Templates Search";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search  and create Title Reports Document with Effective Date and verified it was created in Document Repository screen
                Reports.TestStep = "Search  and create Title Reports Document with Effective Date:  Set Type to Filtered Templates, Title Reports type and click on Search button";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click).Element.FAClick();
                var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(3, 1, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText(DateTime.Now.Date.ToString("MM/dd/yyyy"));
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(templateName).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion
                FastDriver.WebDriver.Quit();


                //Inicio steps test case
                #region Login Fast
                Reports.TestStep = "Login to FAST IIS screen";
                FAST_Login_IIS();
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Search file from precondition and navigate to Document Repository screen
                Reports.TestStep = "Search for file from precondition and navigate to Document Repository screen";
                FastDriver.TopFrame.SetNumberAndPressEnter(FileNum);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search for a Policy
                Reports.TestStep = "In Template Search screen search for a Policy document";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem(Temptype);
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempDesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion


                #region Add Policy in Doc Rep
                Reports.TestStep = "Add policy document to Document Repository screen";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(tempDesc).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion

                #region Select Policy and right click for Phrase View/Edit
                Reports.TestStep = "Select policy document from Document Repository and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, tempDesc, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Complete Policy Number and Policy Issue Date
                Reports.TestStep = "Complete policy number and Issue date and click on save button";
                FastDriver.NextGenDocumentRepository.Policy_IssueDate.FASetText(DateTime.Now.Date.ToString("MM/dd/yyyy"));
                FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.FASetText(FileNum);
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                Playback.Wait(220000);
                Keyboard.SendKeys("{HOME}");
                Playback.Wait(1000);
                Keyboard.PressModifierKeys(System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(1000);
                Keyboard.SendKeys("{END}");
                Keyboard.SendKeys("{DOWN}");
                Playback.Wait(500);
                Keyboard.SendKeys("{DOWN}");
                Keyboard.ReleaseModifierKeys(System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(1000);
                Keyboard.PressModifierKeys(System.Windows.Input.ModifierKeys.Control);
                Keyboard.SendKeys("c");
                Keyboard.ReleaseModifierKeys(System.Windows.Input.ModifierKeys.Control);
                
                
                //Mouse.Move(new System.Drawing.Point(Screen.PrimaryScreen.Bounds.Width/2, Screen.PrimaryScreen.Bounds.Height/2));
                //Mouse.Click();
                //FastDriver.WebDriver.SwitchTo().DefaultContent();
                //FastDriver.WebDriver.SwitchTo().ActiveElement().FASendKeys("+" + FAKeys.ArrowDown);
                //FastDriver.WebDriver.SwitchTo().ActiveElement().FASendKeys("+" + FAKeys.ArrowDown);
                //FastDriver.WebDriver.SwitchTo().ActiveElement().FASendKeys("^A");
                //Playback.Wait(1000);
                //FastDriver.WebDriver.SwitchTo().ActiveElement().FASendKeys("^C");
                //Playback.Wait(1000000);
                // Keyboard.SendKeys("+" + System.Windows.Forms.Keys.Down);
                //sendKeysToPhraseEditor("+", FAKeys.ArrowDown);
                Playback.Wait(1000);
               // Keyboard.SendKeys("+" + System.Windows.Forms.Keys.Down);
               // Keyboard.SendKeys("+" + System.Windows.Forms.Keys.Down);
                //sendKeysToPhraseEditor("+", FAKeys.ArrowDown);
               // Playback.Wait(1000);
               // Keyboard.SendKeys("^A");
              // // Playback.Wait(1000);
               // Keyboard.SendKeys("^C");
                var content = System.Windows.Forms.Clipboard.GetText(TextDataFormat.UnicodeText);
               Reports.StatusUpdate(content,true);
               Reports.StatusUpdate("Verify whether the Data Element(s) is present within the Document.",true);
               Support.AreEqual("True", content.Contains(DateTime.Now.Date.ToString("MMMM dd, yyyy")).ToString(), true);
               //Moves mouse pointer to the delivery option in the toolbar
                Mouse.Move(new System.Drawing.Point(1156, 65));
                Mouse.Click();
                Playback.Wait(1000);
                //Moves mouse pointer to the preview suboption from the delivery option
                Mouse.Move(new System.Drawing.Point(1172, 90));
                Mouse.Click();
                Playback.Wait(20000);

                #region Save PDF file
                Reports.TestStep = "Save PDF file";
                string savePath = @"C:\Reports\" + "PDFForTestting";
                CreateDirectory(savePath);
                string tempPdfFile = savePath + "\\" + DateTime.Today.ToString("MMMddyyyy") + ".PDF";
                SavePDFFile(tempPdfFile);
                Playback.Wait(1600);
                FastDriver.WebDriver.ClosePreviewWindow();
                #endregion

                #region Validate the PDF has 'Policy Date (and Time): May 17, 2016' in the document
                Reports.TestStep = "Validate the PDF has 'Policy Date (and Time): '" + DateTime.Now.Date.ToString("MMMM dd, yyyy") + "' in the document";
                var pdfTextContent = Support.ReadPdfFile(tempPdfFile);
                Support.AreEqual("True", pdfTextContent.Contains("Policy Date (and Time): " + DateTime.Now.Date.ToString("MMMM dd, yyyy")).ToString(), true);

                //Moves mouse pointer to the close button on the docment editor 
                Mouse.Move(new System.Drawing.Point(1847, 39));
                Mouse.Click();
                Playback.Wait(20000);
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                //FastDriver.WebDriver.SwitchTo().Conte();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.Policy_IssueDate);
                Support.AreEqual("False", string.IsNullOrEmpty(FastDriver.NextGenDocumentRepository.Policy_IssueDate.FAGetValue()).ToString());
                Support.AreEqual("False", string.IsNullOrEmpty(FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.FAGetValue()).ToString());

                #endregion
                //FastDriver.NextGenDocumentRepository.DocumentEditorObject.FAClick();

                #endregion
                //Playback.Wait(1000000000);
            }
            catch (Exception e)
            {
                
                FailTest(e.Message);
            }
        }
      #region custom class methods
        
        //Taken from Sanity code and US#691144
      
        private void LoadOrCreateTemp(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create Owner Policy Template";

            FAST_Login_ADM(isSuperUser: false);
            
            #region Region selection
            Reports.TestStep = "Navigate to QA Sandpointe NG Region";
            FastDriver.SecuritySelectRegionOffice.Open();
            FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
            #endregion

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Owner Policy Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            #region Create Template if not created
            Reports.TestStep = "Create Template if not created";
            if (!templateExists)
            {
                Reports.TestStep = "Creating Owner Policy Template " + templateDesc;
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (true)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                }

                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
            #endregion
        }

        public void AddPhrase(String TempDesc, String Temptype,String Phrasecode)
        {

            FAST_Login_ADM(isSuperUser: false);

            #region Region selection
            Reports.TestStep = "Navigate to QA Sandpointe NG Region";
            FastDriver.SecuritySelectRegionOffice.Open();
            FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
            #endregion

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Navigate to NextGen Document Preparation/Templates Search
            Reports.TestStep = "Navigate to NextGen Document Preparation/Templates Search";
            FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            #endregion

            #region Search Owner Policy Template and add phrases to it
            Reports.TestStep = "Search Template by Type & Description";
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(Temptype);
            FastDriver.NextGenDocumentPreparation.TemplateSearchRegions.FAClick();
            FastDriver.NextGenDocumentPreparation.AllRegions.FASetCheckbox(true);
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(TempDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable);

            if (FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.IsDisplayed())
            {

                    //Select Template for Edit
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentPreparation.TemplateResultsTable.StringExistOnTable(TempDesc).ToString());
                    FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    var PhraseTable = FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.GetAttribute("textContent");
                    var PhraseExists = PhraseTable.Contains(Phrasecode);

                if (!PhraseExists)
                {
                    //Click for Insert Phrase menu from Phrases sub-tab
                    Reports.TestStep = "Insert Phrases Option in Menu Context ";
                    FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);

                    //Insert Phrase which contains Policy Issue Date from Corporate
                    Reports.TestStep = "Phrases Selection Dialogue";
                    FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                    FastDriver.PhraseSelectDlg.Source.FASelectItem("Corporate");
                    FastDriver.PhraseSelectDlg.PhraseName.FASetText(Phrasecode);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();

                    //Save and Remove Under Construction Checkbox
                    Reports.TestStep = "Click Save and Under Construction ";
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                }
                else
                {
                    //Save and Remove Under Construction Checkbox
                    Reports.TestStep = "Click Save and Under Construction ";
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                }
            }
            else
            {
                Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
            }
            #endregion
 
        }

        //Taken from Sanity code
   
        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }
        public static void CreateDirectory(string DirectoryName)
        {
            if (!Directory.Exists(DirectoryName))
            {
                Directory.CreateDirectory(DirectoryName);
            }
        }

        private void sendKeysToPhraseEditor(string sModifier, string sKeys)
        {
            //FastDriver.WebDriver.SwitchTo().Frame("tbContentElement");
            FastDriver.PhraseEditorDlg.SwitchToDialogContentFrame();
            ModifierKeys modifier = ModifierKeys.None;
            if (sModifier == "^")
            {
                modifier = ModifierKeys.Control;
            }
            if (sModifier == "%")
            {
                modifier = ModifierKeys.Alt;
            }
            if (sModifier == "+")
            {
                modifier = ModifierKeys.Shift;
            }
            Keyboard.SendKeys(sKeys, modifier);
        }

        #endregion custom class methods





        [ClassCleanup]
        public static void ClassCleanup()
        {
            MasterTestClass.CleanupClass();
        }
    }

}
