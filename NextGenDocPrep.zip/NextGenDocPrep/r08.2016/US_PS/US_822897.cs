﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace NextGenDocPrep.r08._2016.US_PS
{
    [CodedUITest]
    public class US_822897 : FASTHelpers
    {
        SilverlightSupport FALibSL = new SilverlightSupport();
        [TestMethod]
        [Description("US#822897 - PROD-Exception Templates are displayed in Templates Search Criteria")]

        public void TestCase_828493()
        {
            try
            {
                Reports.TestDescription = "Test Case#828493 - Validate Exception Templates are not displayed in search results ADM";

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region Navigate to NextGen Document Preparation/Templates Search
                Reports.TestStep = "Navigate to NextGen Document Preparation/Templates Search";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                #endregion

                #region Search Exception Template
                Reports.TestStep = "In template Search Criteria :  Set Type to All, All Regions and Template Description as: 'Exception template' and click on Search button";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateSearchRegions.FAClick();
                FastDriver.NextGenDocumentPreparation.AllRegions.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Exception Template");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                Playback.Wait(3000);
                Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentPreparation.TemplateResultsTable.StringExistOnTable("Exception Template").ToString());             
                #endregion

                #region Click on New Search button
                Reports.TestStep = "Click on New Search button";
                FastDriver.NextGenDocumentPreparation.TemplateNewSearch.FAClick();
                #endregion

                #region Search Template by Corporate Region and No description
                Reports.TestStep = "In template Search Criteria :  Set Type to 'Exception Template', DOCPREP Corporate Region and click on Search button";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateSearchRegions.FAClick();
                FastDriver.NextGenDocumentPreparation.SelectRegionCheckbox("196").FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.SelectRegionCheckbox("12837").FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(30000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                Playback.Wait(30000);
                Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentPreparation.TemplateResultsTable.StringExistOnTable("Exception Template").ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

       [TestMethod]
       public void TestCase_828497()
        {
            try
            {
                Reports.TestDescription = "Test Case#828497 - Validate SDN Result Templates are not displayed in search results ADM";

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region Navigate to NextGen Document Preparation/Templates Search
                Reports.TestStep = "Navigate to NextGen Document Preparation/Templates Search";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                #endregion

                #region Search Exception Template
                Reports.TestStep = "In template Search Criteria :  Set Type to All, All Regions and Template Description as: 'SDN Result' and click on Search button";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateSearchRegions.FAClick();
                FastDriver.NextGenDocumentPreparation.AllRegions.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("SDN Template");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(element: FastDriver.NextGenDocumentPreparation.TemplateResultsTable);
                Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentPreparation.TemplateResultsTable.StringExistOnTable("SDN Template").ToString());
                #endregion

                #region Click on New Search button
                Reports.TestStep = "Click on New Search button";
                FastDriver.NextGenDocumentPreparation.TemplateNewSearch.FAClick();
                #endregion

                #region Search Template by Corporate Region and No description
                Reports.TestStep = "In template Search Criteria :  Set Type to 'SDN Result', DOCPREP Corporate Region and click on Search button";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("SDN Result");
                FastDriver.NextGenDocumentPreparation.TemplateSearchRegions.FAClick();
                FastDriver.NextGenDocumentPreparation.SelectRegionCheckbox("196").FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.SelectRegionCheckbox("12837").FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(element: FastDriver.NextGenDocumentPreparation.TemplateResultsTable);
                Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentPreparation.TemplateResultsTable.StringExistOnTable("SDN Template").ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

       [TestMethod]
       public void TestCase_828499()
       {
           try
           {
               Reports.TestDescription = "Test Case#828497 - Validate Exception Templates are not displayed in search results IIS";

               #region Login Fast
               Reports.TestStep = "Login into the IIS Side.";
               FAST_Login_IIS();
               #endregion


               #region Office selection
               Reports.TestStep = "Navigate to QA Sandpointe NG Region";
               FastDriver.SecuritySelectRegionOffice.Open();
               FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
               #endregion

               #region Create a  File
               Reports.TestStep = "Create a file";
               FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");

               try
               {
                   FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                   FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
               }
               catch
               {
                   Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
               }
               FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
               Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD";
               FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
               FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
               FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
               FastDriver.QuickFileEntry.SelectState("CA");
               FastDriver.BottomFrame.Done();
               FastDriver.FileHomepage.WaitForScreenToLoad();
               #endregion

               #region Navigate to NextGen Document Repository/Templates Search
               Reports.TestStep = "Navigate to NextGen Document Repository/Templates Search";
               FastDriver.NextGenDocumentRepository.Open();
               FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
               FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
               #endregion

               #region Search Exception Template
               Reports.TestStep = "In template Search Criteria :  Set Type to All Templates, All type and Template Description as: 'Exception template' and click on Search button";
               FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
               FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
               FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Exception template");
               FastDriver.NextGenDocumentRepository.Search.FAClick();
               FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);

               if (FastDriver.NextGenDocumentRepository.TableResults.IsDisplayed())
               {
                   Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.TableResults.StringExistOnTable("Exception Template").ToString());
               }
               else
               {
                   Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
               }
                           
               #endregion

           }
           catch (Exception ex)
           {
               FailTest(GetExceptionInfo(ex));
           }

       }
       [TestMethod]
       public void TestCase_828505()
       {
           try
           {
               Reports.TestDescription = "Test Case#828505 - Validate SDN Result Templates are not displayed in search results IIS";

               #region Login Fast
               Reports.TestStep = "Login into the IIS Side.";
               FAST_Login_IIS();
               #endregion


               #region Office selection
               Reports.TestStep = "Navigate to QA Sandpointe NG Region";
               FastDriver.SecuritySelectRegionOffice.Open();
               FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
               #endregion

               #region Create a  File
               Reports.TestStep = "Create a file";
               FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
               try
               {
                   FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                   FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
               }
               catch
               {
                   Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
               }
               FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
               Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD";
               FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
               FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
               FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
               FastDriver.QuickFileEntry.SelectState("CA");
               FastDriver.BottomFrame.Done();
               FastDriver.FileHomepage.WaitForScreenToLoad();
               #endregion

               #region Navigate to NextGen Document Repository/Templates Search
               Reports.TestStep = "Navigate to NextGen Document Repository/Templates Search";
               FastDriver.NextGenDocumentRepository.Open();
               FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
               FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
               #endregion

               #region Search Exception Template
               Reports.TestStep = "In template Search Criteria :  Set Type to All Templates, All types and Template Description as: 'SDN Template' and click on Search button";
               FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
               FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
               FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("SDN template");
               FastDriver.NextGenDocumentRepository.Search.FAClick();
               FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false); 
               if (FastDriver.NextGenDocumentRepository.TableResults.IsDisplayed())
               {
                   Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.TableResults.StringExistOnTable("SDN Template").ToString());
               }
               else 
               {
                   Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
               }
               #endregion

               #region Click on New Search button
               Reports.TestStep = "Click on New Search button";
               FastDriver.NextGenDocumentPreparation.TemplateNewSearch.FAClick();
               #endregion

               #region Search Template by Corporate Region and No description
               Reports.TestStep = "In template Search Criteria :  Set Type to 'SDN Result' and click on Search button";
               FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
               FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("SDN Result");
               FastDriver.NextGenDocumentRepository.Search.FAClick();
               FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
               if (FastDriver.NextGenDocumentRepository.TableResults.IsDisplayed())
               {
                   Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.TableResults.StringExistOnTable("SDN Template").ToString());
               }
               else 
               {
                   Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
               }
               #endregion
               

           }
           catch (Exception ex)
           {
               FailTest(GetExceptionInfo(ex));
           }

       }


        [ClassCleanup]
        public static void ClassCleanup()
        {
            MasterTestClass.CleanupClass();
        }

    }
}
