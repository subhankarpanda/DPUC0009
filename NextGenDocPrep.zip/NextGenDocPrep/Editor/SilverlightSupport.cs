﻿using Microsoft.VisualStudio.TestTools.UITest.Extension;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.SilverlightControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml;
using Excel = Microsoft.Office.Interop.Excel;
using Mouse = Microsoft.VisualStudio.TestTools.UITesting.Mouse;
using MouseButtons = System.Windows.Forms.MouseButtons;

namespace NextGenDocPrep
{
    public class SilverlightSupport
    {
        private string CURRENT_STEP, ADD_INFO, ROPROPERTYVALUE, iValidateInfo;
        private UITestControl _browserWindow;
        private BrowserWindow _mainbrowserWindow;
        private string _browserName;
        private bool _containsComparison;
        private bool _isDialog;
        private string _errorMessage;
        private string _specificrownumber;

        // from AutoSupport project
        public static string OBJECT_MAP = "";
        public static string GeneralMessage = "";
        public static string MIC_CLASS = "";
        public static string OBJ_PARENT = "";
        public static XmlElement OBJ_PARENT_ELEMENT = null;
        public static string controlname = "";
        public static bool IsParentSet = true;
        public static DateTime ctrlstartTime = new DateTime();
        public static DateTime ctrlendTime = new DateTime();
        public static string shouldusewaitforreadylevel = "yes";
        public static int syncTimeout = 10000;

        #region Constructor Set Default Values
        public SilverlightSupport()
        {
            ROPROPERTYVALUE = "";
            _browserWindow = null;
            _mainbrowserWindow = null;
            _browserName = "";
            _containsComparison = false;
            _isDialog = false;
            _errorMessage = "";
            _specificrownumber = "";
        }
        #endregion

        #region Different Properties Set & get
        ///<summary>
        ///<para>Sets or gets Parent Window of control. </para>
        ///<para>Example: SilverlightSupport FALibHS = new SilverlightSupport(); UITestControl parenWindow = FALibHS.sBrowserWindow;</para>
        ///</summary>
        public UITestControl sBrowserWindow
        {
            get { return _browserWindow; }
            set { _browserWindow = value; }
        }

        ///<summary>
        ///<para>Sets or gets Browser name. </para>
        ///<para>Example: SilverlightSupport FALibHS = new SilverlightSupport(); string parenWindow = FALibHS.BrowserName;</para>
        ///</summary>
        public string BrowserName
        {
            get { return _browserName; }
            set { _browserName = value; }
        }

        ///<summary>
        ///<para>Sets or gets ContainsComparison flag. This is used in Tables functions SilverlightTableSet/ SilverlightTableGet where one can specify partial string to search</para>
        ///<para>Example: SilverlightSupport FALibHS = new SilverlightSupport(); FALibHS.ContainsComparison=true;</para>
        ///</summary>
        public bool ContainsComparison
        {
            get { return _containsComparison; }
            set { _containsComparison = value; }
        }

        ///<summary>
        ///<para>Do not use. Used Internally.</para>
        ///</summary>
        public bool IsDialog
        {
            get { return _isDialog; }
            set { _isDialog = value; }
        }

        ///<summary>
        ///<para>Do not use. Used Internally.</para>
        ///</summary>
        public string m_errorMessage
        {
            get { return _errorMessage; }
            set { _errorMessage = value; }
        }

        ///<summary>
        ///<para>Contains value after Table Operations SilverlightTableSet/ SilverlightTableGet </para>
        ///<para>Example: SilverlightSupport FALibHS = new SilverlightSupport(); string rowNum= FALibHS.Specific_Row_Number;</para>
        ///</summary>
        public string Specific_Row_Number
        {
            get { return _specificrownumber; }
            set { _specificrownumber = value; }
        }
        #endregion

        #region SilverLightSupport Wrapper Method
        ///<summary>
        ///<para>Returns an object of type FASilverlightInterface with ObjectMap being XML file name and sObjName being node name of the control</para>
        ///<para>Always use SetParent method before using GetControl method</para>
        ///<para>Example: SilverlightSupport FALibHS = new SilverlightSupport(); SilverlightControl hControl = (SilverlightControl)FALibHS.GetControl("QuickFileEntry","BusSource");</para>
        ///</summary>
        public FASilverlightInterface GetControl(string ObjectMap, string sObjName)
        {
            SilverlightControl retControl = null;
            FASilverlightInterface faControl = null;
            ctrlstartTime = DateTime.Now;
            GeneralMessage = "";
            if (IsParentSet)
            {
                //TODO: if IsParentSet=true maybe there is no need to get again... save stream in SetParent()?
                Stream ObjStream = GetObjectMapStream("NextGenDocPrep", ObjectMap);

                if (ObjStream != null)
                {
                    string sProperties = GetORPropertyValues(ObjStream, sObjName, false);
                    if (sProperties != "NO_PROPS")
                    {
                        retControl = ConstructControl(sProperties, MIC_CLASS, sObjName);
                    }
                    else
                    {
                        GeneralMessage = "Object \"" + sObjName + "\" doesn't exist in Map \"" + ObjectMap + "\" OR Properties missing  OR Fix SetParent error";
                        Reports.UpdateDebugLog(sObjName, "", "GetControl", "", "", "", Reports.Result(false), GeneralMessage);
                    }
                }
                else
                {
                    GeneralMessage = "Repository file \"" + ObjectMap + "\" doesn't exist OR Not added to NextGenDocPrep Project OR after adding file, it is not as embedded resource";
                    Reports.UpdateDebugLog(sObjName, "", "GetControl", "", "", "", Reports.Result(false), GeneralMessage);
                }

                faControl = new FASilverlightControl(retControl);
            }

            _browserWindow.WaitForControlReady();
            return faControl;
        }
        #endregion

        #region Get Silverlight Control using Properties
        ///<summary>
        ///<para>Returns an object of type FASilverlightInterface with ObjectMap being XML file name and sObjName being node name of the control</para>
        ///<para>Always use SetParent method before using GetControl method</para>
        ///<para>Example: SilverlightSupport FALibHS = new SilverlightSupport(); SilverlightControl hControl = (SilverlightControl)FALibHS.GetControlByProperties("Id=BusSource;Name=BusName","HtmlTextBox");</para>
        ///</summary>
        public FASilverlightInterface GetControlByProperties(string sProperties, string objClass)
        {
            ctrlstartTime = DateTime.Now;
            FASilverlightInterface faControl = null;
            if (IsParentSet)
            {
                SilverlightControl retControl = ConstructControl(sProperties, objClass, sProperties);
                faControl = new FASilverlightControl(retControl);
            }
            return faControl;
        }
        #endregion

        #region Contruct object based on the properties & knowing the kind of control
        private SilverlightControl ConstructControl(string sProperties, string micClass, string sObjName)
        {
            SilverlightControl slghtControl;
            controlname = sObjName;
            Reports.obj_class = micClass;
            switch (micClass.ToLower())
            {
                case "silverlightbutton":
                    slghtControl = new SilverlightButton(_browserWindow);
                    break;
                case "silverlightcalendar":
                    slghtControl = new SilverlightCalendar(_browserWindow);
                    break;
                case "silverlightcell":
                    slghtControl = new SilverlightCell(_browserWindow);
                    break;
                case "silverlightcheckbox":
                    slghtControl = new SilverlightCheckBox(_browserWindow);
                    break;
                case "silverlightchildwindow":
                    slghtControl = new SilverlightChildWindow(_browserWindow);
                    break;
                case "silverlightcombobox":
                    slghtControl = new SilverlightComboBox(_browserWindow);
                    break;
                case "silverlightcontrol":
                    slghtControl = new SilverlightControl(_browserWindow);
                    break;
                case "silverlightdatapager":
                    slghtControl = new SilverlightDataPager(_browserWindow);
                    break;
                case "silverlightdatepicker":
                    slghtControl = new SilverlightDatePicker(_browserWindow);
                    break;
                case "silverlightdescriptionviewer":
                    slghtControl = new SilverlightDescriptionViewer(_browserWindow);
                    break;
                case "silverlightedit":
                    slghtControl = new SilverlightEdit(_browserWindow);
                    break;
                case "silverlightframe":
                    slghtControl = new SilverlightFrame(_browserWindow);
                    break;
                case "silverlighthyperlink":
                    slghtControl = new SilverlightHyperlink(_browserWindow);
                    break;
                case "silverlightimage":
                    slghtControl = new SilverlightImage(_browserWindow);
                    break;
                case "silverlightlabel":
                    slghtControl = new SilverlightLabel(_browserWindow);
                    break;
                case "silverlightlist":
                    slghtControl = new SilverlightList(_browserWindow);
                    break;
                case "silverlightlistitem":
                    slghtControl = new SilverlightListItem(_browserWindow);
                    break;
                case "silverlightpage":
                    slghtControl = new SilverlightPage(_browserWindow);
                    break;
                case "silverlightprogressbar":
                    slghtControl = new SilverlightProgressBar(_browserWindow);
                    break;
                case "silverlightradiobutton":
                    slghtControl = new SilverlightRadioButton(_browserWindow);
                    break;
                case "silverlightrow":
                    slghtControl = new SilverlightRow(_browserWindow);
                    break;
                case "silverlightslider":
                    slghtControl = new SilverlightSlider(_browserWindow);
                    break;
                case "silverlighttabitem":
                    slghtControl = new SilverlightTabItem(_browserWindow);
                    break;
                case "silverlighttab":
                    slghtControl = new SilverlightTab(_browserWindow);
                    break;
                case "silverlighttable":
                    slghtControl = new SilverlightTable(_browserWindow);
                    break;
                case "silverlighttext":
                    slghtControl = new SilverlightText(_browserWindow);
                    break;
                case "silverlighttree":
                    slghtControl = new SilverlightTree(_browserWindow);
                    break;
                case "silverlighttreeitem":
                    slghtControl = new SilverlightTreeItem(_browserWindow);
                    break;               
                case "silverlightvalidationsummary":
                    slghtControl = new SilverlightValidationSummary(_browserWindow);
                    break;
                case "silverlightViewbox":
                    slghtControl = new SilverlightViewBox(_browserWindow);
                    break;
                default:
                    slghtControl = new SilverlightControl(_browserWindow);
                    break;

            }
            //FASilverlightControl slghtControl = new FASilverlightControl(_browserWindow);
            //slghtControl = new SilverlightComboBox(_browserWindow);
            //slghtControl.controlname = sObjName;
            //slghtControl.SearchProperties["ClassName"] = "Silverlight.ComboBox";


            int ipropcount = 0;
            string[] sNameProp;

            //string cls = slghtControl.GetProperty("ClassName").ToString();

            string[] AllProps = sProperties.Split(';');
            ipropcount = AllProps.Length;

            if (ipropcount != 0)
            {
                for (int i = 0; i < ipropcount; i++)
                {
                    sNameProp = AllProps.GetValue(i).ToString().Split('=');
                    string sValueProp = AllProps.GetValue(i).ToString().Replace(sNameProp[0].ToString() + "=", "");
                    if (sNameProp[0].ToString().Contains("contains"))
                    {
                        string tmpProp = sNameProp[0].Replace("_contains", "");
                        slghtControl.SearchProperties.Add(tmpProp, sValueProp, PropertyExpressionOperator.Contains);
                    }
                    else if (sNameProp[0].ToString().Contains("filter"))
                    {
                        string tmpProp = sNameProp[0].Replace("filter_", "");
                        slghtControl.FilterProperties[tmpProp] = sValueProp;
                    }
                    else
                    {
                        if (sValueProp.Equals("null"))
                        {
                            slghtControl.SearchProperties[sNameProp[0].ToString()] = null;
                        }
                        else
                        {
                            slghtControl.SearchProperties[sNameProp[0].ToString()] = sValueProp;
                        }
                    }
                }
            }

            return slghtControl;
        }
        #endregion

        #region Set Parent Operation
        ///<summary>
        ///<para>Returns an object of type UITestControl with ObjectMap being XML file name and sObjName being node name of the control</para>
        ///<para>Example: SilverlightSupport FALibHS = new SilverlightSupport(); UITestControl uControl = FALibHS.SetParent("QuickFileEntry","QuickFileEntry");</para>
        ///</summary>
        public UITestControl SetParent(string ObjectMap, string sObjName)
        {
            bool iResult = false;
            GeneralMessage = "";
            ctrlstartTime = DateTime.Now;

            OBJ_PARENT = sObjName;
            if (shouldusewaitforreadylevel.ToLower().Equals("yes"))
            {
                Playback.PlaybackSettings.WaitForReadyLevel = WaitForReadyLevel.UIThreadOnly;
            }
            else
            {
                Playback.PlaybackSettings.WaitForReadyLevel = WaitForReadyLevel.Disabled;
            }

            try
            {
                string sProperties = "";
                //TODO: find a way to get current project' dll name
                Stream ObjStream = GetObjectMapStream("NextGenDocPrep", ObjectMap);

                if (ObjStream != null)
                {
                    sProperties = GetORPropertyValues(ObjStream, sObjName, true);

                    if (sProperties != "NO_PROPS")
                    {

                        BrowserWindow sBrowserWindow1 = BrowserWindow();
                        sBrowserWindow1.SearchProperties["ClassName"] = "IEFrame";
                        sBrowserWindow1.TechnologyName = "MSAA";
                        _browserWindow = new HtmlCustom(sBrowserWindow1);
                        iResult = ConstructParent(sProperties);
                    }
                    else
                    {
                        GeneralMessage = "Object \"" + sObjName + "\" doesn't exist in Map \"" + ObjectMap + "\" OR Properties missing.";
                    }
                }
                else
                {
                    IsParentSet = false;
                    GeneralMessage = "Repository file " + ObjectMap + " doesn't exist OR Not added to this project OR after adding file, it is not as embedded resource";
                }

            }

            catch (Exception e)
            {
                iResult = false;
                Reports.TestResult = iResult;
                GeneralMessage = GeneralMessage + ":" + e.Message;
            }
            Playback.PlaybackSettings.WaitForReadyLevel = WaitForReadyLevel.Disabled;
            Reports.UpdateDebugLog(sObjName, MIC_CLASS, "SetParent", "", "", "", Reports.Result(iResult), GeneralMessage);
            return _browserWindow;
        }
        #endregion

        #region Contruct Parent with Properties
        private bool ConstructParent(string sProperties)
        {

            int ipropcount = 0;
            string[] sNameProp;
            bool iResult = false;

            try
            {

                string[] AllProps = sProperties.Split(';');
                ipropcount = AllProps.Length;

                if (ipropcount != 0)
                {
                    for (int i = 0; i < ipropcount; i++)
                    {
                        sNameProp = AllProps.GetValue(i).ToString().Split('=');
                        string sValueProp = AllProps.GetValue(i).ToString().Replace(sNameProp[0].ToString() + "=", "");
                        if (sNameProp[0].ToString().Contains("contains"))
                        {
                            string tmpProp = sNameProp[0].Replace("_contains", "");
                            _browserWindow.SearchProperties.Add(tmpProp, sValueProp, PropertyExpressionOperator.Contains);
                        }
                        else if (sNameProp[0].ToString().Contains("filter"))
                        {
                            string tmpProp = sNameProp[0].Replace("filter_", "");
                            _browserWindow.FilterProperties[tmpProp] = sValueProp;
                        }
                        else
                        {
                            if (sValueProp.Equals("null"))
                            {
                                _browserWindow.SearchProperties[sNameProp[0].ToString()] = null;
                            }
                            else
                            {
                                _browserWindow.SearchProperties[sNameProp[0].ToString()] = sValueProp;
                            }
                        }
                    }
                }

                iResult = _browserWindow.TryFind();
                //_browserWindow.WaitForControlReady(10 * syncTimeout);
                //_browserWindow.SetFocus();
                //_browserWindow.DrawHighlight();  
            }

            catch (Exception e)
            {
                GeneralMessage = GeneralMessage + ":" + e.Message;
            }

            return iResult;
        }
        #endregion

        #region Construct Browser Object
        ///<summary>
        ///<para>Returns an object of type BrowserWindow</para>
        ///<para>Example: SilverlightSupport FALibHS = new SilverlightSupport(); BrowserWindow sWinow = FALibHS.BrowserWindow();</para>
        ///</summary>
        public BrowserWindow BrowserWindow()
        {
            BrowserWindow sBw = null;
            if (Microsoft.VisualStudio.TestTools.UITesting.BrowserWindow.CurrentBrowser.Equals("IE"))
            {
                _browserWindow = new BrowserWindow();
                sBw = (BrowserWindow)_browserWindow;
            }
            else
            {
                sBw = _mainbrowserWindow;
                sBw.SearchProperties["Name"] = _browserName;
            }
            sBw.CloseOnPlaybackCleanup = false;
            return sBw;
        }
        #endregion

        #region Select Date
        ///<summary>
        ///<para>Do not use.</para>
        ///</summary>
        public bool SelectDate(string sProperties, string sDate)
        {
            int ipropcount = 0;
            string[] sNameProp;

            _browserWindow = BrowserWindow();
            _browserWindow.SearchProperties[UITestControl.PropertyNames.Name] = "Calendar";
            _browserWindow.SearchProperties[UITestControl.PropertyNames.ClassName] = "Internet Explorer_TridentDlgFrame";

            HtmlCell DateItem = new HtmlCell(_browserWindow);
            DateItem.SearchProperties["InnerText"] = "17";

            string[] AllProps = sProperties.Split(';');
            ipropcount = AllProps.Length;

            if (ipropcount != 0)
            {
                for (int i = 0; i < ipropcount; i++)
                {
                    sNameProp = AllProps.GetValue(i).ToString().Split('=');
                    string sValueProp = AllProps.GetValue(i).ToString().Replace(sNameProp[0].ToString() + "=", "");
                    if (sNameProp[0].ToString().Contains("contains"))
                    {
                        string tmpProp = sNameProp[0].Replace("_contains", "");
                        DateItem.SearchProperties.Add(tmpProp, sValueProp, PropertyExpressionOperator.Contains);
                    }
                    else if (sNameProp[0].ToString().Contains("filter"))
                    {
                        string tmpProp = sNameProp[0].Replace("filter_", "");
                        DateItem.FilterProperties[tmpProp] = sValueProp;
                    }
                    else
                    {
                        if (sValueProp.Equals("null"))
                        {
                            DateItem.SearchProperties[sNameProp[0].ToString()] = null;
                        }
                        else
                        {
                            DateItem.SearchProperties[sNameProp[0].ToString()] = sValueProp;
                        }
                    }
                }
            }
            return false;
        }
        #endregion

        #region Return right Html Control
        ///<summary>
        ///<para>Returns an object of type HtmlControl which is clearly visible on the screen (which is not hidden).</para>
        ///<para>Example: SilverlightSupport FALibHS = new SilverlightSupport(); SilverlightControl hControl = FALibHS.ReturnRightControl((SilverlightControl)FALibHS.GetControl("QuickFileEntry","QuickFileEntry"));</para>
        ///</summary>
        public SilverlightControl ReturnRightControl(SilverlightControl FAControl)
        {
            SilverlightControl ControltoReturn = null;

            try
            {
                try { _browserWindow.SetFocus(); }
                catch { }
                for (int i = 0; i < FAControl.FindMatchingControls().Count; i++)
                {
                    try
                    {
                        FAControl.FindMatchingControls()[i].EnsureClickable();
                        ControltoReturn = (SilverlightControl)FAControl.FindMatchingControls()[i];
                    }
                    catch { }
                }
            }
            catch { }
            return ControltoReturn;
        }
        #endregion

        #region Return right Html Control from Non-Hidden controls
        ///<summary>
        ///<para>Returns an object of type HtmlControl which is clearly visible on the screen (which is not hidden).</para>
        ///<para>Retruns the control which is at number WhichToReturn in the collection if multiple controls found matching the control</para>
        ///<para>Example: SilverlightSupport FALibHS = new SilverlightSupport(); SilverlightControl hControl = FALibHS.ReturnRightControl((SilverlightControl)FALibHS.GetControl("QuickFileEntry","BusSource"), 2);</para>
        ///</summary>
        public SilverlightControl ReturnRightControl(SilverlightControl FAControl, int WhichToReturn)
        {
            SilverlightControl ControltoReturn = null;
            int ControlNumber = 0;

            try
            {
                try { _browserWindow.SetFocus(); }
                catch { }
                for (int i = 0; i < FAControl.FindMatchingControls().Count; i++)
                {
                    try
                    {
                        FAControl.FindMatchingControls()[i].EnsureClickable();
                        ControlNumber = ControlNumber + 1;
                        ControltoReturn = (SilverlightControl)FAControl.FindMatchingControls()[i];
                        if (ControlNumber == WhichToReturn)
                            break;
                    }
                    catch { }
                }
            }
            catch { }
            return ControltoReturn;
        }
        #endregion

        #region Return right Html Control from all controls present in Screen
        ///<summary>
        ///<para>Returns an object of type HtmlControl which is clearly visible on the screen (which is not hidden).</para>
        ///<para>Collection includes Hidden controls as well. Retruns the control which is at number WhichToReturn in the collection if multiple controls found matching the control</para>
        ///<para>Example: SilverlightSupport FALibHS = new SilverlightSupport(); SilverlightControl hControl = FALibHS.ReturnControlFromAll((SilverlightControl)FALibHS.GetControl("QuickFileEntry","BusSource"), 2);</para>
        ///</summary>
        public SilverlightControl ReturnControlFromAll(SilverlightControl FAControl, int WhichToReturn)
        {
            SilverlightControl ControltoReturn = null;
            int ControlNumber = 0;

            try
            {
                for (int i = 0; i < FAControl.FindMatchingControls().Count; i++)
                {
                    try
                    {
                        FAControl.FindMatchingControls();
                        ControlNumber = ControlNumber + 1;
                        ControltoReturn = (SilverlightControl)FAControl.FindMatchingControls()[i];
                        if (ControlNumber == WhichToReturn)
                            break;
                    }
                    catch { }
                }
            }
            catch { }
            return ControltoReturn;
        }
        #endregion

        #region FindEmbeddedObjectInCell
        private UITestControl FindEmbeddedObjectInCell(UITestControl CellObj, int instance)
        {
            UITestControl tempObject = CellObj;
            UITestControl tempObject1 = CellObj;
            int objInstance = 0;
            try
            {
                UITestControlCollection TempObjArray = new UITestControlCollection();

                TempObjArray = (UITestControlCollection)CellObj.GetChildren();
                if (TempObjArray.Count > 1 && instance > 1)
                {
                    objInstance = instance - 1;
                }

                if (TempObjArray.Count > 0)
                {
                    tempObject = TempObjArray[objInstance];
                    if (TempObjArray[0].GetProperty("ControlType").ToString().Equals("Pane"))
                    {
                        tempObject1 = tempObject;
                        UITestControlCollection FinalObjArray1 = new UITestControlCollection();
                        FinalObjArray1 = TempObjArray[objInstance].GetChildren();
                        if (FinalObjArray1.Count > 0)
                        {
                            if (FinalObjArray1.Count > 1 && instance > 1)
                            {
                                objInstance = instance - 1;
                            }

                            tempObject = FinalObjArray1[objInstance];
                            if (FinalObjArray1[0].GetProperty("ControlType").ToString().Equals("Pane"))
                            {
                                tempObject1 = tempObject;
                                UITestControlCollection FinalObjArray = new UITestControlCollection();
                                FinalObjArray = FinalObjArray1[objInstance].GetChildren();
                                if (FinalObjArray.Count > 0)
                                {
                                    if (FinalObjArray.Count > 1 && instance > 1)
                                    {
                                        objInstance = instance - 1;
                                    }
                                    tempObject1 = tempObject;
                                    tempObject = FinalObjArray[objInstance];
                                    if (FinalObjArray[0].GetProperty("ControlType").ToString().Equals("Pane"))
                                    {
                                        tempObject1 = tempObject;
                                        tempObject = TempObjArray[objInstance];
                                    }
                                }
                            }

                        }

                    }

                }
            }


            catch (Exception e)
            {
                tempObject = tempObject1;
                string s = e.Message;
            }

            return tempObject;
        }
        #endregion

        #region SilverlightTableToExcel
        private bool SilverlightTableToExcel(string sProperties, string sheetname)
        {
            _errorMessage = "";
            bool iResult = true;
            int ipropcount = 0;
            string[] sNameProp;
            string sPath = GetDataPath() + "\\Docs\\";
            string wbName = sheetname + DateTime.Now.ToString().Replace("/", "_").Replace(" ", "_").Replace(":", "_").ToString();
            string objType = "";
            string objValue;
            string propvalue;

            try
            {
                Excel.Application excelApp = new Excel.Application();
                Excel.Workbook newWorkbook = excelApp.Workbooks.Add();
                Excel.Worksheet worksheet = (Excel.Worksheet)newWorkbook.Worksheets.get_Item(1);
                worksheet.Name = sheetname;
                _browserWindow = BrowserWindow();
                if (_isDialog)
                {
                    _browserWindow.SearchProperties["ClassName"] = "Internet Explorer_TridentDlgFrame";
                }
                else
                {
                    _browserWindow.SearchProperties["ClassName"] = "IEFrame";
                }
                SilverlightTable TempObject = new SilverlightTable(_browserWindow);
                string[] AllProps = sProperties.Split(';');
                ipropcount = AllProps.Length;

                if (ipropcount != 0)
                {
                    for (int i = 0; i < ipropcount; i++)
                    {
                        sNameProp = AllProps.GetValue(i).ToString().Split('=');
                        string sValueProp = AllProps.GetValue(i).ToString().Replace(sNameProp[0].ToString() + "=", "");
                        if (sNameProp[0].ToString().Contains("contains"))
                        {
                            string tmpProp = sNameProp[0].Replace("_contains", "");
                            TempObject.SearchProperties.Add(tmpProp, sValueProp, PropertyExpressionOperator.Contains);
                        }
                        else if (sNameProp[0].ToString().Contains("filter"))
                        {
                            string tmpProp = sNameProp[0].Replace("filter_", "");
                            TempObject.FilterProperties[tmpProp] = sValueProp;
                        }
                        else
                        {
                            TempObject.SearchProperties[sNameProp[0].ToString()] = sValueProp;
                        }

                    }
                }

                TempObject.DrawHighlight();
                int srowcnt = TempObject.RowCount;
                int scolcnt = TempObject.ColumnCount;
                UITestControl tempObject = TempObject;

                SilverlightCell cell11 = new SilverlightCell(TempObject);

                for (int k = 0; k < scolcnt; k++)
                {
                    try
                    {
                        cell11.SearchProperties["RowIndex"] = "0";
                        cell11.SearchProperties["ColumnIndex"] = k.ToString();

                        tempObject = FindEmbeddedObjectInCell(cell11, 0);
                        objType = FindObjectType(tempObject, out objValue);
                        switch (objType.ToString())
                        {
                            case "txt":
                                propvalue = tempObject.GetProperty("Text").ToString();
                                break;

                            case "tfi":
                                propvalue = tempObject.GetProperty("FileName").ToString();
                                break;

                            case "lbl":
                                propvalue = tempObject.GetProperty("Label").ToString();
                                break;

                            case "cus":
                                propvalue = tempObject.GetProperty("InnerText").ToString();
                                break;

                            case "rad":
                                propvalue = "";
                                break;

                            case "btn":
                                propvalue = "";
                                break;

                            case "lnk":
                                propvalue = tempObject.GetProperty("InnerText").ToString();
                                break;

                            case "cmb":
                                propvalue = tempObject.GetProperty("SelectedItem").ToString();
                                break;

                            case "lst":
                                propvalue = tempObject.GetProperty("SelectedItemsAsString").ToString();
                                break;

                            case "chk":
                                propvalue = "";
                                break;

                            case "pan":
                                propvalue = tempObject.GetProperty("InnerText").ToString();
                                break;

                            case "img":
                                propvalue = "";
                                break;

                            case "cel":
                                propvalue = tempObject.GetProperty("InnerText").ToString();
                                break;

                            case "tbl":
                                propvalue = tempObject.GetProperty("InnerText").ToString();
                                break;

                            default:
                                propvalue = "";
                                break;
                        }

                        worksheet.Cells[1, k + 1].Interior.Color = Color.SkyBlue;
                        worksheet.Cells[1, k + 1] = propvalue;
                    }
                    catch { }
                }


                {
                    for (int i = 1; i < srowcnt; i++)
                    {
                        for (int j = 0; j < scolcnt; j++)
                        {
                            try
                            {
                                cell11.SearchProperties["RowIndex"] = i.ToString();
                                cell11.SearchProperties["ColumnIndex"] = j.ToString();
                                tempObject = FindEmbeddedObjectInCell(cell11, 0);
                                objType = FindObjectType(tempObject, out objValue);
                                switch (objType.ToString())
                                {
                                    case "txt":
                                        propvalue = tempObject.GetProperty("Text").ToString();
                                        break;

                                    case "tfi":
                                        propvalue = tempObject.GetProperty("FileName").ToString();
                                        break;

                                    case "lbl":
                                        propvalue = tempObject.GetProperty("Label").ToString();
                                        break;

                                    case "cus":
                                        propvalue = tempObject.GetProperty("InnerText").ToString();
                                        break;

                                    case "rad":
                                        propvalue = "";
                                        break;

                                    case "btn":
                                        propvalue = "";
                                        break;

                                    case "lnk":
                                        propvalue = tempObject.GetProperty("InnerText").ToString();
                                        break;

                                    case "cmb":
                                        propvalue = tempObject.GetProperty("SelectedItem").ToString();
                                        break;

                                    case "lst":
                                        propvalue = tempObject.GetProperty("SelectedItemsAsString").ToString();
                                        break;

                                    case "chk":
                                        propvalue = "";
                                        break;

                                    case "pan":
                                        propvalue = tempObject.GetProperty("InnerText").ToString();
                                        break;

                                    case "img":
                                        propvalue = "";
                                        break;

                                    case "cel":
                                        propvalue = tempObject.GetProperty("InnerText").ToString();
                                        break;

                                    case "tbl":
                                        propvalue = tempObject.GetProperty("InnerText").ToString();
                                        break;

                                    default:
                                        propvalue = "";
                                        break;
                                }



                                worksheet.Cells[i + 1, j + 1] = propvalue;
                            }
                            catch { }
                            //}
                        }
                    }
                }

                newWorkbook.SaveAs(sPath + wbName + ".xlsx");
                newWorkbook.Close();
                excelApp.Quit();
                excelApp = null;
                newWorkbook = null;
                worksheet = null;
                cell11 = null;
                iResult = true;
            }
            catch (Exception e)
            {
                _errorMessage = _errorMessage + e.Message;
                iResult = false;
            }

            return iResult;



        }
        #endregion

        #region GetDataPath
        private string GetDataPath()
        {
            string sDirectory = Directory.GetCurrentDirectory();
            sDirectory = Directory.GetParent(sDirectory).FullName;
            string sPath = "";

            if (sDirectory.Contains("AxeTests\\results"))
            {
                sDirectory = Directory.GetParent(sDirectory).FullName;
                sDirectory = Directory.GetParent(sDirectory).FullName;
                sDirectory = Directory.GetParent(sDirectory).FullName;
                sDirectory = Directory.GetParent(sDirectory).FullName;
                sDirectory = Directory.GetParent(sDirectory).FullName;
                sPath = sDirectory + "\\AxeTests\\data";
            }
            else
            {
                sPath = sDirectory + "\\Deployment\\data";
            }
            return sPath;
        }
        #endregion

        #region SilverlightTableSet
        ///<summary>
        ///<para>Performs appropriate action on the Table control. Create control using Object Map ObjMap and ObjName passed.</para>
        ///<para>objValue syntax is as follows "Column1^Row1^Column2|action". Performs action on row based on the value of other column.</para>
        ///<para>Example: SilverlightSupport FALibHS = new SilverlightSupport(); FALibHS.HtmlTableSet("QuickFileEntry","BusTable","#1^HUD^#3|click");</para>
        ///</summary>
        public bool SilverlightTableSet(string ObjMap, string ObjName, string objValue)
        {
            bool iResult = false;
            ctrlstartTime = DateTime.Now;
            iResult = PerformTableOperation1("UPDATE", ObjMap, ObjName, objValue);
            if (iResult == false)
            {
                if (_errorMessage == "")
                    _errorMessage = "Failed to perform action on Table";
            }

            return iResult;
        }
        #endregion

        #region SilverlightTableGSet(string ObjMap, string ObjName, string objValue)
        ///<summary>
        ///<para>Verifies data in the second column based on the first column data. Table control is created using Object Map ObjMap and ObjName passed.</para>
        ///<para>objValue syntax is as follows "Column1^Row1^Column2|ON". Performs action on row based on the value of other column.</para>
        ///<para>Example: SilverlightSupport FALibHS = new SilverlightSupport(); FALibHS.HtmlTableGet("QuickFileEntry","BusTable","#1^HUD^#3|ON");</para>
        ///</summary>
        public bool SilverlightTableGSet(string ObjMap, string ObjName, string objValue)
        {
            bool iResult = false;
            ctrlstartTime = DateTime.Now;
            iResult = PerformTableOperation1("VERIFY", ObjMap, ObjName, objValue);
            if (iResult == false)
            {
                if (_errorMessage == "")
                    _errorMessage = "Failed to perform action on Table";
            }

            return iResult;
        }
        #endregion

        #region NegVerify
        private bool NegVerify(string ObjProperty, string objValue)
        {
            bool iResult = false;
            UITestControl ObjTemplate = new UITestControl();
            //iResult = PerformTableOperation1("NEGVERIFY", ObjProperty, objValue);
            return iResult;

        }
        #endregion

        #region Perform Table Operation.
        private bool PerformTableOperation2(string Operation, UITestControl ObjTemplate, string ObjValue)
        {
            SilverlightTable TempObject = new SilverlightTable();
            bool iResult = false;

            try
            {
                string[] ValArray = ObjValue.Split('|');

                if (ValArray != null)
                {
                    int iValLength = ValArray.GetLength(0);
                    if (iValLength <= 1 || iValLength > 3)
                    {
                        iResult = false;
                    }
                    else
                    {
                        if (iValLength == 2)
                        {
                            iResult = TableOperationWithSingleCellCondition(Operation, ObjTemplate, ValArray);
                        }
                        else
                        {
                            iResult = TableOperationWithDoubleCellCondition(Operation, ObjTemplate, ValArray);
                        }
                    }
                }
                else
                {
                    iResult = false;
                }

            }

            catch (Exception e)
            {
                _errorMessage = _errorMessage + e.Message;
                iResult = false;
            }
            return iResult;
        }
        #endregion

        #region Perform Table Operation.
        private bool PerformTableOperation1(string Operation, string ObjMap, string ObjName, string ObjValue)
        {
            SilverlightTable TempObject = new SilverlightTable(_browserWindow);
            int ipropcount = 0;
            string[] sNameProp;
            bool iResult = false;

            _specificrownumber = "";

            if (IsParentSet)
            {
                GeneralMessage = "";

                Stream ObjStream = GetObjectMapStream("NextGenDocPrep", ObjMap);

                if (ObjStream != null)
                {
                    string sProperties = GetORPropertyValues(ObjStream, ObjName, false);
                    if (sProperties != "NO_PROPS")
                    {
                        string[] AllProps = sProperties.Split(';');
                        ipropcount = AllProps.Length;

                        if (ipropcount != 0)
                        {
                            for (int i = 0; i < ipropcount; i++)
                            {
                                sNameProp = AllProps.GetValue(i).ToString().Split('=');
                                string sValueProp = AllProps.GetValue(i).ToString().Replace(sNameProp[0].ToString() + "=", "");
                                if (sNameProp[0].ToString().Contains("contains"))
                                {
                                    string tmpProp = sNameProp[0].Replace("_contains", "");
                                    TempObject.SearchProperties.Add(tmpProp, sValueProp, PropertyExpressionOperator.Contains);
                                }
                                else if (sNameProp[0].ToString().Contains("filter"))
                                {
                                    string tmpProp = sNameProp[0].Replace("filter_", "");
                                    TempObject.FilterProperties[tmpProp] = sValueProp;
                                }
                                else
                                {
                                    TempObject.SearchProperties[sNameProp[0].ToString()] = sValueProp;
                                }

                            }
                        }

                        TempObject.DrawHighlight();
                        iResult = false;

                        try
                        {
                            string[] ValArray = ObjValue.Split('|');

                            if (ValArray != null)
                            {
                                int iValLength = ValArray.GetLength(0);
                                if (iValLength <= 1 || iValLength > 3)
                                {
                                    iResult = false;
                                }
                                else
                                {
                                    if (iValLength == 2)
                                    {
                                        iResult = TableOperationWithSingleCellCondition(Operation, TempObject, ValArray);
                                    }
                                    else
                                    {
                                        iResult = TableOperationWithDoubleCellCondition(Operation, TempObject, ValArray);
                                    }
                                }
                            }
                            else
                            {
                                iResult = false;
                            }

                        }
                        catch (Exception e)
                        {
                            _errorMessage = _errorMessage + e.Message;
                            GeneralMessage = _errorMessage;
                            iResult = false;
                        }
                    }
                    else
                    {
                        GeneralMessage = "Object \"" + ObjName + "\" doesn't exist in Map \"" + ObjMap + "\" OR Properties missing OR Fix SetParent error";
                        Reports.UpdateDebugLog(ObjName, "", "SilverlightTableGSet", "", "", "", Reports.Result(false), GeneralMessage);
                    }
                }
                else
                {
                    GeneralMessage = "Repository file \"" + ObjMap + "\" doesn't exist OR Not added to NextGenDocPrep Project OR after adding file, it is not as embedded resource";
                    Reports.UpdateDebugLog(ObjName, "", "SilverlightTableGSet", "", "", "", Reports.Result(false), GeneralMessage);
                }
            }

            return iResult;
        }
        #endregion

        #region Get Column Number
        private static int Get_ColumnNumber(int tblColCount, UITestControlCollection tblCells, string ColValue)
        {
            int iColumn = 1001;
            string tblText;

            for (int i = 0; i < tblColCount; i++)
            {
                UITestControl TempControl = (UITestControl)tblCells[i];
                tblText = TempControl.GetProperty("InnerText").ToString();
                if (tblText.Trim().Equals(ColValue))
                {
                    iColumn = i;
                    break;
                }
            }
            return iColumn;
        }
        #endregion

        #region Get Row Number
        private int Get_RowNumber(UITestControl tblObject, UITestControlCollection AllCells, int tblRowCount, int tblColCount, string RowValue, int ColNum, int iStart, int instance)
        {
            int iRow = 1001;
            bool ExceptionFlag = false;
            bool iResult = false;
            string tblText;
            string objType = "";
            string objValue = "";
            UITestControl tempObject = tblObject;

            if (iStart == 1001)
            {
                iStart = 0;
            }

            for (int i = iStart; i < tblRowCount; i++)
            {
                tblText = "";

                tempObject = FindEmbeddedObjectInCell(tblObject, AllCells, ColNum + (i * tblColCount), 0);
                //tempObject.DrawHighlight();
                objType = FindObjectType(tempObject, out objValue);

                if (objType.Equals("tbl"))
                {
                    tempObject = FindEmbeddedObjectInSpecifiedCell(tempObject, ColNum, instance);
                    objType = FindObjectType(tempObject, out objValue);
                }

                if (!objType.Equals("NOTSupportED"))
                {
                    iResult = Get_RO_Property(tempObject, objType, objValue, "", true, out ExceptionFlag);
                    tblText = ROPROPERTYVALUE;

                    if (_containsComparison)
                    {
                        if (tblText.Trim().Contains(RowValue))
                        {
                            iRow = i;
                            break;
                        }
                    }
                    else
                    {
                        if (tblText.Trim().Equals(RowValue))
                        {
                            iRow = i;
                            break;
                        }
                    }


                }
            }
            return iRow;
        }
        #endregion

        #region Get Row Number given two cell data as input
        private int Get_RowNumberWithSecondCondition(UITestControl tblObject, UITestControlCollection AllCells, int tblColCount, string RowValue, int ColNum, int FirstRow)
        {
            int iRow = 1001;
            bool iResult = false;
            bool ExceptionFlag = false;
            string tblText = "";
            string objType = "";
            string objValue = "";

            UITestControl tempObject = tblObject;

            tempObject = FindEmbeddedObjectInCell(tblObject, AllCells, ColNum + (FirstRow * tblColCount), 0);

            objType = FindObjectType(tempObject, out objValue);
            if (!objType.Equals("NOTSupportED"))
            {
                iResult = Get_RO_Property(tempObject, objType, objValue, "", true, out ExceptionFlag);
                tblText = ROPROPERTYVALUE;
                if (tblText.Trim().Equals(RowValue))
                {
                    iRow = FirstRow;
                }
            }
            return iRow;
        }
        #endregion

        #region Find & Get Embedded Object in Cell in the given Table
        private UITestControl FindEmbeddedObjectInCell(UITestControl tblObject, UITestControlCollection CellCollection, int CellNumber, int instance)
        {
            UITestControl tempObject = tblObject;
            UITestControl tempObject1 = tblObject;
            int objInstance = 0;

            UITestControlCollection TempObjArray = new UITestControlCollection();

            TempObjArray = (UITestControlCollection)CellCollection[CellNumber].GetChildren();
            if (TempObjArray.Count > 1 && instance > 1)
            {
                objInstance = instance - 1;
            }

            if (TempObjArray.Count > 0)
            {
                tempObject = TempObjArray[objInstance];
                if (TempObjArray[0].GetProperty("ControlType").ToString().Equals("Pane"))
                {
                    tempObject1 = tempObject;
                    UITestControlCollection FinalObjArray1 = new UITestControlCollection();
                    FinalObjArray1 = TempObjArray[objInstance].GetChildren();
                    if (FinalObjArray1.Count > 0)
                    {
                        if (FinalObjArray1.Count > 1 && instance > 1)
                        {
                            objInstance = instance - 1;
                        }

                        tempObject = FinalObjArray1[objInstance];
                        if (FinalObjArray1[0].GetProperty("ControlType").ToString().Equals("Pane"))
                        {
                            tempObject1 = tempObject;
                            UITestControlCollection FinalObjArray = new UITestControlCollection();
                            FinalObjArray = FinalObjArray1[objInstance].GetChildren();
                            if (FinalObjArray.Count > 0)
                            {
                                if (FinalObjArray.Count > 1 && instance > 1)
                                {
                                    objInstance = instance - 1;
                                }
                                tempObject1 = tempObject;
                                tempObject = FinalObjArray[objInstance];
                                if (FinalObjArray[0].GetProperty("ControlType").ToString().Equals("Pane"))
                                {
                                    tempObject1 = tempObject;
                                    tempObject = TempObjArray[objInstance];
                                }
                            }
                        }

                    }

                }

            }
            else
            {
                tempObject = CellCollection[CellNumber];
            }

            try
            {
                if (!(tempObject.GetProperty("ControlType").ToString().Contains("Table") || tempObject.GetProperty("ControlType").ToString().Contains("ell") || tempObject.GetProperty("ControlType").ToString().Contains("ane") || tempObject.GetProperty("ControlType").ToString().Contains("ust")))
                {
                    tempObject.EnsureClickable();
                }
            }
            catch (Exception e)
            {
                tempObject = tempObject1;
                string s = e.Message;
            }

            return tempObject;
        }
        #endregion

        #region Perform Table Operation given single cell data condition
        private bool TableOperationWithSingleCellCondition(string Operation, UITestControl tblObject, string[] valList)
        {
            int iRowNum1 = 1001;
            int iRowNum = 1001;
            int iColNum1 = 1001;
            int iColNum2 = 1001;
            int iInstance = 0;
            bool iResult = false;
            bool ExceptionFlag = false;

            string objType = "";
            string objValue = "";

            string FirstColValue = "";
            string FirstRowValue = "";
            string SurrogateCol = "";

            string sData = valList.GetValue(1).ToString();


            //JVRAO
            if (sData.StartsWith("#"))
            {
                string[] tempData = sData.Split('#');
                if (tempData.GetLength(0) > 2)
                {
                    sData = tempData.GetValue(2).ToString();
                    iInstance = Convert.ToInt32(tempData.GetValue(1));
                }
            }

            string[] FirstCell = valList.GetValue(0).ToString().Split('^');
            FirstColValue = FirstCell.GetValue(0).ToString();
            FirstRowValue = FirstCell.GetValue(1).ToString();
            SurrogateCol = FirstCell.GetValue(2).ToString();

            UITestControl tempObject = tblObject;

            int tblColCount = (int)tblObject.GetProperty("ColumnCount");
            int tblRowCount = (int)tblObject.GetProperty("RowCount");
            UITestControlCollection AllCells = (UITestControlCollection)tblObject.GetProperty("Cells");

            // Get First Column Number
            if (FirstColValue.StartsWith("#"))
            {
                iColNum1 = Convert.ToInt32(FirstColValue.TrimStart('#').ToString()) - 1;
            }
            else
            {
                iColNum1 = Get_ColumnNumber(tblColCount, AllCells, FirstColValue);
            }


            if (iColNum1 != 1001)
            {
                if (SurrogateCol.StartsWith("#"))
                {
                    iColNum2 = Convert.ToInt32(SurrogateCol.TrimStart('#').ToString()) - 1;
                }
                else
                {
                    iColNum2 = Get_ColumnNumber(tblColCount, AllCells, SurrogateCol);
                }


                if (iColNum2 != 1001)
                {
                    iRowNum = Get_RowNumber(tblObject, AllCells, tblRowCount, tblColCount, FirstRowValue, iColNum1, iRowNum1, iInstance);
                    _specificrownumber = iRowNum.ToString();
                    if (iRowNum != 1001)
                    {
                        tempObject = FindEmbeddedObjectInCell(tblObject, AllCells, iColNum2 + (iRowNum * tblColCount), iInstance);
                        string objValue1;
                        objType = FindObjectType(tempObject, out objValue1);
                        objValue = sData;
                        if (objType.Equals("tbl"))
                        {
                            tempObject = FindEmbeddedObjectInSpecifiedCell(tempObject, iColNum2, iInstance);
                            objType = FindObjectType(tempObject, out objValue1);
                            objValue = sData;

                        }
                        if (!objType.Equals("NOTSupportED"))
                        {
                            string sDatatmp = sData.ToLower();
                            if (!(sDatatmp.Equals("click") || sDatatmp.Equals("dclick") || sDatatmp.Equals("hover") || sDatatmp.Equals("on") || sDatatmp.Equals("off")))
                            {
                                if (Operation.ToLower().Equals("update"))
                                {
                                    iResult = Perform_Operation(tempObject, "UPDATE", objType, objValue, "", true, false, out ExceptionFlag);

                                    if (ROPROPERTYVALUE.Equals(sData))
                                    {
                                        iResult = Perform_Operation(tempObject, Operation, objType, objValue, "", true, false, out ExceptionFlag);
                                    }
                                    else
                                    {
                                        ADD_INFO = "Actual Value: " + ROPROPERTYVALUE;
                                        //iResult = false;
                                    }
                                }
                                else
                                {
                                    iResult = Perform_Operation(tempObject, Operation, objType, objValue, "", true, false, out ExceptionFlag);
                                }
                            }
                            else
                            {
                                iResult = Perform_Operation(tempObject, Operation, objType, objValue, "", true, false, out ExceptionFlag);
                            }
                        }
                    }
                }
            }

            return iResult;
        }
        #endregion

        #region Perform Table Operation given Two cell data condition
        private bool TableOperationWithDoubleCellCondition(string Operation, UITestControl tblObject, string[] valList)
        {
            int iRowNum1 = 1001;
            int iRowNum = 1001;
            int iColNum1 = 1001;
            int iColNum2 = 1001;
            int iColNum3 = 1001;
            int iInstance = 0;
            bool iResult = false;
            string objType = "";
            string objValue = "";

            bool ExceptionFlag = false;

            string FirstColValue = "";
            string FirstRowValue = "";
            string SecondColValue = "";
            string SecondRowValue = "";
            string SurrogateCol = "";

            string sData = valList.GetValue(2).ToString();

            //JVRAO
            if (sData.StartsWith("#"))
            {
                string[] tempData = sData.Split('#');
                if (tempData.GetLength(0) > 2)
                {
                    sData = tempData.GetValue(2).ToString();
                    iInstance = Convert.ToInt32(tempData.GetValue(1));
                }
            }

            string[] FirstCell = valList.GetValue(0).ToString().Split('^');
            string[] SecondCell = valList.GetValue(1).ToString().Split('^');
            FirstColValue = FirstCell.GetValue(0).ToString();
            FirstRowValue = FirstCell.GetValue(1).ToString();
            SecondColValue = SecondCell.GetValue(0).ToString();
            SecondRowValue = SecondCell.GetValue(1).ToString();
            SurrogateCol = SecondCell.GetValue(2).ToString();

            UITestControl tempObject = tblObject;

            int tblRowCount = (int)tblObject.GetProperty("RowCount");
            int tblColCount = (int)tblObject.GetProperty("ColumnCount");
            UITestControlCollection AllCells = (UITestControlCollection)tblObject.GetProperty("Cells");

            // Get First Column Number
            if (FirstColValue.StartsWith("#"))
            {
                iColNum1 = Convert.ToInt32(FirstColValue.TrimStart('#').ToString()) - 1;
            }
            else
            {
                iColNum1 = Get_ColumnNumber(tblColCount, AllCells, FirstColValue);
            }


            if (iColNum1 != 1001)
            {
                if (SecondColValue.StartsWith("#"))
                {
                    iColNum2 = Convert.ToInt32(SecondColValue.TrimStart('#').ToString()) - 1;
                }
                else
                {
                    iColNum2 = Get_ColumnNumber(tblColCount, AllCells, SecondColValue);
                }

                if (iColNum2 != 1001)
                {
                    if (SurrogateCol.StartsWith("#"))
                    {
                        iColNum3 = Convert.ToInt32(SurrogateCol.TrimStart('#').ToString()) - 1;
                    }
                    else
                    {
                        iColNum3 = Get_ColumnNumber(tblColCount, AllCells, SurrogateCol);
                    }
                    if (iColNum3 != 1001)
                    {
                        for (int i = 1; i < tblRowCount; i++)
                        {
                            iRowNum1 = Get_RowNumber(tblObject, AllCells, tblRowCount, tblColCount, FirstRowValue, iColNum1, iRowNum1, iInstance);
                            if (iRowNum1 != 1001)
                            {
                                iRowNum = Get_RowNumberWithSecondCondition(tblObject, AllCells, tblColCount, SecondRowValue, iColNum2, iRowNum1);
                                if (iRowNum != 1001)
                                {
                                    _specificrownumber = iRowNum.ToString();
                                    tempObject = FindEmbeddedObjectInCell(tblObject, AllCells, iColNum3 + (iRowNum * tblColCount), iInstance);
                                    string objValue1;
                                    objType = FindObjectType(tempObject, out objValue1);
                                    if (!Operation.ToLower().Equals("getroprop"))
                                    {
                                        objValue = sData;
                                    }
                                    if (objType.Equals("tbl"))
                                    {
                                        tempObject = FindEmbeddedObjectInSpecifiedCell(tempObject, iColNum2, iInstance);
                                        objType = FindObjectType(tempObject, out objValue1);
                                        if (!Operation.ToLower().Equals("getroprop"))
                                        {
                                            objValue = sData;
                                        }
                                    }

                                    if (!objType.Equals("NOTSupportED"))
                                    {
                                        string sDatatmp = sData.ToLower();
                                        if (!(sDatatmp.Equals("click") || sDatatmp.Equals("dclick") || sDatatmp.Equals("hover") || sDatatmp.ToLower().Equals("on") || sDatatmp.ToLower().Equals("off")))
                                        {
                                            if (Operation.ToLower().Equals("update"))
                                            {
                                                iResult = Perform_Operation(tempObject, "GETROPROP", objType, objValue1, "", true, false, out ExceptionFlag);
                                                if (ROPROPERTYVALUE.Equals(sData))
                                                {
                                                    iResult = Perform_Operation(tempObject, Operation, objType, objValue, "", true, false, out ExceptionFlag);
                                                }
                                                else
                                                {
                                                    ADD_INFO = "Actual Value: " + ROPROPERTYVALUE;
                                                    iResult = false;
                                                }
                                            }
                                            else
                                            {
                                                iResult = Perform_Operation(tempObject, Operation, objType, objValue, "", true, false, out ExceptionFlag);
                                            }
                                        }
                                        else
                                        {
                                            iResult = Perform_Operation(tempObject, Operation, objType, objValue, "", true, false, out ExceptionFlag);
                                        }
                                    }

                                    break;
                                }
                            }
                            else
                            {
                                break;
                            }
                            i = iRowNum1;
                            iRowNum1 = i + 1;
                        }
                    }
                }
            }

            return iResult;
        }
        #endregion

        #region Find row inside child Table
        private UITestControl FindEmbeddedObjectInSpecifiedCell(UITestControl TestObject, int iColNum2, int instance)
        {
            UITestControlCollection AllCells = (UITestControlCollection)TestObject.GetProperty("Cells");
            UITestControl tempObject = AllCells[0];
            UITestControl PrevObject = tempObject;

            try
            {
                if (AllCells.Count > 1)
                {
                    if (instance <= iColNum2)
                    {
                        PrevObject = tempObject;
                        tempObject = AllCells[instance - 1];
                    }
                    else
                    {
                        PrevObject = tempObject;
                        tempObject = AllCells[iColNum2];
                    }

                }
            }
            catch (Exception e)
            {
                tempObject = PrevObject;
                string s = e.Message;
            }
            return tempObject;

        }
        #endregion

        #region Find Object Type & return the Object Type.
        private string FindObjectType(UITestControl TestObject, out string objValue)
        {
            string ObjectType = TestObject.GetProperty("ControlType").ToString();

            string objType = "";
            objValue = "";

            switch (ObjectType.ToString())
            {
                case "Edit":
                    objType = "txt";
                    objValue = "Text";
                    break;

                case "FileInput":
                    objType = "tfi";
                    objValue = "FileName";
                    break;

                case "Label":
                    objType = "lbl";
                    objValue = "InnerText";
                    break;

                case "Custom":
                    objType = "cus";
                    objValue = "InnerText";
                    break;

                case "RadioButton":
                    objType = "rad";
                    objValue = "Selected";
                    break;

                case "Button":
                    objType = "btn";
                    objValue = "DisplayText";
                    break;

                case "Hyperlink":
                    objType = "lnk";
                    objValue = "InnerText";
                    break;

                case "ComboBox":
                    objType = "cmb";
                    objValue = "SelectedItem";
                    break;

                case "List":
                    objType = "lst";
                    objValue = "SelectedItemsAsString";
                    break;

                case "CheckBox":
                    objType = "chk";
                    objValue = "Checked";
                    break;

                case "Pane":
                    objType = "pan";
                    objValue = "InnerText";
                    break;

                case "Image":
                    objType = "img";
                    objValue = "FriendlyName";
                    break;

                case "Cell":
                    objType = "cel";
                    objValue = "InnerText";
                    break;

                case "Table":
                    objType = "tbl";
                    objValue = "InnerText";
                    break;

                default:
                    objType = "NOTSupportED";
                    break;
            }
            return objType;
        }
        #endregion

        #region Method to get Property of an object at Run Time.
        private bool Get_RO_Property(UITestControl ObjTemplate, string objType, string ObjValue, string ObjName, bool forTableOperation, out bool ExceptionStatus)
        {
            bool iResult = true;
            bool IsProperObject = true;
            ExceptionStatus = false;

            ROPROPERTYVALUE = "";

            try
            {
                if (!forTableOperation)
                {
                    switch (objType.ToString())
                    {
                        case "txt":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of Text Field " + ObjName;
                            break;

                        case "tfi":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of Text File Input Field " + ObjName;
                            break;

                        case "lbl":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of Label " + ObjName;
                            break;

                        case "cus":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of Custom Field " + ObjName;
                            break;

                        case "rad":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of Radio button " + ObjName;
                            break;

                        case "pan":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of Pane " + ObjName;
                            break;

                        case "cel":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of Cell " + ObjName;
                            break;

                        case "img":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of Image " + ObjName;
                            break;

                        case "btn":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of Button " + ObjName;
                            break;

                        case "lnk":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of Link " + ObjName;
                            break;

                        case "cmb":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of ComboBox " + ObjName;
                            break;

                        case "lst":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of List Box " + ObjName;
                            break;

                        case "chk":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of CheckBox " + ObjName;
                            break;

                        case "tbl":
                            CURRENT_STEP = "Get Property:" + ObjValue + " of Table " + ObjName;
                            break;

                        default:
                            IsProperObject = false;
                            iResult = false;
                            ADD_INFO = objType.ToString() + " is not Supported by this Framework";
                            break;
                    }
                }
                if (IsProperObject == true)
                {
                    ROPROPERTYVALUE = (string)ObjTemplate.GetProperty(ObjValue).ToString();
                    if (ADD_INFO.Equals("") && !forTableOperation)
                    {
                        ADD_INFO = "Value: " + ROPROPERTYVALUE;
                    }
                    //PerformTableOperation(ObjTemplate, ObjValue);
                }

                //if (!forTableOperation)
                //{
                //ConfigurationManager.AppSettings["ROPROPERTYVALUE"] = ROPROPERTYVALUE;
                //}
            }

            catch (Exception e)
            {
                string s = e.Message;
                iResult = false;
                /*CaptureImage(ObjTemplate);
                ProcessRecoveryScenarios(e, out ExceptionStatus);*/
            }
            return iResult;
        }
        #endregion

        #region Perform Operation
        private bool Perform_Operation(UITestControl ObjTemplate, string Operation, string objType, string ObjValue, string ObjName, bool fortableoperation, bool IsCachedObject, out bool ExceptionStatus)
        {
            ExceptionStatus = false;
            bool iResult = false;

            try
            {
                if (!objType.ToString().ToUpper().Equals("TBL"))
                {
                    if (!ObjValue.ToLower().Equals("exists"))
                    {
                        try { ObjTemplate.EnsureClickable(); }
                        catch { }
                    }
                }

                if (!ObjValue.ToLower().Equals("exists"))
                {
                    //try { ObjTemplate.DrawHighlight(); }
                    //catch { }
                }

                switch (Operation.ToString())
                {
                    case "UPDATE":
                        iResult = Update_Action(Operation, ObjTemplate, objType, ObjValue, ObjName, fortableoperation, out ExceptionStatus);
                        break;

                    case "VERIFY":
                        iResult = Verify_Action(Operation, ObjTemplate, objType, ObjValue, ObjName, fortableoperation, out ExceptionStatus);
                        break;

                    case "NEGVERIFY":
                        iResult = Neg_Verify_Action(Operation, ObjTemplate, objType, ObjValue, ObjName, fortableoperation, out ExceptionStatus);
                        break;

                }

            }
            catch (Exception e)
            {
                _errorMessage = _errorMessage + e.Message;
                iResult = false;
            }
            return iResult;
        }
        #endregion

        #region Method for Update Operation.
        private bool Update_Action(string Operation, UITestControl ObjTemplate, string objType, string ObjValue, string ObjName, bool fortableoperation, out bool ExceptionStatus)
        {
            bool iResult = true;
            ExceptionStatus = false;
            bool skipsetpropertyverification = Playback.PlaybackSettings.SkipSetPropertyVerification;


            try
            {
                //Playback.PlaybackSettings.SkipSetPropertyVerification = true;
                switch (objType.ToString())
                {
                    case "txt":
                        if (ObjValue.ToString().ToUpper().Trim().Equals("DATEPICKER"))
                        {
                            Mouse.Click(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        else
                        {
                            ObjTemplate.SetProperty("Text", ObjValue);
                        }
                        break;

                    case "tfi":
                        ObjTemplate.SetProperty("FileName", ObjValue);
                        break;

                    case "lbl":
                        if (ObjValue.ToString().ToUpper().Trim().Equals("DCLICK"))
                        {
                            Mouse.DoubleClick(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("HOVER"))
                        {
                            Mouse.Hover(ObjTemplate, ObjTemplate.GetClickablePoint(), 1000);
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("RIGHTCLICK"))
                        {
                            Mouse.Click(ObjTemplate, MouseButtons.Right);
                        }
                        else
                        {
                            Mouse.Click(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        break;

                    case "cus":
                        if (ObjValue.ToString().ToUpper().Trim().Equals("DCLICK"))
                        {
                            Mouse.DoubleClick(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("HOVER"))
                        {
                            Mouse.Hover(ObjTemplate, ObjTemplate.GetClickablePoint(), 1000);
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("RIGHTCLICK"))
                        {
                            Mouse.Click(ObjTemplate, MouseButtons.Right);
                        }
                        else
                        {
                            Mouse.Click(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        break;

                    case "rad":
                        bool isSelected = false;
                        isSelected = (bool)ObjTemplate.GetProperty("Selected");
                        if (ObjValue.ToUpper() == "ON")
                        {
                            if (!isSelected)
                            {
                                //ObjTemplate.SetProperty("Selected", true);
                                Mouse.Click(ObjTemplate); //Work Around
                            }
                        }
                        else
                        {
                            if (isSelected)
                            {
                                Mouse.Click(ObjTemplate); //Work Around
                                //ObjTemplate.SetProperty("Selected", false);
                            }
                        }
                        break;

                    case "pan":
                        if (ObjValue.ToString().ToUpper().Trim().Equals("DCLICK"))
                        {
                            Mouse.DoubleClick(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("HOVER"))
                        {
                            Mouse.Hover(ObjTemplate, ObjTemplate.GetClickablePoint(), 1000);
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("RIGHTCLICK"))
                        {
                            Mouse.Click(ObjTemplate, MouseButtons.Right);
                        }
                        else
                        {
                            Mouse.Click(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        break;

                    case "cel":
                        if (ObjValue.ToString().ToUpper().Trim().Equals("DCLICK"))
                        {
                            Mouse.DoubleClick(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("HOVER"))
                        {
                            Mouse.Hover(ObjTemplate, ObjTemplate.GetClickablePoint(), 1000);
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("RIGHTCLICK"))
                        {
                            Mouse.Click(ObjTemplate, MouseButtons.Right);
                        }
                        else
                        {
                            Mouse.Click(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        break;

                    case "img":
                        if (ObjValue.ToString().ToUpper().Trim().Equals("DCLICK"))
                        {
                            Mouse.DoubleClick(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("HOVER"))
                        {
                            Mouse.Hover(ObjTemplate, ObjTemplate.GetClickablePoint(), 1000);
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("RIGHTCLICK"))
                        {
                            Mouse.Click(ObjTemplate, MouseButtons.Right);
                        }
                        else
                        {
                            Mouse.Click(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        break;

                    case "btn":
                        if (ObjValue.ToString().ToUpper().Trim().Equals("DCLICK"))
                        {
                            Mouse.DoubleClick(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("HOVER"))
                        {
                            Mouse.Hover(ObjTemplate, ObjTemplate.GetClickablePoint(), 1000);
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("RIGHTCLICK"))
                        {
                            Mouse.Click(ObjTemplate, MouseButtons.Right);
                        }
                        else
                        {
                            Mouse.Click(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        break;

                    case "lnk":
                        if (ObjValue.ToString().ToUpper().Trim().Equals("DCLICK"))
                        {
                            Mouse.DoubleClick(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("HOVER"))
                        {
                            Mouse.Hover(ObjTemplate, ObjTemplate.GetClickablePoint(), 1000);
                        }
                        else if (ObjValue.ToString().ToUpper().Trim().Equals("RIGHTCLICK"))
                        {
                            Mouse.Click(ObjTemplate, MouseButtons.Right);
                        }
                        else
                        {
                            Mouse.Click(ObjTemplate, ObjTemplate.GetClickablePoint());
                        }
                        break;

                    case "cmb":
                        ObjTemplate.SetProperty("SelectedItem", ObjValue);
                        break;

                    case "lst":
                        ObjTemplate.SetProperty("SelectedItemsAsString", ObjValue);
                        break;


                    //Work around for check box click as in some cases it 
                    //doesn't perform the operation.
                    case "chk":

                        bool isChecked = false;
                        isChecked = (bool)ObjTemplate.GetProperty("Checked");

                        if (ObjValue.ToUpper() == "ON")
                        {
                            if (!isChecked)
                            {
                                //ObjTemplate.SetProperty("Checked", true);
                                Mouse.Click(ObjTemplate); //Work Around
                            }
                        }
                        else
                        {
                            if (isChecked)
                            {
                                //ObjTemplate.SetProperty("Checked", false);
                                Mouse.Click(ObjTemplate); //Work Around
                            }
                        }
                        break;

                    case "tbl":
                        iResult = PerformTableOperation2(Operation, ObjTemplate, ObjValue);
                        break;

                    default:
                        iResult = false;
                        iValidateInfo = objType.ToString() + " is not Supported by this Framework";
                        break;
                }
            }

            catch (Exception e)
            {
                _errorMessage = _errorMessage + e.Message;
                iResult = false;
                /*CaptureImage(ObjTemplate);
                ProcessRecoveryScenarios(e, out ExceptionStatus);*/
            }
            Playback.PlaybackSettings.SkipSetPropertyVerification = skipsetpropertyverification;
            return iResult;
        }
        #endregion

        #region Method for Verify Operation.
        private bool Verify_Action(string Operation, UITestControl ObjTemplate, string objType, string ObjValue, string ObjName, bool fortableoperation, out bool ExceptionStatus)
        {
            bool iResult = false;
            ExceptionStatus = false;

            try
            {
                switch (objType.ToString())
                {
                    case "txt":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool txtTemp = ObjTemplate.Exists;
                            if (txtTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string temptext = (string)ObjTemplate.GetProperty("Text");
                            if (temptext == ObjValue)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "tfi":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool tfiTemp = ObjTemplate.Exists;
                            if (tfiTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string temptext1 = (string)ObjTemplate.GetProperty("FileName");
                            if (temptext1 == ObjValue)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "lbl":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool lblTemp = ObjTemplate.Exists;
                            if (lblTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string lblTemp = ObjTemplate.GetProperty("Name").ToString();
                            if (lblTemp.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;


                    case "cus":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool cusTemp = ObjTemplate.Exists;
                            if (cusTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string cusTemp = ObjTemplate.GetProperty("InnerText").ToString();
                            if (cusTemp.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "rad":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool radTemp = ObjTemplate.Exists;
                            if (radTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string radStatus = "OFF";

                            if ((bool)ObjTemplate.GetProperty("Selected"))
                            {
                                radStatus = "ON";
                            }

                            if (radStatus == ObjValue)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "pan":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool panTemp = ObjTemplate.Exists;
                            if (panTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string panTemp = ObjTemplate.GetProperty("InnerText").ToString();
                            if (panTemp.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;


                    case "cel":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool cellTemp = ObjTemplate.Exists;
                            if (cellTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        {
                            string cellTemp = ObjTemplate.GetProperty("InnerText").ToString();
                            if (cellTemp.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "img":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool imgTemp = ObjTemplate.Exists;
                            if (imgTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string imgTemp = ObjTemplate.GetProperty("Name").ToString();
                            if (imgTemp.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "btn":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool btnTemp = ObjTemplate.Exists;
                            if (btnTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string btnTemp = ObjTemplate.GetProperty("Name").ToString();
                            if (btnTemp.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "lnk":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool lnkExists = ObjTemplate.Exists;
                            if (lnkExists)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string lnkExists = ObjTemplate.GetProperty("DisplayText").ToString();
                            if (lnkExists.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "cmb":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool cmbTemp = ObjTemplate.Exists;
                            if (cmbTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string selItem = (string)ObjTemplate.GetProperty("SelectedItem");
                            if (selItem == ObjValue)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "lst":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool lstTemp = ObjTemplate.Exists;
                            if (lstTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string sItem = (string)ObjTemplate.GetProperty("SelectedItemsAsString");
                            if (sItem == ObjValue)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "chk":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool chkTemp = ObjTemplate.Exists;
                            if (chkTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string chkStatus = "OFF";

                            if ((bool)ObjTemplate.GetProperty("Checked"))
                            {
                                chkStatus = "ON";
                            }

                            if (chkStatus == ObjValue)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "tbl":

                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool tblTemp = ObjTemplate.Exists;
                            if (tblTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            iResult = PerformTableOperation2(Operation, ObjTemplate, ObjValue);
                        }
                        break;

                    default:
                        iResult = false;
                        break;
                }

            }

            catch (Exception e)
            {
                _errorMessage = _errorMessage + e.Message;
                iResult = false;
                /*CaptureImage(ObjTemplate);
                ProcessRecoveryScenarios(e, out ExceptionStatus);*/
            }
            return iResult;
        }
        #endregion

        #region Method for Neg Verify Operation.
        private bool Neg_Verify_Action(string Operation, UITestControl ObjTemplate, string objType, string ObjValue, string ObjName, bool fortableoperation, out bool ExceptionStatus)
        {
            bool iResult = false;
            ExceptionStatus = false;

            try
            {
                switch (objType.ToString())
                {
                    case "txt":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool txtTemp = ObjTemplate.Exists;
                            if (txtTemp)
                            {
                                iResult = false;
                            }
                            else
                            {
                                iResult = true;
                            }
                        }
                        else
                        {
                            string temptext = (string)ObjTemplate.GetProperty("Text");
                            if (temptext == ObjValue)
                            {
                                iResult = false;
                            }
                            else
                            {
                                iResult = true;
                            }
                        }
                        break;

                    case "tfi":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool tfiTemp = ObjTemplate.Exists;
                            if (tfiTemp)
                            {
                                iResult = false;
                            }
                            else
                            {
                                iResult = true;
                            }
                        }
                        else
                        {
                            string temptext1 = (string)ObjTemplate.GetProperty("FileName");
                            if (temptext1 == ObjValue)
                            {
                                iResult = false;
                            }
                            else
                            {
                                iResult = true;
                            }
                        }
                        break;

                    case "cus":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool cusTemp = ObjTemplate.Exists;
                            if (!cusTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string cusTemp = ObjTemplate.GetProperty("InnerText").ToString();
                            if (!cusTemp.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;


                    case "lbl":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool lblTemp = ObjTemplate.Exists;
                            if (!lblTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string lblTemp = ObjTemplate.GetProperty("Name").ToString();
                            if (!lblTemp.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;


                    case "rad":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool radTemp = ObjTemplate.Exists;
                            if (radTemp)
                            {
                                iResult = false;
                            }
                            else
                            {
                                iResult = true;
                            }
                        }
                        else
                        {
                            string radStatus = "OFF";
                            if ((bool)ObjTemplate.GetProperty("Selected"))
                            {
                                radStatus = "ON";
                            }

                            if (radStatus == ObjValue)
                            {
                                iResult = false;
                            }
                            else
                            {
                                iResult = true;
                            }
                        }
                        break;

                    case "pan":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool panTemp = ObjTemplate.Exists;
                            if (!panTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string panTemp = ObjTemplate.GetProperty("InnerText").ToString();
                            if (!panTemp.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;


                    case "cel":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool cellTemp = ObjTemplate.Exists;
                            if (!cellTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        {
                            string cellTemp = ObjTemplate.GetProperty("InnerText").ToString();
                            if (!cellTemp.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "img":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool imgTemp = ObjTemplate.Exists;
                            if (!imgTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string imgTemp = ObjTemplate.GetProperty("Name").ToString();
                            if (!imgTemp.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "btn":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool btnTemp = ObjTemplate.Exists;
                            if (!btnTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string btnTemp = ObjTemplate.GetProperty("Name").ToString();
                            if (!btnTemp.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "lnk":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool lnkExists = ObjTemplate.Exists;
                            if (!lnkExists)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            string lnkExists = ObjTemplate.GetProperty("DisplayText").ToString();
                            if (!lnkExists.Equals(ObjValue))
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        break;

                    case "cmb":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool cmbTemp = ObjTemplate.Exists;
                            if (cmbTemp)
                            {
                                iResult = false;
                            }
                            else
                            {
                                iResult = true;
                            }
                        }
                        else
                        {
                            string selItem = (string)ObjTemplate.GetProperty("SelectedItem");
                            if (selItem == ObjValue)
                            {
                                iResult = false;
                            }
                            else
                            {
                                iResult = true;
                            }
                        }
                        break;

                    case "lst":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool lstTemp = ObjTemplate.Exists;
                            if (lstTemp)
                            {
                                iResult = false;
                            }
                            else
                            {
                                iResult = true;
                            }
                        }
                        else
                        {
                            string sItem = (string)ObjTemplate.GetProperty("SelectedItemsAsString");
                            if (sItem == ObjValue)
                            {
                                iResult = false;
                            }
                            else
                            {
                                iResult = true;
                            }
                        }
                        break;

                    case "chk":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool chkTemp = ObjTemplate.Exists;
                            if (chkTemp)
                            {
                                iResult = false;
                            }
                            else
                            {
                                iResult = true;
                            }
                        }
                        else
                        {
                            string chkStatus = "OFF";

                            if ((bool)ObjTemplate.GetProperty("Checked"))
                            {
                                chkStatus = "ON";
                            }

                            if (chkStatus == ObjValue)
                            {
                                iResult = false;
                            }
                            else
                            {
                                iResult = true;
                            }
                        }
                        break;

                    case "tbl":
                        if (ObjValue.ToString().ToLower().Equals("exists"))
                        {
                            bool tblTemp = ObjTemplate.Exists;
                            if (!tblTemp)
                            {
                                iResult = true;
                            }
                            else
                            {
                                iResult = false;
                            }
                        }
                        else
                        {
                            iResult = PerformTableOperation2(Operation, ObjTemplate, ObjValue);
                        }
                        break;

                    default:
                        iResult = false;
                        break;
                }
            }

            catch (Exception e)
            {
                _errorMessage = _errorMessage + e.Message;
                iResult = false;
                /*CaptureImage(ObjTemplate);
                ProcessRecoveryScenarios(e, out ExceptionStatus);*/
            }
            return iResult;
        }
        #endregion

        #region Cybin

        public static SilverlightControl GetControlByCoordinates(String Section, String AutomationId)
        {
            int selX = 1, selY = 1;
            int width = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width;
            int hight = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height;
            string Resolution = String.Concat(width.ToString(), "X", hight.ToString());
            string IniSection;
            String FilePath = Reports.DEPLOYDIR + "\\ControlCoordinates.ini";
            SilverlightControl CtrlToReturn = null;
            if (!File.Exists(FilePath))
            {
                GetEmbeddedFile("NextGenDocPrep", "ControlCoordinates.ini", FilePath);
            }


            BrowserWindow EWB = new BrowserWindow();
            EWB.SearchProperties["ClassName"] = "IEFrame";
            EWB.SetFocus();
            Playback.Wait(1000);

            try
            {
                IniSection = Section.Trim() + "_" + Resolution;

                selX = Convert.ToInt32(IniReadValue(FilePath, IniSection, "selX"));
                selY = Convert.ToInt32(IniReadValue(FilePath, IniSection, "selY"));

                System.Drawing.Point sp = new Point(selX, selY);
                System.Drawing.Point previous = sp;
                Mouse.Location = sp;
                Playback.Wait(1000);

                UITestControl sControl = UITestControlFactory.FromPoint(sp);

                UITestControl ParObj = sControl.GetParent();

                UITestControlCollection ChildObjs = ParObj.GetChildren();



                CtrlToReturn = ChildObjs.Where(p => p.GetProperty("AutomationId").Equals(AutomationId)).FirstOrDefault() as SilverlightControl;


            }
            catch (Exception ex)
            {
                string sMsg = ex.Message;
                CtrlToReturn = null;
            }
            return CtrlToReturn;
        }

        public static UITestControlCollection GetControlCollectionByCoordinates(String Section)
        {
            int selX = 1, selY = 1;
            int width = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width;
            int hight = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height;
            string Resolution = String.Concat(width.ToString(), "X", hight.ToString());
            string IniSection;
            UITestControlCollection ChildObjs = null;
            String FilePath = Reports.DEPLOYDIR + "\\ControlCoordinates.ini";
            if (!File.Exists(FilePath))
            {
                GetEmbeddedFile("NextGenDocPrep", "ControlCoordinates.ini", FilePath);
            }




            BrowserWindow EWB = new BrowserWindow();
            EWB.SearchProperties["ClassName"] = "IEFrame";
            EWB.SetFocus();
            Playback.Wait(1000);

            try
            {
                IniSection = Section.Trim() + "_" + Resolution;

                selX = Convert.ToInt32(IniReadValue(FilePath, IniSection, "selX"));
                selY = Convert.ToInt32(IniReadValue(FilePath, IniSection, "selY"));

                System.Drawing.Point sp = new Point(selX, selY);
                System.Drawing.Point previous = sp;
                Mouse.Location = sp;
                Playback.Wait(1000);

                UITestControl sControl = UITestControlFactory.FromPoint(sp);

                UITestControl ParObj = sControl.GetParent();

                ChildObjs = ParObj.GetChildren();


            }
            catch (Exception ex)
            {
                string sMsg = ex.Message;
                ChildObjs = null;
            }
            return ChildObjs;
        }

        public static SilverlightControl GetControlFromCollection(UITestControlCollection Coll, String AutomationId)
        {

            SilverlightControl CtrlToReturn = (SilverlightControl)Coll.Where(p => p.GetProperty("AutomationId").Equals(AutomationId)).FirstOrDefault();
            return CtrlToReturn;
        }



        #endregion


        public static void CloseClipboardWarning(int timeout = 1000)
        {
            UITestControl MsSilverlight = new UITestControl();
            MsSilverlight.TechnologyName = "MSAA";
            MsSilverlight.SearchProperties.Add(UITestControl.PropertyNames.Name, "Microsoft Silverlight");
            MsSilverlight.SearchProperties.Add(UITestControl.PropertyNames.ClassName, "#32770");

            WinCheckBox RememberMyAnswer = new WinCheckBox(MsSilverlight);
            RememberMyAnswer.TechnologyName = "MSAA";
            RememberMyAnswer.SearchProperties.Add(UITestControl.PropertyNames.Name, "Remember my answer");

            WinButton Yes = new WinButton(MsSilverlight);
            RememberMyAnswer.TechnologyName = "MSAA";
            RememberMyAnswer.SearchProperties.Add(UITestControl.PropertyNames.Name, "Yes");

            if (MsSilverlight.WaitForControlExist(timeout))
            {
                RememberMyAnswer.WaitForControlReady();
                RememberMyAnswer.SetProperty(WinCheckBox.PropertyNames.Checked, true);

                Yes.WaitForControlReady();
                Yes.SetFocus();
                Mouse.Click(Yes);
            }

        }




        // copied from Support.cs  (AutoSupport Project)
        #region From AutoSupport project

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);


        #region Get Object Map Stream
        ///<summary>
        ///<para>Ignore this. Used Internally. Get Stream of file from an assembly.</para>
        ///</summary>
        public static Stream GetObjectMapStream(string binary, string file)
        {
            string fileContents = string.Empty;
            Stream stream = null;
            OBJECT_MAP = file;
            try
            {
                Assembly current = Assembly.LoadFrom(binary + ".dll");
                try
                {
                    stream = current.GetManifestResourceStream(binary + ".Editor." + file + ".XML");
                }
                catch
                {
                    stream = current.GetManifestResourceStream(binary + ".Editor." + file + ".xml");
                }
            }
            catch
            {
                stream = null;
                GeneralMessage = "";
            }
            return stream;
        }
        #endregion

        #region Get Property Collection for the specified object from XML Object Repository.
        ///<summary>
        ///<para>Do not Use. Used Internally. Gets  Properties of the control specified from the Object Map.</para>
        ///</summary>
        public static string GetORPropertyValues(Stream ObjStream, string sObjName, bool IsParent)
        {
            XmlDocument xdoc = new XmlDocument();
            MIC_CLASS = "";
            string sProperties = "NO_PROPS";

            try
            {
                xdoc.Load(ObjStream);

                XmlElement targetElement = null;

                if (IsParent)
                {
                    targetElement = (XmlElement)xdoc.SelectSingleNode("/ObjectMap/Parent[@LogicalName='" + OBJ_PARENT + "']");
                    OBJ_PARENT_ELEMENT = targetElement;
                }
                else
                {
                    targetElement = (XmlElement)OBJ_PARENT_ELEMENT.GetElementsByTagName(sObjName)[0];
                }


                MIC_CLASS = targetElement.Attributes["class"].Value;
                Reports.obj_class = MIC_CLASS;
                sProperties = targetElement.Attributes["properties"].Value;
            }
            catch (Exception e)
            {
                GeneralMessage = "Please check XML file: Exception Occured is " + e.Message;
            }
            return sProperties;
        }
        #endregion

        #region Get Embedded Report file
        ///<summary>
        ///<para>Ignore this. Used Internally. Gets an embedded file "file" from assembly and saves it in the "filepath" specified</para>
        ///</summary>
        public static bool GetEmbeddedFile(string binary, string file, string filePath)
        {
            bool iResult = false;
            string fileContents = string.Empty;
            try
            {
                Assembly current = Assembly.LoadFrom(binary + ".dll");
                using (Stream stream = current.GetManifestResourceStream(binary + "." + file))
                {
                    using (StreamReader streamReader = new StreamReader(stream))
                    {
                        fileContents = streamReader.ReadToEnd();
                    }
                }
            }
            catch (Exception ex)
            {
                string sMsg = ex.Message;
                iResult = false;
                return iResult;
            }

            using (StreamWriter sw = new StreamWriter(filePath))
            {
                sw.Write(fileContents);
                sw.Close();
                iResult = true;
            }
            return iResult;
        }
        #endregion

        #region Reading value from IniFile by passing IniPath, Section, Key
        ///<summary>
        ///<para>Gets the value of the key under the given section of the IniFile</para>
        ///<para>Example: SeleniumInternalHelpersSupportLibrary.General.IniReadValue(path, section, key);k</para>
        ///</summary>
        public static string IniReadValue(string path, string Section, string Key)
        {
            StringBuilder temp = new StringBuilder(255);
            int i = GetPrivateProfileString(Section, Key, "", temp, 255, path);
            return temp.ToString();
        }
        #endregion

        #endregion


    }

}
