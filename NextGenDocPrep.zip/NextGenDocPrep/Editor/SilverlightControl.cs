﻿using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.SilverlightControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Drawing;
using System.Windows.Forms;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;

namespace NextGenDocPrep
{
       // Definition of Class SilverlightControl.
    public class FASilverlightControl : SilverlightControl, FASilverlightInterface
    {
        private string _controlname;
        private SilverlightControl _slvrControl;

        public FASilverlightControl(SilverlightControl sControl)
        {
            _slvrControl = sControl;
            this.CopyFrom(sControl);
            _controlname = SilverlightSupport.controlname;
        }

        public string controlname
        {
            get { return _controlname; }
            set { _controlname = value; }
        }

        public void SendKeys(string skeys)
        {
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                //this.WaitForControlExist();
                Keyboard.SendKeys(_slvrControl, skeys);
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "Sendkeys", "", skeys.ToString(), "", Reports.Result(iResult), eErrorMsg);
        }


        public void Set(string sproperty, object value)
        {
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                //this.WaitForControlExist();
                _slvrControl.SetProperty(sproperty, value);
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "Set", sproperty, value.ToString(), "", Reports.Result(iResult), eErrorMsg);
        }

        public object Get(string sproperty)
        {
            object PropValue = "";
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                _slvrControl.WaitForControlReady(SilverlightSupport.syncTimeout);
                PropValue = _slvrControl.GetProperty(sproperty);
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "Get", sproperty, "", PropValue.ToString(), Reports.Result(iResult), eErrorMsg);
            return PropValue;
        }

        public void Click()
        {
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                _slvrControl.WaitForControlReady(SilverlightSupport.syncTimeout);
                Mouse.Click(_slvrControl);
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "Click", "", "", "", Reports.Result(iResult), eErrorMsg);
        }

        public void RightClick()
        {
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                _slvrControl.WaitForControlReady(SilverlightSupport.syncTimeout);
                Mouse.Click(_slvrControl, MouseButtons.Right);
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "RightClick", "", "", "", Reports.Result(iResult), eErrorMsg);
        }

        public void DoubleClick()
        {
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                _slvrControl.WaitForControlReady(SilverlightSupport.syncTimeout);
                Mouse.DoubleClick(_slvrControl);
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "DoubleClick", "", "", "", Reports.Result(iResult), eErrorMsg);
        }

        public void Val(string sproperty, string sExpectedVal)
        {
            object PropValue = "";
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                _slvrControl.WaitForControlReady(SilverlightSupport.syncTimeout);
                PropValue = _slvrControl.GetProperty(sproperty);
                Assert.AreEqual(sExpectedVal, PropValue.ToString());
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "Val", sproperty, sExpectedVal, PropValue.ToString(), Reports.Result(iResult), eErrorMsg);
        }

        public void Highlight()
        {
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                _slvrControl.WaitForControlReady(SilverlightSupport.syncTimeout);
                _slvrControl.DrawHighlight();
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "Highlight", "", "", "", Reports.Result(iResult), eErrorMsg);
        }

        public UITestControlCollection Children()
        {
            UITestControlCollection sCollection = null;
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                _slvrControl.WaitForControlReady(SilverlightSupport.syncTimeout);
                sCollection = _slvrControl.GetChildren();
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "Children", "", "", "", Reports.Result(iResult), eErrorMsg);
            return sCollection;
        }

        public Point ClickablePoint()
        {
            Point sPoint = new Point();
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                _slvrControl.WaitForControlReady(SilverlightSupport.syncTimeout);
                sPoint = _slvrControl.GetClickablePoint();
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "ClickablePoint", "", "", "", Reports.Result(iResult), eErrorMsg);
            return sPoint;
        }

        public void MakeClickable()
        {
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                _slvrControl.WaitForControlReady(SilverlightSupport.syncTimeout);
                _slvrControl.EnsureClickable();
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "MakeClickable", "", "", "", Reports.Result(iResult), eErrorMsg);
        }

        public void MakeClickable(Point ClickPoint)
        {
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                _slvrControl.WaitForControlReady(SilverlightSupport.syncTimeout);
                _slvrControl.EnsureClickable(ClickPoint);
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "MakeClickable", "", "", "", Reports.Result(iResult), eErrorMsg);
        }

        public bool IsExists()
        {
            bool iResult = true;
            bool Exists = false;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                _slvrControl.WaitForControlReady(SilverlightSupport.syncTimeout);
                Exists = _slvrControl.Exists;
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "IsExists", "", "", _slvrControl.Exists.ToString(), Reports.Result(iResult), eErrorMsg);
            return Exists;
        }

        public UITestControl Parent()
        {
            UITestControl uParent = null;
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                _slvrControl.WaitForControlReady(SilverlightSupport.syncTimeout);
                uParent = _slvrControl.GetParent();
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "Parent", "", "", "", Reports.Result(iResult), eErrorMsg);
            return uParent;
        }

        public UITestControlCollection FindControlsMatch()
        {
            UITestControlCollection uTestCollection = null;
            bool iResult = true;
            string eErrorMsg = SilverlightSupport.GeneralMessage;
            try
            {
                _slvrControl.WaitForControlReady(SilverlightSupport.syncTimeout);
                uTestCollection = _slvrControl.FindMatchingControls();
            }
            catch (Exception e)
            {
                iResult = false;
                eErrorMsg = e.Message + ":" + eErrorMsg;
                Reports.TestResult = false;
            }
            Reports.UpdateDebugLog(controlname, Reports.obj_class, "FindControlsMatch", "", "", "", Reports.Result(iResult), eErrorMsg);
            return uTestCollection;
        }

    }

    // FASilverlightInterface exposed 
    public interface FASilverlightInterface
    {
        ///<summary>
        ///<para>Send keystroke to control</para>
        ///</summary>
        void SendKeys(string skeys);

        ///<summary>
        ///<para>Sets value of a given property.</para>
        ///</summary>
        void Set(string sproperty, object value);

        ///<summary>
        ///<para>Gets value of specified property.</para>
        ///</summary>
        object Get(string sproperty);

        ///<summary>
        ///<para>Click Left Mouse Button</para>
        ///</summary>
        void Click();

        ///<summary>
        ///<para>Click Right Mouse Button</para>
        ///</summary>
        void RightClick();

        ///<summary>
        ///<para>DoubleClick Left Mouse Button</para>
        ///</summary>
        void DoubleClick();

        ///<summary>
        ///<para>Verify Expected - Actual Values of the specified property</para>
        ///</summary>
        void Val(string sproperty, string sExpectedVal);

        ///<summary>
        ///<para>Highlights the control</para>
        ///</summary>
        void Highlight();

        ///<summary>
        ///<para>Returns Collection of first-level children of the current control</para>
        ///</summary>
        UITestControlCollection Children();

        ///<summary>
        ///<para>Returns a Clickable point on the control</para>
        ///</summary>
        Point ClickablePoint();

        ///<summary>
        ///<para>Scrolls the user Interface to make sure the control is clickable</para>
        ///</summary>
        void MakeClickable();

        ///<summary>
        ///<para>Scrolls the user Interface to the specific point to make sure the control is clickable</para>
        ///</summary>
        void MakeClickable(Point ClickPoint);

        ///<summary>
        ///<para>Gets a value that indicates whether the controls exists on the user Interface</para>
        ///</summary>
        bool IsExists();

        ///<summary>
        ///<para>Returns the parent of the current control</para>
        ///</summary>
        UITestControl Parent();

        ///<summary>
        ///<para>Returns collection of all controls that match the current control's search & filter properties</para>
        ///</summary>
        UITestControlCollection FindControlsMatch();
    }

}
