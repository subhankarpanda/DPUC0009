﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Input;
using System.Text;



namespace NextGenDocPrep
{
      [CodedUITest]
      [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
      public class NextGen_DPUC0005 : FASTHelpers
      {
            private static int _regionId = 12837;
            private static int _officeId = 12839;

            #region Private methods
            private int regionId
            {
                  get { return _regionId; }
            }
            private int officeId
            {
                  get { return _officeId; }
            }

            private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
            {
                  var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                  nextGenRequest.Source = "LVIS";
                  nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                  nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                  nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                  nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                  nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

                  return nextGenRequest;
            }

            private bool FAST_CreateFile()
            {
                  try
                  {
                        Reports.TestStep = "Create File using FAST GUI.";
                        FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                        try
                        {
                              FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                        }
                        catch
                        {
                              Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                        }

                        FastDriver.QuickFileEntry.CreateStandardFile();
                        FAST_LoadCurrentFile(regionId);
                  }
                  catch
                  {
                        throw new Exception("File could not be created");
                  }

                  return true;
            }

            private bool WCF_CreateFile()
            {
                  try
                  {
                        Reports.TestStep = "Create File using web service.";
                        var nextGenRequest = GetNextGenWCFFileRequest();
                        FAST_WCF_CreateFile(nextGenRequest);
                  }
                  catch
                  {
                        return false;
                  }

                  return true;
            }

            private bool WCF_CreateFileWithNewLoan()
            {
                  try
                  {
                        Reports.TestStep = "Create File using web service.";
                        var nextGenRequest = GetNextGenWCFFileRequest();
                        nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                        {
                              FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                              LiabilityAmount = 5000.02m,
                              NewLoanAmount = 5000.01m,
                        };
                        nextGenRequest.File.SalesPriceAmount = 2500.0m;
                        nextGenRequest.File.LiabilityAmount = 5000.0m;
                        FAST_WCF_CreateFile(nextGenRequest);
                  }
                  catch
                  {
                        return false;
                  }

                  return true;
            }

            private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
            {
                  try
                  {
                        Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

                        FAST_Login_ADM(isSuperUser: false);
                        FAST_OpenRegionOrOffice(officeId);

                        #region Navigate to NextGen Document Preparation Screen
                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();
                        #endregion

                        // *** Create Templates (if not already exit in environment)
                        // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
                        // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
                        // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
                        // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
                        // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

                        #region Verify that Sanity_Automation Template is present
                        Reports.TestStep = "Check Sanity_Automation Template is present";
                        FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                        FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);

                        FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
                        FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                        var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                        var templateExists = templateTable.Contains(templateDesc);
                        #endregion

                        if(!templateExists)
                        {
                              Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                              FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                              FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                              FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                              FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                              FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                              FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                              FastDriver.NextGenDocumentPreparation.Save.FAClick();
                              FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                              FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                              Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                        }
                        else
                        {
                              Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
                        }
                  }
                  catch(Exception ex)
                  {
                        FailTest(GetExceptionInfo(ex));
                  }
                  finally { FastDriver.WebDriver.Quit(); }

            }

            private int CreateDocumentusingWCFService(int DocTemplateTypeId, string DocName)
            {
                  var GetDocTempReq = RequestFactory.GetDocTemplateRequest(DocTemplateTypeId, regionId);
                  var GetDocTempRes = FASTWCFHelpers.FileService.GetDocTemplates(GetDocTempReq);
                  int index;
                  for(index = 0 ; index < GetDocTempRes.Templates.Length - 1 ; index++)
                  {
                        if(GetDocTempRes.Templates[index].Descr.Contains(DocName))
                        {
                              break;
                        }
                  }
                  int templateID = Convert.ToInt32(GetDocTempRes.Templates[index].TemplateID);

                  var CreateDocReq = RequestFactory.GetCreateDocumentDefaultRequest(File.FileID ?? 0, templateID);
                  CreateDocReq.TitleReportDocumentID = 0;

                  var CreateDocRes = FASTWCFHelpers.FileService.CreateDocument(CreateDocReq);

                  return Convert.ToInt32(CreateDocRes.DocumentID);
            }

            private void SavePDFFile(string PDFFilePath)
            {
                  try
                  {
                        //TODO: Need to convert this to AutoIt
                        Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                        BrowserWindow AdobeReaderwin = new BrowserWindow();
                        UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                        for(int i = 0 ; i < Browsercnt.Count ; i++)
                        {
                              if(((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                              {
                                    AdobeReaderwin.Maximized = true;
                                    break;
                              }
                        }

                        Playback.Wait(5000);

                        Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                        Playback.Wait(2000);
                        FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                        Playback.Wait(2000);
                        Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                        Keyboard.SendKeys(PDFFilePath);
                        Playback.Wait(2000);

                        Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                        Playback.Wait(5000);
                        FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                        Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                        Playback.Wait(7000);
                        Support.CloseAllProcessStartingWith("AcroRd32");
                        Support.CloseAllProcessStartingWith("Acrobat");

                  }
                  catch(Exception)
                  {
                        //Sometimes the preview window doesn't have name
                        Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                        Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                        Playback.Wait(2000);
                        FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                        FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                        Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                        Keyboard.SendKeys(PDFFilePath);
                        Playback.Wait(5000);

                        Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                        Playback.Wait(10000);
                        FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                        Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                        Playback.Wait(7000);
                        Support.CloseAllProcessStartingWith("AcroRd32");
                        Support.CloseAllProcessStartingWith("Acrobat");

                  }
            }

            private void InsertDataElement()
            {

                  var currentLine = FastDriver.DocumentEditor.IRDocumentCurrentLine2;
                  if(currentLine.DelayOnce(10).Visible() == false)
                        currentLine.DelayOnce(60);
                  currentLine.FAClick();
                  Keyboard.SendKeys(FAKeys.Enter);
                  FastDriver.DocumentEditor.IRDocumentCurrentLine6.DelayOnce(3).ContextClick();
                  FastDriver.DocumentEditor.IR_CM_InsertDataElement3.DelayOnce(3).FAClick();
                  FastDriver.DocumentEditor.IRInsertSearch5.DoubleClick();
                  Keyboard.SendKeys(FAKeys.Enter);
                  FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                  FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItemBySendingKeys("Buyer");
                  FastDriver.DataElementSelectionDlg.WaitCreation(FastDriver.DataElementSelectionDlg.SearchResult);
                  FastDriver.DataElementSelectionDlg.GetSearchResult(0).FAClick();
                  FastDriver.DataElementSelectionDlg.Select.FAClick();
                  FastDriver.DialogBottomFrame.ClickDone();
                  FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                  FastDriver.DocumentEditor.WaitForScreenToLoad();

                  if(FastDriver.DocumentEditor.IRSave2.DelayOnce(6).Visible())   // 1920 * 1280
                        FastDriver.DocumentEditor.IRSave2.FAClick();
                  else if(FastDriver.DocumentEditor.IRSave3.Visible())     // 1680 * 1050
                        FastDriver.DocumentEditor.IRSave3.FAClick();
                  else
                        Support.Fail("'Save' was not found by ImageRecognition");
                  FastDriver.DocumentEditor.WaitForScreenToLoad();
                  FastDriver.DocumentEditor.Close.FAClick();
                  FastDriver.DocumentEditor.Yes.FAClick();
                  Playback.Wait(6000);
            }

            private void InsertPhrase(string tplPhraseName, string phraseDescription)
            {
                  if(FastDriver.DocumentEditor.IRInsertPhrase3.DelayOnce(60).Visible())
                  {
                        FastDriver.DocumentEditor.IRInsertPhrase3.ContextClick();
                        FastDriver.DocumentEditor.IRInsertPhraseBottom3.FAClick();
                        FastDriver.DocumentEditor.IRInsertSearch1st3.DoubleClick();
                  }
                  else if(FastDriver.DocumentEditor.IRInsertPhrase2.Visible())
                  {
                        FastDriver.DocumentEditor.IRInsertPhrase2.ContextClick();
                        FastDriver.DocumentEditor.IRInsertPhraseBottom2.FAClick();
                        FastDriver.DocumentEditor.IRInsertSearch4.DoubleClick();
                  }
                  else
                  {
                        Support.Fail("'Insert Phrase/Search' was not found by ImageRecognition");
                  }
                  //
                  Reports.TestStep = "Enter phrase code and hit enter to insert phrase (or) Click Search Button \"…\" for inserting phrase";
                  FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
                  //
                  Reports.TestStep = "Select a phrase from the phrase search dialog and click on done button";
                  FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                  FastDriver.PhraseSelectDlg.Description.FASetText(phraseDescription);
                  FastDriver.PhraseSelectDlg.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                  FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                  FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, tplPhraseName, 1, TableAction.Click);
                  FastDriver.DialogBottomFrame.ClickDone();
                  FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                  FastDriver.DocumentEditor.WaitForScreenToLoad();
                  if(FastDriver.DocumentEditor.IRSave2.DelayOnce(6).Visible())
                        FastDriver.DocumentEditor.IRSave2.FAClick();
                  else if(FastDriver.DocumentEditor.IRSave3.Visible())
                        FastDriver.DocumentEditor.IRSave3.FAClick();
                  else
                        Support.Fail("'Save Button' was not found by ImageRecognition");
                  FastDriver.DocumentEditor.WaitForScreenToLoad();
                  FastDriver.DocumentEditor.Close.FAClick();
                  FastDriver.DocumentEditor.WaitCreation(FastDriver.DocumentEditor.Yes);
                  FastDriver.DocumentEditor.Yes.FAClick();
                  Playback.Wait(6000);
            }

            private void Phrase_phraseGrp_Template(string phraseGrp_Name, string phrase_Type, string templateName, string templateDescription, string templateType)
            {
                  #region Navigate to NextGen Document Preparation Screen
                  Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                  FastDriver.NextGenDocumentPreparation.Open();
                  #endregion

                  #region Verify that if Template is present
                  Reports.TestStep = "Check if Template is present";
                  FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                  FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                  FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);

                  //FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("TEST-Template-" + Support.RandomString(templateDescription.Repeat(2)));

                  FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDescription);

                  FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                  var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                  var templateExists = templateTable.Contains(templateDescription);
                  #endregion

                  if(!templateExists)
                  {
                        #region Create new phrase group

                        FastDriver.NextGenDocumentPreparation.Open();
                        Reports.TestStep = "Create new phrase group";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                        FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);


                        var groupName = Support.RandomString(phraseGrp_Name);

                        FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);


                        var groupDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));

                        FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);

                        FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem(phrase_Type);
                        FastDriver.NextGenDocumentPreparation.SaveButtom.Highlight(3);
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                        Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                        #endregion

                        #region Add phrases
                        Reports.TestStep = "Add phrases";
                        FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                        FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);

                        var phraseName = Support.RandomString(phraseGrp_Name);

                        FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);

                        var phraseDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));

                        FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);

                        FastDriver.NextGenDocumentPreparation.SaveButtom.Highlight(3);
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                        #endregion

                        #region Insert phrases
                        Reports.TestStep = "Insert phrases";
                        FastDriver.NextGenDocumentPreparation.PhraseViewButtom.Highlight(3);
                        FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
                        FastDriver.DocumentEditor.WaitForScreenToLoad();
                        this.InsertDataElement();

                        //this.InsertPhrase(phraseName, phraseDescription);


                        #endregion

                        #region Create template

                        #region Navigate to NextGen Document Preparation Screen
                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();
                        #endregion

                        #region Create template
                        Reports.TestStep = "Create a new template";


                        FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
                        FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();


                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                        templateName = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(4));
                        FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                        templateDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(26));

                        FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText("TEST-Template-" + Support.RandomString(templateDescription.Repeat(2)));

                        FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                        FastDriver.NextGenDocumentPreparation.Save.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                        #endregion

                        #region Insert template
                        Reports.TestStep = "Insert template";
                        FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                        FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                        FastDriver.DocumentEditor.WaitForScreenToLoad();
                        this.InsertPhrase(groupName + "/" + phraseName, phraseDescription);
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                        FastDriver.NextGenDocumentPreparation.Save.FAClick();
                        #endregion








                  }
                  else
                  {
                        Reports.StatusUpdate("Template: " + templateDescription + " already exist", true);
                  }


                        #endregion

            }

            public static void MouseHoverOnObject(IWebElement TargetElement)
            {

                  string javaScript = "var evObj = document.createEvent('MouseEvents');" +
                                      "evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);" +
                                      "arguments[0].dispatchEvent(evObj);";
                  IJavaScriptExecutor js = FastDriver.WebDriver as IJavaScriptExecutor;
                  js.ExecuteScript(javaScript, TargetElement);
            }


            public void CreateAssociatePackageNRemove(string TempSearchKeywprd, string Temp1, string Temp2)
            {
                  #region Navigate to Document Repository Screen
                  Reports.TestStep = "Navigate to Document Repository Screen";
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion

                  #region Search a template
                  Reports.TestStep = "Search Template by click on search button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").Highlight();
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").FAClick();
                  //  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion


                  #region Search for templates using search criteria
                  Reports.TestStep = "Search for templates using search criteria(with all fiter and title reports)";
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  // FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                  // FastDriver.NextGenDocumentRepository.SearchScope.FindElement(By.Id("ddTemplTypes")).FASelectItem("Title Reports");
                  FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FAFindElement(ByLocator.Id, "ddcl-ddl_sources").FADoubleClick();
                  FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
                  FastDriver.NextGenDocumentRepository.QASandpoint.FASetCheckbox(true);

                  FastDriver.NextGenDocumentRepository.TemplateDescription.FAClick();
                  FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                  FastDriver.NextGenDocumentRepository.StateValue_ALL_0.FASetCheckbox(true);
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempSearchKeywprd);
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion
                  //  TempSearchKeywprd =  NEXTGEN_SAN*   /     NEXTGEN_SAN_TitleReports_DoNotTouch   NEXTGEN_SAN_EscrowInstruction_DoNotTouch       NEXTGEN_SAN_EscrowInstruction_DoNotTouch
                  // Temp1 =     NEXTGEN_SAN_TitleReports_DoNotTouch  
                  //Temp 2 =  NEXTGEN_SAN_EscrowInstruction_DoNotTouch
                  // Temp3 = NEXTGEN_SAN_EscrowInstruction_DoNotTouch

                  var documents_1 = new List<string> { TempSearchKeywprd };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents_1);

                  #region  Right Click
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", Temp1, "Description", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Select "Create Document" option
                  Reports.TestStep = "Select Create Document option from the context menu";
                  FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Navigate to Document Repository Scree--1
                  Reports.TestStep = "Navigate to Document Repository Screen";
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion

                  #region Click on "Template Search" button      --1
                  Reports.TestStep = "Click on \"Template Search\" button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").Highlight();
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion

                  #region Search for templates using search criteria         --1
                  Reports.TestStep = "Search for templates using search criteria";
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempSearchKeywprd);
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Select a template by using "Ctrl" command     --1
                  Reports.TestStep = "Select one template by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  var documentsnew = new List<string> { Temp2 };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documentsnew);
                  #endregion

                  #region Hold Right Click   --1
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", Temp2, "Description", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Select "Create Document" option    --1
                  Reports.TestStep = "Select \"Create Document\" option";
                  FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Select Multiple templates (2 or more) by using "Ctrl" command
                  Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                  //      FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  var documents3 = new List<string> { Temp1, Temp2 };
                  FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                  //FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents3);
                  #endregion

                  #region   "Highlight two or more documents and Right Click"
                  Reports.TestStep = "Highlight two or more documents and Right Click";
                  FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", Temp2, "Name", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region    Click on "Add to Associate Package and MOdify it"
                  Reports.TestStep = "Click on Add to Associate Package";
                  FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                  if(FastDriver.NextGenDocumentRepository.AssociatePackages.Exists() == true)
                  { FastDriver.NextGenDocumentRepository.AssociatePackages.FAClick(); }

                  Reports.TestStep = "Modify the name of  Associate Package";
                  FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("Modified-associated-Package0");
                  FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();
                  #endregion

                  #region Click on "OK" button in the Alert Message box
                  string Message = "new modified pakcage";
                  string mesg1 = "Package : " + "'" + Message + "'" + " created successfully.";
                  Support.AreEqual(mesg1, "Package : 'new modified pakcage' created successfully.");
                  Reports.TestStep = "Click on ok";
                  FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                  Playback.Wait(5000);
                  #endregion

                  #region Select the package created in the above steps and verify the documents
                  Reports.TestStep = "Select the package created in the above steps and verify the documents";
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  var package = FastDriver.NextGenDocumentRepository.FindAssociatePackage(Temp1);
                  var packageContent = package.GetAttribute("textContent");
                  Support.AreEqual("True", packageContent.Contains("NEXTGEN_SAN_TitleReports_DoNotTouch").ToString(), "Package contains Modified-associated-Package0");

                  package = FastDriver.NextGenDocumentRepository.FindAssociatePackage(Temp1, true);
                  #endregion


                  #region      If package has minimum of three documents ,user optionally highlights a document Right click and clicks the Remove button.

                  Reports.TestStep = "Right click on Remove.";
                  if(packageContent.Contains("NEXTGEN_SAN_TitleReports_DoNotTouch"))
                  {
                        FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle1.Highlight(10);
                        FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle1.FARightClick();
                  }


                  FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Remove.Highlight();
                  FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Remove.FADoubleClick();
                  #endregion

                  #region "System displays the Remove Document Association confirmation message.".

                  Reports.TestStep = "Verify System displays the Remove Document Association confirmation message. ";
                  string Message_1 = "Remove 'NEXTGEN_SAN_LenderPolicy_DoNotTouch' from 'Modified-associated-Package0' ?";
                  FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message_1);
                  Playback.Wait(6000);
                  //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                  Support.MessageHandler(true);
                  #endregion

            }



            public string RandomString(int Size)
            {
                  //string input = "abcdefghijklmnopqrstuvwxyz0123456789";
                  //StringBuilder builder = new StringBuilder();
                  //char ch;
                  Random rand = new Random();

                   string Alphabet =   "abcdefghijklmnopqrstuvwyxzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                   char[] chars = new char[Size];
                   for(int i = 0 ; i < Size ; i++)
                   {
                         chars[i] = Alphabet[rand.Next(Alphabet.Length)];
                   }
                   return new string(chars);

                 
            }

            #endregion

            #region REG

            #region REG0001   Add New Phrase Group
            [TestMethod]
            [Description("Add New Phrase Group")]
            public void DPUC005_REG001()
            {
                  try
                  {
                        Reports.TestDescription = "Main Course 1: Add New Phrase Group";
                        EnableSavingIRSamples();
                        SetSilverlightClipboardPermission_YES();
                        Reports.TestDescription = "Navigate to ADM site";
                        FAST_Login_ADM(isSuperUser: false);
                        FAST_OpenRegionOrOffice(officeId);
                  

                        #region Navigate to NextGen Document Preparation Screen
                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();
                        #endregion


                        #region Create new phrase group
                        Reports.TestDescription = "Create new phrase group";
                        Reports.TestStep = "clicks on the Phrases Tab. ";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                        Reports.TestStep = "Create New PhraseGroup Tab";
                        FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                        Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.


                        Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        string Message_0 = "Phrase Group Name is required.";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_0);
                        Playback.Wait(4500);

                        Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                        string randomName = RandomString(4);
                        FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                        var GRPname = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                        Reports.TestStep = "User selects phrase type.";
                        FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                        var phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                        Reports.TestStep = "User enters a description.";
                        var groupDescription = "TEST--" + "Title--" + GRPname;
                        FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);


                        Reports.TestStep = "10.	User saves the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                        Reports.TestStep = "Verify System adds the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                        Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                        #endregion


                  }

                  catch(Exception ex)
                  {
                        FailTest(GetExceptionInfo(ex));
                  }
            }


            #endregion // Ma in Course 1


            #region REG0002  "Alternate Course 1: Add Phrase to Phrase Group"
            [TestMethod]
            [Description("Alternate Course 1: Add Phrase to Phrase Group")]
            public void DPUC0005_REG0002()
            {

               try
                  {
                        EnableSavingIRSamples();
                        SetSilverlightClipboardPermission_YES();
                        Reports.TestDescription = "Navigate to ADM site";
                        FAST_Login_ADM(isSuperUser: false);
                        FAST_OpenRegionOrOffice(officeId);

                        #region Navigate to NextGen Document Preparation Screen
                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();
                        #endregion
                       
                        #region Create new phrase group
                        Reports.TestDescription = "Create new phrase group";
                        Reports.TestStep = "clicks on the Phrases Tab. ";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                        Reports.TestStep = "Create New PhraseGroup Tab";
                        FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                        Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                        Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        string Message_0 = "Phrase Group Name is required.";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_0);
                        Playback.Wait(4500);
                        

                        Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                        string randomName = RandomString(4);
                        FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                        var GRPname  =   FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                        Reports.TestStep = "User selects phrase type.";
                        FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                        var phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                        Reports.TestStep = "User enters a description.";
                        var groupDescription = "TEST--" +"Title--" +GRPname;
                        FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription); 
                        

                        Reports.TestStep = "10.	User saves the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                        Reports.TestStep = "Verify System adds the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                        Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                        Playback.Wait(6000);
                        #endregion

                        Reports.TestDescription = "Alternate Course 1: Add Phrase to Phrase Group";
                        Reports.TestStep = "Add phrases through search";
                        FastDriver.NextGenDocumentPreparation.PhraseSearch.Exists();
                        Reports.TestStep = "verfiy the Phase serch tab by click on phrase serach tab";
                        FastDriver.NextGenDocumentPreparation.PhraseSearch.FAClickAction();

                        Reports.TestStep = " select same phrase type.";
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                        if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                        { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i15").FASetCheckbox(true); }


                        Reports.TestStep = " enters same description.";
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText(groupDescription);

                        Reports.TestStep = "clicks on the Phrase Search and searches for the required Phrase Group";
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction();
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResultsTable.Exists();
                       var desc =   FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResultsTable.PerformTableAction(1, 4, TableAction.GetCell).Element.FAGetText();
                       Reports.TestStep = "clicks on ‘Add  Phrase’ button in the Actions column of the search results of the Phrase group";
                       if(desc.Contains(groupDescription)) { FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResultsTable.PerformTableAction(1, 4, TableAction.GetCell).Element.FARightClick(); }
                       FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResults_AddPhrase.FASelectContextMenuItem();

                       Reports.TestStep = "enters a unique name for the phrase";
                          FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                          string phrasename =  RandomString(2);
                          char[] remove = { 'J', 'P' };
                          phrasename.Remove(phrasename.Length - 2);
                          string oldphrasename = GRPname.TrimEnd(remove);
                          FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(oldphrasename + phrasename);
                          var Adding_PhraseName = FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue();

                          if(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.IsReadOnly() == false) { Reports.StatusUpdate("verified phrase name is editable", true); }
                          Reports.TestStep = "enters description";
                        var phraseDescription = "TEST--" + "Title-Phrase-" + GRPname;
                        FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);

                        Reports.TestStep = "verify phrase  under construction.";
                        FastDriver.NextGenDocumentPreparation.UnderConstruction_Chkbox.IsEnabled();

                        Reports.TestStep = "User modifies the inherited phrase group properties such as font name, font size, and margins (top, left, right,).";
                        FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FASelectItem("Arial");
                        FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("11");
                        FastDriver.NextGenDocumentPreparation.PhraseMargin_Left.FASetText("0.25");
                        FastDriver.NextGenDocumentPreparation.PhraseMargin_Top.FASetText("0.10");

                        Reports.TestStep = "verify user can able to edits other properties that are specific to a Phrase such as Full Justify, Keep Lines together, and Link to Previous Phrase.";
                        FastDriver.NextGenDocumentPreparation.PhraseMarginMode_FullJustify.FASetCheckbox(true);
                        FastDriver.NextGenDocumentPreparation.PhraseMarginMode_KeepLinesTog.FASetCheckbox(true);
                        Playback.Wait(2000);
                        FastDriver.NextGenDocumentPreparation.PhraseRevisionTable.FAFindElement(ByLocator.Id, "Phrase_0_txtHistComments").FASetText(Adding_PhraseName + ": new Phrase addded");

                     
                        Reports.TestStep = "verify the status is active";
                        FastDriver.NextGenDocumentPreparation.Status_Active.IsEnabled();

                        Reports.TestStep = "selects the option to save the phrase.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(7000);
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                  }
                  
               catch(Exception ex)
                  {
                        FailTest(GetExceptionInfo(ex));
                  }
             
            }


            #endregion reg0002

            
            #region REG003       Alternate Course 2: Search Phrase Group
            [TestMethod]
           public  void DPUC005_REG003()
            {
                 try
                 {
                       Reports.TestDescription = "Main Course 1: Add New Phrase Group";
                       EnableSavingIRSamples();
                       SetSilverlightClipboardPermission_YES();
                       Reports.TestDescription = "Navigate to ADM site";
                       FAST_Login_ADM(isSuperUser: false);
                       FAST_OpenRegionOrOffice(officeId);

                       Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                       FastDriver.NextGenDocumentPreparation.Open();

                       #region Create new phrase group
                       Reports.TestDescription = "Create new phrase group";
                       Reports.TestStep = "clicks on the Phrases Tab. ";
                       FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                       Reports.TestStep = "Create New PhraseGroup Tab";
                       FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                       Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                       Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       string Message_0 = "Phrase Group Name is required.";
                       FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_0);
                       Playback.Wait(4500);

                       Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                       string randomName = RandomString(4);
                       FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                       var GRPname = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                       Reports.TestStep = "User selects phrase type.";
                       FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                       var phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                       Reports.TestStep = "User enters a description.";
                       var groupDescription = "TEST--" + "Title--" + GRPname;
                       FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);


                       Reports.TestStep = "10.	User saves the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                       Reports.TestStep = "Verify System adds the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                       Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                       #endregion


                       Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                       FastDriver.NextGenDocumentPreparation.Open();

                       Reports.TestStep = "clicks on the Phrases Tab. ";
                       FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                       Reports.TestStep = " select same phrase type.";
                       FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                       if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                       { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i15").FASetCheckbox(true); }

                       Reports.TestStep = "selects a region other than the Default region.";
                      
                       FastDriver.NextGenDocumentPreparation.PhraseRegion.FAClickAction();

                       FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//input[@id='ddcl-ddlPhraseRegions-i7']").FASetCheckbox(true);
                                            
                       Reports.TestStep = " enters the description with '*' ";
                       string myString = groupDescription.Remove(groupDescription.Length - 4);


                       FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText(myString+"*");
                       FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction();
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                       if(FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.IsDisplayed() == true)
                       { Reports.StatusUpdate("phrase search group meet the criteria", true); }
                    
                      


                 }

                 catch(Exception ex)
                 {
                       FailTest(GetExceptionInfo(ex));
                 }

            }
            #endregion


            #region REG004       Alternate Course 3: Edit Phrase Group
            [TestMethod]
            public void DPCU0005_REG004()
            {
                try                    
                  {
                        Reports.TestDescription = "Alternate Course 3: Edit Phrase Group";
                        EnableSavingIRSamples();
                        SetSilverlightClipboardPermission_YES();
                        Reports.TestDescription = "Navigate to ADM site";
                        FAST_Login_ADM(isSuperUser: false);
                        FAST_OpenRegionOrOffice(officeId);

                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();

                        #region Create new phrase group
                        Reports.TestDescription = "Create new phrase group";
                        Reports.TestStep = "clicks on the Phrases Tab. ";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                        Reports.TestStep = "Create New PhraseGroup Tab";
                        FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                        Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                        Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        string Message_0 = "Phrase Group Name is required.";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_0);
                        Playback.Wait(4500);

                        Reports.TestStep = "verify to save a Phrase Group when Invalid characters are entered in Phrase Group Name field.";
                        FastDriver.NextGenDocumentPreparation.GroupName.FASetText("^A#$");
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        string ErroMSG_0 = "Name may only contain 0-9 a-z A-Z < > * % $ # : '(-); + = . , characters";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: ErroMSG_0);

                        Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                        string randomName = RandomString(4);
                        FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                        var GRPname = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                        Reports.TestStep = "to save a Phrase Group when Invalid characters are entered in Phrase Group Description field.";
                        FastDriver.NextGenDocumentPreparation.Description.FASetText("^A#$&**##%&*(");
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                      //     Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' "  + - = ( ) . , characters

                        string ErroMSG_1 = "Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \"  + - = ( ) . , characters";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: ErroMSG_1);

                        Reports.TestStep = "User selects phrase type.";
                        FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                        var phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                        Reports.TestStep = "User enters a description.";
                        var groupDescription = "TEST--" + "Title--" + GRPname;
                        FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);


                        Reports.TestStep = "10.	User saves the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                        Reports.TestStep = "Verify System adds the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                        Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                        #endregion


                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();

                        Reports.TestStep = "clicks on the Phrases Tab. ";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                        Reports.TestStep = " select same phrase type.";
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                        if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                        { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i15").FASetCheckbox(true); }

                        Reports.TestStep = "selects a region other than the Default region.";

                        FastDriver.NextGenDocumentPreparation.PhraseRegion.FAClickAction();

                        FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//input[@id='ddcl-ddlPhraseRegions-i7']").FASetCheckbox(true);

                        Reports.TestStep = " enters the description with '*' ";
                        string myString = groupDescription.Remove(groupDescription.Length - 4);
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText(myString + "*");
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction();

                        Reports.TestStep = "search result with all the Phrase Groups that meet the search criteria";
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                        if(FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.IsDisplayed() == true)
                        { Reports.StatusUpdate("phrase search group meet the criteria", true); }

                       FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.FADoubleClick();
                       string Desc = FastDriver.NextGenDocumentPreparation.Description.FAGetValue();

                       Reports.TestStep = "User modifies the phrase group Description, Phrase Type, and/or Formatting";
                       if(FastDriver.NextGenDocumentPreparation.Description.FAGetValue() == groupDescription)
                        { FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription + "--Modified"); }
                       FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                       FastDriver.NextGenDocumentPreparation.PhraseGrpFont_Name.FASelectItem("Arial");
                       FastDriver.NextGenDocumentPreparation.PhraseGrpFont_Size.FASelectItem("11");
                       FastDriver.NextGenDocumentPreparation.PhraseGrpMargin_Left.FASetText("0.25");
                       FastDriver.NextGenDocumentPreparation.PhraseGrpMargin_Right.FASetText("0.25");
                       FastDriver.NextGenDocumentPreparation.PhraseGrpMargin_Top.FASetText("0.10");
                      
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                       if(FastDriver.NextGenDocumentPreparation.PhraseGrpeditRvHisTab_commenttxt.IsEnabled() == true) { FastDriver.NextGenDocumentPreparation.PhraseGrpeditRvHisTab_commenttxt.FASetText("Phrase formatting changed "); }

                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();

                       Reports.TestStep = "Verfiy System updates the Revision History";
                       if(FastDriver.NextGenDocumentPreparation.PhraseGrpRevisionTable.PerformTableAction("Comments", "Phrase properties edited; Phrase formatting changed ", "Comments", TableAction.GetCell).Element.IsDisplayed() == true)
                       {
                             Reports.StatusUpdate("system update the phrase group info successfully.", true);
                       }

                  }

                  catch(Exception ex)
                  {
                        FailTest(GetExceptionInfo(ex));
                  }

            }
            #endregion



            #region REG005      Alternate Course 4: Delete Phrase Group
            [TestMethod]
           public void    DPUC0005_REG005()
           {
                  try
                  {
                        Reports.TestDescription = "Alternate Course 4: Delete Phrase Group";
                        EnableSavingIRSamples();
                        SetSilverlightClipboardPermission_YES();
                        Reports.TestDescription = "Navigate to ADM site";
                        FAST_Login_ADM(isSuperUser: false);
                        FAST_OpenRegionOrOffice(officeId);

                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();

                        #region Create new phrase group
                        Reports.TestDescription = "Create new phrase group";
                        Reports.TestStep = "clicks on the Phrases Tab. ";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                        Reports.TestStep = "Create New PhraseGroup Tab";
                        FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                        Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.


                        Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        string Message_0 = "Phrase Group Name is required.";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_0);
                        Playback.Wait(4500);

                        Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                        string randomName = RandomString(4);
                        FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                        var GRPname = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                        Reports.TestStep = "User selects phrase type.";
                        FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                        var phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                        Reports.TestStep = "User enters a description.";
                        var groupDescription = "TEST--" + "Title--" + GRPname;
                        FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);


                        Reports.TestStep = "10.	User saves the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                        Reports.TestStep = "Verify System adds the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                        Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                        #endregion


                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();

                        Reports.TestStep = "clicks on the Phrases Tab. ";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                        Reports.TestStep = " select same phrase type.";
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                        if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                        { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i15").FASetCheckbox(true); }

                        Reports.TestStep = "selects a region other than the Default region.";

                        FastDriver.NextGenDocumentPreparation.PhraseRegion.FAClickAction();

                        FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//input[@id='ddcl-ddlPhraseRegions-i7']").FASetCheckbox(true);

                        Reports.TestStep = " enters the description with '*' ";
                        string myString = groupDescription.Remove(groupDescription.Length - 4);
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText(myString + "*");
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction(); Playback.Wait(4000);

                        Reports.TestStep = "search result with all the Phrase Groups that meet the search criteria";
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                        if(FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.IsDisplayed() == true)
                        { Reports.StatusUpdate("phrase search group meet the criteria", true); }

                        FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.FARightClick();
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResults_Delete.Highlight(5);
                        FastDriver.NextGenDocumentPreparation.phraseGrpsearchcontext_Delete.FASelectContextMenuItem();
                        //Playback.Wait(4000);

                        if(FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.Exists() == false)
                        { Reports.StatusUpdate("Phrase deleted successfully", true); }

                  }


                  catch(Exception ex)
                  {
                        FailTest(GetExceptionInfo(ex));
                  }

           }


            #endregion


            #region REG006      Alternate Course 5: Deactivate a Phrase Group
            [TestMethod]
           public void    DPUC0005_REG006()
           {
                  try
                  {
                        Reports.TestDescription = "Alternate Course 5: Deactivate a Phrase Group";
                        EnableSavingIRSamples();
                        SetSilverlightClipboardPermission_YES();
                        Reports.TestDescription = "Navigate to ADM site";
                        FAST_Login_ADM(isSuperUser: false);
                        FAST_OpenRegionOrOffice(officeId);

                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();

                        #region Create new phrase group
                        Reports.TestDescription = "Create new phrase group";
                        Reports.TestStep = "clicks on the Phrases Tab. ";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                        Reports.TestStep = "Create New PhraseGroup Tab";
                        FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                        Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                        Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        string Message_0 = "Phrase Group Name is required.";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_0);
                        Playback.Wait(4500);

                        Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                        string randomName = RandomString(4);
                        FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                        var GRPname = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                        Reports.TestStep = "User selects phrase type.";
                        FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Endorsement Phrase[ENDORSE]");
                        var phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                        Reports.TestStep = "User enters a description.";
                        var groupDescription = "TEST--" + "ENDORSE--" + GRPname;
                        FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);


                        Reports.TestStep = "10.	User saves the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                        Reports.TestStep = "Verify System adds the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                        Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                        #endregion

                        #region Edit phrase grop and add a phrase
                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();

                        Reports.TestStep = "clicks on the Phrases Tab. ";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                        Reports.TestStep = " select same phrase type.";
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                        if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                        { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i3").FASetCheckbox(true); }

                        Reports.TestStep = "selects a region other than the Default region.";

                        FastDriver.NextGenDocumentPreparation.PhraseRegion.FAClickAction();
                        Playback.Wait(5000);

                        if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//input[@id='ddcl-ddlPhraseRegions-i7']").IsDisplayed() == true)
                        { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//input[@id='ddcl-ddlPhraseRegions-i7']").FASetCheckbox(true); }
                 
                        Reports.TestStep = " enters the description with '*' ";
                        string myString = groupDescription.Remove(groupDescription.Length - 4);
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText(myString + "*");
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction();

                        Reports.TestStep = "search result with all the Phrase Groups that meet the search criteria";
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                        if(FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.IsDisplayed() == true)
                        { Reports.StatusUpdate("phrase search group meet the criteria", true); }

                        Reports.TestStep = "selects the system option to edit the Phrase Group";    
                        FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.FADoubleClick();

                        Reports.TestStep = "Adding a New phrase";
                        if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                        if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                        FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                        string RandomsName_1 = RandomString(4);
                        FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_1);
                        FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_1 + "--Phrase");
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);
                        #endregion

                        Reports.TestStep = "click on EditPhraseGroup";
                        if(FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }


                        Reports.TestStep = "selects the system option to set the phrase group status as Inactive";
                        if(FastDriver.NextGenDocumentPreparation.PhraseGrpeditstatus_Inactive.IsVisible() == true)
                        { FastDriver.NextGenDocumentPreparation.PhraseGrpeditstatus_Inactive.FAClickAction(); }

                        Reports.TestStep = "verify User can enters Status Change Comment(s)";

                        if(FastDriver.NextGenDocumentPreparation.PhraseGrpeditRvHisTab_commenttxt.IsEnabled() == true) { FastDriver.NextGenDocumentPreparation.PhraseGrpeditRvHisTab_commenttxt.FASetText("Phrase group have done Inactive "); }
                        var commenttext = FastDriver.NextGenDocumentPreparation.PhraseGrpeditRvHisTab_commenttxt.FAGetValue();
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);

                         

                         Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Status", "Inactive", "Revised Date", TableAction.GetText).Message);

                  }

                  catch(Exception ex)
                  {
                        FailTest(GetExceptionInfo(ex));
                  }

           }
          #endregion


            #region REG007     Alternate Course 6: Reactivate a Phrase Group
            [TestMethod]
           public void    DPUC0005_REG007()
           {
                  try
                  {
                        Reports.TestDescription = "Alternate Course 6: Reactivate a Phrase Group";
                       
                        EnableSavingIRSamples();
                        SetSilverlightClipboardPermission_YES();
                        Reports.TestDescription = "Navigate to ADM site";
                        FAST_Login_ADM(isSuperUser: false);
                        FAST_OpenRegionOrOffice(officeId);

                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();

                        #region Create new phrase group
                        Reports.TestDescription = "Create new phrase group";
                        Reports.TestStep = "clicks on the Phrases Tab. ";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                        Reports.TestStep = "Create New PhraseGroup Tab";
                        FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                        Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                        Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        string Message_0 = "Phrase Group Name is required.";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_0);
                        Playback.Wait(4500);

                        Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                        string randomName = RandomString(4);
                        FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                        var GRPname = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();


                        Reports.TestStep = "User selects phrase type.";
                        FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Endorsement Phrase[ENDORSE]");
                        var phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                        Reports.TestStep = "User enters a description.";
                        var groupDescription = "TEST--" + "ENDORSE--" + GRPname;
                        FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);


                        Reports.TestStep = "10.	User saves the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);


                        Reports.TestStep = "Verify System adds the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                        Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                        #endregion

                        #region   Inactive the phrase group by edit phrase group
                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();

                        Reports.TestStep = "clicks on the Phrases Tab. ";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                        Reports.TestStep = " select same phrase type.";
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                        if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                        { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i3").FASetCheckbox(true); }

                        Reports.TestStep = "selects a region other than the Default region.";

                        FastDriver.NextGenDocumentPreparation.PhraseRegion.FAClickAction();

                        FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//input[@id='ddcl-ddlPhraseRegions-i7']").FASetCheckbox(true);

                        Reports.TestStep = " enters the description with '*' ";
                        string myString = groupDescription.Remove(groupDescription.Length - 4);
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText(myString + "*");
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction();

                        Reports.TestStep = "search result with all the Phrase Groups that meet the search criteria";
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                        if(FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.IsDisplayed() == true)
                        { Reports.StatusUpdate("phrase search group meet the criteria", true); }

                        Reports.TestStep = "selects the system option to edit the Phrase Group";
                        FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.FADoubleClick();

                        Reports.TestStep = "Adding a New phrase";
                        if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                        if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                        FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                        string RandomsName_1 = RandomString(4);
                        FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_1);
                        FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_1 + "--Phrase");
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);


                        Reports.TestStep = "click on EditPhraseGroup";
                        if(FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }


                        Reports.TestStep = "selects the system option to set the phrase group status as Inactive";
                        if(FastDriver.NextGenDocumentPreparation.PhraseGrpeditstatus_Inactive.IsVisible() == true)
                        { FastDriver.NextGenDocumentPreparation.PhraseGrpeditstatus_Inactive.FAClickAction(); }

                        Reports.TestStep = "verify User can enters Status Change Comment(s)";

                        if(FastDriver.NextGenDocumentPreparation.PhraseGrpeditRvHisTab_commenttxt.IsEnabled() == true) { FastDriver.NextGenDocumentPreparation.PhraseGrpeditRvHisTab_commenttxt.FASetText("Phrase group have done Inactive "); }
                        var commenttext = FastDriver.NextGenDocumentPreparation.PhraseGrpeditRvHisTab_commenttxt.FAGetValue();
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);
                        #endregion

                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();

                        Reports.TestStep = "clicks on the Phrases Tab. ";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                        Reports.TestStep = " select same phrase type.";
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                        if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                        { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i3").FASetCheckbox(true); }
                        Reports.TestStep = "selects a region other than the Default region.";

                        FastDriver.NextGenDocumentPreparation.PhraseRegion.FAClickAction();

                        FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//input[@id='ddcl-ddlPhraseRegions-i7']").FASetCheckbox(true);

                        Reports.TestStep = " enters the description with '*' ";
                        string myString1 = groupDescription.Remove(groupDescription.Length - 4);
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText(myString1 + "*");
                        FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddPhraseGroupStatus").FASelectItem("InActive");
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction();
                        FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.FADoubleClick();
                        Playback.Wait(4000);
                        Reports.TestStep = "selects the system option to set the phrase group status as active";
                        if(FastDriver.NextGenDocumentPreparation.PhraseGrpeditstatus_active.IsVisible() == true)
                        { FastDriver.NextGenDocumentPreparation.PhraseGrpeditstatus_active.FAClickAction(); }

                        Reports.TestStep = "verify User can enters Status Change Comment(s)";

                        if(FastDriver.NextGenDocumentPreparation.PhraseGrpeditRvHisTab_commenttxt.IsEnabled() == true) { FastDriver.NextGenDocumentPreparation.PhraseGrpeditRvHisTab_commenttxt.FASetText("Phrase group have done active again"); }
                        var commenttext1 = FastDriver.NextGenDocumentPreparation.PhraseGrpeditRvHisTab_commenttxt.FAGetValue();
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);
                        Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Status", "Active", "Revised Date", TableAction.GetText).Message);

                  }

                  catch(Exception ex)
                  {
                        FailTest(GetExceptionInfo(ex));
                  }

           }
          #endregion


            #region REG008     Alternate Course 7: Edit Phrase via Phrase Maintenance
            [TestMethod]
           public void    DPUC0005_REG008()
           {
                  try
                  {
                        Reports.TestDescription = "Alternate Course 7: Edit Phrase via Phrase Maintenance";

                        EnableSavingIRSamples();
                        SetSilverlightClipboardPermission_YES();
                        Reports.TestDescription = "Navigate to ADM site";
                        FAST_Login_ADM(isSuperUser: false);
                        FAST_OpenRegionOrOffice(officeId);


                        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                        FastDriver.NextGenDocumentPreparation.Open();

                        #region Create new phrase group
                        Reports.TestDescription = "Create new phrase group";
                        Reports.TestStep = "clicks on the Phrases Tab. ";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                        Reports.TestStep = "Create New PhraseGroup Tab";
                        FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                        Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                        Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        string Message_0 = "Phrase Group Name is required.";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_0);
                        Playback.Wait(4500);

                        Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                        string randomName = RandomString(4);
                        FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                        var GRPname = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                        Reports.TestStep = "User selects phrase type.";
                        FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Endorsement Phrase[ENDORSE]");
                        var phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                        Reports.TestStep = "User enters a description.";
                        var groupDescription = "TEST--" + "ENDORSE--" + GRPname;
                        FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);


                        Reports.TestStep = "10.	User saves the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                        Reports.TestStep = "Verify System adds the new phrase group.";
                        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                        Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                        #endregion
                       ///*********************************************
                        Reports.TestStep = "Adding a New phrase";
                        if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                        if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                        FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);

                        Reports.TestStep = "Validate to save the new phrase creation instance when Phrase Name is blank.";

                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                        string errormessage0 = "Phrase Name is required.";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: errormessage0);
                        Playback.Wait(3000);


                        Reports.TestStep = "verify to save a Phrase  when Invalid characters are entered in Phrase Group Name field.";
                        FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText("^A#$");
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        string ErroMSG_0 = "Phrase Name may only contain 0-9 a-z A-Z < > * % $ # : ; ' \"  + - = ( ) . , characters";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: ErroMSG_0);

                        string RandomsName_1 = RandomString(4);
                        FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_1);

                        Reports.TestStep = "Validate to save the new phrase creation instance when Phrase Name is blank.";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                        string errormessage = "Phrase Description is required.";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: errormessage);
                        Playback.Wait(3000);

                        Reports.TestStep = "to save a Phrase Group when Invalid characters are entered in Phrase  Description field.";
                        FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("^A#$&**##%&*(");
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                        //     Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' "  + - = ( ) . , characters

                        string ErroMSG_1 = "Phrase Description may only contain 0-9 a-z A-Z < > * % $ # : ; ' \" / + - = ( ) . , characters";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: ErroMSG_1);

                        FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_1 + "--Phrase");
                        var phrase1 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);

                        Reports.TestStep = "click on EditPhraseGroup";
                        if(FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }

                        if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                        if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                       
                        FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                        string RandomsName_2 = RandomString(4);
                        FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_2);
                        FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_2 + "--Phrase");
                        var phrase2 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);

                        FastDriver.NextGenDocumentPreparation.Open();
                        Reports.TestStep = "clicks on the Phrases Tab. ";
                        FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                        FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();


                        Reports.TestStep = " select same phrase type.";
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClickAction();
                        if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                        { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i3").FASetCheckbox(true); }

                        Reports.TestStep = "selects a region other than the Default region.";
                         FastDriver.NextGenDocumentPreparation.PhraseRegion.FAClickAction();
                        FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//input[@id='ddcl-ddlPhraseRegions-i7']").FASetCheckbox(true);

                        Reports.TestStep = " enters the description with '*' and select the phrase ";
                        string myString = groupDescription.Remove(groupDescription.Length - 4);
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText(myString + "*");
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction();
                        FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.FARightClick();
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResults_Properties.FASelectContextMenuItem();

                        Reports.TestStep = "selects a Phrase from the Phrases list";
                        FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "gridPhrases").PerformTableAction("Description", phrase1, "Description", TableAction.GetCell).Element.FARightClick();

                        Reports.TestStep = "right clicks on the Phrase and selects ‘Properties’";
                        FastDriver.NextGenDocumentPreparation.EditPhrasetable.FASelectContextMenuItem();

                        Reports.TestStep = "attempts to enter Top margin value greater than 7.0";
                        FastDriver.NextGenDocumentPreparation.PhraseMargin_Top.FASetText("7.10");
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(2500);
                        string errormessage_1 = "Incorrect Top Margin value. Valid values are decimals between 0.00 and 7.00";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: errormessage_1); Playback.Wait(3000);

                        Reports.TestStep = "attempts to enter Left margin value greater than 7.0";
                        FastDriver.NextGenDocumentPreparation.PhraseMargin_Top.FASetText(".11");
                        FastDriver.NextGenDocumentPreparation.PhraseMargin_Left.FASetText("7.25");
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(2500);
                                    string ERR1 = "Error(s) occured. See Message pane.";
                        FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: ERR1); Playback.Wait(2500);
                        FastDriver.NextGenDocumentPreparation.FAFErrorMessageList.Highlight(2);
                        string errormessage_2 = FastDriver.NextGenDocumentPreparation.FAFErrorMessageList.FAGetText();
                        Support.AreEqual("LeftMarginValue: Valid Entry is 0.0 to 7.0", errormessage_2);


                         Reports.TestStep = "attempts to enter Right margin value greater than 7.0";
                         FastDriver.NextGenDocumentPreparation.PhraseMargin_Left.FASetText(".11");
                         FastDriver.NextGenDocumentPreparation.PhraseMargin_Right.FASetText("7.25");
                         FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                         FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(2500);
                         string ERR2 = "Error(s) occured. See Message pane.";
                         FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: ERR2); Playback.Wait(2500);
                         FastDriver.NextGenDocumentPreparation.FAFErrorMessageList.Highlight(2);
                      
                         string errormessage_3 = FastDriver.NextGenDocumentPreparation.FAFErrorMessageList.FAGetText();
                         Support.AreEqual("RightMarginValue: Valid Entry is 0.0 to 7.0", errormessage_3);


                        Reports.TestStep = "User modifies the inherited phrase group properties such as font name, font size, and margins (top, left, right,).";
                        FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FASelectItem("Arial");
                        FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("11");
                        FastDriver.NextGenDocumentPreparation.PhraseMargin_Left.FASetText("0.25");
                        FastDriver.NextGenDocumentPreparation.PhraseMargin_Top.FASetText("0.10");

                        Reports.TestStep = "verify user can able to edits other properties that are specific to a Phrase such as Full Justify, Keep Lines together, and Link to Previous Phrase.";
                        FastDriver.NextGenDocumentPreparation.PhraseMarginMode_FullJustify.FASetCheckbox(true);
                        FastDriver.NextGenDocumentPreparation.PhraseMarginMode_KeepLinesTog.FASetCheckbox(true);
                        Reports.TestStep = "User enters Comments.";
                        FastDriver.NextGenDocumentPreparation.PhraseGrpRevisionTable.FAFindElement(ByLocator.XPath, "//div[@id='divPhraseRevisionHistory']").FAFindElement(ByLocator.Id, "Phrase_0_txtHistComments").Highlight(10);
                        FastDriver.NextGenDocumentPreparation.PhraseGrpRevisionTable.FAFindElement(ByLocator.XPath, "//div[@id='divPhraseRevisionHistory']").FAFindElement(ByLocator.Id, "Phrase_0_txtHistComments").FASetText((phrase1).Replace("--","+") + "  modifed");

                        Reports.TestStep = "selects the system option to save the changes";
                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment.. please wait...", false); Playback.Wait(8000);


          

                  }

                  catch(Exception ex)
                  {
                        FailTest(GetExceptionInfo(ex));
                  }

           }
                #endregion


            #region REG009     Alternate Course 8: Deactivate a Phrase
            [TestMethod]

            public void DPUC0005_REG009()
            {
                   try
                   {
                         Reports.TestDescription = "Alternate Course 8: Deactivate a Phrase";
                         EnableSavingIRSamples();
                         SetSilverlightClipboardPermission_YES();
                         Reports.TestDescription = "Navigate to ADM site";
                         FAST_Login_ADM(isSuperUser: false);
                         FAST_OpenRegionOrOffice(officeId);


                         Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                         FastDriver.NextGenDocumentPreparation.Open();

                         #region Create new phrase group
                         Reports.TestDescription = "Create new phrase group";
                         Reports.TestStep = "clicks on the Phrases Tab. ";
                         FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                         FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                         Reports.TestStep = "Create New PhraseGroup Tab";
                         FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab

                         Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                         FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                         string Message_0 = "Phrase Group Name is required.";
                         FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_0);
                         Playback.Wait(4500);


                         Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                         FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                         Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                         string randomName = RandomString(4);
                         FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                         var GRPname = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                         Reports.TestStep = "User selects phrase type.";
                         FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Endorsement Phrase[ENDORSE]");
                         var phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                         Reports.TestStep = "User enters a description.";
                         var groupDescription = "TEST--" + "ENDORSE--" + GRPname;
                         FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);


                         Reports.TestStep = "10.	User saves the new phrase group.";
                         FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                         FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                         Reports.TestStep = "Verify System adds the new phrase group.";
                         FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                         Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                         #endregion

                         Reports.TestStep = "Adding a New phrase";
                         if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                         if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                         FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                         string RandomsName_1 = RandomString(4);
                         FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_1);
                         FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_1 + "--Phrase");
                         var phrase1 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                         FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                         FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);

                         Reports.TestStep = "click on EditPhraseGroup";
                         if(FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }

                         if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                         if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }

                         FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                         string RandomsName_2 = RandomString(4);
                         FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_2);
                         FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_2 + "--Phrase");
                         var phrase2 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                         FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                         FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);

                         FastDriver.NextGenDocumentPreparation.Open();
                         Reports.TestStep = "clicks on the Phrases Tab. ";
                         FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                         FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();


                         Reports.TestStep = " select same phrase type.";
                         FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClickAction(); Playback.Wait(3000);
                         if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                         { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i3").FASetCheckbox(true); }

                         Reports.TestStep = "selects a region other than the Default region.";
                         FastDriver.NextGenDocumentPreparation.PhraseRegion.FAClickAction();
                         FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//input[@id='ddcl-ddlPhraseRegions-i7']").FASetCheckbox(true);

                         Reports.TestStep = " enters the description with '*' and select the phrase ";
                         string myString = groupDescription.Remove(groupDescription.Length - 4);
                         FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText(myString + "*");
                         FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction();
                         FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.FARightClick();
                         FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResults_Properties.FASelectContextMenuItem();

                         Reports.TestStep = "selects a Phrase from the Phrases list";
                         FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "gridPhrases").PerformTableAction("Description", phrase1, "Description", TableAction.GetCell).Element.FARightClick();

                         Reports.TestStep = "right clicks on the Phrase and selects ‘Properties’";
                         FastDriver.NextGenDocumentPreparation.EditPhrasetable.FASelectContextMenuItem(); Playback.Wait(5000);
                         FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsDisplayed();
                         Reports.TestStep = "selects the system option to set the phrase status as Inactive.";
                         if(FastDriver.NextGenDocumentPreparation.Status_InActive.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.Status_InActive.FAClickAction(); }

                         Reports.TestStep = " Enters Status Change Comment(s";
                         FastDriver.NextGenDocumentPreparation.PhraseGrpRevisionTable.FAFindElement(ByLocator.XPath, "//div[@id='divPhraseRevisionHistory']").FAFindElement(ByLocator.Id, "Phrase_0_txtHistComments").FASetText((phrase1).Replace("--", "  ") + "  deactivated");
                         FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                         FastDriver.WebDriver.WaitForWindowAndSwitch("One moment...", false); Playback.Wait(8000);

                         var comments1 = FastDriver.NextGenDocumentPreparation.PhraseGrpRevisionTable.FAFindElement(ByLocator.XPath, "//div[@id='divPhraseRevisionHistory']").FAFindElement(ByLocator.Id, "Phrase_1_lblComments").FAGetText();
                         Reports.TestStep = "System deactivates the phrase and displays the deactivation date and the user id";

                         Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseRevisionTable.PerformTableAction("Status", "Inactive", "Revised Date", TableAction.GetText).Message);

                         Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseRevisionTable.PerformTableAction("Revised By", AutoConfig.UserName, "Revised Date", TableAction.GetText).Message, "System Deactivated phrase scuccessfully.");

                         if(FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }
                   }


                   catch(Exception ex)
                   {
                         FailTest(GetExceptionInfo(ex));
                   }
            }
            #endregion



            #region REG0010    Alternate Course 9: Reactivate a Phrase
            [TestMethod]
           public void    DPUC0005_REG0010()
           {
                 try
                 {
                       #region Create a New Phrase group with phrase and deactivate a phrase.
                      
                       EnableSavingIRSamples();
                       SetSilverlightClipboardPermission_YES();
                       Reports.TestDescription = "Navigate to ADM site";
                       FAST_Login_ADM(isSuperUser: false);
                       FAST_OpenRegionOrOffice(officeId);


                       Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                       FastDriver.NextGenDocumentPreparation.Open();

                       #region Create new phrase group
                       Reports.TestDescription = "Create new phrase group";
                       Reports.TestStep = "clicks on the Phrases Tab. ";
                       FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                       Reports.TestStep = "Create New PhraseGroup Tab";
                       FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                       Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                       Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       string Message_0 = "Phrase Group Name is required.";
                       FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_0);
                       Playback.Wait(4500);


                       Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                       string randomName = RandomString(4);
                       FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                       var GRPname = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                       Reports.TestStep = "User selects phrase type.";
                       FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Endorsement Phrase[ENDORSE]");
                       var phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                       Reports.TestStep = "User enters a description.";
                       var groupDescription = "TEST--" + "ENDORSE--" + GRPname;
                       FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);


                       Reports.TestStep = "10.	User saves the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                       Reports.TestStep = "Verify System adds the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                       Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                       #endregion

                       Reports.TestStep = "Adding a New phrase";
                       if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                       if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                       FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                       string RandomsName_1 = RandomString(4);
                       FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_1);
                       FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_1 + "--Phrase");
                       var phrase1 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);

                       Reports.TestStep = "click on EditPhraseGroup";
                       if(FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }

                       if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                       if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }

                       FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                       string RandomsName_2 = RandomString(4);
                       FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_2);
                       FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_2 + "--Phrase");
                       var phrase2 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);

                       FastDriver.NextGenDocumentPreparation.Open();
                       Reports.TestStep = "clicks on the Phrases Tab. ";
                       FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();


                       Reports.TestStep = " select same phrase type.";
                       FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClickAction();
                       if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                       { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i3").FASetCheckbox(true); }

                       Reports.TestStep = "selects a region other than the Default region.";
                       FastDriver.NextGenDocumentPreparation.PhraseRegion.FAClickAction();
                       FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//input[@id='ddcl-ddlPhraseRegions-i7']").FASetCheckbox(true);

                       Reports.TestStep = " enters the description with '*' and select the phrase ";
                       string myString = groupDescription.Remove(groupDescription.Length - 4);
                       FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText(myString + "*");
                       FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction();
                       FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.FARightClick();
                       FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResults_Properties.FASelectContextMenuItem();

                       Reports.TestStep = "selects a Phrase from the Phrases list";
                       FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "gridPhrases").PerformTableAction("Description", phrase1, "Description", TableAction.GetCell).Element.FARightClick();

                       Reports.TestStep = "right clicks on the Phrase and selects ‘Properties’";
                       FastDriver.NextGenDocumentPreparation.EditPhrasetable.FASelectContextMenuItem();

                       Reports.TestStep = "selects the system option to set the phrase status as Inactive.";
                       if(FastDriver.NextGenDocumentPreparation.Status_InActive.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.Status_InActive.FAClickAction(); }

                       Reports.TestStep = " Enters Status Change Comment(s";
                       FastDriver.NextGenDocumentPreparation.PhraseGrpRevisionTable.FAFindElement(ByLocator.XPath, "//div[@id='divPhraseRevisionHistory']").FAFindElement(ByLocator.Id, "Phrase_0_txtHistComments").FASetText((phrase1).Replace("--", "  ") + "  deactivated");
                       
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(8000);
                       var comments1 = FastDriver.NextGenDocumentPreparation.PhraseGrpRevisionTable.FAFindElement(ByLocator.XPath, "//div[@id='divPhraseRevisionHistory']").FAFindElement(ByLocator.Id, "Phrase_1_lblComments").FAGetText();
                       Reports.TestStep = "System deactivates the phrase and displays the deactivation date and the user id";

                       Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseRevisionTable.PerformTableAction("Status", "InActive", "Revised Date", TableAction.GetText).Message);

                       //Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseRevisionTable.PerformTableAction("Revised By", AutoConfig.UserName, "Revised Date", TableAction.GetText).Message);

                       if(FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }


                       #endregion

                       Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                       FastDriver.NextGenDocumentPreparation.Open();

                       Reports.TestStep = "clicks on the Phrases Tab. ";
                       FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                       
                       Reports.TestStep = " select same phrase type.";
                       FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClickAction();
                       if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                       { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i3").FASetCheckbox(true); }

                       Reports.TestStep = "Search the phrase group with phrase which is inactive";
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText(myString + "*");
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseDescription.FASetText(phrase1);
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupPhraseCode.FASetText(GRPname + "/" + RandomsName_1);
                        FastDriver.NextGenDocumentPreparation.PhraseGrp_Status.FASelectItem("Both");
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction();
                        FastDriver.WebDriver.WaitForWindowAndSwitch("One moment.. please wait...", false); Playback.Wait(8000);

                        Reports.TestStep = "Select phrase group and click on right click and navigate to Properties";
                        FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction("Description", groupDescription, "Description", TableAction.GetCell).Element.FARightClick();
                        FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResults_Properties.FASelectContextMenuItem();
                        Playback.Wait(5000);

                        Reports.TestStep = "verfify the inactive phrase selects inactive Phrase from the Phrases list";
                        FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "gridPhrases").PerformTableAction("Description", phrase1, "Description", TableAction.GetCell).Element.Exists();
                        if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "gridPhrases").PerformTableAction("Status", "InActive", "Status", TableAction.GetCell).Element.Exists()== true)
                        {
                              FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "gridPhrases").PerformTableAction("Status", "InActive", "Status", TableAction.GetCell).Element.FARightClick();
                              FastDriver.NextGenDocumentPreparation.EditPhrasetable.FASelectContextMenuItem(); Playback.Wait(5000);

                        }

                        Reports.TestStep = "System displays the Phrase Maintenance screen.";
                        FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsDisplayed();

                        Reports.TestStep = "selects the system option to set the phrase status as Active";
                        if((FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue() == RandomsName_1) && (FastDriver.NextGenDocumentPreparation.Status_InActive.IsSelected()))
                       
                       {FastDriver.NextGenDocumentPreparation.Status_Active.FAClickAction(); }

                        Reports.TestStep = " Enters Status Change Comment(s";
                        FastDriver.NextGenDocumentPreparation.PhraseGrpRevisionTable.FAFindElement(ByLocator.XPath, "//div[@id='divPhraseRevisionHistory']").FAFindElement(ByLocator.Id, "Phrase_0_txtHistComments").FASetText((phrase1).Replace("--", "  ") + " Activated");

                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction(); Playback.Wait(8000);
                        var comments2 = FastDriver.NextGenDocumentPreparation.PhraseGrpRevisionTable.FAFindElement(ByLocator.XPath, "//div[@id='divPhraseRevisionHistory']").FAFindElement(ByLocator.Id, "Phrase_1_lblComments").FAGetText();

                        Reports.TestStep = "System deactivates the phrase and displays the Activation date and the user id";

                        Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseRevisionTable.PerformTableAction("Status", "Active", "Revised Date", TableAction.GetText).Message);

                        Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseRevisionTable.PerformTableAction("Comments", comments2, "Comments", TableAction.GetText).Message);
                        
                 }



                       
                 catch(Exception ex)
                 {
                       FailTest(GetExceptionInfo(ex));
                 }

           }
             #endregion



             #region REG0011    Alternate Course 10: Copy Phrases
            [TestMethod]
           public void    DPUC0005_REG0011()
           {
                 try
                 {
                       EnableSavingIRSamples();
                       SetSilverlightClipboardPermission_YES();
                       Reports.TestDescription = "Navigate to ADM site";
                       FAST_Login_ADM(isSuperUser: false);
                       FAST_OpenRegionOrOffice(officeId);


                       Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                       FastDriver.NextGenDocumentPreparation.Open();

                       #region Create new phrase group 1 with phrase
                       Reports.TestDescription = "Create new phrase group";
                       Reports.TestStep = "clicks on the Phrases Tab. ";
                       FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                       Reports.TestStep = "Create New PhraseGroup Tab";
                       FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                       Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                       Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       string Message_0 = "Phrase Group Name is required.";
                       FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_0);
                       Playback.Wait(4500);

                       Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                       string randomName = RandomString(4).ToUpper(); ;
                       FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                       var GRPname = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                       Reports.TestStep = "User selects phrase type.";
                       FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Endorsement Phrase[ENDORSE]");
                       var phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();

                       Reports.TestStep = "Vaildate the message when we tries to save the instance when Phrase Group Description is blank.";
                       string MessageNEW_0 = "Phrase Group Description is required.";
                       FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: MessageNEW_0); Playback.Wait(3500);


                       Reports.TestStep = "User enters a description.";
                       var groupDescription = "TEST--" + "ENDORSE--" + GRPname;
                       FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);


                       Reports.TestStep = "10.	User saves the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                       Reports.TestStep = "Verify System adds the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                       Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                  

                       Reports.TestStep = "Adding a New phrase";
                       if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                       if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                       FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                       string RandomsName_1 = RandomString(4).ToUpper();
                       FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_1);
                       FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_1 + "--Phrase");
                       var phrase1 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);
                       var phrase1code = FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue();

                       Reports.TestStep = "click on EditPhraseGroup";
                       if(FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }

                       if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                       if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }

                       FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                       string RandomsName_2 = RandomString(4).ToUpper();
                       FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_2);
                       FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_2 + "--Phrase");
                       var phrase2 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                     var phrase2code =   FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);
                 
                       #endregion



                       #region Create new phrase group 2 with phrase
                       Reports.TestDescription = "Create new phrase group";
                       FastDriver.NextGenDocumentPreparation.Open();
                       Reports.TestStep = "clicks on the Phrases Tab. ";
                       FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                       Reports.TestStep = "Create New PhraseGroup Tab";
                       FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                       Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                       Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       string Message_1 = "Phrase Group Name is required.";
                       FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_1);
                       Playback.Wait(4500);

                       Reports.TestStep = "Validate duplicate gropuname by save the new phrase group creation instance when Duplicate Phrase Group Name exists";
                        FastDriver.NextGenDocumentPreparation.GroupName.FASetText(GRPname);
                        FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                        FastDriver.NextGenDocumentPreparation.Description.FASetText("TEST--" + "TITLE--" + GRPname);

                        FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction(); Playback.Wait(3000);
                        Support.MessageHandler(true);


                       Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                       string randomName_1 = RandomString(4).ToUpper(); ;
                       FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName_1);
                       var GRPname_1 = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                       Reports.TestStep = "User selects phrase type.";
                       FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                       var phrasetype_1 = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                       Reports.TestStep = "User enters a description.";
                       var groupDescription_1 = "TEST--" + "TITLE--" + GRPname_1;
                       FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription_1);


                       Reports.TestStep = "10.	User saves the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                       Reports.TestStep = "Verify System adds the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                       Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);


                       Reports.TestStep = "Adding a New phrase";
                       if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                       if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                       FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                       string RandomsName_NEW1 = RandomString(4).ToUpper();
                      
                       FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW1);
                       FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "TITLE--" + RandomsName_NEW1 + "--Phrase");
                       var phrase1_1 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);
                       var phrase1_1Code = FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue();

                       Reports.TestStep = "click on EditPhraseGroup";
                       if(FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }

                       if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                       if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }

                       FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                       FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phrase1_1Code);
                       FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "TITLE--" + phrase1_1Code + "--Phrase");
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(4000);
                       Support.MessageHandler(true);
                       string errormsg =    FastDriver.NextGenDocumentPreparation.FAFErrorMessageList.FAGetText();
                       Support.AreEqual("ObjectCd: Phrase Name already exists. Please enter a new Name", errormsg);

                       string RandomsName_NEW2 = RandomString(4).ToUpper(); ;
                       FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW2);
                       FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "TITLE--" + RandomsName_NEW2 + "--Phrase");
                       string phrase1_2 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);
                       string phrase1_2Code =FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue();
                       #endregion


                       FastDriver.NextGenDocumentPreparation.Open();
                       Reports.TestStep = "clicks on the Phrases Tab. ";
                       FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                       FastDriver.NextGenDocumentPreparation.CopyMovePhrases.FAClickAction();
                       Playback.Wait(3000);

                       if(!FastDriver.NextGenDocumentPreparation.CopyPhrases.IsSelected())
                       { FastDriver.NextGenDocumentPreparation.CopyPhrases.FAClickAction(); }

                       FastDriver.NextGenDocumentPreparation.CopyPhrasesBtn.FAClickAction();
                       Playback.Wait(5000);
                       Reports.TestStep = "Verify the validation Error when there are no phrase to copy";
                       var validationMSg = FastDriver.NextGenDocumentPreparation.CopyPhrasesValidationDivMsg.FAGetText();
                         Support.AreEqual(validationMSg, "No 1:Invalid From Phrase Group.");

                         Playback.Wait(6000);

                         #region Copy a Phrase from one gropp to another group 
                         Reports.TestDescription = "Copy a Phrase from one group to another group ";
                         Reports.TestStep = "Select the region From where Phrase should copied";
                         FastDriver.NextGenDocumentPreparation.FirstFormRegion.FASelectItem("QA Sandpointe - Next Gen");
                         Reports.TestStep = "Select the phrase group From";
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirstFormGroup.FASelectItem(GRPname);

                         Reports.TestStep = "select the phrase From Table List which have to copy";
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirstFormPhraseCodeSelect.FAClickAction();
                         Playback.Wait(3000);
                         FastDriver.NextGenDocumentPreparation.CopyMoveSelectAPhrase.FASetCheckbox(true);
                         FastDriver.NextGenDocumentPreparation.CopyMoveSelectAPhrase_Done.FAClickAction();
                         Playback.Wait(2500);

                         Reports.TestStep = "Select the region where Phrase to be copied";
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirsToRegion.FASelectItem("QA Sandpointe - Next Gen");
                         Reports.TestStep = "select the Phrase Group To";
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirsToGroup.FASelectItem(GRPname_1);

                         Reports.TestStep = "Enter The Phrase Name which to be copied in name/code of";
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseName.FASetText(phrase1code);
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseDescrp.FASetText(phrase1);
                         var ValidationGRP1 = FastDriver.NextGenDocumentPreparation.CopyMoveFirsToGroup.FAGetSelectedItem();
                         var validationPhrase1 = FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseName.FAGetValue();
                         var ValidationPhraseDesc1 = FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseDescrp.FAGetValue();
                         Reports.TestStep = "Copy Phrase by click on copy ";
                         FastDriver.NextGenDocumentPreparation.CopyPhrasesBtn.FAClickAction();
                         Playback.Wait(5000);

                         Reports.TestStep = "Verification of Copy Successfull.";
                         var validationMessgae1 = FastDriver.NextGenDocumentPreparation.CopyPhrasesValidationDivMsg.FAGetText();
                      
                         Support.AreEqual(validationMessgae1, "No 1:Success");
                         #endregion


                         #region Copy same  Phrase again from one group to another group
                         
                         Reports.TestStep = "Select the region where Phrase to be copied";
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirsToRegion.FASelectItem("QA Sandpointe - Next Gen");
                         Reports.TestStep = "select the Phrase Group To";
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirsToGroup.FASelectItem(GRPname_1);
                         var ValidationGRP2 = FastDriver.NextGenDocumentPreparation.CopyMoveFirsToGroup.FAGetSelectedItem();
                         Reports.TestStep = "Enter The Phrase Name which to be copied in name/code of";
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseName.FASetText(phrase1code);
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseDescrp.FASetText(phrase1);
                         var validationPhrase2 = FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseName.FAGetValue();
                         var ValidationPhraseDesc2 = FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseDescrp.FAGetValue();
                         Reports.TestStep = "Copy Phrase by click on copy ";
                         FastDriver.NextGenDocumentPreparation.CopyPhrasesBtn.FAClickAction();
                         Playback.Wait(5000);

                         Reports.TestStep = "Verification of Copy iwth same phrase again.";
                         var validationMessgae2 = FastDriver.NextGenDocumentPreparation.CopyPhrasesValidationDivMsg.FAGetText();
                         Support.AreEqual(validationMessgae2, "No 1:Invalid From Phrase Group.");
                         #endregion


                         #region Copy same  Phrase again from &  to same group with diffrent phrase

                         Reports.TestStep = "Select the region where Phrase to be copied";
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirsToRegion.FASelectItem("QA Sandpointe - Next Gen");
                         Reports.TestStep = "select the Phrase Group To";
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirsToGroup.FASelectItem(GRPname);
                         var ValidationGRP3 = FastDriver.NextGenDocumentPreparation.CopyMoveFirsToGroup.FAGetSelectedItem();
                         Reports.TestStep = "Enter The Phrase Name which to be copied in name/code of";
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseName.FASetText(phrase1_1Code);
                         var validationPhrase3 = FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseName.FAGetValue();
                         FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseDescrp.FASetText(phrase1_1);
                         var ValidationPhraseDesc3 = FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseDescrp.FAGetValue();
                         Reports.TestStep = "Copy Phrase by click on copy ";
                         FastDriver.NextGenDocumentPreparation.CopyPhrasesBtn.FAClickAction();
                         Playback.Wait(5000);

                         Reports.TestStep = "Verification of Copy iwth same phrase again.";
                         var validationMessgae3 = FastDriver.NextGenDocumentPreparation.CopyPhrasesValidationDivMsg.FAGetText();
                         Support.AreEqual(validationMessgae3, "No 1:Success");
                         #endregion

                         FastDriver.NextGenDocumentPreparation.Open();
                         Reports.TestStep = "clicks on the Phrases Tab. ";
                         FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                         FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();


                         Reports.TestStep = " select same phrase type.";
                         FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                         if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                         { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i15").FASetCheckbox(true); }

                         FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClickAction(); Playback.Wait(3000);
                         if(FastDriver.NextGenDocumentPreparation.SelectAllPrase.IsDisplayed()) { FastDriver.NextGenDocumentPreparation.SelectAllPrase.FASetCheckbox(true); }
                         FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupPhraseCode.FASetText(ValidationGRP1 + "/" + validationPhrase1);
                         FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction();
                         Playback.Wait(4000);
                         var phraseDesctoValidate1 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetText();
                         Support.AreEqual(ValidationPhraseDesc1, phraseDesctoValidate1);

                 }



                 catch(Exception ex)
                 {
                       FailTest(GetExceptionInfo(ex));
                 }

           }
             #endregion


            #region  REG0012      Alternate Course 12: Move Phrases

            [TestMethod]
           public void    DPUC0005_REG0012()
           {
                 try
                 {
                       EnableSavingIRSamples();
                       SetSilverlightClipboardPermission_YES();
                       Reports.TestDescription = "Navigate to ADM site";
                       FAST_Login_ADM(isSuperUser: false);
                       FAST_OpenRegionOrOffice(officeId);


                       Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                       FastDriver.NextGenDocumentPreparation.Open();

                       #region Create new phrase group 1 with phrase
                       Reports.TestDescription = "Create new phrase group";
                       Reports.TestStep = "clicks on the Phrases Tab. ";
                       FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                       Reports.TestStep = "Create New PhraseGroup Tab";
                       FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                       Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                       Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       string Message_0 = "Phrase Group Name is required.";
                       FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_0);
                       Playback.Wait(4500);


                       Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                       string randomName = RandomString(4).ToUpper(); ;
                       FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                       var GRPname = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                        Reports.TestStep = "User selects phrase type.";
                       FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Endorsement Phrase[ENDORSE]");
                       var phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                       Reports.TestStep = "User enters a description.";
                       var groupDescription = "TEST--" + "ENDORSE--" + GRPname;
                       FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);


                       Reports.TestStep = "10.	User saves the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                       Reports.TestStep = "Verify System adds the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                       Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);


                       Reports.TestStep = "Adding a New phrase";
                       if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                       if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                       FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                       string RandomsName_1 = RandomString(4).ToUpper();
                       FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_1);
                       FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_1 + "--Phrase");
                       var phrase1 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);
                       var phrase1code = FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue();

                       Reports.TestStep = "click on EditPhraseGroup";
                       if(FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }

                       if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                       if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }

                       FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                       string RandomsName_2 = RandomString(4).ToUpper();
                       FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_2);
                       FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_2 + "--Phrase");
                       var phrase2 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                       var phrase2code = FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);

                       #endregion



                       #region Create new phrase group 2 with phrase
                       Reports.TestDescription = "Create new phrase group";
                       FastDriver.NextGenDocumentPreparation.Open();
                       Reports.TestStep = "clicks on the Phrases Tab. ";
                       FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                       Reports.TestStep = "Create New PhraseGroup Tab";
                       FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                       Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                       Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       string Message_1 = "Phrase Group Name is required.";
                       FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_1);
                       Playback.Wait(4500);


                       Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                       string randomName_1 = RandomString(4).ToUpper(); ;
                       FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName_1);
                       var GRPname_1 = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                       Reports.TestStep = "User selects phrase type.";
                       FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                       var phrasetype_1 = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                       Reports.TestStep = "User enters a description.";
                       var groupDescription_1 = "TEST--" + "TITLE--" + GRPname_1;
                       FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription_1);


                       Reports.TestStep = "10.	User saves the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                       Reports.TestStep = "Verify System adds the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                       Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);


                       Reports.TestStep = "Adding a New phrase";
                       if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                       if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                       FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                       string RandomsName_NEW1 = RandomString(4).ToUpper();

                       FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW1);
                       FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "TITLE--" + RandomsName_NEW1 + "--Phrase");
                       var phrase1_1 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);
                       var phrase1_1Code = FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue();

                       Reports.TestStep = "click on EditPhraseGroup";
                       if(FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }

                       if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                       if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }

                       FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                       string RandomsName_NEW2 = RandomString(4).ToUpper(); ;
                       FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_NEW2);
                       FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "TITLE--" + RandomsName_NEW2 + "--Phrase");
                       var phrase1_2 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);
                       var phrase1_2Code = FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue();
                       #endregion


                       FastDriver.NextGenDocumentPreparation.Open();
                       Reports.TestStep = "clicks on the Phrases Tab. ";
                       FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();

                       FastDriver.NextGenDocumentPreparation.CopyMovePhrases.FAClickAction();
                       Playback.Wait(3000);

                       if(!FastDriver.NextGenDocumentPreparation.MovePhrases.IsSelected())
                       { FastDriver.NextGenDocumentPreparation.MovePhrases.FAClickAction(); }

                       FastDriver.NextGenDocumentPreparation.CopyPhrasesBtn.FAClickAction();
                       Playback.Wait(5000);
                       Reports.TestStep = "Verify the validation Error when there are no phrase to copy";
                       var validationMSg = FastDriver.NextGenDocumentPreparation.CopyPhrasesValidationDivMsg.FAGetText();
                       Support.AreEqual(validationMSg, "No 1:Invalid From Phrase Group.");

                       Playback.Wait(6000);

                       #region Copy a Phrase from one gropp to another group
                       Reports.TestDescription = "Copy a Phrase from one group to another group ";
                       Reports.TestStep = "Select the region From where Phrase should copied";
                       FastDriver.NextGenDocumentPreparation.FirstFormRegion.FASelectItem("QA Sandpointe - Next Gen");
                       Reports.TestStep = "Select the phrase group From";
                       FastDriver.NextGenDocumentPreparation.CopyMoveFirstFormGroup.FASelectItem(GRPname);

                       Reports.TestStep = "select the phrase From Table List which have to copy";
                       FastDriver.NextGenDocumentPreparation.CopyMoveFirstFormPhraseCodeSelect.FAClickAction();
                       Playback.Wait(3000);
                       FastDriver.NextGenDocumentPreparation.CopyMoveSelectAPhrase.FASetCheckbox(true);
                       FastDriver.NextGenDocumentPreparation.CopyMoveSelectAPhrase_Done.FAClickAction();
                       Playback.Wait(2500);

                       Reports.TestStep = "Select the region where Phrase to be copied";
                       FastDriver.NextGenDocumentPreparation.CopyMoveFirsToRegion.FASelectItem("QA Sandpointe - Next Gen");
                       Reports.TestStep = "select the Phrase Group To";
                       FastDriver.NextGenDocumentPreparation.CopyMoveFirsToGroup.FASelectItem(GRPname_1);

                       Reports.TestStep = "Enter The Phrase Name which to be Move in name/code of";
                      
                       var ValidationGRP1 = FastDriver.NextGenDocumentPreparation.CopyMoveFirsToGroup.FAGetSelectedItem();
                       var validationFrOmPhrase1 = FastDriver.NextGenDocumentPreparation.CopyMoveFirstFormPhraseCode.FAGetValue();
                     
                       Reports.TestStep = "Move Phrase by click on MOve ";
                       FastDriver.NextGenDocumentPreparation.CopyPhrasesBtn.FAClickAction();
                       Playback.Wait(5000);

                       Reports.TestStep = "Verification of Copy Successfull.";
                       var validationMessgae1 = FastDriver.NextGenDocumentPreparation.CopyPhrasesValidationDivMsg.FAGetText();

                       Support.AreEqual(validationMessgae1, "No 1:Success");
                       #endregion

                       FastDriver.NextGenDocumentPreparation.Open();
                       Reports.TestStep = "clicks on the Phrases Tab. ";
                       FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();


                       Reports.TestStep = " select same phrase type.";
                       FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                       if(FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.XPath, "//div[@class='ddcl-listPanel2']").Enabled)
                       { FastDriver.NextGenDocumentPreparation.WebDriver.FAFindElement(ByLocator.Id, "ddcl-ddlPhraseTypes-i15").FASetCheckbox(true); }

                       FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClickAction(); Playback.Wait(3000);
                       if(FastDriver.NextGenDocumentPreparation.SelectAllPrase.IsDisplayed()) { FastDriver.NextGenDocumentPreparation.SelectAllPrase.FASetCheckbox(true); }

                       Reports.TestStep = "Enter the Phrase Group and Phrase name(from)";
                       FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupPhraseCode.FASetText(ValidationGRP1 + "/" + validationFrOmPhrase1);
                       FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClickAction();
                       Playback.Wait(4000);
                       var phraseDesctoValidate1 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                       Support.AreEqual(phrase1, phraseDesctoValidate1);
                      
                      
                 }

                 catch(Exception ex)
                 {
                       FailTest(GetExceptionInfo(ex));
                 }

           }

                 

            #endregion


               public string CreatePhrase_EndorseType()
               {

                      #region Create new phrase group 1 with phrase
                       Reports.TestDescription = "Create new phrase group";
                       Reports.TestStep = "clicks on the Phrases Tab. ";
                       FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();  //clicks on the Phrases Tab.  
                       FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                       Reports.TestStep = "Create New PhraseGroup Tab";
                       FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();    //Create New PhraseGroup Tab
                       Reports.TestStep = "4.	System displays the Phrase Group Maintenance screen";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName); // Phrase Group Maintenance screen.

                       Reports.TestStep = "Validate the message save the new phrase group creation instance when Phrase Group Name is blank.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       string Message_0 = "Phrase Group Name is required.";
                       FastDriver.NextGenDocumentPreparation.AcceptDialogAndCompareWith(CompareWith: Message_0);
                       Playback.Wait(4500);


                       Reports.TestStep = "5.	User enters a unique 4-character name for the new phrase group.";
                       string randomName = RandomString(4).ToUpper(); ;
                       FastDriver.NextGenDocumentPreparation.GroupName.FASetText(randomName);
                       string GRPname = FastDriver.NextGenDocumentPreparation.GroupName.FAGetValue();

                        Reports.TestStep = "User selects phrase type.";
                       FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Endorsement Phrase[ENDORSE]");
                       string phrasetype = FastDriver.NextGenDocumentPreparation.TypeSelect.FAGetSelectedItem();
                       Reports.TestStep = "User enters a description.";
                       string groupDescription = "TEST--" + "ENDORSE--" + GRPname;
                       FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);


                       Reports.TestStep = "10.	User saves the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);

                       Reports.TestStep = "Verify System adds the new phrase group.";
                       FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                       Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);


                       Reports.TestStep = "Adding a New phrase";
                       if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                       if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }
                       FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                       string RandomsName_1 = RandomString(4).ToUpper();
                       FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_1);
                       FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_1 + "--Phrase");
                       string phrase1 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);
                       string phrase1code = FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue();

                       Reports.TestStep = "click on EditPhraseGroup";
                       if(FastDriver.NextGenDocumentPreparation.EditPhraseGroup.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.EditPhraseGroup.FAClickAction(); }

                       if(FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.Exists() == true) { FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick(); }
                       if(FastDriver.NextGenDocumentPreparation.AddNewPhrase.IsDisplayed() == true) { FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem(); }

                       FastDriver.NextGenDocumentPreparation.PhrasePropertiestab.IsEnabled(); Playback.Wait(5000);
                       string RandomsName_2 = RandomString(4).ToUpper();
                       FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RandomsName_2);
                       FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("TEST--" + "ENDORSE--" + RandomsName_2 + "--Phrase");
                       string phrase2 = FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue();
                       FastDriver.NextGenDocumentPreparation.SaveButtom.FAClickAction();
                       string  phrase2code = FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FAGetValue();
                       FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false); Playback.Wait(5000);


                       return GRPname ;
                       return phrasetype;
                       return groupDescription;
                       return phrase1; return phrase1code; return phrase2; return phrase2code;

                       #endregion
               }





                 
















            #endregion

          

            [TestInitialize]
            public override void TestInitialize()
            {
                  CloseRelatedProcesses();
                  base.TestInitialize();
            }

            [ClassCleanup]
            public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
      }
}