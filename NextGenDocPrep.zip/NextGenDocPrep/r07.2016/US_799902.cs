﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Windows.Input;

namespace NextGenDocPrep.r07._2016
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_799902 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Template (if not already exit in environment)

            // TC784858 TestCase784858   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Escrow Instruction QA MJJP Test 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Escrow Instruction QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        
        [TestMethod]
        [DeploymentItem(@"Common\Support\Aks.PDF")]
        public void TestCase_800058()
        {
            try
            {
                Reports.TestDescription = "To verify forms is uploaded or not with correct Alignment";
                // Pre-Condition
                LoadTemplateOrCreateNew("TC784849", "TestCase784849", "Endorsement/Guarantee");

                #region 1. Login to ADM
                FAST_Login_ADM(isSuperUser: false);

                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region 2. Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                #endregion

                #region 3. Click on Forms tab and upload a form
                Reports.TestStep = "Click on Templates tab and search for the template";
                FastDriver.NextGenDocumentPreparation.FormsTab.FAClick();
                FastDriver.NextGenDocumentPreparation.AddNewForm.FAClick();
                FastDriver.NextGenDocumentPreparation.BrowseForm.FAClick();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\Aks.PDF");
                #endregion

                Playback.Wait(1000);
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }

        #region Private methods

        private void CreateDocumentFromTemplate(string templateName, string documentName = "")
        {
            Reports.TestStep = "Create a document: " + documentName;
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(templateName);
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

            Reports.TestStep = "Select the Document , Right-Click and select \"Create\" option from the context";
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", templateName, "Description", TableAction.GetCell).Element.FARightClick();
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

            if (FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists(5))
            {
                Reports.TestStep = "Select any policy document name from the list and click on \"Done\" button";
                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists(5);
                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(1, 1, TableAction.Click);
                //FastDriver.NextGenDocumentRepository.Dialog_Table.PerformTableAction(2, 1, TableAction.Click);
                //FastDriver.NextGenDocumentRepository.Dialog_Done.FAClick();
                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            }

            if (documentName != "")
            {
                Reports.TestStep = "Rename document";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", templateName, "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.EditDocumentName.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.EditDocument_DocumentName.FASetText(documentName);
                FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();
            }
            else
                documentName = templateName;

            Reports.TestStep = "Verify document creation"; // TODO: search actual Description column
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            var docs = FastDriver.NextGenDocumentRepository.DocumentsTable.GetAttribute("textContent");
            Support.AreEqual("True", docs.Contains(documentName).ToString(), "Document Table contains doc named: " + documentName);

        }

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        #endregion


        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }

    public class ImageBenchException : Exception, System.Runtime.Serialization.ISerializable
    {
        public ImageBenchException() : base() { }

        public ImageBenchException(string message) : base(message) { }

        public ImageBenchException(string format, params object[] args)
            : base(string.Format(format, args)) { }

        public ImageBenchException(string message, Exception innerException)
            : base(message, innerException) { }

        public ImageBenchException(string format, Exception innerException, params object[] args)
            : base(string.Format(format, args), innerException) { }
    }
}
