﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;

namespace NextGenDocPrep.r07._2016
{

    [CodedUITest]
    public class US_762214 : FASTHelpers
    {


        #region Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }
        #endregion


        [TestMethod]

        public void DOCGEN_01_Move_the_large_refresh_button_in_Phrase_View_screen()
        {
            try
            {
                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Create  a Document Document Repository
                Reports.TestStep = "Create  a Document Document Repository ";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(3, 1, TableAction.Click, "Title Reports").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();               
                #endregion

                #region Right Click Phrases View Edit Selected
                Reports.TestStep = "Right Click Phrases View Edit Selected";              
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhrasesViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion


                #region Click Refresh Button in Phrases Screen
                Reports.TestStep = "Click Refresh Button in Phrases Screen";
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.RefreshDocument.Highlight();
                FastDriver.NextGenDocumentRepository.RefreshDocument.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();  
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

            }





            catch (Exception ex)
            {
                FailTest(ex.Message);
            }


        }






        [ClassCleanup]
        public static void ClassCleanup()
        {
            FASTHelpers.CleanupClass();
        }

    }
}
