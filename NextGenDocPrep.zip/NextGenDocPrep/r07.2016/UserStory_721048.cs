﻿using FASTSelenium.Common;
using FASTSelenium.ImageRecognition;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Input;


namespace NextGenDocPrep.r07._2016
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class UserStory_721048 : FASTHelpers
    {
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Escrow Instruction QA MJJP Test 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateResultsTable);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction(5, "Escrow Instruction QA MJJP Test 1", 5, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.SwitchToContentFrame();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        #region templates

        //[TestMethod]
        //public void SAN_NEXTGEN_00_CreateTemplates()
        //{
        //    try
        //    {
        //        // set up data for use with Sanity test case:
        //        Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

        //        FAST_Login_ADM(isSuperUser: false);

        //        FAST_OpenRegionOrOffice(officeId);

        //        #region Navigate to NextGen Document Preparation Screen
        //        Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
        //        FastDriver.NextGenDocumentPreparation.Open();
        //        #endregion

        //        // *** Create Templates (if not already exit in environment)
        //        // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
        //        // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
        //        // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
        //        // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
        //        // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

        //        string[] templates = new string[5];
        //        templates[0] = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";
        //        templates[1] = "NEXTGEN_SAN_TitleReports_DoNotTouch";
        //        templates[2] = "NEXTGEN_SAN_LenderPolicy_DoNotTouch";
        //        templates[3] = "NEXTGEN_SAN_OwnerPolicy_DoNotTouch";
        //        templates[4] = "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch";

        //        string[] tempname = new string[5];
        //        tempname[0] = "SAN-NEXTGEN100";
        //        tempname[1] = "SAN-NEXTGEN200";
        //        tempname[2] = "SAN-NEXTGEN300";
        //        tempname[3] = "SAN-NEXTGEN400";
        //        tempname[4] = "SAN-NEXTGEN500";

        //        string[] temptype = new string[5];
        //        temptype[0] = "Escrow Instruction";
        //        temptype[1] = "Title Reports";
        //        temptype[2] = "Lender Policy";
        //        temptype[3] = "Owner Policy";
        //        temptype[4] = "Endorsement/Guarantee";

        //        int i = 0;
        //        for (i = 0; i < 5; i++)
        //        {
        //            Reports.TestStep = "Verify Sanity_Automation Templates are prensent or not";
        //            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
        //            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
        //            Reports.TestStep = "Search for template using template search criteria";
        //            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
        //            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templates[i]);
        //            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
        //            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
        //            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
        //            if (!templateTable.Contains(templates[i]))
        //            {
        //                //create / copy template

        //                Reports.TestStep = "Creating Automation Template" + templates[i] + "required for Sanity";
        //                FastDriver.NextGenDocumentPreparation.Open();
        //                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
        //                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
        //                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
        //                Reports.TestStep = "Search for template using template search criteria";
        //                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
        //                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
        //                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Escrow Instruction QA MJJP Test 1");
        //                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
        //                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction(2, 5, TableAction.Click).Element.FARightClick();
        //                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
        //                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[i]);
        //                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[i]);
        //                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[i]);
        //                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
        //                FastDriver.NextGenDocumentPreparation.Save.FAClick();
        //                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
        //                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
        //                Playback.Wait(1000);
        //                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
        //                FastDriver.NextGenDocumentPreparation.Open();
        //            }
        //            else
        //            {
        //                Reports.StatusUpdate("Template: " + templates[i] + " already exist", true);
        //            }
        //        }

        //        // TODO: Modify Templates: 
        //        // NEXTGEN_SAN_EscrowInstruction_DoNotTouch
        //        //  add data element=> BUFNAM   Buyer: Name-First Name *
        //        //  add phrase =>  ENC2/249 - Address

        //        // NEXTGEN_SAN_TitleReports_DoNotTouch
        //        // add data elements: Seller First Name, SEFNAM



        //        // TODO: Create Phrases
        //        // NEXTGEN-SAN-ExceptionPhrase-DoNotTouch, type: Exception Phrase[EXCEPTION]   *** for test case 21

        //        // NEXTGEN-SAN-EscrowPhrase-DoNotTouch, type: Escrow Phrase  *** test case13 with data element\


        //    }
        //    catch (Exception ex)
        //    {
        //        FailTest(GetExceptionInfo(ex));
        //    }
        //}

        #endregion

        [TestMethod]
        public void TestCase_796708()
        {
            try
            {
                LoadTemplateOrCreateNew("TC796708", "TestCase796708", "Escrow Instruction");

                #region Login to FAST IIS side and create a basic file
                Reports.TestStep = "Login to FAST IIS side and Create a basic file";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document from template search
                Reports.TestStep = "Add any document from template search";
                CreateDocumentFromTemplate("TestCase796708", "TC796708");

                #endregion

                #region Perform image Doc for the document twice

                Reports.TestStep = "Perform image Doc for the document twice";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796708", "Name", TableAction.GetCell).Element.FARightClick();
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.BuyerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796708", "Name", TableAction.GetCell).Element.FARightClick();
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);

                #endregion

                #region Click on icon to expand

                Reports.TestStep = "Click on icon to expand";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                //click on image icon ImageVersionIcon
                //FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796754", "Name", TableAction.GetCell).Element.FAClick();

                int row = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796708", "Name", TableAction.Click).CurrentRow;
                row = row + 2;
                FastDriver.NextGenDocumentRepository.VersionIcon.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                #endregion

                #region Select second imaged document  and double click on top of it to change type and name in Document Repository screen

                Reports.TestStep = "Select second imaged document  and double click on top of it to change type and name in Document Repository screen";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(row, 7, TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ChangeType.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Change document type (ex. Change to Exchange Reverse)  and Document name and click away

                Reports.TestStep = "Change document type (ex. Change to Exchange Reverse)  and Document name and click away";
                FastDriver.NextGenDocumentRepository.ChangeType_DocumentName.FASetText("TC796708_ChangedName");
                string Changed_SecondDocumentName = FastDriver.NextGenDocumentRepository.ChangeType_DocumentName.FAGetText();
                FastDriver.NextGenDocumentRepository.ChangeType_DocumentType.FASelectItem("Miscellaneous");
                string Changed_SecondDocumentType = FastDriver.NextGenDocumentRepository.ChangeType_DocumentType.FAGetText();
                FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();

                #endregion

                #region Click on collapse/expand icon
                Reports.TestStep = "Click on collapse/expand icon";
                int row1 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796708", "Name", TableAction.Click).CurrentRow;
                row1 = row1 + 2;
                FastDriver.NextGenDocumentRepository.VersionIcon.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Miscellaneous", "Type", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ChangeType.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string Changed_FirstDocumentName = FastDriver.NextGenDocumentRepository.ChangeType_DocumentName.FAGetText();
                string Changed_FirstDocumentType = FastDriver.NextGenDocumentRepository.ChangeType_DocumentType.FAGetText();
                FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();

                if ((Changed_FirstDocumentName == Changed_SecondDocumentName) && (Changed_FirstDocumentType == Changed_SecondDocumentType))
                {
                    Reports.StatusUpdate("Same change reflected in both Imaged Document.", true);
                }
                else
                {
                    Reports.StatusUpdate("Same change NOT reflected in both Imaged Document!", false);
                }
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            
        }

        [TestMethod]
        public void TestCase_796723()
        {
            try
            {
                LoadTemplateOrCreateNew("TC796723", "TestCase796723", "Escrow Instruction");

                #region Login to FAST IIS side and create a basic file
                Reports.TestStep = "Login to FAST IIS side and Create a basic file";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document from template search
                Reports.TestStep = "Add any document from template search";
                CreateDocumentFromTemplate("TestCase796723", "TC796723");

                #endregion

                #region Perform image Doc for the document twice

                Reports.TestStep = "Perform image Doc for the document twice";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796723", "Name", TableAction.GetCell).Element.FARightClick();
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                //FastDriver.ImageDocDlg.BuyerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796723", "Name", TableAction.GetCell).Element.FARightClick();
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                //FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);

                #endregion

                #region Click on icon to expand

                Reports.TestStep = "Click on icon to expand";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                //click on image icon ImageVersionIcon
                //FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796754", "Name", TableAction.GetCell).Element.FAClick();

                int row = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796723", "Name", TableAction.Click).CurrentRow;
                row = row + 2;
                FastDriver.NextGenDocumentRepository.VersionIcon.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();

                #endregion

                #region Select second imaged document  and right click for Change type dialog

                Reports.TestStep = "Select first imaged document  and right click for Change type dialog";
                //select 2nd imaged document

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(row, 7, TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ChangeType.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion

                #region Change document type (ex. Change to Exchange Reverse)  and Document name and Additional information

                Reports.TestStep = "Change document type (ex. Change to Exchange Reverse)  and Document name and Additional information";
                FastDriver.NextGenDocumentRepository.ChangeType_DocumentName.FASetText("TC796723_ChangedName");
                string Changed_SecondDocumentName = FastDriver.NextGenDocumentRepository.ChangeType_DocumentName.FAGetText();
                FastDriver.NextGenDocumentRepository.ChangeType_DocumentType.FASelectItem("Miscellaneous");
                string Changed_SecondDocumentType = FastDriver.NextGenDocumentRepository.ChangeType_DocumentType.FAGetText();
                FastDriver.NextGenDocumentRepository.ChangeType_Comments.FASetText("TC796723 Imaged Document name is changed for the first document.");
                string Changed_SecondComments = FastDriver.NextGenDocumentRepository.ChangeType_Comments.FAGetText();
                FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();

                #endregion

                #region Click on collapse/expand icon
                Reports.TestStep = "Click on collapse/expand icon";
                int row1 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796723", "Name", TableAction.Click).CurrentRow;
                row1 = row1 + 2;
                FastDriver.NextGenDocumentRepository.VersionIcon.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Miscellaneous", "Type", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ChangeType.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string Changed_FirstDocumentName = FastDriver.NextGenDocumentRepository.ChangeType_DocumentName.FAGetText();
                string Changed_FirstDocumentType = FastDriver.NextGenDocumentRepository.ChangeType_DocumentType.FAGetText();
                string Changed_FirstComments = FastDriver.NextGenDocumentRepository.ChangeType_Comments.FAGetText();
                FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();

                if ((Changed_FirstDocumentName == Changed_SecondDocumentName) && (Changed_FirstDocumentType == Changed_SecondDocumentType) && (Changed_FirstComments == Changed_SecondComments))
                {
                    Reports.StatusUpdate("Same change reflected in both Imaged Document.", true);
                }
                else
                {
                    Reports.StatusUpdate("Same change NOT reflected in both Imaged Document!", false);
                }
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        public void TestCase_796753() 
        {
            try 
            { 
            LoadTemplateOrCreateNew("TC796753", "TestCase796753", "Escrow Instruction");

            #region Login to FAST IIS side and create a basic file
            Reports.TestStep = "Login to FAST IIS side and Create a basic file";
            FAST_Login_IIS(regionId: regionId);
            FAST_OpenRegionOrOffice(officeId);
            Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
            #endregion

            #region Navigate to Document Repository
            Reports.TestStep = "Navigate to Document Repository";
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.NextGenDocumentRepository.Open();
            #endregion

            #region Add any document from template search
            Reports.TestStep = "Add any document from template search";
            CreateDocumentFromTemplate("TestCase796753", "TC796753");

            #endregion

            #region Perform image Doc for the document twice

            Reports.TestStep = "Perform image Doc for the document twice";
            FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796753", "Name", TableAction.GetCell).Element.FARightClick();
            //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
            FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
            FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc.JSClick();
            //
            FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
            FastDriver.ImageDocDlg.WaitForScreenToLoad();
            //FastDriver.ImageDocDlg.BuyerSignature.FASetCheckbox(true);
            FastDriver.ImageDocDlg.ImageDoc.FAClick();
            FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);

            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.NextGenDocumentRepository.Open();
            FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796753", "Name", TableAction.GetCell).Element.FARightClick();
            //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
            FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
            FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc.JSClick();
            //
            FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
            FastDriver.ImageDocDlg.WaitForScreenToLoad();
            //FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
            FastDriver.ImageDocDlg.ImageDoc.FAClick();
            FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);

            #endregion

            #region Click on icon to expand

            Reports.TestStep = "Click on icon to expand";
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.NextGenDocumentRepository.Open();
            //click on image icon ImageVersionIcon
            //FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796754", "Name", TableAction.GetCell).Element.FAClick();

            int row = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796753", "Name", TableAction.Click).CurrentRow;
            row = row + 2;
            FastDriver.NextGenDocumentRepository.VersionIcon.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.NextGenDocumentRepository.SwitchToContentFrame();

            #endregion

            #region Select first imaged document  and double click on top of it to change type and name in Document Repository screen

            Reports.TestStep = "Select first imaged document  and right click for Change type dialog";
            FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Imaged Document", "Type", TableAction.GetCell).Element.FARightClick();
            FastDriver.NextGenDocumentRepository.ChangeType.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

            #endregion

            #region Change document type (ex. Change to Exchange Reverse)  and Document name and click away
            Reports.TestStep = "Change document type (ex. Change to Exchange Reverse)  and Document name and Additional information";
            FastDriver.NextGenDocumentRepository.ChangeType_DocumentName.FASetText("TC796753_ChangedName");
            string Changed_FirstDocumentName = FastDriver.NextGenDocumentRepository.ChangeType_DocumentName.FAGetText();
            FastDriver.NextGenDocumentRepository.ChangeType_DocumentType.FASelectItem("Miscellaneous");
            string Changed_FirstDocumentType = FastDriver.NextGenDocumentRepository.ChangeType_DocumentType.FAGetText();
            FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();
            #endregion

            #region Click on collapse/expand icon
            Reports.TestStep = "Click on collapse/expand icon";
            int row1 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796753", "Name", TableAction.Click).CurrentRow;
            row1 = row1 + 2;
            FastDriver.NextGenDocumentRepository.VersionIcon.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.NextGenDocumentRepository.SwitchToContentFrame();

            FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(row, 7, TableAction.GetCell).Element.FARightClick();
            FastDriver.NextGenDocumentRepository.ChangeType.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            string Changed_SecondDocumentName = FastDriver.NextGenDocumentRepository.ChangeType_DocumentName.FAGetText();
            string Changed_SecondDocumentType = FastDriver.NextGenDocumentRepository.ChangeType_DocumentType.FAGetText();
            FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();

            if ((Changed_FirstDocumentName == Changed_SecondDocumentName) && (Changed_FirstDocumentType == Changed_SecondDocumentType))
            {
                Reports.StatusUpdate("Same change reflected in both Imaged Document.", true);
            }
            else
            {
                Reports.StatusUpdate("Same change NOT reflected in both Imaged Document!", false);
            }
            #endregion

            #region Click on collapse/expand icon
            Reports.TestStep = "Click on collapse/expand icon";
            #endregion

        }
        catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void TestCase_796754()
        {
            try
            {
                LoadTemplateOrCreateNew("TC796754", "TestCase796754", "Escrow Instruction");

                #region Login to FAST IIS side and create a basic file

                Reports.TestStep = "Login to FAST IIS side and Create a basic file";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #endregion

                #region Navigate to Document Repository

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();

                #endregion

                #region Add any document from template search

                Reports.TestStep = "Add any document from template search";
                CreateDocumentFromTemplate("TestCase796754", "TC796754");

                #endregion

                #region Perform image Doc for the document twice

                Reports.TestStep = "Perform image Doc for the document twice";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796754", "Name", TableAction.GetCell).Element.FARightClick();
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                //FastDriver.ImageDocDlg.BuyerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796754", "Name", TableAction.GetCell).Element.FARightClick();
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                //FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);

                #endregion

                #region Click on icon to expand

                Reports.TestStep = "Click on icon to expand";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                //click on image icon ImageVersionIcon
                //FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796754", "Name", TableAction.GetCell).Element.FAClick();

                int row = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796754", "Name", TableAction.Click).CurrentRow;
                row = row + 2;
                FastDriver.NextGenDocumentRepository.VersionIcon.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();

                #endregion

                #region Select first imaged document  and right click for Change type dialog

                Reports.TestStep = "Select first imaged document  and right click for Change type dialog";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Imaged Document", "Type", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ChangeType.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                //FastDriver.NextGenDocumentRepository.DocumentsTable.
                #endregion

                #region Change document type (ex. Change to Exchange Reverse)  and Document name and Additional information
                Reports.TestStep = "Change document type (ex. Change to Exchange Reverse)  and Document name and Additional information";
                FastDriver.NextGenDocumentRepository.ChangeType_DocumentName.FASetText("TC796754_ChangedName");
                string Changed_FirstDocumentName = FastDriver.NextGenDocumentRepository.ChangeType_DocumentName.FAGetText();
                FastDriver.NextGenDocumentRepository.ChangeType_DocumentType.FASelectItem("Miscellaneous");
                string Changed_FirstDocumentType = FastDriver.NextGenDocumentRepository.ChangeType_DocumentType.FAGetText();
                FastDriver.NextGenDocumentRepository.ChangeType_Comments.FASetText("TC796754 Imaged Document name is changed for the first document.");
                string Changed_FirstComments = FastDriver.NextGenDocumentRepository.ChangeType_Comments.FAGetText();
                FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();
                #endregion

                #region Click on collapse/expand icon
                Reports.TestStep = "Click on collapse/expand icon";
                int row1 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "TC796754", "Name", TableAction.Click).CurrentRow;
                row1 = row1 + 2;
                FastDriver.NextGenDocumentRepository.VersionIcon.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(row, 7, TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ChangeType.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string Changed_SecondDocumentName = FastDriver.NextGenDocumentRepository.ChangeType_DocumentName.FAGetText();
                string Changed_SecondDocumentType = FastDriver.NextGenDocumentRepository.ChangeType_DocumentType.FAGetText();
                string Changed_SecondComments = FastDriver.NextGenDocumentRepository.ChangeType_Comments.FAGetText();
                FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();

                if ((Changed_FirstDocumentName == Changed_SecondDocumentName) && (Changed_FirstDocumentType == Changed_SecondDocumentType) && (Changed_FirstComments == Changed_SecondComments))
                {
                    Reports.StatusUpdate("Same change reflected in both Imaged Document.", true);
                }
                else
                {
                    Reports.StatusUpdate("Same change NOT reflected in both Imaged Document!", false);
                }
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        #region Private methods

        private void CreateDocumentFromTemplate(string templateName, string documentName = "")
        {
            Reports.TestStep = "Create a document: " + documentName;
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FADoubleClick();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(templateName);
            FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

            Reports.TestStep = "Select the Document , Right-Click and select \"Create\" option from the context";
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", templateName, "Description", TableAction.GetCell).Element.FARightClick();
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

            if (FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists(5))
            {
                Reports.TestStep = "Select any policy document name from the list and click on \"Done\" button";
                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists(5);
                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            }

            if (documentName != "")
            {
                Reports.TestStep = "Rename document";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", templateName, "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.EditDocumentName.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.EditDocument_DocumentName.FASetText(documentName);
                FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();
            }
            else
                documentName = templateName;

            Reports.TestStep = "Verify document creation"; // TODO: search actual Description column
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            var docs = FastDriver.NextGenDocumentRepository.DocumentsTable.GetAttribute("textContent");
            Support.AreEqual("True", docs.Contains(documentName).ToString(), "Document Table contains doc named: " + documentName);

        }

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        #endregion

        private void CloseRelatedProcesses()
        {
            Support.CloseAllProcessStartingWith("AcroRd");
            Support.CloseAllProcessStartingWith("iexplore");
            Support.CloseAllProcessStartingWith("IEDriverServer");
        }

        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}

