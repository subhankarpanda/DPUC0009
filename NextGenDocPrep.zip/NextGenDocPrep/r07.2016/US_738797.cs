﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;

namespace NextGenDocPrep.r07._2016
{
    [CodedUITest]
    public class US_738797 : FASTHelpers
    {

         #region Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }
        #endregion


        [TestMethod]

        public void DocGen_01_To_Verify_functional_Copy_Documents_Button()
        {
            try
            {
                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Select Search Scope Dropdown Documents
                Reports.TestStep = "Select Search Scope Dropdown Documents";
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FASelectItem("File #");
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FASendKeys("1370");
                FastDriver.NextGenDocumentRepository.FindNow.FAClick();
                #endregion

                #region Verify New Copy Button Documents 
                Reports.TestStep = "Verify New Copy Button Documents  ";
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.SelectDocumetcopy.FAClick();
                FastDriver.NextGenDocumentRepository.CopyButton.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();              
                FastDriver.NextGenDocumentRepository.CancelButton.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FileDocumentsTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.TableResults.StringExistOnTable("((00)) A 5/17 Versioning Test").ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Verify Document", false, 30);

                #endregion

                #region   Select Search Scope Dropdown Documents 
                Reports.TestStep = "Select Search Scope Dropdown Documents";
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FASelectItem("File #");
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FASendKeys("1370");
                FastDriver.NextGenDocumentRepository.FindNow.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Verify New Copy Option Drop Down 
                Reports.TestStep = "Verify New Copy Button Documents  ";
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.SelectDocumetcopy.FARightClick();
                FastDriver.NextGenDocumentRepository.CopyFile.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();              
                FastDriver.NextGenDocumentRepository.CancelButton.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FileDocumentsTab.FAClick();
                Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.TableResults.StringExistOnTable("((00)) A 5/17 Versioning Test").ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Verify Document", false, 30);
                #endregion

              


            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]

        public void DocGen_02_To_Verify_functional_Copy_All_documents_Button()
        {
            try
            {
                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Right Click on a table row using Document Name
                Reports.TestStep = "Perform Right Click on a table row using Document Name";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(3, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Select Search Scope Dropdown Documents
                Reports.TestStep = "Select Search Scope Dropdown Documents";
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FASelectItem("File #");
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FASendKeys("1370");
                FastDriver.NextGenDocumentRepository.FindNow.FAClick();
                #endregion

                #region Verify New Copy All Button Documents
                Reports.TestStep = "Verify New Copy Button Documents  ";
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.SelectDocumetcopy.FAClick();
                FastDriver.NextGenDocumentRepository.CopyAllButton.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.CancelButton.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FileDocumentsTab.FAClick();
                #endregion

                #region   Select Search Scope Dropdown Documents
                Reports.TestStep = "Select Search Scope Dropdown Documents";
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FASelectItem("File #");
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FASendKeys("1370");
                FastDriver.NextGenDocumentRepository.FindNow.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Verify New Copy All option Drop Down
                Reports.TestStep = "Verify New Copy All option Drop Down";
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.SelectDocumetcopy.FARightClick();
                FastDriver.NextGenDocumentRepository.CopyallFile.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.CancelButton.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FileDocumentsTab.FAClick();
                #endregion




            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]

        public void DocGen_03_To_Verify_functional_Preview_documents_Button()
        {
            try
            {
                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Right Click on a table row using Document Name
                Reports.TestStep = "Perform Right Click on a table row using Document Name";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(3, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Select Search Scope Dropdown Documents
                Reports.TestStep = "Select Search Scope Dropdown Documents";
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FASelectItem("File #");
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FASendKeys("1370");
                FastDriver.NextGenDocumentRepository.FindNow.FAClick();
                #endregion

                #region Verify New Preview Button Documents
                Reports.TestStep = "Verify New Preview Button Documents";
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.SelectDocumetcopy.FAClick();
                FastDriver.NextGenDocumentRepository.PreviewButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 300);
                FastDriver.WebDriver.ClosePreviewWindow();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.CancelButton.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FileDocumentsTab.FAClick();
                #endregion

                #region   Select Search Scope Dropdown Documents
                Reports.TestStep = "Select Search Scope Dropdown Documents";
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FASelectItem("File #");
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FASendKeys("1370");
                FastDriver.NextGenDocumentRepository.FindNow.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Verify New Preview option Drop Down
                Reports.TestStep = "Verify New Preview option Drop Down";
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.SelectDocumetcopy.FARightClick();
                FastDriver.NextGenDocumentRepository.Preview.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 300);
                FastDriver.WebDriver.ClosePreviewWindow();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.CancelButton.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FileDocumentsTab.FAClick();
                #endregion




            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }



        [TestMethod]

        public void DocGen_04_To_Verify_Done_Button_Mustnt_Be_Appear()
        {
            try
            {
                #region DataSetup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Right Click on a table row using Document Name
                Reports.TestStep = "Perform Right Click on a table row using Document Name";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(3, 1, TableAction.Click, "Escrow Instruction").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Select Search Scope Dropdown Documents
                Reports.TestStep = "Select Search Scope Dropdown Documents";
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_TheFile_File.FASelectItem("File #");
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FAClick();
                FastDriver.NextGenDocumentRepository.SearchScope_UserFileNumber.FASendKeys("1370");
                FastDriver.NextGenDocumentRepository.FindNow.FAClick();
                #endregion

                #region Verify Done Button Mustnt Be Appear
                Reports.TestStep = "Verify Done Button Mustnt Be Appear";
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.SelectDocumetcopy.FAClick();                         
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.CancelButton.FAClick();                
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
               
                #endregion                               



            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }


            
        [ClassCleanup]
        public static void ClassCleanup()
        {
            FASTHelpers.CleanupClass();
        }

    }
}
