﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Input;



namespace NextGenDocPrep
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class NextGen_DPUC0009 : FASTHelpers
    {
        private static int _regionId = 12837;
        private static int _officeId = 12839;

        #region Private methods
        private int regionId
        {
            get { return _regionId; }
        }
        private int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            try
            {
                Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                // *** Create Templates (if not already exit in environment)
                // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
                // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
                // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
                // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
                // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

                #region Verify that Sanity_Automation Template is present
                Reports.TestStep = "Check Sanity_Automation Template is present";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);

                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                var templateExists = templateTable.Contains(templateDesc);
                #endregion

                if (!templateExists)
                {
                    Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                    FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                    FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                    Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                }
                else
                {
                    Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
                }
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }

        }

        private int CreateDocumentusingWCFService(int DocTemplateTypeId, string DocName)
        {
            var GetDocTempReq = RequestFactory.GetDocTemplateRequest(DocTemplateTypeId, regionId);
            var GetDocTempRes = FASTWCFHelpers.FileService.GetDocTemplates(GetDocTempReq);
            int index;
            for (index = 0; index < GetDocTempRes.Templates.Length - 1; index++)
            {
                if (GetDocTempRes.Templates[index].Descr.Contains(DocName))
                {
                    break;
                }
            }
            int templateID = Convert.ToInt32(GetDocTempRes.Templates[index].TemplateID);

            var CreateDocReq = RequestFactory.GetCreateDocumentDefaultRequest(File.FileID ?? 0, templateID);
            CreateDocReq.TitleReportDocumentID = 0;

            var CreateDocRes = FASTWCFHelpers.FileService.CreateDocument(CreateDocReq);

            return Convert.ToInt32(CreateDocRes.DocumentID);
        }

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        private void InsertDataElement()
        {
            FastDriver.DocumentEditor.InsertDataElement();
        }

        private void InsertPhrase(string tplPhraseName, string phraseDescription)
        {
            FastDriver.DocumentEditor.InsertPhraseBelowAndSave(tplPhraseName, phraseDescription);
        }

        private void Phrase_phraseGrp_Template(string phraseGrp_Name, string phrase_Type, string templateName, string templateDescription, string templateType)
        {
            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Verify that if Template is present
            Reports.TestStep = "Check if Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);

            //FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("TEST-Template-" + Support.RandomString(templateDescription.Repeat(2)));

            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDescription);

            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDescription);
            #endregion

            if (!templateExists)
            {
                #region Create new phrase group

                FastDriver.NextGenDocumentPreparation.Open();
                Reports.TestStep = "Create new phrase group";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);


                var groupName = Support.RandomString(phraseGrp_Name);

                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);


                var groupDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));

                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);

                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem(phrase_Type);
                FastDriver.NextGenDocumentPreparation.SaveButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                #endregion

                #region Add phrases
                Reports.TestStep = "Add phrases";
                FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);

                var phraseName = Support.RandomString(phraseGrp_Name);

                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);

                var phraseDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));

                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);

                FastDriver.NextGenDocumentPreparation.SaveButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                #endregion

                #region Insert phrases
                Reports.TestStep = "Insert phrases";
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertDataElement();

                //this.InsertPhrase(phraseName, phraseDescription);


                #endregion

                #region Create template

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Create a new template";


                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();


                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                templateName = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(4));
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                templateDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(26));

                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText("TEST-Template-" + Support.RandomString(templateDescription.Repeat(2)));

                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                #endregion

                #region Insert template
                Reports.TestStep = "Insert template";
                FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertPhrase(groupName + "/" + phraseName, phraseDescription);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion








            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDescription + " already exist", true);
            }


                #endregion

        }

        public static void MouseHoverOnObject(IWebElement TargetElement)
        {

            string javaScript = "var evObj = document.createEvent('MouseEvents');" +
                                "evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);" +
                                "arguments[0].dispatchEvent(evObj);";
            IJavaScriptExecutor js = FastDriver.WebDriver as IJavaScriptExecutor;
            js.ExecuteScript(javaScript, TargetElement);
        }


        public void CreateAssociatePackageNRemove(string TempSearchKeywprd, string Temp1, string Temp2)
        {
            #region Navigate to Document Repository Screen
            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.NextGenDocumentRepository.Open();
            #endregion

            #region Search a template
            Reports.TestStep = "Search Template by click on search button";
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").Highlight();
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").FAClick();
            //  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            #endregion


            #region Search for templates using search criteria
            Reports.TestStep = "Search for templates using search criteria(with all fiter and title reports)";
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            // FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
            // FastDriver.NextGenDocumentRepository.SearchScope.FindElement(By.Id("ddTemplTypes")).FASelectItem("Title Reports");
            FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FAFindElement(ByLocator.Id, "ddcl-ddl_sources").FADoubleClick();
            FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
            FastDriver.NextGenDocumentRepository.QASandpoint.FASetCheckbox(true);

            FastDriver.NextGenDocumentRepository.TemplateDescription.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_ALL_0.FASetCheckbox(true);
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempSearchKeywprd);
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            #endregion
            //  TempSearchKeywprd =  NEXTGEN_SAN*   /     NEXTGEN_SAN_TitleReports_DoNotTouch   NEXTGEN_SAN_EscrowInstruction_DoNotTouch       NEXTGEN_SAN_EscrowInstruction_DoNotTouch
            // Temp1 =     NEXTGEN_SAN_TitleReports_DoNotTouch  
            //Temp 2 =  NEXTGEN_SAN_EscrowInstruction_DoNotTouch
            // Temp3 = NEXTGEN_SAN_EscrowInstruction_DoNotTouch

            var documents_1 = new List<string> { TempSearchKeywprd };
            FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents_1);

            #region  Right Click
            Reports.TestStep = "Hold Right Click";
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", Temp1, "Description", TableAction.GetCell).Element.FARightClick();
            #endregion

            #region Select "Create Document" option
            Reports.TestStep = "Select Create Document option from the context menu";
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            #endregion

            #region Navigate to Document Repository Scree--1
            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.NextGenDocumentRepository.Open();
            #endregion

            #region Click on "Template Search" button      --1
            Reports.TestStep = "Click on \"Template Search\" button";
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").Highlight();
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").FAClick();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            #endregion

            #region Search for templates using search criteria         --1
            Reports.TestStep = "Search for templates using search criteria";
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TempSearchKeywprd);
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            #endregion

            #region Select a template by using "Ctrl" command     --1
            Reports.TestStep = "Select one template by using \"Ctrl\" command";
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            var documentsnew = new List<string> { Temp2 };
            FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documentsnew);
            #endregion

            #region Hold Right Click   --1
            Reports.TestStep = "Hold Right Click";
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", Temp2, "Description", TableAction.GetCell).Element.FARightClick();
            #endregion

            #region Select "Create Document" option    --1
            Reports.TestStep = "Select \"Create Document\" option";
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            #endregion

            #region Select Multiple templates (2 or more) by using "Ctrl" command
            Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
            //      FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            var documents3 = new List<string> { Temp1, Temp2 };
            FastDriver.NextGenDocumentRepository.SelectAllDocuments();
            //FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents3);
            #endregion

            #region   "Highlight two or more documents and Right Click"
            Reports.TestStep = "Highlight two or more documents and Right Click";
            FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", Temp2, "Name", TableAction.GetCell).Element.FARightClick();
            #endregion

            #region    Click on "Add to Associate Package and MOdify it"
            Reports.TestStep = "Click on Add to Associate Package";
            FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

            if (FastDriver.NextGenDocumentRepository.AssociatePackages.Exists() == true)
            { FastDriver.NextGenDocumentRepository.AssociatePackages.FAClick(); }

            Reports.TestStep = "Modify the name of  Associate Package";
            FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("Modified-associated-Package0");
            FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();
            #endregion

            #region Click on "OK" button in the Alert Message box
            string Message = "new modified pakcage";
            string mesg1 = "Package : " + "'" + Message + "'" + " created successfully.";
            Support.AreEqual(mesg1, "Package : 'new modified pakcage' created successfully.");
            Reports.TestStep = "Click on ok";
            FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
            Playback.Wait(5000);
            #endregion

            #region Select the package created in the above steps and verify the documents
            Reports.TestStep = "Select the package created in the above steps and verify the documents";
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            var package = FastDriver.NextGenDocumentRepository.FindAssociatePackage(Temp1);
            var packageContent = package.GetAttribute("textContent");
            Support.AreEqual("True", packageContent.Contains("NEXTGEN_SAN_TitleReports_DoNotTouch").ToString(), "Package contains Modified-associated-Package0");

            package = FastDriver.NextGenDocumentRepository.FindAssociatePackage(Temp1, true);
            #endregion


            #region      If package has minimum of three documents ,user optionally highlights a document Right click and clicks the Remove button.

            Reports.TestStep = "Right click on Remove.";
            if (packageContent.Contains("NEXTGEN_SAN_TitleReports_DoNotTouch"))
            {
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle1.Highlight(10);
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle1.FARightClick();
            }


            FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Remove.Highlight();
            FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Remove.FADoubleClick();
            #endregion

            #region "System displays the Remove Document Association confirmation message.".

            Reports.TestStep = "Verify System displays the Remove Document Association confirmation message. ";
            string Message_1 = "Remove 'NEXTGEN_SAN_LenderPolicy_DoNotTouch' from 'Modified-associated-Package0' ?";
            FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message_1);
            Playback.Wait(6000);
            //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            Support.MessageHandler(true);
            #endregion

        }

        #endregion

        #region REG

        #region REG0001
        [TestMethod]
        [Description("MainFlow: Create a Document (other than a Title Report, Policy, or Endorsement)")]
        public void REG0001()
        {
            try
            {
                Reports.TestDescription = "MainFlow: Create a Document (other than a Title Report, Policy, or Endorsement)";

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                CloseRelatedProcesses();

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", documentName: "NO Title Report, Policy, or Endorsement");

                Reports.TestStep = "Verify the Escrow Instruction document is created";
                FastDriver.NextGenDocumentRepository.Open();
                Support.AreEqual("Escrow Instruction", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NO Title Report, Policy, or Endorsement", "Type", TableAction.GetText).Message);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region REG0002
        [TestMethod]
        [Description("Alternate Course 1:  Add Ad-Hoc Document")]
        public void REG0002()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 1:  Add Ad-Hoc Document";

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                CloseRelatedProcesses();

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                FastDriver.NextGenDocumentRepository.Open();
                var filters = new KeyValuePair<string, string>[] { 
                    new KeyValuePair<string, string>("Source", "Corporate,Region"),
                    new KeyValuePair<string, string>("State", "CA")
                };
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", documentName: "Accomm Signing-Customer Buyer", filters: filters);

                Reports.TestStep = "Verify the Escrow Instruction document is created";
                FastDriver.NextGenDocumentRepository.Open();
                Support.AreEqual("Escrow Instruction", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Accomm Signing-Customer Buyer", "Type", TableAction.GetText).Message);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region REG0003
        [TestMethod]
        [Description("Alternate Course 2:  Create a Document Containing Multi-Entity Data Element")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0003()
        {
            try
            {
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Alternate Course 2:  Create a Document Containing Multi-Entity Data Element";

                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create new phrase group
                Reports.TestStep = "Create new phrase group";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                var groupName = Support.RandomString("ANAN");
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);
                var groupDescription = "TEST--" + Support.RandomString("AN".Repeat(17));
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Title Phrase[TITLE]");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                #endregion

                #region Add phrases
                Reports.TestStep = "Add phrases";
                FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                var phraseName = Support.RandomString("ANAN");
                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);
                var phraseDescription = "TEST--" + Support.RandomString("AN".Repeat(17));
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                #endregion

                #region Insert phrases
                Reports.TestStep = "Insert phrases";
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertDataElement();
                #endregion

                #region Create template
                Reports.TestStep = "Create template";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                var templateName = "TEST--" + Support.RandomString("AN".Repeat(4));
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                var templateDescription = "TEST--" + Support.RandomString("AN".Repeat(26));
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDescription);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                #endregion

                #region Insert template
                Reports.TestStep = "Insert template";
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertPhrase(groupName + "/" + phraseName, phraseDescription);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status") == "true")
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    // just to make sure !
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                    FastDriver.NextGenDocumentPreparation.Inactive.FAClick();
                    FastDriver.NextGenDocumentPreparation.Active.FAClick();
                }
                Support.AreEqual("false", FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status"));
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                Reports.TestStep = "Login to FAST IIS";
                FAST_Login_IIS();
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFileWithNewLoan() || FAST_CreateFile(), "File created successfully");

                #region Preview document
                Reports.TestStep = "Preview document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.GetFilterValue(2).FAClickAction();
                FastDriver.NextGenDocumentRepository.GetFilterInputDiv(2, divIndex: 1).JSClick();
                //  ALSO USED:
                //  FastDriver.NextGenDocumentRepository.GetFilterLabel(2, labelIndex: 1).FAClickAction();
                //  FastDriver.NextGenDocumentRepository.GetFilterInput(2, value:"0").FASetCheckbox(true);
                //  FastDriver.NextGenDocumentRepository.IRFilterValue_All.Offset(390, 300).FAClick();
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(templateDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", templateDescription, "Description", TableAction.GetCell).Element.FAClickAction();
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FADoubleClick();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate);
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText(DateTime.UtcNow.ToPST().ToDateString());
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var docs = FastDriver.NextGenDocumentRepository.DocumentsTable.GetAttribute("textContent");
                Support.AreEqual("True", docs.Contains(templateDescription).ToString(), "Document Table contains doc named: " + templateDescription);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", templateDescription, "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverPreview.JSClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 300);
                FastDriver.WebDriver.ClosePreviewWindow();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally
            {
                SetSilverlightClipboardPermission_NO();
            }
        }
        #endregion

        #region REG0004
        [TestMethod]
        [Description("AlternateCourse3: Add Images to Document Repository")]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        [DeploymentItem(@"Common\Support\RemoveDLLs32bit.bat")]
        [DeploymentItem(@"Common\Support\RemoveDLLs64bit.bat")]
        [DeploymentItem(@"ImageRecognition\Media\ImagingWorkbench\")]
        public void REG0004()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse3: Add Images to Document Repository";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                // In Coded UI script, they verify data entry to make sure data is correct. 
                // I don't think we need to do that.

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Scan button
                Reports.TestStep = "Click on Scan button";
                FastDriver.NextGenDocumentRepository.Scan.FAClick();
                if (FastDriver.WebDriver.WaitForAlertToExist(5))
                {
                    if (!(System.IO.File.Exists(Reports.DEPLOYDIR + "\\RemoveDLLs64bit.bat") || System.IO.File.Exists(Reports.DEPLOYDIR + "\\RemoveDLLs32bit.bat")))
                        throw new ImageBenchException("Image Bench is outdated (must delete older files)");
                    else
                        FastDriver.WebDriver.HandleDialogMessage(true, true);
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Click on Open button and load the image document
                Reports.TestStep = "Click on Open button and load the image document";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.IROpen2.FAClick();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)
                #endregion

                #region Save the TIF Document
                Reports.TestStep = "Save the TIF Document";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: CLosing Disclosure", "Accomm Signing-Customer Seller", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is scanned to the FAST
                Reports.TestStep = "Verify that Document is scanned to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("AFFIX INV", "Escrow: Closing Disclosure");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region REG0005
        [TestMethod]
        [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
        [Description("AlternateCourse 4,5 and 6,15: 1.Split (Break-up) Images, Save to Document Repository and Deliver the document 2.Prevent Creation of Split Image with Only One Page")]
        public void REG0005()
        {
            try
            {
                SetDisplayPDFinBrowser_ON();

                Reports.TestDescription = "AlternateCourse 4,5 and 6,15: 1.Split (Break-up) Images, Save to Document Repository and Deliver the document 2.Prevent Creation of Split Image with Only One Page";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Upload button
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();
                #endregion

                #region Browse document
                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\CECONTRACT_4438673_LEG.pdf";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);
                #endregion

                #region Save the PDF Document
                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is uploaded to the FAST
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Split document
                Reports.TestStep = "Split document";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Name", TableAction.Click);
                // TODO: need to refactor move to PO
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "#4", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgSplit").FAClick();
                FastDriver.SplitDocumentScreenDlg.WaitForDialogToLoad();
                FastDriver.SplitDocumentScreenDlg.PageRange.FASetText("2-3");
                FastDriver.SplitDocumentScreenDlg.Split.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.SplitDocumentScreenDlg.WaitForDialogToLoad();
                FastDriver.NextGenDocumentRepository.HandleAdobeReaderError();  // don't see this on my machine
                FastDriver.SplitDocumentScreenDlg.Save.FAClick();
                FastDriver.WebDriver.ClosePreviewWindow();
                FastDriver.DocumentNameDlg.WaitForDialogLoad1();
                FastDriver.DocumentNameDlg.DocName.FASetText("Split Check");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.SplitDocumentScreenDlg.WaitForDialogToLoad();
                #endregion

                #region Click Done
                Reports.TestStep = "Click Done";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to document Repository
                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify Created Split doc in the Document Repository Screen
                Reports.TestStep = "Verify Created Split doc in the Document Repository Screen";
                docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Split Check", "Miscellaneous");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region REG0006
        [TestMethod]
        [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
        [Description("AlternateCourse5: Split (Break-up) Images and Deliver through Normal Delivery Methods")]
        public void REG0006()
        {
            try
            {
                SetDisplayPDFinBrowser_ON();

                Reports.TestDescription = "AlternateCourse5: Split (Break-up) Images and Deliver through Normal Delivery Methods";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Upload button
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();
                #endregion

                #region Browse document
                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\CECONTRACT_4438673_LEG.pdf";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);
                #endregion

                #region Save the PDF Document
                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is uploaded to the FAST
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Split document
                Reports.TestStep = "Split document";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Name", TableAction.Click);
                // TODO: need to refactor move to PO
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "#4", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgSplit").FAClick();
                FastDriver.SplitDocumentScreenDlg.WaitForDialogToLoad();
                FastDriver.SplitDocumentScreenDlg.PageRange.FASetText("2-3");
                FastDriver.SplitDocumentScreenDlg.Split.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.SplitDocumentScreenDlg.WaitForDialogToLoad();
                FastDriver.NextGenDocumentRepository.HandleAdobeReaderError();  // don't see this on my machine
                FastDriver.SplitDocumentScreenDlg.Save.FAClick();
                FastDriver.WebDriver.ClosePreviewWindow();
                FastDriver.DocumentNameDlg.WaitForDialogLoad1();
                FastDriver.DocumentNameDlg.DocName.FASetText("Split Check");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.SplitDocumentScreenDlg.WaitForDialogToLoad();
                #endregion

                #region Perform fax delivery
                Reports.TestStep = "Perform fax delivery";
                FastDriver.SplitDocumentScreenDlg.Fax.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Fax", true, 10);
                FastDriver.FaxDlg.WaitForScreenToLoad();
                FastDriver.FaxDlg.SendFax();
                FastDriver.WebDriver.WaitForDeliveryWindow("Fax", 200);
                #endregion

                #region Perform email delivery
                Reports.TestStep = "Perform email delivery";
                FastDriver.SplitDocumentScreenDlg.WaitForDialogToLoad();
                FastDriver.SplitDocumentScreenDlg.Email.FAClick();
                FastDriver.EmailDlg.WaitForDialogToLoad1().SendEmail();
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);
                #endregion

                #region Click Done
                Reports.TestStep = "Click Done";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to document Repository
                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify Created Split doc in the Document Repository Screen
                Reports.TestStep = "Verify Created Split doc in the Document Repository Screen";
                docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Split Check", "Miscellaneous");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Navigate to Event/Tracking Log and Select the "Doc Delivery" Option from the dropdown
                Reports.TestStep = "Navigate to Event/Tracking Log";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Reports.TestStep = "Select 'Doc Delivery' from EventCategory";
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Doc Delivery");
                #endregion

                #region Verify Delivery Status in Event Tracking Log Table
                Reports.TestStep = "Verify Delivery Status in Event Tracking Log Table";

                FastDriver.EventTrackingLog.EventTable.Highlight(10);
                string eventLog = FastDriver.EventTrackingLog.EventTable.FAGetText();
                Support.Match("\\[E-mail\\].+Email Service.+Delivery Status: Delivery Successful", eventLog);
                Support.Match("\\[Fax\\].+Fax Service.+Delivery Status: Delivery Successful", eventLog);
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally
            {
                SetDisplayPDFinBrowser_OFF();
            }
        }
        #endregion

        #region REG0007
        [TestMethod]
        [DeploymentItem(@"Common\Support\PDFSigQFormalRep.pdf")]
        [Description("Alternate Course 6:  Prevent Creation of Split Image with Only One Page")]
        public void REG0007()
        {
            try
            {
                SetDisplayPDFinBrowser_ON();

                Reports.TestDescription = "Alternate Course 6:  Prevent Creation of Split Image with Only One Page";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Upload button
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();
                #endregion

                #region Browse document
                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\PDFSigQFormalRep.pdf";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);
                #endregion

                #region Save the PDF Document
                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is uploaded to the FAST
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Split document
                Reports.TestStep = "Split document";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Name", TableAction.Click);

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "#4", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgSplit").FAClick();
                #endregion

                #region "System displays a message from web page as "Splitting not Supported. Active Document Has less than 2 pages".
                Reports.TestStep = "Verify System displays a message from web page as 'Splitting not Supported. Active Document Has less than 2 pages.' ";

                string Message = "Splitting not supported. Active document has less than 2 pages.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);


                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally
            {
                SetDisplayPDFinBrowser_OFF();
            }
        }

        #endregion

        #region REG0008
        [TestMethod]
        [Description("AlternateCourse7 DP9081: Create a Title Report")]
        public void REG0008()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse7 DP9081: Create a Title Report";

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                CloseRelatedProcesses();

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                //FastDriver.NextGenDocumentRepository.Open();
                // FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_TitleReports_DoNotTouch");

                Reports.TestStep = "Verify the Title Report Document is created";
                FastDriver.NextGenDocumentRepository.Open();

                //Added By Subhankar
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.Highlight();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClickAction();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_TitleReports_DoNotTouch");
                FastDriver.NextGenDocumentRepository.GetFilterValue(2).FAClickAction();
                FastDriver.NextGenDocumentRepository.GetFilterInputDiv(2, divIndex: 1).JSClick();
                FastDriver.NextGenDocumentRepository.Search.FAClickAction(); Playback.Wait(8500);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FAClickAction();
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClickAction();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate);
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText(DateTime.UtcNow.ToPST().ToDateString());
                //FastDriver.NextGenDocumentRepository.TitleReportDocDescription.FASetText("abc");
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClickAction(); Playback.Wait(5000);
                //FastDriver.NextGenDocumentRepository.DocInfo_CreateEdit.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("Title Reports", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Type", TableAction.GetText).Message);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region REG0009
        [TestMethod]
        [Description("AlternateCourse8: Propose a Policy to a Title Report")]
        public void REG0009()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse8: Propose a Policy to a Title Report";

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch ", "Lender Policy");
                CloseRelatedProcesses();

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #region Verify user not able to create a Lender Policy document
                Reports.TestStep = "Verify user not able to create a Lender Policy document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_LenderPolicy_DoNotTouch", templateType: "Lender Policy", errorMessage: "NO commitment document on file.");
                #endregion

                #region Create Title Reports document
                Reports.TestStep = "Create Title Reports document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_TitleReports_DoNotTouch");
                #endregion

                #region Create Lender Policy document
                Reports.TestStep = "Create Lender Policy document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_LenderPolicy_DoNotTouch");
                #endregion

                Reports.TestStep = "Verify the Lender Policy is added with the Title Report document";
                FastDriver.NextGenDocumentRepository.Open();
                Support.AreEqual("Title Reports", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Type", TableAction.GetText).Message);
                Support.AreEqual("Lender Policy", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Type", TableAction.GetText).Message);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0010
        [TestMethod]
        [Description("AlternateCourse9: Create a Proposed Policy")]
        public void REG0010()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse9: Create a Proposed Policy";

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN301", "NEXTGEN_SAN_LenderPolicy_DoNotTouch ", "Lender Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN401", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch ", "Owner Policy");
                CloseRelatedProcesses();

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                //Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Support.IsTrue(WCF_CreateFileWithNewLoan() || WCF_CreateFileWithNewLoan(), "File created successfully");

                #region Add Title Reports Document
                Reports.TestStep = "Add Title Reports Document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_TitleReports_DoNotTouch", effectiveDate: DateTime.UtcNow.Subtract(TimeSpan.FromDays(7)).ToPST().ToDateString());
                #endregion

                //Added By Subhankar For Sale price enter in TDS Screen
                Reports.TestStep = "Navigate to TDS screen and Change Sales Price.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.SetSalesPriceAmount(@"9,000.00");
                FastDriver.WebDriver.HandleDialogMessage(false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                Support.AreEqual("9,000.00", FastDriver.TermsDatesStatus.LiabilityAmount.FAGetValue().ToString());

                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.Click();



                #region Add Lender Policy Document
                Reports.TestStep = "Add Lender Policy Document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_LenderPolicy_DoNotTouch");
                #endregion

                Reports.TestStep = "Select the document Right-Click and select 'PhraseView/Edit' option from context";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();

                //Support.AreEqual("04-13-2016", (FastDriver.NextGenDocumentRepository.Policy_EffectiveDate.GetAttribute("Text").ToString()));
                Support.AreEqual("Sales Liability: $9,000.00", FastDriver.NextGenDocumentRepository.SalesLiability.FAGetText());
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();



                #region Add Owner Policy Document
                Reports.TestStep = "Add Owner Policy Document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_OwnerPolicy_DoNotTouch");
                #endregion


                Reports.TestStep = "Select the document Right-Click and select 'PhraseView/Edit' option from context";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();

                //Support.AreEqual("04-13-2016", (FastDriver.NextGenDocumentRepository.Policy_EffectiveDate.GetAttribute("Text").ToString()));
                Support.AreEqual("Sales Liability: $9,000.00", FastDriver.NextGenDocumentRepository.SalesLiability.FAGetText());
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();

                Reports.TestStep = "Verify the Lender Policy is added with the Title Report document";
                FastDriver.NextGenDocumentRepository.Open();
                Support.AreEqual("Title Reports", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Type", TableAction.GetText).Message);
                Support.AreEqual("Lender Policy", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Type", TableAction.GetText).Message);
                Support.AreEqual("Owner Policy", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Type", TableAction.GetText).Message);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        #endregion

        #region REG0011
        [TestMethod]
        [Description("Alternate Course 10:  Create Multiple Documents")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0011()
        {
            try
            {
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Alternate Course 10:  Create Multiple Documents";

                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion




                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");


                //Work with the following service to create phrase, phrase group and template.

                //Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_Test_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                // Phrase_phraseGrp_Template("BNAN", "Title Phrase[TITLE]", "Title-NXTGN11", "NEXTGEN_Test_TitleReports_DoNotTouch", "Title Reports");


                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");


                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select Multiple templates (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "NEXTGEN_SAN_TitleReports_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Navigates to Search Results section of File Documents screen and created mulitple documents should be displayed in the list
                Reports.TestStep = "Navigates to Search Results section of File Documents screen and created mulitple documents should be displayed in the list";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                var documentTable = FastDriver.NextGenDocumentRepository.DocumentsTable.FAGetText();
                Support.AreEqual("True", documentTable.Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString(), "Document table contains NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                Support.AreEqual("True", documentTable.Contains("NEXTGEN_SAN_TitleReports_DoNotTouch").ToString(), "Document table contains NEXTGEN_SAN_TitleReports_DoNotTouch");
                #endregion




            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0012
        [TestMethod]
        [Description("AlternateCourse11: Edit a Document")]
        public void REG0012()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse11: Edit a Document";

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                CloseRelatedProcesses();

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                //Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Support.IsTrue(WCF_CreateFileWithNewLoan() || WCF_CreateFileWithNewLoan(), "File created successfully");

                #region Add Title Reports Document
                Reports.TestStep = "Add Title Reports Document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_TitleReports_DoNotTouch", effectiveDate: DateTime.UtcNow.Subtract(TimeSpan.FromDays(7)).ToPST().ToDateString());
                #endregion


                Reports.TestStep = "Select the document Right-Click and select 'PhraseView/Edit' option from context";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();

                Reports.TestStep = "Insert phrases";
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FADoubleClick();

                #region Get value of data element
                Reports.TestStep = "Get value of data element";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.RefreshDocument);
                //var dataElement = FastDriver.NextGenDocumentRepository.DataElement("Buyer Contact: Name");
                var dataElement = FastDriver.NextGenDocumentRepository.DataElement("File Number");
                var priorValue = dataElement["Input"].FAGetText();

                #endregion

                #region Edit value of any data element and click on "Save" Button
                Reports.TestStep = "Edit value of any data element and click on \"Save\" Button";
                var editedBuyerFirstName = "Edited-Buyer-First-Name";
                dataElement["Input"].FASetText(editedBuyerFirstName);
                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                //var Brokenlink = dataElement["BrokenLink"].Exists().ToString();
                //Support.AreEqual("True", Brokenlink, "Broken Link exists on the table");
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                #endregion

                Reports.TestStep = "Select the Status \"Edited\" from the status dropdown";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentStatus.FASelectItemBySendingKeys("Edited");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click Done";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FADoubleClick();



            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0013
        [TestMethod]
        [Description("Alternate Course 12:  Create a PDF Image")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0013()
        {
            try
            {
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Alternate Course 12:  Create a PDF Image";
                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                // Pre-Condition

                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                // LoadTemplateOrCreateNew("Escrow-NXTGN10", "NEXTGEN_Test_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                // LoadTemplateOrCreateNew("Title-NXTGN20", "NEXTGEN_Test_TitleReports_DoNotTouch", "Title Reports");

                // Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_Test_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                // Phrase_phraseGrp_Template("BNAN", "Title Phrase[TITLE]", "Title-NXTGN11", "NEXTGEN_Test_TitleReports_DoNotTouch", "Title Reports");


                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");


                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");

                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select the template by using "Ctrl" command
                Reports.TestStep = "Select the template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();


                var documents = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion



                #region Right click and Select ImageDoc from Deliver
                Reports.TestStep = "Select \"ImageDoc from  Deliver\" option";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Right click and Select ImageDoc from Deliver in Context Menu Items";

                FastDriver.NextGenDocumentRepository.DocumentsTable.Highlight(3);

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();

                #region Perform ImageDoc Delivery

                //  Assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);


                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.Highlight();

                // FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.FAClick();

                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.JSClick();

                #endregion



                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                FastDriver.ImageDocDlg.markDraft.FASetCheckbox(true);
                FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.Deliver();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 400);


                Reports.TestStep = "Verify A Document will be displays with \"PDF\" Icon and Same \"document name\" which delivered and Type as \"Imaged Document\" and Status as \"Imaged\".";

                FastDriver.NextGenDocumentRepository.Open();

                string PDFImage1 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(2, 10, TableAction.GetCell).Element.FAGetText();


                Support.AreEqual("Imaged", PDFImage1);



                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0014
        [TestMethod]
        [Description("AlternateCourse13: Edit an Image")]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.TIF")]
        [DeploymentItem(@"ImageRecognition\Media\ImagingWorkbench\")]
        public void REG0014()
        {
            try
            {
                EnableSavingIRSamples();

                Reports.TestDescription = "Verify Edit Image Feature";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Scan button
                Reports.TestStep = "Click on Scan button";
                FastDriver.NextGenDocumentRepository.Scan.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Click on Open button and load the image document
                Reports.TestStep = "Click on Open button and load the image document";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)
                #endregion

                #region Save the TIF Document
                Reports.TestStep = "Save the TIF Document";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Miscellaneous", "CD - From Lender - Corrected AFTER Closing", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is scanned to the FAST
                Reports.TestStep = "Verify that Document is scanned to the FAST";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "AFFIX INV", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.EditImage.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
                #endregion

                #region Click on Edit image option to open ImageWorkbench
                Reports.TestStep = "Click on Edit image option to open ImageWorkbench";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                FastDriver.ImagingWorkBench.IRRotateRight2.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)
                #endregion

                #region Save the Edited Image
                Reports.TestStep = "Save the Edited Image";
                FastDriver.SaveDocumentDlg.SaveEditImageUsingAutoIt();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);
                #endregion

                #region Navigate to document Repository
                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Edited Image is present in the File Documents
                Reports.TestStep = "Verify that Edited Image is present in the File Documents";
                int row = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "AFFIX INV", "Name", TableAction.Click).CurrentRow;
                row = row + 2;
                FastDriver.NextGenDocumentRepository.VersionIcon.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(row, 7, TableAction.Click);  // TODO: use column Name if possible
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region REG0015
        [TestMethod]
        [Description("Alternate Course 14:  Remove a Document")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
        public void REG0015()
        {
            try
            {
                string documentTable;

                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Alternate Course 14: Remove a Document";
                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                try
                {
                    FAST_OpenRegionOrOffice(officeId);
                }
                catch (Exception ex)
                {
                    FAST_OpenRegionOrOffice(officeId);
                }

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                // Pre-Condition

                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN400", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN500", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");

                // Work with the following service to create phrase, phrase group and template.

                //Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Title-NXTGN11", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Lender-NXTGN11", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Owner-NXTGN11", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                //Phrase_phraseGrp_Template("ANAN", "Endorsement Phrase[ENDORSE]", "EndorsementGuarantee-NXTGN11", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");


                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select Multiple templates (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for Policy_w/o_Title Reports using search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select the template by using "Ctrl" command
                Reports.TestStep = "Select the template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();


                var documentsEndo = new List<string> { "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documentsEndo);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select any Policy from the grid
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Highlight(3);


                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.GetRowCount(), 1, TableAction.GetCell).Element.FADoubleClick();


                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.Highlight(3);
                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.FADoubleClick();
                #endregion



                #region Right click and Select ImageDoc from Deliver
                Reports.TestStep = "Select \"ImageDoc from  Deliver\" option";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Right click and Select ImageDoc from Deliver in Context Menu Items";

                FastDriver.NextGenDocumentRepository.DocumentsTable.Highlight(3);

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();

                #region Perform ImageDoc Delivery

                //  Assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);


                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.Highlight();

                //FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.FAClick();

                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.JSClick();

                #endregion


                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                FastDriver.ImageDocDlg.markDraft.FASetCheckbox(true);
                FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.Deliver();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 400);

                #endregion


                #region Navigates to Search Results section of File Documents screen and created mulitple documents should be displayed in the list
                Reports.TestStep = "Navigates to Search Results section of File Documents screen and created mulitple documents should be displayed in the list";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Type", TableAction.GetCell).Element.FARightClick();
                string Name = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Name", TableAction.GetCell).Element.FAGetText();
                #endregion

                #region Select "Remove" option
                Reports.TestStep = "Select \"Remove\" option";
                FastDriver.NextGenDocumentRepository.Remove.FASelectContextMenuItem();
                #endregion

                #region Verify the error message

                Reports.TestStep = "Verify the error message";
                string Message = "";
                Message = "Policy document(s) " + Name + " is/are associated to one or more Endorsement/Guarantee documents and cannot be removed.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);

                #endregion

                #region Select the Escrow Instruction type document
                Reports.TestStep = "Select and double click on the Escrow Instruction type document";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Status", TableAction.GetCell).Element.FADoubleClick();
                #endregion

                #region Select "Finalized" option from the dropdown
                Reports.TestStep = "Select \"Finalized\" option from the Status dropdown";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Status", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "item.DocStatusCD").FASelectItem("Finalized");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select "Remove" option
                Reports.TestStep = "Select \"Remove\" option";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                Name = "";
                Name = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FAGetText();
                FastDriver.NextGenDocumentRepository.Remove.FASelectContextMenuItem();
                #endregion

                #region Verify the error message
                Reports.TestStep = "Verify the error message";
                Message = "";
                Message = "Document(s) is/are in finalized status, cannot be removed. Document Name : " + Name + ".";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);

                #endregion

                #region Select the Escrow Instruction type document
                Reports.TestStep = "Select and double click on the Escrow Instruction type document";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Status", TableAction.GetCell).Element.FADoubleClick();
                #endregion

                #region Select "UnFinalized" option from the dropdown
                Reports.TestStep = "Select \"UnFinalized\" option from the Status dropdown";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Status", TableAction.GetCell).Element.FADoubleClick();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Status", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "item.DocStatusCD").FASelectItem("UnFinalized");
                #endregion

                #region Enter the Reason in the dialog box and click on Done
                Reports.TestStep = "UnFinalize the Document.";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DivEventComment.Highlight(3);
                FastDriver.NextGenDocumentRepository.UnfinalizedNote.Highlight(3);
                FastDriver.NextGenDocumentRepository.UnfinalizedNote.FASetText(@"UnFinalized");
                FastDriver.NextGenDocumentRepository.ReasonUnfinalize_Done.Highlight(3);
                FastDriver.NextGenDocumentRepository.ReasonUnfinalize_Done.FADoubleClick();


                #region Click on Upload button
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();
                #endregion

                #region Browse document
                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\CECONTRACT_4438673_LEG.pdf";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);
                #endregion

                #region Save the PDF Document
                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is uploaded to the FAST
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Navigate to Home Warranty page and Enter GAB
                Reports.TestStep = "Navigate to Home Warranty screen and Enter GAB";
                FastDriver.HomeWarrantyDetail.Open();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                #endregion
                #region Enter Buyer and Seller charges
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("100" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("200" + FAKeys.Tab);

                FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FASetText("100" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FASetText("200" + FAKeys.Tab);
                #endregion

                #region Navigate to "Active Disbursement"
                Reports.TestStep = "Navigate to \"Active Disbursement\" screen";

                FastDriver.ActiveDisbursementSummary.Open();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", @"Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion
                #region Go to "Edit Disbursement"
                Reports.TestStep = "Go to \"Edit Disbursement\" screen";
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Select Disburse As: Wire";
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");

                Reports.TestStep = "Enter mandatory highlighed fields under the Wire Details section";
                string Bank_Number = FastDriver.EditDisbursement.FromAccount.FAGetText().ToString();

                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("1234567");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText(Bank_Number);
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText(Bank_Number);

                Reports.TestStep = "Add Escrow: Payoff/Demand bill document under Wire Instructions";

                FastDriver.EditDisbursement.Add.FAClick();
                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Select Wire Instructions", timeoutSeconds: 10);
                FastDriver.SelectWireInstructionsDlg.SwitchToDialogContentFrame();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.SelectWireInstructionsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to "Document Repository"
                Reports.TestStep = "Navigate to \"Document Repository\" screen";
                FastDriver.NextGenDocumentRepository.Open();


                #endregion

                #region Navigates to Search Results section of File Documents screen and created mulitple documents should be displayed in the list
                Reports.TestStep = "Navigates to Search Results section of File Documents screen and created mulitple documents should be displayed in the list";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Type", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Remove" option
                Reports.TestStep = "Select \"Remove\" option";
                FastDriver.NextGenDocumentRepository.Remove.FASelectContextMenuItem();
                #endregion

                #region Verify the error message



                Reports.TestStep = "Verify the error message";
                Message = "";
                Message = "Document(s) Miscellaneous PDFDocument cannot be removed because it's attached to a created, pending or issued wire disbursement.Please remove from wire disbursement before removing the Document.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);


                FastDriver.NextGenDocumentRepository.Open();
                Reports.TestStep = "Double click on the Type Column of the document which is attached to a pending wire";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Type", TableAction.GetCell).Element.FADoubleClick();


                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.itemDocumentName.IsVisible().ToString(), false);
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.itemDocTypeCDID.IsVisible().ToString(), false);


                Reports.TestStep = "Right click on the Type Column of the document which is attached to a pending wire and verify \"Edit Document Name\" is enable or disabled.";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Type", TableAction.GetCell).Element.FARightClick();

                string EditdocNameRGB = FastDriver.NextGenDocumentRepository.EditDocumentName.FAGetAttribute("style");
                string CompareRGB = FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FAGetAttribute("style");

                if (EditdocNameRGB != CompareRGB && EditdocNameRGB == "color: rgb(168, 168, 168);")
                {

                    Support.AreEqual("True", "True", "Edit Document Name is Disabled");
                }

                Reports.TestStep = "Verify the Document Name text box is enabled or disbale in \"Change Type Dialog Box\"";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Type", TableAction.GetCell).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.Change_Type.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.EditDocumentDlg.EditDocumentNameDialog.Highlight(5);

                Reports.TestStep = "Verify controls are enabled or disabled in \"Edit Document\" Dialog.";

                Support.AreEqual("False", FastDriver.EditDocumentDlg.EditDocName.IsEnabled().ToString(), false);

                //The following script is failing because og bugs.
                //Support.AreEqual("False", FastDriver.EditDocumentDlg.DocumentNameCbo.IsEnabled().ToString(), false);
                //Support.AreEqual("False", FastDriver.EditDocumentDlg.EditDocumentAdditionalInfo.IsEnabled().ToString(), false);
                FastDriver.EditDocumentDlg.EditDocument_Done.FAClick();


                #endregion





            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0016
        [TestMethod]
        [Description("AlternateCourse15:  Deliver a Document")]
        public void REG0016()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse15:  Deliver a Document";

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                CloseRelatedProcesses();

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                var DocumentName = "SAN_NEXTGEN_10";
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_EscrowInstruction_DoNotTouch", DocumentName);

                #region Perform Print Delivery
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverPrint.JSClick();
                FastDriver.PrintDlg.WaitForScreenToLoad().SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 300);
                #endregion

                #region Perform Fax Delivery
                Reports.TestStep = "Perform Fax Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", DocumentName, "Name", TableAction.GetCell).Element.FARightClick();
                //  Trick or Treat!
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverFax.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Fax", true, 15);
                FastDriver.FaxDlg.WaitForScreenToLoad().SendFax();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Fax, 300);

                //Reports.TestStep = "Perform Fax Delivery";
                //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                //FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", DocumentName, "Name", TableAction.GetCell).Element.FARightClick();
                //FastDriver.NextGenDocumentRepository.SearchResult_Deliver.FAMoveToElement();
                //FastDriver.NextGenDocumentRepository.SearchResult_DeliverFax.FAClick();
                //FastDriver.FaxDlg.WaitForScreenToLoad().SendFax();
                //FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Fax, 200);
                #endregion

                #region Perform Email Delivery
                Reports.TestStep = "Perform Email Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", DocumentName, "Name", TableAction.GetCell).Element.FARightClick();
                //  Trick or Treat!
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverEmail.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 15);
                FastDriver.EmailDlg.WaitForDialogToLoad().SendEmail();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Email, 300);
                #endregion

                #region Perform Preview Delivery
                Reports.TestStep = "Perform Preview Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", DocumentName, "Name", TableAction.GetCell).Element.FARightClick();
                //  Trick or Treat!
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverPreview.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 300);
                FastDriver.WebDriver.ClosePreviewWindow();
                #endregion

                #region Perform ImageDoc Delivery
                Reports.TestStep = "Perform ImageDoc Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", DocumentName, "Name", TableAction.GetCell).Element.FARightClick();
                //  Trick or Treat!
                //  assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc.JSClick();
                //
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 300);
                #endregion

                #region Navigate to Event/Tracking Log in FAST Nav
                Reports.TestStep = "Navigate to Event/Tracking Log in FAST Nav";
                FastDriver.EventTrackingLog.Open();
                #endregion

                #region Select Doc Delivery from the Event Category dropdown
                Reports.TestStep = "Select Doc Delivery from the Event Category dropdown";
                FastDriver.EventTrackingLog.EventCategory.FASelectItemBySendingKeys("doc delivery");
                Playback.Wait(1000);    // TODO: find a better way to check if table finishes loading. wait until .//option[@selected][text()='Doc Delivery']
                FastDriver.EventTrackingLog.WaitForWindowToLoad(); // create a WaitForTableToLoad(string eventCategory) method 
                #endregion

                #region Verifying Print Delivery
                Reports.TestStep = "Verifying Print Delivery";
                string printServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Print]", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", printServiceComment.Contains(File.FileNumber).ToString(), "Verify Print Service Comments contains 'File Number: " + File.FileNumber + "'");
                Support.AreEqual("True", printServiceComment.Contains(DocumentName).ToString(), "Verify Print Service Comments contains 'Documents: " + DocumentName + "'");
                Support.AreEqual("True", printServiceComment.Contains("Delivery Method: Print").ToString(), "Verify Print Service Comments contains 'Delivery Method: Print'");
                Support.AreEqual("True", printServiceComment.Contains("Delivery Status: Delivery Successful").ToString(), "Verify Print Service Comments contains 'Delivery Status: Delivery Successful'");
                Support.AreEqual("True", printServiceComment.Contains(DocumentName + " : ImageDoc Successful").ToString(), "Verify Print Service Comments contains '" + DocumentName + " : ImageDoc Successful'");
                #endregion

                #region Verifying Fax Delivery
                Reports.TestStep = "Verifying Fax Delivery";
                var faxNumber = AutoConfig.DeliverFaxTo.Replace("-", "").FormatAsPhoneNumber();
                var faxServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Fax]", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", faxServiceComment.Contains(File.FileNumber).ToString(), "Verify Fax Service Comments contains 'File Number: " + File.FileNumber + "'");
                Support.AreEqual("True", faxServiceComment.Contains(DocumentName).ToString(), "Verify Fax Service Comments contains 'Documents: " + DocumentName + "'");
                Support.AreEqual("True", faxServiceComment.Contains("Delivery Method: Fax").ToString(), "Verify Fax Service Comments contains 'Delivery Method: Fax'");
                Support.AreEqual("True", faxServiceComment.Contains(faxNumber).ToString(), "Verify Fax Service Comments contains fax number: " + faxNumber);
                #endregion

                #region Verifying Email Delivery
                Reports.TestStep = "Verifying Email Delivery";
                var emailServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[E-mail]", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", emailServiceComment.Contains(File.FileNumber).ToString(), "Verify Email Service Comments contains 'File Number: " + File.FileNumber + "'");
                Support.AreEqual("True", emailServiceComment.Contains(DocumentName).ToString(), "Verify Email Service Comments contains 'Documents: " + DocumentName + "'");
                Support.AreEqual("True", emailServiceComment.Contains("Delivery Method: Email").ToString(), "Verify Email Service Comments contains 'Delivery Method: Email'");
                Support.AreEqual("True", emailServiceComment.Contains("Recipients: " + AutoConfig.DeliverEmailTo).ToString(), "Verify Email Service Comments contains 'Recipients: " + AutoConfig.DeliverEmailTo + "'");
                Support.AreEqual("True", emailServiceComment.Contains("Delivery Status: Delivery Successful").ToString(), "Verify Email Service Comments contains 'Delivery Status: Delivery Successful'");
                #endregion

                #region Verifying ImageDoc Delivery
                Reports.TestStep = "Verifying ImageDoc Delivery";
                var imageDocServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[ImageDoc]", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", imageDocServiceComment.Contains(File.FileNumber).ToString(), "Verify ImageDoc Service Comments contains 'File Number: " + File.FileNumber + "'");
                Support.AreEqual("True", imageDocServiceComment.Contains(DocumentName).ToString(), "Verify ImageDoc Service Comments contains 'Documents: " + DocumentName + "'");
                Support.AreEqual("True", imageDocServiceComment.Contains("Delivery Method: Image Doc").ToString(), "Verify ImageDoc Service Comments contains 'Delivery Method: Image Doc'");
                Support.AreEqual("True", imageDocServiceComment.Contains(DocumentName + " : ImageDoc Successful").ToString(), "Verify ImageDoc Service Comments contains '" + DocumentName + " : ImageDoc Successful'");
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region REG0017
        [TestMethod]
        [Description("AlternateCourse17: Alternate Course 16:  Copy Exceptions and/or Requirements and/or Informational Notes from a Title Report or Policy Document ")]
        public void REG0017()
        {
            EnableSavingIRSamples();
            SetSilverlightClipboardPermission_YES();

            Reports.TestDescription = "Alternate Course 14: Remove a Document";
            Reports.TestDescription = "Login to ADM site";
            FAST_Login_ADM(isSuperUser: false);
            try
            {
                FAST_OpenRegionOrOffice(officeId);
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));

            }
            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // Pre-Condition

            LoadTemplateOrCreateNew("SAN-NEXTGEN101", "NEXTGEN_SAN_EscrowInfoNote_DoNotTouch", "Title Reports");
            LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
            LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
            LoadTemplateOrCreateNew("SAN-NEXTGEN505", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");



            // Work with the following service to create phrase, phrase group and template.

            //Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInfoNote_DoNotTouch", "Title Reports");
            //Phrase_phraseGrp_Template("ANAN", "Endorsement Phrase[ENDORSE]", "Title-NXTGN11", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
            //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Lender-NXTGN11", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
            //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Owner-NXTGN11", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
            //Phrase_phraseGrp_Template("ANAN", "Endorsement Phrase[ENDORSE]", "EndorsementGuarantee-NXTGN11", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");


            Reports.TestDescription = "Login to IIS site";
            FAST_Login_IIS(regionId: regionId);
            FAST_OpenRegionOrOffice(officeId);
            Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

            #region Navigate to Document Repository Screen
            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.NextGenDocumentRepository.Open();
            #endregion

            #region Click on "Template Search" button
            Reports.TestStep = "Click on \"Template Search\" button";
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            #endregion

            #region Search for templates using search criteria
            Reports.TestStep = "Search for templates using search criteria";
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            FastDriver.NextGenDocumentRepository.TemplateDescription.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_ALL_0.FASetCheckbox(true);
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            #endregion

            #region Select Multiple templates (2 or more) by using "Ctrl" command
            Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            var documents = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
            FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
            #endregion

            #region Hold Right Click
            Reports.TestStep = "Hold Right Click";
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
            #endregion

            #region Select "Create Document" option
            Reports.TestStep = "Select \"Create Document\" option";
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            #endregion

            string filenumber_0 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();


            #region Create File
            Reports.TestStep = "Create a File";
            Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
            //  FastDriver.FileHomepage.WaitForScreenToLoad();
            // var filenumber_1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
            #endregion

            #region Navigate to Document Repository Screen
            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.NextGenDocumentRepository.Open();
            #endregion

            #region Click on "Template Search" button
            Reports.TestStep = "Click on \"Template Search\" button";
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FADoubleClick();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            #endregion

            #region Search for templates using search criteria
            Reports.TestStep = "Search for templates using search criteria";
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN*");
            FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
            //FastDriver.NextGenDocumentRepository.StateValue_All.FADoubleClick();

            //  FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

            #endregion

            #region Select Multiple templates (2 or more) by using "Ctrl" command
            Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            var documents1 = new List<string> { "NEXTGEN_DESCRIPTION_TEST", "NEXTGEN_SAN_TitleReports_DoNotTouch" };
            FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents1);
            #endregion

            #region Hold Right Click
            Reports.TestStep = "Hold Right Click";
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_DESCRIPTION_TEST", "Description", TableAction.GetCell).Element.FARightClick();
            #endregion

            #region Select "Create Document" option
            Reports.TestStep = "Select \"Create Document\" option";
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            #endregion

            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

            var documents2 = new List<string> { "NEXTGEN_DESCRIPTION_TEST" };
            FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents2);



            #region Hold Right Click
            Reports.TestStep = "Hold Right Click";
            FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_DESCRIPTION_TEST", "Name", TableAction.GetCell).Element.FARightClick();

            Reports.TestStep = "Click on Phrase/view Edit";
            FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            //bool DocInfo = FastDriver.NextGenDocumentRepository.DocumentInfoTab.IsDisplayed();
            //Support.AreEqual(DocInfo.ToString(), "True");
            #endregion
            //  FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "APR1 Endorse Template", effectiveDate: DateTime.UtcNow.Subtract(TimeSpan.FromDays(7)).ToPST().ToDateString());
            DateTime today = System.DateTime.Today; // As DateTime
            string s_today = today.ToString("MM/dd/yyyy"); // As String

            FastDriver.DocumentInfo.EffectiveDateText.FASetText(s_today);

            Reports.TestStep = "Click on Save'";
            FastDriver.NextGenDocumentRepository.TitleReportSave.FADoubleClick();
            #region Click On Copy From
            Reports.TestStep = "Click on Copy From";
            FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "btnCopyFrom").FADoubleClick();

            #region Enter / Overtype the default file number with File Number which is created in Step-3

            Reports.TestStep = "Enter / Overtype Filenumber ";
            FastDriver.CopyFrom.WaitForScreenToLoad();
            FastDriver.CopyFrom.Copy_FileNum.Highlight();
            FastDriver.CopyFrom.Copy_FileNum.FASetText(filenumber_0);

            FastDriver.CopyFrom.CopyFrom_Region.FASelectItem("QA Sandpointe - Next Gen");
            FastDriver.CopyFrom.CopyFrom_RefreshBtn.FAClick();
            //   FastDriver.CopyFrom.Searchbtn.FAClick();
            // FastDriver.CopyFrom.WaitForScreenToLoad();
            #endregion
            Reports.TestStep = "Verify the table is avilable with List and click on checkbox";
            Playback.Wait(4000);
            FastDriver.CopyFrom.WaitForScreenToLoad();
            if (FastDriver.CopyFrom.DocResultGrid.Exists() == true)
            { FastDriver.CopyFrom.GridChkbox_0.FAClick(); }

            Reports.TestStep = "Click on Exceptions/Requirements/Informational Notes/Endorsements Radio button";

            FastDriver.CopyFrom.Radio_ExcReqInfEnd.FAClick();   //rbExcReqInfo
            #endregion

            #region Click on List
            Reports.TestStep = "Click on List Button on the selected document";
            if ((FastDriver.CopyFrom.BtnList_phrase.Exists()) == true)
            { FastDriver.CopyFrom.BtnList_phrase.FADoubleClick(); Playback.Wait(10000); }
            else
            {
                if (FastDriver.CopyFrom.WebDriver.FAFindElement(ByLocator.Id, "divmoveDocsResultContent").FAFindElement(ByLocator.Id, "divSearchDocsGrid").FAFindElement(ByLocator.Id, "gridExpReqInfoCpyDocumentList").FAFindElement(ByLocator.Id, "btnphraseSelect").Exists() == true)
                { FastDriver.CopyFrom.GridChkbox_0.FASetCheckbox(true); }

            }
            if (FastDriver.SelectExcReqInfNote.SelectAllPhrase.Exists() == true)
            {
                FastDriver.SelectExcReqInfNote.SelectAllPhrase.FASetCheckbox(true);

            }
            else
            {
                FastDriver.SelectExcReqInfNote.SelectAll_temp.Highlight(5);
                FastDriver.SelectExcReqInfNote.SelectAll_temp.FAClick();
            }
            FastDriver.SelectExcReqInfNote.Bottom_Done.FAClick(); Playback.Wait(6000);

            if (FastDriver.CopyFrom.DocResultGrid.Exists() == true) ;
            { FastDriver.CopyFrom.GridChkbox_0.FASetCheckbox(true); Playback.Wait(8000); }

            if ((FastDriver.CopyFrom.AddPhrases.Exists()) == true)
            { FastDriver.CopyFrom.AddPhrases.FAClick(); }
            #region   Verify the message being displayed and message
            Reports.TestStep = "Verify the message being displayed and message";
            string Message = "Phrases From NEXTGEN_SAN_LenderPolicy_DoNotTouch are successfully Processed.";
            FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);

            #region Click on "OK" button in the Alert Message box
            Reports.TestStep = "Click on \"OK\" button in the Alert Message box";
            FastDriver.CopyFrom.CopyFrom_BottomDone.Highlight(5);
            FastDriver.CopyFrom.CopyFrom_BottomDone.FADoubleClick();
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            FastDriver.NextGenDocumentRepository.TitleReportSave.Highlight(); FastDriver.NextGenDocumentRepository.TitleReportSave.FAClick();



            #endregion
            #endregion

            #endregion


        }

        #endregion

        #region REG0018
        [TestMethod]
        [Description("AlternateCourse17: Issue a Policy")]
        public void REG0018()
        {
            try
            {
                Reports.TestDescription = "AlternateCourse17: Issue a Policy ";

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN301", "NEXTGEN_SAN_LenderPolicy_DoNotTouch ", "Lender Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN401", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch ", "Owner Policy");
                CloseRelatedProcesses();

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                //Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Support.IsTrue(WCF_CreateFileWithNewLoan() || WCF_CreateFileWithNewLoan(), "File created successfully");

                #region Add Title Reports Document
                Reports.TestStep = "Add Title Reports Document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_TitleReports_DoNotTouch", effectiveDate: DateTime.UtcNow.Subtract(TimeSpan.FromDays(7)).ToPST().ToDateString());
                #endregion

                //Added By Subhankar For Sale price enter in TDS Screen
                Reports.TestStep = "Navigate to TDS screen and Change Sales Price.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.SetSalesPriceAmount(@"9,000.00");
                FastDriver.WebDriver.HandleDialogMessage(false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                Support.AreEqual("9,000.00", FastDriver.TermsDatesStatus.LiabilityAmount.FAGetValue().ToString());

                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.Click();



                #region Add Lender Policy Document
                Reports.TestStep = "Add Lender Policy Document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_LenderPolicy_DoNotTouch");
                #endregion

                Reports.TestStep = "Select the document Right-Click and select 'PhraseView/Edit' option from context";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();

                //Support.AreEqual("04-13-2016", (FastDriver.NextGenDocumentRepository.Policy_EffectiveDate.GetAttribute("Text").ToString()));
                Support.AreEqual("Sales Liability: $9,000.00", FastDriver.NextGenDocumentRepository.SalesLiability.FAGetText());
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();



                #region Add Owner Policy Document
                Reports.TestStep = "Add Owner Policy Document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_OwnerPolicy_DoNotTouch");
                #endregion


                Reports.TestStep = "Select the document Right-Click and select 'PhraseView/Edit' option from context";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();

                //Support.AreEqual("04-13-2016", (FastDriver.NextGenDocumentRepository.Policy_EffectiveDate.GetAttribute("Text").ToString()));
                Support.AreEqual("Sales Liability: $9,000.00", FastDriver.NextGenDocumentRepository.SalesLiability.FAGetText());
                FastDriver.NextGenDocumentRepository.Policy_IssueDate.FASetText(DateTime.UtcNow.ToPST().ToDateString());
                FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.FASetText("124578");

                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();

                Reports.TestStep = "Verify the Lender Policy is added with the Title Report document";
                FastDriver.NextGenDocumentRepository.Open();
                Support.AreEqual("Title Reports", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Type", TableAction.GetText).Message);
                Support.AreEqual("Lender Policy", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Type", TableAction.GetText).Message);
                Support.AreEqual("Owner Policy", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Type", TableAction.GetText).Message);





            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        #endregion

        #region REG0019
        [TestMethod]
        [Description("Alternate Course 18:  Enter Manual Policy Number")]
        public void REG0019()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 18:  Enter Manual Policy Number";

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN301", "NEXTGEN_SAN_LenderPolicy_DoNotTouch ", "Lender Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN401", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch ", "Owner Policy");
                CloseRelatedProcesses();

                FAST_Login_IIS(regionId: regionId);
                try
                {
                    FAST_OpenRegionOrOffice(officeId);
                }

                catch (Exception ex)
                {
                    FailTest(GetExceptionInfo(ex));

                }
                Support.IsTrue(WCF_CreateFileWithNewLoan() || WCF_CreateFileWithNewLoan(), "File created successfully");

                #region Add Title Reports Document
                Reports.TestStep = "Add Title Reports Document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_TitleReports_DoNotTouch", effectiveDate: DateTime.UtcNow.Subtract(TimeSpan.FromDays(7)).ToPST().ToDateString());
                #endregion

                //Added By Subhankar For Sale price enter in TDS Screen
                Reports.TestStep = "Navigate to TDS screen and Change Sales Price.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.SetSalesPriceAmount(@"9,000.00");
                FastDriver.WebDriver.HandleDialogMessage(false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                Support.AreEqual("9,000.00", FastDriver.TermsDatesStatus.LiabilityAmount.FAGetValue().ToString());

                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.Click();



                #region Add Lender Policy Document
                Reports.TestStep = "Add Lender Policy Document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_LenderPolicy_DoNotTouch");
                #endregion

                Reports.TestStep = "Select the document Right-Click and select 'PhraseView/Edit' option from context";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();

                //Support.AreEqual("04-13-2016", (FastDriver.NextGenDocumentRepository.Policy_EffectiveDate.GetAttribute("Text").ToString()));
                Support.AreEqual("Sales Liability: $9,000.00", FastDriver.NextGenDocumentRepository.SalesLiability.FAGetText());
                FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.FASetText("123457");
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();



                #region Add Owner Policy Document
                Reports.TestStep = "Add Owner Policy Document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_OwnerPolicy_DoNotTouch");
                #endregion


                Reports.TestStep = "Select the document Right-Click and select 'PhraseView/Edit' option from context";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();

                //Support.AreEqual("04-13-2016", (FastDriver.NextGenDocumentRepository.Policy_EffectiveDate.GetAttribute("Text").ToString()));
                Support.AreEqual("Sales Liability: $9,000.00", FastDriver.NextGenDocumentRepository.SalesLiability.FAGetText());
                FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.FASetText("52AB245");
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();

                Reports.TestStep = "Verify the Lender Policy is added with the Title Report document";
                FastDriver.NextGenDocumentRepository.Open();
                Support.AreEqual("Title Reports", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Type", TableAction.GetText).Message);
                Support.AreEqual("Lender Policy", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Type", TableAction.GetText).Message);
                Support.AreEqual("Owner Policy", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Type", TableAction.GetText).Message);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0021
        [TestMethod]
        [Description("Alternate Course 20:  Create/Save Endorsement")]
        public void REG0021()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 20:  Create/Save Endorsement";

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN500", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");

                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFileWithNewLoan() || FAST_CreateFile(), "File created successfully");

                #region Add Document
                Reports.TestStep = "Add Document";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_TitleReports_DoNotTouch", "SAN_NEXTGEN_16_TitleReports");
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_LenderPolicy_DoNotTouch", "SAN_NEXTGEN_16_LenderPolicy");
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "SAN_NEXTGEN_16_EndorsementGuarantee");
                #endregion


                Support.AreEqual("Title Reports", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_16_TitleReports", "Type", TableAction.GetText).Message);
                Support.AreEqual("Lender Policy", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_16_LenderPolicy", "Type", TableAction.GetText).Message);
                Support.AreEqual("Endorsement/Guarantee", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_16_EndorsementGuarantee", "Type", TableAction.GetText).Message);




            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0022
        [TestMethod]
        [Description("Alternate Course 21:  Create/Edit Endorsement")]
        public void REG0022()
        {
            try
            {
                Reports.TestDescription = "Alternate Course 21:  Create/Edit Endorsement";

                // Pre-Condition
                //LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                //LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN500", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");

                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFileWithNewLoan() || FAST_CreateFile(), "File created successfully");

                #region Add Document
                Reports.TestStep = "Select the document from context";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.CreateEditDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch");
                //FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(templateDescription: "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch");
                #endregion


                #region Get value of data element
                Reports.TestStep = "Get value of data element";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.RefreshDocument);
                //var dataElement = FastDriver.NextGenDocumentRepository.DataElement("Buyer Contact: Name");
                var dataElement = FastDriver.NextGenDocumentRepository.DataElement("Buyer Name(s)");
                var priorValue = dataElement["Input"].FAGetText();

                #region Edit value of any data element and click on "Save" Button
                Reports.TestStep = "Edit value of any data element and click on \"Save\" Button";
                var editedBuyerFirstName = "Edited-Buyer-First-Name";
                dataElement["Input"].FASetText(editedBuyerFirstName);
                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);
                #endregion


                Reports.TestStep = "Click Done";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FADoubleClick();


                #endregion


                FastDriver.NextGenDocumentRepository.Open();


                Support.AreEqual("Endorsement/Guarantee", FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Type", TableAction.GetText).Message);




            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        #endregion

        #region REG0023
        [TestMethod]
        [Description("Alternate Course 23:  Linking Endorsement to Policy")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
        public void REG0023()
        {
            try
            {
                string documentTable;

                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Alternate Course 23:  Linking Endorsement to Policy";
                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                //#region Navigate to NextGen Document Preparation Screen
                //Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                //FastDriver.NextGenDocumentPreparation.Open();
                //#endregion

                // Pre-Condition

                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN400", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN500", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");
                LoadTemplateOrCreateNew("SAN-NEXTGEN700", "NEXTGEN_SAN_Policy_w/o_Title Reports", "Policy w/o Title Reports");

                //Work with the following service to create phrase, phrase group and template.

                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Title-NXTGN11", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Lender-NXTGN11", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Owner-NXTGN11", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                //Phrase_phraseGrp_Template("ANAN", "Endorsement Phrase[ENDORSE]", "EndorsementGuarantee-NXTGN11", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");
                //Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_Policy_w/o_Title Reports", "Policy w/o Title Reports");


                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select Multiple templates (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion


                #region Search for templates using search criteria
                Reports.TestStep = "Search for Policy_w/o_Title Reports using search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion



                #region Select the template by using "Ctrl" command
                Reports.TestStep = "Select the template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();


                var documentsEndo = new List<string> { "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documentsEndo);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select any Policy from the grid
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Highlight(8);

                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.GetRowCount(), 1, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.GetRowCount(), 1, TableAction.GetCell).Element.FADoubleClick();


                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.Highlight(3);
                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.FADoubleClick();
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for Policy_w/o_Title Reports template using search criteria
                Reports.TestStep = "Search for Policy_w/o_Title Reports using search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Policy w/o Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion



                #region Select the template by using "Ctrl" command
                Reports.TestStep = "Select the template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();


                var Policywo = new List<string> { "NEXTGEN_SAN_Policy_w/o_Title Reports" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, Policywo);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_Policy_w/o_Title Reports", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for Endorsement/Guarantee template using search criteria
                Reports.TestStep = "Search for Policy_w/o_Title Reports using search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Select the template by using "Ctrl" command
                Reports.TestStep = "Select the template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                var documentsEndo2 = new List<string> { "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documentsEndo2);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select any Policy from the grid
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Highlight(3);

                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.GetRowCount(), 1, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.GetRowCount(), 1, TableAction.GetCell).Element.FADoubleClick();

                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.Highlight(3);
                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0024
        [TestMethod]
        [Description("Alternate Course 23:  Remove Associated Document from Package ")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0024()
        {
            string Message;

            EnableSavingIRSamples();
            SetSilverlightClipboardPermission_YES();

            Reports.TestDescription = "Alternate Course 23:  Create First Associated Document Package ";

            Reports.TestStep = "Login to ADM site";
            FAST_Login_ADM(isSuperUser: false);
            try
            {
                FAST_OpenRegionOrOffice(officeId);
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));

            }

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion


            #region Pre- Condition
            Reports.TestDescription = "Create a template";

            LoadTemplateOrCreateNew("NWTM", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");

            // Work with the following service to create phrase, phrase group and template.

            //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Title-NWTM1", "APR Endorse Template", "Title Reports");
            #endregion

            #region  File Side

            Reports.TestStep = "Create a Basic File";
            FAST_Login_IIS(regionId: regionId);
            FAST_OpenRegionOrOffice(officeId);
            Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
            #endregion

            #region Navigate to Document Repository Screen
            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.NextGenDocumentRepository.Open();
            #endregion

            #region Search a template
            Reports.TestStep = "Search Template by click on search button";
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").Highlight();
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").FAClick();
            //  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
            Playback.Wait(6000);
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            #endregion


            #region Search for templates using search criteria
            Reports.TestStep = "Search for templates using search criteria(with all fiter and title reports)";
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            // FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
            // FastDriver.NextGenDocumentRepository.SearchScope.FindElement(By.Id("ddTemplTypes")).FASelectItem("Title Reports");
            FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FAFindElement(ByLocator.Id, "ddcl-ddl_sources").FADoubleClick();
            FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
            FastDriver.NextGenDocumentRepository.QASandpoint.FASetCheckbox(true);

            FastDriver.NextGenDocumentRepository.TemplateDescription.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_ALL_0.FASetCheckbox(true);
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 40);
            Playback.Wait(15000);
            #endregion

            var documents = new List<string> { "NEXTGEN_SAN*" };
            FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);

            #region  Right Click
            Reports.TestStep = "Hold Right Click";
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
            #endregion


            #region Select "Create Document" option
            Reports.TestStep = "Select Create Document option from the context menu";
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            #endregion

            #region Repeat the Process for more Document

            #region Navigate to Document Repository Scree--1
            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.NextGenDocumentRepository.Open();
            #endregion

            #region Click on "Template Search" button      --1
            Reports.TestStep = "Click on \"Template Search\" button";
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").Highlight();
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").FAClick();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            #endregion

            #region Search for templates using search criteria         --1
            Reports.TestStep = "Search for templates using search criteria";
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            #endregion

            #region Select a template by using "Ctrl" command     --1
            Reports.TestStep = "Select one template by using \"Ctrl\" command";
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            var documents1 = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
            FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents1);
            #endregion

            #region Hold Right Click   --1
            Reports.TestStep = "Hold Right Click";
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
            #endregion

            #region Select "Create Document" option    --1
            Reports.TestStep = "Select \"Create Document\" option";
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            #endregion

            //// Again Creating another document
            #region Navigate to Document Repository Screen  -2
            Reports.TestStep = "Navigate to Document Repository Screen";
            FastDriver.NextGenDocumentRepository.Open();
            #endregion

            #region Search a template   -2
            Reports.TestStep = "Search Template by click on search button";
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").Highlight();
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").FAClick();
            // FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            #endregion


            #region Search for templates using search criteria  -2
            Reports.TestStep = "Search for templates using search criteria(with all fiter and title reports)";
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            // FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
            // FastDriver.NextGenDocumentRepository.SearchScope.FindElement(By.Id("ddTemplTypes")).FASelectItem("Title Reports");
            FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FAFindElement(ByLocator.Id, "ddcl-ddl_sources").FADoubleClick();
            FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
            FastDriver.NextGenDocumentRepository.QASandpoint.FASetCheckbox(true);
            FastDriver.NextGenDocumentRepository.TemplateDescription.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_ALL_0.FASetCheckbox(true);
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            #endregion

            var documents_1 = new List<string> { "NEXTGEN_SAN*" };
            FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents_1);

            #region  Right Click     -2
            Reports.TestStep = "Hold Right Click";
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
            #endregion


            #region Select "Create Document" option -2
            Reports.TestStep = "Select Create Document option from the context menu";
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            #endregion

            #region Select Multiple templates (2 or more) by using "Ctrl" command
            Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
            //      FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
            var documents3 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch" };
            FastDriver.NextGenDocumentRepository.SelectAllDocuments();
            //FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents3);
            #endregion
            #endregion


            #region   "Highlight two or more documents and Right Click"
            Reports.TestStep = "Highlight two or more documents and Right Click";
            FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
            #endregion

            #region    Click on "Add to Associate Package and MOdify it"

            Reports.TestStep = "Click on Add to Associate Package";
            FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

            if (FastDriver.NextGenDocumentRepository.AssociatePackages.Exists() == true)
            { FastDriver.NextGenDocumentRepository.AssociatePackages.FAClick(); }

            Reports.TestStep = "Modify the name of  Associate Package";
            FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("Modified-associated-Package0");
            FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick(); Playback.Wait(10000);
            #endregion

            #region Click on "OK" button in the Alert Message box
            Message = "new modified pakcage";
            string mesg = "Package : " + "'" + Message + "'" + " created successfully.";
            Support.AreEqual(mesg, "Package : 'new modified pakcage' created successfully.");
            Reports.TestStep = "Click on ok";
            FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
            #endregion


            #region Click on "PACKAGES" link
            Reports.TestStep = "Click on \"PACKAGES\" link";
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            //TODO: check if Packages tab is expanded. If not, expand it
            // if(FastDriver.NextGenDocumentRepository.PackagesTree.IsDisplayed())    // expand Packages tab
            //   FastDriver.NextGenDocumentRepository.Packages.FAClick();

            #endregion

            #region Select the package created in the above steps and verify the documents
            Reports.TestStep = "Select the package created in the above steps and verify the documents";
            var package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("NEXTGEN_SAN_TitleReports_DoNotTouch");
            var packageContent = package.GetAttribute("textContent");
            Support.AreEqual("True", packageContent.Contains("NEXTGEN_SAN_TitleReports_DoNotTouch").ToString(), "Package contains Modified-associated-Package0");

            package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("NEXTGEN_SAN_TitleReports_DoNotTouch", true);
            #endregion


            #region      If package has minimum of three documents ,user optionally highlights a document Right click and clicks the Remove button.

            Reports.TestStep = "Right click on Remove.";
            if (packageContent.Contains("NEXTGEN_SAN_TitleReports_DoNotTouch"))
            {
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle1.Highlight();
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle1.FARightClick();
            }


            FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Remove1.Highlight();
            FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Remove1.FAClick();
            Playback.Wait(15000);
            #endregion


            #region "System displays the Remove Document Association confirmation message.".

            Reports.TestStep = "Verify System displays the Remove Document Association confirmation message. ";
            //Document removed from AssociateDocPackage successfully. Name of Package: ModifiedID of the Package: 15869262
            string Message1 = "Remove 'NEXTGEN_SAN_LenderPolicy_DoNotTouch' from 'Modified-associated-Package0' ?";
            FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message1);
            Playback.Wait(10000);

            Support.MessageHandler(true);
            #endregion


            #region Verify system removes the document package from the Associate Docs tab.
            Reports.TestStep = "Verify system removes the document from the Associate Docs tab.";
            package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("Modified-associated-Package0");
            packageContent = package.GetAttribute("textContent");
            Support.AreEqual("True", packageContent.Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString(), "Package is removed.");
            #endregion

            ////
            #region  If package contains only two documents , if user optionally highlights a document Right Click and clicks the Remove button
            Reports.TestStep = "If package contains only two documents , if user optionally highlights a document Right Click and clicks the Remove button";
            var packagenew = FastDriver.NextGenDocumentRepository.FindAssociatePackage("Modified-associated-Package0");
            var packageContentnew = packagenew.GetAttribute("textContent");
            Support.AreEqual("True", packageContentnew.Contains("NEXTGEN_SAN_TitleReports_DoNotTouch").ToString(), "Package contains Modified-associated-Package0");

            Reports.TestStep = "Right click on Remove.";
            if (packageContentnew.Contains("NEXTGEN_SAN_TitleReports_DoNotTouch"))
            {
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle1.Highlight();
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle1.FARightClick();
            }

            FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Remove1.Highlight();
            FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Remove1.FAClick();
            Playback.Wait(15000);


            #region "System displays the Remove Document Association confirmation message.".
            string packagenam = "Modified-associated-Package0";
            // Remove Docs From Associate Docs Package failed. Reason: Minimum 2 Documents are required to be present in a Associate Docs Package.Name of the Package: ModifiedID of the Package: 15869262
            Reports.TestStep = "Verify System displays the Remove Document Association confirmation message. ";
            string Message2 = "Remove 'NEXTGEN_SAN_EscrowInstruction_DoNotTouch' from 'Modified-associated-Package0' ?";
            FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message2);
            Playback.Wait(15000);
            Support.MessageHandler(true);

            #endregion


            #region Verify system removes the document package from the Associate Docs tab.
            Reports.TestStep = "Verify system removes the document from the Associate Docs tab.";
            package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("Modified-associated-Package0");
            packageContent = package.GetAttribute("textContent");
            Support.AreEqual("True", packageContent.Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString(), "Package is removed.");
            #endregion

            #region Verify System logs the package removal event in the file’s Event Log.
            try { FastDriver.EventTrackingLog.Open(); }
            catch { FastDriver.EventTrackingLog.Open(); Playback.Wait(5000); FastDriver.EventTrackingLog.WaitForScreenToLoad(); }
            FastDriver.EventTrackingLog.EventTable.Highlight(3);
            string strEvent = FastDriver.EventTrackingLog.EventTable.FAGetText();
            Support.Match("\\[Remove Docs From Associate Docs Package\\]", strEvent);
            Support.Match("\\[Remove Docs From Associate Docs Package\\]", strEvent);
            #endregion


            #endregion

        }



        #endregion

        #region REG0025_26_27
        [TestMethod]
        [Description("Alternate Course 24:  Create Additional Document Package / Alternate Course 25:  Prevent Creation of New Document Package with Only One Document / Alternate Course 26:  Add a Document to an Existing Document Package")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
        public void REG0025_26_27()
        {
            try
            {
                string Message, msg;

                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Alternate Course 24:  Create Additional Document Package / Alternate Course 25:  Prevent Creation of New Document Package with Only One Document / Alternate Course 26:  Add a Document to an Existing Document Package";
                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN400", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN500", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");


                //Work with the following service to create phrase, phrase group and template.

                // Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Title-NXTGN11", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Lender-NXTGN11", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Owner-NXTGN11", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                //Phrase_phraseGrp_Template("ANAN", "Endorsement Phrase[ENDORSE]", "EndorsementGuarantee-NXTGN11", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");
                // Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch10", "Escrow Instruction");


                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "BAT0026: Prevent Creation of New Document Package with Only One Document";

                #region Navigate to Document Repository Screen

                Reports.TestStep = "BAT0026: Prevent Creation of New Document Package with Only One Document";
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select a templates by using "Ctrl" command
                Reports.TestStep = "Select one template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documentsEndorse = new List<string> { "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documentsEndorse);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion


                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                #endregion


                #region Select "Click on "Add to Associate Package"
                Reports.TestStep = "Select \"Add to Associate Package\" option";
                FastDriver.NextGenDocumentRepository.AddAssociatePkg.FASelectContextMenuItem();
                #endregion

                #region "System should not allow to create new package because only one document selected".
                Reports.TestStep = "Verify System prevents creating an Associate Package with web message";

                Message = "Minimum two documents are required to Save a new package, please add two or more documents to the package to save it.";

                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);


                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion




                #region Navigate to Document Repository Screen
                Reports.TestStep = "BAT0025: Create Additional Document Package";
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select a template by using "Ctrl" command
                Reports.TestStep = "Select one template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Perform ImageDoc Delivery and verify "Edit Document Name" functionality
                FastDriver.NextGenDocumentRepository.Open();


                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                // FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.FAClick();
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.JSClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                FastDriver.ImageDocDlg.markDraft.FASetCheckbox(true);
                FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.Deliver();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 400);
                #endregion


                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Select Multiple templates (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents1 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents1);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion




                #region Select Multiple Documents (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple Documents (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents2 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents2);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();

                string DocName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.GetCell).Element.FAGetText();

                #endregion

                #region Select "Hightlight two or more Documents and click on "Add to Associate Package"
                Reports.TestStep = "Select \"Add to Associate Package\" option";

                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion


                #region Get the Package Name
                FastDriver.NextGenDocumentRepository.AssociatePackages.FASetCheckbox(true);
                //FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("Associated package2" + FAKeys.Tab);
                msg = "";
                msg = FastDriver.NextGenDocumentRepository.AssociatePackagesName.FAGetValue();
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();

                #endregion

                #region "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully".
                Reports.TestStep = "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully";
                Message = "";
                Message = "Package : " + "'" + msg + "'" + " created successfully.";

                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);

                #endregion

                #region "Verify Name of the associated documents package should be same as name of the first document".
                Reports.TestStep = "Verify Name of the associated documents package should be same as name of the first document";
                string AssocitePackageParent = FastDriver.NextGenDocumentRepository.AssociateDocumentPackageParent.FAGetText();
                Support.AreEqual(DocName, AssocitePackageParent, true);


                #endregion


                #region Select Multiple Documents (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple Documents (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.Open();

                var documents21 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents21);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();



                #endregion

                #region Select "Hightlight two or more Documents and click on "Add to Associate Package"
                Reports.TestStep = "Select \"Add to Associate Package\" option";

                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion


                #region Get the Package Name
                FastDriver.NextGenDocumentRepository.AssociatePackages.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("Associated package2" + FAKeys.Tab);
                msg = "";
                msg = FastDriver.NextGenDocumentRepository.AssociatePackagesName.FAGetValue();
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();
                #endregion


                #region "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully".
                Reports.TestStep = "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully";
                Message = "";
                Message = "Package : " + "'" + msg + "'" + " created successfully.";

                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);

                #endregion





                #region  Select the package created in the above steps and verify the documents
                Reports.TestStep = "Select the package created in the above steps and verify the documents";
                var package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("Associated package2");
                var packageContent = package.GetAttribute("textContent");
                //Support.AreEqual("True", packageContent.Contains("NEXTGEN_SAN_TitleReports_DoNotTouch").ToString(), "Package contains Associated package2");
                package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("Associated package2", true);
                #endregion



                #region   Rename the associated packeage name:
                Reports.TestStep = "Rename the associated package name:";
                package.FARightClick();
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Rename.FAMoveToElement();
                var Rename = FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Rename;

                var Renameaction = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).MoveToElement(Rename);
                Renameaction.DoubleClick().Perform();
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "editNode").FASendKeys("XYZZZZ");
                String RenamePackageName = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "editNode").FAGetValue();
                string length = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "editNode").GetAttribute("maxlength");
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "editNode").FASendKeys(FAKeys.Enter);
                //FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle_Edit.FASetText("");



                #region  Verify the length of the  Rename the associated packeage name text box

                Support.AreEqual("75", length, true);

                #endregion

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion



                #region Verify if the Renamed the associated packeage name does not change the name of the first document
                FastDriver.NextGenDocumentRepository.Open();
                Reports.TestStep = "Verify if the Renamed the associated packeage name does not change the name of the first document";

                DocName = "";
                DocName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.GetCell).Element.FAGetText();
                if (RenamePackageName != DocName)
                { Support.AreEqual("true", "true", "The Renamed the associated packeage name does not change the name of the first document", true); }

                #endregion


                #region Select Multiple Documents (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple Documents (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.Open();
                //FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents12 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents12);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();


                #endregion


                #region Verify Remove option in the Context Menu is Enabled or Disable.
                Reports.TestStep = "Verify if \"Remove\" option in the Context Menu is Enabled or Disabled.";
                FastDriver.NextGenDocumentRepository.Remove.Highlight(5);


                string RemoveRGB = FastDriver.NextGenDocumentRepository.Remove.FAGetAttribute("style");
                string CompareRGB = FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FAGetAttribute("style");

                if (RemoveRGB != CompareRGB && RemoveRGB == "color: rgb(168, 168, 168);")
                {

                    Support.AreEqual("True", "True", "Remove is Disabled");
                }

                #endregion


                #region Verify "Add to Associate Package" option in the Context Menu is Enabled or Disable.
                Reports.TestStep = "Verify if \"Add to Associate Package\" option in the Context Menu is Enabled or Disabled.";
                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.Highlight(5);
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.AddToAssociatePackage.IsEnabled().ToString(), true);
                #endregion

                #region Select "Hightlight two or more Documents and click on "Add to Associate Package"
                Reports.TestStep = "Select \"Add to Associate Package\" option";

                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion


                #region Modify Package Name
                FastDriver.NextGenDocumentRepository.AssociatePackages.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("Associated package21" + FAKeys.Tab);
                msg = "";
                msg = FastDriver.NextGenDocumentRepository.AssociatePackagesName.FAGetValue();
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();
                #endregion

                #region "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully".
                Reports.TestStep = "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully";
                Message = "";
                Message = "Package : " + "'" + msg + "'" + " created successfully.";

                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);

                #endregion

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();


                #region Select One Document by using "Ctrl" command
                FastDriver.NextGenDocumentRepository.Open();
                Reports.TestStep = "Select One Document by using \"Ctrl\" command";
                var documents3 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch" };

                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents3);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                #endregion


                #region Select "Click on "Add to Associate Package"
                Reports.TestStep = "Select \"Add to Associate Package\" option";
                FastDriver.NextGenDocumentRepository.AddAssociatePkg.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.AssociatePackagesRbtn.Highlight(3);

                FastDriver.NextGenDocumentRepository.AssociatePackagesRbtn.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.Highlight(3);
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FADoubleClick();
                #endregion
                #region "System should not allow to create new package because only one document selected".
                Reports.TestStep = "Verify System displays a message from web page as 'The document:XXXXX' already exists.' ";
                msg = "";
                msg = documents3[0].ToString();
                Message = "";
                Message = "The document : " + "'" + msg + "'" + " already exists.";

                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                Support.MessageHandler(true);


                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.AssociatePackages_Cancel.Highlight();
                FastDriver.NextGenDocumentRepository.AssociatePackages_Cancel.FADoubleClick();
                #endregion

                #region Select Multiple templates (2 or more) by using "Ctrl" command
                FastDriver.NextGenDocumentRepository.Open();

                var documents4 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents4);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Hightlight two or more Documents and click on "Add to Associate Package"
                Reports.TestStep = "Select \"Add to Associate Package\" option";

                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.AssociatePackages.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("Associated package3");
                msg = "";
                msg = FastDriver.NextGenDocumentRepository.AssociatePackagesName.FAGetValue();
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.Highlight();
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FADoubleClick();
                //FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                //FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #region "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully".
                Reports.TestStep = "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully";
                Message = "";
                Message = "Package : " + "'" + msg + "'" + " created successfully.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                Support.MessageHandler(true);

                #endregion


                #region Select Multiple templates (2 or more) by using "Ctrl" command
                Reports.TestStep = "BAT0027: Add a Document to an Existing Document Package.";
                FastDriver.NextGenDocumentRepository.Open();
                var documents5 = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents5);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Hightlight two or more Documents and click on "Add to Associate Package"
                Reports.TestStep = "Select \"Add to Associate Package\" option";

                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.AssociatePackagesRbtn3.Highlight(3);
                FastDriver.NextGenDocumentRepository.AssociatePackagesRbtn3.FASetCheckbox(true);

                msg = "";
                msg = FastDriver.NextGenDocumentRepository.AssociatePackagesRbtn3.FAGetValue();
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();
                // FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region "Verify System displays a confirmation web message as "documents added to: "xxxx" package successfully"".
                Reports.TestStep = "Verify System displays a confirmation web message as 'documents added to: 'xxxx' package successfully'";

                Message = "documents added to : " + "'" + msg + "'" + " package successfully.";

                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);


                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion



                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion


        #region REG0028

        [TestMethod]
        public void REG0028()
        {
            try
            {

                string Message, msg;

                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Alternate Course 29:  Resequence Documents in a Package";
                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN400", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN500", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");


                //Work with the following service to create phrase, phrase group and template.

                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Title-NXTGN11", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Lender-NXTGN11", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Owner-NXTGN11", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                //Phrase_phraseGrp_Template("ANAN", "Endorsement Phrase[ENDORSE]", "EndorsementGuarantee-NXTGN11", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");
                //Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");


                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");


                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select a template by using "Ctrl" command
                Reports.TestStep = "Select one template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Select Multiple templates (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents1 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents1);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Select Multiple templates (3 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple Documents (3 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents2 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents2);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Hightlight two or more Documents and click on "Add to Associate Package"
                Reports.TestStep = "Select \"Add to Associate Package\" option";

                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region  Select the associated package  and remove name by backspace
                Reports.TestStep = "Select Asso. Package";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.AssociatePackages.Exists() == true)
                { FastDriver.NextGenDocumentRepository.AssociatePackages.FASetCheckbox(true); }
                FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("Associated package2" + FAKeys.Tab);
                msg = FastDriver.NextGenDocumentRepository.AssociatePackagesName.FAGetValue();
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();
                #endregion

                #region "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully".
                Reports.TestStep = "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully";
                Message = "Package : " + "'" + msg + "'" + " created successfully.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                Support.MessageHandler(true);
                //Support.MessageHandler(true);
                //FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FADoubleClick();
                //FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                //if(FastDriver.NextGenDocumentRepository.AssociatePackagesName.Exists()) { FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FADoubleClick(); }
                //FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                //#region Click on "PACKAGES" link
                //Reports.TestStep = "Click on \"PACKAGES\" link";
                //FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                ////TODO: check if Packages tab is expanded. If not, expand it
                //if(FastDriver.NextGenDocumentRepository.PackagesTree.IsDisplayed())
                //      FastDriver.NextGenDocumentRepository.Packages.FAClick();
                //#endregion

                #region  Select the package created in the above steps and verify the documents
                Reports.TestStep = "Select the package created in the above steps and verify the documents";
                var package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("Associated package2");
                var packageContent = package.GetAttribute("textContent");
                //Support.AreEqual("True", packageContent.Contains("NEXTGEN_SAN_TitleReports_DoNotTouch").ToString(), "Package contains Associated package2");
                package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("Associated package2", true);
                #endregion

                #region   Rename the associated packeage name:
                Reports.TestStep = "Rename the associated packeage name:";


                package.FARightClick();

                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "aDocSubMenu").FAFindElement(ByLocator.XPath, "//a[@href='#Rename']").Highlight(10);
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Rename.FAMoveToElement();
                var Rename = FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Rename;

                var Renameaction = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).MoveToElement(Rename);
                Renameaction.DoubleClick().Perform();


                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "editNode").FASendKeys("XYZZZZ");
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "editNode").FASendKeys(FAKeys.Enter);
                //FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle_Edit.FASetText("");
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
                FastDriver.NextGenDocumentRepository.Open();
                Reports.StatusUpdate("  package name saved by Moving away from the current window by Click on Document Repository link", true);
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        #endregion

        #region REG0029
        [TestMethod]
        [Description("Alternate Course 28:  Remove a Document Package from the Associate Docs Tab")]

        public void REG0029()
        {
            try
            {
                string Message, msg;

                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Alternate Course 28:  Remove a Document Package from the Associate Docs Tab";
                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                try
                {
                    FAST_OpenRegionOrOffice(officeId);
                }

                catch (Exception ex)
                {
                    FailTest(GetExceptionInfo(ex));

                }
                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN400", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN500", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");


                //Work with the following service to create phrase, phrase group and template.

                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Title-NXTGN11", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Lender-NXTGN11", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Owner-NXTGN11", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                //Phrase_phraseGrp_Template("ANAN", "Endorsement Phrase[ENDORSE]", "EndorsementGuarantee-NXTGN11", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");
                //Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");


                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");


                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select a template by using "Ctrl" command
                Reports.TestStep = "Select one template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Select Multiple templates (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents1 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents1);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Select Multiple templates (3 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple Documents (3 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents2 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents2);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Hightlight two or more Documents and click on "Add to Associate Package"
                Reports.TestStep = "Select \"Add to Associate Package\" option";

                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.AssociatePackages.FASetCheckbox(true);

                FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("Associated package2" + FAKeys.Tab);
                msg = FastDriver.NextGenDocumentRepository.AssociatePackagesName.FAGetValue();
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();
                #endregion

                #region "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully".
                Reports.TestStep = "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully";
                Message = "Package : " + "'" + msg + "'" + " created successfully.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Select the package in the pacakges menu Right Click
                Reports.TestStep = "Verify Select the package in the pacakges menu Right Click";
                #endregion

                #region Click on "PACKAGES" link
                Reports.TestStep = "Click on \"PACKAGES\" link";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                if (FastDriver.NextGenDocumentRepository.PackagesTree.IsDisplayed())
                    FastDriver.NextGenDocumentRepository.Packages.FAClick();
                #endregion

                #region Select the package created in the above steps and verify the documents

                #endregion
                Reports.TestStep = "Select the package created in the above steps and verify the documents";
                var package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("Associated package2");
                var packageContent = package.GetAttribute("textContent");

                #region
                Reports.TestStep = "Right click on Remove.";
                if (packageContent.Contains("Associated package2"))
                {
                    FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle.Highlight();
                    FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle.FARightClick();
                }

                msg = FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle.FAGetText().ToString();
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Remove.Highlight(3);
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Remove.FADoubleClick();

                #endregion

                #region "System displays the Remove Document Association confirmation message.".
                Reports.TestStep = "Verify System displays the Remove Document Association confirmation message. ";
                Message = "Remove Package " + "'" + msg + "'" + " ?";

                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);

                // Support.MessageHandler(true);

                #endregion


                #region "Verify if the package removed successfully.".
                Reports.TestStep = "Verify if the package removed successfully.";
                Message = "'" + msg + "'" + " removed successfully.";

                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);

                // Support.MessageHandler(true);

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion



                #region Verify system removes the document package from the Associate Docs tab.
                Reports.TestStep = "Verify system removes the document package from the Associate Docs tab.";
                package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("Associate Document Packages");
                packageContent = package.GetAttribute("textContent");
                Support.AreEqual("False", packageContent.Contains("Associated package2").ToString(), "Package is removed.");

                #endregion

                #region Verify System logs the package removal event in the file’s Event Log.
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventTable.Highlight(3);
                string strEvent = FastDriver.EventTrackingLog.EventTable.FAGetText();
                Support.Match("\\[Associated Documents Package Removal\\].+Package deleted successfully", strEvent);
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0030
        [TestMethod]
        [Description("Alternate Course 29:  Resequence Documents in a Package")]

        public void REG0030()
        {
            try
            {
                string Message, msg;

                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Alternate Course 29:  Resequence Documents in a Package";
                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN400", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN500", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");


                //Work with the following service to create phrase, phrase group and template.

                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Title-NXTGN11", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Lender-NXTGN11", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Owner-NXTGN11", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                //Phrase_phraseGrp_Template("ANAN", "Endorsement Phrase[ENDORSE]", "EndorsementGuarantee-NXTGN11", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");
                //Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");


                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");


                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select a template by using "Ctrl" command
                Reports.TestStep = "Select one template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion


                #region Select Multiple templates (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents1 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents1);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Select Multiple Documnets (3 or more) by using "Ctrl" command in Document Table
                Reports.TestStep = "Select Multiple Documents (3 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents2 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents2);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Hightlight two or more Documents and click on "Add to Associate Package"
                Reports.TestStep = "Select \"Add to Associate Package\" option";

                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Done";
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FADoubleClick();
                #endregion
                #region Click on "OK" button in the Alert Message box and verify the messgage
                Reports.TestStep = "Click on \"OK\" button in the Alert Message box";
                Message = "Please select an option.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                Support.MessageHandler(true);

                #endregion

                #region  Select the associated package  and remove name by backspace
                Reports.TestStep = "Select Asso. Package";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.AssociatePackages.Exists() == true)
                { FastDriver.NextGenDocumentRepository.AssociatePackages.FASetCheckbox(true); }

                FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("" + FAKeys.Backspace);
                Reports.TestStep = "Click on Done";
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();
                Reports.TestStep = "System displays a web message as 'Associate package name is required' ";
                Message = "Associate package name is required";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                Support.MessageHandler(true);

                #endregion
                #region
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.AssociatePackages.FASetCheckbox(true);

                FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("Associated package2" + FAKeys.Tab);
                msg = FastDriver.NextGenDocumentRepository.AssociatePackagesName.FAGetValue();
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();
                #endregion

                #region "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully".
                Reports.TestStep = "Verify System displays confirmation that 'Package: 'xxxxxxx' created successfully";
                Message = "Package : " + "'" + msg + "'" + " created successfully.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Click on "PACKAGES" link
                Reports.TestStep = "Click on \"PACKAGES\" link";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                //TODO: check if Packages tab is expanded. If not, expand it
                if (FastDriver.NextGenDocumentRepository.PackagesTree.IsDisplayed())
                    FastDriver.NextGenDocumentRepository.Packages.FAClick();
                #endregion

                #region Using drag and drop Resequence documents in the package.
                var package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("NEXTGEN_SAN_TitleReports_DoNotTouch");
                var packageContent = package.GetAttribute("textContent");

                Reports.TestStep = "Using drag and drop Resequence documents in the package.";
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle1.Highlight();
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle2.Highlight();
                FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle2.FADragAndDrop(FastDriver.NextGenDocumentRepository.AssociateDocumentPackageEle1);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0031
        [TestMethod]

        [DeploymentItem(@"Common\Support\PDFSigQFormalRep.pdf")]
        [DeploymentItem(@"Common\Support\DPUC0005_Maintain_Phrase.doc")]
        [DeploymentItem(@"Common\Support\NexGen_Report.xlsx")]
        [DeploymentItem(@"Common\Support\TiFF1.tif")]
        [DeploymentItem(@"Common\Support\imagesJPG.jpg")]

        [Description("Alternate Course 30:  Search Results Filter")]

        public void REG0031()
        {
            try
            {
                //string Message, msg;


                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                SetDisplayPDFinBrowser_ON();


                Reports.TestDescription = "Alternate Course 30:  Search Results Filter";


                try
                {
                    #region DataSetup
                    var credentials = new Credentials()
                    {
                        UserName = AutoConfig.UserName,
                        Password = AutoConfig.UserPassword
                    };
                    #endregion

                    #region Login to FAST Application File Side
                    Reports.TestStep = "Login to FAST Application File Side";
                    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                    Reports.TestStep = "Navigate to Select Office screen";
                    //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                    FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                    Reports.TestStep = "Navigate to NextGen Region/Office Level";
                    FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                    var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                    if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                        throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                    #endregion

                    #region CreateFile
                    string fileNumber = "";
                    try
                    {
                        Reports.TestStep = "Create File using web service.";
                        var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                        nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                        nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                        nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                        nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                        nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                        nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                        fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                        FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);



                    }
                    catch //If not able to create file via web service, create file via FAST GUI
                    {
                        Reports.TestStep = "Create File using FAST GUI.";
                        FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                        try
                        {
                            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                        }
                        catch
                        {
                            Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                        }

                        FastDriver.QuickFileEntry.CreateStandardFile();
                        FastDriver.TopFrame.SwitchToTopFrame();
                        FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                        fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                    }
                    #endregion

                    #region  Navigate to Document Repository Screen
                    Reports.TestStep = "Navigate to Document Repository Screen";
                    FastDriver.NextGenDocumentRepository.Open();
                    #endregion

                    #region Create different types of Documents in File Documents Landing Page
                    FastDriver.NextGenDocumentRepository.CreateAllTypesofDocs();
                    #endregion

                    #region  Navigate to Document Repository Screen
                    Reports.TestStep = "Navigate to Document Repository Screen";
                    FastDriver.NextGenDocumentRepository.Open();
                    #endregion


                    #region Upload all different types of files.(Example: PDF, Word, Excel, Tiff, JPG etc.)
                    Reports.TestStep = "Upload all different types of files.(Example: PDF, Word, Excel, PNG, JPG etc.)";
                    FastDriver.NextGenDocumentRepository.UploadAllTypesofFiles();
                    #endregion

                    #region Filter Service
                    FastDriver.NextGenDocumentRepository.REG0031_Filter();
                    #endregion



                }
                catch (Exception ex)
                {

                    FailTest(ex.Message);
                }


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion


        #region REG0032
        [TestMethod]
        [Description("Alternate Course 31:  Change Document Name – Images Only")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
        public void REG0032()
        {
            try
            {
                string documentTable;

                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Alternate Course 31:  Change Document Name – Images Only";
                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                try
                {
                    FAST_OpenRegionOrOffice(officeId);
                }
                catch (Exception ex)
                {
                    FAST_OpenRegionOrOffice(officeId);
                }

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                // Pre-Condition

                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN400", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN500", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");

                // Work with the following service to create phrase, phrase group and template.

                //Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Title-NXTGN11", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Lender-NXTGN11", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Owner-NXTGN11", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                //Phrase_phraseGrp_Template("ANAN", "Endorsement Phrase[ENDORSE]", "EndorsementGuarantee-NXTGN11", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");


                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select Multiple templates (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documents = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for Policy_w/o_Title Reports using search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select the template by using "Ctrl" command
                Reports.TestStep = "Select the template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();


                var documentsEndo = new List<string> { "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documentsEndo);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select any Policy from the grid
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Highlight(3);
                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.GetRowCount(), 1, TableAction.GetCell).Element.FADoubleClick();
                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.Highlight(3);
                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.FADoubleClick();
                #endregion



                #region Right click and Select ImageDoc from Deliver
                Reports.TestStep = "Select \"ImageDoc from  Deliver\" option";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Right click and Select ImageDoc from Deliver in Context Menu Items";

                FastDriver.NextGenDocumentRepository.DocumentsTable.Highlight(3);

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();

                #region Perform ImageDoc Delivery

                //  Assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);


                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.Highlight();

                //FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.FAClick();

                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.JSClick();

                #endregion


                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                FastDriver.ImageDocDlg.markDraft.FASetCheckbox(true);
                FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.Deliver();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 400);

                #endregion


                #region Double click on Imaged type column. Add name in Document text box and select any options in the drop down box.

                FastDriver.NextGenDocumentRepository.Open();
                Reports.TestStep = "Double click on Imaged type column. Add name in Document text box and select any options in the drop down box";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Imaged Document", "Type", TableAction.GetCell).Element.FADoubleClick();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.itemDocumentName.IsEnabled().ToString(), true);
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.itemDocTypeCDID.IsEnabled().ToString(), true);

                FastDriver.NextGenDocumentRepository.itemDocTypeCDID.FASelectItem("Escrow: Misc");
                string stritemDocTypeCDID = FastDriver.NextGenDocumentRepository.itemDocTypeCDID.FAGetSelectedItem();


                FastDriver.NextGenDocumentRepository.itemDocTypeName.Highlight(5);
                FastDriver.NextGenDocumentRepository.itemDocTypeName.FASelectItemBySendingKeys("Audit PKG");
                string stritemDocTypeName = FastDriver.NextGenDocumentRepository.itemDocTypeName.FAGetSelectedItem();

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(10, "Imaged", 7, TableAction.GetElementFromTableCell, "input").Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(10, "Imaged", 7, TableAction.GetElementFromTableCell, "input").Element.FASetText("Edit_PDF123");
                string stritemDocumentName = FastDriver.NextGenDocumentRepository.itemDocumentName.FAGetText();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Owner Policy", "Name", TableAction.GetCell).Element.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Verify Type and Document Name System automatically saves the modified changes to the imaged document";
                string DocType = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Imaged", "Type", TableAction.GetCell).Element.FAGetText();
                string DocName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Imaged", "Name", TableAction.GetCell).Element.FAGetText();
                Support.AreEqual("true", DocType.Contains(stritemDocTypeCDID).ToString(), true);
                Support.AreEqual("true", DocName.Contains(stritemDocumentName).ToString(), true);
                Support.AreEqual("true", DocName.Contains(stritemDocTypeName).ToString(), true);
                #endregion


                #region Click on Upload button
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();
                #endregion

                #region Browse document
                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\CECONTRACT_4438673_LEG.pdf";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);
                #endregion

                #region Save the PDF Document
                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is uploaded to the FAST
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Navigate to Home Warranty page and Enter GAB
                Reports.TestStep = "Navigate to Home Warranty screen and Enter GAB";
                FastDriver.HomeWarrantyDetail.Open();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                #endregion
                #region Enter Buyer and Seller charges
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("100" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("200" + FAKeys.Tab);

                FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FASetText("100" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FASetText("200" + FAKeys.Tab);
                #endregion

                #region Navigate to "Active Disbursement"
                Reports.TestStep = "Navigate to \"Active Disbursement\" screen";

                FastDriver.ActiveDisbursementSummary.Open();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Status", @"Pending", "Status", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                #endregion
                #region Go to "Edit Disbursement"
                Reports.TestStep = "Go to \"Edit Disbursement\" screen";
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Select Disburse As: Wire";
                FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");

                Reports.TestStep = "Enter mandatory highlighed fields under the Wire Details section";
                string Bank_Number = FastDriver.EditDisbursement.FromAccount.FAGetText().ToString();

                FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("1234567");
                FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText(Bank_Number);
                FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText(Bank_Number);

                Reports.TestStep = "Add Escrow: Payoff/Demand bill document under Wire Instructions";

                FastDriver.EditDisbursement.Add.FAClick();
                Reports.TestStep = "Select the wire Instruction Doc.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Select Wire Instructions", timeoutSeconds: 10);
                FastDriver.SelectWireInstructionsDlg.SwitchToDialogContentFrame();
                FastDriver.SelectWireInstructionsDlg.Instruction1.FASetCheckbox(true);
                FastDriver.SelectWireInstructionsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                #endregion





                #region Navigate to "Document Repository"
                Reports.TestStep = "Navigate to \"Document Repository\" screen";
                FastDriver.NextGenDocumentRepository.Open();


                #endregion

                #region Navigates to Search Results section of File Documents screen and created mulitple documents should be displayed in the list
                Reports.TestStep = "Navigates to Search Results section of File Documents screen and created mulitple documents should be displayed in the list";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Type", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Remove" option
                Reports.TestStep = "Select \"Remove\" option";
                FastDriver.NextGenDocumentRepository.Remove.FASelectContextMenuItem();
                #endregion

                #region Verify the error message
                Reports.TestStep = "Verify the error message";
                string Message = "";
                Message = "Document(s) Miscellaneous PDFDocument cannot be removed because it's attached to a created, pending or issued wire disbursement.Please remove from wire disbursement before removing the Document.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);




                FastDriver.NextGenDocumentRepository.Open();
                Reports.TestStep = "Double click on the Type Column of the document which is attached to a pending wire";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Type", TableAction.GetCell).Element.FADoubleClick();


                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.itemDocumentName.IsVisible().ToString(), false);
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.itemDocTypeCDID.IsVisible().ToString(), false);


                Reports.TestStep = "Right click on the Type Column of the document which is attached to a pending wire and verify \"Edit Document Name\" is enable or disabled.";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Type", TableAction.GetCell).Element.FARightClick();

                string EditdocNameRGB = FastDriver.NextGenDocumentRepository.EditDocumentName.FAGetAttribute("style");
                string CompareRGB = FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FAGetAttribute("style");

                if (EditdocNameRGB != CompareRGB && EditdocNameRGB == "color: rgb(168, 168, 168);")
                {

                    Support.AreEqual("True", "True", "Edit Document Name is Disabled");
                }

                Reports.TestStep = "Verify the Document Name text box is enabled or disbale in \"Change Type Dialog Box\"";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Type", TableAction.GetCell).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.Change_Type.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.EditDocumentDlg.EditDocumentNameDialog.Highlight(5);

                Reports.TestStep = "Verify controls are enabled or disabled in \"Edit Document\" Dialog.";

                Support.AreEqual("False", FastDriver.EditDocumentDlg.EditDocName.IsEnabled().ToString(), false);

                FastDriver.EditDocumentDlg.EditDocument_Done.FAClick();


                #endregion





            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion



        #region REG33_34_35
        [TestMethod]
        public void REG33_34_35()
        {
            try
            {
                Reports.TestDescription = "Verify import Recorded Documents";

                FAST_Login_IIS(regionId: regionId);

                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Import Recorded docs button
                Reports.TestStep = "Click on Import Recorded docs button";
                FastDriver.NextGenDocumentRepository.ImportedRecordedDocs.FAClick();
                #endregion

                #region Enter Recorded documents information
                Reports.TestStep = "Enter Recorded documents information";
                FastDriver.RecordedDocsDlg.WaitForScreenToLoad();
                FastDriver.RecordedDocsDlg.EnterRecordingInformation();



                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Navigate to document Repository
                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify recorded document in the document repository
                Reports.TestStep = "Verify recorded document in the document repository";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Assessment Map-45.7", "Miscellaneous");
                //var docStatus1 = FastDriver.NextGenDocumentRepository.WaitForDocument("Assessor Map-40.5", "Miscellaneous");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                //Support.AreEqual("True", docStatus1.ToString(), "Document exists on the table");

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region REG0038
        [TestMethod]
        [Description("Create First Real Time Mail Document Package and Perform Delivery ")]
        public void REG0038()
        {
            try
            {
                Reports.TestDescription = "Create First Real Time Mail Document Package";
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                #region FAST ADM Side
                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Template Creation on ADM Side
                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");

                //Work with the following service to create phrase, phrase group and template.

                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Title-NXTGN11", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                //Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                #endregion
                #endregion

                Reports.TestDescription = "Login to IIS Side";

                #region  Login to FAST File side, Create File and Navigate to NextGen DOC Repo.

                Reports.TestStep = "Login to IIS and Naviagte to NextGen DOC Screen";
                FAST_Login_IIS(regionId: regionId);
                try { FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); }
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(3000);
                //  FastDriver.LeftNavigation.Navigate<NextGenDocumentPreparation>("Home>System Maintenance>Document Preparation"); 
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").Highlight();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").FAClick();
                //  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FAFindElement(ByLocator.Id, "ddcl-ddl_sources").FADoubleClick();
                FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateDescription.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Create  Package

                Reports.TestStep = "Select one template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                Reports.TestStep = "Create Package";
                var documents = new List<string> { "NEXTGEN_SAN*" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);

                #region  Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 50);
                Playback.Wait(5000);
                #endregion

                Reports.TestStep = "Create Document";
                var documents1 = new List<string> { "NEXTGEN_SAN*" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents1);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                // FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                #region Create/ ADD to RTM Package
                FastDriver.NextGenDocumentRepository.AddToRTMPackage1.Highlight(10);
                FastDriver.NextGenDocumentRepository.AddToRTMPackage1.FASelectContextMenuItem();

                // FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "'contextMenuDocument").Highlight(10);

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 40); Playback.Wait(10000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region   Validate the message if package is not selected
                Reports.TestStep = "Validate the message if package is not selected";
                try
                {
                    FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                }
                catch { FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//div/div[@class='ui-dialog-buttonset']/button/span[text()='Done']").FADoubleClick(); }
                #endregion
                #endregion

                string mesg = "Please select an option.";
                Support.AreEqual(mesg, "Please select an option.");
                Reports.TestStep = "Click on ok";
                Support.MessageHandler(true);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #region Create a RTM Package
                Reports.TestStep = "Enter/Edit the RTM Package name";
                // FastDriver.NextGenDocumentRepository.EditpackageName.FASetText("New_RTM_Package1");
                FastDriver.NextGenDocumentRepository.EditpackageName.FASetText("New_RTM_Package1");

                FastDriver.NextGenDocumentRepository.RTMPakageRadio.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                Playback.Wait(10000);
                string Message = "Package : 'New_RTM_Package1' created successfully.";

                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                // Support.MessageHandler(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                ///************FastDriver.NextGenDocumentRepository.DoneRTMPackages.FADoubleClick();
                ////**************************************************************************************************************
                #endregion

                #region Verify  the Tab, Copies, and Color fields for data entry

                Reports.TestStep = "Verify  the Tab, Copies, and Color fields for data entry";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TabName.Exists(); FastDriver.NextGenDocumentRepository.TabName.FASetText("abc");
                FastDriver.NextGenDocumentRepository.Copies.Exists(); FastDriver.NextGenDocumentRepository.Copies.FASetText("2");
                FastDriver.NextGenDocumentRepository.Colourchk.Exists(); FastDriver.NextGenDocumentRepository.Colourchk.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion


                #region  Verify the Delivery  message before Address

                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("EMail"); Playback.Wait(6000);
                string MSG1 = "mail to / return to address missing. please add the address before delivery";
                //   FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: MSG1);

                #endregion

                #region Select Mail To address
                Reports.TestStep = "Select Mail To address";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.MailTo);
                FastDriver.NextGenDocumentRepository.MailTo.FAClick(); Playback.Wait(4000);
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.SelectAddresses);
                FastDriver.NextGenDocumentRepository.SelectAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                #endregion
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #region Select File Business Parties
                Reports.TestStep = "Select File Business Parties";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FileBusinessPartyTable.PerformTableAction(6, "Business Source", 1, TableAction.On);
                FastDriver.NextGenDocumentRepository.DoneSearchAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion


                #region Search GAB
                // Reports.TestStep = "Verify the search GAB properties";
                // FastDriver.NextGenDocumentRepository.SearchGAB.FAClick();
                // FastDriver.BusinessOrgSearchDlg.WaitForDialogToLoad();
                // FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //// FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                // FastDriver.BusinessOrgSearchDlg.WaitForDialogToLoad();
                // FastDriver.BusinessOrgSearchDlg.IDCode.FASetText("344");
                // FastDriver.BusinessOrgSearchDlg.Find.FAClick();
                // FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                // FastDriver.WebDriver.FindElement(By.Id("cmdCheckAll")).Highlight();


                #endregion

                #region  Verify the Selection of Return Sub-tab

                Reports.TestStep = "Verify the Selection of Return Sub-tab";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ReturnTo.FAClick(); Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.OfficeSelection);
                FastDriver.NextGenDocumentRepository.OfficeSelection.FASelectItemByIndex(1);
                #endregion

                #region  Verify the delivery after addresses    - ImageDoc
                Reports.TestStep = "Verify the delivery after addresses    - ImageDoc";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("ImageDoc");
                Playback.Wait(7000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                FastDriver.ImageDocDlg.markDraft.FASetCheckbox(true);
                FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.Deliver();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 300);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20); Playback.Wait(15000);
                #endregion

                #region Verify the Print Delivery
                Reports.TestStep = "Verify the Print Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Print");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintDlg.WaitForScreenToLoad(); Playback.Wait(5000);
                FastDriver.PrintDlg.SelectPrinter();
                Playback.Wait(15000);
                FastDriver.PrintDlg.PublishDocument.FASetCheckbox(true);
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 800);
                // FastDriver.WebDriver.WaitForWindowAndSwitch("Status...................", false, 50);

                Playback.Wait(15000);
                if (FastDriver.PrintDlg.Print.Exists()) { FastDriver.PrintDlg.Print.FADoubleClick(); }
                #endregion


                #region Verify the FAX Delivery
                Reports.TestStep = "Verify the FAX Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Fax");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FaxDlg.WaitForScreenToLoad();
                //FastDriver.FaxDlg.Insert.FAClick();
                //FastDriver.FaxDlg.FAXNumber.FASetText("7148001570");
                //FastDriver.FaxDlg.publishDocument.FASetCheckbox(true);
                //FastDriver.FaxDlg.Message.FASetText("Any Message");
                try { FastDriver.FaxDlg.SendFax(); FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Fax, 300); Playback.Wait(9000); }
                catch
                {
                    FastDriver.FaxDlg.Insert.FAClick();
                    FastDriver.FaxDlg.FAXNumber.FASetText("7148001570");
                    FastDriver.FaxDlg.publishDocument.FASetCheckbox(true);
                    FastDriver.FaxDlg.Message.FASetText("Any Message");
                    FastDriver.FaxDlg.FAX.FAClick();
                    FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Fax, 400);
                }
                if (FastDriver.FaxDlg.FAX.Exists()) { FastDriver.FaxDlg.FAX.FAClick(); }

                //FastDriver.WebDriver.WaitForWindowAndSwitch("Status...................", false, 40); 
                Playback.Wait(15000);
                #endregion


                #region Verify the Email Delivery
                Reports.TestStep = "Verify the Email Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("EMail");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.EmailDlg.WaitForDialogToLoad();
                try { FastDriver.EmailDlg.SendEmail(); FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Email, 300); Playback.Wait(15000); }
                catch
                {
                    FastDriver.EmailDlg.ToText.FASetText("rmodi@firstam.com");
                    FastDriver.EmailDlg.SellerNamecheckBox.FASetCheckbox(true);
                    FastDriver.EmailDlg.Message.FASetText("this is test mail");
                    FastDriver.EmailDlg.ToText.FASetText("rmodi@firstam.com");
                    FastDriver.EmailDlg.Email.FADoubleClick();
                    if (FastDriver.EmailDlg.Email.Exists()) { FastDriver.EmailDlg.Email.FAClick(); }
                    FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Email, 300);
                    //FastDriver.WebDriver.WaitForWindowAndSwitch("Status...................", false, 40);
                    Playback.Wait(15000);
                } Playback.Wait(15000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Verify the Preview Delivery
                Reports.TestStep = "Verify the Preview Delivery";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("Preview");
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Preview, 600);
                Playback.Wait(20000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 300);
                FastDriver.WebDriver.ClosePreviewWindow();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region REG0039
        [TestMethod]
        [Description("Create Additional Real Time Mail Document Package ")]
        public void REG0039()
        {
            try
            {
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                #region FAST ADM Side
                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Template Creation on ADM Side
                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");

                //Work with the following service to create phrase, phrase group and template.

                //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Title-NXTGN11", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                //Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                #endregion
                #endregion

                Reports.TestDescription = "Login to IIS Side";

                #region  Login to FAST File side, Create File and Navigate to NextGen DOC Repo.

                Reports.TestStep = "Login to IIS and Naviagte to NextGen DOC Screen";
                FAST_Login_IIS(regionId: regionId);
                try { FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); }
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open();

                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").Highlight();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").FADoubleClick();
                //  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FAFindElement(ByLocator.Id, "ddcl-ddl_sources").FADoubleClick();
                FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateDescription.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select one template by using \"Ctrl\" command

                Reports.TestStep = "Select one template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                Reports.TestStep = "Create Package";
                var documents = new List<string> { "NEXTGEN_SAN*" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region  Create Document
                Reports.TestStep = "Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                Playback.Wait(9000);
                #endregion


                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").Highlight();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").FAClick();
                //  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FindElement(By.Id("ddcl-ddl_sources")).FAClick();
                FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateDescription.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select one template by using \"Ctrl\" command

                Reports.TestStep = "Select one template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                Reports.TestStep = "Create Package";
                var documents_two = new List<string> { "NEXTGEN_SAN*" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents_two);
                #endregion

                #region  Creat Document
                Reports.TestStep = "Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                Playback.Wait(9000);
                #endregion

                Reports.TestStep = "Right Click for Context Menu";
                var documents1 = new List<string> { "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();


                #region Create/ ADD to RTM Package
                FastDriver.NextGenDocumentRepository.AddToRTMPackage.Highlight(5);
                try { FastDriver.NextGenDocumentRepository.AddToRTMPackage.FASelectContextMenuItem(); }
                catch { FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//ul[@id='contextMenuDocumentMulti']/li[@class='addtoRTMPackage']/a[@href='#addtoRTMPackage']").FASelectContextMenuItem(); }

                //  FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//ul[@id='contextMenuDocumentMulti']/li[@class='addtoRTMPackage']/a[@href='#addtoRTMPackage']").FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); Playback.Wait(15000);
                #endregion

                //#region   Validate the message if package is not selected
                //Reports.TestStep = "Validate the message if package is not selected";
                //try
                //{
                //  if(  FastDriver.NextGenDocumentRepository.RTMPakageRadio.IsSelected()== true)
                //      {
                //            FastDriver.NextGenDocumentRepository.RTMPakageRadio.FAClickAction();
                //      }
                //    FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick(); Playback.Wait(8000);
                //}
                //catch { FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//div/div[@class='ui-dialog-buttonset']/button/span[text()='Done']").FAClick(); }


                //string mesg = "Please select an option.";
                //Support.AreEqual(mesg, "Please select an option.");
                //Reports.TestStep = "Click on ok";
                //Support.MessageHandler(true);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
             

                #region  Enter/Edit the RTM Package name
                Reports.TestStep = "Enter/Edit the RTM Package name";

                FastDriver.NextGenDocumentRepository.EditpackageName.FASetText("New_RTM_Package1");

                FastDriver.NextGenDocumentRepository.RTMPakageRadio.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                string Message = "Package : " + "'" + "New_RTM_Package1" + "'" + " created successfully.";

                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);

                Playback.Wait(5000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 40);
                //Reports.TestStep = "Click On Done";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                //******************************************************************************************************
                #endregion

                #region Verify  the Tab, Copies, and Color fields for data entry
                Reports.TestStep = "Verify  the Tab, Copies, and Color fields for data entry";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TabName.Exists(); FastDriver.NextGenDocumentRepository.TabName.FASetText("abc");
                FastDriver.NextGenDocumentRepository.Copies.Exists(); FastDriver.NextGenDocumentRepository.Copies.FASetText("2");
                FastDriver.NextGenDocumentRepository.Colourchk.Exists(); FastDriver.NextGenDocumentRepository.Colourchk.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "txtTabName").Highlight(5);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick(); Playback.Wait(8000);
                #endregion


                #region   Click on Package Link and Right click on RTM package
                Reports.TestStep = "'Click on Package Link and Right click on RTM package";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.NextGenDocumentRepository.PackageLink.Highlight(3);


                FastDriver.NextGenDocumentRepository.PackageLink.SendKeys(FAKeys.Enter); Playback.Wait(3000);
                if (!FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "tree").IsDisplayed())
                {
                    CreateAssociatePackageNRemove("NEXTGEN_SAN*", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");

                }


                #region Create another Package
                Reports.TestStep = "Create another Package";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.RTMPackageLink.FARightClick();

                FastDriver.NextGenDocumentRepository.CreateNewPackage_RTM.Highlight(3);
                FastDriver.NextGenDocumentRepository.CreateNewPackage_RTM.FASelectContextMenuItem();
                Playback.Wait(3000);

                FastDriver.NextGenDocumentRepository.WebDriver.FindElement(By.Id("editNode")).FASetText("New R T M" + FAKeys.Enter);

                #endregion
                #endregion

                #region Add Document to New Package

                FastDriver.NextGenDocumentRepository.WebDriver.FindElement(By.Id("DocumentName")).FAClick();
                var Doc1 = FastDriver.NextGenDocumentRepository.DashboardDocuments;
                var RTM1 = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//div/ul/li[2]/ul/li[2]/span/span[contains(@class, 'dynatree-icon')]");
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FADragAndDrop(RTM1);

                Playback.Wait(8000);
                string RTMMessage1 = "Package : 'New R T M' created successfully.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: RTMMessage1);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Rename the package
                Reports.TestStep = "Rename the Package";
                //FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                //FastDriver.NextGenDocumentRepository.FirstRTMPackage.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.RTMPackage2_node.FARightClick();
                FastDriver.NextGenDocumentRepository.Context_Rename.FAClickAction();
                FastDriver.NextGenDocumentRepository.Rtm_EditName.FASetText("Modified" + FAKeys.Enter);

                #endregion

                #region Resequence :- Alternate Course 42:  Re-sequence Documents in a Package";
                Reports.TestStep = "Resequence the Doc in Packaage";
                Reports.TestDescription = "Alternate Course 42:  Re-sequence Documents in a Package";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (!FastDriver.NextGenDocumentRepository.FirstRTMPackage.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                }

                FastDriver.NextGenDocumentRepository.FirstRTMPackage.FAClick();
                FastDriver.NextGenDocumentRepository.RTMPackage1_Doc1node.Highlight(3);
                FastDriver.NextGenDocumentRepository.RTMPackage1_Doc2node.Highlight(3);
                var RTM2 = FastDriver.NextGenDocumentRepository.RTMPackage1_Doc1node;
                var RTM3 = FastDriver.NextGenDocumentRepository.RTMPackage1_Doc2node;
                FastDriver.NextGenDocumentRepository.RTMPackage1_Doc2node.FADragAndDrop(RTM2);
                // var dragdrop_new = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).DragAndDrop(RTM3, RTM2);
                // dragdrop_new.Perform();
                if (!FastDriver.NextGenDocumentRepository.RTMPackage1_Doc1node.IsDisplayed())
                { FastDriver.NextGenDocumentRepository.FirstRTMPackage.FAClick(); }
                string RTM_Doc1 = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//div[@id='tree']//a/ancestor::ul/li[2]/ul/li/ul/li[1]/span/a").FAGetText();
                Support.AreEqual(RTM_Doc1, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", true);

                //FastDriver.NextGenDocumentRepository.
                #endregion

                #region Modify the packages
                FastDriver.NextGenDocumentRepository.RTMPackage2_node.FARightClick();
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "RTMsubMenu").FAFindElement(ByLocator.XPath, "//li[2]/a[text()='Details']").FAClick();

                #region modify  the Tab, Copies, and Color fields for data entry
                Reports.TestStep = "modify  the Tab, Copies, and Color fields for data entry";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TabName.Exists(); FastDriver.NextGenDocumentRepository.TabName.FASetText("ABC Modify");
                FastDriver.NextGenDocumentRepository.Copies.Exists(); FastDriver.NextGenDocumentRepository.Copies.FASetText("4");
                FastDriver.NextGenDocumentRepository.Colourchk.Exists(); FastDriver.NextGenDocumentRepository.Colourchk.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ReturnTo.Exists();
                FastDriver.NextGenDocumentRepository.ReturnTo.FAClickAction(); Playback.Wait(5000);
                FastDriver.NextGenDocumentRepository.WebDriver.FindElement(By.Id("ddlretFileOffice")).FASelectItemByIndex(1);

                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClickAction();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                #endregion
                #endregion

                #region remove the  Packages;

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//div/ul/li[2]/ul/li[2]/span/a[contains(@class, 'dynatree-title')]").FARightClick();
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "RTMsubMenu").FAFindElement(ByLocator.XPath, "//li[3]/a[text()='Remove']").FAClick();

                string Message1 = "Remove Package 'Modified' ?";

                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message1);
                Playback.Wait(5000);
                // FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                string Message2 = "'Modified' removed successfully.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message2);
                #endregion

                #region  adding same document into the package
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); Playback.Wait(5000);
                if (!FastDriver.NextGenDocumentRepository.FirstRTMPackage.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                }
                var Doc2 = FastDriver.NextGenDocumentRepository.DashboardDocuments;
                var package1 = FastDriver.NextGenDocumentRepository.FirstRTMPackage;
                FastDriver.NextGenDocumentRepository.DashboardDocuments.FADragAndDrop(package1);
             

                string Warningmessage = "The document : 'NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch' already exists.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Warningmessage);
                Playback.Wait(3000);
                #endregion

                #region      Adding New Address through details :-- Alternative course : 43
                Reports.TestStep = "Adding New Address through details";

                FastDriver.NextGenDocumentRepository.RTMPackageLink.FARightClick();

                FastDriver.NextGenDocumentRepository.AddAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                Playback.Wait(4000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); FastDriver.NextGenDocumentRepository.Rtm_AddressName.Highlight(5);
                FastDriver.NextGenDocumentRepository.Rtm_AddressName.FASetText("FAI Bang ABCD");
                FastDriver.NextGenDocumentRepository.Rtm_Addressline1.FASetText("Street1");
                FastDriver.NextGenDocumentRepository.Rtm_AddressCity.FASetText("Santa Ana");
                FastDriver.NextGenDocumentRepository.Rtm_AddressState.FASelectItem("CA");
                FastDriver.NextGenDocumentRepository.Rtm_AddressZip.FASetText("56012");
                FastDriver.NextGenDocumentRepository.Rtm_AddressContactNo.FASendKeys(FAKeys.Tab);
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "dv_CreateNewRTMAddress").FAFindElement(ByLocator.XPath, "//input[contains(@onclick, 'SaveNewRecord()')]").FAClick();
                string AddingRTMAddress = "RTM Address saved successfully.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: AddingRTMAddress);
                // FastDriver.NextGenDocumentRepository.DivAddress.Highlight(10);
                FastDriver.NextGenDocumentRepository.CreateNewClose.FAClick();
                #endregion

                #region Selecting New Address through RTM address.
                Reports.TestStep = "Selecting New Address through RTM address.";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (!FastDriver.NextGenDocumentRepository.FirstRTMPackage.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.FirstRTMPackage);
                }
                // FastDriver.NextGenDocumentRepository.FirstRTMPackage.FARightClick();

                FastDriver.NextGenDocumentRepository.WebDriver.FindElement(By.XPath("//div/ul/li[2]/ul/li[1]/span/a[contains(@class, 'dynatree-title')]")).FARightClick();
                FastDriver.NextGenDocumentRepository.WebDriver.FindElement(By.Id("RTMsubMenu")).FindElement(By.XPath("//li[2]/a[text()='Details']")).FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.MailTo.Exists(); FastDriver.NextGenDocumentRepository.MailTo.FAClick();
                Playback.Wait(2000);
                FastDriver.NextGenDocumentRepository.SelectAddresses.FAClick(); Playback.Wait(2000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30); FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//ul/li/a[@href='#divRTMAdd']").FAClickAction(); Playback.Wait(5000);

                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//div/table[@id='tblRTMAddresses']").Highlight(3);

                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "tblRTMAddresses").PerformTableAction(1, 1, TableAction.Click);

                if (FastDriver.NextGenDocumentRepository.RTMSelectAddressDone.IsDisplayed()) { FastDriver.NextGenDocumentRepository.RTMSelectAddressDone.FAClick(); }


                #endregion

                #region  Verify the Selection of Return Sub-tab

                Reports.TestStep = "Verify the Selection of Return Sub-tab";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ReturnTo.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.OfficeSelection);
                FastDriver.NextGenDocumentRepository.OfficeSelection.FASelectItemByIndex(1);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();

                #endregion


                #region   Finalize the document before Deliverd

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Doc_Finalize.FASelectContextMenuItem();
                Playback.Wait(6000);

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Doc_Finalize.FASelectContextMenuItem(); Playback.Wait(5000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); Playback.Wait(5000);
                FastDriver.NextGenDocumentRepository.PackageLink.Highlight(2);
                FastDriver.NextGenDocumentRepository.PackageLink.SendKeys(FAKeys.Enter); Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (!FastDriver.NextGenDocumentRepository.FirstRTMPackage.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                }

                #endregion

                #region "Alternate Course 45:  Deliver an RTM Package";
                Reports.TestDescription = "Alternate Course 45:  Deliver an RTM Package";

                #region   " Deliver an RTM Package: Email ";
                Reports.TestStep = " Deliver an RTM Package: Email ";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (!FastDriver.NextGenDocumentRepository.FirstRTMPackage.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.FirstRTMPackage);
                }
                FastDriver.NextGenDocumentRepository.FirstRTMPackage.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DeliverRTM);
                FastDriver.NextGenDocumentRepository.DeliverRTM.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.EmailRTM);

                FastDriver.NextGenDocumentRepository.EmailRTM.JSClick(); Playback.Wait(6000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.EmailDlg.WaitForDialogToLoad();
                try { FastDriver.EmailDlg.SendEmail(); FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Email, 300); }
                catch
                {
                    FastDriver.EmailDlg.ToText.FASetText("rmodi@firstam.com");
                    FastDriver.EmailDlg.SellerNamecheckBox.FASetCheckbox(true);
                    FastDriver.EmailDlg.Message.FASetText("this is test mail");
                    FastDriver.EmailDlg.ToText.FASetText("rmodi@firstam.com");
                    FastDriver.EmailDlg.Email.FADoubleClick();
                    if (FastDriver.EmailDlg.Email.Exists()) { FastDriver.EmailDlg.Email.FAClick(); }
                    FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Email, 300);
                    //FastDriver.WebDriver.WaitForWindowAndSwitch("Status...................", false, 40);
                    Playback.Wait(15000);
                }
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Playback.Wait(8000);
                #endregion

                #region   " Deliver an RTM Package: Print "
                Reports.TestStep = " Deliver an RTM Package: Print ";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (!FastDriver.NextGenDocumentRepository.FirstRTMPackage.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.FirstRTMPackage);
                }
                FastDriver.NextGenDocumentRepository.FirstRTMPackage.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DeliverRTM);
                FastDriver.NextGenDocumentRepository.DeliverRTM.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.PrintRTM);
                FastDriver.NextGenDocumentRepository.PrintRTM.Highlight();
                FastDriver.NextGenDocumentRepository.PrintRTM.JSClick(); Playback.Wait(8000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SelectPrinter();
                FastDriver.PrintDlg.PublishDocument.FASetCheckbox(true);
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 300);
                // FastDriver.WebDriver.WaitForWindowAndSwitch("Status...................", false, 50);
                #endregion

                #region       " Deliver an RTM Package: FAX ";
                Reports.TestStep = " Deliver an RTM Package: FAX ";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (!FastDriver.NextGenDocumentRepository.FirstRTMPackage.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.FirstRTMPackage);
                }
                FastDriver.NextGenDocumentRepository.FirstRTMPackage.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DeliverRTM);
                FastDriver.NextGenDocumentRepository.DeliverRTM.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.FaxRTM);
                FastDriver.NextGenDocumentRepository.FaxRTM.Highlight(5);
                FastDriver.NextGenDocumentRepository.FaxRTM.JSClick(); Playback.Wait(6000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FaxDlg.WaitForScreenToLoad();
                try { FastDriver.FaxDlg.SendFax(); FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Fax, 300); Playback.Wait(9000); }
                catch
                {
                    FastDriver.FaxDlg.Insert.FAClick();
                    FastDriver.FaxDlg.FAXNumber.FASetText("7148001570");
                    FastDriver.FaxDlg.publishDocument.FASetCheckbox(true);
                    FastDriver.FaxDlg.Message.FASetText("Any Message");
                    FastDriver.FaxDlg.FAX.FAClick();
                    FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Fax, 400);
                }
                if (FastDriver.FaxDlg.FAX.Exists()) { FastDriver.FaxDlg.FAX.FAClick(); }

                //FastDriver.WebDriver.WaitForWindowAndSwitch("Status...................", false, 40); 
                Playback.Wait(15000);

                #endregion

                #region       " Deliver an RTM Package: Image-doc ";
                Reports.TestStep = " Deliver an RTM Package: ImageDOC ";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (!FastDriver.NextGenDocumentRepository.FirstRTMPackage.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.FirstRTMPackage);
                }
                FastDriver.NextGenDocumentRepository.FirstRTMPackage.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DeliverRTM);
                FastDriver.NextGenDocumentRepository.DeliverRTM.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.ImageDocRTM);
                FastDriver.NextGenDocumentRepository.ImageDocRTM.Highlight(5);
                FastDriver.NextGenDocumentRepository.ImageDocRTM.JSClick(); Playback.Wait(6000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                FastDriver.ImageDocDlg.markDraft.FASetCheckbox(true);
                FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.Deliver();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 300);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20); Playback.Wait(15000);
                #endregion

                #region       " Deliver an RTM Package: preview";
                Reports.TestStep = " Deliver an RTM Package: preview ";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (!FastDriver.NextGenDocumentRepository.FirstRTMPackage.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.FirstRTMPackage);
                }
                FastDriver.NextGenDocumentRepository.FirstRTMPackage.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DeliverRTM);
                FastDriver.NextGenDocumentRepository.DeliverRTM.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.PreviewRTM);
                FastDriver.NextGenDocumentRepository.PreviewRTM.Highlight(5);
                FastDriver.NextGenDocumentRepository.PreviewRTM.JSClick(); Playback.Wait(15000);
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 900);
                FastDriver.WebDriver.ClosePreviewWindow();


               
               
                #endregion
                #endregion

            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region REG0050
        [TestMethod]
        [Description("Verify Policy document delivered via epolicy")]
        public void REG0050()
        {

            try
            {
                Reports.TestDescription = "Verify Policy document delivered via epolicy";
                int mortgateid = 349;
                string entityid = "A101";
                int mortgateofcid = 12193;

                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                Reports.TestStep = "Login to FAST ADM";
                FAST_Login_ADM(true);

                Reports.TestStep = "Change region to Mortgate Services Region";
                FAST_OpenRegionOrOffice(mortgateid);

                Reports.TestStep = "Navigate to Addressbook";
                FastDriver.AddressBookSearch.Open();

                Reports.TestStep = "Search for the wxisting EntityID code \"A101\" ";
                FastDriver.AddressBookSearch.EntityID.FASetText(entityid);
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Searching...", true, 30);
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction("ID Code", entityid, "ID Code", TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Select Corporate Parent as \"Wells Fargo\" ";
                FastDriver.BusinessPartyOrganizationSetUp.CorporateParent.FASelectItem("Wells Fargo");
                FastDriver.BusinessPartyOrganizationSetUp.eSubscriptions.FAClick();

                Reports.TestStep = "Verify Title Policy Delivery  is checked in eSubscriptions webpage dialog";
                FastDriver.BusPartyOrgeSubscriptionsDlg.WaitForScreenToLoad();
                if (FastDriver.BusPartyOrgeSubscriptionsDlg.eTitlePolicyDelivery.FAGetAttribute("Checked") == "False")
                    FastDriver.BusPartyOrgeSubscriptionsDlg.eTitlePolicyDelivery.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Login to fast file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);

                Reports.TestStep = "Change Office to mortgate office";
                FAST_OpenRegionOrOffice(mortgateofcid);

                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("A101");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion

                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Make Mysearch as empty";
                FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");

                Reports.TestStep = "Create a Title report document in the document repository";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Preliminary Report - CA (Corp)");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "Preliminary Report - CA (Corp)", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Make Mysearch as empty";
                FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");

                Reports.TestStep = "Create a Lender policy document in the document repository";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Lender Policy");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("CA-ALTA Loan Policy (6-17-06)-N");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "CA-ALTA Loan Policy (6-17-06)-N", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Add effective date to Title Report";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Preliminary Report - CA (Corp)", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);
                FastDriver.NextGenDocumentRepository.EffectiveDate.FASetText(DateTime.Now.AddDays(-3).ToDateString());
                FastDriver.NextGenDocumentRepository.DocInfo_Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Finalize the lender policy";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "CA-ALTA Loan Policy (6-17-06)-N", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);
                FastDriver.NextGenDocumentRepository.Policy_EffectiveDate.FASetText(DateTime.Now.ToDateString());
                if (FastDriver.NextGenDocumentRepository.Policy_Autonumbercheckbox.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentRepository.Policy_Autonumbercheckbox.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);
                if (FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.IsVisible() == true)
                    FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.FASetText(Support.RandomString("ANANNANANAANAN"));
                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.DocumentStatus.FASelectItem("Finalized");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                var watch = Stopwatch.StartNew();
                while (watch.ElapsedMilliseconds <= 120 * 1000) // 120 Seconds
                {
                    FastDriver.NextGenDocumentRepository.Open();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    string Epolicysymbol = FastDriver.WebDriver.FAFindElement(ByLocator.Id, "imgEPoilcy").Exists().ToString();

                    if (Epolicysymbol == "True")
                    {
                        break;
                    }

                }

                watch.Stop();

                Reports.TestStep = "Perform Epolicy Delivery";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "CA-ALTA Loan Policy (6-17-06)-N", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Deliver.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.SearchResult_Deliver.FAMouseOver();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, "EpolicyDeliverySingleID").FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForDeliveryWindow("Epolicy", 400);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify Submitted Delivery Status in Event/Tracking Log";
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion


        #region REG0040_6_3_4_Docdetail
        [TestMethod]
        [Description(@"Verify Document details screen &  Verify Image doc details screen & Verify publish document details screen")]


        public void REG0040_6_3_4_Docdetail()
        {
            try
            {
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: true);
                FAST_OpenRegionOrOffice(officeId);
                Playback.Wait(9000);
                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");
                CloseRelatedProcesses();

                //LoadTemplateOrCreateNew("SAN-NEXTGEN101", "NEXTGEN_SAN_EscrowInfoNote_DoNotTouch", "Title Reports");
                //LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                //LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                //LoadTemplateOrCreateNew("SAN-NEXTGEN505", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";
                Reports.TestDescription = " Documents Creation";

                Reports.TestStep = "Login to File Side with superuser credential";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);                                                  // creat a File -- superuser
                try { FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); } Playback.Wait(4000);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);
                Reports.TestStep = "Capture File Number";
                var filenum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClickAction();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TemplateName1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClickAction();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TemplateName1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Documnet is created ";                     // Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);

                Reports.TestStep = "Create a  image document in the document repository";      // Image Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TemplateName1, "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.SearchResult_Deliver);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.FAMoveToElement();
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.Highlight(5);
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.JSClick();

                //FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc.FAMoveToElement();
                // FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.FAClick();
                Playback.Wait(14000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                FastDriver.ImageDocDlg.markDraft.FASetCheckbox(true);
                FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.Deliver();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 900);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 90);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); Playback.Wait(7000);

                Reports.TestStep = "Verify tye document is imaged";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(5000);
                var statusimg = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(2, 10, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual("Imaged ", statusimg);

                Reports.TestStep = "Verify The Image Doc have PDF  View";
                FastDriver.NextGenDocumentRepository.PdfViewerIcon.IsDisplayed();
                if (FastDriver.NextGenDocumentRepository.PdfViewerIcon.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.PdfViewerIcon.FAClick(); Playback.Wait(15000);
                    FastDriver.WebDriver.ClosePreviewWindow(); Playback.Wait(6000);
                }


                Reports.TestStep = "take values  From Document Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight(10);
                FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                var DocumentID = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                var DocumentName = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText();
                var DocStatus = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedUser = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText();
                var TempRegionId = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(11, 2, TableAction.GetCell).Element.FAGetText();
                var TempRegioName = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(12, 2, TableAction.GetCell).Element.FAGetText();

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.Highlight(5);
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }
                Reports.TestStep = "Take values from Images Doc info";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Imaged", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick(); Playback.Wait(10000);

                var ImageName = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocumentDetails").PerformTableAction(1, 1, TableAction.GetCell).Element.FAGetText();

                Support.AreEqual("Image Name: " + TemplateName1, ImageName);
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocDetails").IsDisplayed();

                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocDetails").FAFindElement(ByLocator.XPath, "//div[@class='divBoxed']").Highlight();
                var imageInfo0_Name = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocDetails").FAFindElement(ByLocator.XPath, "//div[@class='divBoxed']").PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(imageInfo0_Name, TemplateName1);
                var imageInfo0_status = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocDetails").FAFindElement(ByLocator.XPath, "//div[@class='divBoxed']").PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText();
                var imageInfo0_CreatedBy = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocDetails").FAFindElement(ByLocator.XPath, "//div[@class='divBoxed']").PerformTableAction(7, 2, TableAction.GetCell).Element.FAGetText();
                var imageInfo0_CreatedDate = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocDetails").FAFindElement(ByLocator.XPath, "//div[@class='divBoxed']").PerformTableAction(6, 2, TableAction.GetCell).Element.FAGetText();


                //*********************** PART- II ***************************//

                #region Verification
                Reports.TestDescription = "Verify the Documents details with different user";
                var credentials1 = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword,
                };

                FAST_Login_IIS(regionId: regionId);
                try { FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); }

                Reports.TestStep = "Enter The file Number captuered";
                FastDriver.TopFrame.FileNumberEditBox.FASetText(filenum + FAKeys.Enter);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(5000);

                Reports.TestStep = "Verify the Documnet is created ";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var Doc_status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual("Created", status);




                Reports.TestStep = "Verify the Documents Details";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Escrow Instruction", "Type", TableAction.Click).Element.FARightClick();
                // FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Escrow Instruction", "Type", TableAction.Click).Element.FADoubleClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick(); Playback.Wait(10000);

                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight(5);

                FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed();
                var Document_ID = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                var Document_Name = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText();
                //FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(1, 1, TableAction.GetCell).Element.Highlight(5);
                var Doc_Status = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText();
                var Created_User = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText();
                var TempRegion_Id = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(11, 2, TableAction.GetCell).Element.FAGetText();
                var TempRegion_Name = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(12, 2, TableAction.GetCell).Element.FAGetText();

                Support.AreEqual(DocumentID, Document_ID); Support.AreEqual(Document_Name, DocumentName);
                Support.AreEqual(DocStatus, Doc_status);

                Support.AreEqual(CreatedUser, Created_User);
                Support.AreEqual(TempRegionId, TempRegion_Id);
                Support.AreEqual(TempRegion_Name, TempRegioName);

                Reports.TestStep = "Verify the images Documents Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Imaged", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick(); Playback.Wait(10000);


                var ImageName_1 = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocumentDetails").PerformTableAction(1, 1, TableAction.GetCell).Element.FAGetText();
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocumentDetails").PerformTableAction(1, 1, TableAction.GetCell).Element.Highlight(5);
                Support.AreEqual("Image Name: " + TemplateName1, ImageName_1);
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocDetails").IsDisplayed();

                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocDetails").FAFindElement(ByLocator.XPath, "//div[@class='divBoxed']").Highlight(5);
                var imageInfo1_Name = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocDetails").FAFindElement(ByLocator.XPath, "//div[@class='divBoxed']").PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(imageInfo1_Name, TemplateName1);
                var imageInfo1_status = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocDetails").FAFindElement(ByLocator.XPath, "//div[@class='divBoxed']").PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText();
                var imageInfo1_CreatedBy = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocDetails").FAFindElement(ByLocator.XPath, "//div[@class='divBoxed']").PerformTableAction(7, 2, TableAction.GetCell).Element.FAGetText();
                var imageInfo1_CreatedDate = FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divDocDetails").FAFindElement(ByLocator.XPath, "//div[@class='divBoxed']").PerformTableAction(6, 2, TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(imageInfo0_Name, imageInfo0_Name);
                Support.AreEqual(imageInfo1_status, imageInfo0_status);
                Support.AreEqual(imageInfo0_CreatedBy, imageInfo1_CreatedBy);
                Support.AreEqual(imageInfo0_CreatedDate, imageInfo1_CreatedDate);
                #endregion




            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }


        }


        #endregion

        #region REG0051_PublishDocument Dialog
        [TestMethod]
        [Description("Alternate Course :  Publish Document Dialog")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG00Publish()
        {
            try
            {
                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Alternate Course :  Publish Document Dialog";
                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                // Pre-Condition

                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");


                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");


                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");

                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select the template by using "Ctrl" command
                Reports.TestStep = "Select the template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();


                var documents = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion



                #region Right click and Select ImageDoc from Deliver
                Reports.TestStep = "Select \"ImageDoc from  Deliver\" option";

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Right click and Select ImageDoc from Deliver in Context Menu Items";

                FastDriver.NextGenDocumentRepository.DocumentsTable.Highlight(3);

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();

                #region Perform ImageDoc Delivery

                //  Assuming Context Menu is offset { left: 340, top: 304 } within content container;
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);


                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.Highlight();

                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.FAClick();

                //FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.JSClick();

                #endregion



                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                FastDriver.ImageDocDlg.markDraft.FASetCheckbox(true);
                FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.Deliver();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 400);


                Reports.TestStep = "Verify A Document will be displays with \"PDF\" Icon and Same \"document name\" which delivered and Type as \"Imaged Document\" and Status as \"Imaged\".";

                FastDriver.NextGenDocumentRepository.Open();

                string PDFImage1 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(2, 10, TableAction.GetCell).Element.FAGetText();


                Support.AreEqual("Imaged", PDFImage1);


                #region Select the document Right-Click and select 'Add PublishQuee' option from context
                Reports.TestStep = "Select the document Right-Click and select 'Add PublishQueue' option from context";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(2, 10, TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.AddPublishQueue.FASelectContextMenuItem();
                #endregion

                FastDriver.NextGenDocumentRepository.PublishDoc.Highlight();
                FastDriver.NextGenDocumentRepository.SelectAllPublish.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.PublishDocument_Done.FAClick();
                string Publishto = " Published to : Assumption Lender,Business Source,Buyer,Buyer's Attorney,Buyer's Broker,Buyer's RE Broker Transaction Coordinator,Buyer's Real Estate Agent,Directed By,Loan Investor,Loan Investor Contact,Mortgage Broker,New Lender,Other RE Broker Transaction Coordinator,Other Real Estate Agent,Other Real Estate Broker,Outside Escrow Company,Outside Title Company,Seller,Seller's Attorney,Seller's Broker,Seller's RE Broker Transaction Coordinator,Seller's Real Estate Agent";
                Support.AreEqual(Publishto, FastDriver.NextGenDocumentRepository.PublishTo.FAGetValue());



                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Imaged", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.AddInterfaceQueue.FAMouseOver();
                FastDriver.NextGenDocumentRepository.EP.Highlight();
                FastDriver.NextGenDocumentRepository.EP.FASetCheckbox(true);
                Playback.Wait(3000);

                FastDriver.WebDriver.HandleDialogMessage();
                Playback.Wait(3000);

                FastDriver.NextGenDocumentRepository.Open();
                Playback.Wait(3000);

                string PDFImage2 = FastDriver.NextGenDocumentRepository.InterfaceEP.FAGetAttribute("title").ToString();
                Support.AreEqual("Added to Interface EP", PDFImage2);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion


        #region REG0052
        [TestMethod]
        [Description("6.7: Edit Document Dialog Box")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0052()
        {
            try
            {
                int mortgateid = 349;
                string entityid = "BOA";
                int mortgateofcid = 12193;



                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Alternate Course 12:  Create a PDF Image";
                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                // Pre-Condition

                LoadTemplateOrCreateNew("SAN-NEXTGEN100", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Escrow Instruction");

                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                #region Createfile
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.SwitchToContentFrame();
                FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(entityid);
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
                FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                    FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
                else if (ClosingDisclosureSupport.IMDFormType == "CD")
                    FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

                FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText("6000");
                FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
                FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
                FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
                FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
                FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
                FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("BOA");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    throw new Exception("File could not be created");
                }
                #endregion


                //Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");


                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");

                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select the template by using "Ctrl" command
                Reports.TestStep = "Select the template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                var documents = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Perform "Edit Document Name" functionality
                Reports.TestStep = "Select \"Edit Document Name\" option";

                // FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                string DocName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FAGetText();


                FastDriver.NextGenDocumentRepository.EditDocumentName.FAClick();
                // FastDriver.NextGenDocumentRepository.EditDocumentName.JSClick(); 
                //  FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                // FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.EditDocumentDlg.EditDocumentNameDialog.Highlight(5);

                Reports.TestStep = "Verify controls are enabled or disabled in \"Edit Document\" Dialog.";
                Support.AreEqual("False", FastDriver.EditDocumentDlg.ChangeDocTypeChk.IsEnabled().ToString(), false);
                Support.AreEqual("False", FastDriver.EditDocumentDlg.CreateaCopy.IsEnabled().ToString(), false);
                Support.AreEqual("False", FastDriver.EditDocumentDlg.DocumentTypeCbo.IsEnabled().ToString(), false);
                Support.AreEqual("False", FastDriver.EditDocumentDlg.DocumentNameCbo.IsEnabled().ToString(), false);
                Support.AreEqual("False", FastDriver.EditDocumentDlg.EditDocumentComment.IsEnabled().ToString(), false);
                Support.AreEqual("True", FastDriver.EditDocumentDlg.EditDocument_Done.IsEnabled().ToString(), true);
                Support.AreEqual("True", FastDriver.EditDocumentDlg.EditDocument_Cancel.IsEnabled().ToString(), true);


                //Reports.TestStep = "Verify \"File No:\" is enabled or disabled";

                //Support.AreEqual("False", FastDriver.EditDocumentDlg.EditFileNum.IsReadOnly().ToString(), false);

                Reports.TestStep = "Verify Edit Document Name is same as Name of Documents Table.";
                string strName = FastDriver.EditDocumentDlg.EditDocName.FAGetValue();
                Support.AreEqual(DocName, strName, true);

                Reports.TestStep = "Verify Edit Document Name text box is enabled and editable";
                Support.AreEqual("True", FastDriver.EditDocumentDlg.EditDocName.IsEnabled().ToString(), true);

                Reports.TestStep = "Verify length of Edit Document Name Text Box.";
                string Length = FastDriver.EditDocumentDlg.EditDocName.FAGetAttribute("maxlength");
                Support.AreEqual("58", Length, true);

                Reports.TestStep = "Edit Document Name";
                FastDriver.EditDocumentDlg.EditDocName.Clear();
                FastDriver.EditDocumentDlg.EditDocName.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch_Edited");
                strName = "";
                strName = FastDriver.EditDocumentDlg.EditDocName.FAGetValue();
                FastDriver.EditDocumentDlg.EditDocument_Done.Highlight(5);
                FastDriver.EditDocumentDlg.EditDocument_Done.FAClickAction();
                FastDriver.NextGenDocumentRepository.Open();



                string strDocName = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.PerformTableAction("Status", "Created", "Name", TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(strName, strDocName, true);
                #endregion

                #region Perform ImageDoc Delivery and verify "Edit Document Name" functionality
                //FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1,7, TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                //FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.FAClick();
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.JSClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                FastDriver.ImageDocDlg.markDraft.FASetCheckbox(true);
                FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.Deliver();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 400);
                #endregion

                #region Verify "Control Types"  are visible in Documents Table when Status is "Imaged in Edit Document Name Dialog."
                Reports.TestStep = "Verify \"Control Types\"  are visible in DocumentsTable when Status is \"Imaged\"in Edit Document Name Dialog.";
                FastDriver.NextGenDocumentRepository.Open();

                string strDocStatusType = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.PerformTableAction("Type", "Imaged Document", "Status", TableAction.GetCell).Element.FAGetText();
                if (strDocStatusType == "Imaged")
                {
                    FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Imaged Document", "Type", TableAction.GetCell).Element.FADoubleClick();


                    Support.AreEqual("True", FastDriver.NextGenDocumentRepository.itemDocumentName.IsEnabled().ToString(), true);
                    Support.AreEqual("True", FastDriver.NextGenDocumentRepository.itemDocTypeCDID.IsEnabled().ToString(), true);

                }
                else
                {
                    FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.GetCell).Element.FADoubleClick();

                    Support.AreEqual("False", FastDriver.NextGenDocumentRepository.itemDocumentName.IsEnabled().ToString(), false);
                    Support.AreEqual("False", FastDriver.NextGenDocumentRepository.itemDocTypeCDID.IsEnabled().ToString(), false);
                }


                #endregion

                #region Verify "Edit Document Name" functionality
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Imaged Document", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.EditDocumentName.FAClick();
                // FastDriver.NextGenDocumentRepository.EditDocumentName.JSClick(); 
                // FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //   FastDriver.EditDocumentDlg.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify \"Change Document Type\" and \"Create a Copy\" check boxes are enabled or disabled for Imaged Type.";
                Support.AreEqual(true, FastDriver.EditDocumentDlg.ChangeDocTypeChk.IsEnabled(), "true");
                Support.AreEqual(false, FastDriver.EditDocumentDlg.CreateaCopy.IsEnabled(), "false");

                Reports.TestStep = "Set \"Change Document Type\" True.";
                FastDriver.EditDocumentDlg.ChangeDocTypeChk.FASetCheckbox(true);

                if (FastDriver.EditDocumentDlg.ChangeDocTypeChk.IsSelected() == true)
                {

                    Reports.TestStep = "Verify controls are enabled or disabled in \"Edit Document\" Dialog for Imaged Type.";
                    Support.AreEqual("True", FastDriver.EditDocumentDlg.CreateaCopy.IsEnabled().ToString(), true);
                    Support.AreEqual("True", FastDriver.EditDocumentDlg.DocumentTypeCbo.IsEnabled().ToString(), true);
                    Support.AreEqual("True", FastDriver.EditDocumentDlg.EditDocNameChkTrue.IsEnabled().ToString(), true);
                    Support.AreEqual("True", FastDriver.EditDocumentDlg.EditDocumentComment.IsEnabled().ToString(), true);
                    Support.AreEqual("True", FastDriver.EditDocumentDlg.EditDocument_Done.IsEnabled().ToString(), true);
                    Support.AreEqual("True", FastDriver.EditDocumentDlg.EditDocument_Cancel.IsEnabled().ToString(), true);

                }
                Reports.TestStep = "Select Document Type \"Exchange : Delayed\" and Document Name \"MISCELLANEOUS\", Verify the functionality";
                FastDriver.EditDocumentDlg.DocumentTypeCbo.FASelectItem("Exchange : Delayed");
                FastDriver.EditDocumentDlg.DocumentNameCbo.FASelectItem("MISCELLANEOUS");
                string strDocTypecbo = FastDriver.EditDocumentDlg.DocumentTypeCbo.FAGetSelectedItem();
                string strDocNamecbo = FastDriver.EditDocumentDlg.DocumentNameCbo.FAGetSelectedItem();

                Reports.TestStep = "Verify if Additional Information Text Box is visible and the length of the Text Box.";
                Support.AreEqual("True", FastDriver.EditDocumentDlg.EditDocumentAdditionalInfo.IsVisible().ToString(), true);

                Reports.TestStep = "Verify the length of comment Text Box.";
                Length = "";
                Length = FastDriver.EditDocumentDlg.EditDocumentAdditionalInfo.FAGetAttribute("maxlength");
                Support.AreEqual("40", Length, true);


                //***************** The following code will pass with EditDocumentComment maxlength needs to set with 255.***********************//
                //Reports.TestStep = "Verify the length of comment Text Box.";
                //Length = "";
                //Length = FastDriver.EditDocumentDlg.EditDocumentComment.FAGetAttribute("maxlength");
                //Support.AreEqual("255", Length, true);



                FastDriver.EditDocumentDlg.EditDocument_Done.FAClick();
                FastDriver.NextGenDocumentRepository.Open();


                string strDocTypeName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "MISCELLANEOUS NEXTGEN_SAN_EscrowInstruction_DoNotTouch_Edited", "Type", TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(strDocTypecbo, strDocTypeName, true);
                strDocName = "";
                strDocName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Exchange : Delayed", "Name", TableAction.GetCell).Element.FAGetText();
                Support.AreEqual("true", strDocName.Contains(strDocNamecbo).ToString(), true);

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Exchange : Delayed", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.EditDocumentName.FAClick();                
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.EditDocumentDlg.ChangeDocTypeChk.FASetCheckbox(true);

                Reports.TestStep = "Select Document Type \"Exchange : Miscellaneous\" and Document Name \"MISCELLANEOUS\", Verify the functionality";
                FastDriver.EditDocumentDlg.DocumentTypeCbo.FASelectItem("Exchange : Miscellaneous");


                if (FastDriver.EditDocumentDlg.DocumentNameCbo.FAGetText() != "")
                {
                    FastDriver.EditDocumentDlg.DocumentNameCbo.FASelectItem("MISCELLANEOUS");
                    strDocTypecbo = ""; strDocNamecbo = ""; strDocTypeName = "";

                    strDocTypecbo = FastDriver.EditDocumentDlg.DocumentTypeCbo.FAGetSelectedItem();
                    strDocNamecbo = FastDriver.EditDocumentDlg.DocumentNameCbo.FAGetSelectedItem();

                    FastDriver.EditDocumentDlg.EditDocument_Done.FAClick();
                    FastDriver.NextGenDocumentRepository.Open();

                    strDocTypeName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "MISCELLANEOUS NEXTGEN_SAN_EscrowInstruction_DoNotTouch_Edited", "Type", TableAction.GetCell).Element.FAGetText();
                    Support.AreEqual(strDocTypecbo, strDocTypeName, true);
                    strDocName = "";
                    strDocName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Exchange : Miscellaneous", "Name", TableAction.GetCell).Element.FAGetText();
                    Support.AreEqual("true", strDocName.Contains(strDocNamecbo).ToString(), true);


                }

                else
                {
                    FastDriver.EditDocumentDlg.EditDocument_Cancel.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(true);


                }

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "MISCELLANEOUS NEXTGEN_SAN_EscrowInstruction_DoNotTouch_Edited", "Type", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.EditDocumentName.FAClick();                
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.EditDocumentDlg.ChangeDocTypeChk.FASetCheckbox(true);

                Reports.TestStep = "Select Document Type \"Exchange : Reverse\" and Document Name \"MISCELLANEOUS\", Verify the functionality";
                FastDriver.EditDocumentDlg.DocumentTypeCbo.FASelectItem("Exchange : Reverse");
                FastDriver.EditDocumentDlg.DocumentNameCbo.FASelectItem("MISCELLANEOUS");
                strDocTypecbo = ""; strDocNamecbo = ""; strDocTypeName = "";

                strDocTypecbo = FastDriver.EditDocumentDlg.DocumentTypeCbo.FAGetSelectedItem();
                strDocNamecbo = FastDriver.EditDocumentDlg.DocumentNameCbo.FAGetSelectedItem();

                FastDriver.EditDocumentDlg.EditDocument_Done.FAClick();
                FastDriver.NextGenDocumentRepository.Open();

                strDocTypeName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "MISCELLANEOUS MISCELLANEOUS NEXTGEN_SAN_EscrowInstruction_DoNotTouch_Edited", "Type", TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(strDocTypecbo, strDocTypeName, true);
                strDocName = "";
                strDocName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Exchange : Reverse", "Name", TableAction.GetCell).Element.FAGetText();
                Support.AreEqual("true", strDocName.Contains(strDocNamecbo).ToString(), true);

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "MISCELLANEOUS MISCELLANEOUS NEXTGEN_SAN_EscrowInstruction_DoNotTouch_Edited", "Type", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.EditDocumentName.FAClick();
                //FastDriver.NextGenDocumentRepository.EditDocumentName.JSClick(); 
                // FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                // FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.EditDocumentDlg.ChangeDocTypeChk.FASetCheckbox(true);

                Reports.TestStep = "Select Document Type \"Exchange : Secured\" and Document Name \"SEC-CIP\", Verify the functionality";
                FastDriver.EditDocumentDlg.DocumentTypeCbo.FASelectItem("Exchange : Secured");
                FastDriver.EditDocumentDlg.DocumentNameCbo.FASelectItem("SEC-CIP");
                strDocTypecbo = ""; strDocNamecbo = ""; strDocTypeName = "";
                strDocTypecbo = FastDriver.EditDocumentDlg.DocumentTypeCbo.FAGetSelectedItem();
                strDocNamecbo = FastDriver.EditDocumentDlg.DocumentNameCbo.FAGetSelectedItem();
                FastDriver.EditDocumentDlg.EditDocument_Done.FAClick();
                FastDriver.NextGenDocumentRepository.Open();
                strDocTypeName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SEC-CIP MISCELLANEOUS MISCELLANEOUS NEXTGEN_SAN_EscrowInstruction_DoNotTouch_Edited", "Type", TableAction.GetCell).Element.FAGetText();
                Support.AreEqual(strDocTypecbo, strDocTypeName, true);
                strDocName = "";
                strDocName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Exchange : Secured", "Name", TableAction.GetCell).Element.FAGetText();
                Support.AreEqual("true", strDocName.Contains(strDocNamecbo).ToString(), true);
                #endregion

                #region Verify "Change Type" functionality
                string Change_TypeRGB, CompareRGB;
                if (strDocTypeName.Contains("Secured"))
                {
                    Reports.TestStep = "Change Type is disabled for Seucred Type";
                    FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Exchange : Secured", "Name", TableAction.GetCell).Element.FARightClick();

                    //FastDriver.NextGenDocumentRepository.Change_Type.Highlight(5); 
                    //Support.AreEqual("False", FastDriver.NextGenDocumentRepository.Change_Type.IsEnabled().ToString(), false); 

                    Change_TypeRGB = FastDriver.NextGenDocumentRepository.Change_Type.FAGetAttribute("style");
                    CompareRGB = FastDriver.NextGenDocumentRepository.AddPublishQueue.FAGetAttribute("style");

                    if (Change_TypeRGB != CompareRGB && Change_TypeRGB == "color: rgb(168, 168, 168);")
                    {

                        Support.AreEqual("True", "True", "Change Type is Disabled");
                    }

                }
                Reports.TestStep = "Select any other Document Type in Edit Document Name Dialog.";
                #region Perform ImageDoc Delivery and verify "Edit Document Name" functionality
                FastDriver.NextGenDocumentRepository.Open();

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                //FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.FAClick();
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.JSClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                FastDriver.ImageDocDlg.markDraft.FASetCheckbox(true);
                FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.Deliver();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 400);
                #endregion
                FastDriver.NextGenDocumentRepository.Open();

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Exchange : Secured", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.EditDocumentName.FAClick();
                // FastDriver.NextGenDocumentRepository.EditDocumentName.JSClick(); 

                // FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                // FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.EditDocumentDlg.ChangeDocTypeChk.FASetCheckbox(true);

                Reports.TestStep = "Select Document Type \"Escrow: Closing Statements\" and Document Name \"Miscellaneous\", Verify the functionality";
                FastDriver.EditDocumentDlg.DocumentTypeCbo.FASelectItem("Escrow: Closing Statements");
                FastDriver.EditDocumentDlg.DocumentNameCbo.FASelectItem("Miscellaneous");


                FastDriver.EditDocumentDlg.EditDocument_Done.FAClick();
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Change Type and Verify.";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous NEXTGEN_SAN_EscrowInstruction_DoNotTouch_Edited", "Type", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Change_Type.Highlight(5);
                FastDriver.NextGenDocumentRepository.Change_Type.FAClick();

                //FastDriver.NextGenDocumentRepository.EditDocumentName.JSClick(); 
                // FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //  FastDriver.EditDocumentDlg.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify controls are enabled or disabled in \"Edit Document\" Dialog for Imaged Type in Changed Type Dialog.";
                Support.AreEqual("True", FastDriver.EditDocumentDlg.ChangeDocTypeChk.IsEnabled().ToString(), true);
                Support.AreEqual("True", FastDriver.EditDocumentDlg.ChangeDocTypeChk.IsSelected().ToString(), true);
                Support.AreEqual("True", FastDriver.EditDocumentDlg.CreateaCopy.IsEnabled().ToString(), true);
                Support.AreEqual("True", FastDriver.EditDocumentDlg.DocumentTypeCbo.IsEnabled().ToString(), true);
                Support.AreEqual("True", FastDriver.EditDocumentDlg.DocumentNameCbo.IsEnabled().ToString(), true);
                Support.AreEqual("True", FastDriver.EditDocumentDlg.EditDocumentComment.IsEnabled().ToString(), true);
                Support.AreEqual("True", FastDriver.EditDocumentDlg.EditDocument_Done.IsEnabled().ToString(), true);
                Support.AreEqual("True", FastDriver.EditDocumentDlg.EditDocument_Cancel.IsEnabled().ToString(), true);
                FastDriver.EditDocumentDlg.EditDocument_Cancel.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true);
                Reports.TestStep = "Verify Change Type for CPL Type.";
                Reports.TestStep = "Navigate to Closing Protection Letter Screen.";
                FastDriver.ClosingProtectionLetter.Open();
                FastDriver.ClosingProtectionLetter.Office.FASelectItem("DEMO - ABC Settlement Services/CA/Redding");
                FastDriver.ClosingProtectionLetter.BuyerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.SellerSummary.FASetCheckbox(true);
                FastDriver.ClosingProtectionLetter.LenderTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FAClick();

                FastDriver.ClosingProtectionLetter.LenderDetailsFax.FASetText("999-999-9999");
                FastDriver.ClosingProtectionLetter.SubmitCPLRequest.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                Playback.Wait(3000);
                Keyboard.SendKeys("%{F4}");

                Reports.TestStep = "Navigate to Document Repository Screen.";
                FastDriver.NextGenDocumentRepository.Open();
                Reports.TestStep = "Verify Change Type is disabled for Seucred Type";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous NEXTGEN_SAN_EscrowInstruction_DoNotTouch_Edited", "Type", TableAction.GetCell).Element.FARightClick();


                //Support.AreEqual("False", FastDriver.NextGenDocumentRepository.ChangeType.IsEnabled().ToString(), false);
                Change_TypeRGB = ""; CompareRGB = "";
                Change_TypeRGB = FastDriver.NextGenDocumentRepository.Change_Type.FAGetAttribute("style");
                CompareRGB = FastDriver.NextGenDocumentRepository.AddPublishQueue.FAGetAttribute("style");

                if (Change_TypeRGB != CompareRGB && Change_TypeRGB == "color: rgb(168, 168, 168);")
                {

                    Support.AreEqual("True", "True", "Change Type is Disabled");
                }


                Reports.TestStep = "Click on D/D in the top blue bar to submit a Date Down request";
                //FastDriver.NextGenDocumentRepository.Open();                 

                FastDriver.TopFrame.WaitForScreenToLoad();
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.DD.Highlight(5);

                FastDriver.TopFrame.DD.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Date Down Request", true, 20);
                FastDriver.DateDownRequest.WaitForScreenToLoad();
                Reports.TestStep = "Select the property, then click on ‘Submit’";
                FastDriver.DateDownRequest.Submit.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to Document Repository Screen.";
                FastDriver.NextGenDocumentRepository.Open();
                Reports.TestStep = "Verify Change Type is disabled";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous NEXTGEN_SAN_EscrowInstruction_DoNotTouch_Edited", "Type", TableAction.GetCell).Element.FARightClick();
                //Support.AreEqual("False", FastDriver.NextGenDocumentRepository.Change_Type.IsEnabled().ToString(), false);

                Change_TypeRGB = ""; CompareRGB = "";
                Change_TypeRGB = FastDriver.NextGenDocumentRepository.Change_Type.FAGetAttribute("style");
                CompareRGB = FastDriver.NextGenDocumentRepository.AddPublishQueue.FAGetAttribute("style");

                if (Change_TypeRGB != CompareRGB && Change_TypeRGB == "color: rgb(168, 168, 168);")
                {

                    Support.AreEqual("True", "True", "Change Type is Disabled");
                }



                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        #endregion


        #region REG0052_StarterRef
        [TestMethod]
        [Description("6.7: Edit Document Dialog Box: Starter Ref")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0052_StarterRef()
        {
            try
            {

                Reports.TestDescription = "Verify Starter/Ref Functionality NextGen to NextGen";
                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                CloseRelatedProcesses();
                #region Create 1st File (Next Gen) as previous
                Reports.TestStep = "Create 1st File (Next Gen) as previous";
                var nextGenRequest = GetNextGenWCFFileRequest();
                var response = FileService.CreateFile(nextGenRequest);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                var File = FileService.GetOrderDetails(response.FileID ?? 0);
                #endregion

                #region Create 2nd File (Next Gen) as previous
                Reports.TestStep = "Create 2nd File (Next Gen) as previous";
                var response2 = FileService.CreateFile(nextGenRequest);
                Support.AreEqual("1", response2.OperationResponse.Status.ToString(), response2.OperationResponse.StatusDescription);
                var File2 = FileService.GetOrderDetails(response2.FileID ?? 0);
                #endregion

                Reports.TestStep = "Login to FAST to open 1st File";
                FAST_Login_IIS(int.Parse(File.FileNumber), regionId: File.Services[0].OfficeInfo.RegionID);

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_TitleReports_DoNotTouch", "SAN_NEXTGEN_17A_TitleReports");

                #region Select Policy document Right-Click and select "view/edit" option
                Reports.TestStep = "Select Policy document Right-Click and select \"view/edit\" option";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_17A_TitleReports", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();
                #endregion

                #region Select an Effective Date
                Reports.TestStep = "Select an Effective Date";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocInfo_CopyFrom);
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText(DateTime.Now.Date.ToString("MM/dd/yyyy"));
                #endregion

                #region Click Save
                Reports.TestStep = "Click Save";
                FastDriver.NextGenDocumentRepository.DocInfo_Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Click Done
                Reports.TestStep = "Click Done";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocInfo_Done);
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                #endregion


                #region Perform ImageDoc Delivery and verify "Edit Document Name" functionality
                FastDriver.NextGenDocumentRepository.Open();


                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                //FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.FAClick();
                FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.JSClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                FastDriver.ImageDocDlg.markDraft.FASetCheckbox(true);
                FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                FastDriver.ImageDocDlg.Deliver();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 400);
                #endregion






                //#region Create an image document
                //Reports.TestStep = "Create an image document";
                //FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                //FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SAN_NEXTGEN_17A_TitleReports", "Name", TableAction.GetCell).Element.FARightClick();
                //FastDriver.NextGenDocumentRepository.SearchResult_Deliver.FAMoveToElement();
                //FastDriver.NextGenDocumentRepository.SearchResult_DeliverPrint.FAMoveToElement();
                //var imageDoc = FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc;
                //var imageDocActions = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).MoveToElement(imageDoc);
                //imageDocActions.Click().Perform();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                //FastDriver.ImageDocDlg.WaitForScreenToLoad(FastDriver.ImageDocDlg.ImageDoc);
                //FastDriver.ImageDocDlg.ImageDoc.FAClick();
                //FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);
                //#endregion

                #region Load target file
                Reports.TestStep = "Load target file";
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);
                #endregion

                #region Navigate to Starter/Ref screen
                Reports.TestStep = "Navigate to Starter/Ref screen";
                FastDriver.StarterReference.Open();
                #endregion

                #region In the Nextgen Starter File Number field, enter the file number(Created in Pre-Condition)
                Reports.TestStep = "In the Nextgen Starter File Number field, enter the file number(Created in Pre-Condition)";
                FastDriver.StarterReference.StarterFileNumber.FASetText(File.FileNumber);
                #endregion

                #region Select the Copy Documents check box in the Select Document to Copy section
                Reports.TestStep = "Select the Copy Documents check box in the Select Document to Copy section";
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
                #endregion

                #region Select Multiple documents, including documents and any imaged documents
                Reports.TestStep = "Select Multiple documents, including documents and any imaged documents";
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
                #endregion

                #region Click Done
                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                #endregion

                #region Click Copy Now or (Alt+C)
                Reports.TestStep = "Click Copy Now or (Alt+C)";
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Wait up to 5 min for document copy to complete
                Reports.TestStep = "Wait up to 5 min for document copy to complete";
                var copyDocumentStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("SAN_NEXTGEN_17A_TitleReports", "Title Reports", 300);
                if (!copyDocumentStatus)
                    throw new Exception("Document failed to copy from Starter file");   // wonder if there is a better idea...
                #endregion

                #region Verify Change Type is enabled or disabled
                Reports.TestStep = "Verify Change Type is enabled or disabled";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Imaged Document", "Name", TableAction.GetCell).Element.FARightClick();
                string Change_TypeRGB = FastDriver.NextGenDocumentRepository.Change_Type.FAGetAttribute("style");
                string AddPublishQueueRGB = FastDriver.NextGenDocumentRepository.AddPublishQueue.FAGetAttribute("style");

                if (Change_TypeRGB != AddPublishQueueRGB && Change_TypeRGB == "color: rgb(168, 168, 168);")
                {

                    Support.AreEqual("True", "True", "Change Type is Disabled");
                }
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        #endregion

        #region  REG0041_6_8_TitleReport_InfoTab
        [TestMethod]
        [Description(@" Verify The Title Report Info/ Button icons/ Field Definations")]

        public void REG0041_6_8_TitleReport_InfoTab()
        {
            try
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: true);
                FAST_OpenRegionOrOffice(officeId);
                Playback.Wait(9000);
                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                CloseRelatedProcesses();

                //LoadTemplateOrCreateNew("SAN-NEXTGEN101", "NEXTGEN_SAN_EscrowInfoNote_DoNotTouch", "Title Reports");
                //LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                //LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                //LoadTemplateOrCreateNew("SAN-NEXTGEN505", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");


                string TemplateName1 = "NEXTGEN_SAN_TitleReports_DoNotTouch";
                string Exceptions1_NextGenRegion = "ASHV/ANNI,EQSP/EQSP";
                string Exception2_corpregion = "EE/25,EE/10D,EE/10A,EE/10C";
                string Reuirement1_Nextgen = "R/WR,R/9,R/A31,R/2P,R/WR,R/17,R/11,R/4";
                string Reuirement2_CorpRegion = "RN/N10,RN/AFF,RN/T11M,RN/17,RN/4REO,RN/M37,RN/17,RN/M37,RN/4REO";
                string InormationNotes1_Nextgen = "INP/INP1,INP/INP2,INFO/11,ATPZ/38,JL6/1C,JL6/4,JL6/7,JL6/7";
                string InormationNotes2_Corp = "BAC/44,BAC/34,BAC/35,BAC/39,BAC/43,BAC/41,APAI/DE,RIN/13,RIN/19,RIN/16,RIN/20N,RIN/18N";
                string Endorsment_NextGen = "EPS/EPS1,EPS/EPS2,ANEP/2,ANEP/1,PVGT/PVTP";
                string Endorsment_Corp = "1461/0001";


                Reports.TestStep = "Login to File Side with superuser credential";


                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);                                                  // creat a File -- superuser
                try { FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); } Playback.Wait(4000);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);
                var filenum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TemplateName1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "click on Template to enable info tab";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TemplateName1, "Description", TableAction.Click);
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.IsDisplayed();
                if (FastDriver.NextGenDocumentRepository.DocumentInfoTab.Exists())
                { Reports.StatusUpdate("Info tab is Visible and active", true); }
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                Playback.Wait(4000);
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divTemplateProperties").IsDisplayed();

                Reports.TestStep = "verify the templated Name is present'";
                var TempifnoName = FastDriver.NextGenDocumentRepository.TitleReportDocDescription.FAGetValue();
                Support.AreEqual(TempifnoName, TemplateName1);

                DateTime today = System.DateTime.Today; // As DateTime
                string s_today = today.ToString("MM/dd/yyyy"); // As String

                FastDriver.NextGenDocumentRepository.EffectiveDate.FASetText(s_today);

                //*****************************Excpetion****************************************
                #region   Excpetion
                Reports.TestStep = "Verify the Excpetion enter is valid or not";
                FastDriver.NextGenDocumentRepository.TitelReportExceptions.FASetText("abcded/123456#3");
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                Playback.Wait(4000);

                Reports.TestStep = "Verify the message being displayed and message";
                string Message = "Invalid Phrase(s): abcded/123456#3";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);
                Playback.Wait(8000);
                Reports.TestStep = "Enter Valid phrase code for Excpetion";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.TitelReportExceptions);
                FastDriver.NextGenDocumentRepository.TitelReportExceptions.FASetText(FAKeys.Control + "A");
                FastDriver.NextGenDocumentRepository.TitelReportExceptions.Clear(); FastDriver.NextGenDocumentRepository.TitelReportExceptions.Clear();
                FastDriver.NextGenDocumentRepository.TitelReportExceptions.FASetText(Exceptions1_NextGenRegion);


                Reports.TestStep = "Select The source for Exception";
                FastDriver.NextGenDocumentRepository.TitelReportExceptionsSourceRegion.FASelectItem("QA Sandpointe - Next Gen");
                var ExcepSource_Reg = FastDriver.NextGenDocumentRepository.TitelReportExceptionsSourceRegion.FAGetSelectedItem();

                var ExceSorceReg_currnt = FastDriver.NextGenDocumentRepository.TitelReportExceptSourceReg.FAGetText();
                Support.AreEqual("None", ExceSorceReg_currnt);
                #endregion

                #region   Reuirement
                //***************************** Reuirement **********************
                Reports.TestStep = "Verify the Requirements phrase code enter is valid or not";
                FastDriver.NextGenDocumentRepository.TitelReportRequirements.FASetText("abcded/123456#3");
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                Playback.Wait(4000);

                Reports.TestStep = "Verify the message being displayed and message";
                string Message1 = "Invalid Phrase(s): abcded/123456#3";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message1);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.TitelReportRequirements);
                FastDriver.NextGenDocumentRepository.TitelReportRequirements.FASetText(FAKeys.Control + "A");
                FastDriver.NextGenDocumentRepository.TitelReportRequirements.Clear();
                FastDriver.NextGenDocumentRepository.TitelReportRequirements.FASetText(Reuirement2_CorpRegion);
                Playback.Wait(3500);

                Reports.TestStep = "Select The source for Requirements";
                FastDriver.NextGenDocumentRepository.TitelReportRequirementsSourceRegion.FASelectItem("DOCPREP Corporate Region");
                var RequSource_Reg = FastDriver.NextGenDocumentRepository.TitelReportRequirementsSourceRegion.FAGetSelectedItem();

                var RequSorceReg_currnt = FastDriver.NextGenDocumentRepository.TitelReportReqtSourceReg.FAGetText();
                Support.AreEqual("None", RequSorceReg_currnt);
                #endregion

                #region   Informtional notes
                //*********************** Informtional notes ***********************


                Reports.TestStep = "Verify the Informtional notes phrase code enter is valid or not";
                FastDriver.NextGenDocumentRepository.TitelReportInformation.FASetText("abcded/123456#3");
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                Playback.Wait(6000);

                Reports.TestStep = "Verify the message being displayed and message";
                string Message2 = "Invalid Phrase(s): abcded/123456#3";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message2);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.TitelReportInformation);
                FastDriver.NextGenDocumentRepository.TitelReportInformation.FASetText(FAKeys.Control + "A");
                FastDriver.NextGenDocumentRepository.TitelReportInformation.Clear();
                FastDriver.NextGenDocumentRepository.TitelReportInformation.FASetText(InormationNotes1_Nextgen);
                Playback.Wait(3500);

                Reports.TestStep = "Select The source for Informtional notes";
                FastDriver.NextGenDocumentRepository.TitelReportInformationSourceRegion.FASelectItem("QA Sandpointe - Next Gen"); Playback.Wait(3500);
                var InfoSource_Reg = FastDriver.NextGenDocumentRepository.TitelReportInformationSourceRegion.FAGetSelectedItem();

                var InfoSorceReg_currnt = FastDriver.NextGenDocumentRepository.TitelReportInfotSourceReg.FAGetText();
                Support.AreEqual("None", InfoSorceReg_currnt);
                #endregion

                #region    Endorsment
                //************** Endorsment *******************************


                Reports.TestStep = "Verify the Informtional notes phrase code enter is valid or not";
                FastDriver.NextGenDocumentRepository.TitelReportEndorsement.FASetText("abcded/123456#3");
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                Playback.Wait(4000);

                Reports.TestStep = "Verify the message being displayed and message";
                string Message3 = "Invalid Phrase(s): abcded/123456#3";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message3);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.TitelReportEndorsement);
                FastDriver.NextGenDocumentRepository.TitelReportEndorsement.FASetText(FAKeys.Control + "A");
                FastDriver.NextGenDocumentRepository.TitelReportEndorsement.Clear();
                FastDriver.NextGenDocumentRepository.TitelReportEndorsement.FASetText(Endorsment_NextGen);


                Reports.TestStep = "Select The source for Endorsment";
                FastDriver.NextGenDocumentRepository.TitelReportEndorsementSourceRegion.FASelectItem("QA Sandpointe - Next Gen"); Playback.Wait(3500);
                var EndorSource_Reg = FastDriver.NextGenDocumentRepository.TitelReportEndorsementSourceRegion.FAGetSelectedItem();

                var EndorSorceReg_currnt = FastDriver.NextGenDocumentRepository.TitelReportEndortSourceReg.FAGetText();
                Support.AreEqual("None", EndorSorceReg_currnt);
                #endregion


                var DOCNAME_0 = FastDriver.NextGenDocumentRepository.TitleReportDocDescription.FAGetValue();    // Docu Name

                var Effictvedate_0 = FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FAGetValue(); // Date


                var Excptionphrase_0 = FastDriver.NextGenDocumentRepository.TitelReportExceptions.FAGetValue();    // Exception phrase Entered

                var Requirephrase_0 = FastDriver.NextGenDocumentRepository.TitelReportRequirements.FAGetValue();


                var Infophrase_0 = FastDriver.NextGenDocumentRepository.TitelReportInformation.FAGetValue();

                var Endorsphrase_0 = FastDriver.NextGenDocumentRepository.TitelReportEndorsement.FAGetValue();

                Reports.TestStep = "Click on Create/Save to Create  a Dcoument";
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                Playback.Wait(8000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 50);

                //***************** Verification*****************

                Reports.TestDescription = "Verify the Title Reports Document Information";

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Select The Document Created and Right click on document";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TemplateName1, "Name", TableAction.Click).Element.FARightClick();
                if (FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FAClick();
                    Playback.Wait(5000);
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please...", true, 40);

                Reports.TestStep = "Save values into Variables";

                var DOCNAME = FastDriver.NextGenDocumentRepository.TitleReportDocDescription.FAGetValue();    // Docu Name

                var Effictvedate = FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FAGetValue(); // Date

                var exceptionsource = FastDriver.NextGenDocumentRepository.TitelReportExceptSourceReg.FAGetText(); //Excep  Source display

                var Excptionphrase = FastDriver.NextGenDocumentRepository.TitelReportExceptions.FAGetValue();    // Exception phrase Entered

                var Requiresource = FastDriver.NextGenDocumentRepository.TitelReportReqtSourceReg.FAGetText();    // req Source display

                var Requirephrase = FastDriver.NextGenDocumentRepository.TitelReportRequirements.FAGetValue();

                var Infosource = FastDriver.NextGenDocumentRepository.TitelReportInfotSourceReg.FAGetText();

                var Infophrase = FastDriver.NextGenDocumentRepository.TitelReportInformation.FAGetValue();

                var Endorsmentsource = FastDriver.NextGenDocumentRepository.TitelReportEndortSourceReg.FAGetText();

                var Endorsphrase = FastDriver.NextGenDocumentRepository.TitelReportEndorsement.FAGetValue();

                Support.AreEqual(DOCNAME, DOCNAME_0);
                Support.AreEqual(Effictvedate, Effictvedate_0);
                Support.AreEqual(exceptionsource, ExcepSource_Reg);

                Support.AreEqual(Infosource, InfoSource_Reg);
                Support.AreEqual(Endorsmentsource, EndorSource_Reg);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }


        }



        #endregion

        #region  REG0042_6_13_CopyFrom_InfoTab
        [TestMethod]
        [Description(@" Verify The Copy from tab info / Field Definations")]

        public void REG0042_6_13_CopyFrom_InfoTab()
        {
            try
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: true);
                try
                {
                    FAST_OpenRegionOrOffice(officeId);
                }

                catch (Exception ex)
                {
                    FailTest(GetExceptionInfo(ex));

                }
                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                CloseRelatedProcesses();

                string TemplateName1 = "NEXTGEN_SAN_TitleReports_DoNotTouch";

                string Exceptions1_NextGenRegion = "ASHV/ANNI,EQSP/EQSP";
                string Exception2_corpregion = "EE/25,EE/10D,EE/10A,EE/10C";
                string Reuirement1_Nextgen = "R/WR,R/9,R/A31,R/2P,R/WR,R/17,R/11,R/4";
                string Reuirement2_CorpRegion = "RN/N10,RN/AFF,RN/T11M,RN/17,RN/4REO,RN/M37,RN/17,RN/M37,RN/4REO";
                string InormationNotes1_Nextgen = "INP/INP1,INP/INP2,INFO/11,ATPZ/38,JL6/1C,JL6/4,JL6/7,JL6/7";
                string InormationNotes2_Corp = "BAC/44,BAC/34,BAC/35,BAC/39,BAC/43,BAC/41,APAI/DE,RIN/13,RIN/19,RIN/16,RIN/20N,RIN/18N";
                string Endorsment_NextGen = "EPS/EPS1,EPS/EPS2,ANEP/2,ANEP/1,PVGT/PVTP";
                string Endorsment_Corp = "1461/0001";


                Reports.TestStep = "Login to File Side with superuser credential";


                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);                                                  // creat a File -- superuser
                try { FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); } Playback.Wait(4000);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);
                var filenum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TemplateName1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "Create a title/poiicy document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TemplateName1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Documnet is created ";                     // Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);

                Reports.TestStep = "Right click on document and Click on phrase/view edit ";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TemplateName1, "Name", TableAction.Click).Element.FARightClick();
                if (FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FAClick();
                    Playback.Wait(5000);
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please...", true, 40);

                Reports.TestStep = "Enter The vlaues into  the title Doc ";

                DateTime today = System.DateTime.Today; // As DateTime
                string s_today = today.ToString("MM/dd/yyyy"); // As String

                FastDriver.NextGenDocumentRepository.EffectiveDate.FASetText(s_today);

                Reports.TestStep = "modified the doc Name";
                FastDriver.NextGenDocumentRepository.TitleReportDocDescription.FASetText(TemplateName1 + "_Modified");
                var TempifnoName = FastDriver.NextGenDocumentRepository.TitleReportDocDescription.FAGetValue();

                Reports.TestStep = "Enter Valid phrase code for Excpetion and select region";
                FastDriver.NextGenDocumentRepository.TitelReportExceptions.FASetText(Exceptions1_NextGenRegion);
                FastDriver.NextGenDocumentRepository.TitelReportExceptionsSourceRegion.FASelectItem("QA Sandpointe - Next Gen");
                var ExcepSource_Reg = FastDriver.NextGenDocumentRepository.TitelReportExceptionsSourceRegion.FAGetSelectedItem();

                //---
                Reports.TestStep = "Enter Valid phrase code for Requirements and select region";
                FastDriver.NextGenDocumentRepository.TitelReportRequirements.FASetText(Reuirement2_CorpRegion);
                Playback.Wait(3500);

                FastDriver.NextGenDocumentRepository.TitelReportRequirementsSourceRegion.FASelectItem("DOCPREP Corporate Region");
                var RequSource_Reg = FastDriver.NextGenDocumentRepository.TitelReportRequirementsSourceRegion.FAGetSelectedItem();

                //------
                Reports.TestStep = "Enter Valid phrase code for Informational notes and select region";
                FastDriver.NextGenDocumentRepository.TitelReportInformation.FASetText(InormationNotes1_Nextgen);
                Playback.Wait(3500);

                FastDriver.NextGenDocumentRepository.TitelReportInformationSourceRegion.FASelectItem("QA Sandpointe - Next Gen"); Playback.Wait(3500);
                var InfoSource_Reg = FastDriver.NextGenDocumentRepository.TitelReportInformationSourceRegion.FAGetSelectedItem();

                //---
                Reports.TestStep = "Enter Valid phrase code for Endorsments and select region";
                FastDriver.NextGenDocumentRepository.TitelReportEndorsement.FASetText(Endorsment_Corp);

                FastDriver.NextGenDocumentRepository.TitelReportEndorsementSourceRegion.FASelectItem("DOCPREP Corporate Region"); Playback.Wait(3500);
                var EndorSource_Reg = FastDriver.NextGenDocumentRepository.TitelReportEndorsementSourceRegion.FAGetSelectedItem();

                Reports.TestStep = "Click on Save";
                if (FastDriver.NextGenDocumentRepository.TitleReportSave.IsDisplayed())
                { FastDriver.NextGenDocumentRepository.TitleReportSave.FAClick(); Playback.Wait(9000); }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 50);


                //************************** Create another File ********************

                Reports.TestStep = "Login to File Side with superuser credential";
                var credentials1 = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials1);                                                  // creat a File -- superuser
                try { FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); } Playback.Wait(4000);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);
                var filenum_1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TemplateName1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "Create a title/poiicy document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TemplateName1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Documnet is created ";                     // Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var status_1 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status_1);

                Reports.TestStep = "Right click on document and Click on phrase/view edit ";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TemplateName1, "Name", TableAction.Click).Element.FARightClick();
                if (FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FAClick();
                    Playback.Wait(5000);
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please...", true, 40);

                Reports.TestDescription = "Verification of Copy From tab";
                Reports.TestStep = "clcik on Copy From";
                if (FastDriver.NextGenDocumentRepository.DocInfo_CopyFrom.IsDisplayed())
                { FastDriver.NextGenDocumentRepository.DocInfo_CopyFrom.FAClick(); Playback.Wait(5000); }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please...", true, 40);

                Reports.TestStep = "Verify the Copy From  default Field defination";
                FastDriver.CopyFrom.WaitForScreenToLoad();
                if (FastDriver.CopyFrom.Copy_FileNum.Exists() == true) { Reports.StatusUpdate("File Number field Is exist", true); }
                if (FastDriver.CopyFrom.CopyFrom_Region.Exists() == true) { Reports.StatusUpdate("Source Region select drop down is exist", true); }
                if (FastDriver.CopyFrom.CopyFrom_RadioExceptions.IsSelected() == true) { Reports.StatusUpdate("Exceptions radio Button  checked", true); }
                if (FastDriver.CopyFrom.CopyFrom_RadioRequirement.Exists() == true) { Reports.StatusUpdate("Requiremnt radio Button is exist", true); }
                if ((!FastDriver.CopyFrom.CopyFrom_RadioRequirement.IsSelected()) == true) { Reports.StatusUpdate("Requiremnt radio Button is not checked", true); }

                if (!(FastDriver.CopyFrom.Radio_rbInfoNotes.IsSelected()) == true) { Reports.StatusUpdate("infor Notes radio Button not checked", true); }
                if (!(FastDriver.CopyFrom.Radio_rbEndorsements.IsSelected()) == true) { Reports.StatusUpdate("Endorsements radio Button not checked", true); }  // Radio_ExcReqInfEnd
                if (!(FastDriver.CopyFrom.Radio_ExcReqInfEnd.IsSelected()) == true) { Reports.StatusUpdate("Endorsements radio Button not checked", true); }

                if (FastDriver.CopyFrom.Searchbtn.IsEnabled() == true) { Reports.StatusUpdate("Search button is exist", true); }
                if (FastDriver.CopyFrom.CopyFrom_RefreshBtn.IsEnabled() == true) { Reports.StatusUpdate("Refresh button is exist and Enable", true); }
                if (FastDriver.CopyFrom.AddPhrases.IsEnabled() == true) { Reports.StatusUpdate("Add Phrases button is exist and Enable", true); }

                Reports.TestStep = "Verify the Title Policy name and Exceptions is copied to new file";
                FastDriver.CopyFrom.Copy_FileNum.FASetText(filenum);
                FastDriver.CopyFrom.CopyFrom_Region.FASelectItem(ExcepSource_Reg);
                FastDriver.CopyFrom.CopyFrom_RefreshBtn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please...", true, 40); Playback.Wait(15000);
                FastDriver.CopyFrom.DocResultGrid.IsDisplayed();
                var Doc1_chk = FastDriver.CopyFrom.DocResultGrid.PerformTableAction(2, 1, TableAction.GetCell).Element.IsEnabled();
                FastDriver.CopyFrom.DocResultGrid.PerformTableAction(2, 1, TableAction.GetCell).Element.Highlight(10);
                FastDriver.CopyFrom.DocResultGrid.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(10);
                if (FastDriver.CopyFrom.DocResultGrid.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText() == TempifnoName)
                { FastDriver.CopyFrom.DocResultGrid.PerformTableAction(2, 1, TableAction.GetCell).Element.FAClick(); }
                if (FastDriver.CopyFrom.DocResultGrid.PerformTableAction(2, 7, TableAction.GetCell).Element.Exists())
                { FastDriver.CopyFrom.DocResultGrid.PerformTableAction(2, 7, TableAction.GetCell).Element.FAClick(); }
                Playback.Wait(15000);

                Reports.TestStep = "Selection of Exception phrase Code";
                var exceptionAddeding = FastDriver.CopyFrom.WebDriver.FAFindElement(ByLocator.Id, "gridPhraseSelection").PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();

                if (FastDriver.CopyFrom.WebDriver.FAFindElement(ByLocator.Id, "gridPhraseSelection").PerformTableAction(1, 2, TableAction.GetCell).Element.Exists())
                { FastDriver.CopyFrom.WebDriver.FAFindElement(ByLocator.Id, "gridPhraseSelection").PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "chkselPhrases").FASetCheckbox(true); }

                var ExceptionPhrasecode_selected = FastDriver.CopyFrom.WebDriver.FAFindElement(ByLocator.Id, "gridPhraseSelection").PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Playback.Wait(6000);

                #region click on done
                Reports.TestStep = "Click on done - after selection of Exception codes";
                FastDriver.CopyFrom.CopyFromExcep_Done.Highlight(10);
                FastDriver.CopyFrom.CopyFromExcep_Done.FAClick();
                Playback.Wait(4000);

                Reports.TestStep = "Click on Add Phrase to Add the phrase code";
                FastDriver.CopyFrom.AddPhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please...", true, 40);
                string Warningmessage = "Phrases From " + TempifnoName + " are successfully Processed.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Warningmessage);
                Playback.Wait(3000);
                Reports.TestStep = "Click on copy from done";
                FastDriver.CopyFrom.CopyFrom_BottomDone.FAClick();
                #endregion

                Reports.TestStep = "'verify the Exception Added through Copy from into current File";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var NewExceptionAdded = FastDriver.NextGenDocumentRepository.TitelReportExceptions.FAGetText();
                Support.AreEqual(NewExceptionAdded, exceptionAddeding);
                FastDriver.NextGenDocumentRepository.EffectiveDate.FASetText(s_today);
                FastDriver.NextGenDocumentRepository.TitleReportSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please...", true, 40);
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }



        }



        #endregion

        #region  REG0061_6.10	Lender/Owner Policy Info Tab
        [TestMethod]
        [Description(@" AlternateCourse: 6.10	Lender/Owner Policy Info Tab")]

        public void REG0061_LenderOwnerPolicyInfoTab()
        {
            try
            {
                string TemplateName1 = "NEXTGEN_SAN_LenderPolicy_DoNotTouch";
                string TemplateName = "NEXTGEN_SAN_TitleReports_DoNotTouch";

                string Exceptions1_NextGenRegion = "ASHV/ANNI,EQSP/EQSP";
                //string Exception2_corpregion = "EE/25,EE/10D,EE/10A,EE/10C";
                //string Reuirement1_Nextgen = "R/WR,R/9,R/A31,R/2P,R/WR,R/17,R/11,R/4";
                //string Reuirement2_CorpRegion = "RN/N10,RN/AFF,RN/T11M,RN/17,RN/4REO,RN/M37,RN/17,RN/M37,RN/4REO";
                //string InormationNotes1_Nextgen = "INP/INP1,INP/INP2,INFO/11,ATPZ/38,JL6/1C,JL6/4,JL6/7,JL6/7";
                //string InormationNotes2_Corp = "BAC/44,BAC/34,BAC/35,BAC/39,BAC/43,BAC/41,APAI/DE,RIN/13,RIN/19,RIN/16,RIN/20N,RIN/18N";
                //string Endorsment_NextGen = "EPS/EPS1,EPS/EPS2,ANEP/2,ANEP/1,PVGT/PVTP";
                //string Endorsment_Corp = "1461/0001";


                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", TemplateName, "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN300", TemplateName1, "Lender Policy");

                //Reports.TestDescription = "Login to IIS site";
                //FAST_Login_IIS(regionId: regionId);
                //FAST_OpenRegionOrOffice(officeId);
                //Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Login to File Side with superuser credential";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);                                                  // creat a File -- superuser
                try { FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); } Playback.Wait(4000);
                Support.IsTrue(WCF_CreateFileWithNewLoan() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);
                var filenum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "Create a title/poiicy document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TemplateName, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Document is created ";                     // Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);

                Reports.TestStep = "Right click on document and Click on phrase/view edit ";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TemplateName, "Name", TableAction.Click).Element.FARightClick();
                if (FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FAClick();
                    Playback.Wait(5000);
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please...", true, 40);

                Reports.TestStep = "Enter The vlaues into  the title Doc ";

                DateTime today = System.DateTime.Today; // As DateTime
                string s_today = today.ToString("MM/dd/yyyy"); // As String

                FastDriver.NextGenDocumentRepository.EffectiveDate.FASetText(s_today);

                Reports.TestStep = "modified the doc Name";
                FastDriver.NextGenDocumentRepository.TitleReportDocDescription.FASetText(TemplateName + "_Modified");
                var TempifnoName = FastDriver.NextGenDocumentRepository.TitleReportDocDescription.FAGetValue();

                Reports.TestStep = "Enter Valid phrase code for Excpetion and select region";
                FastDriver.NextGenDocumentRepository.TitelReportExceptions.FASetText(Exceptions1_NextGenRegion);
                FastDriver.NextGenDocumentRepository.TitelReportExceptionsSourceRegion.FASelectItem("QA Sandpointe - Next Gen");
                var ExcepSource_Reg = FastDriver.NextGenDocumentRepository.TitelReportExceptionsSourceRegion.FAGetSelectedItem();
                FastDriver.NextGenDocumentRepository.DocInfo_Save.FAClick();

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "Create a Lender/Owner poiicy document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TemplateName1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Documnet is created ";                     // Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var status1 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status1);

                Reports.TestStep = "Right click on document and Click on phrase/view edit ";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TemplateName1, "Name", TableAction.Click).Element.FARightClick();
                if (FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FAClick();
                    Playback.Wait(5000);
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please...", true, 40);

                Reports.TestStep = "Enter The vlaues into  the title Doc ";

                FastDriver.NextGenDocumentRepository.Policy_EffectiveDate.FASetText(s_today);
                FastDriver.NextGenDocumentRepository.Policy_IssueDate.FASetText("04-13-2016");
                FastDriver.NextGenDocumentRepository.PolicyInfo_PolicyNumber.FASetText("12345ABC");

                Reports.TestStep = "modified the doc Name";
                FastDriver.NextGenDocumentRepository.PolicyDescription.FASetText(TemplateName1 + "_Modified");
                var TempifnoName1 = FastDriver.NextGenDocumentRepository.PolicyDescription.FAGetValue();

                FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClick();




                //************************** Create another File ********************

                Reports.TestStep = "Login to File Side with superuser credential";
                var credentials1 = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials1);                                                  // creat a File -- superuser
                try { FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); } Playback.Wait(4000);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);
                var filenum_1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "Create a title/poiicy document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TemplateName, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TemplateName1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "Create a title/poiicy document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TemplateName1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Documnet is created ";                     // Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var status_1 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status_1);

                Reports.TestStep = "Right click on document and Click on phrase/view edit ";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TemplateName1, "Name", TableAction.Click).Element.FARightClick();
                if (FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FAClick();
                    Playback.Wait(5000);
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please...", true, 40);

                Reports.TestDescription = "Verification of Copy From tab";
                Reports.TestStep = "clcik on Copy From";
                if (FastDriver.NextGenDocumentRepository.DocInfo_CopyFrom.IsDisplayed())
                { FastDriver.NextGenDocumentRepository.DocInfo_CopyFrom.FAClick(); Playback.Wait(5000); }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please...", true, 40);


                Reports.TestStep = "Verify the Copy From  default Field defination";
                FastDriver.CopyFrom.WaitForScreenToLoad();
                if (FastDriver.CopyFrom.FileNumber.Exists() == true) { Reports.StatusUpdate("File Number field Is exist", true); }
                if (FastDriver.CopyFrom.CopyFrom_Region.Exists() == true) { Reports.StatusUpdate("Source Region select drop down is exist", true); }
                if (FastDriver.CopyFrom.CopyFrom_RadioExceptions.IsSelected() == true) { Reports.StatusUpdate("Exceptions radio Button  checked", true); }
                if (FastDriver.CopyFrom.CopyFrom_RadioRequirement.Exists() == true) { Reports.StatusUpdate("Requiremnt radio Button is exist", true); }
                if ((!FastDriver.CopyFrom.CopyFrom_RadioRequirement.IsSelected()) == true) { Reports.StatusUpdate("Requiremnt radio Button is not checked", true); }

                if (!(FastDriver.CopyFrom.Radio_rbInfoNotes.IsSelected()) == true) { Reports.StatusUpdate("infor Notes radio Button not checked", true); }
                if (!(FastDriver.CopyFrom.Radio_rbEndorsements.IsSelected()) == true) { Reports.StatusUpdate("Endorsements radio Button not checked", true); }  // Radio_ExcReqInfEnd
                if (!(FastDriver.CopyFrom.Radio_ExcReqInfEnd.IsSelected()) == true) { Reports.StatusUpdate("Endorsements radio Button not checked", true); }

                if (FastDriver.CopyFrom.Searchbtn.IsEnabled() == true) { Reports.StatusUpdate("Search button is exist", true); }
                if (FastDriver.CopyFrom.CopyFrom_RefreshBtn.IsEnabled() == true) { Reports.StatusUpdate("Refresh button is exist and Enable", true); }
                if (FastDriver.CopyFrom.AddPhrases.IsEnabled() == true) { Reports.StatusUpdate("Add Phrases button is exist and Enable", true); }

                Reports.TestStep = "Verify the Title Policy name and Exceptions is copied to new file";
                FastDriver.CopyFrom.Copy_FileNum.FASetText(filenum);
                FastDriver.CopyFrom.CopyFrom_Region.FASelectItem(ExcepSource_Reg);
                FastDriver.CopyFrom.CopyFrom_RefreshBtn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please...", true, 40); Playback.Wait(15000);
                FastDriver.CopyFrom.DocResultGrid.IsDisplayed();
                FastDriver.CopyFrom.WaitForScreenToLoad();
                var Doc1_chk = FastDriver.CopyFrom.DocResultGrid.PerformTableAction(2, 3, TableAction.GetCell).Element.IsEnabled();
                FastDriver.CopyFrom.DocResultGrid.PerformTableAction(2, 3, TableAction.GetCell).Element.Highlight(10);
                if (FastDriver.CopyFrom.DocResultGrid.PerformTableAction("Document Name", TempifnoName1, "Document Name", TableAction.GetCell).Element.Exists())
                { FastDriver.CopyFrom.DocResultGrid.PerformTableAction(2, 3, TableAction.GetCell).Element.FAClick(); }
                if (FastDriver.CopyFrom.DocResultGrid.PerformTableAction(2, 9, TableAction.GetCell).Element.Exists())
                { FastDriver.CopyFrom.DocResultGrid.PerformTableAction(2, 9, TableAction.GetCell).Element.FAClick(); }
                Playback.Wait(15000);

                Reports.TestStep = "Selection of Exception phrase Code";
                var exceptionAddeding = FastDriver.CopyFrom.WebDriver.FAFindElement(ByLocator.Id, "gridPhraseSelection").PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();

                if (FastDriver.CopyFrom.WebDriver.FAFindElement(ByLocator.Id, "gridPhraseSelection").PerformTableAction(1, 2, TableAction.GetCell).Element.Exists())
                { FastDriver.CopyFrom.WebDriver.FAFindElement(ByLocator.Id, "gridPhraseSelection").PerformTableAction(1, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "chkselPhrases").FASetCheckbox(true); }

                var ExceptionPhrasecode_selected = FastDriver.CopyFrom.WebDriver.FAFindElement(ByLocator.Id, "gridPhraseSelection").PerformTableAction(1, 2, TableAction.GetCell).Element.FAGetText();
                Playback.Wait(6000);

                #region click on done
                Reports.TestStep = "Click on done - after selection of Exception codes";
                FastDriver.CopyFrom.CopyFromExcep_Done.FAClick();
                Playback.Wait(4000);

                Reports.TestStep = "Click on Add Phrase to Add the phrase code";
                FastDriver.CopyFrom.AddPhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please...", true, 40);
                string Warningmessage = "Phrases From " + TempifnoName + " are successfully Processed.";
                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Warningmessage);
                Playback.Wait(3000);
                Reports.TestStep = "Click on copy from done";
                FastDriver.CopyFrom.CopyFrom_BottomDone.FAClick();
                #endregion

                Reports.TestStep = "'verify the Exception Added through Copy from into current File";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.LenderException.Highlight(5);
                var NewExceptionAdded = FastDriver.NextGenDocumentRepository.LenderException.FAGetText();
                Support.AreEqual(NewExceptionAdded, exceptionAddeding);
                FastDriver.NextGenDocumentRepository.PolicyReportSave.FAClick();

            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }



        }



        #endregion

        #region REG0043_6_15_16_Commitment
        [TestMethod]
        [Description("verify the user to associate a Policy template to a Title Report and Endorsment/Guarentee to Policy")]
        public void REG0043_6_15_16_Commitment()
        {
            try
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                Reports.TestDescription = "Login to ADM site";
                FAST_Login_ADM(isSuperUser: true);
                try
                {
                    FAST_OpenRegionOrOffice(officeId);
                }

                catch (Exception ex)
                {
                    FailTest(GetExceptionInfo(ex));

                }
                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                // Pre-Condition
                LoadTemplateOrCreateNew("SAN-NEXTGEN201", "NEXTGEN_DESCRIPTION_TEST", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN400", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                LoadTemplateOrCreateNew("SAN-NEXTGEN500", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");

                CloseRelatedProcesses();

                string TitleTemplateName1 = "NEXTGEN_SAN_TitleReports_DoNotTouch";

                string TitleTemplateName2 = "NEXTGEN_DESCRIPTION_TEST";

                string PolicyTemplateName1 = "NEXTGEN_SAN_LenderPolicy_DoNotTouch";
                string PolicyTemplateName2 = "NEXTGEN_SAN_OwnerPolicy_DoNotTouch";
                string EndorsmentGuarantee1 = "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch";

                #region   verify the user able to associate a Policy template to a Title Report
                Reports.TestDescription = "verify the user able to associate a Policy template to a Title Report ";
                Reports.TestStep = "Login to File Side with superuser credential";


                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);                                                  // creat a File -- superuser
                try { FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); } Playback.Wait(4000);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);
                var filenum = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); FastDriver.NextGenDocumentRepository.TemplateSearchButton.Highlight(5);
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TitleTemplateName1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "Create a title/poiicy document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TitleTemplateName1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 50);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Documnet is created ";                     // Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);


                #region Create Another Title Report

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); FastDriver.NextGenDocumentRepository.TemplateSearchButton.Highlight(5);
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TitleTemplateName2);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "Create a title/poiicy document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TitleTemplateName2, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Documnet is created ";                     // Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var status_1 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status_1);


                #endregion

                #region Verify any policy creation and Associate to anY Tile Report
                Reports.TestStep = "Verify that Policy Document can not be created with assoication to titile Report";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); FastDriver.NextGenDocumentRepository.TemplateSearchButton.Highlight(5);
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);


                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(PolicyTemplateName1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "Create a title/poiicy document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", PolicyTemplateName1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 50);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();


                Reports.TestStep = "Verify the Popup for association with Title is Open and Exist";
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divTitlePolicySelection").Highlight(10);
                if (FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists())
                { Reports.StatusUpdate("Association popup is exist", true); }

                Reports.TestStep = "Verify that Policy document can not be created without association with any Title Doc";

                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsCommtiment_Done.FAClick();
                Playback.Wait(5000);
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (!(FastDriver.NextGenDocumentRepository.DocumentsTable.FAFindElement(ByLocator.Id, "DocumentName").FADescription() == "NEXTGEN_SAN_LenderPolicy_DoNotTouch"))
                { Reports.StatusUpdate("Policy Document is not Created", true); }

                Reports.TestStep = "Associate Policy to Title report";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); FastDriver.NextGenDocumentRepository.TemplateSearchButton.Highlight(5);
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(PolicyTemplateName1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", PolicyTemplateName1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 50);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divTitlePolicySelection").Highlight();
                if (FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists())
                { Reports.StatusUpdate("Association popup is exist", true); }

                if (FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists())
                {
                    if (FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAGetText() == TitleTemplateName1)

                    { FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAClick(); }
                }

                FastDriver.NextGenDocumentRepository.TitlePolicyDetailsCommtiment_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 90);
                //Reports.TestStep = "Verify Policy doc is created after association";
                //if(FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", PolicyTemplateName1, "Name", TableAction.Click).Element.Exists())
                //{ Reports.StatusUpdate("Policy Document is  Created", true); }

                Playback.Wait(5000);
                #endregion

                #endregion

                #region   verify the user able to associate a  Endorsment/Guarentee to Policy
                Reports.TestDescription = "verify the user able to associate a  Endorsment/Guarentee to Policy";


                Reports.TestStep = "Login to File Side with superuser credential";
                var credentials1 = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials1);                                                  // creat a File -- superuser
                try { FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); } Playback.Wait(4000);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);
                var filenum1 = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); FastDriver.NextGenDocumentRepository.TemplateSearchButton.Highlight(5);
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TitleTemplateName1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "Create a title/poiicy document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TitleTemplateName1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 50);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Documnet is created ";                     // Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var status_0 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status_0);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); FastDriver.NextGenDocumentRepository.TemplateSearchButton.Highlight(5);
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(PolicyTemplateName1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "Create a title/poiicy document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", PolicyTemplateName1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 50);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Documnet is created ";                     // Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var status_2 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(2, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status_2);


                #region Create Another Title Report

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); FastDriver.NextGenDocumentRepository.TemplateSearchButton.Highlight(5);
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(PolicyTemplateName2);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "Create a title/poiicy document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", PolicyTemplateName2, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Documnet is created ";                     // Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var status_3 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status_3);


                #endregion

                #region Verify any policy creation and Associate to anY Tile Report
                Reports.TestStep = "Verify that Policy Document can not be created with assoication to titile Report";

                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search for Endorsment Guarantee";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); FastDriver.NextGenDocumentRepository.TemplateSearchButton.Highlight(5);
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                Playback.Wait(5000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);


                Reports.TestStep = "search Endorsement Template";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EndorsmentGuarantee1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                Reports.TestStep = "Create a Endorsment document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", EndorsmentGuarantee1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 50);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();


                Reports.TestStep = "Verify the Popup for association with Title is Open and Exist";
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divTitlePolicySelection").Highlight(10);
                if (FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists())
                { Reports.StatusUpdate("Association popup is exist", true); }

                Reports.TestStep = "Verify that EndorsementGuarantee document can not be created without association with any Title Doc";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.Highlight(5);
                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.FAClick();
                Playback.Wait(5000);
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (!(FastDriver.NextGenDocumentRepository.DocumentsTable.FAFindElement(ByLocator.Id, "DocumentName").FADescription() == "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch"))
                { Reports.StatusUpdate("Endorsment Document is not Created", true); }

                Reports.TestStep = "Associate Endorsment to policy ";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); FastDriver.NextGenDocumentRepository.TemplateSearchButton.Highlight(5);
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(EndorsmentGuarantee1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", EndorsmentGuarantee1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 50);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.Id, "divTitlePolicySelection").Highlight();
                if (FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists())
                { Reports.StatusUpdate("Association popup is exist", true); }

                if (FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Exists())
                {
                    if (FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAGetText() == PolicyTemplateName1)

                    { FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAClick(); }
                }

                FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);


                Reports.TestStep = "Verify Policy doc is created after association";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(5000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", EndorsmentGuarantee1, "Name", TableAction.Click).Element.Exists())
                { Reports.StatusUpdate("Endorsemnt/Gurantee Document is  Created", true); }

                Playback.Wait(5000);
                #endregion

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        #endregion


        #region REG0001
        [TestMethod]
        [Description("Test NEw")]
        public void REG000111()
        {
            try
            {
                Reports.TestDescription = "Associate Doc IMageDoc";



                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion



                Reports.TestDescription = "Login to IIS Side";

                #region  Login to FAST File side, Create File and Navigate to NextGen DOC Repo.

                Reports.TestStep = "Login to IIS and Naviagte to NextGen DOC Screen";
                FAST_Login_IIS(regionId: regionId);
                try { FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); }
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open();

                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").Highlight();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").FADoubleClick();
                //  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FAFindElement(ByLocator.Id, "ddcl-ddl_sources").FADoubleClick();
                FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateDescription.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select one template by using \"Ctrl\" command

                Reports.TestStep = "Select one template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                Reports.TestStep = "Create Package";
                var documents = new List<string> { "NEXTGEN_SAN_Endorsement_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                #endregion

                #region  Create Document
                Reports.TestStep = "Create Document";

                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_Endorsement_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                Playback.Wait(9000);
                #endregion
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();


                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").Highlight();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAFindElement(ByLocator.Id, "btnDocTemplateSearch").FAClickAction();
                //  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FindElement(By.Id("ddcl-ddl_sources")).FAClick();
                FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateDescription.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select one template by using \"Ctrl\" command

                Reports.TestStep = "Select one template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                Reports.TestStep = "Create Package";
                var documents_two = new List<string> { "NEXTGEN_SAN*" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents_two);
                #endregion

                #region  Creat Document
                Reports.TestStep = "Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                Playback.Wait(9000);
                #endregion

                Reports.TestStep = "Right Click for Context Menu";
                var documents1 = new List<string> { "NEXTGEN_SAN_Endorsement_DoNotTouch", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents1);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();

                Reports.TestStep = "Select \"Add to Associate Package\" option";
                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();



                Playback.Wait(5000);

                #region   Validate the message if package is not selected
                Reports.TestStep = "Validate the message if package is not selected";
                try
                {
                    FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick(); Playback.Wait(8000);
                }
                catch { FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//div/div[@class='ui-dialog-buttonset']/button/span[text()='Done']").FAClick(); }


                string mesg = "Please select an option.";
                Support.AreEqual(mesg, "Please select an option.");
                Reports.TestStep = "Click on ok";
                Support.MessageHandler(true);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                Reports.TestStep = "Enter/Edit the Asso. Package name";

                FastDriver.NextGenDocumentRepository.Assoc_EditpackageName.FASetText("New_Associate_Package1");

                FastDriver.NextGenDocumentRepository.Asso_PakageRadio.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                string Message = "Package : " + "'" + "New_Associate_Package1" + "'" + " created successfully.";

                FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(CompareWith: Message);

                Playback.Wait(5000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 40);
                #region   Finalize the document before Deliverd

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_Endorsement_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Doc_Finalize.FASelectContextMenuItem();
                Playback.Wait(6000);

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Doc_Finalize.FASelectContextMenuItem(); Playback.Wait(5000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(); Playback.Wait(5000);
                FastDriver.NextGenDocumentRepository.PackageLink.Highlight(2);
                FastDriver.NextGenDocumentRepository.PackageLink.SendKeys(FAKeys.Enter); Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (!FastDriver.NextGenDocumentRepository.FirstRTMPackage.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.RTMPackageLink.FAClick();
                }

                #endregion


                FastDriver.NextGenDocumentRepository.PackageLink.FASendKeys(FAKeys.Enter);
                FastDriver.NextGenDocumentRepository.AssoPackageLink.FAClickAction();
                FastDriver.NextGenDocumentRepository.FirstAssoMPackage.IsDisplayed();
                FastDriver.NextGenDocumentRepository.FirstAssoMPackage.FARightClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//ul[@id='aDocSubMenu']/li[@class='Deliver separator']/a[@href='#Deliver']"));
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//ul[@id='aDocSubMenu']/li[@class='Deliver separator']/a[@href='#Deliver']").FAMoveToElement();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//ul[@id='aDocSubMenu']//a[@href='#ImageDoc']"));
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//ul[@id='aDocSubMenu']//a[@href='#ImageDoc']").Highlight(5);
                FastDriver.NextGenDocumentRepository.WebDriver.FAFindElement(ByLocator.XPath, "//ul[@id='aDocSubMenu']//a[@href='#ImageDoc']").FADoubleClick();
                FastDriver.NextGenDocumentRepository.ImageDocRTM.JSClick(); Playback.Wait(6000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.EmailDlg.WaitForDialogToLoad();










            }

            catch (Exception)
            {
                throw;
            }
        }


        #endregion // Ma in Course 1

       

        #region REG0044_US#246100 watermark Policy/Endorsment
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        public void REG0044_US_246100()
        {
            try
            {
                IRDebugging(true);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "US # 246100 watermark Policy/Endorsment"; 
                Reports.TestDescription = "Login to IIS site";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");


                #region  creating  NEXTGEN_SAN_TitleReports_DoNotTouch       Document
                #region Navigate to Document Repository Screen

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select a templates by using "Ctrl" command
                Reports.TestStep = "Select one template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documentsTitle = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documentsTitle);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #endregion


                #region  creating  NEXTGEN_SAN_OwnerPolicy_DoNotTouch       Document
                #region Navigate to Document Repository Screen

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select a templates by using "Ctrl" command
                Reports.TestStep = "Select one template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documentsOwner = new List<string> { "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documentsOwner);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #endregion


                #region  Creating  NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch       Document
                #region Navigate to Document Repository Screen

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on "Template Search" button
                Reports.TestStep = "Click on \"Template Search\" button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for templates using search criteria
                Reports.TestStep = "Search for templates using search criteria";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                #endregion

                #region Select a templates by using "Ctrl" command
                Reports.TestStep = "Select one template by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                var documentsEndorse = new List<string> { "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documentsEndorse);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Select "Create Document" option
                Reports.TestStep = "Select \"Create Document\" option";
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #endregion

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Name", TableAction.GetCell).Element.Exists();

                string status_3 = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(6, 10, TableAction.GetCell).Element.FAGetText();

                Playback.Wait(3000);
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Name", TableAction.GetCell).Element.Exists())
                {
                    FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                }

                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FAClickAction();
                Playback.Wait(12000);
                FastDriver.DocumentEditor.WaitForScreenToLoad();

                #region Select Draft in Watermark Dropdown
                Reports.TestStep = "Select Draft in Watermark Dropdown";
                FastDriver.DocumentEditor.IRSelectWatermark(FastDriver.DocumentEditor.IRDoc_Draft);
                #endregion

                #region Select Priview in Delivery Dropdown
                Reports.TestStep = "Select Priview in Delivery Dropdown";
                FastDriver.DocumentEditor.IRDelivery1(FastDriver.DocumentEditor.IRDocDeliveryPreview);
                #endregion

                #region Switch to Preview window and Close
                Reports.TestStep = "Switch to Preview window and Close";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Status: Delivery Requested...", false, 30);
                Playback.Wait(8000);          
                Keyboard.SendKeys("%{f4}");
                #endregion
                                  
                #region Switch to Document Editor window save and Close
                Reports.TestStep = "Switch to Document Editor window save and Close";
                FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                #endregion

                #region Finalize the Document
                Reports.TestStep = "Finalize the Document";
                FastDriver.DocumentEditor.FinalizeDocument1();
                #endregion

               
                #region Select Priview in Delivery Dropdown
                Reports.TestStep = "Select Priview in Delivery Dropdown";
                FastDriver.DocumentEditor.IRDelivery1(FastDriver.DocumentEditor.IRDocDeliveryPreview);
                #endregion

                #region Switch to Preview window and Close
                Reports.TestStep = "Switch to Preview window and Close";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Status: Delivery Requested...", false, 30);
                Playback.Wait(8000);          
                Keyboard.SendKeys("%{f4}");
                #endregion
                                  
                #region Switch to Document Editor window save and Close
                Reports.TestStep = "Switch to Document Editor window save and Close";
                FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
               // FastDriver.DocumentEditor.SaveAndClose();                         

                FastDriver.DocumentEditor.CloseEditor();
                FastDriver.NextGenDocumentRepository.Open();
                #endregion
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


       #endregion
                       
        #region REG0045
          [TestMethod]
        public void REG0045()
        {
              try
              {
                    IRDebugging(true);
                    SetSilverlightClipboardPermission_YES();

                    Reports.TestDescription = "Login to IIS site";
                    FAST_Login_IIS(regionId: regionId);
                    FAST_OpenRegionOrOffice(officeId);
                    Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                    #region Navigate to Document Repository Screen

                    Reports.TestStep = "Navigate to Document Repository Screen";
                    FastDriver.NextGenDocumentRepository.Open();
                    #endregion

                    #region Click on "Template Search" button
                    Reports.TestStep = "Click on \"Template Search\" button";
                    FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                    #endregion

                    #region Search for templates using search criteria
                    Reports.TestStep = "Search for templates using search criteria";
                    FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                    FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                    FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                    FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);

                    Playback.Wait(3500);
                    #region   Save the search as favorite search
                    Reports.TestDescription = "Save the search as favorite search";

                    FastDriver.NextGenDocumentRepository.MySearchSaveButton.FAClickAction(); Playback.Wait(3000);
                    if(FastDriver.NextGenDocumentRepository.FavoriteSearchSaveBtn.Exists())
                    {
                          FastDriver.NextGenDocumentRepository.FavoriteSearchSaveBtn.FAClickAction();
                    }
                    Reports.TestStep = "verify that Favorite filter name can not be emplty.";
                    string MSG1 = "Filter Name cannot be empty!";
                    FastDriver.NextGenDocumentRepository.AcceptDialogAndCompareWith(MSG1, true);
                    if(FastDriver.NextGenDocumentRepository.FavoriteSearchDIV.IsDisplayed() == true)
                    {
                          FastDriver.NextGenDocumentRepository.EnterNewFilterName.FASetText("NEXTGEN Filter");
                    }

                    Reports.TestStep = "Save favorite search as a primary filter";
                    FastDriver.NextGenDocumentRepository.FavoriteSearchPrimaryChk.FASetCheckbox(true);
                    FastDriver.NextGenDocumentRepository.FavoriteSearchSaveBtn.FAClickAction();
                    #endregion


                    #endregion



                    #region  creating  NEXTGEN_SAN_TitleReports_DoNotTouch       Document
                    #region Navigate to Document Repository Screen

                    Reports.TestStep = "Navigate to Document Repository Screen";
                    FastDriver.NextGenDocumentRepository.Open();
                    #endregion

                    #region Click on "Template Search" button
                    Reports.TestStep = "Click on \"Template Search\" button";
                    FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                    #endregion

                    #region Search for templates using search criteria
                    Reports.TestStep = "Search for templates using search criteria";
                    FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                    FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                    FastDriver.NextGenDocumentRepository.Search.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                    #endregion

                    #region Select a templates by using "Ctrl" command
                    Reports.TestStep = "Select one template by using \"Ctrl\" command";
                    FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                    var documentsTitle = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch" };
                    FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documentsTitle);
                    #endregion

                    #region Hold Right Click
                    Reports.TestStep = "Hold Right Click";
                    FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                    #endregion

                    #region Select "Create Document" option
                    Reports.TestStep = "Select \"Create Document\" option";
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    #endregion

                    #endregion

               

              }

              catch (Exception ex)
              {
                    FailTest(ex.Message);
                }



        }



        #endregion

        #region REG0064_US244531
          [TestMethod]
          [Description("US # 244531: Editing Documents with Finalized Status")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
          [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
          public void REG0064_US244531()
          {
              try
              {



                  IRDebugging(true);
                  SetSilverlightClipboardPermission_YES();


                  Reports.TestDescription = "US # 244531:Editing Documents with Finalized Status";

                  Reports.TestDescription = "Login to IIS site";
                  FAST_Login_IIS(regionId: regionId);
                  FAST_OpenRegionOrOffice(officeId);
                  Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                  #region Navigate to Document Repository Screen
                  Reports.TestStep = "Navigate to Document Repository Screen";
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion

                  #region Click on "Template Search" button
                  Reports.TestStep = "Click on \"Template Search\" button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion

                  #region Search for templates using search criteria
                  Reports.TestStep = "Search for templates using search criteria";
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Select Multiple templates (2 or more) by using "Ctrl" command
                  Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  var documents = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                  #endregion

                  #region Hold Right Click
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Select "Create Document" option
                  Reports.TestStep = "Select \"Create Document\" option";
                  FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Select and double click on the Escrow Instruction type document
                  Reports.TestStep = "Select and double click on the Escrow Instruction type document";
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                  FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Status", TableAction.GetCell).Element.FADoubleClick();
                  #endregion

                  #region Select "Finalized" option from the dropdown
                  Reports.TestStep = "Select \"Finalized\" option from the Status dropdown";
                  FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Status", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "item.DocStatusCD").FASelectItem("Finalized");
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Click on "Document View/Edit" and Go to the Document Editor
                  Reports.TestStep = "Click on \"Document View/Edit\" and Go to the Document Editor";

                  FastDriver.NextGenDocumentRepository.Open();
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.DocumentsInnerTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Type", TableAction.GetCell).Element.FARightClick();

                  FastDriver.NextGenDocumentRepository.DocumentViewEdit.Highlight(5);
                  FastDriver.NextGenDocumentRepository.DocumentViewEdit.FAClick();
                  FastDriver.DocumentEditor.WaitForScreenToLoad();
                  Playback.Wait(3000);
                  #endregion

                  #region Enter Text in the Editor
                  Reports.TestStep = "Enter Text in the Editor";
                  var currentLine = FastDriver.DocumentEditor.IRDocumentCurrentLineEdit;
                  if (currentLine.DelayOnce(10).Visible() == false)
                      currentLine.DelayOnce(10);
                  currentLine.ContextHighlight();
                  Keyboard.SendKeys(FAKeys.Enter);
                  Keyboard.SendKeys("Test1234");
                  //FastDriver.DocumentEditor.IRDocumentCurrentLineEdit.ContextHighlight();
                  #endregion

                  #region Verify if Text in the Editor is entered
                  Reports.TestStep = "Verify if Text in the Editor is entered";
                  Support.AreEqual("False", FastDriver.DocumentEditor.IRDocumentCurrentLineEdit.FAGetText().Contains("Test1234").ToString(), false);
                  #endregion

                  #region Click on Unfinalized and make it "Unfinalized"
                  Reports.TestStep = "Click on Unfinalized and make it \"Unfinalized\"";
                  FastDriver.DocumentEditor.UnfinalizeDocumentEdit("Test");
                  #endregion

                  #region Insert another Phrase
                  Reports.TestStep = "Insert another Phrase";
                  FastDriver.DocumentEditor.InsertPhraseBelowAndSave("NGS1/1", "NEXTGEN-SAN-EscrowPhrase-DoNotTouch");
                  FastDriver.NextGenDocumentRepository.Open();

                  #endregion

              }
              catch (Exception ex)
              {
                  FailTest(GetExceptionInfo(ex));
              }
          }

          #endregion

        #region REG0065_US244588
          [TestMethod]
          [Description("US # 244588: Default Document Description  ")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
          [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
          public void REG0065_US244588()
          {
              try
              {
                  string documentTable;


                  IRDebugging(true);
                  SetSilverlightClipboardPermission_YES();

                  // EnableSavingIRSamples();
                  SetSilverlightClipboardPermission_YES();

                  Reports.TestDescription = "US # 244588: Default Document Description";
                 
                  Reports.TestDescription = "Login to IIS site";
                  FAST_Login_IIS(regionId: regionId);
                  FAST_OpenRegionOrOffice(officeId);
                  Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                  #region Navigate to Document Repository Screen
                  Reports.TestStep = "Navigate to Document Repository Screen";
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion

                  #region Click on "Template Search" button
                  Reports.TestStep = "Click on \"Template Search\" button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion

                  #region Search for templates using search criteria
                  Reports.TestStep = "Search for templates using search criteria";
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Select Title Report Template by using "Ctrl" command
                  Reports.TestStep = "Select Title Report Template by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  var documents = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch" };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FAClick();
                  #endregion



                  #region Click on Info Tab
                  Reports.TestStep = "Click on Info Tab";
                  FastDriver.NextGenDocumentRepository.DocumentInfoTab.Highlight(5);
                  FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClickAction();
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.TitleReportDocDescription.Clear();
                  FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClickAction();
                  #endregion

                  #region Verify the Error Message
                  Reports.TestStep = "Verify the Error Message";
                  Support.AreEqual("Missing commitment Name.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                  FastDriver.NextGenDocumentRepository.TemplateResultsTab.Highlight(5);
                  FastDriver.NextGenDocumentRepository.TemplateResultsTab.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  #endregion


                  //#region Select Multiple templates (2 or more) by using "Ctrl" command
                  //Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                  //FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  //var documents1 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                  //FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents1);
                  //#endregion

                  //#region Hold Right Click
                  //Reports.TestStep = "Hold Right Click";
                  //FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                  //#endregion

                  //#region Select "Create Document" option
                  //Reports.TestStep = "Select \"Create Document\" option";
                  //FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  //FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  //#endregion

                  #region Navigate to Document Repository Screen
                  Reports.TestStep = "Navigate to Document Repository Screen";
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion

                  #region Click on "Template Search" button
                  Reports.TestStep = "Click on \"Template Search\" button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion

                  #region Search for templates using search criteria
                  Reports.TestStep = "Search for templates using search criteria";
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion


                  #region Select Multiple templates (2 or more) by using "Ctrl" command
                  Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  var documents1 = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents1);
                  #endregion

                  #region Hold Right Click
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Select "Create Document" option
                  Reports.TestStep = "Select \"Create Document\" option";
                  FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  #endregion





                  #region Select a policy Document by using "Ctrl" command
                  Reports.TestStep = "Select a policy Document by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  var documents2 = new List<string> { "NEXTGEN_SAN_LenderPolicy_DoNotTouch" };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents2);
                  #endregion

                  #region Hold Right Click
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Name", TableAction.GetCell).Element.FADoubleClick();
                  #endregion

                  #region Click on Info Tab
                  Reports.TestStep = "Click on Info Tab";
                  FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClickAction();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.PolicyDescription.Clear();
                  FastDriver.NextGenDocumentRepository.PolicyInfoSave.FAClickAction();
                  #endregion

                  #region Verify the Error Message
                  Reports.TestStep = "Verify the Error Message";
                  Support.AreEqual("Policy Description is missing", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion

                  #region Click on "Template Search" button
                  Reports.TestStep = "Click on \"Template Search\" button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion

                  #region Search for templates using search criteria
                  Reports.TestStep = "Search for templates using search criteria";
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Select Endorsement/Guarantee Template by using "Ctrl" command
                  Reports.TestStep = "Select Endorsement/Guarantee Template by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  var documents4 = new List<string> { "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents4);
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.GetCell).Element.FAClick();
                  #endregion


                  #region Hold Right Click
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Select "Create Document" option
                  Reports.TestStep = "Select \"Create Document\" option";
                  FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  #endregion

                  #region Select Endorsement/Guarantee Document by using "Ctrl" command
                  Reports.TestStep = "Select Endorsement/Guarantee Document by using \"Ctrl\" command";
                  var documents3 = new List<string> { "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents3);
                  #endregion

                  #region Select any Policy from the grid
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Highlight(3);


                  FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.GetRowCount(), 1, TableAction.GetCell).Element.FADoubleClick();


                  FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.Highlight(3);
                  FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.FADoubleClick();
                  #endregion

                  #region Double Click
                  Reports.TestStep = "Double Click";
                  FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Name", TableAction.GetCell).Element.FADoubleClick();
                  #endregion

                  #region Click on Info Tab
                  Reports.TestStep = "Click on Info Tab";
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.DocumentInfoTab1.Highlight(5);
                  FastDriver.NextGenDocumentRepository.DocumentInfoTab1.FAClickAction();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.PolicyDescription.Clear();
                  FastDriver.NextGenDocumentRepository.EndorsementInfoSave.Highlight(3);
                  FastDriver.NextGenDocumentRepository.EndorsementInfoSave.FAClickAction();
                  #endregion

                  #region Verify the Error Message
                  Reports.TestStep = "Verify the Error Message";
                  Support.AreEqual("Description is missing", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion

                  #region Select a Title Report, right click and click on "Edit Document Name"
                  Reports.TestStep = "Select a Title Report, right click and click on \"Edit Document Name\" ";
                  FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                  FastDriver.NextGenDocumentRepository.EditDocumentName.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.EditDocumentDlg.EditDocumentNameDialog.Highlight(5);
                  #endregion

                  #region Clear the "Edit document Name" Textbox and click on "Done"
                  Reports.TestStep = "Clear the \"Edit document Name\" Textbox and click on \"Done\".";
                  FastDriver.EditDocumentDlg.EditDocName.Clear();
                  FastDriver.EditDocumentDlg.EditDocument_Done.FAClick();
                  #endregion


                  #region Verify the Error Message
                  Reports.TestStep = "Verify the Error Message";
                  Support.AreEqual("Document Name is Required..", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion


                  #region Click on "Template Search" button
                  Reports.TestStep = "Click on \"Template Search\" button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion

                  #region Search for templates using search criteria
                  Reports.TestStep = "Search for templates using search criteria";
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Select Title Report Template by using "Ctrl" command
                  Reports.TestStep = "Select Title Report Template by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  var documents5 = new List<string> { "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents5);
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FAClick();
                  #endregion


                  #region Hold Right Click
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Select "Create Document" option
                  Reports.TestStep = "Select \"Create Document\" option";
                  FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  #endregion


                  #region Perform ImageDoc Delivery and verify "Edit Document Name" functionality
                  //FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1,7, TableAction.GetCell).Element.FARightClick();
                  FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                  FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                  FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.FAClick();
                  // FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.JSClick();
                  FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                  FastDriver.ImageDocDlg.WaitForScreenToLoad();
                  FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                  FastDriver.ImageDocDlg.markDraft.FASetCheckbox(true);
                  FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                  FastDriver.ImageDocDlg.Deliver();
                  FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 400);
                  #endregion

                  #region Verify "Control Types"  are visible in Documents Table when Status is "Imaged in Edit Document Name Dialog."
                  Reports.TestStep = "Verify \"Control Types\"  are visible in DocumentsTable when Status is \"Imaged\"in Edit Document Name Dialog.";
                  FastDriver.NextGenDocumentRepository.Open();

                  string strDocStatusType = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.PerformTableAction("Type", "Imaged Document", "Status", TableAction.GetCell).Element.FAGetText();
                  if (strDocStatusType == "Imaged")
                  {


                      FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Type", "Imaged Document", "Type", TableAction.GetCell).Element.FARightClick();
                      FastDriver.NextGenDocumentRepository.EditDocumentName.FAClick();
                      FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                      FastDriver.EditDocumentDlg.EditDocumentNameDialog.Highlight(5);


                      #region Clear the "Edit document Name" Textbox and click on "Done"
                      Reports.TestStep = "Clear the \"Edit document Name\" Textbox and click on \"Done\".";
                      FastDriver.EditDocumentDlg.EditDocName.Clear();
                      FastDriver.EditDocumentDlg.ChangeDocTypeChk.FASetCheckbox(true);
                      FastDriver.EditDocumentDlg.DocumentTypeCbo.FASelectItemByIndex(0);
                      FastDriver.EditDocumentDlg.EditDocument_Done.FAClickAction();
                      #endregion


                      #region Verify the Error Message
                      Reports.TestStep = "Verify the Error Message";
                      Support.AreEqual("Document Type and Document Name are required fields.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                      FastDriver.NextGenDocumentRepository.Open();
                      #endregion



                  }


                  #endregion




              }
              catch (Exception ex)
              {
                  FailTest(GetExceptionInfo(ex));
              }
          }

          #endregion


        #region REG0066_US244589
          [TestMethod]
          [Description("US # 244589: Document Status Changes")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
          [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
          public void REG0066_US244589()
          {
              try
              {



                  IRDebugging(true);
                  SetSilverlightClipboardPermission_YES();


                  Reports.TestDescription = "US # 244589: Document Status Changes";

                  Reports.TestDescription = "Login to IIS site";
                  FAST_Login_IIS(regionId: regionId);
                  FAST_OpenRegionOrOffice(officeId);
                  Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                  #region Navigate to Document Repository Screen
                  Reports.TestStep = "Navigate to Document Repository Screen";
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion

                  #region Click on "Template Search" button
                  Reports.TestStep = "Click on \"Template Search\" button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion

                  #region Search for templates using search criteria
                  Reports.TestStep = "Search for templates using search criteria";
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Select Multiple templates (2 or more) by using "Ctrl" command
                  Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  var documents = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                  #endregion

                  #region Hold Right Click
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Select "Create Document" option
                  Reports.TestStep = "Select \"Create Document\" option";
                  FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion


                  #region Verify the "Status" of the "File Document"
                  Reports.TestStep = "Verify the \"Status\" of the \"File Document\" ";
                  FastDriver.NextGenDocumentRepository.Open();   
                  string strStatus = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Status", TableAction.GetCell).Element.FAGetText();
                  Support.AreEqual("Created", strStatus, true);          
                  #endregion

                  #region Select and double click on the Escrow Instruction type document
                  Reports.TestStep = "Select and double click on the Escrow Instruction type document";
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                  FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.GetCell).Element.FADoubleClick();
                  #endregion

                  #region Enter "Buyer Name(s)" and Save in Phrase View Screen
                  Reports.TestStep = "Enter \"Buyer Name(s)\" and Save in Phrase View Screen";
                  FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.RefreshDocument);
                  //var dataElement = FastDriver.NextGenDocumentRepository.DataElement("Buyer Contact: Name");
                  var dataElement = FastDriver.NextGenDocumentRepository.DataElement("Buyer Name(s)");
                 
                  #endregion

                  #region Edit value of any data element and click on "Save" Button
                  Reports.TestStep = "Edit value of any data element and click on \"Save\" Button";
                  var editedBuyerFirstName = "Edited-Buyer-First-Name";
                  dataElement["Input"].FASetText(editedBuyerFirstName);
                  FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  FastDriver.NextGenDocumentRepository.Open();   
                  #endregion


                  #region Verify the "Status" of the "File Document"
                  Reports.TestStep = "Verify the \"Status\" of the \"File Document\" ";
                  strStatus = "";
                  strStatus = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Status", TableAction.GetCell).Element.FAGetText();
                  Support.AreEqual("Edited", strStatus, true);
                  #endregion


              }
              catch (Exception ex)
              {
                  FailTest(GetExceptionInfo(ex));
              }
          }

          #endregion


        #region REG0067_US#247119&243980
          [TestMethod]
          [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
          [Description("US# 247119&243980: Title Report/Policy/Endorsement Documents")]
          public void REG0067_US247119_243980()
          {
              try
              {
                  SetDisplayPDFinBrowser_ON();

                  Reports.TestDescription = "US# 247119&243980: Title Report/Policy/Endorsement Documents";

                  FAST_Login_IIS(regionId: regionId);
                  FAST_OpenRegionOrOffice(officeId);
                  Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                  #region Navigate to Document Repository Screen
                  Reports.TestStep = "Navigate to Document Repository Screen";
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion                  
                 
                  #region Click on "Template Search" button
                  Reports.TestStep = "Click on \"Template Search\" button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion

                  #region Search for templates using search criteria
                  Reports.TestStep = "Search for templates using search criteria";
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Select Multiple templates (2 or more) by using "Ctrl" command
                  Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  var documents = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                  #endregion

                  #region Hold Right Click
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Select "Create Document" option
                  Reports.TestStep = "Select \"Create Document\" option";
                  FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Select and double click on the Title Reports document
                  Reports.TestStep = "Select and double click on the Title Reports document";
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                  FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Status", TableAction.GetCell).Element.FADoubleClick();
                  #endregion

                  #region Select "Finalized" option from the dropdown
                  Reports.TestStep = "Select \"Finalized\" option from the Status dropdown";
                  FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Status", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "item.DocStatusCD").FASelectItem("Finalized");
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Right click on Owner Policy Document and Select ImageDoc from Deliver
                  Reports.TestStep = "Right click on Owner Policy Document and Select \"ImageDoc from  Deliver\" option";

                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  Reports.TestStep = "Right click and Select ImageDoc from Deliver in Context Menu Items";

                  FastDriver.NextGenDocumentRepository.DocumentsTable.Highlight(3);

                  FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Perform ImageDoc Delivery

                  //  Assuming Context Menu is offset { left: 340, top: 304 } within content container;
                  FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);


                  FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.Highlight();

                   FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.FAClick();

                 // FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.JSClick();              
                  FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                  FastDriver.ImageDocDlg.WaitForScreenToLoad();
                  FastDriver.ImageDocDlg.publishDocument.FASetCheckbox(true);
                  FastDriver.ImageDocDlg.markDraft.FASetCheckbox(true);
                  FastDriver.ImageDocDlg.SellerSignature.FASetCheckbox(true);
                  FastDriver.ImageDocDlg.Deliver();
                  FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc, 400);                 

                  FastDriver.NextGenDocumentRepository.Open();                  
                  #endregion

                  #region Right click on Imaged Document and Select ImageDoc from Deliver
                  Reports.TestStep = "Right click on Imaged Document and Select \"ImageDoc from  Deliver\" option";

                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  Reports.TestStep = "Right click and Select ImageDoc from Deliver in Context Menu Items";

                  FastDriver.NextGenDocumentRepository.DocumentsTable.Highlight(3);

                  FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Imaged", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Perform ImageDoc Delivery

                  //  Assuming Context Menu is offset { left: 340, top: 304 } within content container;
                  FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);


                  FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.Highlight();

                   FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.FAClick();

                 // FastDriver.NextGenDocumentRepository.SearchResult_DeliverImageDoc1.JSClick();
                  
                  #endregion


                  #region Verify the Error Message
                  Reports.TestStep = "Verify the Error Message";                 
                  Support.AreEqual("ImageDoc Delivery is not allowed for image documents.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());


                  #endregion


              }
              catch (Exception ex)
              {
                  FailTest(GetExceptionInfo(ex));
              }
              finally
              {
                  SetDisplayPDFinBrowser_OFF();
              }
          }
          #endregion

          #region REG0068_US#243967
          [TestMethod]
          [Description("US#243967: Title Report & Policy Association")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
          [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
          public void REG0068_US243967()
          {
              try
              {                  

                  EnableSavingIRSamples();
                  SetSilverlightClipboardPermission_YES();

                  Reports.TestDescription = "US#243967: Title Report & Policy Association";
                  Reports.TestDescription = "Login to ADM site";
                  FAST_Login_ADM(isSuperUser: false);
                  FAST_OpenRegionOrOffice(officeId);

                  //#region Navigate to NextGen Document Preparation Screen
                  //Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                  //FastDriver.NextGenDocumentPreparation.Open();
                  //#endregion

                  // Pre-Condition

                  //LoadTemplateOrCreateNew("SAN-NEXTGEN200", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                  //LoadTemplateOrCreateNew("SAN-NEXTGEN300", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                  //LoadTemplateOrCreateNew("SAN-NEXTGEN400", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                  //LoadTemplateOrCreateNew("SAN-NEXTGEN500", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");
                  //LoadTemplateOrCreateNew("SAN-NEXTGEN700", "NEXTGEN_SAN_Policy_w/o_Title Reports", "Policy w/o Title Reports");

                  //Work with the following service to create phrase, phrase group and template.

                  FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Title Phrase[TITLE]", "Title-NXTGEN11", "Title Reports");
                  FastDriver.NextGenDocumentPreparation.TemplateDescr.Highlight(5); 

                  string strTemplateName = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetValue();

                  FastDriver.NextGenDocumentPreparation.Phrase_phraseGrp_Template_Final("ANAN", "Title Phrase[TITLE]", "Title-NXTGEN12", "Title Reports");
                  string strTemplateName1 = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetValue(); 



                  //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Title-NXTGN11", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Title Reports");
                  //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Lender-NXTGN11", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Lender Policy");
                  //Phrase_phraseGrp_Template("ANAN", "Title Phrase[TITLE]", "Owner-NXTGN11", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Owner Policy");
                  //Phrase_phraseGrp_Template("ANAN", "Endorsement Phrase[ENDORSE]", "EndorsementGuarantee-NXTGN11", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Endorsement/Guarantee");
                  //Phrase_phraseGrp_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "NEXTGEN_SAN_Policy_w/o_Title Reports", "Policy w/o Title Reports");


                  Reports.TestDescription = "Login to IIS site";
                  FAST_Login_IIS(regionId: regionId);
                  FAST_OpenRegionOrOffice(officeId);
                  Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                  #region Navigate to Document Repository Screen
                  Reports.TestStep = "Navigate to Document Repository Screen";
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion



                  #region Search for Policy_w/o_Title Reports template using search criteria
                  Reports.TestStep = "Search for Policy_w/o_Title Reports using search criteria";
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TEST-Template*");
                  FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                  FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion
                  
                  
                  //#region Click on "Template Search" button
                  //Reports.TestStep = "Click on \"Template Search\" button";
                  //FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  //FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  //#endregion

                  //#region Search for templates using search criteria
                  //Reports.TestStep = "Search for templates using search criteria";
                  //FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  //FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TEST-Template");
                  //FastDriver.NextGenDocumentRepository.Search.FAClick();
                  //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  //#endregion

                  #region Select Multiple templates (2 or more) by using "Ctrl" command
                  Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  //var documents = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
                  var documents = new List<string> { strTemplateName, strTemplateName1 };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                  #endregion

                  #region Hold Right Click
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", strTemplateName, "Description", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Select "Create Document" option
                  Reports.TestStep = "Select \"Create Document\" option";
                  FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Navigate to Document Repository Screen
                  Reports.TestStep = "Navigate to Document Repository Screen";
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion

                  #region Click on "Template Search" button
                  Reports.TestStep = "Click on \"Template Search\" button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion


                  #region Search for templates using search criteria
                  Reports.TestStep = "Search for Owner Policy using search criteria";
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Owner Policy");
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                  FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                  FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion



                  #region Select the template by using "Ctrl" command
                  Reports.TestStep = "Select the template by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();


                  var documentsEndo = new List<string> { "NEXTGEN_SAN_OwnerPolicy_DoNotTouch" };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documentsEndo);
                  #endregion

                  #region Hold Right Click
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_OwnerPolicy_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Select "Create Document" option
                  Reports.TestStep = "Select \"Create Document\" option";
                  FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Select any Policy from the grid
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.Highlight(8);

                  FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.GetRowCount(), 1, TableAction.GetCell).Element.Highlight(5);
                  FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.PerformTableAction(FastDriver.NextGenDocumentRepository.TitlePolicyDetailsTable.GetRowCount(), 1, TableAction.GetCell).Element.FADoubleClick();


                  FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.Highlight(3);
                  FastDriver.NextGenDocumentRepository.TitlePolicyDetails_Done.FADoubleClick();
                  #endregion

                  #region Navigate to Document Repository Screen
                  Reports.TestStep = "Navigate to Document Repository Screen";
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion

                  #region Click on "Template Search" button
                  Reports.TestStep = "Click on \"Template Search\" button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion

                  #region Search for Policy_w/o_Title Reports template using search criteria
                  Reports.TestStep = "Search for Policy_w/o_Title Reports using search criteria";
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Owner Policy");
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                  FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                  FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion



                  #region Select the template by using "Ctrl" command
                  Reports.TestStep = "Select the template by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();


                  var Policywo = new List<string> { "NEXTGEN_SAN_LenderPolicy_DoNotTouch" };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, Policywo);
                  #endregion

                  #region Hold Right Click
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_LenderPolicy_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Select "Create Document" option
                  Reports.TestStep = "Select \"Create Document\" option";
                  FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Navigate to Document Repository Screen
                  Reports.TestStep = "Navigate to Document Repository Screen";
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion

                  #region Click on "Template Search" button
                  Reports.TestStep = "Click on \"Template Search\" button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion
                                

              }
              catch (Exception ex)
              {
                  FailTest(GetExceptionInfo(ex));
              }
          }

          #endregion

          #region REG0069
          [TestMethod]
          [Description("Verify system shall display a template in file side if the template has only a phrase marker form")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
         
          public void REG0069()
          {
              try
              {



                  //IRDebugging(true);
                  //SetSilverlightClipboardPermission_YES();

                  try
                  {
                      IRDebugging(true);
                      SetSilverlightClipboardPermission_YES();

                      Reports.TestDescription = "Verify system shall display a template in file side if the template has only a phrase marker form";

                      #region Navigate to ADM site
                      Reports.TestStep = "Navigate to ADM site";
                      FAST_Login_ADM(isSuperUser: false);
                      FAST_OpenRegionOrOffice(officeId);
                      #endregion

                      #region Navigate to NextGen Document Preparation Screen and create a Template with Regional Form
                      Reports.TestStep = "Navigate to NextGen Document Preparation Screen and create a Template";
                      FastDriver.DocumentEditor.Regional_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                      string strTemplateName = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetValue();
                      FastDriver.NextGenDocumentPreparation.Save.FAClick();                   
                   
                      #endregion


                      Reports.TestDescription = "Login to IIS site";
                      FAST_Login_IIS(regionId: regionId);
                      FAST_OpenRegionOrOffice(officeId);
                      Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                      #region Navigate to Document Repository Screen
                      Reports.TestStep = "Navigate to Document Repository Screen";
                      FastDriver.NextGenDocumentRepository.Open();
                      #endregion


                      #region Click on "Template Search" button
                      Reports.TestStep = "Click on \"Template Search\" button";
                      FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                      FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                      #endregion

                      #region Search for Regional Form Template
                      Reports.TestStep = "Search for Regional Form Template";
                      FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                      FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                      FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                      FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TEST-Template*");
                      FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                      FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                      FastDriver.NextGenDocumentRepository.Search.FAClick();
                      FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                      #endregion                     

                      #region Select a template by using "Ctrl" command
                      Reports.TestStep = "Select a template by using \"Ctrl\" command";
                      FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                     
                      var documents = new List<string> { strTemplateName };
                      FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                      #endregion

                      #region Hold Right Click
                      Reports.TestStep = "Hold Right Click";
                      FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", strTemplateName, "Description", TableAction.GetCell).Element.FARightClick();
                      #endregion

                      #region Select "Create Document" option
                      Reports.TestStep = "Select \"Create Document\" option";
                      FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                      FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                      #endregion

                      #region Navigate to Document Repository Screen
                      Reports.TestStep = "Navigate to Document Repository Screen";
                      FastDriver.NextGenDocumentRepository.Open();
                      #endregion

                  }
                  catch (Exception ex)
                  {
                      FailTest(GetExceptionInfo(ex));
                  }

              }
              catch (Exception ex)
              {
                  FailTest(GetExceptionInfo(ex));
              }
          }

          #endregion


          #region REG0070
          [TestMethod]
          [Description("Verify system shall display latest version template in file side if form is edited")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]

          public void REG0070()
          {
              try
              {


                  //IRDebugging(true);
                  //SetSilverlightClipboardPermission_YES();

                  try
                  {
                      IRDebugging(true);
                      SetSilverlightClipboardPermission_YES();

                      Reports.TestDescription = "Verify system shall display latest version template in file side if form is edited";

                      #region Navigate to ADM site
                      Reports.TestStep = "Navigate to ADM site";
                      FAST_Login_ADM(isSuperUser: false);
                      FAST_OpenRegionOrOffice(officeId);
                      #endregion

                      #region Navigate to NextGen Document Preparation Screen and create a Template with Regional Form
                      Reports.TestStep = "Navigate to NextGen Document Preparation Screen and create a Template";
                      FastDriver.DocumentEditor.Regional_Template("ANAN", "Escrow Phrase[ESCROW]", "Escrow-NXTGN11", "Escrow Instruction");
                      string strTemplateName = FastDriver.NextGenDocumentPreparation.TemplateDescr.FAGetValue();
                      Playback.Wait(1000);
                      FastDriver.NextGenDocumentPreparation.Save.Highlight(5);
                      FastDriver.NextGenDocumentPreparation.Save.FAClick();
                      FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                      #endregion


                      Reports.TestDescription = "Login to IIS site";
                      FAST_Login_IIS(regionId: regionId);
                      FAST_OpenRegionOrOffice(officeId);
                      Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                      #region Navigate to Document Repository Screen
                      Reports.TestStep = "Navigate to Document Repository Screen";
                      FastDriver.NextGenDocumentRepository.Open();
                      #endregion


                      #region Click on "Template Search" button
                      Reports.TestStep = "Click on \"Template Search\" button";
                      FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                      FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                      #endregion

                      #region Search for Regional Form Template
                      Reports.TestStep = "Search for Regional Form Template";
                      FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                      FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                      FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                      FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TEST-Template*");
                      FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                      FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                      FastDriver.NextGenDocumentRepository.Search.FAClick();
                      FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                      #endregion

                      #region Select a template by using "Ctrl" command
                      Reports.TestStep = "Select a template by using \"Ctrl\" command";
                      FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                      var documents = new List<string> { strTemplateName };
                      FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                      #endregion

                      #region Hold Right Click
                      Reports.TestStep = "Hold Right Click";
                      FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", strTemplateName, "Description", TableAction.GetCell).Element.FARightClick();
                      #endregion

                      #region Select "Create Document" option
                      Reports.TestStep = "Select \"Create Document\" option";
                      FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                      FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                      #endregion

                      #region Navigate to Document Repository Screen
                      Reports.TestStep = "Navigate to Document Repository Screen";
                      FastDriver.NextGenDocumentRepository.Open();
                      #endregion

                      #region Select and double click on the Regoinal document
                      Reports.TestStep = "Select and double click on the Regoinal document";
                      FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                      FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                      FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", strTemplateName, "Name", TableAction.GetCell).Element.FADoubleClick();
                      #endregion

                      #region Verify the number of Phrase Marker
                      Reports.TestStep = "Verify the number of Phrase Marker";
                      FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                      FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.RefreshDocument);
                      int rowCount = FastDriver.NextGenDocumentRepository.PhraseDataElementTable.GetRowCount();
                      if(rowCount > 1 )
                      Support.AreEqual("True", "True", "Phrase Marker has been added" );
                      FastDriver.NextGenDocumentRepository.Open();   
                      #endregion


                      #region Navigate to ADM site
                      Reports.TestStep = "Navigate to ADM site";
                      FAST_Login_ADM(isSuperUser: false);
                      FAST_OpenRegionOrOffice(officeId);
                      #endregion

                      #region Navigate to NextGen Document Preparation Screen and Edit the Template with Regional Form
                      Reports.TestStep = "Navigate to NextGen Document Preparation Screen and Edit the Template with Regional Form";
                      FastDriver.DocumentEditor.Regional_Template_Edit("Escrow Instruction", strTemplateName);
                      #endregion


                      Reports.TestDescription = "Login to IIS site";
                      FAST_Login_IIS(regionId: regionId);
                      FAST_OpenRegionOrOffice(officeId);
                      Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                      #region Navigate to Document Repository Screen
                      Reports.TestStep = "Navigate to Document Repository Screen";
                      FastDriver.NextGenDocumentRepository.Open();
                      #endregion


                      #region Click on "Template Search" button
                      Reports.TestStep = "Click on \"Template Search\" button";
                      FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                      FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                      #endregion

                      #region Search for Regional Form Template
                      Reports.TestStep = "Search for Regional Form Template";
                      FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                      FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                      FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                      FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("TEST-Template*");
                      FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                      FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                      FastDriver.NextGenDocumentRepository.Search.FAClick();
                      FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                      #endregion

                      #region Select a template by using "Ctrl" command
                      Reports.TestStep = "Select a template by using \"Ctrl\" command";
                      FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                      var documents1 = new List<string> { strTemplateName };
                      FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents1);
                      #endregion

                      #region Hold Right Click
                      Reports.TestStep = "Hold Right Click";
                      FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", strTemplateName, "Description", TableAction.GetCell).Element.FARightClick();
                      #endregion

                      #region Select "Create Document" option
                      Reports.TestStep = "Select \"Create Document\" option";
                      FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                      FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                      #endregion

                      #region Navigate to Document Repository Screen
                      Reports.TestStep = "Navigate to Document Repository Screen";
                      FastDriver.NextGenDocumentRepository.Open();
                      #endregion

                      #region Select and double click on the Regoinal document
                      Reports.TestStep = "Select and double click on the Regoinal document";
                      FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                      FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                      FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", strTemplateName, "Name", TableAction.GetCell).Element.FADoubleClick();
                      #endregion

                      #region Verify the number of Phrase Marker
                      Reports.TestStep = "Verify the number of Phrase Marker";
                      FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                      FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.RefreshDocument);
                      rowCount = 0;

                      FastDriver.NextGenDocumentRepository.PhraseDataElementTable.Highlight(5); 
                      rowCount = FastDriver.NextGenDocumentRepository.PhraseDataElementTable.GetRowCount();
                      if (rowCount > 3)
                          Support.AreEqual("True", "True", "Phrase Marker has been added");
                      FastDriver.NextGenDocumentRepository.Open();  
                      #endregion



                  }
                  catch (Exception ex)
                  {
                      FailTest(GetExceptionInfo(ex));
                  }

              }
              catch (Exception ex)
              {
                  FailTest(GetExceptionInfo(ex));
              }
          }

          #endregion


          #region REG0071_911597
          [TestMethod]
          [Description("Test Case 911597:Insert Auto Numbering button IIS")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
          public void REG0071_911597()
          {
              try
              {



                  IRDebugging(true);
                  SetSilverlightClipboardPermission_YES();


                  Reports.TestDescription = "Test Case 911597:Insert Auto Numbering button IIS";

                  Reports.TestDescription = "Login to IIS site";
                  FAST_Login_IIS(regionId: regionId);
                  FAST_OpenRegionOrOffice(officeId);
                  Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                  #region Navigate to Document Repository Screen
                  Reports.TestStep = "Navigate to Document Repository Screen";
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion

                  #region Click on "Template Search" button
                  Reports.TestStep = "Click on \"Template Search\" button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion

                  #region Search for templates using search criteria
                  Reports.TestStep = "Search for templates using search criteria";
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Select Multiple templates (2 or more) by using "Ctrl" command
                  Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  var documents = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                  #endregion

                  #region Hold Right Click
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Select "Create Document" option
                  Reports.TestStep = "Select \"Create Document\" option";
                  FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion                 

                  #region Click on "Document View/Edit" and Go to the Document Editor
                  Reports.TestStep = "Click on \"Document View/Edit\" and Go to the Document Editor";
                  FastDriver.NextGenDocumentRepository.Open();
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.DocumentsInnerTable.PerformTableAction("Name", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Type", TableAction.GetCell).Element.FARightClick();
                  FastDriver.NextGenDocumentRepository.DocumentViewEdit.Highlight(5);
                  FastDriver.NextGenDocumentRepository.DocumentViewEdit.FAClick();
                  FastDriver.DocumentEditor.WaitForScreenToLoad();
                  Playback.Wait(5000);
                  #endregion

                  #region Click on Phrase and Insert Auto Number                  
                  FastDriver.DocumentEditor.InsertAutoNumbering();                                  
                  #endregion


              }
              catch (Exception ex)
              {
                  FailTest(GetExceptionInfo(ex));
              }
          }

          #endregion

          #region REG0072_911591
          [TestMethod]
          [Description("Test Case 911591: Selecting  Auto Numbering Properties Icon ADM")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
          public void REG0072_911591()
          {
              try
              {



                  IRDebugging(true);
                  SetSilverlightClipboardPermission_YES();


                  Reports.TestDescription = "Test Case 912544: Selecting  Auto Numbering Properties Icon ADM";


                  #region Navigate to ADM site
                  Reports.TestStep = "Navigate to ADM site";
                  FAST_Login_ADM(isSuperUser: false);
                  FAST_OpenRegionOrOffice(officeId);
                  #endregion

                  #region Navigate to NextGen Document Preparation Screen and Edit the Template with Regional Form
                  Reports.TestStep = "Navigate to NextGen Document Preparation Screen and Edit the Template with Regional Form";
                  FastDriver.DocumentEditor.AutoNumber_Template_Edit("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                  #endregion


              }
              catch (Exception ex)
              {
                  FailTest(GetExceptionInfo(ex));
              }
          }

          #endregion


          #region REG0073_912544_912750
          [TestMethod]
          [Description("Test Case 912544:Selecting  Auto Numbering Properties Icon ADM")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
          public void REG0073_912544_912750()
          {
              try
              {



                  IRDebugging(true);
                  SetSilverlightClipboardPermission_YES();

                  Reports.TestDescription = "Test Case 912544: Selecting  Auto Numbering Properties Icon ADM";

                  #region Navigate to ADM site
                  Reports.TestStep = "Navigate to ADM site";
                  FAST_Login_ADM(isSuperUser: false);
                  FAST_OpenRegionOrOffice(officeId);
                  #endregion

                  #region Navigate to NextGen Document Preparation Screen and Edit the Template with Regional Form
                  Reports.TestStep = "Navigate to NextGen Document Preparation Screen and Edit the Template with Regional Form";
                  FastDriver.DocumentEditor.Select_AutoNumber_Template_Edit("Escrow Instruction", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                  #endregion


                 




              }
              catch (Exception ex)
              {
                  FailTest(GetExceptionInfo(ex));
              }
          }

          #endregion


          #region REG0074_912552_912735
          [TestMethod]
          [Description("Test Case 912552_912735:Selecting  Auto Numbering Properties Icon IIS / New multi-level list Auto Numbering Properties icon | Outline Properties icon IIS")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\")]
          [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
          public void REG0074_912552_912735()
          {
              try
              {

                  IRDebugging(true);
                  SetSilverlightClipboardPermission_YES();

                  Reports.TestDescription = "Test Case 912552_912735:Verify changed The Auto Numbering icon to Red in IIS / New multi-level list Auto Numbering Properties icon | Outline Properties icon IIS";

                  Reports.TestDescription = "Login to IIS site";
                  FAST_Login_IIS(regionId: regionId);
                  FAST_OpenRegionOrOffice(officeId);
                  Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                  #region Navigate to Document Repository Screen
                  Reports.TestStep = "Navigate to Document Repository Screen";
                  FastDriver.NextGenDocumentRepository.Open();
                  #endregion

                  #region Click on "Template Search" button
                  Reports.TestStep = "Click on \"Template Search\" button";
                  FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  #endregion

                  #region Search for templates using search criteria
                  Reports.TestStep = "Search for templates using search criteria";
                  FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                  FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN*");
                  FastDriver.NextGenDocumentRepository.Search.FAClick();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Select Multiple templates (2 or more) by using "Ctrl" command
                  Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                  FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                  var documents = new List<string> { "NEXTGEN_SAN_TitleReports_DoNotTouch", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch" };
                  FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.TemplatesTable, documents);
                  #endregion

                  #region Hold Right Click
                  Reports.TestStep = "Hold Right Click";
                  FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Description", TableAction.GetCell).Element.FARightClick();
                  #endregion

                  #region Select "Create Document" option
                  Reports.TestStep = "Select \"Create Document\" option";
                  FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                  FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                  #endregion

                  #region Click on "Document View/Edit" and Go to the Document Editor
                  Reports.TestStep = "Click on \"Document View/Edit\" and Go to the Document Editor";
                  FastDriver.NextGenDocumentRepository.Open();
                  FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                  FastDriver.NextGenDocumentRepository.DocumentsInnerTable.PerformTableAction("Name", "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch", "Type", TableAction.GetCell).Element.FARightClick();

                  FastDriver.NextGenDocumentRepository.DocumentViewEdit.Highlight(5);
                  FastDriver.NextGenDocumentRepository.DocumentViewEdit.FAClick();
                  FastDriver.DocumentEditor.WaitForScreenToLoad();
                  Playback.Wait(5000);
                  #endregion

                   
                  FastDriver.DocumentEditor.InsertAutoNumbering();
                  FastDriver.NextGenDocumentRepository.Open(); 

              }
              catch (Exception ex)
              {
                  FailTest(GetExceptionInfo(ex));
              }
          }


          #endregion






        #endregion








        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}