﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using System.Windows.Input;
using FASTSelenium.DataObjects;
using System.Diagnostics;

namespace NextGenDocPrep.r10_2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class UserStory849216 : MasterTestClass
    {
        #region Data Setup
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
       
        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        #endregion Data Setup

        #region Private Methods

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FASTHelpers.FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FASTHelpers.FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        public bool CreateStandardFile_OtherRegion(string GABID)
        {
            Reports.TestStep = "Create File using FAST GUI.";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
            try
            {
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            }
            catch
            {
                Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
            }

            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(GABID);
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(GABID);
            FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
            if (!FastDriver.QuickFileEntry.Title.Selected)
                FastDriver.QuickFileEntry.Title.FAClick();
            if (!FastDriver.QuickFileEntry.Escrow.Selected)
                FastDriver.QuickFileEntry.Escrow.FAClick();
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
            FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

            FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
            FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
            FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
            FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
            FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
            FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
            FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
            FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
            FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
            FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
            FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
            FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
            FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
            FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
            FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
            FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
            FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
            FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
            FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
            FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
            FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
            FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
            FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
            FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");
            Playback.Wait(1000);
            //Keyboard.SendKeys("^{D}"); //Send Control + D
            //FastDriver.BottomFrame.Done();

            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            FASTHelpers.FAST_Login_ADM(isSuperUser: false);
            FASTHelpers.FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            #region If template does not exist
            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Escrow Instruction QA MJJP Test 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Escrow Instruction QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
            #endregion
        }

        private void AddDocumentInDocRepo(string TemplateName1)
        {
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);
            // Template  seaarch
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TemplateName1);
            FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TemplateName1, "Description", TableAction.Click).Element.FARightClick();
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            // Document creation
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
        }

        private void VerifyDocumentInformationDetails(string documentName = null, string status = "Edited")
        {
            var details = FastDriver.NextGenDocumentRepository.DetailsTable1.FAGetAttribute("textContent").Clean();
            Support.IsTrue(!string.IsNullOrWhiteSpace(details), "Document Information content is not empty");
            Support.IsTrue(details.Length > 200, "Document Information content has sufficient information");
            Support.Match("Document.ID:.[0-9]+", details, "Document ID");
            Support.Match("Document.Name:." + documentName ?? "", details, "Document Name");
            Support.Match("Document.Status:." + status, details, "Document Status");
            var _date = DateTime.UtcNow.ToPST().ToString("M/d/yyyy").Replace("/", "\\/").TrimStart('0');
            var _time = "[0-9]?[0-9]:[0-9]?[0-9]:[0-9]{2}.(PM|AM)";
            Support.Match("Created.Date:." + _date + "." + _time, details, "Created Date");
            Support.Match("Created.User:.Super.User", details, "Created User");
            Support.Match("Status.Chg.DATE:." + _date + "." + _time, "Status Chg DATE");
            Support.Match("Status.Chg.User:.FAST.QA07", details, "Status Chg User");
            Support.Match("Delivery.User:.", details, "Delivery User");
            Support.Match("Delivered.Date:.", details, "Delivered Date");
            Support.Match("System.Use-.ServiceFileID:.[0-9]+", details, "System Use- ServiceFileID");
            Support.Match("Template.Region.BUID:.[0-9]+", details, "Template Region BUID");
            Support.Match("Template.Region.Name:.QA.Sandpointe.-.Next.Gen", details, "Template Region Name");
        }

        #endregion Private Methods

        #region Non Document Editor

        #region Testcase 882929 Validate Status Change User, Status Change Date and Time | Create document

        [TestMethod]
        public void Testcase_882929()
        {
            Reports.TestDescription = "Validate Status Change User, Status Change Date and Time | Create document";

            try
            {
                //Data template
                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";
                string super_user = "Super User";


                Reports.TestStep = "Login to File Side with superuser credential";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);
                try { FASTHelpers.FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); } Playback.Wait(4000);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TemplateName1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TemplateName1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Documnet is created ";                     // Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);

                Reports.TestStep = "take values  From Document Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight(10);
                FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                var DocumentName = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText();
                var DocStatus = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedDate = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedUser = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText();


                Reports.TestStep = "Verify document details in the details dialog box";
                Support.AreEqual(TemplateName1, DocumentName);
                Support.AreEqual("Created", DocStatus);
                Support.AreEqual(super_user, CreatedUser);
                string date = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                Support.AreEqual("True", CreatedDate.Contains(date).ToString());
                VerifyDocumentInformationDetails(documentName: TemplateName1, status: "Created");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 883638 Validate Status Change User, Status Change Date and Time | Right click/double click -Phrase view

        [TestMethod]
        public void Testcase_883638()
        {
            Reports.TestDescription = "Validate Status Change User, Status Change Date and Time | Right click/double click -Phrase view";

            try
            {
                //Data template
                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";
                string super_user = "Super User";


                Reports.TestStep = "Login to File Side with superuser credential";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);
                try { FASTHelpers.FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); } Playback.Wait(4000);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open(); Playback.Wait(6000);

                Reports.TestStep = "Click on template search";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Create a  document in the document repository";                            // Template  seaarch
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TemplateName1);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", TemplateName1, "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created..", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Documnet is created ";                     // Document creation
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);

                Reports.TestStep = "take values  From Document Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight(10);
                FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                var DocumentName = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText();
                var DocStatus = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedDate = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedUser = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText();


                Reports.TestStep = "Verify document details in the details dialog box";
                Support.AreEqual(TemplateName1, DocumentName);
                Support.AreEqual("Created", DocStatus);
                Support.AreEqual(super_user, CreatedUser);
                string date = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                Support.AreEqual("True", CreatedDate.Contains(date).ToString());

                Reports.TestStep = "Click on OK in the document dialog details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.Highlight(5);
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }

                Reports.TestStep = "Verify Details in Phrase View Tab, compare with document details in the dialog in landing page";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TemplateName1, "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);

                //Get details
                var DocumentName1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText();
                var DocStatus1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedDate1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedUser1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText();
                //Verify
                Support.AreEqual(DocumentName, DocumentName);
                Support.AreEqual(DocStatus, DocStatus);
                Support.AreEqual(CreatedUser, CreatedUser);
                Support.AreEqual(CreatedDate, CreatedDate1);

                Reports.TestStep = "Read the file number";
                FastDriver.FileHomepage.Open();
                string filenum = FastDriver.FileHomepage.FileNum.FAGetValue();

                //Login with different user and verify the document user details
                Reports.TestStep = "Login with different user and verify doc details";
                FASTHelpers.FAST_Login_IIS(regionId: regionId);
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Reports.TestStep = "Search File.";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search").WaitForScreenToLoad();
                FastDriver.FileSearch.SetFileNumber(filenum, IsNonExistingFile: false);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("File Number Search Selection", false, 30);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TemplateName1, "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight(10);
                FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed();
                Support.AreEqual(DocumentName, FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetText).Message);
                Support.AreEqual(DocStatus, FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetText).Message);
                Support.AreEqual(CreatedDate, FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetText).Message);
                Support.AreEqual(CreatedUser, FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetText).Message);



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 883692 Validate Document Status, Status Change Date and Time | Insert a Phrase | Phrase View
        [TestMethod]
        public void Testcase_883692()
        {
            Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Phrase | Phrase View";

            try
            {
                #region Data Setup
                String Phrasecode = "T/3";
                String super_user = "Super User";
                String fastqa_user = "FAST QA07";
                //String templateName = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";
                #endregion

                #region Login to Fast
                Reports.TestStep = "Login to Fast IIS screen with superuser credential";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);
                try { FASTHelpers.FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); }
                Playback.Wait(4000);
                #endregion

                #region Create a file
                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                String FileNum = FastDriver.FileHomepage.txtFileNumber.FAGetValue();
                #endregion

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open();
                Playback.Wait(6000);
                #endregion

                #region Add document in Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 3, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var DocumentTableExist = FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed();
                while (!DocumentTableExist)
                {
                    FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }

                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(templateName).ToString());
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);

                // Take values  From Document Details
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight(10);
                FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                var DocumentName = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText();
                var DocStatus = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedDate = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedUser = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText();

                //Verify document details in the details dialog bo
                Support.AreEqual(templateName, DocumentName);
                Support.AreEqual("Created", DocStatus);
                Support.AreEqual(super_user, CreatedUser);
                string date = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                Support.AreEqual("True", CreatedDate.Contains(date).ToString());
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.Highlight(5);
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }
                #endregion

                #region Logout and login back with different user
                Reports.TestStep = "Login into the IIS Side.";
                FASTHelpers.FAST_Login_IIS();
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Search file and edit document added in it
                Reports.TestStep = "Search for file from step 2, select previous document and right click /double click for Phrase View screen";
                FastDriver.TopFrame.SetNumberAndPressEnter(FileNum);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, templateName, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FADoubleClick();
                Playback.Wait(600);
                #endregion

                #region Insert Phrase below in Phrase View
                Reports.TestStep = "In Phrase View screen, select a phrase and right click to Insert->Below->Phrase";
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.DataElementTable.PerformTableAction(3, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Insert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.Below.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.BelowPhrase.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.BelowPhrase.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion

                #region Search and Insert a Phrase
                Reports.TestStep = "Search for a Phrase and double click on top of it or click done button";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Source.FASelectItem("Corporate");
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(Phrasecode);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                String date1 = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                #endregion

                #region Navigate to Details Tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.Highlight(10);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.IsDisplayed();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                Support.AreEqual(DocumentName, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("Edited", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedDate, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedUser, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.FAGetText().Contains(date1).ToString());
                Support.AreEqual(fastqa_user, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.FAGetText());
                #endregion

                #region Click Done button
                Reports.TestStep = "Click on Done button";
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                #endregion

                #region Observe Details from Document Repository
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                //Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DetailsTable);
                FastDriver.NextGenDocumentRepository.DetailsTable.Highlight(10);
                //FastDriver.NextGenDocumentRepository.DetailsTable.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                VerifyDocumentInformationDetails();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }
                #endregion

                #region Select document in Document Repository
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View screen";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", templateName, "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.PhraseViewTab);
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FADoubleClick();
                Playback.Wait(600);
                #endregion

                #region Insert Phrase Above in Phrase View
                Reports.TestStep = "In Phrase View screen, select a phrase and right click to Insert->Above->Phrase";
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.DataElementTable.PerformTableAction(1,5 ,TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[0]);
                Support.AreEqual("Phrase", FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[0].FAGetText());
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[0].FAClick();
              
                #endregion

                #region Search and Insert a Phrase
                Reports.TestStep = "Search for a Phrase and double click on top of it or click done button";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Source.FASelectItem("Corporate");
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(Phrasecode);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                String date2 = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                #endregion

                #region Navigate to Details Tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.Highlight(10);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.IsDisplayed();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                Support.AreEqual(DocumentName, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("Edited", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedDate, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedUser, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.FAGetText().Contains(date2).ToString());
                Support.AreEqual(fastqa_user, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.FAGetText());
                #endregion

                #region Click Done button
                Reports.TestStep = "Click on Done button";
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                #endregion

                #region Observe Details from Document Repository
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight(10);
                FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                VerifyDocumentInformationDetails();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region Testcase 883696 Validate Document Status, Status Change Date and Time | Insert a Misc. Phrase | Phrase View

        [TestMethod]
        public void Testcase_883696()
        {
           

            try
            {
                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Misc. Phrase | Phrase View";
                #region Data Setup
                String Phrasecode = "T/3";
                String super_user = "Super User";
                String fastqa_user = "FAST QA07";
                //String templateName = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";
                #endregion

                #region Login to Fast
                Reports.TestStep = "Login to Fast IIS screen with superuser credential";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);
                try { FASTHelpers.FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); }
                Playback.Wait(4000);
                #endregion

                #region Create a file
                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                String FileNum = FastDriver.FileHomepage.txtFileNumber.FAGetValue();
                #endregion

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open();
                Playback.Wait(6000);
                #endregion

                #region Add document in Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 3, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var DocumentTableExist = FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed();
                while (!DocumentTableExist)
                {
                    FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }

                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(templateName).ToString());
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);

                // Take values  From Document Details
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight(10);
                FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                var DocumentName = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText();
                var DocStatus = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedDate = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedUser = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText();

                //Verify document details in the details dialog bo
                Support.AreEqual(templateName, DocumentName);
                Support.AreEqual("Created", DocStatus);
                Support.AreEqual(super_user, CreatedUser);
                string date = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                Support.AreEqual("True", CreatedDate.Contains(date).ToString());
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.Highlight(5);
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }
                #endregion

                #region Logout and login back with different user
                Reports.TestStep = "Login into the IIS Side.";
                FASTHelpers.FAST_Login_IIS();
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Search file and edit document added in it
                Reports.TestStep = "Search for file from step 2, select previous document and right click /double click for Phrase View screen";
                FastDriver.TopFrame.SetNumberAndPressEnter(FileNum);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, templateName, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FADoubleClick();
                Playback.Wait(600);
                #endregion

                #region Insert Misc Phrase below in Phrase View
                Reports.TestStep = "In Phrase View screen, select a phrase and right click to Insert->Below->Mis Phrase";
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.DataElementTable.PerformTableAction(1, 5, TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[0]);
                Support.AreEqual("Misc", FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[1].FAGetText());
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[1].FAClick();
                #endregion

                #region Search and Insert a Misc Phrase
                Reports.TestStep = "Search for a Phrase and double click on top of it or click done button";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.Misc_Phrase_Name);
                FastDriver.NextGenDocumentRepository.Misc_Phrase_Name.FASetText(Support.RandomString("ANANANAAAA"));
                FastDriver.NextGenDocumentRepository.Misc_Phrase_DialogDone.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Inserting Phrase.. please wait...", true, 60);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.SaveAndClose();

                #endregion

                #region Navigate to Details Tab
                Reports.TestStep = "Navigate to Details tab";
                String date1 = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DetailsTab);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.Highlight(10);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.IsDisplayed();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                Support.AreEqual(DocumentName, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("Edited", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedDate, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedUser, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.FAGetText().Contains(date1).ToString());
                Support.AreEqual(fastqa_user, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.FAGetText());
                #endregion

                #region Click Done button
                Reports.TestStep = "Click on Done button";
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                #endregion

                #region Observe Details from Document Repository
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                //Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DetailsTable);
                FastDriver.NextGenDocumentRepository.DetailsTable.Highlight(10);
                //FastDriver.NextGenDocumentRepository.DetailsTable.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                VerifyDocumentInformationDetails();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }
                #endregion

                #region Select document in Document Repository
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View screen";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", templateName, "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.PhraseViewTab);
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FADoubleClick();
                Playback.Wait(600);
                #endregion

                #region Insert Misc Phrase below in Phrase View
                Reports.TestStep = "In Phrase View screen, select a phrase and right click to Insert->Below->Mis Phrase";
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.DataElementTable.PerformTableAction(1, 5, TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[0]);
                Support.AreEqual("Misc", FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[2].FAGetText());
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[2].FAClick();
                #endregion

                #region Search and Insert a Misc Phrase
                Reports.TestStep = "Search for a Phrase and double click on top of it or click done button";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.Misc_Phrase_Name);
                FastDriver.NextGenDocumentRepository.Misc_Phrase_Name.FASetText(Support.RandomString("ANANANAAAA"));
                FastDriver.NextGenDocumentRepository.Misc_Phrase_DialogDone.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Inserting Phrase.. please wait...", true, 60);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.SaveAndClose();

                #endregion

                #region Navigate to Details Tab
                Reports.TestStep = "Navigate to Details tab";
                String date2 = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DetailsTab);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.Highlight(10);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.IsDisplayed();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                Support.AreEqual(DocumentName, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("Edited", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedDate, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedUser, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.FAGetText().Contains(date2).ToString());
                Support.AreEqual(fastqa_user, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.FAGetText());
                #endregion

                #region Click Done button
                Reports.TestStep = "Click on Done button";
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                #endregion

                #region Observe Details from Document Repository
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight(10);
                FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                VerifyDocumentInformationDetails();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 883699 Validate Document Status, Status Change Date and Time | Insert a Restart Numbering | Phrase View

        [TestMethod]
        public void Testcase_883699()
        {
            

            try
            {
                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Restart Numbering | Phrase View";
                #region Data Setup
                String Phrasecode = "T/3";
                String super_user = "Super User";
                String fastqa_user = "FAST QA07";
                //String templateName = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";
                #endregion

                #region Login to Fast
                Reports.TestStep = "Login to Fast IIS screen with superuser credential";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);
                try { FASTHelpers.FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); }
                Playback.Wait(4000);
                #endregion

                #region Create a file
                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                String FileNum = FastDriver.FileHomepage.txtFileNumber.FAGetValue();
                #endregion

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open();
                Playback.Wait(6000);
                #endregion

                #region Add document in Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 3, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var DocumentTableExist = FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed();
                while (!DocumentTableExist)
                {
                    FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }

                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(templateName).ToString());
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);

                // Take values  From Document Details
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight(10);
                FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                var DocumentName = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText();
                var DocStatus = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedDate = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedUser = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText();

                //Verify document details in the details dialog bo
                Support.AreEqual(templateName, DocumentName);
                Support.AreEqual("Created", DocStatus);
                Support.AreEqual(super_user, CreatedUser);
                string date = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                Support.AreEqual("True", CreatedDate.Contains(date).ToString());
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.Highlight(5);
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }
                #endregion

                #region Logout and login back with different user
                Reports.TestStep = "Login into the IIS Side.";
                FASTHelpers.FAST_Login_IIS();
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Search file and edit document added in it
                Reports.TestStep = "Search for file from step 2, select previous document and right click /double click for Phrase View screen";
                FastDriver.TopFrame.SetNumberAndPressEnter(FileNum);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, templateName, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FADoubleClick();
                Playback.Wait(600);
                #endregion

                #region Insert Restart Numbering below in Phrase View
                Reports.TestStep = "In Phrase View screen, select a phrase and right click to Insert->Below->Restart Numbering";
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.DataElementTable.PerformTableAction(1, 5, TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[0]);
                Support.AreEqual("Restart Numbering", FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[2].FAGetText());
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[2].FAClick();
                #endregion

                #region Navigate to Details Tab
                Reports.TestStep = "Navigate to Details tab";
                String date1 = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DetailsTab);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.Highlight(10);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.IsDisplayed();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                Support.AreEqual(DocumentName, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("Edited", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedDate, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedUser, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.FAGetText().Contains(date1).ToString());
                Support.AreEqual(fastqa_user, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.FAGetText());
                #endregion

                #region Click Done button
                Reports.TestStep = "Click on Done button";
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                #endregion

                #region Observe Details from Document Repository
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                //Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DetailsTable);
                FastDriver.NextGenDocumentRepository.DetailsTable.Highlight(10);
                //FastDriver.NextGenDocumentRepository.DetailsTable.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                VerifyDocumentInformationDetails();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }
                #endregion

                #region Select document in Document Repository
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View screen";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", templateName, "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.PhraseViewTab);
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FADoubleClick();
                Playback.Wait(600);
                #endregion

                #region Insert Restart Numbering below in Phrase View
                Reports.TestStep = "In Phrase View screen, select a phrase and right click to Insert->Below->Restart Numbering";
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.DataElementTable.PerformTableAction(1, 5, TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[0]);
                Support.AreEqual("Restart Numbering", FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[2].FAGetText());
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[2].FAClick();
                #endregion

                #region Navigate to Details Tab
                Reports.TestStep = "Navigate to Details tab";
                String date2 = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DetailsTab);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.Highlight(10);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.IsDisplayed();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                Support.AreEqual(DocumentName, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("Edited", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedDate, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedUser, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.FAGetText().Contains(date2).ToString());
                Support.AreEqual(fastqa_user, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.FAGetText());
                #endregion

                #region Click Done button
                Reports.TestStep = "Click on Done button";
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                #endregion

                #region Observe Details from Document Repository
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight(10);
                FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                VerifyDocumentInformationDetails();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 883702 Validate Document Status, Status Change Date and Time | Insert a Section Break | Phrase View

        [TestMethod]
        public void Testcase_883702()
        {
            

            try
            {
                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Section Break | Phrase View";
                #region Data Setup
                String Phrasecode = "T/3";
                String super_user = "Super User";
                String fastqa_user = "FAST QA07";
                //String templateName = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";
                #endregion

                #region Login to Fast
                Reports.TestStep = "Login to Fast IIS screen with superuser credential";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials);
                try { FASTHelpers.FAST_OpenRegionOrOffice(officeId); }
                catch (Exception ex) { FailTest(GetExceptionInfo(ex)); }
                Playback.Wait(4000);
                #endregion

                #region Create a file
                Reports.TestStep = "Create a basic file";
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                Playback.Wait(8000);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                String FileNum = FastDriver.FileHomepage.txtFileNumber.FAGetValue();
                #endregion

                #region Navigate to Document Repository
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentRepository.Open();
                Playback.Wait(6000);
                #endregion

                #region Add document in Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 3, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var DocumentTableExist = FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed();
                while (!DocumentTableExist)
                {
                    FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }

                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(templateName).ToString());
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);

                // Take values  From Document Details
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight(10);
                FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                var DocumentName = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText();
                var DocStatus = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedDate = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText();
                var CreatedUser = FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText();

                //Verify document details in the details dialog bo
                Support.AreEqual(templateName, DocumentName);
                Support.AreEqual("Created", DocStatus);
                Support.AreEqual(super_user, CreatedUser);
                string date = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                Support.AreEqual("True", CreatedDate.Contains(date).ToString());
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.Highlight(5);
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }
                #endregion

                #region Logout and login back with different user
                Reports.TestStep = "Login into the IIS Side.";
                FASTHelpers.FAST_Login_IIS();
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Search file and edit document added in it
                Reports.TestStep = "Search for file from step 2, select previous document and right click /double click for Phrase View screen";
                FastDriver.TopFrame.SetNumberAndPressEnter(FileNum);
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, templateName, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FADoubleClick();
                Playback.Wait(600);
                #endregion

                #region Insert Section Break below in Phrase View
                Reports.TestStep = "In Phrase View screen, select a phrase and right click to Insert->Below->Section Break";
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.DataElementTable.PerformTableAction(1, 5, TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[0]);
                Support.AreEqual("Restart Numbering", FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[3].FAGetText());
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[3].FAClick();
                FastDriver.NextGenDocumentRepository.SectionBreak_DialogDone.FAClick();
                #endregion

                #region Navigate to Details Tab
                Reports.TestStep = "Navigate to Details tab";
                String date1 = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DetailsTab);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.Highlight(10);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.IsDisplayed();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                Support.AreEqual(DocumentName, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("Edited", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedDate, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedUser, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.FAGetText().Contains(date1).ToString());
                Support.AreEqual(fastqa_user, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.FAGetText());
                #endregion

                #region Click Done button
                Reports.TestStep = "Click on Done button";
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                #endregion

                #region Observe Details from Document Repository
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                //Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DetailsTable);
                FastDriver.NextGenDocumentRepository.DetailsTable.Highlight(10);
                //FastDriver.NextGenDocumentRepository.DetailsTable.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                VerifyDocumentInformationDetails();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }
                #endregion

                #region Select document in Document Repository
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View screen";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", templateName, "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.PhraseViewTab);
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FADoubleClick();
                Playback.Wait(600);
                #endregion

                #region Insert Section Break below in Phrase View
                Reports.TestStep = "In Phrase View screen, select a phrase and right click to Insert->Below->Section Break";
                FastDriver.NextGenDocumentRepository.CollapseIcon.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.DataElementTable.PerformTableAction(1, 5, TableAction.Click, "Default Section Break (Continuous)").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DEContextMenu.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[0]);
                Support.AreEqual("Restart Numbering", FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[3].FAGetText());
                FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[3].FAClick();
                FastDriver.NextGenDocumentRepository.SectionBreak_DialogDone.FAClick();
                #endregion

                #region Navigate to Details Tab
                Reports.TestStep = "Navigate to Details tab";
                String date2 = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DetailsTab);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.Highlight(10);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.IsDisplayed();
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                Support.AreEqual(DocumentName, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("Edited", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(3, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedDate, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(4, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual(CreatedUser, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(5, 2, TableAction.GetCell).Element.FAGetText());
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(6, 2, TableAction.GetCell).Element.FAGetText().Contains(date2).ToString());
                Support.AreEqual(fastqa_user, FastDriver.NextGenDocumentRepository.PhraseViewDetailsTable.PerformTableAction(7, 2, TableAction.GetCell).Element.FAGetText());
                #endregion

                #region Click Done button
                Reports.TestStep = "Click on Done button";
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                #endregion

                #region Observe Details from Document Repository
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(14000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight(10);
                FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed();
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(2, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(3, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(4, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(5, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(6, 2, TableAction.GetCell).Element.Highlight(5);
                FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(7, 2, TableAction.GetCell).Element.Highlight(5);
                #endregion

                #region Observe Document status and Status Chg Date
                Reports.TestStep = "Observe Status Chg Date and Document Status";
                VerifyDocumentInformationDetails();
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick(); Playback.Wait(4500);
                if (FastDriver.NextGenDocumentRepository.DetailsTable1.IsDisplayed() == true) { FastDriver.NextGenDocumentRepository.DocDetails_OK.JSClick(); }
                #endregion



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 883710 Validate Status Change User, Status Change Date and Time | Insert a Template | Phrase View

        [TestMethod]
        public void Testcase_883710()
        {
            Reports.TestDescription = "Validate Status Change User, Status Change Date and Time | Insert a Template | Phrase View";

            try
            {


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 884156 Validate Document Status, Status Change User, Status Change Date and Time | Create/Edit document

        [TestMethod]
        public void Testcase_884156()
        {
            Reports.TestDescription = "Validate Document Status, Status Change User, Status Change Date and Time | Create/Edit document";

            try
            {


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 884872 Validate Status Change User, Status Change Date and Time | Create/Save | Info Tab

        [TestMethod]
        public void Testcase_884872()
        {
            Reports.TestDescription = "Validate Status Change User, Status Change Date and Time | Create/Save | Info Tab";

            try
            {


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 884882 Validate Status Change User, Status Change Date and Time | Create/Edit | Info Tab

        [TestMethod]
        public void Testcase_884882()
        {
            Reports.TestDescription = "Validate Status Change User, Status Change Date and Time | Create/Edit | Info Tab";

            try
            {


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 887943 Validate Status Change User, Status Change Date and Time | Move a Phrase | Phrase View

        [TestMethod]
        public void Testcase_887943()
        {
            Reports.TestDescription = "Validate Status Change User, Status Change Date and Time | Move a Phrase | Phrase View";

            try
            {


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion             

        #region Testcase 887962 - Validate Status Change User, Status Change Date and Time | Delete a Phrase | Phrase View

        [TestMethod]
        public void Testcase_887962()
        {
            try
            {
                Reports.TestDescription = "Validate Status Change User, Status Change Date and Time | Delete a Phrase | Phrase View";

                Stopwatch stopwatch = null;
                string tempdesc = Support.RandomString("AAAAAANNNN").ToString();
                LoadTemplateOrCreateNew(tempdesc, tempdesc, "Endorsement/Guarantee");


                Reports.TestStep = "Login with Automation User";

                FASTHelpers.FAST_Login_IIS(regionId: regionId);

                FASTHelpers.FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to File HomePage to get file number";

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string FileNumber = FastDriver.FileHomepage.GetFileNumber();

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, tempdesc).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                stopwatch = Stopwatch.StartNew();

                string date = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                int timehourin24 = DateTime.Now.ToUniversalTime().ToPST().Hour;
                string timehour = "";
                string timemin = DateTime.Now.ToUniversalTime().ToPST().Minute.ToString();
                if (timehourin24 > 12)
                {
                    timehour = (timehourin24 - 12).ToString();
                }
                if (timehourin24 <= 12)
                {
                    timehour = DateTime.Now.ToUniversalTime().ToPST().Hour.ToString();
                }
                if (timehourin24 == 00)
                {
                    timehour = "12";
                }

                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, tempdesc, "Document exists on the Search Result Table");

                Reports.TestStep = "Verify the Data in Details Tab";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTab.FAClick();
                Playback.Wait(2000);

                string CDate = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(4, 2, TableAction.GetText).Message;
                CDate = CDate.Trim();
                Support.AreEqual("True", CDate.Contains(date).ToString());
                Support.AreEqual("True", CDate.Contains(timehour + ":" + timemin).ToString());

                string CUName = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                CUName = CUName.Trim();
                Support.AreEqual(CUName, "FAST QA07");

                string SCDate = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(6, 2, TableAction.GetText).Message;
                SCDate = SCDate.Trim();
                Support.AreEqual("True", SCDate.Contains(date).ToString());
                Support.AreEqual("True", SCDate.Contains(timehour + ":" + timemin).ToString());

                string SCName = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                SCName = SCName.Trim();
                Support.AreEqual(SCName, "FAST QA07");

                Reports.TestStep = "Verify the Data in Details Popup";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.SearchResult_Details.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);
                FastDriver.DetailsDlg.WaitForScreenToLoad();

                string DetailsCDate = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(4, 2, TableAction.GetText).Message;
                DetailsCDate = DetailsCDate.Trim();
                Support.AreEqual("True", DetailsCDate.Contains(date).ToString());
                Support.AreEqual("True", DetailsCDate.Contains(timehour + ":" + timemin).ToString());

                string DetailsCUName = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                DetailsCUName = DetailsCUName.Trim();
                Support.AreEqual(DetailsCUName, "FAST QA07");

                string DetailsSCDate = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(6, 2, TableAction.GetText).Message;
                DetailsSCDate = DetailsSCDate.Trim();
                Support.AreEqual("True", DetailsSCDate.Contains(date).ToString());
                Support.AreEqual("True", DetailsSCDate.Contains(timehour + ":" + timemin).ToString());

                string DetailsSCName = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                DetailsSCName = DetailsSCName.Trim();
                Support.AreEqual(DetailsSCName, "FAST QA07");


                Reports.TestStep = "Login with Super User";


                #region Login
                var credentials = new Credentials() { UserName = "faqa-sa-su", Password = "Superuser3" };
                var credentials1 = new Credentials() { UserName = "feva-sa-su", Password = "superuser" };

                var url = AutoConfig.FASTHomeURL;
                string modifiedurl = url.ToString().ToUpper();
                if (modifiedurl.Contains("FINT"))
                {

                    FASTLogin.Login(url, credentials, true);
                }
                if (modifiedurl.Contains("FEVA"))
                {

                    FASTLogin.Login(url, credentials1, true);
                }

                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                Reports.StatusUpdate("Current region = " + currentInfo["Region"], true);

                #endregion



                Reports.TestStep = "Searching for the Same file";


                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();


                Reports.TestStep = "Editing the document";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.DoubleClick);

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                Reports.TestStep = "Deleting a Phrase";

                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.GetCell).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.SelectDeletefromContextMenu();
                Playback.Wait(2000);

                FastDriver.DeleteDlg.DeleteReason.FASetText("Deleting");
                FastDriver.DeleteDlg.Done.FAClick();
                Playback.Wait(5000);

                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                stopwatch.Stop();
                double totaltimeinmin = stopwatch.Elapsed.TotalMinutes;
                int convtotaltimeinmin = Convert.ToInt32(totaltimeinmin);
                int convtimemin = Convert.ToInt32(timemin);

                int totalmin = convtimemin + convtotaltimeinmin;

                string edittimehour = "";
                string edittimemin = "";

                if (totalmin < 60)
                {
                    edittimehour = timehour;
                    edittimemin = (totalmin).ToString();

                }

                if (totalmin >= 60)
                {

                    edittimehour = (Convert.ToInt32(timehour) + 1).ToString();
                    if (edittimehour == "13")
                    {
                        edittimehour = (Convert.ToInt32(edittimehour) - 12).ToString();
                    }
                    edittimemin = ((totalmin - 60) + convtimemin).ToString();

                }


                Reports.TestStep = "Verify the Data in Details Tab";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTab.FAClick();
                Playback.Wait(2000);

                string CDate1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(4, 2, TableAction.GetText).Message;
                CDate1 = CDate1.Trim();
                Support.AreEqual("True", CDate1.Contains(date).ToString());
                Support.AreEqual("True", CDate1.Contains(timehour + ":" + timemin).ToString());

                string CUName1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                CUName1 = CUName1.Trim();
                Support.AreEqual(CUName1, "FAST QA07");

                string SCDate1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(6, 2, TableAction.GetText).Message;
                SCDate1 = SCDate1.Trim();
                Support.AreEqual("True", SCDate1.Contains(date).ToString());
                Support.AreEqual("True", SCDate1.Contains(edittimehour + ":" + edittimemin).ToString());

                string SCName1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                SCName1 = SCName1.Trim();
                Support.AreEqual(SCName1, "Super User");

                Reports.TestStep = "Navigating to Document Repository Screen";

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Data in Details Popup";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.SearchResult_Details.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                FastDriver.DetailsDlg.WaitForScreenToLoad();


                string DetailsCDate1 = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(4, 2, TableAction.GetText).Message;
                DetailsCDate1 = DetailsCDate1.Trim();
                Support.AreEqual("True", DetailsCDate1.Contains(date).ToString());
                Support.AreEqual("True", DetailsCDate1.Contains(timehour + ":" + timemin).ToString());

                string DetailsCUName1 = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                DetailsCUName1 = DetailsCUName1.Trim();
                Support.AreEqual(DetailsCUName1, "FAST QA07");

                string DetailsSCDate1 = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(6, 2, TableAction.GetText).Message;
                DetailsSCDate1 = DetailsSCDate1.Trim();
                Support.AreEqual("True", DetailsSCDate1.Contains(date).ToString());
                Support.AreEqual("True", DetailsSCDate1.Contains(edittimehour + ":" + edittimemin).ToString());

                string DetailsSCName1 = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                DetailsSCName1 = DetailsSCName1.Trim();
                Support.AreEqual(DetailsSCName1, "Super User");

            }





            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 887963 - Validate Status Change User, Status Change Date and Time | Delete a Phrase button | Phrase View

        [TestMethod]
        public void Testcase_887963()
        {
            try
            {
                Reports.TestDescription = "Validate Status Change User, Status Change Date and Time | Delete a Phrase button | Phrase View";

                Stopwatch stopwatch = null;
                string tempdesc = Support.RandomString("AAAAAANNNN").ToString();
                LoadTemplateOrCreateNew(tempdesc, tempdesc, "Endorsement/Guarantee");


                Reports.TestStep = "Login with Automation User";

                FASTHelpers.FAST_Login_IIS(regionId: regionId);

                FASTHelpers.FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to File HomePage to get file number";

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string FileNumber = FastDriver.FileHomepage.GetFileNumber();

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, tempdesc).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                stopwatch = Stopwatch.StartNew();

                string date = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                int timehourin24 = DateTime.Now.ToUniversalTime().ToPST().Hour;
                string timehour = "";
                string timemin = DateTime.Now.ToUniversalTime().ToPST().Minute.ToString();
                if (timehourin24 > 12)
                {
                    timehour = (timehourin24 - 12).ToString();
                }
                if (timehourin24 <= 12)
                {
                    timehour = DateTime.Now.ToUniversalTime().ToPST().Hour.ToString();
                }
                if (timehourin24 == 00)
                {
                    timehour = "12";
                }

                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, tempdesc, "Document exists on the Search Result Table");

                Reports.TestStep = "Verify the Data in Details Tab";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTab.FAClick();
                Playback.Wait(2000);

                string CDate = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(4, 2, TableAction.GetText).Message;
                CDate = CDate.Trim();
                Support.AreEqual("True", CDate.Contains(date).ToString());
                Support.AreEqual("True", CDate.Contains(timehour + ":" + timemin).ToString());

                string CUName = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                CUName = CUName.Trim();
                Support.AreEqual(CUName, "FAST QA07");

                string SCDate = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(6, 2, TableAction.GetText).Message;
                SCDate = SCDate.Trim();
                Support.AreEqual("True", SCDate.Contains(date).ToString());
                Support.AreEqual("True", SCDate.Contains(timehour + ":" + timemin).ToString());

                string SCName = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                SCName = SCName.Trim();
                Support.AreEqual(SCName, "FAST QA07");

                Reports.TestStep = "Verify the Data in Details Popup";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.SearchResult_Details.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);
                FastDriver.DetailsDlg.WaitForScreenToLoad();

                string DetailsCDate = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(4, 2, TableAction.GetText).Message;
                DetailsCDate = DetailsCDate.Trim();
                Support.AreEqual("True", DetailsCDate.Contains(date).ToString());
                Support.AreEqual("True", DetailsCDate.Contains(timehour + ":" + timemin).ToString());

                string DetailsCUName = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                DetailsCUName = DetailsCUName.Trim();
                Support.AreEqual(DetailsCUName, "FAST QA07");

                string DetailsSCDate = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(6, 2, TableAction.GetText).Message;
                DetailsSCDate = DetailsSCDate.Trim();
                Support.AreEqual("True", DetailsSCDate.Contains(date).ToString());
                Support.AreEqual("True", DetailsSCDate.Contains(timehour + ":" + timemin).ToString());

                string DetailsSCName = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                DetailsSCName = DetailsSCName.Trim();
                Support.AreEqual(DetailsSCName, "FAST QA07");


                Reports.TestStep = "Login with Super User";


                #region Login
                var credentials = new Credentials() { UserName = "faqa-sa-su", Password = "Superuser3" };
                var credentials1 = new Credentials() { UserName = "feva-sa-su", Password = "superuser" };

                var url = AutoConfig.FASTHomeURL;
                string modifiedurl = url.ToString().ToUpper();
                if (modifiedurl.Contains("FINT"))
                {

                    FASTLogin.Login(url, credentials, true);
                }
                if (modifiedurl.Contains("FEVA"))
                {

                    FASTLogin.Login(url, credentials1, true);
                }

                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                Reports.StatusUpdate("Current region = " + currentInfo["Region"], true);

                #endregion



                Reports.TestStep = "Searching for the Same file";


                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();


                Reports.TestStep = "Editing the document";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.DoubleClick);

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                Reports.TestStep = "Deleting a Phrase";

                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 4, TableAction.Click);

                FastDriver.NextGenDocumentRepository.DeletePhrases.FAClick();

                FastDriver.DeleteDlg.DeleteReason.FASetText("Deleting");
                FastDriver.DeleteDlg.Done.FAClick();
                Playback.Wait(5000);

                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                stopwatch.Stop();
                double totaltimeinmin = stopwatch.Elapsed.TotalMinutes;
                int convtotaltimeinmin = Convert.ToInt32(totaltimeinmin);
                int convtimemin = Convert.ToInt32(timemin);

                int totalmin = convtimemin + convtotaltimeinmin;

                string edittimehour = "";
                string edittimemin = "";

                if (totalmin < 60)
                {
                    edittimehour = timehour;
                    edittimemin = (totalmin).ToString();

                }

                if (totalmin >= 60)
                {

                    edittimehour = (Convert.ToInt32(timehour) + 1).ToString();
                    if (edittimehour == "13")
                    {
                        edittimehour = (Convert.ToInt32(edittimehour) - 12).ToString();
                    }
                    edittimemin = ((totalmin - 60) + convtimemin).ToString();

                }


                Reports.TestStep = "Verify the Data in Details Tab";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTab.FAClick();
                Playback.Wait(2000);

                string CDate1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(4, 2, TableAction.GetText).Message;
                CDate1 = CDate1.Trim();
                Support.AreEqual("True", CDate1.Contains(date).ToString());
                Support.AreEqual("True", CDate1.Contains(timehour + ":" + timemin).ToString());

                string CUName1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                CUName1 = CUName1.Trim();
                Support.AreEqual(CUName1, "FAST QA07");

                string SCDate1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(6, 2, TableAction.GetText).Message;
                SCDate1 = SCDate1.Trim();
                Support.AreEqual("True", SCDate1.Contains(date).ToString());
                Support.AreEqual("True", SCDate1.Contains(edittimehour + ":" + edittimemin).ToString());

                string SCName1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                SCName1 = SCName1.Trim();
                Support.AreEqual(SCName1, "Super User");

                Reports.TestStep = "Navigating to Document Repository Screen";

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Data in Details Popup";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.SearchResult_Details.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                FastDriver.DetailsDlg.WaitForScreenToLoad();


                string DetailsCDate1 = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(4, 2, TableAction.GetText).Message;
                DetailsCDate1 = DetailsCDate1.Trim();
                Support.AreEqual("True", DetailsCDate1.Contains(date).ToString());
                Support.AreEqual("True", DetailsCDate1.Contains(timehour + ":" + timemin).ToString());

                string DetailsCUName1 = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                DetailsCUName1 = DetailsCUName1.Trim();
                Support.AreEqual(DetailsCUName1, "FAST QA07");

                string DetailsSCDate1 = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(6, 2, TableAction.GetText).Message;
                DetailsSCDate1 = DetailsSCDate1.Trim();
                Support.AreEqual("True", DetailsSCDate1.Contains(date).ToString());
                Support.AreEqual("True", DetailsSCDate1.Contains(edittimehour + ":" + edittimemin).ToString());

                string DetailsSCName1 = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                DetailsSCName1 = DetailsSCName1.Trim();
                Support.AreEqual(DetailsSCName1, "Super User");

            }





            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 887968 Validate Status Change User, Status Change Date and Time | Move a Phrase button | Phrase View

        [TestMethod]
        public void Testcase_887968()
        {
            Reports.TestDescription = "Validate Status Change User, Status Change Date and Time | Move a Phrase button | Phrase View";

            try
            {


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 887990 - Validate Status Change User, Status Change Date and Time | Finalized/Unfinalized a Document | Phrase View

        [TestMethod]
        public void Testcase_887990()
        {
            try
            {
                Reports.TestDescription = "Validate Status Change User, Status Change Date and Time | Finalized/Unfinalized a Document | Phrase View";

                Stopwatch stopwatch = null;
                string tempdesc = Support.RandomString("AAAAAANNNN").ToString();
                LoadTemplateOrCreateNew(tempdesc, tempdesc, "Endorsement/Guarantee");


                Reports.TestStep = "Login with Automation User";

                FASTHelpers.FAST_Login_IIS(regionId: regionId);

                FASTHelpers.FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to File HomePage to get file number";

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                string FileNumber = FastDriver.FileHomepage.GetFileNumber();

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, tempdesc).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                stopwatch = Stopwatch.StartNew();

                string date = DateTime.Now.ToUniversalTime().ToPST().ToShortDateString();
                int timehourin24 = DateTime.Now.ToUniversalTime().ToPST().Hour;
                string timehour = "";
                string timemin = DateTime.Now.ToUniversalTime().ToPST().Minute.ToString();
                if (timehourin24 > 12)
                {
                    timehour = (timehourin24 - 12).ToString();
                }
                if (timehourin24 <= 12)
                {
                    timehour = DateTime.Now.ToUniversalTime().ToPST().Hour.ToString();
                }
                if (timehourin24 == 00)
                {
                    timehour = "12";
                }

                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, tempdesc, "Document exists on the Search Result Table");

                Reports.TestStep = "Verify the Data in Details Tab";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTab.FAClick();
                Playback.Wait(2000);

                string CDate = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(4, 2, TableAction.GetText).Message;
                CDate = CDate.Trim();
                Support.AreEqual("True", CDate.Contains(date).ToString());
                Support.AreEqual("True", CDate.Contains(timehour + ":" + timemin).ToString());

                string CUName = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                CUName = CUName.Trim();
                Support.AreEqual(CUName, "FAST QA07");

                string SCDate = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(6, 2, TableAction.GetText).Message;
                SCDate = SCDate.Trim();
                Support.AreEqual("True", SCDate.Contains(date).ToString());
                Support.AreEqual("True", SCDate.Contains(timehour + ":" + timemin).ToString());

                string SCName = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                SCName = SCName.Trim();
                Support.AreEqual(SCName, "FAST QA07");

                Reports.TestStep = "Verify the Data in Details Popup";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.SearchResult_Details.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);
                FastDriver.DetailsDlg.WaitForScreenToLoad();

                string DetailsCDate = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(4, 2, TableAction.GetText).Message;
                DetailsCDate = DetailsCDate.Trim();
                Support.AreEqual("True", DetailsCDate.Contains(date).ToString());
                Support.AreEqual("True", DetailsCDate.Contains(timehour + ":" + timemin).ToString());

                string DetailsCUName = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                DetailsCUName = DetailsCUName.Trim();
                Support.AreEqual(DetailsCUName, "FAST QA07");

                string DetailsSCDate = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(6, 2, TableAction.GetText).Message;
                DetailsSCDate = DetailsSCDate.Trim();
                Support.AreEqual("True", DetailsSCDate.Contains(date).ToString());
                Support.AreEqual("True", DetailsSCDate.Contains(timehour + ":" + timemin).ToString());

                string DetailsSCName = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                DetailsSCName = DetailsSCName.Trim();
                Support.AreEqual(DetailsSCName, "FAST QA07");


                Reports.TestStep = "Login with Super User";


                #region Login
                var credentials = new Credentials() { UserName = "faqa-sa-su", Password = "Superuser3" };
                var credentials1 = new Credentials() { UserName = "feva-sa-su", Password = "superuser" };

                var url = AutoConfig.FASTHomeURL;
                string modifiedurl = url.ToString().ToUpper();
                if (modifiedurl.Contains("FINT"))
                {

                    FASTLogin.Login(url, credentials, true);
                }
                if (modifiedurl.Contains("FEVA"))
                {

                    FASTLogin.Login(url, credentials1, true);
                }

                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                Reports.StatusUpdate("Current region = " + currentInfo["Region"], true);

                #endregion



                Reports.TestStep = "Searching for the Same file";


                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();

                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();


                Reports.TestStep = "Editing the document";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.DoubleClick);

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.DocumentStatus.FASelectItem("Finalized");
                Playback.Wait(5000);
                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                stopwatch.Stop();
                double totaltimeinmin = stopwatch.Elapsed.TotalMinutes;
                int convtotaltimeinmin = Convert.ToInt32(totaltimeinmin);
                int convtimemin = Convert.ToInt32(timemin);

                int totalmin = convtimemin + convtotaltimeinmin;

                string edittimehour = "";
                string edittimemin = "";

                if (totalmin < 60)
                {
                    edittimehour = timehour;
                    edittimemin = (totalmin).ToString();

                }

                if (totalmin >= 60)
                {

                    edittimehour = (Convert.ToInt32(timehour) + 1).ToString();
                    if (edittimehour == "13")
                    {
                        edittimehour = (Convert.ToInt32(edittimehour) - 12).ToString();
                    }
                    edittimemin = ((totalmin - 60) + convtimemin).ToString();

                }


                Reports.TestStep = "Verify the Data in Details Tab";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTab.FAClick();
                Playback.Wait(2000);

                string CDate1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(4, 2, TableAction.GetText).Message;
                CDate1 = CDate1.Trim();
                Support.AreEqual("True", CDate1.Contains(date).ToString());
                Support.AreEqual("True", CDate1.Contains(timehour + ":" + timemin).ToString());

                string CUName1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                CUName1 = CUName1.Trim();
                Support.AreEqual(CUName1, "FAST QA07");

                string SCDate1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(6, 2, TableAction.GetText).Message;
                SCDate1 = SCDate1.Trim();
                Support.AreEqual("True", SCDate1.Contains(date).ToString());
                Support.AreEqual("True", SCDate1.Contains(edittimehour + ":" + edittimemin).ToString());

                string SCName1 = FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                SCName1 = SCName1.Trim();
                Support.AreEqual(SCName1, "Super User");

                Reports.TestStep = "Navigating to Document Repository Screen";

                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Data in Details Popup";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempdesc, "Name", TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentRepository.SearchResult_Details.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving... Please Wait...", false, 20);

                FastDriver.DetailsDlg.WaitForScreenToLoad();


                string DetailsCDate1 = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(4, 2, TableAction.GetText).Message;
                DetailsCDate1 = DetailsCDate1.Trim();
                Support.AreEqual("True", DetailsCDate1.Contains(date).ToString());
                Support.AreEqual("True", DetailsCDate1.Contains(timehour + ":" + timemin).ToString());

                string DetailsCUName1 = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(5, 2, TableAction.GetText).Message;
                DetailsCUName1 = DetailsCUName1.Trim();
                Support.AreEqual(DetailsCUName1, "FAST QA07");

                string DetailsSCDate1 = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(6, 2, TableAction.GetText).Message;
                DetailsSCDate1 = DetailsSCDate1.Trim();
                Support.AreEqual("True", DetailsSCDate1.Contains(date).ToString());
                Support.AreEqual("True", DetailsSCDate1.Contains(edittimehour + ":" + edittimemin).ToString());

                string DetailsSCName1 = FastDriver.DetailsDlg.DetailsTable.PerformTableAction(7, 2, TableAction.GetText).Message;
                DetailsSCName1 = DetailsSCName1.Trim();
                Support.AreEqual(DetailsSCName1, "Super User");

            }





            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #endregion       

        #region Document Editor
        #region Testcase 883672 Validate Status Change User, Status Change Date and Time | Right click Document View/Edit

        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Status Change User, Status Change Date and Time | Right click Document View/Edit")]
        public void Testcase_883672()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Validate Status Change User, Status Change Date and Time | Right click Document View/Edit";

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Select previous document and right click for Document View/Edit
                Reports.TestStep = "Select previous document and right click for Document View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TemplateName1, "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Edit anything within the document (Adding a phrase for example)
                Reports.TestStep = "Edit anything within the document (Adding a phrase for example)";
                FastDriver.DocumentEditor.IRInsertPhraseArrowWhite.ContextClick();
                FastDriver.DocumentEditor.IRInsertPhraseMove.FAClick();
                FastDriver.DocumentEditor.IRInsertPhraseBelowGray.FAClick();
                #endregion

                #region Save & Close Editor
                Reports.TestStep = "Save & Close Editor";
                FastDriver.DocumentEditor.IRClickSave();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FAClick();
                FastDriver.DocumentEditor.Yes.FAClick();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FASelectContextMenuItem();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DetailsTable1.Highlight();
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 883678 Validate Status Change User, Status Change Date and Time | Right click/double click ->Phrase view->Document View

        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Status Change User, Status Change Date and Time | Right click/double click ->Phrase view->Document View")]
        public void Testcase_883678()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Validate Status Change User, Status Change Date and Time | Right click/double click ->Phrase view->Document View";

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", TemplateName1, "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Edit anything within the document (ex. Adding a phrase)
                Reports.TestStep = "Edit anything within the document (ex. Adding a phrase)";
                FastDriver.DocumentEditor.IRInsertPhraseArrowWhite.ContextClick();
                FastDriver.DocumentEditor.IRInsertPhraseMove.FAClick();
                FastDriver.DocumentEditor.IRInsertPhraseBelowGray.FAClick();
                #endregion

                #region Save & Close Editor
                Reports.TestStep = "Save & Close Editor";
                FastDriver.DocumentEditor.IRClickSave();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FAClick();
                FastDriver.DocumentEditor.Yes.FAClick();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region Testcase 883717 Validate Document Status, Status Change Date and Time | Insert a Phrase | Phrase View->Document View

        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Insert a Phrase | Phrase View->Document View")]
        public void Testcase_883717()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Phrase | Phrase View->Document View";

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a phrase: Insert->Below->Phrase
                Reports.TestStep = "Insert a phrase: Insert->Below->Phrase";
                FastDriver.DocumentEditor.InsertPhraseBelowAndSave("NGS1/1", "NEXTGEN-SAN-EscrowPhrase-DoNotTouch");
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Phrase View/Edit
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Edit anything within the document (ex. Adding a phrase)
                Reports.TestStep = "Edit anything within the document (ex. Adding a phrase)";
                FastDriver.DocumentEditor.IRInsertPhraseArrowWhite.ContextClick();
                FastDriver.DocumentEditor.IRInsertPhraseMove.FAClick();
                FastDriver.DocumentEditor.IRInsertPhraseBelowGray.FAClick();
                #endregion

                #region Click on Save changes
                Reports.TestStep = "Click on Save changes";
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 883724 Validate Document Status, Status Change Date and Time | Insert a Misc. Phrase | Phrase View ->Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Insert a Misc. Phrase | Phrase View ->Document View")]
        public void Testcase_883724()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Phrase | Phrase View->Document View";

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a misc phrase: Insert->Bottom->Misc
                Reports.TestStep = "Insert a misc phrase: Insert->Bottom->Misc";
                FastDriver.DocumentEditor.InsertMiscPhraseAndSave();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Phrase View/Edit
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Edit anything within the document (ex. Adding a phrase)
                Reports.TestStep = "Edit anything within the document (ex. Adding a phrase)";
                FastDriver.DocumentEditor.IRInsertPhraseArrowWhite.ContextClick();
                FastDriver.DocumentEditor.IRInsertPhraseMove.FAClick();
                FastDriver.DocumentEditor.IRInsertPhraseBelowGray.FAClick();
                #endregion

                #region Click on Save changes
                Reports.TestStep = "Click on Save changes";
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 883751 Validate Document Status, Status Change Date and Time | Insert a Restart Numbering | Phrase View->Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Insert a Restart Numbering | Phrase View->Document View")]
        public void Testcase_883751()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Restart Numbering | Phrase View->Document View";

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a Restart Numbering phrase: Insert->Bottom->Restart Numbering
                Reports.TestStep = "Insert a Restart Numbering phrase: Insert->Bottom->Restart Numbering";
                FastDriver.DocumentEditor.InsertRestartNumberingAndSave();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Phrase View/Edit
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a Restart Numbering phrase: Insert->Bottom->Restart Numbering
                Reports.TestStep = "Insert a Restart Numbering phrase: Insert->Bottom->Restart Numbering";
                FastDriver.DocumentEditor.InsertRestartNumberingAndSave();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 883756 Validate Document Status, Status Change Date and Time | Insert a Section Break | Phrase View->Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Insert a Section Break | Phrase View->Document View")]
        public void Testcase_883756()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Section Break | Phrase View->Document View";

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a Section Break phrase: Insert->Bottom->Section Break
                Reports.TestStep = "Insert a Section Break phrase: Insert->Bottom->Section Break";
                FastDriver.DocumentEditor.InsertSectionBreakAndSave();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Phrase View/Edit
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a Section Break phrase: Insert->Bottom->Section Break
                Reports.TestStep = "Insert a Section Break phrase: Insert->Bottom->Section Break";
                FastDriver.DocumentEditor.InsertSectionBreakAndSave();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 883758 Validate Document Status, Status Change Date and Time | Insert a Template | Phrase View->Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Insert a Template | Phrase View->Document View")]
        public void Testcase_883758()
        { 
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Template | Phrase View->Document View";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a Template: Insert->Bottom->Template Search
                Reports.TestStep = "Insert a Template: Insert->Bottom->Template Search";
                FastDriver.DocumentEditor.InsertTemplateAndSave("Escrow Instruction");
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Phrase View/Edit
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a Template: Insert->Bottom->Template Search
                Reports.TestStep = "Insert a Template: Insert->Bottom->Template Search";
                FastDriver.DocumentEditor.InsertTemplateAndSave("Lender Policy");
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 884122 Validate Document Status, Status Change Date and Time | Insert a Phrase | Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Insert a Phrase | Document View")]
        public void Testcase_884122()
        { 
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Phrase | Document View";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a phrase: Insert->Above->Phrase
                Reports.TestStep = "Insert a phrase: Insert->Above->Phrase";
                FastDriver.DocumentEditor.InsertPhraseBelowAndSave("NGS1/1", "NEXTGEN-SAN-EscrowPhrase-DoNotTouch");
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Phrase View/Edit
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Edit anything within the document (ex. Adding a phrase)
                Reports.TestStep = "Edit anything within the document (ex. Adding a phrase)";
                FastDriver.DocumentEditor.PhraseInsertAbovePhrase();
                FastDriver.DocumentEditor.HandlePhraseSelectionDlg("NGS1/1", "NEXTGEN-SAN-EscrowPhrase-DoNotTouch");
                #endregion

                #region Click on Save changes
                Reports.TestStep = "Click on Save changes";
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 884124 Validate Document Status, Status Change Date and Time | Insert a Misc. Phrase | Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Insert a Misc. Phrase | Document View")]
        public void Testcase_884124()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Misc. Phrase | Document View";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a misc phrase: Insert->Bottom->Misc
                Reports.TestStep = "Insert a misc phrase: Insert->Bottom->Misc";
                FastDriver.DocumentEditor.InsertMiscPhraseAndSave();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Phrase View/Edit
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Edit anything within the document (ex. Adding a misc. phrase)
                Reports.TestStep = "Edit anything within the document (ex. Adding a misc. phrase)";
                FastDriver.DocumentEditor.PhraseInsertAboveMisc();
                FastDriver.DocumentEditor.AcceptCreateMisc();
                #endregion

                #region Click on Save changes
                Reports.TestStep = "Click on Save changes";
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 884125 Validate Document Status, Status Change Date and Time | Insert a Restart Numbering | Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Insert a Restart Numbering | Document View")]
        public void Testcase_884125()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Restart Numbering | Document View";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a Restart Numbering phrase: Insert->Bottom->Restart Numbering
                Reports.TestStep = "Insert a Restart Numbering phrase: Insert->Bottom->Restart Numbering";
                FastDriver.DocumentEditor.InsertRestartNumberingAndSave();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Phrase View/Edit
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a Restart Numbering phrase: Insert->Bottom->Restart Numbering
                Reports.TestStep = "Insert a Restart Numbering phrase: Insert->Bottom->Restart Numbering";
                FastDriver.DocumentEditor.PhraseInsertRestartNumbering();
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 884126 Validate Document Status, Status Change Date and Time | Insert a Section Break | Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Insert a Section Break | Document View")]
        public void Testcase_884126()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Section Break | Document View";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a Section Break phrase: Insert->Bottom->Section Break
                Reports.TestStep = "Insert a Section Break phrase: Insert->Bottom->Section Break";
                FastDriver.DocumentEditor.InsertSectionBreakAndSave();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Phrase View/Edit
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a Section Break phrase: Insert->Above->Section Break
                Reports.TestStep = "Insert a Section Break phrase: Insert->Above->Section Break";
                FastDriver.DocumentEditor.PhraseInsertAboveSectionBreak();
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 884127 Validate Document Status, Status Change Date and Time | Insert a Template | Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Insert a Template | Document View")]
        public void Testcase_884127()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Insert a Template | Document View";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a Template: Insert->Bottom->Template Search
                Reports.TestStep = "Insert a Template: Insert->Bottom->Template Search";
                FastDriver.DocumentEditor.InsertTemplateAndSave("Escrow Instruction");
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Phrase View/Edit
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a Template: Insert->Above->Template Search
                Reports.TestStep = "Insert a Template: Insert->Above->Template Search";
                FastDriver.DocumentEditor.PhraseInsertAboveTemplate();
                FastDriver.DocumentEditor.HandleInsertTemplateDlg("Lender Policy");
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 887948 Validate Document Status, Status Change Date and Time | Move a Phrase | Phrase View->Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Move a Phrase | Phrase View->Document View")]
        public void Testcase_887948()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Move a Phrase | Phrase View->Document View";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Select a phrase and right click to Move->Below
                Reports.TestStep = "Select a phrase and right click to Move->Below";
                FastDriver.DocumentEditor.PhraseMoveBelow();
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Phrase View/Edit
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Select a phrase and right click to Move->Above
                Reports.TestStep = "Select a phrase and right click to Move->Above";
                FastDriver.DocumentEditor.PhraseMoveAbove();
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 887950 Validate Document Status, Status Change Date and Time | Move a Phrase | Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Move a Phrase | Document View")]
        public void Testcase_887950()
        { 
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Move a Phrase | Document View";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Select a phrase and right click to Move->Below
                Reports.TestStep = "Select a phrase and right click to Move->Below";
                FastDriver.DocumentEditor.PhraseMoveBelow();
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the Document View/Edit
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Select a phrase and right click to Move->Above
                Reports.TestStep = "Select a phrase and right click to Move->Above";
                FastDriver.DocumentEditor.PhraseMoveAbove();
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 887974 Validate Document Status, Status Change Date and Time | Delete a Phrase | Phrase View->Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Delete a Phrase | Phrase View->Document View")]
        public void Testcase_887974() 
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Delete a Phrase | Phrase View->Document View";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentEditor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Select a phrase and right click to Delete
                Reports.TestStep = "Select a phrase and right click to Delete";
                FastDriver.DocumentEditor.PhraseDelete("test reason");
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 887975 Validate Document Status, Status Change Date and Time | Delete a Phrase | Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Document Status, Status Change Date and Time | Delete a Phrase | Document View")]
        public void Testcase_887975()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Delete a Phrase | Document View";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Select a phrase and right click to Delete
                Reports.TestStep = "Select a phrase and right click to Delete";
                FastDriver.DocumentEditor.PhraseDelete("test reason");
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region Testcase 890875 Validate Status Change User, Status Change Date and Time | Finalized/Unfinalized a Document | Document View
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("Validate Status Change User, Status Change Date and Time | Finalized/Unfinalized a Document | Document View")]
        public void Testcase_890875()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                string TemplateName1 = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";

                Reports.TestDescription = "Validate Document Status, Status Change Date and Time | Finalized/Unfinalized a Document | Document View";

                #region Login to Fast IIS screen
                Reports.TestStep = "Login to Fast IIS screen";
                var superuser = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };
                FASTHelpers.FAST_Login_IIS(credentials: superuser);
                #endregion

                #region Create a basic file
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add any document to Doc Rep";
                AddDocumentInDocRepo(TemplateName1);
                var status = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 10, TableAction.GetText).Element.FAGetText();
                Support.AreEqual("Created", status);
                #endregion

                #region Logout and log back in with a different User
                Reports.TestStep = "Logout and log back in with a different User";
                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Search for file created in step 2
                Reports.TestStep = "Search for file created in step 2";
                FastDriver.TopFrame.SearchFileByFileNumber(FASTHelpers.File.FileNumber);
                #endregion

                #region Select previous document and Document/Phrase View
                Reports.TestStep = "Select previous document and Document/Phrase View";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Finalize the document
                Reports.TestStep = "Finalize the document";
                FastDriver.DocumentEditor.FinalizeDocument();
                FastDriver.DocumentEditor.CloseEditor();
                #endregion 

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Finalized", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", status: "Finalized");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Finalized", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", status: "Finalized");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Phrase View/Edit
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Finalized", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Unfinalized the document
                Reports.TestStep = "Unfinalized the document";
                FastDriver.DocumentEditor.UnfinalizeDocument("test reason");
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

                #region Navigate to Details tab
                Reports.TestStep = "Navigate to Details tab";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.Phrases_ViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
                FastDriver.NextGenDocumentRepository.DetailsTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DetailsTable);
                #endregion

                #region Observe Status Chg User and Status Chg Date
                Reports.TestStep = "Observe Status Chg User and Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", status: "Edited");
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region In Document Repository screen, Select the document and right click for Details
                Reports.TestStep = "In Document Repository screen, Select the document and right click for Details";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Edited", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SearchResult_Details.FAClick();
                Playback.Wait(6000);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Observe Status Chg Date
                Reports.TestStep = "Observe Status Chg Date";
                VerifyDocumentInformationDetails(documentName: "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", status: "Edited");
                FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion
        #endregion Document Editor       
        
        [TestInitialize]
        public override void TestInitialize()
        {
            FASTHelpers.CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
