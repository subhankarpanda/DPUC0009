﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;


namespace NextGenDocPrep.r10._2016.US_Enhancement
{
    [CodedUITest]
    public class US_762321 : FASTHelpers
    {
        #region Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }
        #endregion

        [TestMethod]

        public void TC_Select_the_region_drop_down_to_validate_default_to_user_logged_in_region()
        {
            try
            {
                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();                
                #endregion

                #region Select Region(s) Drop-Down
                Reports.TestStep = "Select Region(s) Drop-Down";
                FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading", false);
                #endregion

                #region To validate by default users logged in region checkbox is checked and default
                Reports.TestStep = "To validate by default users logged in region checkbox is checked and default";
                FastDriver.NextGenDocumentPreparation.RegionDocGenDrop.FASetCheckbox(true);
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.RegionDropdonw.Exists().ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }



        [TestMethod]

        public void TC_3693_Verify_new_column_name_and_captures_user_Admin_username()
        {
            try
            {
                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Verify New Column exist with the name "Revisede by"
                Reports.TestStep = "Verify New Column exist with the name Revisede by";
                FastDriver.NextGenDocumentPreparation.RevisedByColumn.Highlight();
                FastDriver.NextGenDocumentPreparation.RevisedByColumn.FAClick();                
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 15);
                if (FastDriver.NextGenDocumentPreparation.TemplateTableDash.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentPreparation.TemplateTableDash.StringExistOnTable("Revised By").ToString());
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Revised By", false, 35);
                string UserDetail = FastDriver.NextGenDocumentPreparation.TemplateTableDash.GetColumnCount().ToString();
                FastDriver.NextGenDocumentPreparation.TemplateTableDash.PerformTableAction(6, 6, TableAction.Click);                                    
                #endregion


            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }


        [TestMethod]

        public void TC_3718_Select_sort_option_for_user_column()
        {
            try
            {
                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Validate sorting option in  "Revised by" column.
                Reports.TestStep = "Validate sorting option in Revised by column. ";               
                Support.AreEqual("Revised By", FastDriver.NextGenDocumentPreparation.RevisedByColumn.FAGetText().ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion

                #region Click on sort option
                Reports.TestStep = " Click on sort option ";
                FastDriver.NextGenDocumentPreparation.RevisedByColumn.FAClick();
                FastDriver.NextGenDocumentPreparation.SortRivsedBy.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.SortRivsedBy.Exists().ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion



            }
            catch (Exception ex)
            {

                FailTest(ex.Message);

            }
        }



        [TestMethod]

        public void TC_4035_The_users_shall_load_screen_with_logged_in_region_templates_and_sorted_by_Date()
        {
            try
            {

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Select Region(s) Drop-Down  and Validate defaulted region in Regions drop-down
                Reports.TestStep = "Select Region(s) Drop-Down  and Validate defaulted region in Regions drop-down";
                FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAClick();
                Support.AreEqual("QA Sandpointe - Next Gen", FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAGetText().ToString());                
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 #endregion

                #region Validate that the users logged in region(s) checkbox are checked.
                Reports.TestStep = "Validate that the users logged in region(s) checkbox are checked.";
                FastDriver.NextGenDocumentPreparation.RegionDocGenDrop.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion

                #region Validate templates default sorting
                Reports.TestStep = "Validate templates default sorting";
                FastDriver.NextGenDocumentPreparation.CreatedDateColumn.FAClick();              
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateTableDash.PerformTableAction(1, 1, TableAction.Click, "").Element.FADoubleClick();               
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 #endregion

                #region Validate Template region should match with region from region column
                Reports.TestStep = "Validate Template region should match with region from region column";
                FastDriver.NextGenDocumentPreparation.TemplateRegion.Highlight();
                string TestFile = FastDriver.NextGenDocumentPreparation.TemplateRegion.FAGetSelectedItem().ToString();
                Support.AreEqual("QA Sandpointe - Next Gen", TestFile);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion




            }
            catch (Exception ex)
            {

                FailTest(ex.Message);

            }
        }


        [TestMethod]

        public void TC_4059Ability_to_change_the_sorting_order_and_change_the_region_from_user_of_those_region()
    {
        try
    {
        string RandomtemplateName = Support.RandomString("AAAAAAA");
        string RandomDescription = Support.RandomString("AAAAAAA");
        string RandomTemplateType = "";
        string RegionSett = "North American Title California Division, QA Sandpointe - Next Gen";
      

        #region Login Fast
        Reports.TestStep = "Login into the ADM Side.";
        FAST_Login_ADM(isSuperUser: true);
        #endregion

        #region Office selection
        Reports.TestStep = "Navigate to QA Sandpointe NG Region";
        FastDriver.SecuritySelectRegionOffice.Open();
        FastDriver.SecuritySelectRegionOffice.EnterBUID("6210");
        #endregion

        #region  Navigate NexGen Document Preparation
        Reports.TestStep = "Navigate NexGen Document Preparation";
        FastDriver.NextGenDocumentPreparation.Open();
        #endregion

        #region Navigate to NextGen Document Preparation/Templates Search/ Create a Template
        Reports.TestStep = " Navigate to NextGen Document Preparation/Templates Search/ Create a Template";
        FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
        FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
        FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
        FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
        FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
        //FastDriver.NextGenDocumentPreparation.Region.FAClick();      
        //FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
        //FastDriver.NextGenDocumentPreparation.NextGenReg.FAClick();
        //FastDriver.NextGenDocumentPreparation.NortRegDivi.FAClick(); 
        FastDriver.NextGenDocumentPreparation.TemplateDescription.FASendKeys(RandomDescription);
        FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
        FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
        var templateTable = FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.GetAttribute("textContent");
        var templateExists = templateTable.Contains(RegionSett);
        if (!templateExists)
        {
            FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
            //FastDriver.NextGenDocumentPreparation.TemplateRegion.FAClick();
            //FastDriver.NextGenDocumentPreparation.TemplateRegion.FASelectItem("North American Title California Division");
            FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
            FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(RandomDescription);
            FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(RandomTemplateType);
            FastDriver.NextGenDocumentPreparation.Save.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
            Reports.StatusUpdate("Template: " + RandomDescription + " just created", true);

        }
        else
        {
            Reports.StatusUpdate("Template: " + RandomDescription + " already exist", true);
        }
        #endregion

        #region Office selection
        Reports.TestStep = "Navigate to QA Sandpointe NG Region";
        FastDriver.SecuritySelectRegionOffice.Open();
        FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
        #endregion

        #region  Navigate NexGen Document Preparation
        Reports.TestStep = "Navigate NexGen Document Preparation";
        FastDriver.NextGenDocumentPreparation.Open();
        #endregion

        #region Select any region from drop-down
        Reports.TestStep = "Select any region from drop-down ";
        FastDriver.NextGenDocumentPreparation.DashboardTab.FAClick();
        FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
        FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAClick();
        FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
        FastDriver.NextGenDocumentPreparation.RegionDocGenDrop.FASetCheckbox(true);
        FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
        FastDriver.NextGenDocumentPreparation.RegionNationalTiCaliforniaDivision.FAClick();
        FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
        FastDriver.NextGenDocumentPreparation.TemplateTableRefresh.FAClick();
        FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
        #endregion

        #region Validate user by default format
        Reports.TestStep = "Validate user by default format ";        
        var Formatuser = FastDriver.NextGenDocumentPreparation.FormatUser.FAGetText();
        Support.AreEqual("feva-sa-su", Formatuser);
        FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
        #endregion

        #region Validate date format and ability user click on any column
        Reports.TestStep = "Validate date format and ability user click on any column";     
        FastDriver.NextGenDocumentPreparation.DateDash.IsDisplayed();   
        var details = FastDriver.NextGenDocumentPreparation.DateDash.FAGetAttribute("textContent").Clean();
                var _date = DateTime.UtcNow.ToPST().ToDateString(slash: true, trim: true);
                var _time = DateTime.UtcNow.ToPST().ToTimeString(trim: true, timeZone: true);
        Support.AreNotEqual(details, _date + " " + _time, false);
        FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);       
        FastDriver.NextGenDocumentPreparation.CreatedDateColumn.FAClick();
        FastDriver.NextGenDocumentPreparation.CreatedDateColumn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
        #endregion       
    }
            catch (Exception ex)
            {

                FailTest(ex.Message);
    }

    }


        [TestMethod]

        public void TC_4080_To_verify_recent_activities_in_the_dashboard_by_date()
        {
            try
            {

                string RandomtemplateName = Support.RandomString("AAAAAAA");
                string RandomDescription = Support.RandomString("AAAAAAA");
                string RandomTemplateType = "";

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Navigate to NextGen Document Preparation/Templates Search/ Create a Template
                Reports.TestStep = " Navigate to NextGen Document Preparation/Templates Search/ Create a Template";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                var templateExists = templateTable.Contains(RandomDescription);
                if (!templateExists)
                {
                    FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(RandomDescription);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(RandomTemplateType);
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    Reports.StatusUpdate("Template: " + RandomDescription + " just created", true);

                }
                else
                {
                    Reports.StatusUpdate("Template: " + RandomDescription + " already exist", true);
                }
                #endregion

                #region Validate New Template exist on Dashboard Tab
                Reports.TestStep = "Validate New Template exist on Dashboard Tab";
                FastDriver.NextGenDocumentPreparation.DashboardTab.FAClick();
                if (FastDriver.NextGenDocumentPreparation.TemplateTableDash.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateTableDash.StringExistOnTable(RandomDescription).ToString());
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Verify Favorite template ", false, 35);
                #endregion

                #region Verify each sort by coulmns
                Reports.TestStep = "Verify each sort by coulmns";
                FastDriver.NextGenDocumentPreparation.TemplateNameColumn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify the Column", false);
                FastDriver.NextGenDocumentPreparation.TemplateNameColumn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify the Column", false);
                FastDriver.NextGenDocumentPreparation.TemplateDescriptionColumn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify the Column", false);
                FastDriver.NextGenDocumentPreparation.TemplateDescriptionColumn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify the Column", false);
                FastDriver.NextGenDocumentPreparation.TemplateTypecolumn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify the Column", false);
                FastDriver.NextGenDocumentPreparation.TemplateTypecolumn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify the Column", false);
                FastDriver.NextGenDocumentPreparation.CreatedDateColumn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify the Column", false);
                FastDriver.NextGenDocumentPreparation.CreatedDateColumn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify the Column", false);
                FastDriver.NextGenDocumentPreparation.RegionCoulmn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify the Column", false);
                FastDriver.NextGenDocumentPreparation.RegionCoulmn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify the Column", false);
                FastDriver.NextGenDocumentPreparation.RevisedByColumn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify the Column", false);
                FastDriver.NextGenDocumentPreparation.RevisedByColumn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify the Column", false);
                FastDriver.NextGenDocumentPreparation.RevisedByColumn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify the Column", false);
                #endregion

                #region Select Region(s) Drop-Down
                Reports.TestStep = "Select Region(s) Drop-Down  ";
                FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAClick();
                #endregion

                #region Validate by default users logged in region checkbox is checked.
                Reports.TestStep = "Validate by default users logged in region checkbox is checked.";
                Support.AreEqual("QA Sandpointe - Next Gen", FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAGetText().ToString());    
                FastDriver.NextGenDocumentPreparation.RegionDocGenDrop.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion


                #region Click on template row 
                Reports.TestStep = "Click on template row ";
                FastDriver.NextGenDocumentPreparation.TemplateTableDash.PerformTableAction(1, 1, TableAction.Click, "").Element.FADoubleClick();  
                #endregion



                #region Verify template region in properties tab. 
                Reports.TestStep = " Verify template region in properties tab";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading properties tab screen", false);               
                var RegionTemplate = FastDriver.NextGenDocumentPreparation.TemplateRegion.FAGetSelectedItem();
                Support.AreEqual("QA Sandpointe - Next Gen", RegionTemplate);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verifing Region", false, 10);
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }



    [TestMethod]

        public void TC_4112_Validate_warning_message_when_no_region_is_selected_in_drop_down()
        {
        try
        {
            #region Login Fast
            Reports.TestStep = "Login into the ADM Side.";
            FAST_Login_ADM(isSuperUser: true);
            #endregion

            #region Office selection
            Reports.TestStep = "Navigate to QA Sandpointe NG Region";
            FastDriver.SecuritySelectRegionOffice.Open();
            FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
            #endregion

            #region  Navigate NexGen Document Preparation
            Reports.TestStep = "Navigate NexGen Document Preparation";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Validate warning message
            Reports.TestStep = "Validate warning message";
            FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
            FastDriver.NextGenDocumentPreparation.RegionDocGenDrop.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
            FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
            FastDriver.NextGenDocumentPreparation.TemplateTableRefresh.FAClick();
            Support.AreEqual("Please select a region", FastDriver.WebDriver.HandleDialogMessage(true, true, 15).ToString());
            FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
            #endregion

        }
        catch (Exception ex)
        {

            FailTest(ex.Message);
        }
        }


        [TestMethod]

        public void TC_9716_Verify_user_has_the_ability_to_select_the_other_regions_apart_from_logged_in_region_and_verify_Templates()
        {
            try
            {
                string RandomtemplateName = Support.RandomString("AAAAAAA");
                string RandomDescription = Support.RandomString("AAAAAAA");
                string RandomTemplateType = "";

                // Precondition Create a template from another region                     

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office and Region selection California
                Reports.TestStep = "Office selection California";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("12971");
                #endregion                

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Navigate to NextGen Document Preparation/Templates Search/ Create a Template
                Reports.TestStep = " Navigate to NextGen Document Preparation/Templates Search/ Create a Template";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                var TemplateTest = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                var templateExists2 = TemplateTest.Contains(RandomDescription);
                if (!templateExists2)
                {
                    FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(RandomDescription);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(RandomTemplateType);
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    Reports.StatusUpdate("Template: " + RandomDescription + " just created", true);

                }
                else
                {
                    Reports.StatusUpdate("Template: " + RandomDescription + " already exist", true);
                }
                #endregion



                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Select Region(s) Drop-Down
                Reports.TestStep = "Select Region(s) Drop-Down ";
                FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAClick();
                #endregion


                #region Select any region(s) in drop-down
                Reports.TestStep = "Select any region(s) in drop-down";
                FastDriver.NextGenDocumentPreparation.RegionNationalTiCaliforniaDivision.FAClick();
                FastDriver.NextGenDocumentPreparation.RegionDocGenDrop.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateTableRefresh.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading resquest", false);         
                var TemplateonTable = FastDriver.NextGenDocumentPreparation.RegionTable.FAGetText();
                Support.AreEqual("North American Title California Division", TemplateonTable);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading resquest", false);
                #endregion

                #region Click on Template of the other Region and Verify region in properties tab
                Reports.TestStep = "Click on Template of the other Region and Verify region in properties tab";
                FastDriver.NextGenDocumentPreparation.TemplateTableDash.PerformTableAction(1, 1, TableAction.Click, "").Element.FADoubleClick();                
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading resquest", false);
                var RegionProperties = FastDriver.NextGenDocumentPreparation.TemplateRegion.FAGetSelectedItem();
                Support.AreEqual("North American Title California Division", RegionProperties);            
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading resquest", false);
                 #endregion

                           }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }



        [TestMethod]

        public void TC_9754_Verify_All_region_Option_from_Drop_Drown()
        {
            try
            {

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Verify All option in drop-down
                Reports.TestStep = "Verify All option in drop-down";
                FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAClick();
                FastDriver.NextGenDocumentPreparation.RegionDocGenDrop.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Set up All option", false);
                FastDriver.NextGenDocumentPreparation.AllRegionDash.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify All region is checked ", false);
                FastDriver.NextGenDocumentPreparation.AllRegionDash.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify All region is checked ", false);
                FastDriver.NextGenDocumentPreparation.AllregionChecked.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAClick();      
                #endregion

                #region Verify all region are display on table 
                Reports.TestStep = "Verify all region are display on table ";
                var Filters = FastDriver.NextGenDocumentPreparation.AllregionChecked.FAGetText();
                if (FastDriver.NextGenDocumentPreparation.TemplateTableDash.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateTableDash.StringExistOnTable(Filters).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");

                }           
                #endregion

                #region Remove All option in region list drop-down and select some other region
                Reports.TestStep = "Remove All option in region list drop-down and select some other region";
                FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("loading drop-down", false);
                FastDriver.NextGenDocumentPreparation.AllRegionDash.FAClick();
                FastDriver.NextGenDocumentPreparation.AllRegionDash.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false);
                FastDriver.NextGenDocumentPreparation.RegionNationalTiCaliforniaDivision.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false);
                FastDriver.NextGenDocumentPreparation.RegionNationalTiCaliforniaDivision.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false);
                FastDriver.NextGenDocumentPreparation.RegionDocPrepNextGen.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false);
                FastDriver.NextGenDocumentPreparation.RegionDocPrepNextGen.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false);
                FastDriver.NextGenDocumentPreparation.RegionDropdonw.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false);
                FastDriver.NextGenDocumentPreparation.TemplateTableRefresh.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);

            }
        }



    [TestMethod]

        public void TC_1610_Create_New_Template_and_Verifies_that_is_editable_by_other_users()
        {
            try
            {
                string RandomtemplateName = Support.RandomString("AAAAAAA");
                string RandomDescription = Support.RandomString("AAAA");
                string RandomTemplateType = "";
                string tempName = "San Diego city";
                string Formuse = "fastts\fastqa07";

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Navigate to NextGen Document Preparation/Templates Search/ Create a Template
                Reports.TestStep = " Navigate to NextGen Document Preparation/Templates Search/ Create a Template";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                var templateExists = templateTable.Contains(RandomDescription);
                if (!templateExists)
                {
                    FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(RandomDescription);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(RandomTemplateType);
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    Reports.StatusUpdate("Template: " + RandomDescription + " just created", true);

                }
                else
                {
                    Reports.StatusUpdate("Template: " + RandomDescription + " already exist", true);
                }
                #endregion

                #region Validate New Template exist on Dashboard Tab
                Reports.TestStep = "Validate New Template exist on Dashboard Tab";
                FastDriver.NextGenDocumentPreparation.DashboardTab.FAClick();
                if (FastDriver.NextGenDocumentPreparation.TemplateTableDash.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateTableDash.StringExistOnTable(RandomDescription).ToString());
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Verify Favorite template ", false, 35);
                #endregion

                //Changes the user

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: false);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Search template created by user1
                Reports.TestStep = "Search template created by user1";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                #endregion

                #region User 2 make some changes into template 
                Reports.TestStep = "User 2 make some changes into template ";
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(tempName);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                FastDriver.NextGenDocumentPreparation.Template_Information_FontName.FASelectItem(RandomTemplateType);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                FastDriver.NextGenDocumentPreparation.DashboardTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                #endregion

                #region Validate New Template exist on Dashboard Tab
                Reports.TestStep = "Validate New Template exist on Dashboard Tab";
                FastDriver.NextGenDocumentPreparation.DashboardTab.FAClick();
                if (FastDriver.NextGenDocumentPreparation.DashTable.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.DashTable.StringExistOnTable(RandomtemplateName).ToString());
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentPreparation.DashTable.StringExistOnTable(tempName, false).ToString());                    
                }             
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Verify  template ", false, 35);
                #endregion          

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }




        [TestMethod]

        public void TC_1631_Verify_the_last_status_of_the_templates_created()
    {
            try
            {
                string descripTem = "I've changes Properties";

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion


                #region Search any template 2 day ago
                Reports.TestStep = "Search any template 2 day ago";            
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                FastDriver.NextGenDocumentPreparation.TemplateTableDash.PerformTableAction(1, 1, TableAction.Click, "").Element.FADoubleClick();               
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASendKeys(descripTem);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                FastDriver.NextGenDocumentPreparation.DashboardTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);              
                if (FastDriver.NextGenDocumentPreparation.DashTable.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.DashTable.StringExistOnTable(descripTem, false).ToString());
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 30);
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
    }


        [ClassCleanup]
        public static void ClassCleanup()
        {
            FASTHelpers.CleanupClass();
        }
    }
}