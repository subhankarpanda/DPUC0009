﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;

namespace NextGenDocPrep.r10._2016.US_Enhancement
{

    [CodedUITest]
    public class US_779848 : FASTHelpers
    {
        #region Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }
        #endregion

        [TestMethod]
        public void TC_4971_Verify_new_button_Save_in_Phrase_Properties_screen ()
        {
            try
            {

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                #endregion

                #region Search any Template in ADM
                Reports.TestStep = "Search any Template in ADM";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ",false);
                #endregion

                #region Select any Phrase into Template and Validate Save Button is there
                 Reports.TestStep = "Select any Phrase into Template ";
                 FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                 FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FADoubleClick();
                 FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.Highlight();
                 Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.Exists().ToString());
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                 FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                 FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                 FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                 FastDriver.NextGenDocumentPreparation.PropertiesphraseContext.FAClickAction();                
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                 FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.Highlight();
                 Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.Exists().ToString());
                 FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false,15);
                 #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);

            }
        }


        [TestMethod]

        public void TC_4994_Validate_if_user_has_made_any_changes_on_clicking_save_button_changes_are_saved_Existing_Phrase()
        {
            try
            {

               

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                #endregion

                #region Search any Template in ADM
                Reports.TestStep = "Search any Template in ADM";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASendKeys("1793");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion

                #region Select any Phrase with menu context into Template And Changes any properties phrase.
                Reports.TestStep = "Select any Phrase with menu context into Template And Changes any properties phrase";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();               
                FastDriver.NextGenDocumentPreparation.PropertiesphraseContext.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FASelectItem("Calibri");
                FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("14");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion

                #region Select any phrase double-click on phrase table and validate last changes.
                Reports.TestStep = "Select any phrase double-click on phrase table and validate last changes";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FADoubleClick();
                Support.AreEqual("Calibri".ToString(), FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FAGetSelectedItem().ToString(), " Verify type size word");
                Support.AreEqual("14".ToString(), FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FAGetSelectedItem().ToString(), " Verify type size word");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion

                #region Modify last changes in properties phrase
                Reports.TestStep = " Modify last changes in properties phrase";
                FastDriver.NextGenDocumentPreparation.PhraseMarginMode_KeepLinesTog.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FASelectItem("Georgia");
                FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("16");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion

                #region Verify  all phrase changes are in Phrase Tab.
                Reports.TestStep = "Verify  all phrase changes are in Phrase Tab";
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                FastDriver.NextGenDocumentPreparation.ExcrowFilterPhrase.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseDescription.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseDescription.FASendKeys("1793");
                FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhrasesResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTable.PerformTableAction(3, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.EditPhrasetable.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);               
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false, 5);      
                #endregion

             

                


           

                

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]

        public void TC_5019_System_allows_to_save_multiple_changes_on_clicking_Save_button_Existing_phrase()
        {
            try
            {

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                #endregion

                #region Search any Template in ADM
                Reports.TestStep = "Search any Template in ADM";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASendKeys("1793");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion

                #region Select any Phrase with menu context into Template And Changes any properties phrase.
                Reports.TestStep = "Select any Phrase into Template ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PropertiesphraseContext.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FASelectItem("Calibri");
                FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("14");        
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();                
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion

                #region Select any phrase double-click on phrase table and validate last changes.
                Reports.TestStep = "Select any phrase double-click on phrase table and validate last changes";             
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                Support.AreEqual("Calibri", FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FAGetSelectedItem().ToString(), " Verify type size word");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                Support.AreEqual("14", FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FAGetSelectedItem().ToString(), " Verify type size word");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion

                #region Modify last changes in properties phrase
                Reports.TestStep = " Modify last changes in properties phras";
                //FastDriver.NextGenDocumentPreparation.PhraseMarginMode_KeepLinesTog.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FASelectItem("MS PMincho");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion

                #region Verify  all phrase changes are in Phrase Tab.
                Reports.TestStep = "Verify  all phrase changes are in Phrase Tab";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                FastDriver.NextGenDocumentPreparation.SelectAllPrase.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseDescription.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseDescription.FASendKeys("1793");
                FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClick();                
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhrasesResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTable.PerformTableAction(3, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.EditPhrasetable.FASelectContextMenuItem();               
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                //FastDriver.NextGenDocumentPreparation.PhraseMarginMode_KeepLinesTog.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion

                #region  Click on Template Tab and verify in Template Preview.
                Reports.TestStep = "Click on Template Tab and verify in Template Preview";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASendKeys("1793");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FADoubleClick();                                           
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false, 20);

                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);

            }
        }

        [TestMethod]

        public void TC_5108_Validate_phrases_multiple_changes_are_saved_New_Template_Existing_Phrase()

        {
            try
            {
                string RandomtemplateName = Support.RandomString("AAAAAAA");

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                #endregion

                #region Create  any Template in ADM
                Reports.TestStep = "Search any Template in ADM";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.TemplateName.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(RandomtemplateName);   
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys("US-779848");
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Form");
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion   

                #region Phrases Selection Dialogue and Phrase Type and click Save
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type and click Save  ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();                
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Miscellaneous Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("0108 phrase group[0108]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion    

                #region select same phrase and change properties phrase. 
                Reports.TestStep = "select same phrase and changes properties phrase";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FASelectItem("Calibri");
                FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("18");
                FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.PropertiesphraseContext.FASelectContextMenuItem();
                Support.AreEqual("Calibri", FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FAGetSelectedItem().ToString(), " Verify type fond word");
                Support.AreEqual("18", FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FAGetSelectedItem().ToString(), " Verify type fond word");
                FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("20");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion
   

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void TC_6008_If_user_has_not_made_any_changes_on_click_Save_system_should_display_warning_message()
        {
            try
            {
                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                #endregion

                #region Search any Template in ADM
                Reports.TestStep = "Search any Template in ADM";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion

                #region Select any Phrase into Template, Click on save button validate warn.
                Reports.TestStep = "Select any Phrase into Template, Click on save button validate warn. ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 15);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab);                                  
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);               
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PropertiesphraseContext.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 15);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab);                 
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false,10);
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }
            


        [TestMethod]

        public void TC_6026_If_user_has_made_changes_and_not_saved_it_system_should_display_warning()
        {
            try
            {
                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                #endregion

                #region Search any Template in ADM
                Reports.TestStep = "Search any Template in ADM";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                #endregion

                #region Select any Phrase into Template, Click on save button validate warn.
                Reports.TestStep = "Select any Phrase into Template, Click on save button validate warn. ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FASelectItem("SimSun-ExtB");
                FastDriver.NextGenDocumentPreparation.Templates_PropertiesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);                         
                FastDriver.WebDriver.HandleDialogMessage(true, true, 15);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab);   
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false, 15);
               #endregion

                







            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }


        [TestMethod]

        public void TC_0719_Verify_scenarios_Versioning_Phrase_Template()
        {
            try
            {
                string RandomtemplateName = Support.RandomString("AAAAAAA");
                string RandomDescription = Support.RandomString("AAAAAAA");

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Preparation/Templates Search/ Create a Template
                Reports.TestStep = " Navigate to NextGen Document Preparation/Templates Search/ Create a Template";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                var templateExists = templateTable.Contains(RandomDescription);
                if (!templateExists)
                {
                    FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(RandomDescription);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Form");
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.NextGenDocumentPreparation.VersioningTemplate.Highlight();
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.VersioningTemplate.IsDisplayed().ToString());
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    Reports.StatusUpdate("Template: " + RandomDescription + " just created", true);

                }
                else
                {
                    Reports.StatusUpdate("Template: " + RandomDescription + " already exist", true);
                }
                FastDriver.NextGenDocumentPreparation.VersioningTemplate.Highlight();               
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                #endregion

                #region Click Filtering TAB Select All Select options
                Reports.TestStep = "Click Filtering TAB Select All Select options ";
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (true)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                }

                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion    

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion 
                
                #region Phrases Selection Dialogue and Phrase Type and click Save
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type and click Save  ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();             
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Miscellaneous Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("0108 phrase group[0108]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Exception Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("Zera[#]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Click Save and Under Construction
                Reports.TestStep = "Click Save and Under Construction ";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                if (false)
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                }

                FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                #endregion

               


               

            
                // Go IIS

                #region DataSetup IIS
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region Login to FAST Application File Side
                Reports.TestStep = "Login to FAST Application File Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Navigate to Select Office screen";
                //FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad();

                Reports.TestStep = "Navigate to NextGen Region/Office Level";
                FastDriver.SecuritySelectRegionOffice.EnterBUID(officeId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                if (currentInfo["Region"] != "QA Sandpointe - Next Gen")
                    throw new Exception("Incorrect Region. Current region = " + currentInfo["Region"]);
                #endregion

                #region CreateFile
                string fileNumber = "";
                try
                {
                    Reports.TestStep = "Create File using web service.";
                    var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
                    nextGenRequest.Source = "LVIS";     // for EVAL00, source has to other than FAST
                    nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
                    nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
                    nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);
                    fileNumber = FastDriver.FACreateFileFromWCF(nextGenRequest);
                    FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                }
                catch //If not able to create file via web service, create file via FAST GUI
                {
                    Reports.TestStep = "Create File using FAST GUI.";
                    FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                    try
                    {
                        FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                    }
                    catch
                    {
                        Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                    }

                    FastDriver.QuickFileEntry.CreateStandardFile();
                    FastDriver.TopFrame.SwitchToTopFrame();
                    FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
                    fileNumber = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
                }
                #endregion

                #region  Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search criteria All Templates Option
                Reports.TestStep = "Perform Select Template Search criteria All Templates Option";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click, "Exchange Delayed").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

              

                            

                // Come Back ADM 

                #region DataSetup ADM
                Reports.TestStep = "DataSetup ADM";
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);
                #endregion

                #region Navigate Document Preparation
                Reports.TestStep = "Navigate Document Preparation ";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #region Search Templates into Template TAB
                Reports.TestStep = "Search Templates into Template TAB";
                FastDriver.NextGenDocumentPreparation.TemplateTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateType.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 2, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please........", false);
                FastDriver.NextGenDocumentPreparation.VersioningTemplate.Highlight();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.VersioningTemplate.IsDisplayed().ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("view versioning Template", false, 5);
                #endregion           

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);

            }
        }
        
        
        
        [ClassCleanup]
        public static void ClassCleanup()
        {
            FASTHelpers.CleanupClass();
        }  
    }
}
