﻿using FASTSelenium.Common;
using FASTSelenium.ImageRecognition;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NextGenDocPrep
{
    [CodedUITest]
    public class IRSampleTest : FASTHelpers
    {
        [TestMethod]
        [Description("Test FAST IIS expandable left navigation frame")]
        [DeploymentItem(@"ImageRecognition\Media\LeftNav\")]
        public void expandable_left_navigation_test()
        {
            try
            {
                /*
                 * Pre-Condition for automation with IR:
                    * Set display resolution as close as posible to 1716 x 1034
                    * Set display color-depth equal to 32 bit
                    * Have an on-screen pixel ruler, visit http://www.arulerforwindows.com/
                    * Have an on-screen capture application like Snipping Tool
                 */
              

                Reports.TestDescription = "Test FAST IIS expandable left navigation frame";

                #region Login to FAST IIS
                Reports.TestStep = "Login to FAST IIS";
                FAST_Login_IIS();
                #endregion

                #region Click on the left arrow "<" to collapse the frame
                Reports.TestStep = "Click on the left arrow \"<\" to collapse the frame";
                FastDriver.FileSiteLeftNavigationPane.IRLeftArrow.DelayOnce(5).FAClick();
                #endregion

                #region Click on the double right arrow ">>" to return to its default size
                Reports.TestStep = "Click on the double right arrow \">>\" to return to its default size";
                FastDriver.FileSiteLeftNavigationPane.IRDoubleRightArrow.DelayOnce(5).FAClick();
                #endregion

                #region Click on the right arrow ">" to expand the frame
                Reports.TestStep = "Click on the right arrow \">\" to expand the frame";
                FastDriver.FileSiteLeftNavigationPane.IRRightArrow.DelayOnce(5).FAClick();
                #endregion

                #region Click on the double left arrow "<<" to return to its default size
                Reports.TestStep = "Click on the double left arrow \"<<\" to return to its default size";
                FastDriver.FileSiteLeftNavigationPane.IRDouleLeftArrow.DelayOnce(5).FAClick();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
