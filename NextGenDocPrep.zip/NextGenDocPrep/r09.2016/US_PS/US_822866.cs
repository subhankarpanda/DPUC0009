﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using System.Windows.Input;
using FASTSelenium.DataObjects;
using System.Diagnostics;

namespace NextGenDocPrep.r09._2016.US_PS
{
    [CodedUITest]
    public class US_822866 : MasterTestClass
    {
        SilverlightSupport FALibSL = new SilverlightSupport();
        [TestMethod, DeploymentItem(@"Common\Support\Map_Tiff.tif")]
        [Description("US#822866-INC2901092-10.5 Release, NextGen Sanity, Map Image DE showing file path")]

        public void TestCase_860282()
        {

            try
            {
                Reports.TestDescription = "Test Case#860282- Verify that Map image DE path field is empty and disable in Phrase View Tab";

                #region Data set up
                String tempName = "MMMM-0000";
                String tempDesc = "Map Image DE";
                String Temptype = "Title Reports";
                String Phrasecode = "FSIM/FSIM";
                #endregion


                #region Methods call
                LoadCopytemplate(tempName, tempDesc, Temptype);
                #endregion

                //Login to FAST
                #region Login Fast
                Reports.TestStep = "Login into the IIS Side.";
                FASTHelpers.FAST_Login_IIS();
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Create file
                CreateFile();
                #endregion

                #region Navigate to document Repository
                Reports.TestStep = "Navigate to document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Add the same template in document repository which was created in ADM
                Reports.TestStep = "Add the same template in document repository which was created in ADM";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem(Temptype);
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempDesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(tempDesc).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion
 
                #region Select title report in document Repository screen and right click for Phrase View/Edit
                Reports.TestStep = "Select title report in document Repository screen and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, tempDesc, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Edit document by adding effective date and click on Save button
                Reports.TestStep = "Edit document by adding effective date and click on Save button";
                if (FastDriver.NextGenDocumentRepository.InfoTabscreen.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText("08/08/2016");
                    FastDriver.NextGenDocumentRepository.TitleReportSave.FAClick();
                    FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                    FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText("08/08/2016");
                    FastDriver.NextGenDocumentRepository.TitleReportSave.FAClick();
                    FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }
                #endregion

                #region Click on Upload button
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();
                #endregion

                #region Browse document
                Reports.TestStep = "Browse document";
                Playback.Wait(3000);
                string filePath = Reports.DEPLOYDIR + @"\Map_Tiff.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);
                #endregion

                #region Save the PDF Document
                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Title: Search Package", "Plat/Survey", null);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Select added title report and right click for Phrase View/Edit
                Reports.TestStep = "Select added title report and right click for Phrase View/Edit";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, tempDesc, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Validate Map image DE in Phrase View/Edit
                Reports.TestStep = "Validate Map image DE in Phrase View/Edit";
                if (FastDriver.NextGenDocumentRepository.InfoTabscreen.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.PhraseViewTab.FADoubleClick();
                    FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                    Support.AreEqual("", FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "MAP image returned by Fast Search", 4, TableAction.GetInputValue).Message.ToString());
                    Support.AreEqual("False", FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "MAP image returned by Fast Search", 4, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsEnabled().ToString());
                 }
                else
                {
                    Support.AreEqual("", FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "MAP image returned by Fast Search", 4, TableAction.GetInputValue).Message.ToString());
                    Support.AreEqual("False", FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "MAP image returned by Fast Search", 4, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsEnabled().ToString());
                 
                }
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #region custom methods
        private void FAST_SU_IIS_Login(bool isSuperUser = true, int? regionId = null)
        {
            #region FAST Login IIS
            Reports.TestStep = "FAST Login IIS";
            var credentials = new Credentials() { UserName = isSuperUser ? AutoConfig.UserNameSU : AutoConfig.UserName, Password = isSuperUser ? AutoConfig.UserPasswordSU : AutoConfig.UserPassword };
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            if (regionId != null)
                FASTHelpers.FAST_OpenRegionOrOffice(regionId ?? 0);
            #endregion
        }
        private void CreateFile()
        {
            Reports.TestStep = "Create a basic file with insurance and buyer/seller information";

            #region Create a  File
            Reports.TestStep = "Create a file";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
            try
            {
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            }
            catch
            {
                Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
            }
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
            Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD | Buyer/Seller Info | Lender";
            FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
            FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
            FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
            FastDriver.QuickFileEntry.SelectState("CA");
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
            FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFirstName");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLastName");
            FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFirstName");
            FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLastName");
            FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("248");
            FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
            FastDriver.BottomFrame.Done();
            FastDriver.FileHomepage.WaitForScreenToLoad();
            String FileNum = FastDriver.FileHomepage.txtFileNumber.FAGetValue();
            #endregion

            #region Setting New Loan Insurance
            Reports.TestStep = "Set New Loan Insurance Information and Loan Number";
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.WaitForScreenToLoad();
            FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("0123456");
            FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("0123");
            FastDriver.BottomFrame.Done();
            #endregion
        }
        private void LoadCopytemplate(string templateName, string templateDesc, string templateType)
        {
            FASTHelpers.FAST_Login_ADM(isSuperUser: false);

            #region Region selection
            Reports.TestStep = "Navigate to QA Sandpointe NextGen region";
            FastDriver.SecuritySelectRegionOffice.Open();
            FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
            #endregion

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion


            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Platt Map");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Platt Map", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (true)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                }
                //Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
            #endregion
        }
        #endregion
        private string NullToString(object Value)
        {
            return Value == null ? "" : Value.ToString();

        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            MasterTestClass.CleanupClass();
        }
    }
}
