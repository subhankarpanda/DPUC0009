﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace NextGenDocPrep.r09._2016.US_PS
{
    [CodedUITest]
    public class US_824038 : FASTHelpers
    {
         SilverlightSupport FALibSL = new SilverlightSupport();
         [TestMethod]
         [Description("815221 - INC2901082 10.5 Release, NextGen Sanity, Data Elements don't auto-populate after Unfinalize")]

         public void TestCase_851584()
         { 
            try
            {

                Reports.TestDescription = "Test Case#820221 - Validate Data Elements populate after Unfinalize Document";

                String Phrasecode = "T/3";
                String TemplateDesc = "Preliminary Report - CA";

                #region Login Fast
                Reports.TestStep = "Login into the IIS Side.";
                FAST_SU_IIS_Login(isSuperUser:true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");

                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD";
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search for Template
                Reports.TestStep = "Search for a document (Preliminary Report - CA) and add to Document Repository screen";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FAClick();
                FastDriver.NextGenDocumentRepository.CaliforniaRegion.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FAClick();
                FastDriver.NextGenDocumentRepository.StateFilter.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(TemplateDesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click).Element.FARightClick();
                //var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 3, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(TemplateDesc).ToString());

                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion

                #region NAvigate to Template Phrase View
                Reports.TestStep = "Select the template and right click for Phrase View Edit option";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, TemplateDesc, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Complete effective date and phrase
                Reports.TestStep = "Complete effective date and enter exceptions phrase( T/3) and save changes";
                if (FastDriver.NextGenDocumentRepository.InfoTabscreen.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText("05/17/2016");
                    FastDriver.NextGenDocumentRepository.TitelReportExceptions.FASetText(Phrasecode);
                    FastDriver.NextGenDocumentRepository.TitelReportExceptionsSourceRegion.FASelectItem("DOCPREP Corporate Region");
                    FastDriver.NextGenDocumentRepository.TitleReportSave.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }
                else 
                {
                    FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                    FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText("05/17/2016");
                    FastDriver.NextGenDocumentRepository.TitelReportExceptions.FASetText(Phrasecode);
                    FastDriver.NextGenDocumentRepository.TitelReportExceptionsSourceRegion.FASelectItem("DOCPREP Corporate Region");
                    FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }
                #endregion

                #region Validate Phrase content is blank
                Reports.TestStep = "Navigate to Phrase View Tab, observe recent added phrase and click on Finalized document option";
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FADoubleClick();
                //Playback.Wait(600);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                Support.AreEqual("", FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "Tax Year", 4, TableAction.GetInputValue).Message.ToString());
                Support.AreEqual("", FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "Tax ID Number (APN/PN)", 4, TableAction.GetInputValue).Message.ToString());
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FADoubleClick();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocumentStatus.FASelectItemBySendingKeys("Finalized");
                Playback.Wait(600);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();      
                #endregion

                #region Complete tax information
                Reports.TestStep = "Navigate to Properties/Tax info screen and enter APN and tax information";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                //Playback.Wait(500);
                //FastDriver.PropertyTaxInfoSupplementalTax.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoSupplementalTax.New.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FASetText("2004-1896");
                FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FASetText("2014-2015");
                FastDriver.PropertyTaxInfoAnnualTax.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnSave.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoAnnualTax.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();
                #endregion

                #region Navigate back to Doc Rep
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Select document and edit for phrase view
                Reports.TestStep = "Select template 'Preliminary Report - CA' and right click for phrase view option";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, TemplateDesc, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Unfinalized the document
                Reports.TestStep = "Click on unfinalized the document";
                //FastDriver.NextGenDocumentRepository.DocumentStatus.FASelectItem("Unfinalized");
                FastDriver.NextGenDocumentRepository.DocumentStatus.FASelectItemBySendingKeys("U");
                #endregion

                #region Provide Unfinalized reason
                Reports.TestStep = "Provide unfinalized reason and click on Done button";
                FastDriver.UnFinalizeDlg.WaitForScreenToLoad();
                FastDriver.UnFinalizeDlg.UnFinalizeReason.FASetText("Test Reason");
                FastDriver.UnFinalizeDlg.Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Validate phrase should display Tax Information
                Reports.TestStep = "Navigate to Phrase View tab and observe added phrase (T/3)";
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                Support.AreEqual("2014-2015", FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "Tax Year", 4, TableAction.GetInputValue).Message.ToString());
                Support.AreEqual("2004-1896", FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "Tax ID Number (APN/PN)", 4, TableAction.GetInputValue).Message.ToString());
                #endregion

                #region Click Done button
                Reports.TestStep = "Click on Done button";
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentsTable);
                #endregion

                #region Validate values remain in phrase
                Reports.TestStep = "Repeat step 10 and navigate to Phrase View tab";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(7, TemplateDesc, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.InfoTabscreen.IsDisplayed())
                {
                    FastDriver.NextGenDocumentRepository.PhraseViewTab.FADoubleClick();
                    FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                    Support.AreEqual("2014-2015", FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "Tax Year", 4, TableAction.GetInputValue).Message.ToString());
                    Support.AreEqual("2004-1896", FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "Tax ID Number (APN/PN)", 4, TableAction.GetInputValue).Message.ToString());
                }
                else
                {
                    Support.AreEqual("2014-2015", FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "Tax Year", 4, TableAction.GetInputValue).Message.ToString());
                    Support.AreEqual("2004-1896", FastDriver.NextGenDocumentRepository.PhraseViewDETableValues(Phrasecode).PerformTableAction(3, "Tax ID Number (APN/PN)", 4, TableAction.GetInputValue).Message.ToString());
                }
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }         
         
         }
         private void FAST_SU_IIS_Login(bool isSuperUser = true, int? regionId = null)
         {
             #region FAST Login IIS
             Reports.TestStep = "FAST Login ADM";
             //var credentials = new Credentials() { UserName = Support.GetRunOption(isSuperUser ? "User_Name2" : "User_Name"), Password = Support.GetRunOption(isSuperUser ? "User_Password2" : "User_Password") };
             var credentials = new Credentials() { UserName = isSuperUser ? AutoConfig.UserNameSU : AutoConfig.UserName, Password = isSuperUser ? AutoConfig.UserPasswordSU : AutoConfig.UserPassword };
             FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

             if (regionId != null)
                 FAST_OpenRegionOrOffice(regionId ?? 0);
             #endregion
         }
        [ClassCleanup]
        public static void ClassCleanup()
        {
            MasterTestClass.CleanupClass();
        }
    }
}
