﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace NextGenDocPrep.r09._2016.US_PS
{
    [CodedUITest]
    public class US_815221 : FASTHelpers
    {
        SilverlightSupport FALibSL = new SilverlightSupport();
        [TestMethod]
        [Description("815221 - PROD - N Issue _Creating Title Report always taking the same title report, even though user selects a different title report")]
        public void TestCase_820221()
        {
            try
            {
                Reports.TestDescription = "Test Case#820221 - Validate title report creates selected one everytime / Create Document";

                #region Login Fast
                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");

                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD";
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Navigate to Template Search
                Reports.TestStep = "Click on Template Search button or tab if is not defaulted";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search a Title Report
                Reports.TestStep = "Search by Title Report type";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                #endregion

                #region Select a Title Report
                Reports.TestStep = "Select one of the title reports";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click);
                var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 3, TableAction.GetText).Message;
                #endregion

                #region  Navigate to Info Tab from selected title report
                Reports.TestStep = "Navigate to Info Tab from selected title report";
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                #endregion

                #region  Select an effective date
                Reports.TestStep = "Select an effective date";
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText("05/17/2016");
                #endregion

                #region Navigate back to template search results
                Reports.TestStep = "Go back to template search results";
                FastDriver.NextGenDocumentRepository.TemplateResultsTab.FAClick();

                #endregion

                #region Right click for Create Document
                Reports.TestStep = "Right click for Create Document";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(templateName).ToString());

                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion

                #region Navigate to Template Search
                Reports.TestStep = "Select Template Search";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search a Title Report
                Reports.TestStep = "Search by Title Report";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                #endregion

                #region Select and create another Title Report
                Reports.TestStep = "Select another random title report and right click for Create Document";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click).Element.FARightClick();
                var tempName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 3, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var rowsTable = FastDriver.NextGenDocumentRepository.DocTableRows.GetRowCount();
                //var rowsTable = FastDriver.NextGenDocumentRepository.DocumentsTable.FAFindElement(ByLocator.Id, "gridDocumentsInnerGrid").GetRowCount();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(tempName).ToString());
                    //Validate first title report exist on table
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(templateName).ToString());
                    //Validate number of rows in table
                    Support.AreEqual("2", rowsTable.ToString());

                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void TestCase_820296()
        {
            try
            {
                Reports.TestDescription = "Test Case#820296 - Validate title report creates selected one everytime / Create/Edit Document";

                #region Login Fast
                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");

                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD";
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Navigate to Template Search
                Reports.TestStep = "Click on Template Search button or tab if is not defaulted";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search a Title Report
                Reports.TestStep = "Search by Title Report type";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                #endregion

                #region Select a Title Report
                Reports.TestStep = "Select one of the title reports";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click);
                var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 3, TableAction.GetText).Message;
                #endregion

                #region  Navigate to Info Tab from selected title report
                Reports.TestStep = "Navigate to Info Tab from selected title report";
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                #endregion

                #region  Select an effective date
                Reports.TestStep = "Select an effective date";
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText("05/17/2016");
                #endregion

                #region Navigate back to template search results
                Reports.TestStep = "Go back to template search results";
                FastDriver.NextGenDocumentRepository.TemplateResultsTab.FAClick();

                #endregion

                #region Right click for Create Document
                Reports.TestStep = "Right click for Create/Edit Document";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateEditDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(templateName).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion

                #region Navigate to Template Search
                Reports.TestStep = "Select Template Search";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search a Title Report
                Reports.TestStep = "Search by Title Report";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                #endregion

                #region Select and create another Title Report
                Reports.TestStep = "Select another random title report and right click for Create/Edit Document";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click).Element.FARightClick();
                var tempName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 3, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.CreateEditDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var rowsTable = FastDriver.NextGenDocumentRepository.DocTableRows.GetRowCount();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(tempName).ToString());
                    //Validate first title report exist on table
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(templateName).ToString());
                    //Validate number of rows in table
                    Support.AreEqual("2", rowsTable.ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void TestCase_820311()
        {
            try
            {
                Reports.TestDescription = "Test Case#820311 - Validate title report creates selected one everytime /   Create/Edit from Info Tab";

                #region Login Fast
                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");

                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD";
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Navigate to Template Search
                Reports.TestStep = "Click on Template Search button or tab if is not defaulted";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search a Title Report
                Reports.TestStep = "Search by Title Report type";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                #endregion

                #region Select a Title Report
                Reports.TestStep = "Select one of the title reports";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click);
                var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 3, TableAction.GetText).Message;
                #endregion

                #region  Navigate to Info Tab from selected title report
                Reports.TestStep = "Navigate to Info Tab from selected title report";
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                #endregion

                #region  Select an effective date
                Reports.TestStep = "Select an effective date";
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText("05/17/2016");
                #endregion

                #region Click on Create/Edit button
                Reports.TestStep = "Click on Create/Edit button";
                FastDriver.NextGenDocumentRepository.DocInfo_CreateEdit.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region
                Reports.TestStep = "Click Done button";
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(templateName).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion

                #region Navigate to Template Search
                Reports.TestStep = "Select Template Search";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search a Title Report
                Reports.TestStep = "Search by Title Report";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                #endregion

                #region Select and create another Title Report
                Reports.TestStep = "Select another random title report and right click for Create/Edit Document";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click).Element.FARightClick();
                var tempName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 3, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.CreateEditDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var rowsTable = FastDriver.NextGenDocumentRepository.DocTableRows.GetRowCount();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(tempName).ToString());
                    //Validate first title report exist on table
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(templateName).ToString());
                    //Validate number of rows in table
                    Support.AreEqual("2", rowsTable.ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void TestCase_820312()
        {
            try
            {
                Reports.TestDescription = "Test Case#820312 - Validate title report creates selected one everytime / Create/Save from Info Tab";

                #region Login Fast
                Reports.TestStep = "Login into the IIS Side.";
                FAST_Login_IIS();
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");

                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD";
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Navigate to Template Search
                Reports.TestStep = "Click on Template Search button or tab if is not defaulted";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search a Title Report
                Reports.TestStep = "Search by Title Report type";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                #endregion

                #region Select a Title Report
                Reports.TestStep = "Select one of the title reports";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click);
                var templateName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 3, TableAction.GetText).Message;
                #endregion

                #region  Navigate to Info Tab from selected title report
                Reports.TestStep = "Navigate to Info Tab from selected title report";
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                #endregion

                #region  Select an effective date
                Reports.TestStep = "Select an effective date";
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText("05/17/2016");
                #endregion

                #region Click on Create/Edit button
                Reports.TestStep = "Click on Create/Save button";
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(templateName).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion

                #region Navigate to Template Search
                Reports.TestStep = "Select Template Search";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search a Title Report
                Reports.TestStep = "Search by Title Report";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
                #endregion

                #region Select and create another Title Report
                Reports.TestStep = "Select another random title report and right click for Create Document";
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click).Element.FARightClick();
                var tempName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 3, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var rowsTable = FastDriver.NextGenDocumentRepository.DocTableRows.GetRowCount();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(tempName).ToString());
                    //Validate first title report exist on table
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTableTemplateExist(templateName).ToString());
                    //Validate number of rows in table
                    Support.AreEqual("2", rowsTable.ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        [ClassCleanup]
        public static void ClassCleanup()
        {
            MasterTestClass.CleanupClass();
        }
    }
}


