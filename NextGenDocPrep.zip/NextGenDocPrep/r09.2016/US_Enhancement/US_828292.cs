﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Windows.Input;

namespace NextGenDocPrep.r09._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_828292 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS"; 
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            

            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Endrosement two phrase ***AUTOMATION DNT***");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Endrosement two phrase ***AUTOMATION DNT***", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        
         

        [TestMethod]
        public void ITR_r09_2016_US_828292_TC_849399_No_1()
        {
            try
            {

                Reports.TestDescription = "User Story: 828292- To verify that the system should allow the user to add keyword value having less than 500 characters in Template Properties screen- ADM";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                string key1 = Support.RandomString("ANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANAN").ToString();
                string char250 = key1 + "#$%,;#$%,;#$%,;#$%,;#$%,;#$%,;#$%,;#$%,;#$%,;#$%,;";


                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");            
                                
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);
               
              
                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Uncheck UC Checkbox";
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.IsSelected().ToString().ToUpper()=="TRUE")
                {
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                }

                Reports.TestStep = "Enter 250 Characters in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(char250);
                Playback.Wait(7000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Validate 250 Characters in Keywords field";
                string keywordvalue250 = FastDriver.NextGenDocumentPreparation.TemplateKeys.FAGetValue();
                Support.AreEqual(char250, keywordvalue250);
                
                Playback.Wait(2000);

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r09_2016_US_828292_TC_849407_No_2()
        {
            try
            {

                Reports.TestDescription = "User Story: 828292- To verify that the system should allow the user to add keyword value having 500 characters in Template Properties screen- ADM";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                string key1 = Support.RandomString("ANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANAN").ToString();
                string char250 = key1 + "#$%,;#$%,;#$%,;#$%,;#$%,;#$%,;#$%,;#$%,;#$%,;#$%,;";
                string char500 = char250 + char250;

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Check UC Checkbox";
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.IsSelected().ToString().ToUpper() == "FALSE")
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                }

                Reports.TestStep = "Enter 500 Characters in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(char500);
                Playback.Wait(7000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Validate 500 Characters in Keywords field";
                string keywordvalue500 = FastDriver.NextGenDocumentPreparation.TemplateKeys.FAGetValue();
                Support.AreEqual(char500, keywordvalue500);

                Playback.Wait(2000);

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r09_2016_US_828292_TC_849408_No_3()
        {
            try
            {

                Reports.TestDescription = "User Story: 828292- To verify that the system should allow the user to add different keyword value having 500 characters in Template Properties screen- ADM";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                string alpha500 = Support.RandomString("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA").ToString();

                string num500 = Support.RandomString("NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN").ToString();

                string sp500 = "<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*<>*%$#:;'/+-=().*&_*";


                string key1 = Support.RandomString("ANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANAN").ToString();
                string all250 = key1 + "<>*%$#:;'/+-=().,&_*<>*%$#:;'/+-=().,&_*<>*%$#:;'/";

                string all500 = all250 + all250;


                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Uncheck UC Checkbox";
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.IsSelected().ToString().ToUpper() == "TRUE")
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                }

                Reports.TestStep = "Enter 500 alphabets in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(alpha500);
                Playback.Wait(7000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Validate 500 alphabets in Keywords field";
                string keywordalphavalue = FastDriver.NextGenDocumentPreparation.TemplateKeys.FAGetValue();
                Support.AreEqual(alpha500, keywordalphavalue);

                Playback.Wait(2000);


                Reports.TestStep = "Enter 500 numeric in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(num500);
                Playback.Wait(7000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Validate 500 numeric in Keywords field";
                string keywordnumvalue = FastDriver.NextGenDocumentPreparation.TemplateKeys.FAGetValue();
                Support.AreEqual(num500, keywordnumvalue);

                Playback.Wait(2000);


                Reports.TestStep = "Enter 500 special characters in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(sp500);
                Playback.Wait(7000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Validate 500 special characters in Keywords field";
                string keywordspvalue = FastDriver.NextGenDocumentPreparation.TemplateKeys.FAGetValue();
                Support.AreEqual(sp500, keywordspvalue);

                Playback.Wait(2000);

                Reports.TestStep = "Enter 500 combine characters in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(all500);
                Playback.Wait(7000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Validate 500 combine characters in Keywords field";
                string keywordallvalue = FastDriver.NextGenDocumentPreparation.TemplateKeys.FAGetValue();
                Support.AreEqual(all500, keywordallvalue);

                Playback.Wait(2000);


                Reports.TestStep = "Enter spaces in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText("                                                  ");
                Playback.Wait(7000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Validate null in Keywords field";
                string keywordnullvalue = FastDriver.NextGenDocumentPreparation.TemplateKeys.FAGetValue();
                Support.AreEqual("", keywordnullvalue);

                Playback.Wait(2000);



            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void ITR_r09_2016_US_828292_TC_849411_No_4()
        {
            try
            {

                Reports.TestDescription = "User Story: 828292- To verify that the system should allow the user to pull the template in file side with keyword value having 500 characters in Template Properties screen- ADM";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

             
                string key1 = Support.RandomString("ANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANANAN").ToString();
                string all250 = key1 + "<>*%$#:;'/+-=().,&_*<>*%$#:;'/+-=().,&_*<>*%$#:;'/";

                string all500 = all250 + all250;


                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Uncheck UC Checkbox";
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.IsSelected().ToString().ToUpper() == "TRUE")
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                }

                Reports.TestStep = "Enter 500 alphabets in Keywords field";
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(all500);
                Playback.Wait(7000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(5000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Validate 500 combine characters in Keywords field";
                string keywordfilevalue = FastDriver.NextGenDocumentPreparation.TemplateKeys.FAGetValue();
                Support.AreEqual(all500, keywordfilevalue);

                Playback.Wait(2000);

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.CreateStandardFile();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Playback.Wait(10000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using keyword search criteria";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.Id, "ddl_FilterTypes_2").FASelectItem("Keywords");
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.keywordsValues.FASetText(all500);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4,tempnameanddesc,4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(tempnameanddesc).ToString());
                

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        





        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }

    
}
