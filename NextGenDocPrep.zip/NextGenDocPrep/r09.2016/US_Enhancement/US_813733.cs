﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;


namespace NextGenDocPrep.r09._2016.US_Enhancement
{
    

    [CodedUITest]
    public class US_813733 : FASTHelpers
    {
        
        [TestMethod]
        public void TC_1024_Favorite_templates_are_selected_by_default_State_shall_be_All_along_with_Source_which_is_All_()
        {
            try
            {

                #region Login Fast
                Reports.TestStep = "Login into the IIS screen.";
                FAST_Login_IIS_SUPER(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search and Favorite Template criteria
                Reports.TestStep = "Perform Select Template Search and Favorite Template criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var Search = FastDriver.NextGenDocumentRepository.MySearch.FAGetSelectedItem();
                if (Search.ToString() != "")
                {
                    FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                }
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Exchange Delayed");
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();                                       
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
                FastDriver.NextGenDocumentRepository.SelectALL.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
                FastDriver.NextGenDocumentRepository.StateFilter.FAClick();
                FastDriver.NextGenDocumentRepository.SourceAndStateAll.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.StateFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Verify checkbox", false, 20);
                
                   
               
               
                #endregion

            }

            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void TC_0996_Display_all_the_Favorite_templates_from_all_the_regions_and_all_the_states()
        {
            try
            {

                #region Login Fast
                Reports.TestStep = "Login into the IIS screen.";
                FAST_Login_IIS_SUPER();
                #endregion

                #region Office and Region selection California
                Reports.TestStep = "Office selection California";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("12971");                
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("1237561");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search and Favorite Template criteria
                Reports.TestStep = "Perform Select Template Search and Favorite Template criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var Search = FastDriver.NextGenDocumentRepository.MySearch.FAGetSelectedItem();
                if (Search.ToString() != "")
                {
                    FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                }
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();          
                FastDriver.NextGenDocumentRepository.FavoriteOption.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable("Endorsement/Guarantee").ToString());
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Verify Favorite template ", false, 35);                             
                #endregion

                #region Office  and Region Selection Nevada North America Title California Division
                Reports.TestStep = "Office  and Region Selection Nevada North America Title California Division";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("12970");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("1369184");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search and Favorite Template criteria
                Reports.TestStep = "Perform Select Template Search and Favorite Template criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var Search1 = FastDriver.NextGenDocumentRepository.MySearch.FAGetSelectedItem();
                if (Search1.ToString() != "")
                {
                    FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                }
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Form");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FavoriteOption.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Form");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable("Form").ToString());
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Verify Favorite template ", false, 35); 
                #endregion              

                #region Office Regeion Selection DOCPREP Corporate Region
                Reports.TestStep = "Office Regeion Selection DOCPREP Corporate Region";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("197");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("1235");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search and Favorite Template criteria
                Reports.TestStep = "Perform Select Template Search and Favorite Template criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var Search2 = FastDriver.NextGenDocumentRepository.MySearch.FAGetSelectedItem();
                if (Search2.ToString() != "")
                {
                    FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                }
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FavoriteOption.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable("Title Reports").ToString());
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Verify Favorite template ", false, 35); 
                #endregion              

                #region Office and Region selection QA Sanpointe Next Gen 
                Reports.TestStep = "Office and Region selection QA Sanpointe Next Gen ";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search and Favorite Template criteria
                Reports.TestStep = "Perform Select Template Search and Favorite Template criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Ltr/Transmittal");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FavoriteOption.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Ltr/Transmittal");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable("Escrow Ltr/Transmittal").ToString());
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Verify Favorite template ", false, 35); 
                #endregion

                #region Verify All Favorites Templates Created in All Others Regions
                Reports.TestStep = "Verify All Favorites Templates Created in All Others Regions";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString()); 
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please one Moment", false, 20);
                #endregion




            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void TC_7590_To_Verify_Different_Combination_of_Templates_Search_Criteria_Dropdown_and_Switching_between_tabs_()
        {
            try
            {
                
                #region Login Fast
                Reports.TestStep = "Login into the IIS screen.";
                FAST_Login_IIS_SUPER();
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Click New Search Button Recently Used Template option criteria
                Reports.TestStep = "Perform Click New Search Button Recently Used Template option criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var Search = FastDriver.NextGenDocumentRepository.MySearch.FAGetSelectedItem();
                if (Search.ToString() != "")
                {
                    FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                }
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Recently Used Templates");
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString());
                FastDriver.NextGenDocumentRepository.SearchTemplateCriteriaButton.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateNewSearch.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Perform Click New Search Button Filtered Templates option criteria
                Reports.TestStep = "Perform Click New Search Button Filtered Templates option criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString());
                FastDriver.NextGenDocumentRepository.SearchTemplateCriteriaButton.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateNewSearch.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Perform Click New Search Button Favorite Templates option criteria
                Reports.TestStep = "Perform Click New Search Button Favorite Templates option criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Favorite Templates");
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString());
                FastDriver.NextGenDocumentRepository.SearchTemplateCriteriaButton.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateNewSearch.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Perform Click New Search Button All Templates option criteria
                Reports.TestStep = "Perform Click New Search Button All Templates option criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString());
                FastDriver.NextGenDocumentRepository.SearchTemplateCriteriaButton.FAClick();
                FastDriver.NextGenDocumentRepository.TemplateNewSearch.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Perform Switching Between Template Search and File Document. 
                Reports.TestStep = "Perform Switching Between Template Search and File Document.";
                FastDriver.NextGenDocumentRepository.FileDocumentsTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                #endregion





            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }



        [TestMethod]
        public void TC_8335Verify_System_should_prevent_Navigating_Template_Filtering_back_to_Saved_Primary_Filtering_Criteria_after_search()
        {
            try
            {
                #region Login Fast
                Reports.TestStep = "Login into the IIS screen.";
                FAST_Login_IIS_SUPER();
                #endregion

                #region Office and Region selection QA Sanpointe Next Gen
                Reports.TestStep = "Office and Region selection QA Sanpointe Next Gen ";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify All Favorites Templates Created in All Others Regions
                Reports.TestStep = "Verify All Favorites Templates Created in All Others Regions";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var Search = FastDriver.NextGenDocumentRepository.MySearch.FAGetSelectedItem();
                if (Search.ToString() != "")
                {
                    FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                }

                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Favorite Templates");
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString());  
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please one Moment", false, 10);
                #endregion

                #region Save Criteria Filter in My Search 
                Reports.TestStep = "Verify All Favorites Templates Created in All Others Regions";
                FastDriver.NextGenDocumentRepository.MySearchSaveButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.EnterNewFilterName.FAClick();
                FastDriver.NextGenDocumentRepository.EnterNewFilterName.FASendKeys("Favorites Search");                
                FastDriver.NextGenDocumentRepository.SaveButonMySearch.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.TemplateSearchTab);
                FastDriver.NextGenDocumentRepository.TemplateSearchTab.FAClick(); 
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.MySearch.FAClick();
                FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("Favorites Search");
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
            
        }


        [TestMethod]
        public void TC_8794_To_Verify_State_and_Source_Filter_displaying_a_warning_message_if_not_is_selected()
        {
            try
            {
                #region Login Fast
                Reports.TestStep = "Login into the IIS screen.";
                FAST_Login_IIS_SUPER();
                #endregion

                #region Office and Region selection QA Sanpointe Next Gen
                Reports.TestStep = "Office and Region selection QA Sanpointe Next Gen ";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Click Source unchecked filter option
                Reports.TestStep = "Perform Click Source unchecked filter option";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var Search = FastDriver.NextGenDocumentRepository.MySearch.FAGetSelectedItem();
                if (Search.ToString() != "")
                {
                    FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                }

                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Favorite Templates");
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString());  
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SelectALL.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Search.FAClick();                             
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.ValuesRegeion.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SelectALL.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                #endregion

                #region Perform Click State unchecked filter option
                Reports.TestStep = "Perform Click State unchecked filter option";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.StateFilter.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.StateFilter.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();          
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 20);              
                #endregion

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void TC_6651_To_Verify_State_All_option_display_all_template_any_region_into_Favorites_Template()
        {
            try
            {
                

                Reports.TestDescription = "";
                string RandomtemplateName = Support.RandomString("AAAAAAA");
                String tempDesc = Support.RandomString("AAANANANANA");
                String Temptype = "Title Reports";
                String Phrasecode = "TP13/27";

                LoadOrCreateTemp(RandomtemplateName, tempDesc, Temptype);
                AddPhrase(tempDesc, Temptype, Phrasecode);               
               
                #region Login Fast
                Reports.TestStep = "Login into the IIS screen.";
                FAST_Login_IIS_SUPER();
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Select Template Search and Favorite Template criteria
                Reports.TestStep = "Perform Select Template Search and Favorite Template criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 50);
                var Search = FastDriver.NextGenDocumentRepository.MySearch.FAGetSelectedItem();
                if (Search.ToString() != "")
                {
                    FastDriver.NextGenDocumentRepository.MySearch.FASelectItem(""); 
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 50);
                }
                
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem(Temptype);
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempDesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 50);
                if(FastDriver.WebDriver.FAFindElement(ByLocator.Id, "img_afav").IsVisible() == true);
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, "img_afav").FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", false, 50);
                Support.AreEqual("True", FastDriver.WebDriver.FAFindElement(ByLocator.Id, "img_rfav").IsVisible().ToString());                           
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please one Moment", false, 20);
              
                Reports.TestStep = "Verify templaet should be visible in the search result for favorite template filter with specific template type";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempDesc, "Template Name", TableAction.Click);
                #endregion

                #region Verify All Favorites Templates Created in All Others Regions
                Reports.TestStep = "Verify All Favorites Templates Created in All Others Regions";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Favorite Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please one Moment", false, 20);
                Reports.TestStep = "Verify templaet should be visible in the search result for favorite template filter with All";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempDesc, "Template Name", TableAction.Click);
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }



        private void LoadOrCreateTemp(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Title Reports";

            FAST_Login_ADM(isSuperUser: false);

            #region Region selection
            Reports.TestStep = "Navigate to QA Sandpointe NG Region";
            FastDriver.SecuritySelectRegionOffice.Open();
            FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
            #endregion

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Tatli Reports";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            #region Create Template if not created
            Reports.TestStep = "Create Template if not created";
            if (!templateExists)
            {
                Reports.TestStep = "Title Reports " + templateDesc;
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                if (FastDriver.NextGenDocumentPreparation.GroupFilter1.IsDisplayed())
                {
                    Support.AreEqual("AZ", FastDriver.NextGenDocumentPreparation.ValidateState.FAGetText());
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (true)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                    FastDriver.NextGenDocumentPreparation.StateAddRemove.FAClick();
                    FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                    FastDriver.StateSelectionDlg.Clear.FAClick();
                    FastDriver.StateSelectionDlg.table.PerformTableAction("State", "AZ", "Select", TableAction.On);
                    FastDriver.StateSelectionDlg.Select.FAClick();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                    FastDriver.NextGenDocumentPreparation.ServiceTypeSelectAll.FAClick();
                    FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.FAClick();
                    FastDriver.NextGenDocumentPreparation.OwningOfcSelectAll.FAClick();
                    FastDriver.NextGenDocumentPreparation.ProductTypeSelectAll.FAClick();
                    FastDriver.NextGenDocumentPreparation.PropertyTypeSelectAll.FAClick();
                    FastDriver.NextGenDocumentPreparation.TransactionTypeSelectAll.FAClick();
                    FastDriver.NextGenDocumentPreparation.BusinessSegmentSelectAll.FAClick();
                    FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.FAClick();
                    FastDriver.NextGenDocumentPreparation.SearchTypeSelectAll.FAClick();
                    FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Save);
                }

                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }


            #endregion
        }

        public void AddPhrase(String TempDesc, String Temptype, String Phrasecode)
        {

            FAST_Login_ADM(isSuperUser: false);

            #region Region selection
            Reports.TestStep = "Navigate to QA Sandpointe NG Region";
            FastDriver.SecuritySelectRegionOffice.Open();
            FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
            #endregion

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Navigate to NextGen Document Preparation/Templates Search
            Reports.TestStep = "Navigate to NextGen Document Preparation/Templates Search";
            FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            #endregion

            #region Search Title Reports Template and add phrases to it
            Reports.TestStep = "Search Title Reports Template and add phrases to it";
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(Temptype);
            FastDriver.NextGenDocumentPreparation.TemplateSearchRegions.FAClick();
            FastDriver.NextGenDocumentPreparation.AllRegions.FASetCheckbox(true);
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(TempDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
            if (FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.IsDisplayed())
            {

                //Select Template for Edit
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description",TempDesc,"Description",TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                var PhraseTable = FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.GetAttribute("textContent");
                var PhraseExists = PhraseTable.Contains(Phrasecode);

                if (!PhraseExists)
                {
                    //Click for Insert Phrase menu from Phrases sub-tab
                    Reports.TestStep = "Insert Phrases Option in Menu Context ";
                    FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);

                    //Insert Phrase which contains Policy Issue Date from Corporate
                    Reports.TestStep = "Phrases Selection Dialogue";
                    FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                    FastDriver.PhraseSelectDlg.Source.FASelectItem("Corporate");
                    FastDriver.PhraseSelectDlg.PhraseName.FASetText(Phrasecode);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();

                    //Save and Remove Under Construction Checkbox
                    Reports.TestStep = "Click Save and Under Construction ";
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                    FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                }
                else
                {
                    //Save and Remove Under Construction Checkbox
                    Reports.TestStep = "Click Save and Under Construction ";
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                }
            }
            else
            {
                Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
            }
            #endregion

        }




        private void FAST_Login_IIS_SUPER(bool isSuperUser = true, int? regionId = null)
        {

            #region FAST_Login_IIS_SUP
            Reports.TestStep = "FAST_Login_IIS_SUP";

            var credentials = new Credentials() { UserName = isSuperUser ? AutoConfig.UserNameSU : AutoConfig.UserName, Password = isSuperUser ? AutoConfig.UserPasswordSU : AutoConfig.UserPassword };

            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            if (regionId != null)
                FAST_OpenRegionOrOffice(regionId ?? 0);

            #endregion

        }



             [ClassCleanup]
        public static void ClassCleanup()
        {
            FASTHelpers.CleanupClass();
        }       
            
        
    }
}
