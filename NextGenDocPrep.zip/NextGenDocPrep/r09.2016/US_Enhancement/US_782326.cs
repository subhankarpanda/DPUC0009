﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;

namespace NextGenDocPrep.r09._2016.US_Enhancement
{
    [CodedUITest]
    public class US_782326 : FASTHelpers
    {
        #region Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }
        #endregion

        [TestMethod]
        public void TC_0021_To_Verify_visible_indicator_in_NextGen_Template_properties_tab_screens_if_template_manually_created()
        {
            try
            {

                string RandomtemplateName = Support.RandomString("AAAAAAA");
                string RandomDescription = Support.RandomString("AAAAAAA");

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region Navigate to NextGen Document Preparation/Templates Search/ Create a Template
                Reports.TestStep = " Navigate to NextGen Document Preparation/Templates Search/ Create a Template";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                var templateExists = templateTable.Contains(RandomDescription);
                if (!templateExists)
                {
                    FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(RandomDescription);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Form");
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    Reports.StatusUpdate("Template: " + RandomDescription + " just created", true);
                    
                }
                else
                {
                    Reports.StatusUpdate("Template: " + RandomDescription + " already exist", true);
                }
                #endregion

                #region Search Template created Manually
                Reports.TestStep = "Search Template created Manually";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Form");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASendKeys(RandomDescription);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please",false);
                FastDriver.NextGenDocumentPreparation.ManuallyCreatedIcon.Highlight();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.ManuallyCreatedIcon.IsDisplayed().ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false,5);
                #endregion



            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
            
        }



        [TestMethod]
        public void TC_0849_To_Verify_visible_indicator_in_NextGen_Phrases_properties_tab_screens_if_Phrases_manually_created()
        {
            try
            {

                string RandomPhrasesName = Support.RandomString("AAAA");
                string RandomDescription = Support.RandomString("AAAAA");
                string RamdomPhrasedName2 = Support.RandomString("AAAAA");
                string RamdomDescript2 = Support.RandomString("AAAAA");

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region Navigate to NextGen Document Preparation
                Reports.TestStep = "Navigate to NextGen Document Preparation";              
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.PhrasesTab);
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClick();
                Reports.TestStep = "Verify if exist a phrases ";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhraseSearch);
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                FastDriver.NextGenDocumentPreparation.ExcrowFilterPhrase.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhraseSearch);
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseDescription.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseDescription.FASendKeys(RandomDescription);
                FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                var PhraseTable = FastDriver.NextGenDocumentPreparation.PhrasesResultTable.GetAttribute("textContent");
                var Phrasesexist = PhraseTable.Contains(RandomDescription);
                if (!Phrasesexist)
                {
                    
                    Reports.TestStep = "If Phrase not exist, Create new phrase";
                    FastDriver.NextGenDocumentPreparation.CreateNewPhrases.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    FastDriver.NextGenDocumentPreparation.GroupName.FASetText(RandomPhrasesName);
                    FastDriver.NextGenDocumentPreparation.Description.FASetText(RandomDescription);
                    FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Escrow Phrase[ESCROW]");
                    FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                    FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                    FastDriver.NextGenDocumentPreparation.AddNewPhrase.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad(); 
                    FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(RamdomPhrasedName2);
                    FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(RamdomDescript2);
                    FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                    FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                    Reports.StatusUpdate("Template: " + RandomDescription + " just created", true);

                }
                else
                {
                    Reports.StatusUpdate("Template: " + RandomDescription + " already exist", true);
                }
                #endregion

                #region Search Phrases created Manually
                Reports.TestStep = "Search Template created Manually";
                FastDriver.NextGenDocumentPreparation.PhraseSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.SelectAllPrase.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                if (FastDriver.NextGenDocumentPreparation.PhrasesResultTable.IsDisplayed())
                {
                    Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.PhrasesResultTable.StringExistOnTable(RandomDescription).ToString());
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Verify Favorite Phrases ", false, 35);                
                #endregion

                #region Verify Manually Icom 
                Reports.TestStep = "Verify Manually Icon";
                FastDriver.NextGenDocumentPreparation.PhrasesResultTable.PerformTableAction(1, 1, TableAction.Click, "Escrow Phrase[ESCROW]").Element.FADoubleClick();                        
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.PhrasesTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.EditPhrasetable.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.ManuallyIconPhrase.Highlight();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.ManuallyIconPhrase.IsDisplayed().ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 5);
                #endregion



            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void TC_0872_To_Verify_no_indicator_is_visible_in_NextGen_Template_properties_tab_screens_if_template_is_migrated()
        {
            try
            {
                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion                                           

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                #endregion

                #region Search any Template in ADM
                Reports.TestStep = "Search any Template in ADM";
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASendKeys("1413 Test Template");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentPreparation.ManuallyCreatedIcon.IsDisplayed().ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false,5);
                #endregion





            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }



        [TestMethod]
        public void TC_0889_To_Verify_not_visible_indicator_in_NextGen_Phrases_properties_tab_screens_if_Phrases_is_migrated()
        {
            try
            {
                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region Navigate to NextGen Document Preparation/Templates Search
                Reports.TestStep = "Navigate to NextGen Document Preparation/Templates Search";
                FastDriver.NextGenDocumentPreparation.Open();
              
                #endregion

                #region Verify  no visible indicator in Next Gen Phrases 
                Reports.TestStep = "Verify  no visible indicator in Next Gen Phrases ";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                FastDriver.NextGenDocumentPreparation.SelectAllPrase.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseDescription.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseDescription.FASendKeys("1081 phrase");
                FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhrasesResultTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.EditPhrasetable.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentPreparation.ManuallyCreatedIconPhrase.IsDisplayed().ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false,5);
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void TC_3956_To_Verify_copy_Template_is_visible_Icon_is_displayed()
        {
            try
            {
                string RandomtemplateName = "SD City ";
                string RandomDescription = "CA State";
             

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region Navigate to NextGen Document Preparation/Templates Search/ Create a Template
                Reports.TestStep = " Navigate to NextGen Document Preparation/Templates Search/ Create a Template";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                var templateExists = templateTable.Contains(RandomDescription);
                if (!templateExists)
                {
                    FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(RandomDescription);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Form");
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    Reports.StatusUpdate("Template: " + RandomDescription + " just created", true);

                }
                else
                {
                    Reports.StatusUpdate("Template: " + RandomDescription + " already exist", true);
                }
                #endregion

                #region Search New Template verify Manually Icon
                Reports.TestStep = "Search New Template verify Manually Icon";          
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");                
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplateRes.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(FAKeys.Backspace);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASendKeys(RandomtemplateName);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(FAKeys.Backspace);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);          
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASendKeys(RandomDescription);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearchTab);               
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();              
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");                             
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.FADoubleClick();             
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.ManuallyCreatedIcon.Highlight();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.ManuallyCreatedIcon.IsDisplayed().ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 5);
                #endregion

               
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void TC_3964_To_Verify_copy_Phrases_is_visible_Icon_is_displayed()
        {
            try
            {
                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion


                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region Navigate to NextGen Document Preparation/Templates Search
                Reports.TestStep = "Navigate to NextGen Document Preparation/Templates Search";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                #endregion

                #region Copy Phrase 
                Reports.TestStep = "Copy Phrase ";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.CopyMovePhraseTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.FirstFormGroup.FASelectItem("OLDGRT");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.CopyMoveFirstFormPhraseCodeSelect.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please",false);
                FastDriver.NextGenDocumentPreparation.CopyMoveSelectAPhrase.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.CopyMoveSelectAPhrase_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.CopyMoveFirsToGroup.FASelectItem("PG");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseName.FAClick();
                FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseName.FASendKeys("PG");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseDescrp.FAClick();
                FastDriver.NextGenDocumentPreparation.CopyMoveFirsToPhraseDescrp.FASendKeys("PG");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.CopyPhrasesBtn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.CopyPhrasesValidatuionErrorDiv.PerformTableAction(2, 1, TableAction.Click, "").Element.FAClick();
                if (FastDriver.NextGenDocumentPreparation.CopyPhrasesValidatuionErrorDiv.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentPreparation.CopyPhrasesValidatuionErrorDiv.StringExistOnTable("No 1:Success").ToString());
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false,10);
                #endregion

                #region Verify Manually icon
                Reports.TestStep = " Verify Manually icon ";
                FastDriver.NextGenDocumentPreparation.PhraseSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                FastDriver.NextGenDocumentPreparation.SelectAllPrase.FAClick();
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();               
                FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhrasesResultTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.EditPhrasetable.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.ManuallyCreatedIconPhrase.IsDisplayed().ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false, 5);               
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }



        [TestMethod]
        public void TC_5534_To_Verify_in_Template_has_Phrases_Tab_Right_Click_Properties_menu_context_option()
        {
            try
            {

                string RandomtemplateName = Support.RandomString("AAAAAAA");
                string RandomDescription = Support.RandomString("AAAAAAA");

                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
                #endregion

                #region Navigate to NextGen Document Preparation
                Reports.TestStep = "Navigate to NextGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();               
                #endregion                

                #region Navigate to NextGen Document Preparation/Templates Search/ Create a Template
                Reports.TestStep = " Navigate to NextGen Document Preparation/Templates Search/ Create a Template";
                FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(RandomDescription);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                var templateExists = templateTable.Contains(RandomDescription);
                if (!templateExists)
                {
                    FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(RandomtemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(RandomDescription);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Form");
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();                  
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                    Reports.StatusUpdate("Template: " + RandomDescription + " just created", true);

                }
                else
                {
                    Reports.StatusUpdate("Template: " + RandomDescription + " already exist", true);
                }
                
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please.....", false);
                #endregion

                #region Insert Phrases Option in Menu Context
                Reports.TestStep = "Insert Phrases Option in Menu Context ";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                #endregion                 

                #region Phrases Selection Dialogue and Phrase Type and click Save
                Reports.TestStep = "Phrases Selection Dialogue and Phrase Type and click Save  ";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Escrow Phrase");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("CVRFL[CVRF]");
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTableName.FADoubleClick();             
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab);
                #endregion

                #region Search a Phrase and verify Manually icon 
                Reports.TestStep = "Search a Phrase and verify Manually icon";
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FADoubleClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.ManuallyCreatedIconPhrase.IsDisplayed().ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 1, TableAction.Click, "").Element.FARightClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                FastDriver.NextGenDocumentPreparation.PropertiesphraseContext.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false);
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.ManuallyCreatedIconPhrase.IsDisplayed().ToString());
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please ", false,10);
                #endregion



            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }






        [ClassCleanup]
        public static void ClassCleanup()
        {
            FASTHelpers.CleanupClass();
        }       

    }
}
