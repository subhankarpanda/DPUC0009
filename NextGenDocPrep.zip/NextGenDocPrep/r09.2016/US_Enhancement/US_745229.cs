﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;

namespace NextGenDocPrep.r09._2016.US_Enhancement
{
    [CodedUITest]
  public  class US_745229 : FASTHelpers
    {

        [TestMethod]
        public void TC_8868_State_shall_be_All_along_with_Source_which_is_All()
        {
            try
            {
                
                #region Login Fast
                Reports.TestStep = "Login into the IIS screen.";
                FAST_Login_IIS();
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion
                
                #region Perform Click  State Filter Option Filtered Templates option criteria
                Reports.TestStep = "Perform Click  State Filter Option Filtered Templates option criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();               
                var Search = FastDriver.NextGenDocumentRepository.MySearch.FAGetSelectedItem();
                if (Search.ToString() != "")
                {
                    FastDriver.NextGenDocumentRepository.MySearch.FASelectItem(""); 
                }
                FastDriver.NextGenDocumentRepository.Keywords_filter_0.FAClick();
                FastDriver.NextGenDocumentRepository.Keywords_filter_0.FASelectItem("State");
                FastDriver.NextGenDocumentRepository.StateFilter.FAClick();
                try
                {
                    FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                }
                catch 
                {

                    Reports.StatusUpdate(" Unable to click on state All option", true);
                }       
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 20);
                #endregion

                #region Perform Click State Filter Option Recently Used Template option criteria
                Reports.TestStep = "Perform Click State Filter Option Recently Used Template option criteria";                           
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Recently Used Templates");
                var type = FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem();
                if (type.ToString() != "All")
                {
                    FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                }
                FastDriver.NextGenDocumentRepository.StateFilter.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 30);              
                #endregion               

                #region Perform Click New Search Button Favorite Templates option criteria
                Reports.TestStep = "Perform Click New Search Button Favorite Templates option criteria";               
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Favorite Templates");
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString());  
                FastDriver.NextGenDocumentRepository.StateFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                FastDriver.NextGenDocumentRepository.Search.FAClick();                
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 20);
                #endregion

                #region Perform Click New Search Button All Templates option criteria
                Reports.TestStep = "Perform Click New Search Button All Templates option criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString());  
                FastDriver.NextGenDocumentRepository.StateFilter.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment Please", false, 10);              
                #endregion

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            
            }
            
        }
    

        [TestMethod]
        public void TC_8870Search_for_All_templates_by_Source_region_corporate_and_all_other_region_and_All_states()
        {
            try
            {
                #region Login Fast
                Reports.TestStep = "Login into the IIS screen.";
                FAST_Login_IIS();
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Perform Click New Search Button All Templates option criteria
                Reports.TestStep = "Perform Click New Search Button All Templates option criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please",false, 50);                
                var Search = FastDriver.NextGenDocumentRepository.MySearch.FAGetSelectedItem();
                if (Search.ToString() != "")
                {
                    FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                }
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString());
                FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Corporate.Highlight();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Region.Highlight();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SourcesFilter_Values.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                FastDriver.NextGenDocumentRepository.Search.FAClick();          
                #endregion

            }
            catch (Exception ex)
            {
                
                 FailTest(ex.Message);
            }
            
        }

        [TestMethod]
        public void TC_8873_To_Verify_State_Filter_displaying_a_warning_message_if_not_is_selected()
        {
            try
            {

                #region Login Fast
                Reports.TestStep = "Login into the IIS screen.";
                FAST_Login_IIS();
                #endregion

                #region Office and Region selection QA Sanpointe Next Gen
                Reports.TestStep = "Office and Region selection QA Sanpointe Next Gen ";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search TAB or Button
                Reports.TestStep = "Click on Template Search TAB or Button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 50);
                var Search = FastDriver.NextGenDocumentRepository.MySearch.FAGetSelectedItem();
                if (Search.ToString() != "")
                {
                    FastDriver.NextGenDocumentRepository.MySearch.FASelectItem(""); 
                }
                #endregion

                #region Select  All Templates
                Reports.TestStep = "Select  All Templates";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString());   
                #endregion

                #region Remove state from state filter and click on Search button
                Reports.TestStep = "Remove state from state filter and click on Search button";
                FastDriver.NextGenDocumentRepository.StateFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);              
                try
                {
                    FastDriver.NextGenDocumentRepository.StateValue_CA_1.FAClick();
                }
                catch 
                {
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false,2);
                    Reports.StatusUpdate(" Unable to click on state All option", true);
                }       
                //Handeling Warning message
                FastDriver.NextGenDocumentRepository.StateFilter.FAClick();
                Support.AreEqual("Please select ...", FastDriver.NextGenDocumentRepository.PleaseSelect.FAGetText().ToString());
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                //FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                Support.AreEqual("Please select a state.", FastDriver.WebDriver.HandleDialogMessage(true, true, 10).ToString());               
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 20);
                #endregion                     

                #region Change to filtered  templates criteria
                Reports.TestStep = "Change to filtered  templates criteria  ";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.TemplateSearchTab);              
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Favorite Templates");
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString());
                #endregion

                #region Add state option criteria empty
                Reports.TestStep = "Add state option criteria empty ";
                FastDriver.NextGenDocumentRepository.StateFilter.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_CA_1.FASetCheckbox(false);
                FastDriver.NextGenDocumentRepository.StateValue_All.FASetCheckbox(false);
                FastDriver.NextGenDocumentRepository.StateFilter.FAClick();
                //Fast System isn't put words"Please select ..." for a while this field is empty. bug#935553
                //Support.AreEqual("", FastDriver.NextGenDocumentRepository.PleaseSelect.FAGetText().ToString());
                #endregion

                #region Click on Search button
                Reports.TestStep = "Click on Search button";
                //Handeling Warning message
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Support.AreEqual("Please select a state.", FastDriver.WebDriver.HandleDialogMessage(true, true, 10).ToString());     
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 20);
                #endregion

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
            
        }

        [TestMethod]
        public void TC_8884_Verify_System_should_prevent_Navigating_Template_Filtering_back_to_Saved_Primary_Filtering_Criteria_after_search()
        {
            try
            {

                //PreCondition Create A bew Filter My Search 
                
                #region Login Fast
                Reports.TestStep = "Login into the IIS screen.";
                FAST_Login_IIS();
                #endregion

                #region Office and Region selection QA Sanpointe Next Gen
                Reports.TestStep = "Office and Region selection QA Sanpointe Next Gen ";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search TAB or Button 
                Reports.TestStep = "Click on Template Search TAB or Button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 50);
                #endregion

                #region Verify My search has a filter created
                Reports.TestStep = "Verify My search has a filter created";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Recently Used Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please one Moment", false, 10);
                FastDriver.NextGenDocumentRepository.MySearchSaveButton.FAClick();
                FastDriver.NextGenDocumentRepository.EnterNewFilterName.FAClick();
                FastDriver.NextGenDocumentRepository.EnterNewFilterName.FASendKeys("Favorites Search");
                FastDriver.NextGenDocumentRepository.FavoriteSearchPrimaryChk.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.SaveButonMySearch.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.TemplateSearchTab);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please one Moment", false, 10);
                #endregion

               // Verify funcionality 

                #region Login Fast
                Reports.TestStep = "Login into the IIS screen.";
                FAST_Login_IIS();
                #endregion

                #region Office and Region selection QA Sanpointe Next Gen
                Reports.TestStep = "Office and Region selection QA Sanpointe Next Gen ";
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("12839");
                #endregion

                #region Create a  File
                Reports.TestStep = "Create a basic file";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
                FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
                FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
                FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
                FastDriver.QuickFileEntry.SelectState("CA");
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                #region Navigate to NextGen Document Repository
                Reports.TestStep = "Navigate to NextGen Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search TAB or Button
                Reports.TestStep = "Click on Template Search TAB or Button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 50);
                #endregion


                #region Now modify the existing filter criteria and click on search
                Reports.TestStep = "Now modify the existing filter criteria and click on search";
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("All Templates");
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString());  
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please one Moment", false, 10);
                #endregion

                #region Verify system should not retain primary filter search criteria
                Reports.TestStep = "Verify system should not retain primary filter search criteria "; 
                Support.AreEqual("[Modified, Not Saved]",FastDriver.NextGenDocumentRepository.Modified_Not_Saved.FAGetText().ToString());
                Support.AreEqual("All", FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FAGetSelectedItem().ToString());                
                #endregion

            }
            catch (Exception ex)
            {
                
                 FailTest(ex.Message);
            }
                    
            
        }

    
      
             [ClassCleanup]
        public static void ClassCleanup()
        {
            FASTHelpers.CleanupClass();
        }       
            
        
    }
}


