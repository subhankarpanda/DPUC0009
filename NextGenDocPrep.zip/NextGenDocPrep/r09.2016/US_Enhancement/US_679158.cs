﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.ImageRecognition;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Input;

namespace NextGenDocPrep.r09._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_679158 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LA.COM";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }
      

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);
            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }             
              

        #region TestCase-844185 Verify "WINTRACK" Delivery option in the document view

        [TestMethod]
        public void TestCase_844185()
        {
             Reports.TestDescription = "Verify \"WINTRACK\" Delivery option in the document view";

             try
             {
                 string secondexternalnumber = Support.RandomString("ANANANANAN");

                 Reports.TestStep = "Login to FAST Application";
                 FAST_Login_IIS(regionId: regionId);
                 FAST_OpenRegionOrOffice(officeId);

                 Reports.TestStep = "Create a basic fine using Quick file entry";
                 Reports.TestStep = "Create File using FAST GUI.";
                 FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                 try
                 {
                     FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                 }
                 catch
                 {
                     Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                 }

                 FastDriver.QuickFileEntry.CreateStandardFile();
                
                 Reports.TestStep = "Naviagte to Document Repository";
                 FastDriver.NextGenDocumentRepository.Open();
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                 Reports.TestStep = "Click on Template Search button";
                 FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();

                 FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                 Reports.TestStep = "Search for a template using template search criteria and create as a document";
                 FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                 FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                 FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Preliminary Report-TEST");
                 FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                 FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                 FastDriver.NextGenDocumentRepository.Search.FAClick();
                 FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "Preliminary Report-TEST", "Description", TableAction.Click).Element.FARightClick();
                 FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created...", true, 10);
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                 Reports.TestStep = "Verify created document in File documents search results screen";
                 var docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Preliminary Report-TEST", "Name", TableAction.GetText).Message;
                 Support.AreEqual(docName, "Preliminary Report-TEST", "Document exists on the Search Result Table");

                 Reports.TestStep = "Navigate to Document view screen";
                 FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Preliminary Report-TEST", "Name", TableAction.Click).Element.FARightClick();
                 FastDriver.NextGenDocumentRepository.SearchResult_Details.FASelectContextMenuItem();
                 FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);
                 FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DetailsTable);

                 Reports.TestStep = "Get the file ID ";
                 int fileId = Convert.ToInt32(FastDriver.NextGenDocumentRepository.DetailsTable.PerformTableAction(10, 2, TableAction.GetText).Message);
                 FastDriver.NextGenDocumentRepository.DocDetails_OK.FAClick();


                 Reports.TestStep = "Update Second order source as WINTRACK for the FAST order";
                 var updateSecondOrderSourceRequest = RequestFactory.GetUpdateSecondOrderSourceRequest(fileId: fileId, appID: 10, secondExternalFileNum: secondexternalnumber); //WINTRACK
                 var updateSecondOrderSourceResponse = FileService.UpdateSecondOrderSource(updateSecondOrderSourceRequest);
                 Reports.StatusUpdate("UpdateSecondOrderSource operation response: " + updateSecondOrderSourceResponse.StatusDescription, updateSecondOrderSourceResponse.Status == 1);


                 FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Preliminary Report-TEST", "Name", TableAction.Click).Element.FARightClick();
                 FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();

                 Reports.TestStep = "Verify WINTRACK delivery in Document Editor screen";
                 FastDriver.DocumentEditor.WaitForScreenToLoad();

                 // TO DO : Verification in editor is pending
             }
             catch (Exception ex)
             {
                 FailTest(ex.Message);
             }

        }

        #endregion

        #region TestCase-844186 Verify "LA.COM" Delivery option in the document view

        [TestMethod]
        public void TestCase_844186()
        {
            Reports.TestDescription = "Verify \"LA.COM\" Delivery option in the document view";

            try
            {
                string secondexternalnumber = Support.RandomString("ANANANANAN");

                Reports.TestStep = "Login to FAST Application";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Create a LA.COM order using CreateFile() and enter file number in FAST";
                CreateFileRequest nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.Source = "LA.COM";

                var newFile = FileService.CreateFile(nextGenRequest);
                var fileId = (int)newFile.FileID;

                Support.IsTrue((int)(newFile.FileID ?? 0) > 0, "Is valid FileId ? " + fileId);

                OrderDetailsResponse file = FileService.GetOrderDetails(fileId);

                Reports.TestStep = "Search File.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);
            
                Reports.TestStep = "Naviagte to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Search for a template using template search criteria and create as a document";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Preliminary Report-TEST");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "Preliminary Report-TEST", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify created document in File documents search results screen";
                var docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Description", "Preliminary Report-TEST", "Description", TableAction.GetText).Message;
                Support.AreEqual(docName, "Preliminary Report-TEST", "Document exists on the Search Result Table");

                Reports.TestStep = "Navigate to Document view screen";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Preliminary Report-TEST", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();

                Reports.TestStep = "Verify LA.COM delivery in Document Editor screen";
                FastDriver.DocumentEditor.WaitForScreenToLoad();

                // TO DO : Verification in editor is pending
            }

            catch(Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region TestCase-844187 Verify "LVIS" Delivery option in the document view

        [TestMethod]
        public void TestCase_844187()
        {
            Reports.TestDescription = "Verify \"LVIS\" Delivery option in the document view";

            try
            {
                string secondexternalnumber = Support.RandomString("ANANANANAN");

                Reports.TestStep = "Login to FAST Application";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Reports.TestStep = "Create file using CreateFile() and enter file number in FAST";
                CreateFileRequest nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.Source = "FAST";

                var newFile = FileService.CreateFile(nextGenRequest);
                var fileId = (int)newFile.FileID;

                Support.IsTrue((int)(newFile.FileID ?? 0) > 0, "Is valid FileId ? " + fileId);

                OrderDetailsResponse file = FileService.GetOrderDetails(fileId);

                Reports.TestStep = "Search File.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Update Second order source as LVIS for the FAST order";
                var updateSecondOrderSourceRequest = RequestFactory.GetUpdateSecondOrderSourceRequest(fileId: fileId, appID: 38, secondExternalFileNum: secondexternalnumber); //WINTRACK
                var updateSecondOrderSourceResponse = FileService.UpdateSecondOrderSource(updateSecondOrderSourceRequest);
                Reports.StatusUpdate("UpdateSecondOrderSource operation response: " + updateSecondOrderSourceResponse.StatusDescription, updateSecondOrderSourceResponse.Status == 1);

                Reports.TestStep = "Naviagte to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Search for a template using template search criteria and create as a document";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Preliminary Report-TEST");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "Preliminary Report-TEST", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Verify created document in File documents search results screen";
                var docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Description", "Preliminary Report-TEST", "Description", TableAction.GetText).Message;
                Support.AreEqual(docName, "Preliminary Report-TEST", "Document exists on the Search Result Table");

                Reports.TestStep = "Navigate to Document view screen";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Preliminary Report-TEST", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();

                Reports.TestStep = "Verify LVIS delivery in Document Editor screen";
                FastDriver.DocumentEditor.WaitForScreenToLoad();

                // TO DO : Verification in editor is pending
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }


        }

        #endregion
       
        #region TestCase-846926 Verify multiple interface parnters delivery options in Document view screen example First Order source as LA.COM and Second Order source as LVIS (or) WINTRACK then in Document View both LA.COM and LVIS (or) WINTRACK should display

        [TestMethod]
        public void TestCase_846926()
        {
            string secondexternalnumber = Support.RandomString("ANANANANAN");

            Reports.TestStep = "Login to FAST Application";
            FAST_Login_IIS(regionId: regionId);
            FAST_OpenRegionOrOffice(officeId);

            Reports.TestStep = "Create LA.COM file using CreateFile() and enter file number in FAST";
            CreateFileRequest nextGenRequest = GetNextGenWCFFileRequest();
            nextGenRequest.Source = "LA.COM";

            var newFile = FileService.CreateFile(nextGenRequest);
            var fileId = (int)newFile.FileID;

            Support.IsTrue((int)(newFile.FileID ?? 0) > 0, "Is valid FileId ? " + fileId);

            OrderDetailsResponse file = FileService.GetOrderDetails(fileId);

            Reports.TestStep = "Search File.";
            FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

            Reports.TestStep = "Update Second order source as WINTRACK for the FAST order";
            var updateSecondOrderSourceRequest = RequestFactory.GetUpdateSecondOrderSourceRequest(fileId: fileId, appID: 10, secondExternalFileNum: secondexternalnumber); //WINTRACK
            var updateSecondOrderSourceResponse = FileService.UpdateSecondOrderSource(updateSecondOrderSourceRequest);
            Reports.StatusUpdate("UpdateSecondOrderSource operation response: " + updateSecondOrderSourceResponse.StatusDescription, updateSecondOrderSourceResponse.Status == 1);

            Reports.TestStep = "Naviagte to Document Repository";
            FastDriver.NextGenDocumentRepository.Open();
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

            Reports.TestStep = "Click on Template Search button";
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();

            FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

            Reports.TestStep = "Search for a template using template search criteria and create as a document";
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Preliminary Report-TEST");
            FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "Preliminary Report-TEST", "Description", TableAction.Click).Element.FARightClick();
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created...", true, 10);
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

            Reports.TestStep = "Verify created document in File documents search results screen";
            var docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Description", "Preliminary Report-TEST", "Description", TableAction.GetText).Message;
            Support.AreEqual(docName, "Preliminary Report-TEST", "Document exists on the Search Result Table");

            Reports.TestStep = "Navigate to Document view screen";
            FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Preliminary Report-TEST", "Name", TableAction.Click).Element.FARightClick();
            FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();

            Reports.TestStep = "Verify LA.COM and WINTRACK deliveries in Document Editor screen";
            FastDriver.DocumentEditor.WaitForScreenToLoad();

            // TO DO : Verification in editor is pending

            secondexternalnumber = Support.RandomString("ANANNANAN");

            Reports.TestStep = "Login to FAST Application";
            FAST_Login_IIS(regionId: regionId);
            FAST_OpenRegionOrOffice(officeId);

            Reports.TestStep = "Create LA.COM file using CreateFile() and enter file number in FAST";
           
            newFile = FileService.CreateFile(nextGenRequest);
            fileId = (int)newFile.FileID;

            Support.IsTrue((int)(newFile.FileID ?? 0) > 0, "Is valid FileId ? " + fileId);

            file = FileService.GetOrderDetails(fileId);

            Reports.TestStep = "Search File.";
            FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

            Reports.TestStep = "Update Second order source as LVIS for the FAST order";
            updateSecondOrderSourceRequest = RequestFactory.GetUpdateSecondOrderSourceRequest(fileId: fileId, appID: 38, secondExternalFileNum: secondexternalnumber); //WINTRACK
            updateSecondOrderSourceResponse = FileService.UpdateSecondOrderSource(updateSecondOrderSourceRequest);
            Reports.StatusUpdate("UpdateSecondOrderSource operation response: " + updateSecondOrderSourceResponse.StatusDescription, updateSecondOrderSourceResponse.Status == 1);

            Reports.TestStep = "Naviagte to Document Repository";
            FastDriver.NextGenDocumentRepository.Open();
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

            Reports.TestStep = "Click on Template Search button";
            FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();

            FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

            Reports.TestStep = "Search for a template using template search criteria and create as a document";
            FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
            FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
            FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("Preliminary Report-TEST");
            FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
            FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
            FastDriver.NextGenDocumentRepository.Search.FAClick();
            FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "Preliminary Report-TEST", "Description", TableAction.Click).Element.FARightClick();
            FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created...", true, 10);
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

            Reports.TestStep = "Verify created document in File documents search results screen";
            docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Description", "Preliminary Report-TEST", "Description", TableAction.GetText).Message;
            Support.AreEqual(docName, "Preliminary Report-TEST", "Document exists on the Search Result Table");

            Reports.TestStep = "Navigate to Document view screen";
            FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Preliminary Report-TEST", "Name", TableAction.Click).Element.FARightClick();
            FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();

            Reports.TestStep = "Verify LA.COM and LVIS deliveries in Document Editor screen";
            FastDriver.DocumentEditor.WaitForScreenToLoad();

            // TO DO : Verification in editor is pending


        }

        #endregion

       
        #region Private methods

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        #endregion

        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
