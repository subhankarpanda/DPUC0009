﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using System.Windows.Input;
using FASTSelenium.DataObjects;

namespace NextGenDocPrep.r09._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_844678 : FASTHelpers
    {
        #region Data Setup
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        private static string natgabid = "ATTY3419";
        private static string mortgageid = "A101";
       
        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        #endregion

        #region Private Methods

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.PropertyValueTypeCD = 15;
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                //FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }       

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        public bool CreateStandardFile_OtherRegion(string GABID)
        {
            Reports.TestStep = "Create File using FAST GUI.";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
            try
            {
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            }
            catch
            {
                Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
            }

            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.BusinessSourceGABcode);
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(GABID);
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText(GABID);
            FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
            if (!FastDriver.QuickFileEntry.Title.Selected)
                FastDriver.QuickFileEntry.Title.FAClick();
            if (!FastDriver.QuickFileEntry.Escrow.Selected)
                FastDriver.QuickFileEntry.Escrow.FAClick();
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
            FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
            FastDriver.QuickFileEntry.ProgramType.FASelectItemByIndex(0);

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FastDriver.QuickFileEntry.FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);

            FastDriver.QuickFileEntry.ProductTable.PerformTableAction(2, 1, TableAction.On);
            FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText("5000");
            FastDriver.QuickFileEntry.PropertyInformationName.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
            FastDriver.QuickFileEntry.PropertyInformationLot.FASetText("Lot1");
            FastDriver.QuickFileEntry.PropertyInformationBlock.FASetText("Block1");
            FastDriver.QuickFileEntry.PropertyInformationUnit.FASetText("Unit1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN1.FASetText("Prop1APN1");
            FastDriver.QuickFileEntry.PropertyPropTaxAPN2.FASetText("9845012345");
            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
            FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
            FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
            FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
            FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
            FastDriver.QuickFileEntry.Buyer1SSN.FASetText("123456789");
            FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
            FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
            FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
            FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2SpouseName");
            FastDriver.QuickFileEntry.Buyer2SSN.FASetText("123456789");
            FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
            FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
            FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
            FastDriver.QuickFileEntry.Seller1SSN.FASetText("987654321");
            FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
            FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
            FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
            FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
            FastDriver.QuickFileEntry.Seller2SSN.FASetText("987654321");          
            Playback.Wait(1000);
            //Keyboard.SendKeys("^{D}"); //Send Control + D
            //FastDriver.BottomFrame.Done();

            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                throw new Exception("File could not be created");
            }

            return true;
        }
        private bool FAST_CreateFilewithprogramtype()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateCustomizedFileWithProgramType();
                //FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }       

        #endregion

        #region TestCase-850798 To verify system disables the owning office when Owning Region is selected as All/multiple

        [TestMethod]
        public void TestCase_850798()
        {
            Reports.TestDescription = "To verify system disables the owning office when Owning Region is selected as All/multiple";

            try
            {
                int corpregionid = 196;
                string tempname = Support.RandomString("AAANNNANANA");
                string tempdesc = Support.RandomString("AAANNNANANAANANANANANA");
                string tplPhraseName = "EN06/1";


                Reports.TestStep = "Login to FAST Admin side";
                FAST_Login_ADM(true);

                Reports.TestStep = "Navigate to Corporate Region";
                FAST_OpenRegionOrOffice(corpregionid);
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(4000);
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on the templates tab and create new template type of endorsement";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab.FAClick();
                string TempRegn = FastDriver.NextGenDocumentPreparation.TemplateRegion.FAGetSelectedItem().ToString();
                Support.AreEqual("DOCPREP Corporate Region", TempRegn);
                string Temptype = FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FAGetSelectedItem().ToString();
                Support.AreEqual("Endorsement/Guarantee", Temptype);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(tempdesc);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatePhrases);

                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                Reports.TestStep = "Create phrases from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();

                Reports.TestStep = "Select any phrase from Phrase selection dialogbox";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(tplPhraseName);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FilteringTab);

                Reports.TestStep = "Click on Filtering and add Suggested filter";
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", true, 20);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddFilterGroup);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);

                Reports.TestStep = "Verify Select all for owning region and disable owning office,program type and underwriter";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("true", FastDriver.NextGenDocumentPreparation.OwningRegionSelectAll.FAGetAttribute("Checked"), "Owning Regions is selected as All");
                Support.AreEqual("False", FastDriver.NextGenDocumentPreparation.OwningOfcSelectAll.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.IsSelected ().ToString());
                FastDriver.NextGenDocumentPreparation.Title.FAClick();
                FastDriver.NextGenDocumentPreparation.Escrow.FAClick();
                FastDriver.NextGenDocumentPreparation.PropertyType.FASelectItem("Single Family Residence");
                FastDriver.NextGenDocumentPreparation.BusinessSegment.FASelectItem("Residential");
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");

                Reports.TestStep = "Clcik on \"Done\" button";
                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.UnderConstruction);

                Reports.TestStep = "Verify the values are retained in the filter";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FilteringTab);
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                string Owningregion = FastDriver.NextGenDocumentPreparation.GrougTableOwningRegion.FAGetText();
                Support.AreEqual("ALL", Owningregion);

                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);

                FastDriver.NextGenDocumentPreparation.OwningRegionSelectAll.FAClick();
                FastDriver.NextGenDocumentPreparation.SelectOwningRegion.FASelectItem("North American Title California Division");
                UIKeyboard.PressModifierKeys(UIModifierKeys.Control);       // hold down CTRL key
                Playback.Wait(500); // need this
                FastDriver.NextGenDocumentPreparation.SelectOwningRegion.FASelectItem("Mortgage Services");
                UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control);

                Support.AreEqual("FALSE", FastDriver.NextGenDocumentPreparation.OwningOfcSelectAll.IsEnabled().ToString().ToUpper());
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.IsSelected().ToString());

                Reports.TestStep = "Clcik on \"Done\" button";
                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();

                Reports.TestStep = "Verify the owining region, underwriter and program type";
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                string Owningregion1 = FastDriver.NextGenDocumentPreparation.GrougTableOwningRegion.FAGetText();
                Support.AreEqual("Mortgage Services, North American Title Calif...", Owningregion1);
                string underwriter = FastDriver.NextGenDocumentPreparation.GrougTableunderwriter.FAGetText();
                Support.AreEqual("", underwriter);
                string programtype = FastDriver.NextGenDocumentPreparation.GrougTableprogramtype.FAGetText();
                Support.AreEqual("", programtype);

                Reports.TestStep = "Verify owning region, owning office,program type and underwriter are disabled";
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("FALSE", FastDriver.NextGenDocumentPreparation.OwningOfcSelectAll.IsEnabled().ToString().ToUpper());
                Support.AreEqual("FALSE", FastDriver.NextGenDocumentPreparation.OwningOfcSelectAll.IsSelected().ToString().ToUpper());
                Support.AreEqual("TRUE", FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.IsEnabled().ToString().ToUpper());
                Support.AreEqual("FALSE", FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.IsSelected().ToString().ToUpper());
                Support.AreEqual("TRUE", FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.IsEnabled().ToString().ToUpper());
                Support.AreEqual("FALSE", FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.IsSelected().ToString().ToUpper());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region TestCase-850824 To verify system displays the template in all the regions when owning region is set to ALL

        [TestMethod]
        public void TestCase_850824()
        {
            Reports.TestDescription = "To verify system displays the template in all the regions when owning region is set to ALL";

            try
            {
                int corpregionid = 196;
                int natofficeid = 12970;                
                string tempname = Support.RandomString("AAANNNANANA");
                string tempdesc = Support.RandomString("AAANNNANANAANANANANANA");
                string tplPhraseName = "EN06/1";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                Reports.TestStep = "Login to FAST Admin side";
                FAST_Login_ADM(true);

                Reports.TestStep = "Navigate to Corporate Region";
                FAST_OpenRegionOrOffice(corpregionid);
                
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on the templates tab and create new template type of endorsement";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab.FAClick();
                string TempRegn = FastDriver.NextGenDocumentPreparation.TemplateRegion.FAGetSelectedItem().ToString();
                Support.AreEqual("DOCPREP Corporate Region", TempRegn);
                string Temptype = FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FAGetSelectedItem().ToString();
                Support.AreEqual("Endorsement/Guarantee", Temptype);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(tempdesc);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatePhrases);

                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                Reports.TestStep = "Create phrases from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1,2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();

                Reports.TestStep = "Select any phrase from Phrase selection dialogbox";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(tplPhraseName);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FilteringTab);

                Reports.TestStep = "Click on Filtering and add Suggested filter";
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", true, 20);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddFilterGroup);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);

                Reports.TestStep = "Verify Select all for owning region and disablw owning office,program type and underwriter";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("true", FastDriver.NextGenDocumentPreparation.OwningRegionSelectAll.FAGetAttribute("Checked").ToLower(), "Owning Regions is selected as All");
                Support.AreEqual("false", FastDriver.NextGenDocumentPreparation.OwningOfcSelectAll.IsEnabled().ToString().ToLower());
                Support.AreEqual("true", FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.IsEnabled().ToString().ToLower());
                Support.AreEqual("true", FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.IsEnabled().ToString().ToLower());
                FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.FAClick();
                FastDriver.NextGenDocumentPreparation.Title.FAClick();
                FastDriver.NextGenDocumentPreparation.Escrow.FAClick();
                FastDriver.NextGenDocumentPreparation.PropertyType.FASelectItem("Single Family Residence");
                FastDriver.NextGenDocumentPreparation.BusinessSegment.FASelectItem("Residential");
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");
                                
                Reports.TestStep = "Clcik on \"Done\" button";
                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.UnderConstruction);

                Reports.TestStep = "Uncheck the under construction and save the template";
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();                
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                Playback.Wait(2000);

                Reports.TestStep = "Login to FAST File side";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                FAST_CreateFile();

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Make my search as empty";
                FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);

                Reports.TestStep = "With 'Filtered Templates' in the search criteria and source as 'corporate', 'region', search for the above template";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);              
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Pelase wait...", true, 10);

                Reports.TestStep = "Verify system should display the template in the search result";
                Support.AreEqual(tempdesc,FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempdesc, "Description", TableAction.GetText).Message,"Template is displayed successfully");

                Reports.TestStep = "With 'Filtered Templates' in the search criteria and source as 'corporate' search for the above template";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.CorporateRegion.FAClick();
                if (FastDriver.NextGenDocumentRepository.Corporate.FAGetAttribute("Checked") == "False")
                    FastDriver.NextGenDocumentRepository.Corporate.FAClick();
                if (FastDriver.NextGenDocumentRepository.SelectRegion.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentRepository.SelectRegion.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);

                Reports.TestStep = "Verify system should display the template in the search result";
                Support.AreEqual(tempdesc, FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempdesc, "Description", TableAction.GetText).Message, "Template is displayed successfully");

                Reports.TestStep = "Login to NAT Region";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FAST_OpenRegionOrOffice(natofficeid);
                CreateStandardFile_OtherRegion(natgabid);

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Make my search as empty";
                FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);

                Reports.TestStep = "With 'Filtered Templates' in the search criteria and source as 'corporate', 'region', search for the above template";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Pelase wait...", true, 10);

                Reports.TestStep = "Verify system should display the template in the search result";
                Support.AreEqual(tempdesc, FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempdesc, "Description", TableAction.GetText).Message, "Template is displayed successfully");

                Reports.TestStep = "With 'Filtered Templates' in the search criteria and source as 'corporate' search for the above template";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.CorporateRegion.FAClick();
                if (FastDriver.NextGenDocumentRepository.Corporate.FAGetAttribute("Checked") == "False")
                    FastDriver.NextGenDocumentRepository.Corporate.FAClick();
                if (FastDriver.NextGenDocumentRepository.SelectRegion.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentRepository.SelectRegion.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Pelase wait...", true, 10);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Pelase wait...", true, 10);

                Reports.TestStep = "Verify system should display the template in the search result";
                Support.AreEqual(tempdesc, FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempdesc, "Description", TableAction.GetText).Message, "Template is displayed successfully");


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region TestCase-850834 To verify system is not displaying owning region option for any regions other than doc prep region

        [TestMethod]
        public void TestCase_850834()
        {
            Reports.TestDescription = "To verify system is not displaying owning region option for any regions other than doc prep region";

            try
            {
                string tempname = Support.RandomString("AAANNNANANA");
                string tempdesc = Support.RandomString("AAANNNANANAANANANANANA");


                Reports.TestStep = "Login to FAST Admin side";
                FAST_Login_ADM(true);

                Reports.TestStep = "Navigate to QA sandpointe nextgenRegion";
                FAST_OpenRegionOrOffice(regionId);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on the templates tab and create new template type of endorsement";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab.FAClick();
                string TempRegn = FastDriver.NextGenDocumentPreparation.TemplateRegion.FAGetSelectedItem().ToString();
                Support.AreEqual("QA Sandpointe - Next Gen", TempRegn);
                string Temptype = FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FAGetSelectedItem().ToString();
                Support.AreEqual("Endorsement/Guarantee", Temptype);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(tempdesc);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatePhrases);

                Reports.TestStep = "Click on Filtering and add Suggested filter";
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", true, 20);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddFilterGroup);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);

                Reports.TestStep = "Verify Owning region is not displayed";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("False", FastDriver.NextGenDocumentPreparation.OwningRegionSelectAll.IsVisible().ToString());
                Support.AreEqual("False", FastDriver.NextGenDocumentPreparation.SelectOwningRegion.IsVisible().ToString());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region TestCase-856920 To verify system displays the template when specific or multiple owning region is selected

        [TestMethod]
        public void TestCase_856920()
        {
            Reports.TestDescription = "To verify system displays the template when specific or multiple owning region is selected";

            try
            {
                int corpregionid = 196;
                int natofficeid = 12970;
                int mortgageregionid = 424;

                string tempname = Support.RandomString("AAANNNANANA");
                string tempdesc = Support.RandomString("AAANNNANANAANANANANANA");
                string tplPhraseName = "EN06/1";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                Reports.TestStep = "Login to FAST Admin side";
                FAST_Login_ADM(true);

                Reports.TestStep = "Navigate to Corporate Region";
                FAST_OpenRegionOrOffice(corpregionid);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on the templates tab and create new template type of endorsement";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab.FAClick();
                string TempRegn = FastDriver.NextGenDocumentPreparation.TemplateRegion.FAGetSelectedItem().ToString();
                Support.AreEqual("DOCPREP Corporate Region", TempRegn);
                string Temptype = FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FAGetSelectedItem().ToString();
                Support.AreEqual("Endorsement/Guarantee", Temptype);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(tempdesc);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatePhrases);

                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                Reports.TestStep = "Create phrases from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();

                Reports.TestStep = "Select any phrase from Phrase selection dialogbox";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(tplPhraseName);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FilteringTab);

                Reports.TestStep = "Click on Filtering and add Suggested filter";
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", true, 20);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddFilterGroup);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);

                Reports.TestStep = "Verify system allows to select multiple owning regions";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                FastDriver.NextGenDocumentPreparation.OwningRegionSelectAll.FAClick();
                FastDriver.NextGenDocumentPreparation.SelectOwningRegion.FASelectItem("North American Title California Division");
                UIKeyboard.PressModifierKeys(UIModifierKeys.Control);       // hold down CTRL key
                Playback.Wait(500); // need this
                FastDriver.NextGenDocumentPreparation.SelectOwningRegion.FASelectItem("Mortgage Services");
                UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control);     // release CTRL key

                Support.AreEqual("false", FastDriver.NextGenDocumentPreparation.OwningOfcSelectAll.IsEnabled().ToString().ToLower());
                Support.AreEqual("true", FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.IsEnabled().ToString().ToLower());
                Support.AreEqual("true", FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.IsEnabled().ToString().ToLower());
                FastDriver.NextGenDocumentPreparation.Title.FAClick();
                FastDriver.NextGenDocumentPreparation.Escrow.FAClick();
                FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.FAClick();
                FastDriver.NextGenDocumentPreparation.PropertyType.FASelectItem("Single Family Residence");
                FastDriver.NextGenDocumentPreparation.BusinessSegment.FASelectItem("Residential");
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");

                Reports.TestStep = "Clcik on \"Done\" button";
                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.UnderConstruction);

                Reports.TestStep = "Uncheck the under construction and save the template";
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                Playback.Wait(2000);

                
                Reports.TestStep = "Login to FAST file side in NAT region";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FAST_OpenRegionOrOffice(natofficeid);
                CreateStandardFile_OtherRegion(natgabid);

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Make my search as empty";
                FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);

                Reports.TestStep = "With 'Filtered Templates' in the search criteria and source as 'corporate', 'region', search for the above template";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Pelase wait...", true, 10);

                Reports.TestStep = "Verify system should display the template in the search result";
                Support.AreEqual(tempdesc, FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempdesc, "Description", TableAction.GetText).Message, "Template is displayed successfully");

                Reports.TestStep = "With 'Filtered Templates' in the search criteria and source as 'corporate' search for the above template";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.CorporateRegion.FAClick();
                if (FastDriver.NextGenDocumentRepository.Corporate.FAGetAttribute("Checked") == "False")
                    FastDriver.NextGenDocumentRepository.Corporate.FAClick();
                if (FastDriver.NextGenDocumentRepository.SelectNATRegion.FAGetAttribute("Checked") == "True")
                    FastDriver.NextGenDocumentRepository.SelectNATRegion.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Pelase wait...", true, 10);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Pelase wait...", true, 10);

                Reports.TestStep = "Verify system should display the template in the search result";
                Support.AreEqual(tempdesc, FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempdesc, "Description", TableAction.GetText).Message, "Template is displayed successfully");

                Reports.TestStep = "Login to FAST file side in Mortgage services region";
                FAST_OpenRegionOrOffice(mortgageregionid);
                CreateStandardFile_OtherRegion(mortgageid);

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Make my search as empty";
                FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);

                Reports.TestStep = "With 'Filtered Templates' in the search criteria and source as 'corporate', 'region', search for the above template";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Pelase wait...", true, 10);

                Reports.TestStep = "Verify system should display the template in the search result";
                Support.AreEqual(tempdesc, FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempdesc, "Description", TableAction.GetText).Message, "Template is displayed successfully");

                Reports.TestStep = "With 'Filtered Templates' in the search criteria and source as 'corporate' search for the above template";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.CorporateRegion.FAClick();
                if (FastDriver.NextGenDocumentRepository.Corporate.FAGetAttribute("Checked") == "False")
                    FastDriver.NextGenDocumentRepository.Corporate.FAClick();
                if (FastDriver.NextGenDocumentRepository.SelectRegion.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentRepository.SelectRegion.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Pelase wait...", true, 10);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Pelase wait...", true, 10);

                Reports.TestStep = "Verify system should display the template in the search result";
                Support.AreEqual(tempdesc, FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempdesc, "Description", TableAction.GetText).Message, "Template is displayed successfully");


                Reports.TestStep = "Login to FAST File side QA sandpointe nextgen region";
                FAST_OpenRegionOrOffice(_officeId);
                FAST_CreateFile();

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Make my search as empty";
                FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);

                Reports.TestStep = "With 'Filtered Templates' in the search criteria and source as 'corporate', 'region', search for the above template";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);

                Reports.TestStep = "Verify system should not display the template in the search result";
                Support.AreEqual(tempdesc, FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempdesc, "Description", TableAction.GetText).Message);
                string Templateexist = FastDriver.NextGenDocumentRepository.TemplatesTable.FeeExistOnTable(tempdesc).ToString();
                Support.AreEqual("False", Templateexist);

                Reports.TestStep = "With 'Filtered Templates' in the search criteria and source as 'corporate' search for the above template";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.CorporateRegion.FAClick();
                if (FastDriver.NextGenDocumentRepository.Corporate.FAGetAttribute("Checked") == "False")
                    FastDriver.NextGenDocumentRepository.Corporate.FAClick();
                if (FastDriver.NextGenDocumentRepository.SelectRegion.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentRepository.SelectRegion.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);

                Reports.TestStep = "Verify system should not display the template in the search result";
                Support.AreEqual(tempdesc, FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempdesc, "Description", TableAction.GetText).Message);
                string Templatexist = FastDriver.NextGenDocumentRepository.TemplatesTable.FeeExistOnTable(tempdesc).ToString();
                Support.AreEqual("False", Templatexist);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region TestCase-860887 Verify system retains the values selected in filter dialog

        [TestMethod]
        public void TestCase_860887()
        {
            Reports.TestDescription = "Verify system retains the values selected in filter dialog";

            try
            {
                int corpregionid = 196;
                string tempname = Support.RandomString("AAANNNANANA");
                string tempdesc = Support.RandomString("AAANNNANANAANANANANANA");
                string tplPhraseName = "EN06/1";


                Reports.TestStep = "Login to FAST Admin side";
                FAST_Login_ADM(true);

                Reports.TestStep = "Navigate to Corporate Region";
                FAST_OpenRegionOrOffice(corpregionid);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on the templates tab and create new template type of endorsement";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab.FAClick();
                string TempRegn = FastDriver.NextGenDocumentPreparation.TemplateRegion.FAGetSelectedItem().ToString();
                Support.AreEqual("DOCPREP Corporate Region", TempRegn);
                string Temptype = FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FAGetSelectedItem().ToString();
                Support.AreEqual("Endorsement/Guarantee", Temptype);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(tempdesc);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatePhrases);

                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                Reports.TestStep = "Create phrases from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();

                Reports.TestStep = "Select any phrase from Phrase selection dialogbox";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(tplPhraseName);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FilteringTab);

                Reports.TestStep = "Click on Filtering and add Suggested filter";
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", true, 20);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddFilterGroup);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);

                Reports.TestStep = "Verify Select all for owning region and disable owning office,program type and underwriter";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("true", FastDriver.NextGenDocumentPreparation.OwningRegionSelectAll.FAGetAttribute("Checked").ToLower(), "Owning Regions is selected as All");
                Support.AreEqual("false", FastDriver.NextGenDocumentPreparation.OwningOfcSelectAll.IsEnabled().ToString().ToLower());
                Support.AreEqual("true", FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.IsEnabled().ToString().ToLower());
                Support.AreEqual("true", FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.IsEnabled().ToString().ToLower());
                FastDriver.NextGenDocumentPreparation.Title.FAClick();
                FastDriver.NextGenDocumentPreparation.Escrow.FAClick();
                FastDriver.NextGenDocumentPreparation.PropertyType.FASelectItem("Single Family Residence");
                FastDriver.NextGenDocumentPreparation.BusinessSegment.FASelectItem("Residential");
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");

                Reports.TestStep = "Clcik on \"Done\" button";
                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.UnderConstruction);

                Reports.TestStep = "Uncheck the under construction and save the template";
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading.. please wait...", true, 10);

                Reports.TestStep = "Verify the values are retained in the filter";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FilteringTab);
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                string Owningregion = FastDriver.NextGenDocumentPreparation.GrougTableOwningRegion.FAGetText();
                Support.AreEqual("ALL",Owningregion);
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #region TestCase-To verify system does not display the Template when the Underwriter or program type is blank but file has a program type and Underwriter"
        [TestMethod]
        public void TestCase_887735()
        {
            Reports.TestDescription = "To verify system does not display the Template when the Underwriter or program type is blank but file has a program type and Underwriter";

            try
            {
                int corpregionid = 196;
                int natofficeid = 12970;
                string tempname = Support.RandomString("AAANNNANANA");
                string tempdesc = Support.RandomString("AAANNNANANAANANANANANA");
                string tplPhraseName = "EN06/1";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                Reports.TestStep = "Login to FAST Admin side";
                FAST_Login_ADM(true);

                Reports.TestStep = "Navigate to Corporate Region";
                FAST_OpenRegionOrOffice(corpregionid);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on the templates tab and create new template type of endorsement";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab.FAClick();
                string TempRegn = FastDriver.NextGenDocumentPreparation.TemplateRegion.FAGetSelectedItem().ToString();
                Support.AreEqual("DOCPREP Corporate Region", TempRegn);
                string Temptype = FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FAGetSelectedItem().ToString();
                Support.AreEqual("Endorsement/Guarantee", Temptype);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(tempdesc);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatePhrases);

                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                Reports.TestStep = "Create phrases from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();

                Reports.TestStep = "Select any phrase from Phrase selection dialogbox";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(tplPhraseName);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FilteringTab);

                Reports.TestStep = "Click on Filtering and add Suggested filter";
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", true, 20);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddFilterGroup);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);

                Reports.TestStep = "Verify Select all for owning region and disable owning office,program type and underwriter";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("true", FastDriver.NextGenDocumentPreparation.OwningRegionSelectAll.FAGetAttribute("Checked").ToLower(), "Owning Regions is selected as All");
                Support.AreEqual("false", FastDriver.NextGenDocumentPreparation.OwningOfcSelectAll.IsEnabled().ToString().ToLower());
                Support.AreEqual("true", FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.IsEnabled().ToString().ToLower());
                Support.AreEqual("true", FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.IsEnabled().ToString().ToLower());
                Support.AreEqual("false", FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.IsSelected().ToString().ToLower());
                Support.AreEqual("false", FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.IsSelected().ToString().ToLower());
                FastDriver.NextGenDocumentPreparation.Title.FAClick();
                FastDriver.NextGenDocumentPreparation.Escrow.FAClick();
                FastDriver.NextGenDocumentPreparation.PropertyType.FASelectItem("Single Family Residence");
                FastDriver.NextGenDocumentPreparation.BusinessSegment.FASelectItem("Residential");
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");

                Reports.TestStep = "Clcik on \"Done\" button";
                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.UnderConstruction);

                Reports.TestStep = "Uncheck the under construction and save the template";
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                Playback.Wait(2000);

                Reports.TestStep = "Login to FAST File side";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                FAST_CreateFilewithprogramtype();

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Make my search as empty";
                FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);

                Reports.TestStep = "With 'Filtered Templates' in the search criteria and source as 'corporate', 'region', search for the above template";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Pelase wait...", true, 10);

                Reports.TestStep = "Verify system should display not the template in the search result";
                Support.AreEqual("False", FastDriver.NextGenDocumentRepository.TemplatesTable.FeeExistOnTable(tempdesc).ToString());


                //Support.AreEqual("False", FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempdesc, "Description", TableAction.GetCell).Element.IsVisible().ToString(), "Template is not displayed");
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion 
        #region TestCase-To verify system should display the Template when the Underwriter or program type is selected and also file has a program type and Underwriter"
        [TestMethod]
        public void TestCase_887737()
        {
            Reports.TestDescription = "To verify system should display the Template when the Underwriter or program type is selected and also file has a program type and Underwriter";

            try
            {
                int corpregionid = 196;
                int natofficeid = 12970;
                string tempname = Support.RandomString("AAANNNANANA");
                string tempdesc = Support.RandomString("AAANNNANANAANANANANANA");
                string tplPhraseName = "EN06/1";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserNameSU,
                    Password = AutoConfig.UserPasswordSU,
                };

                Reports.TestStep = "Login to FAST Admin side";
                FAST_Login_ADM(true);

                Reports.TestStep = "Navigate to Corporate Region";
                FAST_OpenRegionOrOffice(corpregionid);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();

                Reports.TestStep = "Click on the templates tab and create new template type of endorsement";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplateTab.FAClick();
                string TempRegn = FastDriver.NextGenDocumentPreparation.TemplateRegion.FAGetSelectedItem().ToString();
                Support.AreEqual("DOCPREP Corporate Region", TempRegn);
                string Temptype = FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FAGetSelectedItem().ToString();
                Support.AreEqual("Endorsement/Guarantee", Temptype);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname);
                FastDriver.NextGenDocumentPreparation.TemplateDescr.FASetText(tempdesc);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatePhrases);

                Reports.TestStep = "Click on Template Phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);

                Reports.TestStep = "Create phrases from the template phrases tab";
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.PhraseListContextMenu.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.AboveBelowPhrase.FindElements(By.TagName("A"))[2]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0]);
                FastDriver.NextGenDocumentPreparation.belowAddPhrase.FindElements(By.TagName("A"))[0].JSClick();

                Reports.TestStep = "Select any phrase from Phrase selection dialogbox";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(tplPhraseName);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.FilteringTab);

                Reports.TestStep = "Click on Filtering and add Suggested filter";
                FastDriver.NextGenDocumentPreparation.FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", true, 20);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.AddFilterGroup);
                FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAMoveToElement();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.SuggestedFilter);
                FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);

                Reports.TestStep = "Verify Select all for owning region and disablw owning office,program type and underwriter";
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.StateAddRemove);
                Support.AreEqual("true", FastDriver.NextGenDocumentPreparation.OwningRegionSelectAll.FAGetAttribute("Checked").ToLower(), "Owning Regions is selected as All");
                Support.AreEqual("FALSE", FastDriver.NextGenDocumentPreparation.OwningOfcSelectAll.IsEnabled().ToString().ToUpper());
                Support.AreEqual("TRUE", FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.IsEnabled().ToString().ToUpper());
                Support.AreEqual("TRUE", FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.IsEnabled().ToString().ToUpper());
                Support.AreEqual("FALSE", FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.IsSelected().ToString().ToUpper());
                Support.AreEqual("FALSE", FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.IsSelected().ToString().ToUpper());
                FastDriver.NextGenDocumentPreparation.Title.FAClick();
                FastDriver.NextGenDocumentPreparation.Escrow.FAClick();
                FastDriver.NextGenDocumentPreparation.UnderwriterSelectAll.FAClick();
                FastDriver.NextGenDocumentPreparation.ProgramTypeSelectAll.FAClick();
                FastDriver.NextGenDocumentPreparation.PropertyType.FASelectItem("Single Family Residence");
                FastDriver.NextGenDocumentPreparation.BusinessSegment.FASelectItem("Residential");
                FastDriver.NextGenDocumentPreparation.TransactionType.FASelectItem("Sale w/Mortgage");

                Reports.TestStep = "Clcik on \"Done\" button";
                FastDriver.NextGenDocumentPreparation.FilterSelection_Done.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.UnderConstruction);

                Reports.TestStep = "Uncheck the under construction and save the template";
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", true, 10);
                Playback.Wait(2000);

                Reports.TestStep = "Login to FAST File side";
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                FAST_CreateFilewithprogramtype();

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);

                Reports.TestStep = "Make my search as empty";
                FastDriver.NextGenDocumentRepository.MySearch.FASelectItem("");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please.. wait...", true, 10);

                Reports.TestStep = "With 'Filtered Templates' in the search criteria and source as 'corporate', 'region', search for the above template";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Pelase wait...", true, 10);

                Reports.TestStep = "Verify system should not display the template in the search result";
                Support.AreEqual(tempdesc, FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempdesc, "Description", TableAction.GetText).Message, "Template is displayed successfully");

                Reports.TestStep = "With 'Filtered Templates' in the search criteria and source as 'corporate' search for the above template";
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempdesc);
                FastDriver.NextGenDocumentRepository.CorporateRegion.FAClick();
                if (FastDriver.NextGenDocumentRepository.Corporate.FAGetAttribute("Checked") == "False")
                    FastDriver.NextGenDocumentRepository.Corporate.FAClick();
                if (FastDriver.NextGenDocumentRepository.SelectRegion.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentRepository.SelectRegion.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);

                Reports.TestStep = "Verify system should display the template in the search result";
                Support.AreEqual(tempdesc, FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", tempdesc, "Description", TableAction.GetText).Message, "Template is displayed successfully");
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion 
        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
