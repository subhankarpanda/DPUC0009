﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Windows.Input;

namespace NextGenDocPrep.r09._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_596888 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS"; 
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            

            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Endrosement two phrase ***AUTOMATION DNT***");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Endrosement two phrase ***AUTOMATION DNT***", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

       


        [TestMethod]
        public void ITR_r09_2016_US_596888_TC_847166_No_1()
        {
            try
            {

                Reports.TestDescription = "User Story:596888- Verify the order of 'Region' and 'Corporate' in Phrase Selection Dialog invoked from Phrases Subtab of a Template";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");            
                                
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);
               
              
                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Inserting Phrase";
              
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2,1, TableAction.Click).Element.FARightClick();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenu.FindElement(By.LinkText("Insert")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuAboveBelow.FindElement(By.LinkText("Below")).FAMouseOver();

                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).Highlight();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).FAMouseOver();
                FastDriver.NextGenDocumentPreparation.PhraseContextMenuBelowPhrase.FindElement(By.LinkText("Phrase")).JSClick();

                Reports.TestStep = "Verify the order of Source Values in Phrase Selection Dialog";

                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                string default_source= FastDriver.PhraseSelectDlg.Source.FAGetSelectedItem().ToString().Trim();
                Support.AreEqual("Region", default_source);

                FastDriver.PhraseSelectDlg.Source.FASelectItemByIndex(0);
                Playback.Wait(7000);
                string first_source = FastDriver.PhraseSelectDlg.Source.FAGetSelectedItem().ToString().Trim();
                Support.AreEqual("Corporate", first_source);

                FastDriver.PhraseSelectDlg.Source.FASelectItemByIndex(1);
                Playback.Wait(7000);
                string second_source = FastDriver.PhraseSelectDlg.Source.FAGetSelectedItem().ToString().Trim();
                Support.AreEqual("Region", second_source);

                FastDriver.PhraseSelectDlg.PhraseName.FASetText("E/1");

                string phname1 = FastDriver.PhraseSelectDlg.PhraseName.FAGetText().ToString().ToUpper();
                phname1 = phname1.Replace(" ", "");
                phname1 = phname1.Trim();

                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(5000);
                Reports.TestStep = "Saving the Changes";

                Keyboard.SendKeys("%{S}");
                Playback.Wait(7000);

                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Search for the created template";

                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                Playback.Wait(5000);


                Reports.TestStep = "Editing the created template";

                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", tempnameanddesc, "Description", TableAction.DoubleClick);
                Playback.Wait(5000);

                Reports.TestStep = "Navigating to Phrases Tab";
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                Playback.Wait(7000);
                Reports.TestStep = "Verify the Changes in Phrases Tab";
               Support.AreEqual("True",  FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.FeeExistOnTable(phname1).ToString());


            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void ITR_r09_2016_US_596888_TC_847169_No_3()
        {
            try
            {

                Reports.TestDescription = "User Story:596888- Verify the order of 'Region' and 'Corporate' in Phrase Selection Dialog invoked from Phrases View Screen";

                string tempnameanddesc = Support.RandomString("ANANANANANAN").ToString();

                LoadTemplateOrCreateNew(tempnameanddesc, tempnameanddesc, "Endorsement/Guarantee");

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for a Endorsement/Guarantee type template using template search criteria";
                

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempnameanddesc);
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();

                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, tempnameanddesc).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();

                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                string docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempnameanddesc, "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, tempnameanddesc, "Document exists on the Search Result Table");

                Reports.TestStep = "Editing the added document";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempnameanddesc, "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.PerformTableAction(1, 6, TableAction.Click).Element.FARightClick();

                Reports.TestStep = "Adding Phrase Above the selected Phrase";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2].Highlight();
                FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2].FAMouseOver();

                FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.ContextMenu2.FindElements(By.TagName("A"))[0].FAMouseOver();

                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[0].Highlight();
                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[0].FAMouseOver();
                FastDriver.NextGenDocumentRepository.ContextMenu3.FindElements(By.TagName("A"))[0].JSClick();
                

                Reports.TestStep = "Verify the order of Source Values in Phrase Selection Dialog";

                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                string default_source = FastDriver.PhraseSelectDlg.Source.FAGetSelectedItem().ToString().Trim();
                Support.AreEqual("Region", default_source);

                FastDriver.PhraseSelectDlg.Source.FASelectItemByIndex(0);
                Playback.Wait(7000);
                string first_source = FastDriver.PhraseSelectDlg.Source.FAGetSelectedItem().ToString().Trim();
                Support.AreEqual("Corporate", first_source);

                FastDriver.PhraseSelectDlg.Source.FASelectItemByIndex(1);
                Playback.Wait(7000);
                string second_source = FastDriver.PhraseSelectDlg.Source.FAGetSelectedItem().ToString().Trim();
                Support.AreEqual("Region", second_source);
                
                FastDriver.PhraseSelectDlg.Source.FASelectItemByIndex(0);
                Playback.Wait(7000);

                FastDriver.PhraseSelectDlg.PhraseName.FASetText("E/1");
               
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(7000);
                Reports.TestStep = "Saving the Changes";
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
               
                FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Editing the added document";

                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempnameanddesc, "Name", TableAction.DoubleClick);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                Reports.TestStep = "Verify the Phrase got saved in Phrase View Tab";

                FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.PhraseDataElementTable1.FeeExistOnTable("*E/1").ToString());


            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        


        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }

    
}
