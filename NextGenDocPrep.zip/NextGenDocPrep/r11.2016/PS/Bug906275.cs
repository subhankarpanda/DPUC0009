﻿using FASTSelenium.Common;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers;
using OpenQA.Selenium;

namespace NextGenDocPrep.r08._2016.US_Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class Bug906275 : FASTHelpers
    {
        #region Data Setup
        public static int _regionId = 12837;
        public static int _officeId = 12839;

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        #endregion

        #region Private Methods

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }
        #endregion

        [TestMethod]
        public void TestCase_906275()
        {
            try
            {
                Reports.TestDescription = "Verify Creat Document and Create/Edit Document  functionality with Icons";

                #region Login to File side and change office to NextGen
                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: officeId);
                FAST_OpenRegionOrOffice(officeId);

                #endregion

                #region Create a file
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document repository
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button and select any document form the search results and create document and create or edit documen with icons
                Reports.TestStep = "Click on Template Search button and search for any template using template search criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_TitleReports_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                Reports.TestStep = "Select the template from Template Results , and click on Create button in the template table cell";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Actions", TableAction.GetCell).Element.FindElement(By.Id("imgCreateDoc")).FAClick();
                //FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait,document is getting created...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_TitleReports_DoNotTouch", "Name", TableAction.Click);
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                Reports.TestStep = "Select the template from Template Results , and click on Create/Edit button in the template table cell";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Actions", TableAction.GetCell).Element.FindElement(By.Id("imgEditDoc")).FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
                FastDriver.NextGenDocumentRepository.DocInfo_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.Click);
                #endregion

            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
