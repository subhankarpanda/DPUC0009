﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using SeleniumInternalHelpers;


namespace NextGenDocPrep.r11._2016.US_PS_909761
{

    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_908623 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);
            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region templates

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            string[] templates = new string[5];
            templates[0] = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";
            templates[1] = "NEXTGEN_SAN_TitleReports_DoNotTouch";
            templates[2] = "NEXTGEN_SAN_LenderPolicy_DoNotTouch";
            templates[3] = "NEXTGEN_SAN_OwnerPolicy_DoNotTouch";
            templates[4] = "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch";

            string[] tempname = new string[5];
            tempname[0] = "SAN-NEXTGEN100";
            tempname[1] = "SAN-NEXTGEN200";
            tempname[2] = "SAN-NEXTGEN300";
            tempname[3] = "SAN-NEXTGEN400";
            tempname[4] = "SAN-NEXTGEN500";

            string[] temptype = new string[5];
            temptype[0] = "Escrow Instruction";
            temptype[1] = "Title Reports";
            temptype[2] = "Lender Policy";
            temptype[3] = "Owner Policy";
            temptype[4] = "Endorsement/Guarantee";

            #endregion
            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            #region Create Escrow Instruction

            if (!templateExists && templateType == "Escrow Instruction")
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Escrow Instruction QA MJJP Test 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                templateExists = templateTable.Contains(templateDesc);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Escrow Instruction QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[0]);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[0]);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[0]);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
            }

            #endregion
            #region Create Title Reports

            if (!templateExists && templateType == "Title Reports")
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Title Report QA MJJP 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                templateExists = templateTable.Contains(templateDesc);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Title Report QA MJJP 1", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[1]);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[1]);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[1]);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
            }

            #endregion
            #region Create Lender Policy

            if (!templateExists && templateType == "Lender Policy")
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Lender Policy QA MJJP Test 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                templateExists = templateTable.Contains(templateDesc);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Lender Policy QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[2]);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[2]);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[2]);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
            }

            #endregion
            #region Create Owner Policy

            if (!templateExists && templateType == "Owner Policy")
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Owner Policy QA MJJP Test 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                templateExists = templateTable.Contains(templateDesc);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Owner Policy QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[3]);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[3]);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[3]);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
            }

            #endregion
            #region Endorsement/Guarantee

            if (!templateExists && templateType == "Endorsement/Guarantee")
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Template QA MJJP-DO NOT TOUCH02");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                templateExists = templateTable.Contains(templateDesc);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Template QA MJJP-DO NOT TOUCH02", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[4]);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[4]);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[4]);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
            }

            #endregion


        }

        #region TestCase_911042-Verify system displays the email image or document name in the Generic email history tab

        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void TestCase_911042()
        {
            try
            {

                Reports.TestDescription = "To verify system displays the email image or document name in the Generic email history tab";

                #region upload a document
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();
                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);


                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveMisDocument(@"Miscellaneous", "Upload");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Upload", "Miscellaneous");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Create multiple documents in the Document Repository
                Reports.TestStep = "Create multiple documents in the Document Repository";
                for (int i = 1; i <= 2; i++)
                {
                    FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "NEXTGEN-SAN-14-0" + i.ToString());
                }
                #endregion
            

                #region scan a document
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
               
                Reports.TestStep = "Click on Scan button";
                FastDriver.NextGenDocumentRepository.Scan.FAClick();
                if (FastDriver.WebDriver.WaitForAlertToExist(5))
                {
                    if (!(System.IO.File.Exists(Reports.DEPLOYDIR + "\\RemoveDLLs64bit.bat") || System.IO.File.Exists(Reports.DEPLOYDIR + "\\RemoveDLLs32bit.bat")))
                        throw new ImageBenchException("Image Bench is outdated (must delete older files)");
                    else
                        FastDriver.WebDriver.HandleDialogMessage(true, true);
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                       
                Reports.TestStep = "Click on Open button and load the image document";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                //FastDriver.ImagingWorkBench.IROpen.SubPlaneR1().SubPlaneR1().SubPlaneR2().FAClick();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)          
    
                Reports.TestStep = "Save the TIF Document";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Escrow: Misc", "Audit PKG", "");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                            
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                
                Reports.TestStep = "Verify that Document is scanned to the FAST";
                docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Audit PKG", "Escrow: Misc");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

              #region Reports.TestStep = "Select all the documents and perform Email delivery";
                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FARightClick();
                //FastDriver.NextGenDocumentRepository.ShowContextMenu(FastDriver.NextGenDocumentRepository.ContextMenuXPath, 230, 0);
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.Deliver);
               // FastDriver.NextGenDocumentRepository.SearchResult_DeliverEmail.Click();
                FastDriver.NextGenDocumentRepository.MouseHoverOnObject(FastDriver.NextGenDocumentRepository.SearchResult_DeliverEmail);
                FastDriver.NextGenDocumentRepository.DeliverEmail.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Email", true, 15); 
                FastDriver.EmailDlg.WaitForDialogToLoad().SendEmail(); 
                FastDriver.WebDriver.WaitForDeliveryWindow("Email", 200);
               #endregion

             #region Verify in the Generic Email history tab for the document and images names in the attachments column;
              Reports.TestStep = "Verify in the Generic Email history tab for the document and images names in the attachments column";
                FastDriver.GenericEmail.Open();
                FastDriver.GenericEmail.EmailHistoryTab.FAClick();
                FastDriver.EmailHistory.WaitForScreenToLoad();
                Playback.Wait(1000);
                Reports.TestStep = "Verify entry of sent Email details in Email History";
                //Upload, CD - From Lender - Corrected AFTER Closing, NEXTGEN_SAN_EscrowInstruction_DoNotTouch, NEXTGEN-SAN-14-0");
                FastDriver.EmailHistory.VerifyDatafromHistory(rowindex: 1, columnindex: 6, CellText: "NEXTGEN-SAN-14-01, NEXTGEN-SAN-14-02, Audit PKG, Upload");
     
                ;

             #endregion
              
            }
            catch
            {}
        }
    

        #endregion



    }

    }


        


  