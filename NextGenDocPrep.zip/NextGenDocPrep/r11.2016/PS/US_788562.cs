﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.ImageRecognition;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Input;

namespace NextGenDocPrep.r11._2016.PS
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_788562 : MasterTestClass
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LA.COM";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FASTHelpers.FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }
      

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FASTHelpers.FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FASTHelpers.FAST_Login_ADM(isSuperUser: false);
            FASTHelpers.FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        #region TestCase-907425 Verify LA.com option is displayed inthe Phrase view delivery dropdown

        [TestMethod]
        public void TestCase_907425()
        {
            

            try
            {
                Reports.TestDescription = "Verify LA.com option is displayed in the Phrase view delivery dropdown";
                Reports.TestStep = "Pre-condition: Create a LA.com file";

                FASTHelpers.FAST_Login_IIS(regionId: regionId);
                FASTHelpers.FAST_OpenRegionOrOffice(officeId);
                CreateFileRequest nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.Source = "LA.COM";
                var newFile = FileService.CreateFile(nextGenRequest);
                var fileId = (int)newFile.FileID;
                Support.IsTrue((int)(newFile.FileID ?? 0) > 0, "Is valid FileId ? " + fileId);

                OrderDetailsResponse file = FileService.GetOrderDetails(fileId);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Login to IIS and searchf or the LA.com file";

                Reports.TestStep = "Navigate to Document repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Click on Template search and add a document";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.SearchScope);
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait, document is getting created...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                Reports.TestStep = "Select the document and right click for View/edit";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods);

                Reports.TestStep = "Select the delivery option LA.com";
                
                FastDriver.NextGenDocumentRepository.DocumentDeliveryMethods.FASelectItem("LA.COM");
                FastDriver.WebDriver.WaitForDeliveryWindow("LA.COM",300);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.DocumentEditor);

                
                Reports.TestStep = "Navigate to Event/Tracking log";

                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                string interfacedelcomments = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Interface Doc Delivery]", "Comments", TableAction.GetText).Message;
                Support.AreEqual(true, interfacedelcomments.Contains("Documents: NEXTGEN_SAN_EscrowInstruction_DoNotTouch"), "Document is present");
                Support.AreEqual(true, interfacedelcomments.Contains("Delivery Method: LA.COM"), "Document Delivered to LA.COM");
                var watch = Stopwatch.StartNew();
                while (watch.ElapsedMilliseconds <= 120 * 1000) // 120 Seconds
                {
                    FastDriver.EventTrackingLog.Open();
                    FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                    string interfacedelcomments1 = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Interface Doc Delivery]", "Comments", TableAction.GetText).Message;

                    if (interfacedelcomments1.Contains("Delivery Status: Delivery Successful") == true)
                    {
                        break;
                    }

                }

                watch.Stop();
                Support.AreEqual(true, interfacedelcomments.Contains("Delivery Status: Delivery Successful"), "Delivery is successful");
                Support.AreEqual(true, interfacedelcomments.Contains("Interface Delivery of NEXTGEN_SAN_EscrowInstruction_DoNotTouch: Successful"), "Interface Delivery Successful");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion


        #region Private methods

        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", ModifierKeys.Alt);

                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }

        #endregion

        [TestInitialize]
        public override void TestInitialize()
        {
            FASTHelpers.CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
