﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using System.Windows.Input;
using FASTSelenium.DataObjects;
using System.Diagnostics;


namespace NextGenDocPrep.r11._2016.PS
{
    [CodedUITest]
    public class US_906169 : MasterTestClass
    {
        [TestMethod]
        [DeploymentItem(@"ImageRecognition\Media\DocRep\DocEditor\")]
        [Description("User Story 906169-FINT10- Section Break(Next Page) inserting as read only from template")]

        public void TestCase_907194()
        {
            try
            {
                FASTHelpers.IRDebugging(!Reports.IsMTMExecutions);
                SetSilverlightClipboardPermission_YES();

                Reports.TestDescription = "TestCase#907194 - Validate Section Break(Next Page) is not inserted as Read only from another template | IIS";

                #region Login Fast
                Reports.TestStep = "Login into the IIS Side.";
                FAST_SU_IIS_Login(isSuperUser: false);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NextGen region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Create file
                CreateFile();
                #endregion

                #region Navigate to Document Repository screen
                Reports.TestStep = "Navigate to Document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Add any document to Doc Rep
                Reports.TestStep = "Add a document from template search";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click).Element.FAClick();
                var tempName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 3, TableAction.GetText).Message;
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText("05/17/2016");
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(tempName).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion

                #region Select document and right click for Document View\Edit
                Reports.TestStep = "Select document and right click for Document View/Edit";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Status", "Created", "Status", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.DocumentViewEdit.FASelectContextMenuItem();
                FastDriver.DocumentEditor.WaitForScreenToLoad(60);
                #endregion

                #region Insert a Restart Numbering phrase: Insert->Bottom->Section Break
                Reports.TestStep = "Insert a Section Break phrase: Insert->Bottom->Restart Numbering";
                FastDriver.DocumentEditor.InsertSectionBreak();
                FastDriver.DocumentEditor.SaveAndClose();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #region custom methods
        private void FAST_SU_IIS_Login(bool isSuperUser = true, int? regionId = null)
        {
            #region FAST Login IIS
            Reports.TestStep = "FAST Login IIS";
            var credentials = new Credentials() { UserName = isSuperUser ? AutoConfig.UserNameSU : AutoConfig.UserName, Password = isSuperUser ? AutoConfig.UserPasswordSU : AutoConfig.UserPassword };
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            if (regionId != null)
                FASTHelpers.FAST_OpenRegionOrOffice(regionId ?? 0);
            #endregion
        }
        private void CreateFile()
        {
            Reports.TestStep = "Create a basic file with insurance and buyer/seller information";

            #region Create a  File
            Reports.TestStep = "Create a file";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
            try
            {
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            }
            catch
            {
                Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
            }
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
            Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD | Buyer/Seller Info | Lender";
            FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
            FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
            FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
            FastDriver.QuickFileEntry.SelectState("CA");
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
            FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFirstName");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLastName");
            FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFirstName");
            FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLastName");
            FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("248");
            FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
            FastDriver.BottomFrame.Done();
            FastDriver.FileHomepage.WaitForScreenToLoad();
            String FileNum = FastDriver.FileHomepage.txtFileNumber.FAGetValue();
            #endregion

            #region Setting New Loan Insurance
            Reports.TestStep = "Set New Loan Insurance Information and Loan Number";
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.WaitForScreenToLoad();
            FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("0123456");
            FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("0123");
            FastDriver.BottomFrame.Done();
            #endregion
        }
        private void LoadOrCreateTemp(string templateName, string templateDesc, string templateType)
        {
            Reports.TestStep = "Create Template";

            FASTHelpers.FAST_Login_ADM(isSuperUser: false);

            #region Region selection
            Reports.TestStep = "Navigate to QA Sandpointe NextGen region";
            FastDriver.SecuritySelectRegionOffice.Open();
            FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
            #endregion

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Verify that Template is present
            Reports.TestStep = "Check Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            #region Create Template if not created
            Reports.TestStep = "Create Template if not created";
            if (!templateExists)
            {
                Reports.TestStep = "Creating Template " + templateDesc;
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (true)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                }

                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
            #endregion
        }
        private void AddPhrase(String TempDesc, String Temptype, String Phrasecode)
        {

            FASTHelpers.FAST_Login_ADM(isSuperUser: false);

            #region Region selection
            Reports.TestStep = "Navigate to QA Sandpointe NextGen region";
            FastDriver.SecuritySelectRegionOffice.Open();
            FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
            #endregion

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Navigate to NextGen Document Preparation/Templates Search
            Reports.TestStep = "Navigate to NextGen Document Preparation/Templates Search";
            FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            #endregion

            #region Search Policy Template and add phrases to it
            Reports.TestStep = "Search Template by Type & Description";
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(Temptype);
            FastDriver.NextGenDocumentPreparation.TemplateSearchRegions.FAClick();
            FastDriver.NextGenDocumentPreparation.AllRegions.FASetCheckbox(true);
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(TempDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable);

            if (FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.IsDisplayed())
            {

                //Select Template for Edit
                Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentPreparation.TemplateResultsTable.StringExistOnTable(TempDesc).ToString());
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. Please wait...", false);
                Playback.Wait(25000);
                var PhraseTable = FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.GetAttribute("textContent");
                var PhraseExists = PhraseTable.Contains(Phrasecode);
                var UCcheckbox = FastDriver.NextGenDocumentPreparation.UnderConstruction.IsSelected();

                if (!PhraseExists)
                {
                    //Click for Insert Phrase menu from Phrases sub-tab
                    Reports.TestStep = "Insert Phrases Option in Menu Context ";
                    FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);

                    //Insert Phrase which contains Policy Issue Date from Corporate
                    Reports.TestStep = "Phrases Selection Dialogue";
                    FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                    FastDriver.PhraseSelectDlg.Source.FASelectItem("Corporate");
                    FastDriver.PhraseSelectDlg.PhraseName.FASetText(Phrasecode);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();

                    //Save and Remove Under Construction Checkbox
                    Reports.TestStep = "Click Save and Under Construction ";
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                    if (UCcheckbox == true)
                    {
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    }
                    FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                }
                else
                {
                    //Save and Remove Under Construction Checkbox
                    Reports.TestStep = "Click Save and Under Construction ";
                    if (UCcheckbox == true)
                    {
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    }
                    FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                }
            }
            else
            {
                Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
            }
            #endregion

        }
         #endregion

        [ClassCleanup]
        public static void ClassCleanup()
        {
            MasterTestClass.CleanupClass();
        }
    }
}
