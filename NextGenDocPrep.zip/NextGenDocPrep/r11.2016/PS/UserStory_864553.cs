﻿using FASTSelenium.Common;
using FASTSelenium.ImageRecognition;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Input;

namespace NextGenDocPrep.r11._2016.PS
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class UserStory_864553 : FASTHelpers
    {
        #region DataSetup
        public static int _regionId = 12837;
        public static int _officeId = 12839;

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }
        #endregion

        #region Private Methods

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }
        #endregion

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void TestCase_909051()
        {
            try
            {
                Reports.TestDescription = "Verify Default First Associate Documents Package is selected by Default";

                #region Login to FAST IIS NextGen Region and create a basic file
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for a Escrow Instruction type template using template search criteria
                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                #endregion

                #region Select the template from Template Results , Right click and select Create Document
                // Perform Right Click on a table row using Document Name 
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Verify Created Document in File Documents Table grid
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Document exists on the Search Result Table");
                #endregion

                #region Click on Upload button
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();
                #endregion

                #region Browse document
                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);
                #endregion

                #region Save the PDF Document
                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is uploaded to the FAST
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Select Multiple templates (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var documents = new List<string> { "Miscellaneous PDFDocument" ,"NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Add to Associate Package
                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("true",FastDriver.NextGenDocumentRepository.AssociatePackages.FAGetAttribute("Selected"));
                FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("NEXTGEN-TestCase-909051");
                #endregion

                #region Click on Done Button
                Reports.TestStep = "Click on Done Button";
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();
                #endregion

                #region Click on "OK" button in the Alert Message box
                Reports.TestStep = "Click on \"OK\" button in the Alert Message box";
                FastDriver.WebDriver.HandleDialogMessage(true, true, 15);
                #endregion

                #region Click on "PACKAGES" link
                Reports.TestStep = "Click on \"PACKAGES\" link";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                // TODO: check if Packages tab is expanded. If not, expand it
                //                if (FastDriver.NextGenDocumentRepository.PackagesTree.IsDisplayed())    // expand Packages tab
                //                    FastDriver.NextGenDocumentRepository.Packages.FAClick();
                #endregion

                #region Select the package created in the above steps and verify the documents
                Reports.TestStep = "Select the package created in the above steps and verify the documents";
                var package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("NEXTGEN-TestCase-909051");
                var packageContent = package.GetAttribute("textContent");
                Support.AreEqual("True", packageContent.Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString(), "Package contains NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                Support.AreEqual("True", packageContent.Contains("Miscellaneous PDFDocument").ToString(), "Package contains Miscellaneous PDFDocument");
                
                #endregion

            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod]
        public void TestCase_909052()
        {
            try
            {
                Reports.TestDescription = "Verify Default First RTM Documents Package is selected by Default";

                #region Login to FAST IIS NextGen Region and create a basic file
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for a Escrow Instruction type template using template search criteria
                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                #endregion

                #region Select the template from Template Results , Right click and select Create Document
                // Perform Right Click on a table row using Document Name 
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Verify Created Document in File Documents Table grid
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Document exists on the Search Result Table");
                #endregion

                #region Create New RTM Package and Verify First RTM Package is selected by default
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.AddToRTMPackage1.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.NextGenDocumentRepository.RTMPakageRadio.FAGetAttribute("Selected"));
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.MailTo);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Verify the created RTM Package

                Reports.TestStep = "Click on Packages link";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Packages.FASelectContextMenuItem(); // Send Enter key to the control
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.RTMPackageLink);
                Reports.TestStep = "Verify the created RTM Package";
                var package = FastDriver.NextGenDocumentRepository.FindRTMPackage("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                var packageContent = package.GetAttribute("textContent");
                Support.AreEqual("True", packageContent.Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString(), "Package contains NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void TestCase_909233()
        {
            try
            {
                Reports.TestDescription = "Verify when multiple Associate Documents Package are present none of the options should be selected by Default";

                #region Login to FAST IIS NextGen Region and create a basic file
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for a Escrow Instruction type template using template search criteria
                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                #endregion

                #region Select the template from Template Results , Right click and select Create Document
                // Perform Right Click on a table row using Document Name 
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Verify Created Document in File Documents Table grid
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Document exists on the Search Result Table");
                #endregion

                #region Click on Upload button
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();
                #endregion

                #region Browse document
                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);
                #endregion

                #region Save the PDF Document
                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is uploaded to the FAST
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Select Multiple templates (2 or more) by using "Ctrl" command
                Reports.TestStep = "Select Multiple templates (2 or more) by using \"Ctrl\" command";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var documents = new List<string> { "Miscellaneous PDFDocument", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch" };
                FastDriver.NextGenDocumentRepository.SelectDocuments(FastDriver.NextGenDocumentRepository.DocumentsTable, documents);
                #endregion

                #region Hold Right Click
                Reports.TestStep = "Hold Right Click";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Add to Associate Package
                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.NextGenDocumentRepository.AssociatePackages.FAGetAttribute("Selected"));
                FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("NEXTGEN-TestCase-909051");
                #endregion

                #region Click on Done Button
                Reports.TestStep = "Click on Done Button";
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();
                #endregion

                #region Click on "OK" button in the Alert Message box
                Reports.TestStep = "Click on \"OK\" button in the Alert Message box";
                FastDriver.WebDriver.HandleDialogMessage(true, true, 15);
                #endregion

                #region Click on "PACKAGES" link
                Reports.TestStep = "Click on \"PACKAGES\" link";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                // TODO: check if Packages tab is expanded. If not, expand it
                //                if (FastDriver.NextGenDocumentRepository.PackagesTree.IsDisplayed())    // expand Packages tab
                //                    FastDriver.NextGenDocumentRepository.Packages.FAClick();
                #endregion

                #region Select the package created in the above steps and verify the documents
                Reports.TestStep = "Select the package created in the above steps and verify the documents";
                var package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("NEXTGEN-TestCase-909051");
                var packageContent = package.GetAttribute("textContent");
                Support.AreEqual("True", packageContent.Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString(), "Package contains NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                Support.AreEqual("True", packageContent.Contains("Miscellaneous PDFDocument").ToString(), "Package contains Miscellaneous PDFDocument");

                #endregion

                #region Create Another Associate Package and verify radio buttons check should be disabled

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Create multiple documents in the Document Repository
                Reports.TestStep = "Create multiple documents in the Document Repository";
                for (int i = 1; i <= 2; i++)
                {
                    FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate("NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "NEXTGEN-909233" + i.ToString());
                }
                #endregion

                #region On the Document Repository screen, highlight minimum of the documents that are to be included in the document package
                Reports.TestStep = "On the Document Repository screen, highlight minimum of the documents that are to be included in the document package";
                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                #endregion

                #region Right-Click on Highlighted documents and select "Add to Associate Package"
                Reports.TestStep = "Right-Click on Highlighted documents and select \"Add to Associate Package\"";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN-9092331", "Name", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Add to Associate Package
                Reports.TestStep = "Verify Associate Packages should not be selected by default after the first package got created";
                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                List<IWebElement> asspkgs = FastDriver.NextGenDocumentRepository.AssociatePackagesTable.FAFindElements(ByLocator.ClassName, "aPackageNames").GetAllVisible();
                foreach(var aspkg in asspkgs)
                {
                    if(aspkg.Selected == false)
                    {
                        Reports.StatusUpdate("Associate Package is not slected",true);
                    }
                    else
                    {
                        Reports.StatusUpdate("Associate Package is slected",false);
                    }
                }
                Reports.TestStep = "Click on Cancel Button";
                FastDriver.NextGenDocumentRepository.AssociatePackages_Cancel.FAClick();


              
                #endregion

        
                      
                #endregion

               

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void TestCase_909234()
        {
            try
            {
                Reports.TestDescription = "Verify Default First RTM Documents Package is selected by Default";

                #region Login to FAST IIS NextGen Region and create a basic file
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                #endregion

                #region Search for a Escrow Instruction type template using template search criteria
                Reports.TestStep = "Search for a Escrow Instruction type template using template search criteria";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                #endregion

                #region Select the template from Template Results , Right click and select Create Document
                // Perform Right Click on a table row using Document Name 
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(1, 4, TableAction.Click, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch").Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                #endregion

                #region Verify Created Document in File Documents Table grid
                Reports.TestStep = "Verify Created Document in File Documents Table grid";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                var docName = FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetText).Message;
                Support.AreEqual(docName, "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Document exists on the Search Result Table");
                #endregion

                #region Create New RTM Package and Verify First RTM Package is selected by default
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.AddToRTMPackage1.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.NextGenDocumentRepository.RTMPakageRadio.FAGetAttribute("Selected"));
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.MailTo);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Verify the created RTM Package

                Reports.TestStep = "Click on Packages link";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Packages.FASelectContextMenuItem(); // Send Enter key to the control
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.RTMPackageLink);
                Reports.TestStep = "Verify the created RTM Package";
                var package = FastDriver.NextGenDocumentRepository.FindRTMPackage("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                var packageContent = package.GetAttribute("textContent");
                Support.AreEqual("True", packageContent.Contains("NEXTGEN_SAN_EscrowInstruction_DoNotTouch").ToString(), "Package contains NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Upload button
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();
                #endregion

                #region Browse document
                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);
                #endregion

                #region Save the PDF Document
                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDFDocument");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is uploaded to the FAST
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("Miscellaneous PDFDocument", "Escrow: Payoff Demand/Bills");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Create another RTM Package and verify in the Packages dialog box two RTM packages  not selected
                Reports.TestStep = "Create another RTM package with uploade image";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "Miscellaneous PDFDocument", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.AddToRTMPackage1.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                List<IWebElement> rtmpackges = FastDriver.NextGenDocumentRepository.AssociatePackagesTable.FAFindElements(ByLocator.ClassName, "aRTMPackageNames").GetAllVisible();
                foreach (var rtmpkg in rtmpackges)
                {
                    if (rtmpkg.Selected == false)
                    {
                        Reports.StatusUpdate("Associate Package is not slected", true);
                    }
                    else
                    {
                        Reports.StatusUpdate("Associate Package is slected", false);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }

        }

        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
