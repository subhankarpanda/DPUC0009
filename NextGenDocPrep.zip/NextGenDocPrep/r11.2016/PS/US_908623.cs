﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace NextGenDocPrep.r11._2016.US_PS
{

    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_908623 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);
            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region templates

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            string[] templates = new string[5];
            templates[0] = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";
            templates[1] = "NEXTGEN_SAN_TitleReports_DoNotTouch";
            templates[2] = "NEXTGEN_SAN_LenderPolicy_DoNotTouch";
            templates[3] = "NEXTGEN_SAN_OwnerPolicy_DoNotTouch";
            templates[4] = "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch";

            string[] tempname = new string[5];
            tempname[0] = "SAN-NEXTGEN100";
            tempname[1] = "SAN-NEXTGEN200";
            tempname[2] = "SAN-NEXTGEN300";
            tempname[3] = "SAN-NEXTGEN400";
            tempname[4] = "SAN-NEXTGEN500";

            string[] temptype = new string[5];
            temptype[0] = "Escrow Instruction";
            temptype[1] = "Title Reports";
            temptype[2] = "Lender Policy";
            temptype[3] = "Owner Policy";
            temptype[4] = "Endorsement/Guarantee";

            #endregion
            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            #region Create Escrow Instruction

            if (!templateExists && templateType == "Escrow Instruction")
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Escrow Instruction QA MJJP Test 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                templateExists = templateTable.Contains(templateDesc);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Escrow Instruction QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[0]);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[0]);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[0]);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
            }

            #endregion
            #region Create Title Reports

            if (!templateExists && templateType == "Title Reports")
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Title Report QA MJJP 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                templateExists = templateTable.Contains(templateDesc);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Title Report QA MJJP 1", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[1]);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[1]);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[1]);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
            }

            #endregion
            #region Create Lender Policy

            if (!templateExists && templateType == "Lender Policy")
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Lender Policy QA MJJP Test 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                templateExists = templateTable.Contains(templateDesc);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Lender Policy QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[2]);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[2]);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[2]);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
            }

            #endregion
            #region Create Owner Policy

            if (!templateExists && templateType == "Owner Policy")
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Owner Policy QA MJJP Test 1");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                templateExists = templateTable.Contains(templateDesc);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Owner Policy QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[3]);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[3]);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[3]);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
            }

            #endregion
            #region Endorsement/Guarantee

            if (!templateExists && templateType == "Endorsement/Guarantee")
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Template QA MJJP-DO NOT TOUCH02");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
                templateExists = templateTable.Contains(templateDesc);
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Template QA MJJP-DO NOT TOUCH02", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[4]);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[4]);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[4]);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
            }

            #endregion


        }

        #region TestCase_908717-Verify system displays all the versions of the imagedoc - Associate package

        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void TestCase_908717()
        {
            try
            {
                Reports.TestDescription = "Verify Creating Associate Docs Package and perform imagedoc Delivery mutliple times and verify the versions";


                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();


                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();



                Reports.TestStep = "Browse document";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                FastDriver.UploadDocumentDlg.UploadFile(filePath);


                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Misc", "SEC-OPK-Open Order Documents", "");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);



                Reports.TestStep = "Navigate to Document Repository Screen";

                FastDriver.NextGenDocumentRepository.Open();


                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("SEC-OPK-Open Order Documents", "Escrow: Misc");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");


                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();


                #region Browse document
                Reports.TestStep = "Browse document";
                filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";

                FastDriver.UploadDocumentDlg.UploadFile(filePath);
                #endregion
                #region Save the PDF Document
                Reports.TestStep = "Save the PDF Document";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                FastDriver.SaveDocumentDlg.SaveMisDocument(@"Miscellaneous", "SEC-Escow Information Sheet");
                // FastDriver.SaveDocumentDlg.DocumentNameText.FASetText("SEC-Escow Information Sheet");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is uploaded to the FAST
                Reports.TestStep = "Verify that Document is uploaded to the FAST";
                docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("SEC-Escow Information Sheet", "Miscellaneous");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region On the Document Repository screen, highlight minimum of the documents that are to be included in the document package
                Reports.TestStep = "On the Document Repository screen, highlight minimum of the documents that are to be included in the document package";
                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                #endregion

                #region Right-Click on Highlighted documents and select "Add to Associate Package"
                Reports.TestStep = "Right-Click on Highlighted documents and select \"Add to Associate Package\"";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SEC-OPK-Open Order Documents", "Name", TableAction.GetCell).Element.FARightClick();
                #endregion

                #region Edit Name in the editable package name and selection radio button option
                Reports.TestStep = "Edit Name in the editable package name and selection radio button option";
                FastDriver.NextGenDocumentRepository.AddToAssociatePackage.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.AssociatePackages.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.AssociatePackagesName.FASetText("SEC-OPK-Open Order Documents 1");
                #endregion

                #region Click on Done Button
                Reports.TestStep = "Click on Done Button";
                FastDriver.NextGenDocumentRepository.AssociatePackages_Done.FAClick();
                #endregion

                #region Click on "OK" button in the Alert Message box
                Reports.TestStep = "Click on \"OK\" button in the Alert Message box";
                FastDriver.WebDriver.HandleDialogMessage(true, true, 15);
                #endregion

                #region Click on "PACKAGES" link
                Reports.TestStep = "Click on \"PACKAGES\" link";
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                // TODO: check if Packages tab is expanded. If not, expand it
                //                if (FastDriver.NextGenDocumentRepository.PackagesTree.IsDisplayed())    // expand Packages tab
                //                    FastDriver.NextGenDocumentRepository.Packages.FAClick();
                #endregion

                #region Select the package created in the above steps and verify the documents
                Reports.TestStep = "Select the package created in the above steps and verify the documents";
                var package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("SEC-OPK-Open Order Documents 1");
                var packageContent = package.GetAttribute("textContent");
                Support.AreEqual("True", packageContent.Contains("SEC-OPK-Open Order Documents").ToString(), "Package contains SEC-OPK-Open Order Documents");
                Support.AreEqual("True", packageContent.Contains("SEC-Escow Information Sheet").ToString(), "Package contains SEC-Escow Information Sheet");
                package = FastDriver.NextGenDocumentRepository.FindAssociatePackage("SEC-OPK-Open Order Documents 1", true);

                int i = 1;
                for (i = 1; i <= 5; i++)
                {
                    #region Perform ImageDoc Delivery
                    Reports.TestStep = "Perform ImageDoc Delivery";
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    package.FARightClick();
                    FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Deliver);
                    FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_Deliver.FAMoveToElement();
                    FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverImageDoc);
                    FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverPrint.FAMoveToElement();
                    var imageDoc = FastDriver.NextGenDocumentRepository.AssociateDocumentPackages_DeliverImageDoc;
                    var imageDocActions = new OpenQA.Selenium.Interactions.Actions(FastDriver.WebDriver).MoveToElement(imageDoc);
                    imageDocActions.Click().Perform();

                    FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                    FastDriver.ImageDocDlg.WaitForScreenToLoad();
                    FastDriver.ImageDocDlg.ImageDoc.FAClick();
                    FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc);

                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    #endregion
                }
                #endregion
                Reports.TestStep = "Verify for all the imagdoc versions";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.VersionIcon);
                FastDriver.NextGenDocumentRepository.VersionIcon.Click();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.VersionIcon);
                // FastDriver.NextGenDocumentRepository.DocTableRows.PerformTableAction("Name", "SEC-OPK-Open Order Documents", "Name", TableAction.Click);
                int DocCount = FastDriver.NextGenDocumentRepository.DocTableRows.FindElements(OpenQA.Selenium.By.Id("DocumentName")).Count;
                int count = 0;
                for (int j = 0; j < DocCount; j++)
                {
                    string hrh = FastDriver.NextGenDocumentRepository.DocTableRows.FindElements(OpenQA.Selenium.By.Id("DocumentName"))[j].Text;
                    if (hrh == "SEC-OPK-Open Order Documents 1")
                        count++;
                }

                Support.AreEqual("5", count.ToString());

               
            }
            catch
            {}
        }
    

        #endregion

        #region TestCase_908718-Verify system displays all the versions of the imagedoc - RTM package
        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void TC_908718()
        {
            try
            {
                Reports.TestDescription = "Verify Creating RTM package and perform imagedoc Delivery mutliple times and verify the versions";

            
                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

               
                    #region Click on Upload button
                    Reports.TestStep = "Click on Upload button";
                    FastDriver.NextGenDocumentRepository.Upload.FAClick();
                    #endregion

                    #region Browse document
                    Reports.TestStep = "Browse document";
                    string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                    FastDriver.UploadDocumentDlg.UploadFile(filePath);
                    #endregion
                    #region Save the PDF Document
                    Reports.TestStep = "Save the PDF Document";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                    FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Misc", "SEC-OPK-Open Order Documents", "");
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    #endregion

                    #region Navigate to Document Repository Screen
                    Reports.TestStep = "Navigate to Document Repository Screen";
                    
                     FastDriver.NextGenDocumentRepository.Open();
                    #endregion

                    #region Verify that Document is uploaded to the FAST
                    Reports.TestStep = "Verify that Document is uploaded to the FAST";
                    var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("SEC-OPK-Open Order Documents", "Escrow: Misc");
                    Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                    #endregion
                    #region Click on Upload button
                    Reports.TestStep = "Click on Upload button";
                    FastDriver.NextGenDocumentRepository.Upload.FAClick();
                    #endregion

                    #region Browse document
                    Reports.TestStep = "Browse document";
                    filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                   
                    FastDriver.UploadDocumentDlg.UploadFile(filePath);
                    #endregion
                    #region Save the PDF Document
                    Reports.TestStep = "Save the PDF Document";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
                    FastDriver.SaveDocumentDlg.SaveMisDocument(@"Miscellaneous", "SEC-Escow Information Sheet");
                   // FastDriver.SaveDocumentDlg.DocumentNameText.FASetText("SEC-Escow Information Sheet");
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    #endregion

                    #region Navigate to Document Repository Screen
                    Reports.TestStep = "Navigate to Document Repository Screen";
                    FastDriver.NextGenDocumentRepository.Open();
                    #endregion

                    #region Verify that Document is uploaded to the FAST
                    Reports.TestStep = "Verify that Document is uploaded to the FAST";
                    docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("SEC-Escow Information Sheet", "Miscellaneous");
                    Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                    #endregion

                Reports.TestStep = "Create RTM Package";
                FastDriver.NextGenDocumentRepository.SelectAllDocuments();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "SEC-OPK-Open Order Documents", "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.AddToRTMPackage.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.RTMPakageRadio.FASetCheckbox(true);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #region Select Mail To address
                Reports.TestStep = "Select Mail To address";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.MailTo);
                FastDriver.NextGenDocumentRepository.MailTo.FAClick();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.SelectAddresses);
                FastDriver.NextGenDocumentRepository.SelectAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Select File Business Parties
                Reports.TestStep = "Select File Business Parties";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.FileBusinessPartyTable.PerformTableAction(6, "Business Source", 1, TableAction.On);
                FastDriver.NextGenDocumentRepository.DoneSearchAddresses.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Select Return To address
                Reports.TestStep = "Select Return To address";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.ReturnTo);
                FastDriver.NextGenDocumentRepository.ReturnTo.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.OfficeSelection);
                FastDriver.NextGenDocumentRepository.OfficeSelection.FASelectItemByIndex(1);
                FastDriver.NextGenDocumentRepository.DoneRTMPackages.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Select Return To address
                Reports.TestStep = "Click on Packages link";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.Packages.FASelectContextMenuItem(); // Send Enter key to the control
                FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.RTMPackageLink);
                #endregion
                int i = 1;
                for (i = 1; i <= 5; i++)
                {

                    Reports.TestStep = "Perform ImageDoc Delivery";
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    FastDriver.NextGenDocumentRepository.FirstRTMPackage.FARightClick();
                    FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.DeliverRTM);
                    FastDriver.NextGenDocumentRepository.DeliverRTM.FAMoveToElement();
                    FastDriver.NextGenDocumentRepository.WaitCreation(FastDriver.NextGenDocumentRepository.ImageDocRTM);
                    //FastDriver.NextGenDocumentRepository.PrintRTM.FAMoveToElement();
                    FastDriver.NextGenDocumentRepository.ImageDocRTM.JSClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc");
                    FastDriver.ImageDocDlg.WaitForScreenToLoad();
                    FastDriver.ImageDocDlg.ImageDoc.FAClick();
                    FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 200);

                }

                Reports.TestStep = "Verify for all the imagdoc versions";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.VersionIcon);
                FastDriver.NextGenDocumentRepository.VersionIcon.Click();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.VersionIcon);
                // FastDriver.NextGenDocumentRepository.DocTableRows.PerformTableAction("Name", "SEC-OPK-Open Order Documents", "Name", TableAction.Click);
                int DocCount =FastDriver.NextGenDocumentRepository.DocTableRows.FindElements(OpenQA.Selenium.By.Id("DocumentName")).Count;
                int count1= 0;
                for (int j = 0; j < DocCount; j++)
                {
                    string hrh = FastDriver.NextGenDocumentRepository.DocTableRows.FindElements(OpenQA.Selenium.By.Id("DocumentName"))[j].Text;
                    if (hrh == "SEC-OPK-Open Order Documents 1")
                        count1++;
                }

                Support.AreEqual("5", count1.ToString());

                int docName = FastDriver.NextGenDocumentRepository.DocTableRows.PerformTableAction(7, "SEC-OPK-Open Order Documents 1", 7, TableAction.GetAttribute).CurrentRow;
                Support.AreEqual(docName.ToString(), "SEC-OPK-Open Order Documents 1", "Document exists on the Search Result Table");                
            }

            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

    }

    }


        


  