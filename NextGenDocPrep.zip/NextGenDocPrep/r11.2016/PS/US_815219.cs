﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Windows.Input;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using FASTSelenium.DataObjects;

namespace NextGenDocPrep.Enhancement
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class US_815219 : FASTHelpers
    {
        // Maybe these should be in Config?
        private static int _regionId = 12837;   // QA Sandpointe - Next Gen
        private static int _officeId = 12839;   // QA Sandpointed Office - Next Gen
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            var nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS"; 
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionId) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void LoadTemplateOrCreateNew(string templateName, string templateDesc, string templateType)
        {
            

            FAST_Login_ADM(isSuperUser: false);

            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Endrosement two phrase ***AUTOMATION DNT***");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Endrosement two phrase ***AUTOMATION DNT***", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        private void LoadTemplateOrCreateNewWithoutLogin(string templateName, string templateDesc, string templateType)
        {
            
            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (!templateExists)
            {
                Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplatesTab);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                //
                Reports.TestStep = "Search for template using template search criteria";
                FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Endrosement two phrase ***AUTOMATION DNT***");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Endrosement two phrase ***AUTOMATION DNT***", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.CopyTemplate.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                Playback.Wait(3000);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
        }

        private void InsertPhrase(string tplPhraseName, string phraseDescription)
        {
            FastDriver.DocumentEditor.InsertPhraseBelowAndSave(tplPhraseName, phraseDescription);
        }
       
         [TestMethod]
        public void ITR_r12_2016_US_815219()
        {
            try
            {

                Reports.TestDescription = "User Story: 781362- Verify that system will display the selection popup on creating documents having '?' indexed data elements obtained by keyword search";


                string EG1tempnameanddesc = Support.RandomString("ANANANANAN").ToString();
                EG1tempnameanddesc = "EG1-" + EG1tempnameanddesc;

                string EG2tempnameanddesc = Support.RandomString("NANANANANA").ToString();
                EG2tempnameanddesc = "EG2-" + EG2tempnameanddesc;

              
                string KewwordValue = Support.RandomString("NNAANNAANNAANNAANNAAN").ToString();

                EnableSavingIRSamples();
                SetSilverlightClipboardPermission_YES();
                
                FAST_Login_ADM(isSuperUser: false);
                FAST_OpenRegionOrOffice(officeId);

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create new phrase group
                Reports.TestStep = "Create new phrase group";
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                var groupName = Support.RandomString("ANAN");
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);
                var groupDescription = "TEST--" + Support.RandomString("AN".Repeat(17));
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);
                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem("Endorsement Phrase[ENDORSE]");
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                #endregion

                #region Create phrases
                Reports.TestStep = "Create phrases";
                FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                var phraseName = Support.RandomString("ANAN");
                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);
                var phraseDescription = "TEST--" + Support.RandomString("AN".Repeat(17));
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                #endregion

                #region Add data element
                Reports.TestStep = "Add data element";
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.InsertDataElementwithIDandIndex("BUNAME, SENAME","?");
               
                #endregion

                #region Create template
                Reports.TestStep = "Create template";
                                
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);

                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(EG1tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(EG1tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                #endregion

                #region Insert Phrases
                Reports.TestStep = "Insert Phrases";
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertPhrase(groupName + "/" + phraseName, phraseDescription);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status") == "true")
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    // just to make sure !
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                    FastDriver.NextGenDocumentPreparation.Inactive.FAClick();
                    FastDriver.NextGenDocumentPreparation.Active.FAClick();
                }
                Support.AreEqual("false", FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status"));
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                #region Create template
                Reports.TestStep = "Create template";

                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);

                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(EG2tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(EG2tempnameanddesc);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem("Endorsement/Guarantee");
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                FastDriver.NextGenDocumentPreparation.TemplateKeys.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                #endregion

                #region Insert Phrases
                Reports.TestStep = "Insert Phrases";
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertPhrase(groupName + "/" + phraseName, phraseDescription);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status") == "true")
                {
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    // just to make sure !
                    FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                    FastDriver.NextGenDocumentPreparation.Inactive.FAClick();
                    FastDriver.NextGenDocumentPreparation.Active.FAClick();
                }
                Support.AreEqual("false", FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("status"));
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                #endregion

                         

                Reports.TestStep = "FAST IIS Login";

                FAST_Login_IIS(regionId: regionId);
                FAST_OpenRegionOrOffice(officeId);

                #region Create File
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("HUDFLINSR1");
                FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
                FastDriver.QuickFileEntry.DirectedBYGABcode.FASetText("HUDLEASE03");
                FastDriver.QuickFileEntry.DirectedBYFind.FAClick();
                if (!FastDriver.QuickFileEntry.Title.Selected)
                    FastDriver.QuickFileEntry.Title.FAClick();
                if (!FastDriver.QuickFileEntry.Escrow.Selected)
                    FastDriver.QuickFileEntry.Escrow.FAClick();
                FastDriver.QuickFileEntry.BusinessSegment.FASelectItemBySendingKeys("Residential");
                FastDriver.QuickFileEntry.TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

                FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("J305");
                FastDriver.QuickFileEntry.PropertyBookAddrLin2.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyBookAddrLin3.FASetText("JJEJAMQ");
                FastDriver.QuickFileEntry.PropertyCity.FASetText("ALBANY");
                FastDriver.QuickFileEntry.PropertyState.FASelectItemBySendingKeys("CA");
                FastDriver.QuickFileEntry.PropertyZip.FASetText("12345");
                FastDriver.QuickFileEntry.PropertyCounty.FASetText("ALAMEDA");
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");

                FastDriver.QuickFileEntry.Seller1Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItemBySendingKeys("Individual");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");

                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("247");
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                FastDriver.QuickFileEntry.AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
                FastDriver.QuickFileEntry.AssociatedBusinessPartyFind.FAClick();
                FastDriver.QuickFileEntry.NoteType.FASelectItemBySendingKeys("EPIC");
                FastDriver.QuickFileEntry.Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
                Playback.Wait(1000);
                try
                {
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    FastDriver.BottomFrame.Done();
                }
                FastDriver.FileHomepage.WaitForScreenToLoad();

                #endregion

               
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                Reports.TestStep = "Click on Template Search button";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();

                Reports.TestStep = "Search for the templates created in ADM";
               

                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("All");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.TagName, "IMG").FAClick();
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.DataTable.FAFindElement(ByLocator.Id, "ddl_FilterTypes_2").FASelectItem("Keywords");
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.keywordsValues.FASetText(KewwordValue);
                Playback.Wait(3000);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                Playback.Wait(7000);

                Reports.TestStep = "Select the template from Template Results , Right click and select Create All Documents";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction(4, EG1tempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.Highlight();
                Support.AreEqual("True", FastDriver.NextGenDocumentRepository.CreateAllDocuments.IsEnabled().ToString(), "Create All Documents option is enable");
                FastDriver.NextGenDocumentRepository.CreateAllDocuments.FASelectContextMenuItem();
                Playback.Wait(5000);

                Reports.TestStep = "Select the document Right-Click and select 'PhraseView/Edit' option from context";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(4, EG1tempnameanddesc, 4, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.ViewEdit.FASelectContextMenuItem();

                

                //string errormsg = FastDriver.WebDriver.HandleDialogMessage();
                //errormsg = errormsg.ToUpper().Replace("\n", "").Replace("\t", "").Trim();
                //Support.AreEqual(errormsg, "DO YOU WISH TO CREATE ALL TEMPLATES?", "Error Message Verified");

                //Playback.Wait(5000);
                //FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                //FastDriver.NextGenDocumentRepository.MultiIndexValueTable1.PerformTableAction(2,1, TableAction.Click);
                //FastDriver.NextGenDocumentRepository.MultiIndexValueTable2.PerformTableAction(3, 1, TableAction.Click);

                //Keyboard.SendKeys("{TAB}");
                //Keyboard.SendKeys("{TAB}");
                //Keyboard.SendKeys("{ENTER}");

                //Playback.Wait(2000);

                //FastDriver.NextGenDocumentRepository.MultiIndexValueTable1.PerformTableAction(3, 1, TableAction.Click);
                //FastDriver.NextGenDocumentRepository.MultiIndexValueTable2.PerformTableAction(2, 1, TableAction.Click);

                //Keyboard.SendKeys("{TAB}");
                //Keyboard.SendKeys("{TAB}");
                //Keyboard.SendKeys("{ENTER}");
                //Playback.Wait(5000);

                //Reports.TestStep = "Verify Created Document in File Documents Table grid";
                //FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                //Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EG1tempnameanddesc).ToString(), "Endorsement1- Added");
                //Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EG2tempnameanddesc).ToString(), "Endorsement2- Added");

                //FastDriver.NextGenDocumentRepository.Open();
                //FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                //Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EG1tempnameanddesc).ToString(), "Endorsement1- Added");
                //Support.AreEqual("True", FastDriver.NextGenDocumentRepository.DocumentsTable.FeeExistOnTable(EG2tempnameanddesc).ToString(), "Endorsement2- Added");
               

            }


            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
         [ClassCleanup]
         public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }


}
