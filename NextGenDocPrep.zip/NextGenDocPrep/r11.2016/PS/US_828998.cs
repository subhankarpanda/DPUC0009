﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.IIS;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;

namespace NextGenDocPrep.r11._2016.PS
{
   [CodedUITest]
   public class US_828998 : FASTHelpers
    {

       [TestMethod]
       [Description("US#828998 - Prod- Outline Properties option is disabled in ADM")]
       public void TestCase_907001()
       {
           try
           {

               Reports.TestDescription = "Test Case#907001 - Validate outline properties option in editor is disabled for finalized document | Phrase View";

               #region Login Fast
               Reports.TestStep = "Login into the IIS Side.";
               FAST_Login_IIS();
               #endregion

               #region Office selection
               Reports.TestStep = "Navigate to QA Sandpointe NG Region";
               FastDriver.SecuritySelectRegionOffice.Open();
               FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
               #endregion

               #region File Creation
               CreateFile();
               #endregion

               #region Navigate to Document Repository screen
               Reports.TestStep = "Navigate to NextGen Document Repository/Templates Search";
               FastDriver.NextGenDocumentRepository.Open();
               FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
               FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

               #endregion

               #region Create any document from template search
               Reports.TestStep = "Create any document from template search";
               FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
               FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Title Reports");
               FastDriver.NextGenDocumentRepository.Search.FAClick();
               FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 1, TableAction.Click).Element.FAClick();
               var tempName = FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(2, 3, TableAction.GetText).Message;
               FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
               FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText("05/17/2016");
               FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
               FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
               if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
               {
                   Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(tempName).ToString());
               }
               else
               {
                   Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
               }
               #endregion

               #region Select the document and edit it by right click option
               Reports.TestStep = "Select the document and edit it by right click option";
               FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempName, "Name", TableAction.GetCell).Element.FARightClick();
               FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
               FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
               FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
               FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
               FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
               #endregion

               #region Select Finalized from Status drop down
               Reports.TestStep = "Select Finalized from Status drop down";
               FastDriver.NextGenDocumentRepository.DocumentStatus.FASelectItemBySendingKeys("Finalized");
               FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();   
               #endregion

               #region Select a phrase and right click
               Reports.TestStep = "Select a phrase and right click";
               FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
               FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait", false);
               FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();
               FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.PhraseDataElementTable);
               FastDriver.NextGenDocumentRepository.PhraseDataElementTable.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
               FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
               
               //Edit Phrase disabled
               FastDriver.NextGenDocumentRepository.DEContextMenu.FAMouseOver();
               FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
               FastDriver.NextGenDocumentRepository.ContextMenuSeparator(".edit.separator");
               
 
               //Edit Section Break disabled
               FastDriver.NextGenDocumentRepository.EditSectionBreak.FAMouseOver();
               FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
               FastDriver.NextGenDocumentRepository.ContextMenuSeparator(".editSB.separator");
   
               //Insert Phrase disabled
               FastDriver.NextGenDocumentRepository.PhrasesInsert.FAMouseOver();
               FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
               FastDriver.NextGenDocumentRepository.ContextMenuSeparator(".insert.separator");

               //Move option disabled
               FastDriver.NextGenDocumentRepository.PhraseContextMove.FAMouseOver();
               FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
               FastDriver.NextGenDocumentRepository.ContextMenuSeparator(".move.separator");

               //Delete option disabled
               FastDriver.NextGenDocumentRepository.PhraseContextDelete.FAMouseOver();
               FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
               FastDriver.NextGenDocumentRepository.ContextMenuSeparator(".delete.separator");
               #endregion


           }
           catch (Exception ex)
           {
               FailTest(GetExceptionInfo(ex));
           }


       }
       #region custom methods
       private void FAST_SU_IIS_Login(bool isSuperUser = true, int? regionId = null)
       {
           #region FAST Login IIS
           Reports.TestStep = "FAST Login IIS";
           var credentials = new Credentials() { UserName = isSuperUser ? AutoConfig.UserNameSU : AutoConfig.UserName, Password = isSuperUser ? AutoConfig.UserPasswordSU : AutoConfig.UserPassword };
           FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

           if (regionId != null)
               FAST_OpenRegionOrOffice(regionId ?? 0);
           #endregion
       }
       private void CreateFile()
       {
           Reports.TestStep = "Create a basic file with insurance and buyer/seller information";

           #region Create a  File
           Reports.TestStep = "Create a file";
           FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
           try
           {
               FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
               FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
           }
           catch
           {
               Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
           }
           FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
           Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD | Buyer/Seller Info | Lender";
           FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
           FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
           FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
           FastDriver.QuickFileEntry.SelectState("MS");
           FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
           FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFirstName");
           FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLastName");
           FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
           FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFirstName");
           FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLastName");
           FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("248");
           FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
           FastDriver.BottomFrame.Done();
           FastDriver.FileHomepage.WaitForScreenToLoad();
           String FileNum = FastDriver.FileHomepage.txtFileNumber.FAGetValue();
           #endregion

           #region Setting New Loan Insurance
           Reports.TestStep = "Set New Loan Insurance Information and Loan Number";
           FastDriver.NewLoan.Open();
           FastDriver.NewLoan.WaitForScreenToLoad();
           FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("0123456");
           FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("0123");
           FastDriver.BottomFrame.Done();
           #endregion
       }
       private void SavePDFFile(string PDFFilePath)
       {
           try
           {
               //TODO: Need to convert this to AutoIt
               Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
               BrowserWindow AdobeReaderwin = new BrowserWindow();
               UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

               for (int i = 0; i < Browsercnt.Count; i++)
               {
                   if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                   {
                       AdobeReaderwin.Maximized = true;
                       break;
                   }
               }

               Playback.Wait(5000);

               Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
               Playback.Wait(2000);
               FastDriver.WebDriver.HandleAdobeReaderDialog(false, true, 5);

               Playback.Wait(2000);
               Keyboard.SendKeys("{N}", ModifierKeys.Alt);

               Keyboard.SendKeys(PDFFilePath);
               Playback.Wait(2000);

               Keyboard.SendKeys("{S}", ModifierKeys.Alt);
               Playback.Wait(5000);
               FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true, 5);

               Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
               Playback.Wait(7000);
               Support.CloseAllProcessStartingWith("AcroRd32");
               Support.CloseAllProcessStartingWith("Acrobat");

           }
           catch (Exception)
           {
               //Sometimes the preview window doesn't have name
               Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
               Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
               Playback.Wait(2000);
               FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This check the do not show this message again
               FastDriver.WebDriver.HandleDialogMessage(false, true, 5); //This close the dialog

               Keyboard.SendKeys("{N}", ModifierKeys.Alt);
               Keyboard.SendKeys(PDFFilePath);
               Playback.Wait(5000);

               Keyboard.SendKeys("{S}", ModifierKeys.Alt);
               Playback.Wait(10000);
               FastDriver.WebDriver.HandleDialogMessage(false, true, 5);

               Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
               Playback.Wait(7000);
               Support.CloseAllProcessStartingWith("AcroRd32");
               Support.CloseAllProcessStartingWith("Acrobat");

           }
       }
       #endregion
       [ClassCleanup]
       public static void ClassCleanup()
       {
           MasterTestClass.CleanupClass();
       }
    }
}
