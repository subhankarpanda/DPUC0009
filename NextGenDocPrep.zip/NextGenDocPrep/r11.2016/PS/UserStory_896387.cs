﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NextGenDocPrep.r11._2016.PS
{
    [CodedUITest]
    [DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
    public class UserStory_896387 : FASTHelpers
    {
        #region Data Setup
        public static int _regionId = 12837;
        public static int _officeId = 12839;

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }

        #endregion

        #region Private Methods

        private FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = RequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = officeId;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = regionId;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = officeId;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionId);

            return nextGenRequest;
        }

        private bool FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(regionId);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        private bool WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }
        #endregion

        [TestMethod]
        [DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        [DeploymentItem(@"Common\Support\RemoveDLLs32bit.bat")]
        [DeploymentItem(@"Common\Support\RemoveDLLs64bit.bat")]
        [Description("Verify For Starter Ref copied documents user should be able to edit document Name")]
        public void TestCase_903995()
        {
            try
            {
                Reports.TestDescription = "Verify For Starter Ref copied documents user should be able to edit document Name";

                #region Login to File side and change office to NextGen
                Reports.TestStep = "Login to FAST file side";
                FAST_Login_IIS(regionId: officeId);
                FAST_OpenRegionOrOffice(officeId);
               
                #endregion

                #region Create a file (Starter)
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                #endregion

                #region Navigate to Document repository
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Click on Template Search button and select any document form the search results and create document
                Reports.TestStep = "Click on Template Search button and search for any template using template search criteria";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForTemplateSearchTabToLoad();
                FastDriver.NextGenDocumentRepository.SearchScope.FASelectItem("All Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText("NEXTGEN_SAN_EscrowInstruction_DoNotTouch");
                FastDriver.NextGenDocumentRepository.StateValue_CA.FAClick();
                FastDriver.NextGenDocumentRepository.StateValue_All.FAClick();
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait...", true, 60);
                Reports.TestStep = "Select the template from Template Results , Right click and select Create Document";
                FastDriver.NextGenDocumentRepository.TemplatesTable.PerformTableAction("Description","NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Description", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.CreateDocument.FASelectContextMenuItem();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please wait,document is getting created...", true, 60);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Click on Scan button
                Reports.TestStep = "Click on Scan button";
                FastDriver.NextGenDocumentRepository.Scan.FAClick();
                if (FastDriver.WebDriver.WaitForAlertToExist(5))
                {
                    if (!(System.IO.File.Exists(Reports.DEPLOYDIR + "\\RemoveDLLs64bit.bat") || System.IO.File.Exists(Reports.DEPLOYDIR + "\\RemoveDLLs32bit.bat")))
                        throw new ImageBenchException("Image Bench is outdated (must delete older files)");
                    else
                        FastDriver.WebDriver.HandleDialogMessage(true, true);
                }
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Click on Open button and load the image document           
                Reports.TestStep = "Click on Open button and load the image document";
                FastDriver.ImagingWorkBench.WaitForWindowToLoad();
                //FastDriver.ImagingWorkBench.IROpen.FAClick();
                FastDriver.ImagingWorkBench.ClickOpen();
                FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)
                #endregion

                #region Save the TIF Document
                Reports.TestStep = "Save the TIF Document";
                FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt("Exchange : Delayed", "MISCELLANEOUS", "AFFIX INV");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion

                #region Verify that Document is scanned to the FAST
                Reports.TestStep = "Verify that Document is scanned to the FAST";
                var docStatus = FastDriver.NextGenDocumentRepository.WaitForDocument("AFFIX INV", "Exchange : Delayed");
                Support.AreEqual("True", docStatus.ToString(), "Document exists on the table");
                #endregion

                #region Read the file Number from the file home Page
                FastDriver.FileHomepage.Open();
                string fileno = FastDriver.FileHomepage.GetFileNumber();
                #endregion

                #region Create another File (Reference)
                Support.IsTrue(WCF_CreateFile() || FAST_CreateFile(), "File created successfully");
                
                #endregion

                #region Perform Starter/Ref Copy Documents from (Starter) File to (Reference) File
                FastDriver.StarterReference.Open();
                FastDriver.StarterReference.StarterFileNumber.FASetText(fileno);
                FastDriver.StarterReference.CopyDocument.FASetCheckbox(true);
                FastDriver.CopyDocuments.WaitForScreenToLoad();
                FastDriver.CopyDocuments.SelectAll.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.StarterReference.WaitForScreenToLoad();
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Copying...", true, 60);
                FastDriver.StarterReference.WaitForScreenToLoad();
                Playback.Wait(5000);
                #endregion

                #region Verify in the Event/Tracking log Starter Ref Completion
                Reports.TestStep = "Verify in the Event/Tracking log Starter Ref Completion";
                FastDriver.EventTrackingLog.Open();
                var watch = Stopwatch.StartNew();
                while (watch.ElapsedMilliseconds <= 120 * 1000) // 120 Seconds
                {
                    FastDriver.EventTrackingLog.Open();
                    if (FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Starter Ref Copy Documents Completed]", "Event", TableAction.Click).Element.IsVisible() && FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Starter Ref Copy Images Completed]", "Event", TableAction.Click).Element.IsVisible())
                    {
                        break;
                    }
                }
                watch.Stop();

                #endregion

                #region Navigate to Document Repository Screen and verify for Edit Document Name and Edit Image for documents
                Reports.TestStep = "Navigate to Document Repository Screen and verify for Edit Document Name and Edit Image for documents";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "NEXTGEN_SAN_EscrowInstruction_DoNotTouch", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.EditDocumentName.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.EditDocument_DocumentName);
                string newdocumentname = Support.RandomString("ANANANANAN");
                FastDriver.NextGenDocumentRepository.EditDocument_DocumentName.FASetText(newdocumentname);
                FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", newdocumentname, "Name", TableAction.Click);
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", "MISCELLANEOUS AFFIX INV", "Name", TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.EditImage.FASelectContextMenuItem();
                if (FastDriver.ImagingWorkBench.ImagingWorkbench.IsVisible() == true)
                {
                  Reports.StatusUpdate("Edit Image is enabled",true);

                }
                else
                {
                    Reports.StatusUpdate("Edit Image is disabled", true);
                }
                FastDriver.NextGenDocumentRepository.EditDocumentName.FASelectContextMenuItem();                
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad(FastDriver.NextGenDocumentRepository.EditDocument_DocumentName);
                string newimagedocname = Support.RandomString("AAANNNANANA");
                FastDriver.NextGenDocumentRepository.EditDocument_DocumentName.FASetText(newimagedocname);
                FastDriver.NextGenDocumentRepository.EditDocument_Done.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", newimagedocname, "Name", TableAction.Click);

                #endregion

            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        [TestInitialize]
        public override void TestInitialize()
        {
            CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
        
    }
}
