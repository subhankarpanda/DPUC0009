﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.IIS;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;

namespace NextGenDocPrep.r11._2016.PS
{
    [CodedUITest]
    public class US_909550 : FASTHelpers
    {
        [TestMethod]
        [Description("User Story 909550 - INC3175844-DocGen-Image View Event Category not tracking all image views")]
        public void TestCase_909566()
        {

            try
            {
                Reports.TestDescription = "Test Case 909566 - Validate Event/Tracking Log tracks images view per thumbnail";

                #region Data set up
                String tempName = "IMGVTE";
                String tempDesc = "Images View Template";
                String Temptype = "Title Reports";
                String Phrasecode = "TP13/27";
                #endregion


                #region Methods call
                LoadOrCreateTemp(tempName, tempDesc, Temptype);
                AddPhrase(tempDesc, Temptype, Phrasecode);
                #endregion

                //Login to FAST
                #region Login Fast
                Reports.TestStep = "Login into the IIS Side.";
                FAST_SU_IIS_Login(isSuperUser: false);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NextGen region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");
                #endregion

                #region Create file
                CreateFile();
                #endregion

                #region Navigate to document Repository
                Reports.TestStep = "Navigate to document Repository screen";
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Search and add a document
                Reports.TestStep = "Search and add for a document";
                FastDriver.NextGenDocumentRepository.TemplateSearchButton.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.TemplateCriteria.FASelectItem("Filtered Templates");
                FastDriver.NextGenDocumentRepository.TemplateTypeSelect.FASelectItem(Temptype);
                FastDriver.NextGenDocumentRepository.TemplateDescription.FASetText(tempDesc);
                FastDriver.NextGenDocumentRepository.Search.FAClick();
                FastDriver.NextGenDocumentRepository.TableResultsTemplateSearchTAB.PerformTableAction(1, 1, TableAction.Click).Element.FAClick();
                FastDriver.NextGenDocumentRepository.DocumentInfoTab.FAClick();
                FastDriver.NextGenDocumentRepository.DocInfo_EffectiveDate.FASetText(DateTime.Now.Date.ToString("MM/dd/yyyy"));
                FastDriver.NextGenDocumentRepository.DocInfo_CreateSave.FAClick();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                    Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable(tempDesc).ToString());
                }
                else
                {
                    Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
                }
                #endregion

                #region Select the added Document and perform Image Doc delivery
                Reports.TestStep = "Select the added Document and perform Image Doc delivery";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction("Name", tempDesc, "Name", TableAction.GetCell).Element.FARightClick();
                FastDriver.NextGenDocumentRepository.SwitchToContentFrame();
                FastDriver.NextGenDocumentRepository.DeliveriesNGDocRep("ImageDoc");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc -- Webpage Dialog");
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc);
                Playback.Wait(20000);
                #endregion

                #region Click on the imaged document PDF thumbnail
                FastDriver.NextGenDocumentRepository.Open();
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
               if (FastDriver.NextGenDocumentRepository.DocumentsTable.IsDisplayed())
                {
                   while (!FastDriver.NextGenDocumentRepository.DocumentsTable.StringExistOnTable("Imaged",false))
                   {
                       FastDriver.NextGenDocumentRepository.Open();
                       FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                   }

                    FastDriver.NextGenDocumentRepository.PdfViewerIcon.FAClick();
                    FastDriver.WebDriver.ClosePreviewWindow();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                }
                #endregion

                #region Navigate to Event/tracking Log and validate delivery
                Reports.TestStep = "Navigate to Event/tracking Log and validate delivery";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventCategory.FASelectItemBySendingKeys("Image View");
                Playback.Wait(1000);
                FastDriver.EventTrackingLog.WaitForWindowToLoad();
                var imageViewServiceComment = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Image View]", "Comments", TableAction.GetText).Message;
                Support.AreEqual("True", imageViewServiceComment.Contains(tempDesc).ToString(), "Verify Image View Service Comments contains 'Documents: " + tempDesc + "'");
                Support.AreEqual("True", imageViewServiceComment.Contains("Delivery Method: Print Preview").ToString(), "Verify Image View Service Comments contains 'Delivery Method: Print Preview'");
                Support.AreEqual("True", imageViewServiceComment.Contains("Delivery Successful").ToString(), "Verify Image View Service Comments contains 'Delivery Successful'");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #region custom methods
        private void FAST_SU_IIS_Login(bool isSuperUser = true, int? regionId = null)
        {
            #region FAST Login IIS
            Reports.TestStep = "FAST Login IIS";
            var credentials = new Credentials() { UserName = isSuperUser ? AutoConfig.UserNameSU : AutoConfig.UserName, Password = isSuperUser ? AutoConfig.UserPasswordSU : AutoConfig.UserPassword };
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            if (regionId != null)
                FAST_OpenRegionOrOffice(regionId ?? 0);
            #endregion
        }
        private void CreateFile()
        {
            Reports.TestStep = "Create a basic file with insurance and buyer/seller information";

            #region Create a  File
            Reports.TestStep = "Create a file";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
            try
            {
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            }
            catch
            {
                Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
            }
            FastDriver.QuickFileEntry.FindBusinessSourceByGABCode("255");
            Reports.TestStep = "Define services Title+Escrow | Transaction Type = Sale w/o Mortgage | Form type = CD | Buyer/Seller Info | Lender";
            FastDriver.QuickFileEntry.SelectServiceTypeTitle(true);
            FastDriver.QuickFileEntry.SelectServiceTypeEscrow(true);
            FastDriver.QuickFileEntry.SelectTransactionType("Sale w/Mortgage");
            FastDriver.QuickFileEntry.SelectState("CA");
            FastDriver.QuickFileEntry.PropertyInformationType.FASelectItem("Single Family Residence");
            FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("BuyerFirstName");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("BuyerLastName");
            FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Seller1FirstName.FASetText("SellerFirstName");
            FastDriver.QuickFileEntry.Seller1LastName.FASetText("SellerLastName");
            FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText("248");
            FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
            FastDriver.BottomFrame.Done();
            FastDriver.FileHomepage.WaitForScreenToLoad();
            String FileNum = FastDriver.FileHomepage.txtFileNumber.FAGetValue();
            #endregion

            #region Setting New Loan Insurance
            Reports.TestStep = "Set New Loan Insurance Information and Loan Number";
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.WaitForScreenToLoad();
            FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("0123456");
            FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("0123");
            FastDriver.BottomFrame.Done();
            #endregion
        }
        private void LoadOrCreateTemp(string templateName, string templateDesc, string templateType)
        {
            Reports.TestStep = "Create Template";

            FAST_Login_ADM(isSuperUser: false);

            #region Region selection
            Reports.TestStep = "Navigate to QA Sandpointe NextGen region";
            FastDriver.SecuritySelectRegionOffice.Open();
            FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
            #endregion

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Verify that Template is present
            Reports.TestStep = "Check Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            #region Create Template if not created
            Reports.TestStep = "Create Template if not created";
            if (!templateExists)
            {
                Reports.TestStep = "Creating Template " + templateDesc;
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FADoubleClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templateDesc);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.Templates_FilteringTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("change.. please wait...", false);
                if (true)
                {
                    FastDriver.NextGenDocumentPreparation.AddFilterGroup.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.NextGenDocumentPreparation.SuggestedFilter.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(".. please wait...", false);
                    FastDriver.GeograficFilterSelectionDlg.ServiveTypeCheck.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.UnderwriterSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.OwningOfcSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProductTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.PropertyTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.TransactionTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.BusinessSegmentSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.ProgramTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.SearchTypeSelectAll.FAClick();
                    FastDriver.GeograficFilterSelectionDlg.DoneButton.FAClick();
                }

                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDesc + " already exist", true);
            }
            #endregion
        }
        private void AddPhrase(String TempDesc, String Temptype, String Phrasecode)
        {

            FAST_Login_ADM(isSuperUser: false);

            #region Region selection
            Reports.TestStep = "Navigate to QA Sandpointe NextGen region";
            FastDriver.SecuritySelectRegionOffice.Open();
            FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");
            #endregion

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Navigate to NextGen Document Preparation/Templates Search
            Reports.TestStep = "Navigate to NextGen Document Preparation/Templates Search";
            FastDriver.NextGenDocumentPreparation.Open(element: FastDriver.NextGenDocumentPreparation.TemplatesTab);
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            #endregion

            #region Search Policy Template and add phrases to it
            Reports.TestStep = "Search Template by Type & Description";
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(Temptype);
            FastDriver.NextGenDocumentPreparation.TemplateSearchRegions.FAClick();
            FastDriver.NextGenDocumentPreparation.AllRegions.FASetCheckbox(true);
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(TempDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable);

            if (FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.IsDisplayed())
            {

                //Select Template for Edit
                Support.AreEqual(false.ToString(), FastDriver.NextGenDocumentPreparation.TemplateResultsTable.StringExistOnTable(TempDesc).ToString());
                FastDriver.NextGenDocumentPreparation.TemplateSearchResultTable.PerformTableAction(1, 1, TableAction.Click).Element.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
                FastDriver.NextGenDocumentPreparation.Templates_PhrasesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. Please wait...", false);
                Playback.Wait(25000);
                var PhraseTable = FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.GetAttribute("textContent");
                var PhraseExists = PhraseTable.Contains(Phrasecode);
                var UCcheckbox = FastDriver.NextGenDocumentPreparation.UnderConstruction.IsSelected();

                if (!PhraseExists)
                {
                    //Click for Insert Phrase menu from Phrases sub-tab
                    Reports.TestStep = "Insert Phrases Option in Menu Context ";
                    FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent.PerformTableAction(1, 1, TableAction.Click, "").Element.FARightClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentPreparation.PhrasesInsert.FAMouseOver();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentPreparation.PhraseBelowContext.FAMouseOver();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);
                    FastDriver.NextGenDocumentPreparation.BelowPhraseContext.FASelectContextMenuItem();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false);

                    //Insert Phrase which contains Policy Issue Date from Corporate
                    Reports.TestStep = "Phrases Selection Dialogue";
                    FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                    FastDriver.PhraseSelectDlg.Source.FASelectItem("Corporate");
                    FastDriver.PhraseSelectDlg.PhraseName.FASetText(Phrasecode);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.HandleDialogMessage();

                    //Save and Remove Under Construction Checkbox
                    Reports.TestStep = "Click Save and Under Construction ";
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhrasesTAbleContent);
                    if (UCcheckbox == true)
                    {
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    }
                    FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                }
                else
                {
                    //Save and Remove Under Construction Checkbox
                    Reports.TestStep = "Click Save and Under Construction ";
                    if (UCcheckbox == true)
                    {
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    }
                    FastDriver.NextGenDocumentPreparation.SavePhrase.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                }
            }
            else
            {
                Support.AreEqual(false.ToString(), false.ToString(), "Results not displayed");
            }
            #endregion

        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup()
        {
            MasterTestClass.CleanupClass();
        }
    }
}
