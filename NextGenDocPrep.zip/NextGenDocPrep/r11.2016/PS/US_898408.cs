﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;


namespace NextGenDocPrep.r11._2016.PS
{

[CodedUITest]
[DeploymentItem(@"Editor\Microsoft.VisualStudio.TestTools.UITest.Extension.Silverlight.dll")]
   public class US_898408 : MasterTestClass 
    {

        #region Office and Region ID's Details

        private static int _regionId = 196;   
        private static int _officeId = 197;
        SilverlightSupport FALibSL = new SilverlightSupport();

        public int regionId
        {
            get { return _regionId; }
        }

        public int officeId
        {
            get { return _officeId; }
        }
        #endregion


        [TestMethod]

        public void TC_918000_Verify_Phrase_properties_saved_in_Template_Phrases_sub_tab()
        {
            try
            {
                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FASTHelpers.FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("197");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Verify Region drop-down and search for Tamplate
                Reports.TestStep = "Search Template in- Templates Search Criteria";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FADoubleClick();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateType.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.SendKeys("T*");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region View/Edit Template
                Reports.TestStep = "Right Click on Any Row fron Template Result and Select View/Edit";
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateResultsTable.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Modify Values in Phrases
                Reports.TestStep = "Click on Phrases Tab and modify values from Phrases Table for Any Row";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FADoubleClick();
                Support.IsTrue(true, FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(2, "*EINS/TX6A", 2, TableAction.DoubleClick);
                Playback.Wait(8000);
                FastDriver.NextGenDocumentPreparation.UnderConstruction_Chkbox.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("Notice to Lender of the Updation");
                FastDriver.NextGenDocumentPreparation.Status_Active.FAClick();
                FastDriver.NextGenDocumentPreparation.Editable_Chkbox.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FASelectItem("Tahoma");
                FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("11");
                FastDriver.NextGenDocumentPreparation.PhraseMargin_Top.FASetText("0.25");
                FastDriver.NextGenDocumentPreparation.PhraseMargin_Right.FASetText("0.8");
                FastDriver.NextGenDocumentPreparation.PhraseMargin_Left.FASetText("0.9");
                FastDriver.NextGenDocumentPreparation.PhraseMarginMode_FullJustify.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.PhraseMarginMode_KeepLinesTog.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.PhraseMarginMode_LinkToPreviousePhrase.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.FirstComment.FASetText("New Phrase addded");
                Reports.TestStep = "Save all values";
                FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.FAClick();
                Playback.Wait(8000);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                Playback.Wait(8000);
                #endregion

                #region Verify modified values
                Reports.TestStep = "Click on The Same Row And Verify Th Proprties";
                Support.IsTrue(true, FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(2, "*EINS/TX6A", 2, TableAction.DoubleClick);
                Playback.Wait(8000);
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.UnderConstruction_Chkbox.IsSelected(), "Checkbox is not selected");
                Support.AreEqual("Notice to Lender of the Updation", FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue().ToString());
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.Status_Active.IsSelected(), "Status is not Active");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.Editable_Chkbox.IsSelected(), "Checkbox is not selected");
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FAGetText().Contains("Tahoma").ToString(), true);
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FAGetText().Contains("12").ToString(), true);
                Support.AreEqual("0.25", FastDriver.NextGenDocumentPreparation.PhraseMargin_Top.FAGetValue().ToString());
                Support.AreEqual("0.8", FastDriver.NextGenDocumentPreparation.PhraseMargin_Right.FAGetValue().ToString());
                Support.AreEqual("0.9", FastDriver.NextGenDocumentPreparation.PhraseMargin_Left.FAGetValue().ToString());
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.PhraseMarginMode_FullJustify.IsSelected(), "Checkbox is not selected");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.PhraseMarginMode_LinkToPreviousePhrase.IsSelected(), "Checkbox is not selected");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.PhraseMarginMode_KeepLinesTog.IsSelected(), "Checkbox is not selected");
                #endregion

                #region Login Fast Again
                Reports.TestStep = "Login into the ADM Side.";
                FASTHelpers.FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("197");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Verify Region drop-down and search for Tamplate
                Reports.TestStep = "Search Template in- Templates Search Criteria";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FADoubleClick();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateType.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.SendKeys("T*");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region View/Edit Template
                Reports.TestStep = "Right Click on Any Row fron Template Result and Select View/Edit";
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateResultsTable.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Modify Values in Phrases
                Reports.TestStep = "Click on Phrases Tab and modify values from Phrases Table for Any Row";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FADoubleClick();
                Support.IsTrue(true, FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(2, "*EINS/TX6A", 2, TableAction.DoubleClick);
                Playback.Wait(8000);
                FastDriver.NextGenDocumentPreparation.UnderConstruction_Chkbox.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("Notice to Lender of the Delection");
                FastDriver.NextGenDocumentPreparation.Status_Active.FAClick();
                FastDriver.NextGenDocumentPreparation.Editable_Chkbox.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FASelectItem("Tahoma");
                FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("12");
                FastDriver.NextGenDocumentPreparation.PhraseMargin_Top.FASetText(".26");
                FastDriver.NextGenDocumentPreparation.PhraseMargin_Right.FASetText("0.9");
                FastDriver.NextGenDocumentPreparation.PhraseMargin_Left.FASetText("0.7");
                FastDriver.NextGenDocumentPreparation.PhraseMarginMode_FullJustify.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.PhraseMarginMode_KeepLinesTog.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.PhraseMarginMode_LinkToPreviousePhrase.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.FirstComment.FASetText("New Phrase addded");
                Reports.TestStep = "Save all values";
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                Playback.Wait(8000);
                #endregion

                #region Verify modified values
                Reports.TestStep = "Click on The Same Row And Verify Th Proprties";
                Support.IsTrue(true, FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(2, "*EINS/TX6A", 2, TableAction.DoubleClick);
                Playback.Wait(8000);
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.UnderConstruction_Chkbox.IsSelected(), "Checkbox is not selected");
                Support.AreEqual("Notice to Lender of the Delection", FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue().ToString());
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.Status_Active.IsSelected(), "Status is not Active");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.Editable_Chkbox.IsSelected(), "Checkbox is not selected");
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FAGetText().Contains("Tahoma").ToString(), true);
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FAGetText().Contains("12").ToString(), true);
                Support.AreEqual("0.26", FastDriver.NextGenDocumentPreparation.PhraseMargin_Top.FAGetValue().ToString());
                Support.AreEqual("0.9", FastDriver.NextGenDocumentPreparation.PhraseMargin_Right.FAGetValue().ToString());
                Support.AreEqual("0.7", FastDriver.NextGenDocumentPreparation.PhraseMargin_Left.FAGetValue().ToString());
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.PhraseMarginMode_FullJustify.IsSelected(), "Checkbox is not selected");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.PhraseMarginMode_LinkToPreviousePhrase.IsSelected(), "Checkbox is not selected");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.PhraseMarginMode_KeepLinesTog.IsSelected(), "Checkbox is not selected");

                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]

        public void TC_918553_Verify_Phrase_properties_getting_saved_in_Template_Phrases_sub_tab_Docprep()
        {
              try
            {
                #region Login Fast
                Reports.TestStep = "Login into the ADM Side.";
                FASTHelpers.FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("197");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();                
                #endregion

                #region Verify Region drop-down and search for Tamplate
                Reports.TestStep = "Search Template in- Templates Search Criteria";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FADoubleClick();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateType.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.SendKeys("T*");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region View/Edit Template
                Reports.TestStep = "Right Click on Any Row fron Template Result and Select View/Edit";
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateResultsTable.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Modify Values in Phrases
                Reports.TestStep = "Click on Phrases Tab and modify values from Phrases Table for Any Row";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FADoubleClick();
                Support.IsTrue(true, FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(2, "*EINS/TX6A", 2, TableAction.DoubleClick);
                Playback.Wait(8000);
                FastDriver.NextGenDocumentPreparation.UnderConstruction_Chkbox.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("Notice to Lender of the Updation");
                FastDriver.NextGenDocumentPreparation.Status_Active.FAClick();
                FastDriver.NextGenDocumentPreparation.Editable_Chkbox.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.AvailableToAllRegion_CheckBox.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FASelectItem("Tahoma");
                FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("11");
                FastDriver.NextGenDocumentPreparation.PhraseMargin_Top.FASetText("0.25");
                FastDriver.NextGenDocumentPreparation.PhraseMargin_Right.FASetText("0.8");
                FastDriver.NextGenDocumentPreparation.PhraseMargin_Left.FASetText("0.9");
                FastDriver.NextGenDocumentPreparation.PhraseMarginMode_FullJustify.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.PhraseMarginMode_KeepLinesTog.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.PhraseMarginMode_LinkToPreviousePhrase.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.FirstComment.FASetText("New Phrase addded");
                Reports.TestStep = "Save all values";
                FastDriver.NextGenDocumentPreparation.SaveButtonPhraseProperties.FAClick();
                Playback.Wait(8000);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                Playback.Wait(8000);
                #endregion

                #region Verify modified values
                Reports.TestStep = "Click on The Same Row And Verify Th Proprties";
                Support.IsTrue(true, FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(2, "*EINS/TX6A", 2, TableAction.DoubleClick);
                Playback.Wait(8000);
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.UnderConstruction_Chkbox.IsSelected(), "Checkbox is not selected");
                Support.AreEqual("Notice to Lender of the Updation", FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue().ToString());
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.Status_Active.IsSelected(), "Status is not Active");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.Editable_Chkbox.IsSelected(), "Checkbox is not selected");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.AvailableToAllRegion_CheckBox.IsSelected(), "Checkbox is not selected");
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FAGetText().Contains("Tahoma").ToString(), true );
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FAGetText().Contains("12").ToString(), true);
                Support.AreEqual("0.25", FastDriver.NextGenDocumentPreparation.PhraseMargin_Top.FAGetValue().ToString());
                Support.AreEqual("0.8", FastDriver.NextGenDocumentPreparation.PhraseMargin_Right.FAGetValue().ToString());
                Support.AreEqual("0.9", FastDriver.NextGenDocumentPreparation.PhraseMargin_Left.FAGetValue().ToString());
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.PhraseMarginMode_FullJustify.IsSelected(), "Checkbox is not selected");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.PhraseMarginMode_LinkToPreviousePhrase.IsSelected(), "Checkbox is not selected");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.PhraseMarginMode_KeepLinesTog.IsSelected(), "Checkbox is not selected");
                #endregion 

                #region Login Fast Again
                Reports.TestStep = "Login into the ADM Side.";
                FASTHelpers.FAST_Login_ADM(isSuperUser: true);
                #endregion

                #region Office selection
                Reports.TestStep = "Navigate to QA Sandpointe NG Region";
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("197");
                #endregion

                #region  Navigate NexGen Document Preparation
                Reports.TestStep = "Navigate NexGen Document Preparation";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Verify Region drop-down and search for Tamplate
                Reports.TestStep = "Search Template in- Templates Search Criteria";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FADoubleClick();
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateType.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("Escrow Instruction");
                FastDriver.NextGenDocumentPreparation.TemplateDescription.SendKeys("T*");
                FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region View/Edit Template
                Reports.TestStep = "Right Click on Any Row fron Template Result and Select View/Edit";
                Support.AreEqual(true.ToString(), FastDriver.NextGenDocumentPreparation.TemplateResultsTable.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplateResultsTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.ViewEditTemplate.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please", false, 10);
                #endregion

                #region Modify Values in Phrases
                Reports.TestStep = "Click on Phrases Tab and modify values from Phrases Table for Any Row";
                FastDriver.NextGenDocumentPreparation.TemplatePhrases.FADoubleClick();
                Support.IsTrue(true, FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(2, "*EINS/TX6A", 2, TableAction.DoubleClick);
                Playback.Wait(8000);
                FastDriver.NextGenDocumentPreparation.UnderConstruction_Chkbox.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText("Notice to Lender of the Delection");
                FastDriver.NextGenDocumentPreparation.Status_Active.FAClick();
                FastDriver.NextGenDocumentPreparation.Editable_Chkbox.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.AvailableToAllRegion_CheckBox.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FASelectItem("Tahoma");
                FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FASelectItem("12");
                FastDriver.NextGenDocumentPreparation.PhraseMargin_Top.FASetText(".26");
                FastDriver.NextGenDocumentPreparation.PhraseMargin_Right.FASetText("0.9");
                FastDriver.NextGenDocumentPreparation.PhraseMargin_Left.FASetText("0.7");
                FastDriver.NextGenDocumentPreparation.PhraseMarginMode_FullJustify.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.PhraseMarginMode_KeepLinesTog.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.PhraseMarginMode_LinkToPreviousePhrase.FASetCheckbox(true);
                FastDriver.NextGenDocumentPreparation.FirstComment.FASetText("New Phrase addded"); 
                Reports.TestStep = "Save all values";
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                Playback.Wait(8000);
                #endregion

                #region Verify modified values
                Reports.TestStep = "Click on The Same Row And Verify Th Proprties";
                Support.IsTrue(true, FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.Exists().ToString());
                FastDriver.NextGenDocumentPreparation.TemplatePhrasesTablelist.PerformTableAction(2, "*EINS/TX6A", 2, TableAction.DoubleClick);
                Playback.Wait(8000);
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.UnderConstruction_Chkbox.IsSelected(), "Checkbox is not selected");
                Support.AreEqual("Notice to Lender of the Delection", FastDriver.NextGenDocumentPreparation.DesPhrasesName.FAGetValue().ToString());
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.Status_Active.IsSelected(), "Status is not Active");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.Editable_Chkbox.IsSelected(), "Checkbox is not selected");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.AvailableToAllRegion_CheckBox.IsSelected(), "Checkbox is not selected");
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.PhraseFont_Name.FAGetText().Contains("Tahoma").ToString(), true);
                Support.AreEqual("True", FastDriver.NextGenDocumentPreparation.PhraseFont_Size.FAGetText().Contains("12").ToString(), true);
                Support.AreEqual("0.26", FastDriver.NextGenDocumentPreparation.PhraseMargin_Top.FAGetValue().ToString());
                Support.AreEqual("0.9", FastDriver.NextGenDocumentPreparation.PhraseMargin_Right.FAGetValue().ToString());
                Support.AreEqual("0.7", FastDriver.NextGenDocumentPreparation.PhraseMargin_Left.FAGetValue().ToString());
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.PhraseMarginMode_FullJustify.IsSelected(), "Checkbox is not selected");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.PhraseMarginMode_LinkToPreviousePhrase.IsSelected(), "Checkbox is not selected");
                Support.IsTrue(FastDriver.NextGenDocumentPreparation.PhraseMarginMode_KeepLinesTog.IsSelected(), "Checkbox is not selected");
                #endregion

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }


       

        [TestInitialize]
        public override void TestInitialize()
        {
            FASTHelpers.CloseRelatedProcesses();
            base.TestInitialize();
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

        }


    }

